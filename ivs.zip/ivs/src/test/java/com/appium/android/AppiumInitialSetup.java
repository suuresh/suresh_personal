package com.appium.android;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.stream.StreamSupport;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.testcases.ACSInitialSetUp;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class AppiumInitialSetup {
	public WebDriver driver;
	public Xls_Reader excel;
	public SoftAssert sAssertion;
	int invocationCount = 2;
	public GenericMethods generic;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String XlSheetName = null;
	public String XlFileName = null;

	public static final String DEVICE_CONNECT_ADB_COMMAND = "adb connect 172.31.2.204:5555";
	public static final String DEVICE_AWAK_ADB_COMMAND = "adb shell input keyevent KEYCODE_POWER";

	public static Logger log = Logger.getLogger(ACSInitialSetUp.class);
	@Parameters({ "XlFileName", "XlSheetName" })
	@BeforeClass
	public void appiumSetUp(String xlfilename, String xlsheetname) {
		appiumService = AppiumDriverLocalService.buildService(new
				  AppiumServiceBuilder() .usingDriverExecutable(new
				  File(Config.NODE_JS_PATH)).withAppiumJS(new File(Config.APPIUM_MAIN_PATH))
				  .withLogFile(new File(System.getProperty("user.dir") + "/Appium.log"))
				  .withArgument(GeneralServerFlag.LOCAL_TIMEZONE));
				  
				  appiumService.start();
				  
			XlFileName = xlfilename;	  
			XlSheetName = xlsheetname;
		
	}
	
	@Parameters({ "Mobile-operating-system" })
	@BeforeMethod
	public void preCondtion(String MobileOS) throws MalformedURLException {
		
		PropertyConfigurator.configure(System.getProperty("user.dir")
			+ "/log4j.properties");
	//	GenericMethods.updateRBADefault();
		

		if (MobileOS.equalsIgnoreCase("android")) {
			File app = new File(Config.BASE_ANDROID_APK_FILE_PATH);
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, Config.ANDROID_DEVICE_NAME);
			capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, Config.ANDROID_VERSION);
			capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
			capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
			capabilities.setCapability("locationServicesAuthorized", true);
			capabilities.setCapability("autoGrantPermissions", "true");
			capabilities.setCapability("autoAcceptAlerts", "true");
			capabilities.setCapability(MobileCapabilityType.FULL_RESET, "false");
			capabilities.setCapability(MobileCapabilityType.NO_RESET, "true");
		//	capabilities.setCapability("appPackage", "com.wibmo.threeds2.sdk.sampleapp");
		//	capabilities.setCapability("appActivity", "com.wibmo.threeds2.sdk.sampleapp.MainUIActivity");
			aDriver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			aDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		

			sAssertion = new SoftAssert();
		}	
	}
	
	@AfterClass
	public void postclassmethod() {
		appiumService.stop();
	}
	public static void runADBCommand(String command) throws Exception {
		Runtime.getRuntime().exec(command);
	}
	
	/* ***********Command to kill appium which is already running
	
	Windows: taskkill /F /IM node.exe
	Linux: killall node
	
	///////////To find pacekage and activity name ///
	open command prompt
	adb shell
	dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp'
	
	//// to find secure id 
	 * 
	 * adb shell settings get secure android_id
	
	
	****************************** */
	
	
	
}

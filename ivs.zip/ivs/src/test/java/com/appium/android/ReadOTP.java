package com.appium.android;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.acs.libraries.Config;
import com.acs.pages.CardEncryptHomePage;
import com.acs.pages.CheckOutPage;
import com.acs.pages.MultiSelectPage;
import com.acs.pages.OTPPage;
import com.acs.pages.PgResponsePage;
import com.acs.pages.SingleSelectPage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.GetHeaders;
import com.appium.android.ReadOTP;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class ReadOTP {
	
	private final static String SMS_POPUP_CLASSPATH = System.getProperty("user.dir")+"/APKFiles/";
	private final static String SMS_POPUP_APP_NAME = "SMSPopup.apk";
	private final static String SMS_POPUP_PACKAGE_NAME = "net.everythingandroid.smspopup";
	private final static String DEVICE_ID = "05E3DF923D509EFF";

	private final static String ADB_INSTALL_COMMAND = "adb -s " + Config.ANDROID_DEVICE_NAME + " install -r "
			+ SMS_POPUP_CLASSPATH + SMS_POPUP_APP_NAME + "";
	private final static String ADB_UNINSTALL_COMMAND = "adb -s " + Config.ANDROID_DEVICE_NAME + " uninstall "
			+ SMS_POPUP_PACKAGE_NAME + "";
	private final static String ADB_START_ACTIVITY = "adb -s " + Config.ANDROID_DEVICE_NAME
			+ " shell am start -n net.everythingandroid.smspopup/.ui.SmsPopupConfigActivity";
	private final static String ADB_GO_BACK = "adb -s " + Config.ANDROID_DEVICE_NAME + " shell input keyevent 4";

	private final static String TYPE_SEARCH_TEXT_STARTSWITH = "textStartsWith";
	private final static String TYPE_SEARCH_TEXT_CONTAINS = "textContains";
	private final static String TYPE_SEARCH_TEXT = "text";

	private WebDriverWait wait60;
	private Wait<WebDriver> fluentWait30;
	private AppiumDriver localDriver;

	WebDriver driver;
	public AndroidDriver<AndroidElement> aDriver;
	public AppiumDriverLocalService appiumService;

	public static final String DEVICE_CONNECT_ADB_COMMAND = "adb connect 172.31.2.204:5555";
	public static final String DEVICE_AWAK_ADB_COMMAND = "adb shell input keyevent KEYCODE_POWER";

	public ReadOTP(WebDriver driver) {
		this.driver = driver;
		this.driver = driver;
		wait60 = new WebDriverWait(driver, 60);
		fluentWait30 = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		// PageFactory.initElements(driver, this);
		// logger = Logger.getLogger(this.getClass().getName());
	}

	public static void runADBCommand(String command) throws Exception {
		Runtime.getRuntime().exec(command);
	}

	public void launchAppium() throws MalformedURLException {
/*
		try {
			runADBCommand("adb devices");
			Thread.sleep(3000);
			runADBCommand(ReadOTP.DEVICE_CONNECT_ADB_COMMAND);
			Thread.sleep(2000);
			runADBCommand(ReadOTP.DEVICE_AWAK_ADB_COMMAND);
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
		appiumService = AppiumDriverLocalService.buildService(new AppiumServiceBuilder()
				.usingDriverExecutable(new File(Config.NODE_JS_PATH)).withAppiumJS(new File(Config.APPIUM_MAIN_PATH))
				.withLogFile(new File(System.getProperty("user.dir") + "\\Logs\\Appium.log"))
				.withArgument(GeneralServerFlag.LOCAL_TIMEZONE));
		
		appiumService.start();

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", Config.ANDROID_DEVICE_NAME);
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", Config.ANDROID_VERSION);
	//	capabilities.setCapability("deviceId", Config.ANDROID_DEVICE_ID);
	//	capabilities.setCapability("appPackage", "com.samsung.android.messaging");
	//	capabilities.setCapability("appActivity", "com.android.mms.ui.ComposeMessageMms");
		capabilities.setCapability("appPackage", "com.android.mms");
		capabilities.setCapability("appActivity", "com.android.mms.ui.conversation.ConversationActivity");
		
		aDriver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		//aDriver.manage().timeouts().implicitlyWait(20L, TimeUnit.SECONDS);
	}

	public void StopAppiumService() {

		appiumService.stop();

	}

	public String readOTP() throws MalformedURLException {

		ReadOTP r = new ReadOTP(driver);
		r.getMsgContentFromNotification(aDriver, "VK-WIBINC", " is your");

		String otpSms = r.getOtpFromNotificationAdv(aDriver, "VK-WIBINC", " is your");
		/*
		 * System.out.println("OTP is :" + otpSms); otp.getOtpField().sendKeys(otpSms);
		 * 
		 * otp.getOtpSubmitButton().click();
		 */
		// appiumService.stop();

		return otpSms;
	}

	public String getMsgContentFromNotification(AndroidDriver aDriver, String notifictionTitle, String smsContent) {

		(aDriver).openNotifications();

		String notificationXp = "//*[contains(@text,'notifictionTitle')]".replace("notifictionTitle", notifictionTitle);

		aDriver.findElement(By.xpath(notificationXp)).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}
		aDriver.findElement(By.xpath(notificationXp)).click();
		String contentXp = "(//*[contains(@text,'smsContent')])[last()]".replace("smsContent", smsContent);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}

		return aDriver.findElement(By.xpath(contentXp)).getText();

	}

	public String getOtpFromNotificationAdv(AndroidDriver aDriver, String notifictionTitle, String smsContent) {

		String smsText = getMsgContentFromNotification(aDriver, notifictionTitle, smsContent);

		System.out.println("====================Sms Text: " + smsText + "====================");

		for (String str : smsText.split(" ")) {
			if (str.matches("\\d{6}")) {
				return str;
			}

		}
		return "123456";

	}
	
	public String readOTPinSMS(String SMSText) {

		System.out.println("====================Sms Text: " + SMSText + "====================");

		for (String str : SMSText.split(" ")) {
			if (str.matches("\\d{6}")) {
				return str;
			}

		}
		return "123456";

	}
	
	public void installSMSAPK() throws Exception {
		/*
		 * If you do not always want to install SMS APK then check if package already
		 * exists in device: adb shell pm list packages net.everythingandroid.smspopup
		 * it will reply package:[your.package.name] if it is installed already or
		 * anything otherwise FOR NOW I'll junst uninstall it always or else current
		 * configureSMSAPK() would fail
		 */
		this.uninstallSMSAPK();
		runADBCommand(String.format(ADB_INSTALL_COMMAND, DEVICE_ID, new File(SMS_POPUP_CLASSPATH, SMS_POPUP_APP_NAME).getAbsolutePath()));
		Thread.sleep(6000); // --> This can be replaced by checking if package is already installed. In
							// slower devices this sleep may not be enough
	}

	public static void uninstallSMSAPK() throws Exception {
		runADBCommand(String.format(ADB_UNINSTALL_COMMAND, DEVICE_ID, SMS_POPUP_PACKAGE_NAME));
		Thread.sleep(2000);
	}

	public void configureSMSAPK() throws Exception {
		runADBCommand(String.format(ADB_START_ACTIVITY, DEVICE_ID));
		
	    localDriver.findElement(By.id("android:id/button1")).click();
		Thread.sleep(2000);
		waitForIDwithText("android:id/button1", "Accept", TYPE_SEARCH_TEXT).click();

		runADBCommand(String.format(ADB_GO_BACK, DEVICE_ID));
	}

	public String returnSMS() throws Exception {
		String SMS;

		waitForID("net.everythingandroid.smspopup:id/popupMessageMainlayout");
		SMS = waitForID("net.everythingandroid.smspopup:id/messageTextView").getText();
		// System.out.println(String.format(ADB_GO_BACK, DEVICE_ID));
		runADBCommand(String.format(ADB_GO_BACK, DEVICE_ID));
		// System.out.println("SMS is :"+SMS);
		return SMS;
	}
	
	/*
	 * @parameter id Indicates the id of Element to be searched
	 * 
	 * @parameter value Indicates the text in Element to be searched
	 * 
	 * @parameter typeSearch Indicates the type of search
	 * [textStartsWith|textContains|text]
	 */
	private WebElement waitForIDwithText(String id, String value, String typeSearch) throws Exception {
		try {
			String query = "new UiSelector().resourceId(\"" + id + "\")." + typeSearch + "(\"" + value + "\")";
			System.out.println("Query " + query);
			return fluentWait30.until(webDriver -> ((AndroidDriver) localDriver).findElementByAndroidUIAutomator(query));
		} catch (Exception ex) {
			throw new Exception("The following id was not found: " + id);
		}
	}

	/*
	 * @parameter id Indicates the id of Element to be searched
	 */
	private WebElement waitForID(String id) throws Exception {
		try {
			return wait60.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		} catch (Exception ex) {
			throw new Exception("The following id was not found: " + id);
		}
	}


}

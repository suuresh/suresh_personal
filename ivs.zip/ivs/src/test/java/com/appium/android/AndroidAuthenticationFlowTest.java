package com.appium.android;

import java.awt.AWTException;
import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.logging.LogEntries;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.android.pages.AndroidCheckOutPage;
import com.acs.android.pages.AndroidOTPPage;
import com.acs.android.pages.AndroidResponsePage;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MultiSelectPage;
import com.acs.pages.SingleSelectPage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.EncryptAndDecrypt;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.OTPFromEngine;

import io.appium.java_client.android.AndroidElement;

public class AndroidAuthenticationFlowTest extends AppiumInitialSetup {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;
	String acsTxnId;
	LogEntries NetWorklogs;

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "MobileCards");
	}

	@Test(dataProvider = "DataSet", invocationCount=1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId, String AcquirerBankName, String Cardnumber, String Flow, String amount,
			String currencytype, String CardUnionType, String acsTxnId, String decs)
			throws AWTException, MalformedURLException, InterruptedException {

		 ExtentTestManager.getTest().setDescription(decs);
		 SoftAssert sAssertion = new SoftAssert();
		AndroidCheckOutPage androidcheckout = new AndroidCheckOutPage(aDriver);
		AndroidOTPPage otp = new AndroidOTPPage(aDriver);
		AndroidResponsePage response = new AndroidResponsePage(aDriver);

		if (Flow.equalsIgnoreCase("BlockCard")) {
			System.out.println("Block Card condition");
		//	generic.updateCardStatusToActive(EncryptAndDecrypt.EncryptnDecryptData(Cardnumber, "N", IssuerBankId), IssuerBankId);
			System.out.println("Updated the card to active state, before blocking the card");
		}
		androidcheckout.getCurrencySymbol().click();
		aDriver.findElement(By.xpath("//android.widget.CheckedTextView[@text='" + currencytype + "']")).click();

		androidcheckout.getAmountTextField().clear();
		androidcheckout.getAmountTextField().sendKeys(amount);
		System.out.println("Amount entered");
		aDriver.hideKeyboard();
		androidcheckout.gettShirtSizeRadioButton().click();
		System.out.println("TShirt Size radio button clicked");
		androidcheckout.getBuyNowButton().click();
		System.out.println("buy now button clicked");
		generic.explicitWait(3);
		/*
		 * if(androidcheckout.getPermissionAllowButton().isDisplayed()) {
		 * androidcheckout.getPermissionAllowButton().click(); //
		 * generic.explicitWait(1); generic.explicitWait(3);
		 * androidcheckout.getPermissionAllowButton().click(); //
		 * generic.explicitWait(1); generic.explicitWait(3); }else
		 * System.out.println("Permission button is not displayed");
		 */
		androidcheckout.getContinueButton().click();
		System.out.println("continue button clicked");
		generic.explicitWait(1);

		androidcheckout.getCardNumberTextField().clear();
		androidcheckout.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Entere Card number");
		aDriver.hideKeyboard();
		androidcheckout.getCardHolderNameTextFiled().clear();
		androidcheckout.getCardHolderNameTextFiled().sendKeys(Config.ANDRIOD_CARD_HOLDER_NAME);
		System.out.println("Entere Card holder name");
		aDriver.hideKeyboard();
		androidcheckout.getCardExpiryYearTextField().clear();
		androidcheckout.getCardExpiryYearTextField().sendKeys(Config.CARD_EXPIRY_YEAR);
		androidcheckout.getCardExpiryDateTextField().sendKeys(Config.CARD_EXPIRY_MONTH);
		androidcheckout.getCardCVVTextField().sendKeys(Config.CARD_CVV);
		System.out.println("Entere Card CVV number");
		aDriver.hideKeyboard();

		androidcheckout.getMakePaymentButton().click();
		System.out.println("Payment Button Clicked");
		generic.explicitWait(1);

		switch (Flow) {

		case "FrictionLess":
			System.out.println(Flow + " Started");
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Success");
			System.out.println(Flow + " Completed");
			break;

		case "Challenge":
			System.out.println(Flow + "Started");
			generic.explicitWait(2);
			acsTxnId = otp.getOTPSubmitButton().getText();
			String otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId.toLowerCase());

			otp.getOTPTextField().sendKeys(otpValue);
			otp.getOTPSubmitButton().click();
			generic.writingToExcel(XlFileName,"MobileCards", "AcsTxnId", invocationCount, acsTxnId);
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Success");
			System.out.println(Flow + " Completed");
			break;

		case "Blocked":
			System.out.println("Testing blocked");
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Failure");
			System.out.println(Flow + " Completed");
			break;

		case "BlockCard":
			System.out.println(Flow + " Started");
			acsTxnId = otp.getOTPSubmitButton().getText();
			otp.getOTPTextField().clear();
			otp.getOTPTextField().sendKeys("123456");
			otp.getOTPSubmitButton().click();
			otp.getOTPTextField().clear();
			otp.getOTPTextField().sendKeys("123456");
			otp.getOTPSubmitButton().click();
			otp.getOTPTextField().clear();
			otp.getOTPTextField().sendKeys("123456");
			otp.getOTPSubmitButton().click();
			generic.writingToExcel(XlFileName, "MobileCards", "AcsTxnId", invocationCount, acsTxnId);
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Failure");
			System.out.println(Flow + " Completed");
			break;

		case "Canceled":
			System.out.println(Flow + " Started");
			acsTxnId = otp.getOTPSubmitButton().getText();
			otp.getCancelButton().click();
			System.out.println("Canceled the Transaction");
			generic.writingToExcel(XlFileName,"MobileCards", "AcsTxnId", invocationCount, acsTxnId);
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Failure");
			System.out.println(Flow + "Completed");
			break;

		case "Failed":
			System.out.println(Flow + " Started");
			sAssertion.assertEquals(response.getTransactionStatus().getText(), "Failure");
			System.out.println(Flow + "Completed");
			break;
		}

		generic.explicitWait(2);
		System.out.println("Checking the final page");

		System.out.println("verified transaction");
		if (response.getTransactionStatus().getText().equalsIgnoreCase("Success")) {

			if (currencytype.equalsIgnoreCase("INR")) {
				sAssertion.assertEquals(response.getTransactionDescription().getText(),
						"Your order of ₹ " + amount + " is successfully completed.");
			} else if (currencytype.equalsIgnoreCase("USD")) {
				sAssertion.assertEquals(response.getTransactionDescription().getText(),
						"Your order of $ " + amount + " is successfully completed.");
			} else if (currencytype.equalsIgnoreCase("EURO")) {
				sAssertion.assertEquals(response.getTransactionDescription().getText(),
						"Your order of € " + amount + " is successfully completed.");
			}
		}

		
		  if (Flow.equalsIgnoreCase("Blocked")) {
		  System.out.println("Making the BLOCKED card to active");
		//  generic.updateCardStatusToActive(EncryptAndDecrypt.EncryptnDecryptData(Cardnumber, "N", IssuerBankId), IssuerBankId); 
		  System.out.println("Updated the card to active state, before blocking the card"); }
		 

		// generic.explicitWait(3);
		sAssertion.assertAll();
		System.out.println("Invocation count: " + invocationCount);
		// System.out.println(Flow + " Completed");
		// androidcheckout.getContinueShopingButton().click();
		// System.out.println("Continue shopping button clicked");
		// generic.explicitWait(2);
		invocationCount++;

	}

}

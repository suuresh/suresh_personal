package com.api.pushapi;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PushApiFlow extends ACSInitialSetUp {

	int invocationCount = 2;
	public String acsTxnId = null;

	public String encodeGenerateOtpResponse = null;
	
	public String rbaAuthAttempted = null;
	public String generateOtp = null;
	public String decodeGenerateOtpRequest = null;
	public String decodeVerifyOtpRequest = null;
	public String encodeVerifyOtpRequest = null;
	public String verifyOTP = null;
	public Response response = null;
	public Response response1 = null;

	public JsonPath jsonPathEvaluator = null;
	public JsonPath jsonPathEvaluator1 = null;
	public String issuer_guid = null;
	public String authResponseCode = null;
	public String errormsg = null;
	public String errorcode = null;
	public String txnId = null;
	public String preTxnId = null;
	public String preRequestId = null;

	public Xls_Reader excel;

	public LogOutPage logout;
	public LoginPage loginPage;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String XlFileName = null;
	public String OnBoradingXlFileName = null;
	public TridentLogOutPage tlogout;
	public TridentLoginPage tloginPage;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String proxyUrl = null;
	public WebDriverWait wait;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	@SuppressWarnings("deprecation")
	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
			"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
			"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName", "ENV" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename,
			String txn1_0sheetName, String txn2_0sheetName, String acstxn1_0sheetName, String acstxn2_0sheetName,
			String tridenttxn1_0sheetName, String tridenttxn2_0sheetName, String threedsstxn2_0sheetName, String env)
			throws Exception {
	
		Config.BASE_ENVIRONMENT = env;
		Config.assignEnvironment();
		

		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0SheetName = txn1_0sheetName;
		Txn2_0SheetName = txn2_0sheetName;
		ACSTxn1_0SheetName = acstxn1_0sheetName;
		ACSTxn2_0SheetName = acstxn2_0sheetName;
		TridentTxn1_0SheetName = tridenttxn1_0sheetName;
		TridentTxn2_0SheetName = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0SheetName = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;
	}
	
	

	@DataProvider
	public Object[][] DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, Txn1_0SheetName);
	}
	

	@Test(dataProvider="DataSet",invocationCount=1)
	public void pushAPITest(String issuerBankId, String issuerBankName, String binRange, String accountNumber,
			String primaryPhoneNumber, String primaryEmail, String action, String flow, String nameOnCard,
			String statusCode, String statusDescription, String decs) throws Exception {
		
		System.out.println("*****************Test Started*********************");
		
		System.out.println("binRange:"+binRange);
		Thread.sleep(2000);
		SoftAssert sAssertion = new SoftAssert();
		
		if(flow.contentEquals("Insert")) {
			
			GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "accountNumber", invocationCount, "");
			Long randumnumber = (long) Math.floor(Math.random() * 9000000000L);
			accountNumber = binRange + String.valueOf(randumnumber);
		}
		
		String apiReferenceId =  String.valueOf((long) Math.floor(Math.random() * 9000000000L)) + String.valueOf((long) Math.floor(Math.random() * 9000L));
		System.out.println("apiReferenceId:"+apiReferenceId);
		
		String pushApiRequestBody = RequestBodyHelper.pushApiRequestBody(accountNumber, apiReferenceId, action, issuerBankId, primaryPhoneNumber, primaryEmail, nameOnCard);
		System.out.println("pushApiRequestBody:"+pushApiRequestBody);
		
		Response response = PushApiMethods.pushApiEncryptRequest(pushApiRequestBody, issuerBankId );
		//JsonPath jsonPathEvaluator = response.jsonPath();
		Thread.sleep(2000);
		String responseBody = response.getBody().asString();
		
		System.out.println(responseBody);
		
		
		
		Response response1 = PushApiMethods.pushApiPostRequest(responseBody, issuerBankId, apiReferenceId);
		JsonPath jsonPathEvaluator1 = response1.jsonPath();
		Thread.sleep(2000);
		
		
		String resStatusCode = jsonPathEvaluator1.getString("statusCode");
		String resStatusDescription = jsonPathEvaluator1.getString("statusDescription");
		
	
		System.out.println("resStatusCode:" + resStatusCode);
		System.out.println("resStatusDescription:" + resStatusDescription);
		
		sAssertion.assertEquals(resStatusCode, statusCode);
		sAssertion.assertEquals(resStatusDescription, statusDescription);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "accountNumber", invocationCount, accountNumber);
		sAssertion.assertAll();
		invocationCount++;
		
		
		
	}
	
	

}

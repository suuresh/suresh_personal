package com.api.pushapi;

import static io.restassured.RestAssured.given;

import org.testng.Reporter;

import com.acs.libraries.Config;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PushApiMethods {
	
	
	
	public static Response pushApiEncryptRequest(String jsonBody, String IssuerBankId) {
		System.out.println(Config.BASE_PUSH_API_ENCRYPT_URL +  IssuerBankId);
		Response pushapiencryptresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonBody)
				.when()
				.post(Config.BASE_PUSH_API_ENCRYPT_URL +  IssuerBankId);
		
		
		pushapiencryptresponse.then().statusCode(200);
		
		return pushapiencryptresponse;
	}
	
	public static Response pushApiPostRequest(String encryptedtext, String IssuerBankId, String apiReferenceId) {

		Reporter.log("encrypted text to push api");
		
		System.out.println(Config.BASE_PUSH_API_URL + IssuerBankId+"/"+apiReferenceId);

		Response pushapiresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(encryptedtext)
				.when()
				.post(Config.BASE_PUSH_API_URL+  IssuerBankId+"/"+apiReferenceId);
		
		
		pushapiresponse.then().statusCode(200);
	
		
		return pushapiresponse;

	}
}

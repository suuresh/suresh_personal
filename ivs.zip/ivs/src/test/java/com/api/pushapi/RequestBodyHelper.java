package com.api.pushapi;

public class RequestBodyHelper {
    
    public static String pushApiRequestBody(String accountNumber, String apiReferenceId, String action, String bankid, String primaryPhoneNumber, String primaryEmail, String nameOnCard)
    {
        String jsonbody= "{"
        		+ "  \"accountNumber\": \""+accountNumber+"\","
        		+ "  \"apiVersion\": \"3.0\","
        		+ "  \"apiReferenceId\": \""+apiReferenceId+"\","
        		+ "  \"accountIdentifer\": \"12345\","
        		+ "  \"cardExpiry\": \"1224\","
        		+ "  \"expirymode\": \"mmyy\","
        		+ "  \"validFrom\": \"1220\","
        		+ "  \"dob\": \"1982-12-23\","
        		+ "  \"cardType\": \"d\","
        		+ "  \"nameOnCard\": \""+nameOnCard+"\","
        		+ "  \"taxPan\": \"bxzps67543\","
        		+ "  \"primaryPhoneCountryCode\": \"91\","
        		+ "  \"primaryPhoneNumber\": \""+primaryPhoneNumber+"\","
        		+ "  \"primaryPhNumberId\": \"11111\","
        		+ "  \"secondaryPhoneCountryCode\": \"91\","
        		+ "  \"secondaryPhoneNumber\": \"9448774242\","
        		+ "  \"temporaryPhoneCountryCode\": \"91\","
        		+ "  \"temporaryPhoneNumber\": \"9448774242\","
        		+ "  \"primaryEmail\": \""+primaryEmail+"\","
        		+ "  \"secondaryEmail\": \"krishnamurthy.prabhu@wibmo.com\","
        		+ "  \"primaryAccountNumber\": \"1111222\","
        		+ "  \"primaryAccountPhoneCountryCode\": \"91\","
        		+ "  \"primaryAccountPhoneNumber\": \"9448774242\","
        		+ "  \"languagePreference\": \"en_us\","
        		+ "  \"status\": \"1\","
        		+ "  \"action\": \""+action+"\","
        		+ "  \"bankid\": \""+bankid+"\","
        		+ "  \"tokenizedAccountNumber\": \"sdsad\","
        		+ "  \"additionalFields\": {"
        		+ "    \"additionalField1\": \"test1\","
        		+ "    \"additionalField2\": \"test2\","
        		+ "    \"additionalField3\": \"test3\","
        		+ "    \"additionalField4\": \"test4\""
        		+ "  }"
        		+ "}";
        
        return jsonbody;
    }
}

package com.api.payuexpresspay;

import java.io.IOException;
import java.util.Random;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ExpressPayAuthenticationFlow extends ACSInitialSetUp{

	int invocationCount = 2;
	public String acsTxnId = null;

	public String otpGenHashResponse = null;
	public String rbaAuthAttempted = null;
	public String data = null;
	public String data1 = null;
	public Response response = null;
	public Response response1 = null;
	public Response response2 = null;

	public JsonPath jsonPathEvaluator = null;
	public JsonPath jsonPathEvaluator1 = null;
	public JsonPath jsonPathEvaluator2 = null;
	public String servertransactionid = null;
	
	/* Expresspay 2.0 Variables */
	public String encryptRequestResponse = null;
	public String generatedOTP = null;
	public String encryptValidateOTPResponse = null;

	public Xls_Reader excel;

	public LogOutPage logout;
	public LoginPage loginPage;
	public String Txn1_0 = null;
	public String Txn2_0 = null;
	public String ACSTxn1_0 = null;
	public String ACSTxn2_0 = null;
	public String TridentTxn1_0 = null;
	public String TridentTxn2_0 = null;
	public String ThreeDSSTxn2_0 = null;
	public String XlFileName = null;
	public String OnBoradingXlFileName = null;
	public TridentLogOutPage tlogout;
	public TridentLoginPage tloginPage;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String proxyUrl = null;
	public WebDriverWait wait;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	@SuppressWarnings("deprecation")
	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
			"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
			"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName", "ENV" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename,
			String txn1_0sheetName, String txn2_0sheetName, String acstxn1_0sheetName, String acstxn2_0sheetName,
			String tridenttxn1_0sheetName, String tridenttxn2_0sheetName, String threedsstxn2_0sheetName, String env)
			throws Exception {
	
		Config.BASE_ENVIRONMENT = env;
		Config.assignEnvironment();
		

		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0 = txn1_0sheetName;
		Txn2_0 = txn2_0sheetName;
		ACSTxn1_0 = acstxn1_0sheetName;
		ACSTxn2_0 = acstxn2_0sheetName;
		TridentTxn1_0 = tridenttxn1_0sheetName;
		TridentTxn2_0 = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0 = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;

	}

	@DataProvider
	public Object[][] ep1DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, Txn1_0);
	}

	@Test(dataProvider = "ep1DataSet", invocationCount = 1)
	public void expressPay1AuthenticationTest(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String ProtocalVersion, String Flow, String AuthPrefrence, String authFlag, String TransType, String CardUnionType, String acsTxnId, String CavvOrAvv, 
			String decs) throws Exception {

		SoftAssert sAssertion = new SoftAssert();

		long requestid = GenericMethods.generateRandomDigits(15);
		long clienttransactionid = GenericMethods.generateRandomDigits(15);
		long validateotprequestid = GenericMethods.generateRandomDigits(15);
		long resendotprequestid = GenericMethods.generateRandomDigits(15);
		long resendotprequestid1 = GenericMethods.generateRandomDigits(15);
		long resendotprequestid2 = GenericMethods.generateRandomDigits(15);
		long resendotprequestid3 = GenericMethods.generateRandomDigits(15);
		long validateotprequestid2 = GenericMethods.generateRandomDigits(15);

		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0, "CavvOrAvv", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "CavvOrAvv", invocationCount, "");

		switch (Flow) {

		case "Challenge":
			System.out.println("************* V2 challenge ******************");
			otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid);

			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);

			response = ApiMethods.getDecryptedResponse(data);

			jsonPathEvaluator = response.jsonPath();
			servertransactionid = jsonPathEvaluator.getString("process-result.server-transaction-id");
			Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);

			acsTxnId = GenericMethods.getACSTxnIdFromMPIDB(servertransactionid);
			// String CardNumber = FrameWorkUtils.getCardNumber("VALIDCARD");

			String ePayOtp = OTPFromDynamicConfig.getExpressPayOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

			String encryptedOTP = ApiMethods.getEncryptData(ePayOtp);

			String otpValidateHashResponse = ApiMethods.otpValidateHash(encryptedOTP, validateotprequestid,
					clienttransactionid, servertransactionid);

			data1 = ApiMethods.otpValidateInit(otpValidateHashResponse, validateotprequestid);

			response1 = ApiMethods.getDecryptedResponse(data1);
			jsonPathEvaluator1 = response1.jsonPath();
			System.out.println("Final response----"+response1.getBody().asString());
			// Reporter.log(response1.getBody().asString());

			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "000");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "sucess");

			sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.eci"), "05");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.status"), "Y");
			
			GenericMethods.writingToExcel(XlFileName, Txn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			break;

		case "ReSendOTP":
			System.out.println("************* V2 Resed OTP ******************");
			otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid);

			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);

			response = ApiMethods.getDecryptedResponse(data);

			jsonPathEvaluator = response.jsonPath();
			servertransactionid = jsonPathEvaluator.getString("process-result.server-transaction-id");
			Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);

			String otpResendHashResponse = ApiMethods.otpResendHash(resendotprequestid, clienttransactionid,
					servertransactionid);

			data1 = ApiMethods.otpResendInit(otpResendHashResponse, resendotprequestid);
			String otpResendHashResponse2 = ApiMethods.otpResendHash(resendotprequestid1, clienttransactionid,
					servertransactionid);
			data1 = ApiMethods.otpResendInit(otpResendHashResponse2, resendotprequestid1);

			String otpResendHashResponse3 = ApiMethods.otpResendHash(resendotprequestid2, clienttransactionid,
					servertransactionid);
			data1 = ApiMethods.otpResendInit(otpResendHashResponse3, resendotprequestid2);

			String otpResendHashResponse4 = ApiMethods.otpResendHash(resendotprequestid3, clienttransactionid,
					servertransactionid);
			data1 = ApiMethods.otpResendInit(otpResendHashResponse4, resendotprequestid3);

			response1 = ApiMethods.getDecryptedResponse(data1);
			jsonPathEvaluator1 = response1.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "015");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "otp limit reached");

			break;

		case "BlockCard":

			break;

		case "Blocked":
			System.out.println("************* V2 Blocked  ******************");
			String otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid);
			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);
			response = ApiMethods.getDecryptedResponse(data);
			jsonPathEvaluator = response.jsonPath();
			System.out.println(response.getBody().asString());

			System.out.println(jsonPathEvaluator.getString("meta-data.status-code"));
			Assert.assertEquals(jsonPathEvaluator.getString("meta-data.status-code"), "023");
			Assert.assertEquals(jsonPathEvaluator.getString("meta-data.status-description"), "card is blocked");

			break;

		case "Failed":

			break;
		
		case "V4Frictionless":
			System.out.println("************* V4 Frictionless ******************");
			otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid,AuthPrefrence, authFlag,"15");

			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);

			response = ApiMethods.getDecryptedResponse(data);

			jsonPathEvaluator = response.jsonPath();
			servertransactionid = jsonPathEvaluator.getString("process-result.server-transaction-id");
						Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);
			Reporter.log("RBA Auth Attempted : "+rbaAuthAttempted);
			sAssertion.assertEquals(jsonPathEvaluator.getString("meta-data.status-code"), "000");
			sAssertion.assertEquals(jsonPathEvaluator.getString("meta-data.status-description"), "Success");
			sAssertion.assertEquals(jsonPathEvaluator.getString("process-result.rba-auth-attempted"), "true");
			
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.status"), "Y");
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.eci"), "02");
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.rba-approval-status"), "true");
			
			GenericMethods.writingToExcel(XlFileName, Txn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "AcsTxnId", invocationCount, acsTxnId);
			break;
			
		case "V4FallBack":
			System.out.println("************* V4 Fall BAck ******************");
			otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid,AuthPrefrence, authFlag,"151");

			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);

			response = ApiMethods.getDecryptedResponse(data);

			jsonPathEvaluator = response.jsonPath();
			servertransactionid = jsonPathEvaluator.getString("process-result.server-transaction-id");
						Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);
			Reporter.log("RBA Auth Attempted : "+rbaAuthAttempted);
			sAssertion.assertEquals(jsonPathEvaluator.getString("meta-data.status-code"), "000");
			sAssertion.assertEquals(jsonPathEvaluator.getString("meta-data.status-description"), "Success");
			sAssertion.assertEquals(jsonPathEvaluator.getString("process-result.rba-auth-attempted"), "true");
			
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.status"), "Y");
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.eci"), "02");
			sAssertion.assertEquals(jsonPathEvaluator.getString("rba-authentication-result.rba-approval-status"), "true");
			
			GenericMethods.writingToExcel(XlFileName, Txn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "AcsTxnId", invocationCount, acsTxnId);
			break;	
			
		case "V4Challenge":
			System.out.println("************* V4 challenge ******************");
			otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid, clienttransactionid,AuthPrefrence, authFlag);

			data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);

			response = ApiMethods.getDecryptedResponse(data);

			jsonPathEvaluator = response.jsonPath();
			servertransactionid = jsonPathEvaluator.getString("process-result.server-transaction-id");
			rbaAuthAttempted = jsonPathEvaluator.getString("process-result.rba-auth-attempted");
			Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);
			Reporter.log("RBA Auth Attempted : "+rbaAuthAttempted);
			
			if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("FOR_REGISTRATION"))) {
			sAssertion.assertEquals(jsonPathEvaluator.getString("process-result.rba-auth-attempted"), "false");
			
			}else if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("RBA_REGISTERED"))) {
				sAssertion.assertEquals(jsonPathEvaluator.getString("process-result.rba-auth-attempted"), "false");
				
			}else if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("UNKNOWN"))) {
				sAssertion.assertEquals(jsonPathEvaluator.getString("process-result.rba-auth-attempted"), "false");
				
			}else if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("FOR_DEREGISTRATION"))) {
				sAssertion.assertEquals(jsonPathEvaluator.getString("process-data.user-registered-for-rba"), "true");
			}
			acsTxnId = GenericMethods.getACSTxnIdFromMPIDB(servertransactionid);
			// String CardNumber = FrameWorkUtils.getCardNumber("VALIDCARD");

			ePayOtp = OTPFromDynamicConfig.getExpressPayOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
			encryptedOTP = ApiMethods.getEncryptData(ePayOtp);
			otpValidateHashResponse = ApiMethods.otpValidateHash(encryptedOTP, validateotprequestid,
					clienttransactionid, servertransactionid);

			data1 = ApiMethods.otpValidateInit(otpValidateHashResponse, validateotprequestid);

			response1 = ApiMethods.getDecryptedResponse(data1);
			jsonPathEvaluator1 = response1.jsonPath();
			// System.out.println("Final response----"+response1.getBody().asString());
			// Reporter.log(response1.getBody().asString());
			if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("FOR_REGISTRATION"))) {
			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "000");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "sucess");

			sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.eci"), "02");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.status"), "Y");
			sAssertion.assertEquals(jsonPathEvaluator1.getString("rba-consent-modification.rba-consent-modification-status"), "REGISTERED");
	
			}else if(AuthPrefrence.equalsIgnoreCase("OTP_ONLY") && (authFlag.equalsIgnoreCase("FOR_DEREGISTRATION"))) {
				sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "000");
				sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "sucess");

				sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.eci"), "02");
				sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.status"), "Y");
				sAssertion.assertEquals(jsonPathEvaluator1.getString("rba-consent-modification.rba-consent-modification-status"), "DE_REGISTERED");
		
			}else {
				sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "000");
				sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "sucess");

				sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.eci"), "02");
				sAssertion.assertEquals(jsonPathEvaluator1.getString("authentication-result.status"), "Y");
			//	sAssertion.assertEquals(jsonPathEvaluator1.getString("rba-consent-modification.rba-consent-modification-status"), "REGISTERED");
			}
			
			GenericMethods.writingToExcel(XlFileName, Txn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn1_0, "AcsTxnId", invocationCount, acsTxnId);
			
			break;


		}
		sAssertion.assertAll();
		invocationCount++;
	}
	
	
	@DataProvider
	public Object[][] ep2DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		System.out.println(Txn2_0);
		return GenericMethods.getApiData(XlFileName, Txn2_0);
	}

	@Test(dataProvider = "ep2DataSet", invocationCount = 1)
	public void expressPay2AuthenticationTest(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String BinId, String ProtocalVersion, String Flow, String AuthPrefrence, String authFlag, String TransType,
			String CardUnionType, String acsTxnId, String CavvOrAvv, String decs) throws Exception {
		
		System.out.println("Flow:"+Flow);
		System.out.println("IssuerBankId:"+IssuerBankId);
		System.out.println("Cardnumber:"+Cardnumber);

		SoftAssert sAssertion = new SoftAssert();
		
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0, "CavvOrAvv", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "CavvOrAvv", invocationCount, "");
		
		String wibmoExpressPayId = "";
		String acsTransID = "";
		String merchantTransID = "";
		String otpReferenceId = "";
		String secretKey = "";
		String ePayOtp = "";
		String status = "";
		String transStatus = "";
		String hashingResponse = "";
		String statusCode = "";
		String transStatusReason = "";
		String statusDetails = "";
		
		switch (Flow) {

		case "Challenge":
			System.out.println("************* V2 challenge ******************");
			
			//Encrypt Request
			encryptRequestResponse = ApiMethods.encryptRequest(Cardnumber, IssuerBankId, BinId);
			System.out.println("encryptRequestResponse::" + encryptRequestResponse);
			// Generate OTP			
			response = ApiMethods.generateOTP(Cardnumber, IssuerBankId, encryptRequestResponse);
			jsonPathEvaluator = response.jsonPath();
			wibmoExpressPayId = jsonPathEvaluator.getString("wibmoExpressPayId");
			acsTransID = jsonPathEvaluator.getString("acsTransID");
			merchantTransID = jsonPathEvaluator.getString("merchantTransID");
			otpReferenceId = jsonPathEvaluator.getString("otpReferenceId");
			secretKey = jsonPathEvaluator.getString("secretKey");
			
			System.out.println("wibmoExpressPayId"+wibmoExpressPayId);
			
			// Get the OTP Value
			ePayOtp = OTPFromDynamicConfig.getExpressPayOTPFromEngine(Cardnumber, IssuerBankId, acsTransID);
						
			// Encrypt validate otp
			encryptValidateOTPResponse = ApiMethods.getEncryptValidateOTP(wibmoExpressPayId, acsTransID, merchantTransID, otpReferenceId, ePayOtp, IssuerBankId, BinId);
			System.out.println("encryptValidateOTPResponse::"+encryptValidateOTPResponse);
			
			// Validate otp
			response1 = ApiMethods.validateOTP(encryptValidateOTPResponse, IssuerBankId, acsTransID);
			jsonPathEvaluator1 = response1.jsonPath();
			System.out.println("jsonPathEvaluator1::"+jsonPathEvaluator1);
			
			status = jsonPathEvaluator1.getString("status");
			//String statusDescription = jsonPathEvaluator1.getString("statusDescription");
			//String statusDetails = jsonPathEvaluator1.getString("statusDetails");
			
			System.out.println("status::"+status);
			
			sAssertion.assertEquals(status, "Y");			
						
			// Hashing
			hashingResponse = ApiMethods.getHashing(acsTransID, merchantTransID, secretKey, IssuerBankId, BinId);
			
			
			// Final Areq Ares
			response2 = ApiMethods.finalAreqAres(acsTransID, merchantTransID, hashingResponse, Cardnumber, IssuerBankId);
			jsonPathEvaluator2 = response2.jsonPath();
			//System.out.println("jsonPathEvaluator2::"+jsonPathEvaluator2);
			
			transStatus = jsonPathEvaluator2.getString("transStatus");
		
			System.out.println("transStatus::"+transStatus);
			
			sAssertion.assertEquals(transStatus, "Y");			
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			break;
			
		case "OTPExpiery":
			//Encrypt Request
			encryptRequestResponse = ApiMethods.encryptRequest(Cardnumber, IssuerBankId, BinId);
			System.out.println("encryptRequestResponse::" + encryptRequestResponse);
			// Generate OTP			
			response = ApiMethods.generateOTP(Cardnumber, IssuerBankId, encryptRequestResponse);
			jsonPathEvaluator = response.jsonPath();
			wibmoExpressPayId = jsonPathEvaluator.getString("wibmoExpressPayId");
			acsTransID = jsonPathEvaluator.getString("acsTransID");
			merchantTransID = jsonPathEvaluator.getString("merchantTransID");
			otpReferenceId = jsonPathEvaluator.getString("otpReferenceId");
			secretKey = jsonPathEvaluator.getString("secretKey");
			
			System.out.println("wibmoExpressPayId"+wibmoExpressPayId);
			
			// Get the OTP Value
			ePayOtp = OTPFromDynamicConfig.getExpressPayOTPFromEngine(Cardnumber, IssuerBankId, acsTransID);
			System.out.println("Timer start for 210 sec");
			Thread.sleep(210*1000);
			System.out.println("Timer completed for 210 sec");
			
			// Encrypt validate otp
			encryptValidateOTPResponse = ApiMethods.getEncryptValidateOTP(wibmoExpressPayId, acsTransID, merchantTransID, otpReferenceId, ePayOtp, IssuerBankId, BinId);
			System.out.println("encryptValidateOTPResponse::"+encryptValidateOTPResponse);
			System.out.println("IssuerBankId::"+IssuerBankId);
			System.out.println("acsTransID::"+acsTransID);
			
			// Validate otp
			response1 = ApiMethods.validateOTP(encryptValidateOTPResponse, IssuerBankId, acsTransID);
			jsonPathEvaluator1 = response1.jsonPath();
			System.out.println("jsonPathEvaluator1::"+jsonPathEvaluator1);
			
			status = jsonPathEvaluator1.getString("status");
			statusCode = jsonPathEvaluator1.getString("statusCode");
			System.out.println(status);
			System.out.println(statusCode);
			sAssertion.assertEquals(status, "N");
			sAssertion.assertEquals(statusCode, "305");
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			break;
			
		case "AreqExpiery":
			//Encrypt Request
			encryptRequestResponse = ApiMethods.encryptRequest(Cardnumber, IssuerBankId, BinId);
			System.out.println("encryptRequestResponse::" + encryptRequestResponse);
			// Generate OTP			
			response = ApiMethods.generateOTP(Cardnumber, IssuerBankId, encryptRequestResponse);
			jsonPathEvaluator = response.jsonPath();
			wibmoExpressPayId = jsonPathEvaluator.getString("wibmoExpressPayId");
			acsTransID = jsonPathEvaluator.getString("acsTransID");
			merchantTransID = jsonPathEvaluator.getString("merchantTransID");
			otpReferenceId = jsonPathEvaluator.getString("otpReferenceId");
			secretKey = jsonPathEvaluator.getString("secretKey");
			
			System.out.println("wibmoExpressPayId"+wibmoExpressPayId);
			
			// Get the OTP Value
			ePayOtp = OTPFromDynamicConfig.getExpressPayOTPFromEngine(Cardnumber, IssuerBankId, acsTransID);
						
			// Encrypt validate otp
			encryptValidateOTPResponse = ApiMethods.getEncryptValidateOTP(wibmoExpressPayId, acsTransID, merchantTransID, otpReferenceId, ePayOtp, IssuerBankId, BinId);
			System.out.println("encryptValidateOTPResponse::"+encryptValidateOTPResponse);
			
			// Validate otp
			response1 = ApiMethods.validateOTP(encryptValidateOTPResponse, IssuerBankId, acsTransID);
			jsonPathEvaluator1 = response1.jsonPath();
			System.out.println("jsonPathEvaluator1::"+jsonPathEvaluator1);
			
			status = jsonPathEvaluator1.getString("status");
			//String statusDescription = jsonPathEvaluator1.getString("statusDescription");
			//String statusDetails = jsonPathEvaluator1.getString("statusDetails");
			
			System.out.println("status::"+status);
			
			sAssertion.assertEquals(status, "Y");			
						
			// Hashing
			hashingResponse = ApiMethods.getHashing(acsTransID, merchantTransID, secretKey, IssuerBankId, BinId);
			
			Thread.sleep(65*1000);
			
			// Final Areq Ares
			response2 = ApiMethods.finalAreqAres(acsTransID, merchantTransID, hashingResponse, Cardnumber, IssuerBankId);
			jsonPathEvaluator2 = response2.jsonPath();
			//System.out.println("jsonPathEvaluator2::"+jsonPathEvaluator2);
			// TODO
			transStatus = jsonPathEvaluator2.getString("transStatus");
			transStatusReason = jsonPathEvaluator2.getString("transStatusReason");
			System.out.println("transStatus::"+transStatus);
			System.out.println("transStatus::"+transStatusReason);
			
			sAssertion.assertEquals(transStatus, "N");	
			sAssertion.assertEquals(transStatusReason, "14");			
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			/* For txn data storing we need to wait for 10 min */
			Thread.sleep(600*1000);
			
			break;

		case "ReSendOTP":
			System.out.println("************* V2 Resed OTP ******************");
			
			//Encrypt Request
			encryptRequestResponse = ApiMethods.encryptRequest(Cardnumber, IssuerBankId, BinId);
			System.out.println("encryptRequestResponse::" + encryptRequestResponse);
			// Generate OTP			
			response = ApiMethods.generateOTP(Cardnumber, IssuerBankId, encryptRequestResponse);
			jsonPathEvaluator = response.jsonPath();
			wibmoExpressPayId = jsonPathEvaluator.getString("wibmoExpressPayId");
			acsTransID = jsonPathEvaluator.getString("acsTransID");
			merchantTransID = jsonPathEvaluator.getString("merchantTransID");
			otpReferenceId = jsonPathEvaluator.getString("otpReferenceId");
			secretKey = jsonPathEvaluator.getString("secretKey");
			
			// TODO Resend
			Response res1 = ApiMethods.resendOTP(IssuerBankId, acsTransID);
			//jsonPathEvaluator = res1.jsonPath();
			
			Response res2 = ApiMethods.resendOTP(IssuerBankId, acsTransID);
			//jsonPathEvaluator = res2.jsonPath();
			
			Response res3 = ApiMethods.resendOTP(IssuerBankId, acsTransID);
			jsonPathEvaluator1 = res3.jsonPath();
			
			status = jsonPathEvaluator1.getString("status");
			statusCode = jsonPathEvaluator1.getString("statusCode");
			statusDetails = jsonPathEvaluator1.getString("statusDetails");
			
			System.out.println("status::"+status);
			System.out.println("statusCode::"+statusCode);
			System.out.println("statusDetails::"+statusDetails);
			
			sAssertion.assertEquals(status, "N");
			sAssertion.assertEquals(statusCode, "020");	
			sAssertion.assertEquals(statusDetails, "OTP limit reached");			
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			/*
			 * otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid,
			 * clienttransactionid);
			 * 
			 * data = ApiMethods.otpGenerateInit(otpGenHashResponse, requestid);
			 * 
			 * response = ApiMethods.getDecryptedResponse(data);
			 * 
			 * jsonPathEvaluator = response.jsonPath(); servertransactionid =
			 * jsonPathEvaluator.getString("process-result.server-transaction-id");
			 * Reporter.log("Fetched Server Transaction ID-----" + servertransactionid);
			 * 
			 * String otpResendHashResponse = ApiMethods.otpResendHash(resendotprequestid,
			 * clienttransactionid, servertransactionid);
			 * 
			 * data1 = ApiMethods.otpResendInit(otpResendHashResponse, resendotprequestid);
			 * String otpResendHashResponse2 = ApiMethods.otpResendHash(resendotprequestid1,
			 * clienttransactionid, servertransactionid); data1 =
			 * ApiMethods.otpResendInit(otpResendHashResponse2, resendotprequestid1);
			 * 
			 * String otpResendHashResponse3 = ApiMethods.otpResendHash(resendotprequestid2,
			 * clienttransactionid, servertransactionid); data1 =
			 * ApiMethods.otpResendInit(otpResendHashResponse3, resendotprequestid2);
			 * 
			 * String otpResendHashResponse4 = ApiMethods.otpResendHash(resendotprequestid3,
			 * clienttransactionid, servertransactionid); data1 =
			 * ApiMethods.otpResendInit(otpResendHashResponse4, resendotprequestid3);
			 * 
			 * response1 = ApiMethods.getDecryptedResponse(data1); jsonPathEvaluator1 =
			 * response1.jsonPath();
			 */
			//sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-code"), "015");
			//sAssertion.assertEquals(jsonPathEvaluator1.getString("meta-data.status-description"), "otp limit reached");
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			break;

		case "Blocked":
			System.out.println("************* V2 Blocked  ******************");
			/*
			 * String otpGenHashResponse = ApiMethods.otpGenerateHash(Cardnumber, requestid,
			 * clienttransactionid); data = ApiMethods.otpGenerateInit(otpGenHashResponse,
			 * requestid); response = ApiMethods.getDecryptedResponse(data);
			 * jsonPathEvaluator = response.jsonPath();
			 * System.out.println(response.getBody().asString());
			 */
			
			//Encrypt Request
			encryptRequestResponse = ApiMethods.encryptRequest(Cardnumber, IssuerBankId, BinId);
			System.out.println("encryptRequestResponse::" + encryptRequestResponse);
			// Generate OTP			
			response = ApiMethods.generateOTP(Cardnumber, IssuerBankId, encryptRequestResponse);
			jsonPathEvaluator = response.jsonPath();
			wibmoExpressPayId = jsonPathEvaluator.getString("wibmoExpressPayId");
			acsTransID = jsonPathEvaluator.getString("acsTransID");
			merchantTransID = jsonPathEvaluator.getString("merchantTransID");
			status = jsonPathEvaluator.getString("status");
			statusCode = jsonPathEvaluator.getString("statusCode");
			statusDetails = jsonPathEvaluator.getString("statusDetails");
			System.out.println(status);
			System.out.println(statusCode);
			System.out.println(statusDetails);
			
			Assert.assertEquals(status, "N");
			Assert.assertEquals(statusCode, "002");
			Assert.assertEquals(statusDetails, "Card blocked at ACS");
			
			GenericMethods.writingToExcel(XlFileName, Txn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			// Writing to acs file
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0, "AcsTxnId", invocationCount, acsTransID);
			
			break;

		case "Failed":

			break;
		
		
			
			
		

		}
		sAssertion.assertAll();
		invocationCount++;
	}

}

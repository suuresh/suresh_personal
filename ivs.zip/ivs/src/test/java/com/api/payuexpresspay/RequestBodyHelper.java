package com.api.payuexpresspay;

import java.util.HashMap;
import java.util.Map;

public class RequestBodyHelper {
    
    public static String GenerateOTPBody(String PAN,long requestid,long clienttransactionid)
    {
        String jsonbody= "{"+
                "\"version\": \"1.0\","+
                "\"meta-data\": {"+
                    "\"request-id\": "+requestid+","+
                    "\"client-transaction-id\": "+clienttransactionid+","+
                    "\"merchant-group-id\": \"PAYU_Generic\","+
                    "\"encryption-iv\": \"\""+
                "},"+
                "\"user-client-data\": {"+
                    "\"user-ip\": \"1.2.3.4\""+
                "},"+
                "\"card-verification-data\": {"+
                    "\"pan\": \""+PAN+"\","+ 
                    "\"merchant-acquirer-bin\": \"424242\","+
                    "\"merchant-id\": \"412398MPIQERRWTWT\","+
                    "\"merchant-password\": \"12345678\","+
                    "\"browser-accept-headers\": \"text/html\","+
                    "\"browser-user-agent\": \"Mozilla\""+
                "},"+
                "\"card-authentication-data\": {"+
                    "\"merchant-name\": \"AmzFlipBay\","+
                    "\"merchant-country\": \"IND\","+
                    "\"merchant-url\": \"http://www.example.com/\","+
                    "\"purchase-xid\": \"\","+
                    "\"display-amount\": \"1500000\","+
                    "\"purchase-amount\": \"1500000\","+
                    "\"purchase-currency\": \"356\","+
                    "\"purchase-exponent\": \"2\","+
                    "\"payment-recurring-frequency\": \"\","+
                    "\"payment-recurring-expiry\": \"\","+
                    "\"payment-installments-data\": \"\","+
                    "\"card-expiry\": \"w8gno6G3hsuElnBhDcVgbQ==\""+
                "}"+
            "}";
        
        return jsonbody;
    }
    
    public static String GenerateOTPBodyMissingFiled(String PAN,long requestid,long clienttransactionid)
    {
        String jsonbody= "{"+
                "\"version\": \"1.0\","+
                "\"meta-data\": {"+
                    "\"request-id\": "+requestid+","+
                    "\"merchant-group-id\": \"PAYU_Generic\","+
                    "\"encryption-iv\": \"\""+
                "},"+
                "\"user-client-data\": {"+
                    "\"user-ip\": \"1.2.3.4\""+
                "},"+
                "\"card-verification-data\": {"+
                    "\"pan\": \""+PAN+"\","+ 
                    "\"merchant-acquirer-bin\": \"424242\","+
                    "\"merchant-id\": \"412398MPIQERRWTWT\","+
                    "\"merchant-password\": \"12345678\","+
                    "\"browser-accept-headers\": \"text/html\","+
                    "\"browser-user-agent\": \"Mozilla\""+
                "},"+
                "\"card-authentication-data\": {"+
                    "\"merchant-name\": \"AmzFlipBay\","+
                    "\"merchant-country\": \"IND\","+
                    "\"merchant-url\": \"http://www.example.com/\","+
                    "\"purchase-xid\": \"\","+
                    "\"display-amount\": \"1500000\","+
                    "\"purchase-amount\": \"1500000\","+
                    "\"purchase-currency\": \"356\","+
                    "\"purchase-exponent\": \"2\","+
                    "\"payment-recurring-frequency\": \"\","+
                    "\"payment-recurring-expiry\": \"\","+
                    "\"payment-installments-data\": \"\","+
                    "\"card-expiry\": \"w8gno6G3hsuElnBhDcVgbQ==\""+
                "}"+
            "}";
        
        return jsonbody;
    }
    
    public static String GenerateOTPBodyInvalidRequest(String PAN,long requestid,long clienttransactionid)
    {
        String jsonbody= "{"+
                "\"version\": \"1.0\","+
                "\"meta-data\": {"+
                    "\"request-id\": "+requestid+","+
                    "\"client-transaction-id\": "+clienttransactionid+","+
                    "\"dummy\": "+1234+","+
                    "\"merchant-group-id\": \"PAYU_Generic\","+
                    "\"encryption-iv\": \"\""+
                "},"+
                "\"user-client-data\": {"+
                    "\"user-ip\": \"1.2.3.4\""+
                "},"+
                "\"card-verification-data\": {"+
                    "\"pan\": \""+PAN+"\","+ 
                    "\"merchant-acquirer-bin\": \"424242\","+
                    "\"merchant-id\": \"412398MPIQERRWTWT\","+
                    "\"merchant-password\": \"12345678\","+
                    "\"browser-accept-headers\": \"text/html\","+
                    "\"browser-user-agent\": \"Mozilla\""+
                "},"+
                "\"card-authentication-data\": {"+
                    "\"merchant-name\": \"AmzFlipBay\","+
                    "\"merchant-country\": \"IND\","+
                    "\"merchant-url\": \"http://www.example.com/\","+
                    "\"purchase-xid\": \"\","+
                    "\"display-amount\": \"1500000\","+
                    "\"purchase-amount\": \"1500000\","+
                    "\"purchase-currency\": \"356\","+
                    "\"purchase-exponent\": \"2\","+
                    "\"payment-recurring-frequency\": \"\","+
                    "\"payment-recurring-expiry\": \"\","+
                    "\"payment-installments-data\": \"\","+
                    "\"card-expiry\": \"w8gno6G3hsuElnBhDcVgbQ==\""+
                "}"+
            "}";
        
        return jsonbody;
    }
    
    public static String validateOTPBody(String otp,long validateotprequestid,long clienttransactionid,String servertransactionid)
    {        //"{\"id\": \""+id+"\", \"email\": \""+email+"\"}";
        String validateotpjsonbody="{"+
                "\"version\": \"1.0\","+
                "\"meta-data\": {"+
                "\"request-id\": \""+validateotprequestid+"\","+
                "\"client-transaction-id\": \""+clienttransactionid+"\","+
                "\"server-transaction-id\": \""+servertransactionid+"\","+            
                "\"encryption-iv\": \"\""+
                "},"+
                "\"auth-details\": {"+
                "\"otp\": \""+otp+"\""+
            "}"+
                "}";    
        return validateotpjsonbody;
    }
    
    public static String resendOTPBody(long resendotprequestid,long clienttransactionid,String servertransactionid)
    {        //"{\"id\": \""+id+"\", \"email\": \""+email+"\"}";
        String resendotpjsonbody="{"+
                "\"version\": \"1.0\","+
                "\"meta-data\": {"+
                "\"request-id\": \""+resendotprequestid+"\","+
                "\"client-transaction-id\": \""+clienttransactionid+"\","+
                "\"server-transaction-id\": \""+servertransactionid+"\""+                            
            "}"+
                "}";    
        return resendotpjsonbody;
    }
    
    /********** V4 Expresspay Json body preoparation *******************/
    
    public static String GenerateV4OTPBody(String PAN,long requestid,long clienttransactionid, String AuthPrefrence, String custFlag){
    	
        String jsonbody= "{" + 
        		" \"version\": \"1.0\"," + 
        		"\"meta-data\": {" + 
        		"\"request-id\": \""+requestid+"\"," + 
        		"\"client-transaction-id\": \""+clienttransactionid+"\"," + 
        		"\"merchant-group-id\": \"PAYU_Generic\"," + 
        		"\"encryption-iv\": \"\"" + 
        		" }," + 
        		"\"user-client-data\": {" + 
        		"\"user-ip\": \"1.2.3.4\"" + 
        		"}," + 
        		"\"card-verification-data\": {" + 
        		"\"pan\": \""+PAN+"\"," + 
        		"\"merchant-acquirer-bin\": \"479920\"," + 
        		"\"merchant-id\": \"412398MPIQERRWTWTXMP\"," + 
        		"\"merchant-password\": \"password\"," + 
        		"\"browser-accept-headers\": \"text/html\"," + 
        		"\"browser-user-agent\": \"Mozilla\"" + 
        		"}," + 
        		"\"card-authentication-data\": {" + 
        		"\"merchant-name\": \"Naspers\"," + 
        		"\"merchant-country\": \"IND\",\n" + 
        		"\"merchant-url\": \"http://www.example.com/\"," + 
        		"\"purchase-xid\": \"\"," + 
        		"\"display-amount\": \"Rs. 20.00\"," + 
        		"\"purchase-amount\": \"2000\"," + 
        		"\"purchase-currency\": \"356\"," + 
        		"\"purchase-exponent\": \"2\"," + 
        		"\"payment-recurring-frequency\": \"\"," + 
        		"\"payment-recurring-expiry\": \"\"," + 
        		"\"payment-installments-data\": \"\"," + 
        		"\"card-expiry\": \"br8vz11wDCfJrYR9bj0Stg==\"," + 
        		"\"sms-otp-app-id\": \"\"," + 
        		"\"sms-otp-app-os\": \"\"," + 
        		"\"additional-details\": \"\"" + 
        		"}," + 
        		"\"authentication-flow-indicator\": {" + 
        		"\"authentication-preference\": \""+AuthPrefrence+"\"," + 
        		"\"card-holder-consent-indicator-flag\": \""+custFlag+"\"" + 
        		"}," + 
        		"\"rba-authentication-data\": {" + 
        		"\"user-device-os\": \"ANDROID\"," + 
        		"\"imei\": \"6i5l0XZum8ZO5Y4ftqqkAw==\"," + 
        		"\"vendor-id\": \"2b6f0cc904d137be2e1730235f5664094b831186\"," + 
        		"\"imsi\": \"wLW5J2s/64u4NUSsQgKMkQ==\"," + 
        		"\"merchants-user-id\": \"sghSy3H5ZU70UiK4j/lOmg==\"," + 
        		"\"android-id\": \"oUsVRU5UA6/CmQtquAKl5zYVJOHanjAagsHubQGq4u8=\"," + 
        		"\"login-validation-flag\": \"false\"," + 
        		"\"user-consent-flag\": \"true\"," + 
        		"\"latitude\": \"13.005076\"," + 
        		"\"longitude\": \"77.658956\"," + 
        		"\"os-version\": \"1.0\"," + 
        		"\"merchant-app-version\": \"1.0\"," + 
        		"\"ip-address\": \"127.0.0.1\"," + 
        		"\"network-type\": \"2G\"," + 
        		"\"device-make\": \"nokia\"" + 
        		"}" + 
        		"}";
        
        return jsonbody;
    }

public static String GenerateV4OTPBody(String PAN,long requestid,long clienttransactionid, String AuthPrefrence, String custFlag, String amount){
    	
        String jsonbody= "{" + 
        		" \"version\": \"1.0\"," + 
        		"\"meta-data\": {" + 
        		"\"request-id\": \""+requestid+"\"," + 
        		"\"client-transaction-id\": \""+clienttransactionid+"\"," + 
        		"\"merchant-group-id\": \"PAYU_Generic\"," + 
        		"\"encryption-iv\": \"\"" + 
        		" }," + 
        		"\"user-client-data\": {" + 
        		"\"user-ip\": \"1.2.3.4\"" + 
        		"}," + 
        		"\"card-verification-data\": {" + 
        		"\"pan\": \""+PAN+"\"," + 
        		"\"merchant-acquirer-bin\": \"479920\"," + 
        		"\"merchant-id\": \"412398MPIQERRWTWTXMP\"," + 
        		"\"merchant-password\": \"password\"," + 
        		"\"browser-accept-headers\": \"text/html\"," + 
        		"\"browser-user-agent\": \"Mozilla\"" + 
        		"}," + 
        		"\"card-authentication-data\": {" + 
        		"\"merchant-name\": \"Naspers\"," + 
        		"\"merchant-country\": \"IND\",\n" + 
        		"\"merchant-url\": \"http://www.example.com/\"," + 
        		"\"purchase-xid\": \"\"," + 
        		"\"display-amount\": \"Rs. "+amount+".00\"," + 
        		"\"purchase-amount\": \""+amount+"00\"," + 
        		"\"purchase-currency\": \"356\"," + 
        		"\"purchase-exponent\": \"2\"," + 
        		"\"payment-recurring-frequency\": \"\"," + 
        		"\"payment-recurring-expiry\": \"\"," + 
        		"\"payment-installments-data\": \"\"," + 
        		"\"card-expiry\": \"br8vz11wDCfJrYR9bj0Stg==\"," + 
        		"\"sms-otp-app-id\": \"\"," + 
        		"\"sms-otp-app-os\": \"\"," + 
        		"\"additional-details\": \"\"" + 
        		"}," + 
        		"\"authentication-flow-indicator\": {" + 
        		"\"authentication-preference\": \""+AuthPrefrence+"\"," + 
        		"\"card-holder-consent-indicator-flag\": \""+custFlag+"\"" + 
        		"}," + 
        		"\"rba-authentication-data\": {" + 
        		"\"user-device-os\": \"ANDROID\"," + 
        		"\"imei\": \"6i5l0XZum8ZO5Y4ftqqkAw==\"," + 
        		"\"vendor-id\": \"2b6f0cc904d137be2e1730235f5664094b831186\"," + 
        		"\"imsi\": \"wLW5J2s/64u4NUSsQgKMkQ==\"," + 
        		"\"merchants-user-id\": \"sghSy3H5ZU70UiK4j/lOmg==\"," + 
        		"\"android-id\": \"oUsVRU5UA6/CmQtquAKl5zYVJOHanjAagsHubQGq4u8=\"," + 
        		"\"login-validation-flag\": \"false\"," + 
        		"\"user-consent-flag\": \"true\"," + 
        		"\"latitude\": \"13.005076\"," + 
        		"\"longitude\": \"77.658956\"," + 
        		"\"os-version\": \"1.0\"," + 
        		"\"merchant-app-version\": \"1.0\"," + 
        		"\"ip-address\": \"127.0.0.1\"," + 
        		"\"network-type\": \"2G\"," + 
        		"\"device-make\": \"nokia\"" + 
        		"}" + 
        		"}";
        
        return jsonbody;
    }


	/* ExpressPay 2.0 Methods */
	public static String generateEncryptRequestBody(String cardno, String bankId) {
		String jsonbody = "{"
				+ "    \"purchaseAmount\": \"50000\","
				+ "    \"purchaseCurrency\": \"840\","
				+ "    \"purchaseExponent\": \"2\","
				+ "    \"purchaseDate\": \"20201203223521\","
				+ "    \"merchantCountryCode\": \"356\","
				+ "    \"merchantName\": \"YepMe\","
				+ "    \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3;q=0.9\","
				+ "    \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117safari/537.36\""
				+ "}";
		return jsonbody;
	}
	
	public static String generateOTPRequest(String pan, String authData) {
		String jsonBody = "{"
				+ "    \"wibmoExpressPayId\": \"2d0dcbeb-185c-4e90-919b-9839a8cce905\","
				+ "    \"payloadMode\": \"encrypt\","
				+ "    \"cardIdentifier\": \"1\","
				+ "    \"payloadEncAlgo\": \"RSA_OAEP_256\","
				+ "    \"version\": \"2.1.0\","
				+ "    \"cliendID\": \"WIBMO-EXPRESSPAY\","
				+ "    \"merchantTransID\": \"83ae055d-e4ca-11ed-ae46-0d7d2b1ef730\","
				+ "    \"pan\": \""+pan+"\","
				+ "    \"authData\": \""+authData+"\""
				+ "}";
		return jsonBody;
	}
	
	public static String getEncryptValidateOTPRequest(String wibmoExpressPayId, String acsTransID, String merchantTransID, String otpReferenceId, String ePayOtp) {
		String jsonBody = "{"
				+ "    \"clientID\": \"WIBMO-EXPRESSPAY\","
				+ "    \"wibmoExpressPayId\": \""+wibmoExpressPayId+"\","
				+ "    \"acsTransID\": \""+acsTransID+"\","
				+ "    \"merchantTransID\": \""+merchantTransID+"\","
				+ "    \"otpReferenceId\": \""+otpReferenceId+"\","
				+ "    \"messageExtension\": ["
				+ "        {"
				+ "            \"name\": \"userOtpData\","
				+ "            \"id\": \"userOtpData\","
				+ "            \"criticalityIndicator\": true,"
				+ "            \"data\": {"
				+ "                \"name\": \"value1\","
				+ "                \"value\": \""+ePayOtp+"\","
				+ "                \"status\": \"Y\","
				+ "                \"label\": \"label\","
				+ "                \"length\": 6,"
				+ "                \"type\": \"numeric\""
				+ "            }"
				+ "        }"
				+ "    ]"
				+ "}";
		return jsonBody;
	}
	
	public static String getHashingRequest(String acsTransID, String merchantTransID, String secretKey) {
		String jsonBody ="{"				
				+ "    \"value\": \""+acsTransID+"|"+merchantTransID+"\","
				+ "    \"key\": \""+secretKey+"\""
				+ "}";
		return jsonBody;
	}
	
	public static String getFinalAreqAresRequest(String acsTransID, String merchantTransID, String hashingResponse, String Cardnumber) {
		String jsonBody ="{"
				+ "    \"threeDSRequestorAuthenticationInfo\": {"
				+ "        \"threeDSReqAuthMethod\": null,"
				+ "        \"threeDSReqAuthTimestamp\": null,"
				+ "        \"threeDSReqAuthData\": {"
				+ "            \"messageExtension\": ["
				+ "                {"
				+ "                    \"name\": \"wibmo-expresspay-auth\","
				+ "                    \"id\": \"wibmo-expresspay-auth\","
				+ "                    \"criticalityIndicator\": \"false\","
				+ "                    \"data\": {"
				+ "                        \"priorTxnId\": \""+acsTransID+"|"+merchantTransID+"\","
				+ "                        \"hash\": \""+hashingResponse+"\""
				+ "                    }"
				+ "                }"
				+ "            ]"
				+ "        }"
				+ "    },"
				+ "    \"threeDSRequestorChallengeInd\": \"01\","
				+ "    \"threeDSRequestorID\": \"227\","
				+ "    \"threeDSRequestorName\": \"YepMe\","
				+ "    \"threeDSRequestorPriorAuthenticationInfo\": null,"
				+ "    \"threeDSRequestorURL\": \"https://3ds2-api-3dsserver-intg.pc.enstage-sas.com/3dsserverapi/getrres/indmum-mumrdc/L/8126/280f1c9b-96c5-41eb-9879-d1484180ce1f\","
				+ "    \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020200_00397\","
				+ "    \"threeDSServerOperatorID\": \"SVR-V210-WIBMO-50927\","
				+ "    \"threeDSServerTransID\": \"650cf5b4-d125-4bb8-86ae-735020a24448\","
				+ "    \"threeDSServerURL\": \"https://3ds2-api-3dsserver-intg.pc.enstage-sas.com/3dsserverapi/getrres/indmum-mumrdc/L/8126/280f1c9b-96c5-41eb-9879-d1484180ce1f\","
				+ "    \"acctType\": null,"
				+ "    \"acquirerBIN\": \"000000999\","
				+ "    \"acquirerMerchantID\": \"9876543210345\","
				+ "    \"addrMatch\": \"Y\","
				+ "    \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\","
				+ "    \"browserIP\": \"192.168.109.1\","
				+ "    \"browserJavaEnabled\": \"true\","
				+ "    \"browserLanguage\": \"en-GB\","
				+ "    \"browserColorDepth\": \"24\","
				+ "    \"browserScreenHeight\": \"768\","
				+ "    \"browserScreenWidth\": \"1366\","
				+ "    \"browserTZ\": \"-330\","
				+ "    \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\","
				+ "    \"cardExpiryDate\": \"2212\","
				+ "    \"acctInfo\": null,"
				+ "    \"acctNumber\": \""+Cardnumber+"\","
				+ "    \"acctID\": null,"
				+ "    \"billAddrCity\": null,"
				+ "    \"billAddrCountry\": null,"
				+ "    \"billAddrLine1\": null,"
				+ "    \"billAddrLine2\": null,"
				+ "    \"billAddrLine3\": null,"
				+ "    \"billAddrPostCode\": null,"
				+ "    \"billAddrState\": null,"
				+ "    \"email\": null,"
				+ "    \"homePhone\": null,"
				+ "    \"mobilePhone\": null,"
				+ "    \"cardholderName\": null,"
				+ "    \"shipAddrCity\": null,"
				+ "    \"shipAddrCountry\": null,"
				+ "    \"shipAddrLine1\": null,"
				+ "    \"shipAddrLine2\": null,"
				+ "    \"shipAddrLine3\": null,"
				+ "    \"shipAddrPostCode\": null,"
				+ "    \"shipAddrState\": null,"
				+ "    \"workPhone\": null,"
				+ "    \"deviceChannel\": \"02\","
				+ "    \"deviceInfo\": null,"
				+ "    \"deviceRenderOptions\": null,"
				+ "    \"dsReferenceNumber\": \"123456789\","
				+ "    \"dsTransID\": \"d73de580-8c1c-4bb3-8645-76f72fc821dc\","
				+ "    \"dsURL\": \"http://192.168.108.90:8828/ds/services/r/rreq\","
				+ "    \"payTokenInd\": null,"
				+ "    \"purchaseInstalData\": null,"
				+ "    \"mcc\": \"7299\","
				+ "    \"merchantCountryCode\": \"356\","
				+ "    \"merchantName\": \"YepMe\","
				+ "    \"merchantRiskIndicator\": null,"
				+ "    \"messageCategory\": \"01\","
				+ "    \"messageExtension\": null,"
				+ "    \"messageType\": \"AReq\","
				+ "    \"messageVersion\": \"2.1.0\","
				+ "    \"purchaseAmount\": \"500000\","
				+ "    \"purchaseCurrency\": \"840\","
				+ "    \"purchaseExponent\": \"2\","
				+ "    \"purchaseDate\": \"20201203223521\","
				+ "    \"recurringExpiry\": null,"
				+ "    \"recurringFrequency\": null,"
				+ "    \"sdkAppID\": null,"
				+ "    \"sdkEncData\": null,"
				+ "    \"sdkEphemPubKey\": null,"
				+ "    \"sdkReferenceNumber\": null,"
				+ "    \"sdkTransID\": null,"
				+ "    \"transType\": \"01\","
				+ "    \"acsTransID\": null,"
				+ "    \"threeDSCompInd\": \"N\","
				+ "    \"threeDSRequestorAuthenticationInd\": \"01\","
				+ "    \"threeRIInd\": null,"
				+ "    \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/fetchAuthResponse/0d16e8fb-0e6e-421d-b7bc-a69b6493b9f5\","
				+ "    \"sdkMaxTimeout\": null,"
				+ "    \"browserJavascriptEnabled\": null,"
				+ "    \"broadInfo\": null"
				+ "}";
		return jsonBody;
	}
	
	public static String getResendOTPRequest(String acsTxnId) {
		String jsonBody = "{"
				+ "\"clientID\": \"WIBMO-EXPRESSPAY\","
				+ "\"acctID\": \""+acsTxnId+"\""
				+ "}";
		return jsonBody;
	}
	
	

}

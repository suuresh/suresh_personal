package com.api.payuexpresspay;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import org.bson.types.Binary;
import org.testng.Reporter;

import com.acs.libraries.Config;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ApiMethods {

	// Method to Encrypt
	public static String getEncryptData(String key) {
		Response response = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(key)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getEncryptedData");
		String data = response.getBody().asString();
		return data;

	}

	// Method to generate OTPHash
	public static String otpGenerateHash(String Cardnumber, long requestid, long clienttransactionid) throws IOException {
	/*	String BankName = Utilities.getValue("BANKNAME",
				".//Config/config.properties");
		String Cardno = Utilities.getValue(cardtype, ".//TestData/" + BankName
				+ ".properties");*/
		String PAN = ApiMethods.getEncryptData(Cardnumber);
	//	Reporter.log("Test Running for:   " + BankName);
		Reporter.log("OTP GENERATE HASH");
		String jsonbody = RequestBodyHelper.GenerateOTPBody(PAN, requestid,
				clienttransactionid);
		System.out.println(jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response OtpGenHashresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
		
		String OtpGenHashResbody = OtpGenHashresponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + OtpGenHashresponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + OtpGenHashResbody);
		OtpGenHashresponse.then().statusCode(200);
		return OtpGenHashResbody;
	}

	
// overloaded method for Generate OTP Hash for V4 PayU Expresspay
	
	public static String otpGenerateHash(String Cardnumber, long requestid, long clienttransactionid, String AuthPrefrence, String custFlag) throws IOException {
		/*	String BankName = Utilities.getValue("BANKNAME",
					".//Config/config.properties");
			String Cardno = Utilities.getValue(cardtype, ".//TestData/" + BankName
					+ ".properties");*/
			String PAN = ApiMethods.getEncryptData(Cardnumber);
		//	Reporter.log("Test Running for:   " + BankName);
			Reporter.log("OTP GENERATE HASH");
			String jsonbody = RequestBodyHelper.GenerateV4OTPBody(PAN, requestid,
					clienttransactionid, AuthPrefrence, custFlag);
			System.out.println(jsonbody);
			Reporter.log("JSON Request Body:   " + jsonbody);
			Response OtpGenHashresponse = given()
					.accept(ContentType.JSON)
					.with()
					.contentType(ContentType.JSON)
					.and()
					.body(jsonbody)
					.when()
					.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
			
			String OtpGenHashResbody = OtpGenHashresponse.getBody().asString();
			// validate status code
			Reporter.log("Status Code" + OtpGenHashresponse.getStatusCode());
			Reporter.log("Response of OTP Generate Hash API" + OtpGenHashResbody);
			OtpGenHashresponse.then().statusCode(200);
			return OtpGenHashResbody;
		}

	public static String otpGenerateHash(String Cardnumber, long requestid, long clienttransactionid, String AuthPrefrence, String custFlag,String amount) throws IOException {
		/*	String BankName = Utilities.getValue("BANKNAME",
					".//Config/config.properties");
			String Cardno = Utilities.getValue(cardtype, ".//TestData/" + BankName
					+ ".properties");*/
			String PAN = ApiMethods.getEncryptData(Cardnumber);
		//	Reporter.log("Test Running for:   " + BankName);
			Reporter.log("OTP GENERATE HASH");
			String jsonbody = RequestBodyHelper.GenerateV4OTPBody(PAN, requestid,
					clienttransactionid, AuthPrefrence, custFlag,amount);
			System.out.println(jsonbody);
			Reporter.log("JSON Request Body:   " + jsonbody);
			Response OtpGenHashresponse = given()
					.accept(ContentType.JSON)
					.with()
					.contentType(ContentType.JSON)
					.and()
					.body(jsonbody)
					.when()
					.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
			
			String OtpGenHashResbody = OtpGenHashresponse.getBody().asString();
			// validate status code
			Reporter.log("Status Code" + OtpGenHashresponse.getStatusCode());
			Reporter.log("Response of OTP Generate Hash API" + OtpGenHashResbody);
			OtpGenHashresponse.then().statusCode(200);
			return OtpGenHashResbody;
		}
//Overloaded method for otpGenerate Hash
	public static String otpGenerateHash(String Cardnumber, long requestid,
			long clienttransactionid, String jsonbodytype) throws IOException {
	/*	String BankName = Utilities.getValue("BANKNAME",
				".//Config/config.properties");
		String Cardno = Utilities.getValue(cardtype, ".//TestData/" + BankName
				+ ".properties");*/
		String PAN = ApiMethods.getEncryptData(Cardnumber);
		//Reporter.log("Test Running for:   " + BankName);
		Reporter.log("OTP GENERATE HASH");
		String jsonbody = RequestBodyHelper.GenerateOTPBodyMissingFiled(PAN,
				requestid, clienttransactionid);
		System.out.println(jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response OtpGenHashresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
		String OtpGenHashResbody = OtpGenHashresponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + OtpGenHashresponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + OtpGenHashResbody);
		OtpGenHashresponse.then().statusCode(200);

		return OtpGenHashResbody;
	}
//Method Overloaded for otpGenerateHashInvalidRequest
	public static String otpGenerateHashInvalidRequest(String Cardnumber,
			long requestid, long clienttransactionid, String jsonbodytype)
			throws IOException {
	/*	String BankName = Utilities.getValue("BANKNAME",
				".//Config/config.properties");
		String Cardno = Utilities.getValue(cardtype, ".//TestData/" + BankName
				+ ".properties");*/
		String PAN = ApiMethods.getEncryptData(Cardnumber);
	//	Reporter.log("Test Running for:   " + BankName);
		Reporter.log("OTP GENERATE HASH");
		String jsonbody = RequestBodyHelper.GenerateOTPBodyInvalidRequest(PAN,
				requestid, clienttransactionid);
		System.out.println(jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response OtpGenHashresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
		String OtpGenHashResbody = OtpGenHashresponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + OtpGenHashresponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + OtpGenHashResbody);
		OtpGenHashresponse.then().statusCode(200);

		return OtpGenHashResbody;
	}

	// Method to generate OTPInit - Returns data
	public static String otpGenerateInit(String OtpGenHashResbody, long requestid) {

		Reporter.log("OTP GENERATE INIT");

		Response OtpGenInitresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(OtpGenHashResbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"generateOTP?request-id=" + requestid);
		String OtpGenInitResbody = OtpGenInitresponse.getBody().asString();
		JsonPath jsonPathEvaluator = OtpGenInitresponse.jsonPath();
		OtpGenInitresponse.then().statusCode(200);
		System.out.println(jsonPathEvaluator.getString("data"));
		Reporter.log("OTP Generate Init Reponse"
				+ jsonPathEvaluator.getString("data"));
		return jsonPathEvaluator.getString("data");

	}

	// Generic Method for Decryption

	public static Response getDecryptedResponse(String data) {
		Reporter.log("Decryption API");

		Response OtpGenInitdecode = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(data)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getDecodedData");

		String OtpGenInitdecodedResbody = OtpGenInitdecode.getBody().asString();
		System.out.println(OtpGenInitdecodedResbody);
		Reporter.log("OTP Generate Final Response" + OtpGenInitdecodedResbody);
		Reporter.log("API Status Code" + OtpGenInitdecode.getStatusCode());
		OtpGenInitdecode.then().statusCode(200);

		return OtpGenInitdecode;
	}

	// Method For OTP Validate Hash
	public static String otpValidateHash(String otp, long validateotprequestid,
			long clienttransactionid, String servertransactionid)

	{
		String jsonbody = RequestBodyHelper.validateOTPBody(otp,
				validateotprequestid, clienttransactionid, servertransactionid);
		Reporter.log("OTP Validate Hash Body-------" + jsonbody);
		System.out.println(jsonbody);
		Response OtpValidateHashresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
		String validateHashResbody = OtpValidateHashresponse.getBody()
				.asString();
		// validate status code
		Reporter.log("Status Code" + OtpValidateHashresponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + validateHashResbody);
		OtpValidateHashresponse.then().statusCode(200);

		return validateHashResbody;
	}

	public static String otpValidateInit(String OtpGenHashResbody,
			long validateotprequestid) {

		Reporter.log("OTP GENERATE INIT");

		Response OtpGenInitresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(OtpGenHashResbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"validateOTP?request-id="+ validateotprequestid);
		String OtpGenInitResbody = OtpGenInitresponse.getBody().asString();
		JsonPath jsonPathEvaluator = OtpGenInitresponse.jsonPath();
		OtpGenInitresponse.then().statusCode(200);
		System.out.println(jsonPathEvaluator.getString("data"));
		Reporter.log("OTP Generate Init Reponse"
				+ jsonPathEvaluator.getString("data"));
		return jsonPathEvaluator.getString("data");

	}

	public static String otpResendHash(long resendotprequestid,
			long clienttransactionid, String servertransactionid)

	{
		String jsonbody = RequestBodyHelper.resendOTPBody(resendotprequestid,
				clienttransactionid, servertransactionid);
		Reporter.log("OTP Validate Hash Body-------" + jsonbody);
		System.out.println(jsonbody);
		Response OtpValidateHashresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"getHashandEncodedData");
		String validateHashResbody = OtpValidateHashresponse.getBody()
				.asString();
		// validate status code
		Reporter.log("Status Code" + OtpValidateHashresponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + validateHashResbody);
		OtpValidateHashresponse.then().statusCode(200);

		return validateHashResbody;
	}

	public static String otpResendInit(String otpResendHashResponseBody,
			long resendotprequestid) {

		Reporter.log("OTP RESEND INIT");

		Response OtpGenInitresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(otpResendHashResponseBody)
				.when()
				.post(Config.BASE_EXPRESS_MPI_URL+"resendOTP?request-id="+ resendotprequestid);
		String OtpGenInitResbody = OtpGenInitresponse.getBody().asString();
		JsonPath jsonPathEvaluator = OtpGenInitresponse.jsonPath();
		System.out.println(OtpGenInitresponse.getStatusCode());
		OtpGenInitresponse.then().statusCode(200);
		System.out.println(jsonPathEvaluator.getString("data"));
		Reporter.log("OTP Generate Init Reponse"
				+ jsonPathEvaluator.getString("data"));
		return jsonPathEvaluator.getString("data");

	}
	
	
	public static Response pushApiPostRequest(String encryptedtext, String IssuerBankId) {

		Reporter.log("encrypted text to push api");

		Response pushapiresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(encryptedtext)
				.when()
				.post(Config.BASE_PUSH_API_URL+  IssuerBankId);
		String OtpGenInitResbody = pushapiresponse.getBody().asString();
		JsonPath jsonPathEvaluator = pushapiresponse.jsonPath();
		pushapiresponse.then().statusCode(200);
		System.out.println(jsonPathEvaluator.getString("data"));
		Reporter.log("OTP Generate Init Reponse"
				+ jsonPathEvaluator.getString("data"));
		return pushapiresponse;

	}
	
	public static Response deWhiteListedPostRequest(String encryptedtext, String IssuerBankId) {

		Reporter.log("encrypted text to push api");
String postURL=Config.DCS_deWhiteListed_API_URL+ IssuerBankId;
		Response deWhiteapiresponse = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(encryptedtext)
				.when()
				.post(postURL);
		System.out.println("postURL="+postURL);
		/*String OtpGenInitResbody = deWhiteapiresponse.getBody().asString();*/
		JsonPath jsonPathEvaluator = deWhiteapiresponse.jsonPath();
		deWhiteapiresponse.then().statusCode(200);
		Reporter.log("OTP Generate Init Reponse"
				+ jsonPathEvaluator.getString("data"));
		return deWhiteapiresponse;
	}
	
	
	public static void errorCodeListDetailsScreenAdmin​Request(String payload, String IssuerBankId) {
		Reporter.log("Save error code in the DB Admin api");
		String postURL=Config.DCS_SaveErrorList_API_URL+IssuerBankId;
		given()
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post(postURL);
		System.out.println("postURL="+postURL);
	

	}
	
	
	/* ExpressPay 2.0 Methods */
	
	// Method to generate OTPHash
	public static String encryptRequest(String Cardnumber, String bankId, String BinId )
			throws IOException {
		
		//String PAN = ApiMethods.getEncryptData(Cardnumber);
		System.out.println("encryptRequest");
		Reporter.log("Encrypt Request");
		String jsonbody = RequestBodyHelper.generateEncryptRequestBody(Cardnumber, bankId);
		System.out.println("jsonBody: "+jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response encryptRequestResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_URL + "/v1/jweEncDec/enc/epay/"+bankId+"/"+BinId);

		String encryptRequestResponseBody = encryptRequestResponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + encryptRequestResponse.getStatusCode());
		Reporter.log("Response of OTP Generate Hash API" + encryptRequestResponseBody);
		encryptRequestResponse.then().statusCode(200);
		return encryptRequestResponseBody;
	}
	
	// Get PAN Encrypt
	public static String getPANEncryptData(String cardNo, String bankID) {
		String jsonbody = "{\"value\": \""+cardNo+"\"}";
		Response response = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_EXPRESS_IVR_URL+"/v1/jweEncDec/encPan/epay/"+bankID+"/776656");
		String data = response.getBody().asString();
		return data;

	}
	
	// Generate OTP
	public static Response generateOTP(String cardNo, String bankId, String authData) {
		
		String pan = ApiMethods.getPANEncryptData(cardNo, bankId);
		//System.out.println("pan::"+pan);
		String jsonbody = RequestBodyHelper.generateOTPRequest(pan, authData);
		//System.out.println("jsonbody"+jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response generateOTPResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_URL + "/v1/acs/services/epay/otp/"+bankId);

		String generateOTPResponseBody = generateOTPResponse.getBody().asString();
		System.out.println("generateOTPResponseBody:: "+ generateOTPResponseBody);
		// validate status code
		Reporter.log("Status Code" + generateOTPResponse.getStatusCode());
		Reporter.log("Response of Generate OTP API" + generateOTPResponseBody);
		generateOTPResponse.then().statusCode(200);
		return generateOTPResponse;
	}
	
	// Encrypt Validate OTP
	public static String getEncryptValidateOTP(String wibmoExpressPayId, String acsTransID, String merchantTransID, String otpReferenceId, String ePayOtp, String bankId, String BinId) {
		System.out.println("*******");
		String jsonbody = RequestBodyHelper.getEncryptValidateOTPRequest(wibmoExpressPayId, acsTransID, merchantTransID, otpReferenceId, ePayOtp);
		//System.out.println("jsonbody::"+jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response encryptValidateOTPResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_URL + "/v1/jweEncDec/enc/epay/"+bankId+"/"+BinId);

		String encryptValidateOTPResponseBody = encryptValidateOTPResponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + encryptValidateOTPResponse.getStatusCode());
		Reporter.log("Response of Encrypt Validate OTP API" + encryptValidateOTPResponseBody);
		encryptValidateOTPResponse.then().statusCode(200);
		return encryptValidateOTPResponseBody;
	}
	
	// Validate OTP
	public static Response validateOTP(String validateOtpRequest, String bankID, String acsTransID) {	
		
		Response generateValidateOTPResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(validateOtpRequest).when().post(Config.BASE_EXPRESS_IVR_UI_URL + "/v1/acs/services/epay/validate/"+bankID+"/"+acsTransID);

		String generateValidateOTPResponseBody = generateValidateOTPResponse.getBody().asString();
		System.out.println("generateValidateOTPResponseBody::"+generateValidateOTPResponseBody);
		// validate status code
		Reporter.log("Status Code" + generateValidateOTPResponse.getStatusCode());
		Reporter.log("Response of Validate OTP API" + generateValidateOTPResponseBody);
		generateValidateOTPResponse.then().statusCode(200);
		return generateValidateOTPResponse;
	}
	
	// Resend OTP
	public static Response resendOTP(String bankID, String acsTransID) {
		String jsonbody = RequestBodyHelper.getResendOTPRequest( acsTransID);
		Response resendOTPResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_UI_URL + "/v1/acs/services/epay/resend/"+bankID+"/"+acsTransID);

		String resendOTPResponseBody = resendOTPResponse.getBody().asString();
		System.out.println("resendOTPResponseBody::"+resendOTPResponseBody);
		// validate status code
		Reporter.log("Status Code" + resendOTPResponse.getStatusCode());
		Reporter.log("Response of Resend OTP API" + resendOTPResponseBody);
		resendOTPResponse.then().statusCode(200);
		return resendOTPResponse;
	}
	
	// Hashing
	public static String getHashing(String acsTransID, String merchantTransID, String secretKey, String bankId, String BinId) {
		String jsonbody = RequestBodyHelper.getHashingRequest(acsTransID, merchantTransID, secretKey);
		//System.out.println(jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		Response hashingResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_URL + "/v1/jweEncDec/hash/epay/"+bankId+"/"+BinId);

		String hashingResponseBody = hashingResponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + hashingResponse.getStatusCode());
		Reporter.log("Response of Hashing API" + hashingResponseBody);
		hashingResponse.then().statusCode(200);
		return hashingResponseBody;
	}
	
	// Final Areq Ares
	public static Response finalAreqAres(String acsTransID, String merchantTransID, String hashingResponse, String Cardnumber, String IssuerBankId) {
		
		String jsonbody = RequestBodyHelper.getFinalAreqAresRequest(acsTransID, merchantTransID, hashingResponse, Cardnumber);
		//System.out.println("jsonbody:"+jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		
		Response generateFinalAreqAresResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_EXPRESS_IVR_URL + "/v1/acs/services/areq/"+IssuerBankId);

		String finalAreqAresResponseBody = generateFinalAreqAresResponse.getBody().asString();
		
		System.out.println("finalAreqAresResponseBody::"+finalAreqAresResponseBody);
		
		// validate status code
		Reporter.log("Status Code" + generateFinalAreqAresResponse.getStatusCode());
		Reporter.log("Response of Final Areq Ares API" + finalAreqAresResponseBody);
		generateFinalAreqAresResponse.then().statusCode(200);
		return generateFinalAreqAresResponse;
	}
	
	
}

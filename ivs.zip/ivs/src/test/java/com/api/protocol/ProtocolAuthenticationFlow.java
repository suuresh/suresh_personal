package com.api.protocol;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.util.SystemOutLogger;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.pages.ACSSimulatorReponsePage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.payloads.AreqRequestBodyHelper;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ProtocolAuthenticationFlow extends ACSInitialSetUp {

	LogEntries NetWorklogs;
	LogEntries NetWorklogs1;
	
	int invocationCount = 2;
	public String acsTxnId = null;

	public String encodeGenerateOtpResponse = null;
	
	public String rbaAuthAttempted = null;
	public String generateOtp = null;
	public String decodeGenerateOtpRequest = null;
	public String decodeVerifyOtpRequest = null;
	public String encodeVerifyOtpRequest = null;
	public String verifyOTP = null;
	public Response response = null;
	public Response response1 = null;

	public JsonPath jsonPathEvaluator = null;
	public JsonPath jsonPathEvaluator1 = null;
	public String issuer_guid = null;
	public String authResponseCode = null;
	public String errormsg = null;
	public String errorcode = null;
	public String txnId = null;
	public String preTxnId = null;
	public String preRequestId = null;

	public Xls_Reader excel;

	public LogOutPage logout;
	public LoginPage loginPage;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String XlFileName = null;
	public String OnBoradingXlFileName = null;
	public TridentLogOutPage tlogout;
	public TridentLoginPage tloginPage;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String proxyUrl = null;
	public WebDriverWait wait;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	@SuppressWarnings("deprecation")
	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
			"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
			"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName", "ENV" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename,
			String txn1_0sheetName, String txn2_0sheetName, String acstxn1_0sheetName, String acstxn2_0sheetName,
			String tridenttxn1_0sheetName, String tridenttxn2_0sheetName, String threedsstxn2_0sheetName, String env)
			throws Exception {
	
		Config.BASE_ENVIRONMENT = env;
		Config.assignEnvironment();
		

		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0SheetName = txn1_0sheetName;
		Txn2_0SheetName = txn2_0sheetName;
		ACSTxn1_0SheetName = acstxn1_0sheetName;
		ACSTxn2_0SheetName = acstxn2_0sheetName;
		TridentTxn1_0SheetName = tridenttxn1_0sheetName;
		TridentTxn2_0SheetName = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0SheetName = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;
		
		if (OS.equalsIgnoreCase("windows")) {
			
			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.GECKODRIVER_PATH);
				driver = new FirefoxDriver();
				FirefoxOptions options = new FirefoxOptions();
				// options.setHeadless(true);
				driver = new FirefoxDriver(options);
				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				log.debug("opening the chrome browser");
				
				System.setProperty("webdriver.chrome.driver", Config.CHROMEDRIVER_PATH);
				System.setProperty("webdriver.chrome.logfile", "./chromedriver.log");
				System.setProperty("webdriver.chrome.verboseLogging", "true");

				ChromeOptions chromeOptions = new ChromeOptions();
				//DesiredCapabilities cap = DesiredCapabilities.chrome();

				Map<String, Object> prefs = new HashMap<>();
				prefs.put("download.default_directory", downloadLocation);
				chromeOptions.setExperimentalOption("prefs", prefs);
				

				
				chromeOptions.setCapability("chromeOptions", chromeOptions);
				chromeOptions.setAcceptInsecureCerts(true);
				chromeOptions.setCapability("chrome.switches",
						Arrays.asList("--proxy-server=http://192.168.109.32:6558"));
				LoggingPreferences logPrefs = new LoggingPreferences();
				
				logPrefs.enable(LogType.PERFORMANCE, Level.ALL);				
				logPrefs.enable(LogType.DRIVER, Level.ALL);
				
				
				chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
				// cap.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
				chromeOptions.setExperimentalOption("w3c", false);
				driver = new ChromeDriver(chromeOptions);	
				
			}
		} else if (OS.equalsIgnoreCase("linux")) {
			//System.out.println("Entered Linux");
			downloadLocation = "/home/acsapp/downloads";

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.LINUX_GECKODRIVER_PATH);
				FirefoxOptions options = new FirefoxOptions();
				//DesiredCapabilities cap = DesiredCapabilities.firefox();
				setProxyforFireFox(proxyUrl, options);
				options.setHeadless(true);

				driver = new FirefoxDriver(options);

				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {
				System.out.println("Entered Chrome");

				System.setProperty("webdriver.chrome.driver", Config.LINUX_CHROMEDRIVER_PATH);				
				System.setProperty("webdriver.chrome.logfile", "./chromedriver.log");
				System.setProperty("webdriver.chrome.verboseLogging", "true");
				
				ChromeOptions chromeOptions = new ChromeOptions();
				//DesiredCapabilities cap = DesiredCapabilities.chrome();
				
				
				chromeOptions.addArguments("headless");
				chromeOptions.addArguments("start-maximized");
				chromeOptions.addArguments("window-size=1200x600");				
				
				chromeOptions.addArguments("--enable-javascript");				
				chromeOptions.setCapability("chromeOptions", chromeOptions);
				chromeOptions.setAcceptInsecureCerts(true);
				chromeOptions.setCapability("chrome.switches",
						Arrays.asList("--proxy-server=http://192.168.109.32:6558"));
				
				Map<String, Object> prefs = new HashMap<>();
				prefs.put("download.default_directory", downloadLocation);
				chromeOptions.setExperimentalOption("prefs", prefs);
				
				
				LoggingPreferences logPrefs = new LoggingPreferences();
				logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
				// chromeOptions.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
				chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
				chromeOptions.setExperimentalOption("w3c", false);
				chromeOptions.setAcceptInsecureCerts(true);
				
				driver = new ChromeDriver(chromeOptions);
				
				
				
				System.out.println(driver);
			}
		} else if (OS.equalsIgnoreCase("mac")) {

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
				driver = new FirefoxDriver();

				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				driver = new ChromeDriver();
			}
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);

	}
	
	private void setProxyforFireFox(String proxyUrl, FirefoxOptions options) {
		if (proxyUrl != null) {
			// Setting proxy properties for driver
			Proxy proxy = new Proxy();
			proxy.setHttpProxy(proxyUrl);
			proxy.setSslProxy(proxyUrl);

			options.setCapability("proxy", proxy);
		}
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider="DataSet",invocationCount=1)
	public void prorocolAuthenticationTest(String IssuerBankId, String IssuerBankName, String acctNumber,
			String cardUnionType, String ProtocalVersion, String threeDSServerTransID, String threeDSServerPaRqURL,
			String acsTransID, String dsTransID, String cReq, String acsChallengeReqUrl, String authenticationUrl,
			String cres, String decs) throws Exception {
		
		System.out.println("*****************Test Started*********************");
		
		System.out.println("Cardnumber:"+acctNumber);
		
		Thread.sleep(5000);
		SoftAssert sAssertion = new SoftAssert();
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		ACSSimulatorReponsePage responsepage = new ACSSimulatorReponsePage(driver);
		GenericMethods generic = new GenericMethods(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "threeDSServerTransID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "threeDSServerPaRqURL", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "acsTransID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "dsTransID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "cReq", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "acsChallengeReqUrl", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "authenticationUrl", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "cres", invocationCount, "");
		

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");

		String pVrqRequestBody = RequestBodyHelper.generatePVrqRequestBody(ProtocalVersion, acctNumber);
		System.out.println("pVrqRequestBody:"+pVrqRequestBody);
		
		Response response = ProtocolAPIMethods.getPVRQ(pVrqRequestBody);
		JsonPath jsonPathEvaluator = response.jsonPath();
		Thread.sleep(2000);
		threeDSServerTransID = jsonPathEvaluator.getString("threeDSServerTransID");
		threeDSServerPaRqURL = jsonPathEvaluator.getString("threeDSServerPaRqURL");
		
		System.out.println(threeDSServerTransID);
		System.out.println(threeDSServerPaRqURL);
		
		String pArqRequestBody = RequestBodyHelper.generatePARQRequestBody(ProtocalVersion, threeDSServerTransID, acctNumber);
		System.out.println("pArqRequestBody:" + pArqRequestBody);
		
		Response response1 = ProtocolAPIMethods.getPARQ(pArqRequestBody, threeDSServerPaRqURL);
		JsonPath jsonPathEvaluator1 = response1.jsonPath();
		Thread.sleep(2000);
		
		acsTransID = jsonPathEvaluator1.getString("acsTransID");
		dsTransID = jsonPathEvaluator1.getString("dsTransID");
		cReq = jsonPathEvaluator1.getString("cReq");
		acsChallengeReqUrl = jsonPathEvaluator1.getString("acsChallengeReqUrl");
		authenticationUrl = jsonPathEvaluator1.getString("authenticationUrl");
		System.out.println(response1.getBody().asString());
		System.out.println("acsTransID:"+acsTransID);
		System.out.println("dsTransID:"+dsTransID);
		System.out.println("cReq:"+cReq);
		System.out.println("acsChallengeReqUrl:"+acsChallengeReqUrl);
		System.out.println("authenticationUrl:"+authenticationUrl);
		
		Response response2 = ProtocolAPIMethods.getCreq(acsChallengeReqUrl, cReq);
		JsonPath jsonPathEvaluator2 = response2.jsonPath();
		String creqResponse = response2.getBody().asString();
		System.out.println("creqResponse:"+creqResponse);
		
		// Write Creq Response as a html file
		String filePath = System.getProperty("user.dir")+ "/otpPage.html";
		try {
			File myObj = new File(filePath);
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
				
			} else {
				System.out.println("File already exists.");
			}
			FileWriter myWriter = new FileWriter(filePath);
			myWriter.write(creqResponse);
			myWriter.close();
	      
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		  
		driver.get(filePath);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	

		String otpValue = OTPFromEngine.getOTPFromEngine(acctNumber, IssuerBankId, acsTransID);
		
		otp.getOtpTextField().sendKeys(otpValue);
		generic.explicitWait(1);

		otp.getOtpSubmitButton().click();
		generic.explicitWait(2);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));

		/*
		 * sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(),
		 * "Status : Y");
		 * 
		 * if (cardUnionType.equalsIgnoreCase("Visa")) {
		 * sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt
		 * ().getText(), "ECI : 05", "ECI Value Validation");
		 * 
		 * } else {
		 * sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt(
		 * ).getText(), "ECI : 02", "ECI Value Validation"); }
		 */
		
		
		
		// TODO Get ACS Auth Response
		String acsAuthResponse = "";
		NetWorklogs1 = driver.manage().logs().get("driver");
		for (Iterator<LogEntry> it = NetWorklogs1.iterator(); it.hasNext();) {
			LogEntry entry = it.next();
			
			if(entry.getMessage().contains("cres=")) {
				System.out.println(entry.getMessage());
				//System.out.println(entry.getLevel());
				try {			
				int index = entry.getMessage().contains("{") ? entry.getMessage().indexOf("{") : 0;
			    String message =  entry.getMessage().substring(index, entry.getMessage().length());
			    
				JSONObject json = new JSONObject(message);
				//System.out.println(json.get("documentURL"));
				
				JSONObject request = json.getJSONObject("request");
				String postData = request.getString("postData");
				System.out.println(postData);
				acsAuthResponse = postData.split("&cres=")[1];
				}catch(JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
					
		String prqFrqRequestBody = RequestBodyHelper.getPrqFrqRequestBody(ProtocalVersion, threeDSServerTransID, acsTransID, dsTransID, acsAuthResponse);
		System.out.println(prqFrqRequestBody);
		Response response3 = ProtocolAPIMethods.getPrqFrq(prqFrqRequestBody);
		JsonPath jsonPathEvaluator3 = response3.jsonPath();
		String prqFrqResponse = response3.getBody().asString();
		System.out.println(prqFrqResponse);
		sAssertion.assertAll();
		
		// Store the details in the excel file
		System.out.println("Page opened");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "threeDSServerTransID", invocationCount, threeDSServerTransID);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "threeDSServerPaRqURL", invocationCount, threeDSServerPaRqURL);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "acsTransID", invocationCount, acsTransID);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "dsTransID", invocationCount, dsTransID);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "cReq", invocationCount, cReq);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "acsChallengeReqUrl", invocationCount, acsChallengeReqUrl);
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "authenticationUrl", invocationCount, authenticationUrl);
		
	}
	
	private void writeTxnIdExcelFile(String txnId) {
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, txnId);
		
		// Writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, txnId);
	}

}

package com.api.protocol;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import org.testng.Reporter;

import com.acs.libraries.Config;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ProtocolAPIMethods {

	public static Response getPVRQ(String jsonbody) throws IOException {

		Reporter.log("JSON Request Body:   " + jsonbody);
		Response pvrqResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.DCS_PVRQ_URL);
		
		Reporter.log("Status Code" + pvrqResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + pvrqResponse);
		pvrqResponse.then().statusCode(200);
		return pvrqResponse;
	}
	
	public static Response getPARQ(String jsonBody, String url) throws IOException {
		Reporter.log("JSON Request Body:   " + jsonBody);
		Response pArqResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonBody).when().post(url);
		
		Reporter.log("Status Code" + pArqResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + pArqResponse);
		pArqResponse.then().statusCode(200);
		return pArqResponse;
	}
	
	public static Response getCreq(String acsChallengeReqUrl, String creq) throws IOException {
		String body = String.format("creq=%s", creq);
		Response creqResponse = given().contentType("application/x-www-form-urlencoded").and()
				.body(body).when().post(acsChallengeReqUrl);
		Reporter.log("Status Code" + creqResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + creqResponse);
		creqResponse.then().statusCode(200);
		return creqResponse;
	}
	
	public static Response getPrqFrq(String jsonBody) throws IOException {
		Response pRqFrqResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonBody).when().post(Config.DCS_PRQFRQ_URL);
		
		Reporter.log("Status Code" + pRqFrqResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + pRqFrqResponse);
		pRqFrqResponse.then().statusCode(200);
		return pRqFrqResponse;
	}
	
}

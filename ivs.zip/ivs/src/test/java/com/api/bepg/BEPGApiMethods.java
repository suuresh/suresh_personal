package com.api.bepg;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import org.testng.Reporter;

import com.acs.libraries.Config;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class BEPGApiMethods {
	
	// Method to Encode generate OTP
	public static String encodeGenerateOtpRequest(String protocalVersion, String userId, String cardNo, String tranId, String requestId) throws IOException {

		Reporter.log("Encode Generate Otp");
		String jsonbody = RequestBodyHelper.encodeGenerateOtpBody(protocalVersion, userId, cardNo, tranId, requestId);

		//System.out.println(jsonbody);

		Reporter.log("JSON Request Body:   " + jsonbody);
		Response EncodeGenerateOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_BEPG_MPI_URL + "encodeGenerateOtpRequest");

		String EncodeGenerateOtpBody = EncodeGenerateOtpResponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + EncodeGenerateOtpResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + EncodeGenerateOtpBody);
		EncodeGenerateOtpResponse.then().statusCode(200);
		return EncodeGenerateOtpBody;
	}

	/* Generate OTP Request */
	public static String generateOTPRequest(String generateOtpBody) {

		Reporter.log("OTP GENERATE INIT");

		Response generateOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(generateOtpBody).when().post(Config.BASE_BEPG_MPI_URL + "generate_OTP");

		String generateOtpResBody = generateOtpResponse.getBody().asString();
		// JsonPath jsonPathEvaluator = generateOtpResponse.jsonPath();
		generateOtpResponse.then().statusCode(200);
		
		

		System.out.println("generateOtpResBody: " + generateOtpResBody);
		Reporter.log("OTP Generate Init Reponse: " + generateOtpResBody);
		return generateOtpResBody;
	}

	/* Decode Generated OTP */
	public static Response decodeGenerateOtpRequest(String generatedOTPResponse) {
		Reporter.log("Decode Generated OTP Request");
		String response = null;
		Response generateOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(generatedOTPResponse).when().post(Config.BASE_BEPG_MPI_URL + "decodeGenerateOtpRequest");

		response = generateOtpResponse.getBody().asString();
		// JsonPath jsonPathEvaluator = generateOtpResponse.jsonPath();
		generateOtpResponse.then().statusCode(200);

		System.out.println("DecodedOtpResBody: " + response);
		Reporter.log("Decoded OTP Reponse: " + response);

		return generateOtpResponse;
	}
	
	/* Encode Verify OTP */
	public static String encodeVerifyOtpRequest(String protocalVersion, String userId, String issuer_guid, String tranId, String otpValue) {

		Reporter.log("Encode Verify Otp");
		String jsonbody = RequestBodyHelper.encodeVerifyOtpBody(protocalVersion, userId, issuer_guid, tranId, otpValue);

		System.out.println(jsonbody);

		Reporter.log("JSON Request Body:   " + jsonbody);
		Response EncodeVerifyOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(jsonbody).when().post(Config.BASE_BEPG_MPI_URL + "encodeVerifyOtpRequest");

		String encodeVerifyOtpBody = EncodeVerifyOtpResponse.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + EncodeVerifyOtpResponse.getStatusCode());
		Reporter.log("Response of Encode Verify OTP" + encodeVerifyOtpBody);
		EncodeVerifyOtpResponse.then().statusCode(200);
		return encodeVerifyOtpBody;
	}

	/* Verify OTP */
	public static String verifyOTP(String verifyOTPBody) {
		Reporter.log("Verify OTP");

		Response generateVerifyOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(verifyOTPBody).when().post(Config.BASE_BEPG_MPI_URL + "verify_OTP");

		String generateVerifyOtpResBody = generateVerifyOtpResponse.getBody().asString();
		// JsonPath jsonPathEvaluator = generateOtpResponse.jsonPath();
		generateVerifyOtpResponse.then().statusCode(200);

		System.out.println("generateVerifyOtpResBody: " + generateVerifyOtpResBody);
		Reporter.log("Verify OTP Reponse: " + generateVerifyOtpResBody);
		return generateVerifyOtpResBody;
	}
	
	/*Decode Verify Otp Request*/
	public static Response decodeVerifyOtpRequest(String verifyOtpResBody) {
		
		Reporter.log("Decode Verify OTP Request");
		String response = null;
		Response verifyOtpResponse = given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and()
				.body(verifyOtpResBody).when().post(Config.BASE_BEPG_MPI_URL + "decodeVerifyOtpRequest");

		response = verifyOtpResponse.getBody().asString();
		// JsonPath jsonPathEvaluator = generateOtpResponse.jsonPath();
		verifyOtpResponse.then().statusCode(200);

		System.out.println("DecodedVerifyOtpResBody: " + response);
		Reporter.log("Decoded Verify OTP Reponse: " + response);

		return verifyOtpResponse;
	}
	
	
	

}

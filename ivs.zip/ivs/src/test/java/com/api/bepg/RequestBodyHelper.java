package com.api.bepg;

import java.util.HashMap;
import java.util.Map;

public class RequestBodyHelper {
    
    public static String encodeGenerateOtpBody(String protocalVersion, String UserId, String cardNo, String tranId, String requestId)
    {
        String jsonbody= "{"
        		+ "    \"header\": {"
        		+ "        \"version\": \""+protocalVersion+"\","
        		+ "        \"userid\": \""+UserId+ "\""
        		+ "    },"
        		+ "    \"body\": {"
        		+ "        \"card_no\": \""+cardNo+"\","
        		+ "        \"card_exp_date\": \"112023\","
        		+ "        \"card_cvd\": \"123\","
        		+ "        \"card_holder_status\": \"NW\","
        		+ "        \"merchantName\": \"MerchantWibmo\","
        		+ "        \"amount\": \"100.25\","
        		+ "        \"currency_code\": \"356\","
        		+ "        \"shopper_ip_address\": \"203.11.11.12\","
        		+ "        \"language_code\": \"EN\","
        		+ "        \"tran_id\": \""+tranId+"\","
        		+ "        \"requestID\": \""+requestId+"\","
        		+ "        \"app_id\": \"1234567890\""
        		+ "    }"
        		+ "}";
        
        return jsonbody;
    }
    
    public static String encodeVerifyOtpBody(String protocalVersion, String userId, String issuer_guid,  String tranId, String otpValue) {
    	String jsonbody = "{"
    			+ "    \"header\": {"
    			+ "        \"version\": \""+protocalVersion+"\","
    			+ "        \"userid\": \""+userId+"\""
    			+ "    },"
    			+ "    \"body\": {"
    			+ "        \"issuer_guid\": \""+issuer_guid+"\","
    			+ "        \"shopper_ip_address\": \"203.11.11.12\","
    			+ "        \"tran_id\": \""+tranId+"\","
    			+ "        \"otp\": \""+otpValue+"\""
    			+ "    }"
    			+ "}";
    	return jsonbody;
    }
    
    
    
    
  
    
    
    
  
    





}

package com.api.bepg;

import java.io.IOException;
import java.util.Random;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class BEPGAuthenticationFlow extends ACSInitialSetUp {

	int invocationCount = 2;
	public String acsTxnId = null;

	public String encodeGenerateOtpResponse = null;
	
	public String rbaAuthAttempted = null;
	public String generateOtp = null;
	public String decodeGenerateOtpRequest = null;
	public String decodeVerifyOtpRequest = null;
	public String encodeVerifyOtpRequest = null;
	public String verifyOTP = null;
	public Response response = null;
	public Response response1 = null;

	public JsonPath jsonPathEvaluator = null;
	public JsonPath jsonPathEvaluator1 = null;
	public String issuer_guid = null;
	public String authResponseCode = null;
	public String errormsg = null;
	public String errorcode = null;
	public String txnId = null;
	public String preTxnId = null;
	public String preRequestId = null;

	public Xls_Reader excel;

	public LogOutPage logout;
	public LoginPage loginPage;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String XlFileName = null;
	public String OnBoradingXlFileName = null;
	public TridentLogOutPage tlogout;
	public TridentLoginPage tloginPage;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String proxyUrl = null;
	public WebDriverWait wait;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	@SuppressWarnings("deprecation")
	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
			"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
			"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName", "ENV" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename,
			String txn1_0sheetName, String txn2_0sheetName, String acstxn1_0sheetName, String acstxn2_0sheetName,
			String tridenttxn1_0sheetName, String tridenttxn2_0sheetName, String threedsstxn2_0sheetName, String env)
			throws Exception {
	
		Config.BASE_ENVIRONMENT = env;
		Config.assignEnvironment();
		

		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0SheetName = txn1_0sheetName;
		Txn2_0SheetName = txn2_0sheetName;
		ACSTxn1_0SheetName = acstxn1_0sheetName;
		ACSTxn2_0SheetName = acstxn2_0sheetName;
		TridentTxn1_0SheetName = tridenttxn1_0sheetName;
		TridentTxn2_0SheetName = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0SheetName = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void rupayBEPGAuthenticationTest(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String ProtocalVersion, String UserId, String Flow, String AuthPrefrence, String authFlag, String TransType, String CardUnionType, String AcsTxnId, String CavvOrAvv, 
			String decs) throws Exception {
		
		System.out.println("*****************Test Started*********************");
		System.out.println("Flow:"+Flow);
		System.out.println("Cardnumber:"+Cardnumber);
		
		Thread.sleep(5000);
		SoftAssert sAssertion = new SoftAssert();
		
		String tranId = GenericMethods.generateRandomDigitsNumber(15)+""+GenericMethods.generateRandomDigitsNumber(15);
		String requestId = GenericMethods.generateRandomDigitsNumber(15)+""+GenericMethods.generateRandomDigitsNumber(11);
		/*System.out.println("tranId"+tranId.length());
		System.out.println("requestId"+requestId.length());*/
		
		String otpValue = null;
		
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");

		switch (Flow) {

		case "Challenge":
			//System.out.println("************* V2 challenge ******************");
		
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			
			//System.out.println("encodeGenerateOtpResponse: " + encodeGenerateOtpResponse);
			
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			
			Thread.sleep(5000);
			
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			issuer_guid = jsonPathEvaluator.getString("issuer_guid");
			
			//System.out.println("decodeGenerateOtpRequest: " + decodeGenerateOtpRequest);
			//System.out.println("issuer_guid: " + issuer_guid);
			
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			
			// getotpValue
			otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, txnId);
			//System.out.println("otpValue:"+otpValue);
			
			// pass UserId, issuer_guid, tranId, otpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, otpValue);
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode");
			errormsg = jsonPathEvaluator1.getString("errormsg");
			
			sAssertion.assertEquals(authResponseCode, "ACCU000");
			sAssertion.assertEquals(errormsg, "OTP Verificatin Successful");
			
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			break;
			
		case "Failed":
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			//Thread.sleep(5000);
			//txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//56
			errormsg = jsonPathEvaluator.getString("errormsg"); // Internal error occurred. 
			
			
			
			sAssertion.assertEquals(errorcode, "56");
			sAssertion.assertEquals(errormsg, "No such Card number not present in IAS system.");
			
			// Write txnid in excel
			//writeTxnIdExcelFile(txnId);
			break;

		case "ReSendOTP":
			//System.out.println("************* V2 Resed OTP ******************");
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//00
			errormsg = jsonPathEvaluator.getString("errormsg"); // "" 
			sAssertion.assertEquals(errorcode, "00");
			sAssertion.assertEquals(errormsg, "");
			
			//First
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//00
			errormsg = jsonPathEvaluator.getString("errormsg"); // "" 
			sAssertion.assertEquals(errorcode, "00");
			sAssertion.assertEquals(errormsg, "");
			
			//Second
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			
			System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//00
			errormsg = jsonPathEvaluator.getString("errormsg"); // "" 
			sAssertion.assertEquals(errorcode, "00");
			sAssertion.assertEquals(errormsg, "");
			
			//Third
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//00
			errormsg = jsonPathEvaluator.getString("errormsg"); // "" 
			sAssertion.assertEquals(errorcode, "00");
			sAssertion.assertEquals(errormsg, "");
			
			// Fourth
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//453
			errormsg = jsonPathEvaluator.getString("errormsg"); // "Exhausted OTP resend count" 
			sAssertion.assertEquals(errorcode, "453");
			sAssertion.assertEquals(errormsg, "Exhausted OTP resend count");
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			break;
			
		case "OTPPage":
			//1. Invalid otp error code  for 2 times 450
			//2. Third invalid otp error code is 452
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			
			//System.out.println("encodeGenerateOtpResponse: " + encodeGenerateOtpResponse);
			
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			issuer_guid = jsonPathEvaluator.getString("issuer_guid");
			
			//System.out.println("decodeGenerateOtpRequest: " + decodeGenerateOtpRequest);
			//System.out.println("issuer_guid: " + issuer_guid);
			
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			
			// getotpValue
			otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, txnId);
			//System.out.println("otpValue:"+otpValue);
			
			
			// First invalid otp
			
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode"); //450
			errormsg = jsonPathEvaluator1.getString("errormsg"); // "Invalid OTP"
			
			sAssertion.assertEquals(authResponseCode, "450");
			sAssertion.assertEquals(errormsg, "Invalid OTP");
			
			// Second invalid otp
			
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode");
			errormsg = jsonPathEvaluator1.getString("errormsg");
			
			sAssertion.assertEquals(authResponseCode, "450");
			sAssertion.assertEquals(errormsg, "Invalid OTP");
			
			// Third invalid otp
			
			// pass UserId, issuer_guid, tranId, otpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode"); // 452
			errormsg = jsonPathEvaluator1.getString("errormsg"); // Exhausted OTP verification
			
			sAssertion.assertEquals(authResponseCode, "452");
			sAssertion.assertEquals(errormsg, "Exhausted OTP verification");
			
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			
			break;
			
		case "OTPExpiry":
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			
			//System.out.println("encodeGenerateOtpResponse: " + encodeGenerateOtpResponse);
			
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			issuer_guid = jsonPathEvaluator.getString("issuer_guid");
			
			//System.out.println("decodeGenerateOtpRequest: " + decodeGenerateOtpRequest);
			System.out.println("issuer_guid: " + issuer_guid);
			
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			
			// getotpValue
			otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, txnId);
			//System.out.println("otpValue:"+otpValue);
			
			// pass UserId, issuer_guid, tranId, otpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, otpValue);
			
			// Delay for 180 sec
			Thread.sleep(180000);
			
			Thread.sleep(3000);
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode"); // 451
			errormsg = jsonPathEvaluator1.getString("errormsg");	// "OTP Exired"
			
			sAssertion.assertEquals(authResponseCode, "451");
			sAssertion.assertEquals(errormsg, "OTP Exired");
			
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			break;
			
		case "VerifyOTPThirdTime":
			/*
			 * 1. Invalid otp error code for 2 times 450 
			 * 2. Third time valid otp error code is 00
			 */
			preTxnId = tranId;
			preRequestId = requestId;
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			
			//System.out.println("encodeGenerateOtpResponse: " + encodeGenerateOtpResponse);
			
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			issuer_guid = jsonPathEvaluator.getString("issuer_guid");
			
			//System.out.println("decodeGenerateOtpRequest: " + decodeGenerateOtpRequest);
			System.out.println("issuer_guid: " + issuer_guid);
			
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			
			// getotpValue
			otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, txnId);
			System.out.println("otpValue:"+otpValue);
			
			
			// First invalid otp
			
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode"); //450
			errormsg = jsonPathEvaluator1.getString("errormsg"); // "Invalid OTP"
			
			sAssertion.assertEquals(authResponseCode, "450");
			sAssertion.assertEquals(errormsg, "Invalid OTP");
			
			// Second invalid otp
			
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode");
			errormsg = jsonPathEvaluator1.getString("errormsg");
			
			sAssertion.assertEquals(authResponseCode, "450");
			sAssertion.assertEquals(errormsg, "Invalid OTP");
			
			// Third valid otp
			
			// pass UserId, issuer_guid, tranId, otpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, otpValue);
			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode");
			errormsg = jsonPathEvaluator1.getString("errormsg");
			
			sAssertion.assertEquals(authResponseCode, "ACCU000");
			sAssertion.assertEquals(errormsg, "OTP Verificatin Successful");
			
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			
			
			break;
			
		case "SameRequestIdWithDifferentCard":
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, preTxnId, preRequestId);
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			//txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//454
			errormsg = jsonPathEvaluator.getString("errormsg"); // Duplicate requestID
			
			
			
			sAssertion.assertEquals(errorcode, "454");
			sAssertion.assertEquals(errormsg, "Duplicate requestID");
			
			// Write txnid in excel
			//writeTxnIdExcelFile(txnId);		
			
			break;
			
		case "BlockCard":
			// Resend otp for three times card will be block
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			
			//System.out.println("encodeGenerateOtpResponse: " + encodeGenerateOtpResponse);
			
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			issuer_guid = jsonPathEvaluator.getString("issuer_guid");
			
			//System.out.println("decodeGenerateOtpRequest: " + decodeGenerateOtpRequest);
			System.out.println("issuer_guid: " + issuer_guid);
			
			otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, txnId);
			System.out.println("otpValue:"+otpValue);
			
			// getotpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			// getotpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			// getotpValue
			encodeVerifyOtpRequest = BEPGApiMethods.encodeVerifyOtpRequest(ProtocalVersion, UserId, issuer_guid, tranId, "123456");			
			verifyOTP = BEPGApiMethods.verifyOTP(encodeVerifyOtpRequest);
			
			response1 = BEPGApiMethods.decodeVerifyOtpRequest(verifyOTP);
			decodeVerifyOtpRequest = response1.getBody().asString();
			jsonPathEvaluator1 = response1.jsonPath();
			authResponseCode = jsonPathEvaluator1.getString("authResponseCode"); // 452
			errormsg = jsonPathEvaluator1.getString("errormsg"); // Exhausted OTP verification
			
			System.out.println("authResponseCode:"+authResponseCode);
			System.out.println("errormsg:"+errormsg);
			// TODO
			sAssertion.assertEquals(authResponseCode, "452");
			sAssertion.assertEquals(errormsg, "Exhausted OTP verification");
			
			
			// Write txnid in excel			
			writeTxnIdExcelFile(txnId);
			

			break;

		case "Blocked":
			//System.out.println("************* V2 Blocked  ******************");
			
			encodeGenerateOtpResponse = BEPGApiMethods.encodeGenerateOtpRequest(ProtocalVersion, UserId, Cardnumber, tranId, requestId);
			generateOtp = BEPGApiMethods.generateOTPRequest(encodeGenerateOtpResponse);
			Thread.sleep(5000);
			//txnId = GenericMethods.getAcsTxnIdFromOTPTxn(IssuerBankId);
			//System.out.println("generateOtp: " + generateOtp);
			
			
			// decodeGenerateOtpRequest
			response = BEPGApiMethods.decodeGenerateOtpRequest(generateOtp);
			decodeGenerateOtpRequest = response.getBody().asString();
			jsonPathEvaluator = response.jsonPath();
			errorcode = jsonPathEvaluator.getString("errorcode");	//ACCU500
			errormsg = jsonPathEvaluator.getString("errormsg"); // User has been locked out
			
			//System.out.println("authResponseCode:"+authResponseCode);
			System.out.println("errormsg:"+errormsg);
			
			sAssertion.assertEquals(errorcode, "ACCU500");
			sAssertion.assertEquals(errormsg, "User has been locked out");
			
			// Write txnid in excel
			//writeTxnIdExcelFile(txnId);	
			break;

		
		}
		sAssertion.assertAll();
		invocationCount++;
	}
	
	private void writeTxnIdExcelFile(String txnId) {
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, txnId);
		
		// Writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, txnId);
	}

}

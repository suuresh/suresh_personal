package com.acs.utils;

import java.io.ByteArrayInputStream;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.logging.Logger;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import java.util.Base64;
import com.nimbusds.jose.JWEDecrypter;

import com.nimbusds.jose.JWEHeader;
import java.security.interfaces.RSAPublicKey;

import com.nimbusds.jose.crypto.RSADecrypter;

import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSAEncrypter;

public class JWEEncryptionDeWhitelisting {

	public static String jweEncryption(String requestJson, String issuerId) {
		JWEObject jweObject = new JWEObject(new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A128GCM).keyID("rsa1")
				.build(),
				new Payload(requestJson));

		// Encrypt with the recipient's public key
		PublicKey serverPublicKey = generateServerPublicKey(issuerId);
		try {
			jweObject.encrypt(new RSAEncrypter((RSAPublicKey) serverPublicKey));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//logger.error("FAILED - jweEncryption-cause{}",e);
		}
		System.out.println(jweObject.serialize());
		return jweObject.serialize();
	}
	private static PublicKey generateServerPublicKey(String issuerId) {
		PublicKey publicKey = null;
		String encodedCert = "MIIDejCCAmKgAwIBAgIEYDdHtjANBgkqhkiG9w0BAQsFADB/MQswCQYDVQQGEwJJTjESMBAGA1UECAwJS2FybmF0YWthMRIwEAYDVQQHDAlCYW5nYWxvcmUxHjAcBgNVBAoMFWVuU3RhZ2VTb2Z0d2FyZVB2dEx0ZDEoMCYGA1UEAwwfY3VzdC1lbnJvbGwtdWF0LmVuc3RhZ2UtdWF0LmNvbTAeFw0yMTAyMjUwNjQ2MTRaFw0yMjAyMjUwNjQ2MTRaMH8xCzAJBgNVBAYTAklOMRIwEAYDVQQIDAlLYXJuYXRha2ExEjAQBgNVBAcMCUJhbmdhbG9yZTEeMBwGA1UECgwVZW5TdGFnZVNvZnR3YXJlUHZ0THRkMSgwJgYDVQQDDB9jdXN0LWVucm9sbC11YXQuZW5zdGFnZS11YXQuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqKxcVBvqkhO/H8iZ1RIc+k1IdfV7WMA2OX21TCtbm86L+X9yS22Sv0MjyGIQRbjVv/PwCdLoCG889K6UsJZBPl9v9IjhhZbA0YmJ8E384i9sxRwjftgcX/1wvNT4SPqNoQ+h6odi8Mm4GwMd48lZTmffBtPEj/2drGbvLYHVROCY4oHtqgt2J8HjVwjdNNVlSvgYp4WVe3NEda+IkrQxt8p0Rtvhj8cQpck8gwLq/z6yQ5UsGF+2e0nKi/ZJG09at5bRt+gIvUyj30E8gw3+tWxIy46HWQYT1z4vsnPw8JnxBHDu0eK1O4EF3AOB8Hpu4SpdPYXNP2auN7MrGZNTiQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAfVPyalYBw8wULDfP++jep88JRT6to4TXd2PiAksn84zhqzm/YkLTzdWyJBQHIkIt3f7OuMQbqgF0SWe2R3zVSvoEoPWcg6SQlP/Ar5NilzhCWPyqKhNMcONvC0+cgpFe0Vj5xZKMFuVxr1/xXj59WeFI9vysgM9uO8mmOSgUscF6JFdfj4S6YsGgV5Q2ezjprwvCi15AlylVROpOymagT4wfL/L7hwHIek2AtE9ZnbLChRg5xmmWv7GkvOJaJ0BkKShIoBT5Sm38hQUJ7rRrXTHG1+u70RPXQQ7dIXTX7f+qzk4K7MpGNZlIhB9yaJVRxdOGArSv0imZJSSodBam9";
		try {
			java.security.cert.Certificate certificate = convertStringToCertificate(encodedCert) ;
			publicKey = certificate.getPublicKey();
		} catch (Exception e) {
			//logger.error("FAILED - generateServerPublicKeyFromString-cause{}",e);
		}

		return publicKey;
	}
	public static Certificate convertStringToCertificate(String input) {
		Certificate certificate = null;
		byte[] cert = null;
		if (input != null && !"".equals(input.trim())) {
			try {
				input = input.replace("-----BEGIN CERTIFICATE-----", "");
				input = input.replace("-----END CERTIFICATE-----", "");
				cert = Base64.getDecoder().decode(input.getBytes());
				CertificateFactory certificateFactory = CertificateFactory.getInstance("X509");
				certificate = certificateFactory.generateCertificate(new ByteArrayInputStream(cert));
			} catch (Exception var4) {
				//logger.error("convertStringToCertificate-{},", var4.getMessage(), var4);
			} }

		return certificate;
	}
	public static void main(String[] args) throws Exception {
		String fetchRequest = "{\r\n" +
				" \"accountNumber\":\"4568664410900244\",\r\n" +
				" \"apiVersion\":\"1.0\",\r\n" +
				" \"apiRefId\":\"123acbds2345\",\r\n" +
				" \"action\":\"FET\"\r\n" +
				"}";
		String updateRequest = "{\r\n" +
				" \r\n" +
				" \"accountNumber\":\"4568664200966777\",\r\n" +
				" \"apiVersion\":\"1.0\",\r\n" +
				" \"apiRefId\":\"123acbds2345\",\r\n" +
				" \"action\":\"UPD\",\r\n" +
				" \"merchantDetails\":[\r\n" +
				" {\"merchantId\":\"9876543210390\",\"merchantName\":\"MyPoolin\",\"status\":2}]\r\n" +
				" \r\n" +
				"}";
		jweEncryption(updateRequest, null);
	}

}
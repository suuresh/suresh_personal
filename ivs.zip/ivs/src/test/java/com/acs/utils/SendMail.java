package com.acs.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.seleniumhq.jetty9.util.log.Log;

import com.acs.libraries.Config;



public class SendMail
{
	//public static void sendMail(String mailServer, String from,String username, String password,String port, String[] to, String subject, String messageBody, String attachmentPath, String attachmentName) throws MessagingException, AddressException
	public void sendMail(String smtphost, String smtpport, String from, String[] to, String subject, String messageBody, String attachmentPath, String attachmentName) throws MessagingException, AddressException
	{
		boolean debug = false;
		Properties props = new Properties();
		props.put("mail.smtp.host", smtphost);
        props.put("mail.smtp.port", smtpport);
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.EnableSSL.enable","true");
		props.put("mail.smtp.auth", "true");

	//	props.put("mail.smtp.host", mailServer); 
		props.put("mail.debug", "true");
		
	     props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
	     props.setProperty("mail.smtp.socketFactory.fallback", "false");   
	     props.setProperty("mail.smtp.port", "465");   
	     props.setProperty("mail.smtp.socketFactory.port", "465"); 

		
		  Authenticator auth = new SMTPAuthenticator();
		    Session session = Session.getDefaultInstance(props, auth);

		    session.setDebug(debug);
		
		try
		{
			
			
			Transport bus = session.getTransport("smtp");
			bus.connect();
            Message message = new MimeMessage(session);
        
         //X-Priority values are generally numbers like 1 (for highest priority), 3 (normal) and 5 (lowest).
            
             message.addHeader("X-Priority", "1");
             message.setFrom(new InternetAddress(from));
             InternetAddress[] addressTo = new InternetAddress[to.length];
             for (int i = 0; i < to.length; i++)
      		 addressTo[i] = new InternetAddress(to[i]);
             message.setRecipients(Message.RecipientType .TO, addressTo);
             message.setSubject(subject);
                  
             
             BodyPart body = new MimeBodyPart();

            // body.setText(messageBody);
            body.setContent(messageBody,"text/html");

             BodyPart attachment = new MimeBodyPart();
             DataSource source = new FileDataSource(attachmentPath);
             attachment.setDataHandler(new DataHandler(source));
             attachment.setFileName(attachmentName);
             MimeMultipart multipart = new MimeMultipart();
             multipart.addBodyPart(body);
             multipart.addBodyPart(attachment);
             message.setContent(multipart);
             Transport.send(message);
             System.out.println("Sucessfully Sent mail to All Users");
         	 bus.close();
    		
		}
		catch (MessagingException mex)
		{
            mex.printStackTrace();
        }		
	} 
	
	private class SMTPAuthenticator extends javax.mail.Authenticator
	{

	    public PasswordAuthentication getPasswordAuthentication()
	    {
	        String username = Config.frommailid;
	        String password = Config.mailpassword;
	        return new PasswordAuthentication(username, password);
	    }
	}
	
	public void sendEmailWithAttachments(String host, String port,
            final String userName, final String password, String[] mailToArr,String[] mailCCArr,String[] mailBCCArr,
            String subject, String message, String[] attachmentPath) throws AddressException, MessagingException
           {
		//String attach_logFiles = attachlogFiles[0];
		//String attach_ZipFiles = attachzipFiles[0];
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.user", userName);
        properties.put("mail.password", password);
 
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password);
            }
        };
        Session session = Session.getInstance(properties, auth);
 
       try
       {
        
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
 
        msg.setFrom(new InternetAddress(userName));

        boolean s = false;
        
        if(s = mailToArr == null && mailCCArr == null && mailBCCArr==null) 
        {
        	if(s == true)
        	{
        		System.out.println("Please add recepients");
        		throw new Exception();
        	}
        }
        //To Email ID
     
        ArrayList<String> toEmailID = new ArrayList<String>();
        if(mailToArr == null)
        {}
        else
        {
        	for(int i =0 ;i<mailToArr.length;i++)
	        {
	        	toEmailID.add(mailToArr[i]);
	        }
        }
        InternetAddress[] toAddress = new InternetAddress[toEmailID.size()];
        for (int i = 0; i < toEmailID.size(); i++) {
        	toAddress[i] = new InternetAddress(toEmailID.get(i).toString());
        }

        msg.setRecipients(Message.RecipientType.TO, toAddress);

        //CC Email ID
        
        ArrayList<String> ccEmailID = new ArrayList<String>();
        if(mailCCArr == null)
        {}
        else
        {
        	 for(int i =0 ;i<mailCCArr.length;i++)
 	        {
 	        	ccEmailID.add(mailCCArr[i]);
 	        }
        }
        InternetAddress[] ccAddress = new InternetAddress[ccEmailID.size()];
        for (int i = 0; i < ccEmailID.size(); i++) {
        	ccAddress[i] = new InternetAddress(ccEmailID.get(i).toString());
        }

        msg.setRecipients(Message.RecipientType.CC, ccAddress);
        
        //BCC Email ID
        
        ArrayList<String> bccEmailID = new ArrayList<String>();
        if(mailBCCArr == null)
        {}
        else
        {
        	for(int i =0 ;i<mailBCCArr.length;i++)
 	        {
 	        	bccEmailID.add(mailBCCArr[i]);
 	        }
        }
        InternetAddress[] bccAddress = new InternetAddress[bccEmailID.size()];
        for (int i = 0; i < bccEmailID.size(); i++) {
        	bccAddress[i] = new InternetAddress(bccEmailID.get(i).toString());
        }

        msg.setRecipients(Message.RecipientType.BCC, bccAddress);
        
        //Subject
        msg.setSubject(subject);
        msg.setSentDate(new Date());
 
        // creates message part
     //   MimeBodyPart messageBodyPart = new MimeBodyPart();
     //   messageBodyPart.setContent(message, "text/html");
 
        // creates multi-part
      Multipart multipart = new MimeMultipart();
     //   multipart.addBodyPart(messageBodyPart);


    	MimeBodyPart textPart = new MimeBodyPart();
		textPart.setContent(message, "text/html");
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		DataSource fds = new FileDataSource(
				System.getProperty("user.dir").replace("/", "/") + "/images/PieChart.png");
		messageBodyPart.setDataHandler(new DataHandler(fds));
		messageBodyPart.setHeader("Content-ID", "<image>");
		multipart.addBodyPart(textPart);
		multipart.addBodyPart(messageBodyPart);
        
        
        /*File f_log = new File(attach_logFiles);
        if(f_log.exists() && !f_log.isDirectory()) { 
            // do something
        	 MimeBodyPart attachPart = new MimeBodyPart();
             attachPart.attachFile(attach_logFiles);
             multipart.addBodyPart(attachPart);
        }
        else
        {
        	System.out.println("Log File is not found");
        }*/
        
        /*File f_zip = new File(attach_ZipFiles);
        if(f_zip.exists() && !f_zip.isDirectory()) { 
            // do something
        	 MimeBodyPart attachPart = new MimeBodyPart();
            // attachPart.attachFile(attach_ZipFiles);
             multipart.addBodyPart(attachPart);
        }
        else
        {
        	System.out.println("Zip File is not found");
        }*/
        // adds attachments
       if (attachmentPath != null && attachmentPath.length > 0) {
            for (String filePath : attachmentPath) {
                MimeBodyPart attachPart = new MimeBodyPart();
 
                try {
                    attachPart.attachFile(filePath);
                    multipart.addBodyPart(attachPart);
                   
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
 
                //multipart.addBodyPart(attachPart);
                System.out.println("File attached");
            }
        }
    
       
        // sets the multi-part as e-mail's content
        msg.setContent(multipart); 
        // sends the e-mail
        Transport.send(msg);
        
  //      Log.info("==== Mail Sent Successfully ====");
	
           } catch (Exception ex) {
        	   ex.printStackTrace();
     //   	   Log.info("==== Mail not sent - Please check mail configurations ====");
           }
 
    }		
	
	public static void main(String[] args) {
		SendMail mail = new SendMail();
		try {
		//	mail.sendMail(Config.smtphost,Config.smtpport, Config.frommailid, Config.sendmailto, Config.subject, Config.messageBody, Config.attachmentPath, Config.attachmentName);
			mail.sendEmailWithAttachments(Config.smtphost,Config.smtpport, Config.frommailid, Config.mailpassword, Config.sendmailto, Config.mailCCArr, Config.mailBCCArr, Config.subject, Config.messageBody, Config.attachmentPath);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

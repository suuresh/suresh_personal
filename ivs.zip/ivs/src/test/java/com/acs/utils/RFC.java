package com.acs.utils;
/*
 * Copyright �.
 */

import java.io.*;
import java.net.URLDecoder;
import java.util.zip.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.acs.testcases.MPISimulatorAuthenticationFlowTest;

/**
 * @author Administrator
 */
public class RFC {
	static {
		try {
			System.out.println("RFC");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String compressAndEncode(String inputString) throws Exception {
		byte[] compressedData;
		char[] arr;
		try {
			compressedData = compress(inputString);
			arr = Base64.encode(compressedData);
		} catch (Exception e) {
			System.out.println("Error: " + e);
			e.printStackTrace();
			throw e;
		}
		return new String(arr);
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	public static byte[] compress(String inputString) throws Exception {
		String compressedString = "";
		byte[] input = inputString.getBytes();
		int inputLength = input.length;
		// Create the compressor with highest level of compression
		Deflater compressor = new Deflater();
		compressor.setLevel(Deflater.BEST_COMPRESSION);

		// Give the compressor the data to compress
		compressor.setInput(input);
		compressor.finish();

		ByteArrayOutputStream bos = new ByteArrayOutputStream(input.length);
		// Compress the data
		byte[] buf = new byte[1024 * 4];
		int dec_count = 0;
		while (!compressor.finished()) {
			try {
				int count = compressor.deflate(buf);
				bos.write(buf, 0, count);
				dec_count++;
			} catch (Exception e) {
				System.out.println("Error: " + e);
				e.printStackTrace();
				throw new Exception("Unable to deflate");
			}
			if (dec_count >= 15) {
				throw new Exception("Unable to deflate even after 15 try! data was : " + inputString);
			}
		}
		try {
			bos.close();
		} catch (IOException e) {
			System.out.println("Error: " + e);
			e.printStackTrace();
			throw new Exception("Unable to close ByteArrayOutputStream during compressing");
		}

		// Get the compressed data
		byte[] compressedData = bos.toByteArray();
		char[] arr = Base64.encode(compressedData);
		compressedString = new String(arr);
		return compressedData;
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	public static String decodeAndDecompress(String str) throws Exception {
		byte[] decodedString;
		byte[] decompressedString;

		try {
			decodedString = Base64.decode(str.toCharArray());
			decompressedString = decompress(decodedString);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return new String(decompressedString);

	}

	////////////////////////////////////////////////////////////////////////////////////////////
	public static byte[] decompress(byte[] compressedData) throws Exception {
		// Create the decompressor and give it the data to compress
		// byte[] compressedData = str.getBytes();
		Inflater decompressor = new Inflater();
		decompressor.setInput(compressedData);

		// Create an expandable byte array to hold the decompressed data
		ByteArrayOutputStream bos = new ByteArrayOutputStream(compressedData.length);

		try {

			// Decompress the data
			byte[] buf = new byte[1024 * 4];
			int dec_count = 0;
			while (!decompressor.finished()) {
				try {
					dec_count++;
					int count = decompressor.inflate(buf);
					bos.write(buf, 0, count);
				} catch (DataFormatException e) {
					System.out.println("Unable to inflate.");
					throw new Exception("Unable to inflate");
				}
				if (dec_count >= 15) {
					throw new Exception(
							"Unable to inflate even after 15 try! data was : " + new String(compressedData));
				}
			}
		} finally {
			try {
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new Exception("Unable to close ByteArrayOutputStream during decompressing");
			}
		}
		// Get the decompressed data
		byte[] decompressedData = bos.toByteArray();
		return decompressedData;

	}

	public RFC() {
	}

	public static void main(String[] args) throws UnsupportedEncodingException {

		String acsTxnId = null;
	
		String pareqExample = "<ThreeDSecure><Message id=\"43549531\"><PAReq><version>1.0.2</version><Merchant><acqBIN>111111</acqBIN><merID>Flip</merID><name>eBay.co.in</name><country>840</country><url>https://www.merchant.com</url></Merchant><Purchase><xid>MjAxOTA5MTMxMTU0Mjcya0Mwa0U=</xid><date>20030225 17:59:13</date><amount>Rs. 6000.00</amount><purchAmount>600000</purchAmount><currency>840</currency><exponent>2</exponent></Purchase><CH><acctID>202001221739179947uY5eM4eE</acctID><expiry>2005</expiry></CH></PAReq></Message></ThreeDSecure>";
		// String testEncodedPaReq
		// ="eNrVWNmyozi2/ZWM6kd3FrNtKpwnQsxgM8+8YcCYwYCZ4esvPq7MysiuG9F9n/ryglhIW1vS2mtLOln3NkkYM4mGNvk4yUnXhWnyJYu//YZjBE4SGPLbx0kDRtJ9gp+lDRmTtsvq6gP5Hf4dPUHfPzcDbXQPq/7jFEZPSlQ+kM/nBP35eXokrch8ICig/hnFEIZ/ZbkvX9N/EpDwdX84Qe/fJ+gvO9rwKnWbc3MWf8DrrYwRN2OKpTszTuetlxCbgEBN7LcT9KpxisM++UBhGINRlPiCHP4gyD8Q7AR94qfmZQ486mGzjcDwCfoZOG2z0CZVtHxgxP4E/fg6JXNTV8lWYxvrj/IJ+su3Jqw+4J8eAkeOm+0NPVnex6nPHi+fNq8Q9PAFQf8g8D/gbVY+8VPXh/3Qffgn6M/SKQrH8QMAQNESZySGCDtVigQlR4D3s431s8opibIP+OXU9v5sBcq0brP+/vjA3nX+Ak7QyxXocwk/TmaWVltnbfJlfpRV9+23e983f0DQNE2/T9jvdZtCm7swBJPQViHusvQfv71bJbFY3er/qBkdVnWVRWGZrWG/EUVO+nsdf/nh29+ZsYyXJQQyWPrrZuprhODV1xcCYwix2YT+3uhPI/t3evnV2bYLv3b38MV66BdDHycjuSUvRiRfbEP89ts/vkcDk6VJ1/9fuvve1c8WvttzwnJIPhbFmgZ+KAilfO7O9zhpr4HGe4/Btr99b/eueYJ++Pen8++V+mlG3hUjgQubJEw5cOQt64mFkREJ4+2QUB5Z7S6yaO6WlhqXZBc9xWMWX47quSD0CaULt5lvNz9CHdeL8WAQNdq633Dc5LHxEWp7SS+Z6yTgyO5oSFpvmsddwc3X9Z5z1u2J3J7jBEWjAa9H0bBRMxqnlp3x0auiAo6dsdCbp+n4+k5ojg7OkvfYIMM2VM/qtVEFFInkJmz3jfu8yHcaWTB9IDgf3lcZhuxtYkAKzVzN9oHqXnnxQYTAEXmRbcze37gQb1TJn92BI64YQHFEBMQyeAxjj8qVHxqnr/xIVbKHr0tso+F7x7X8XaUhBXHW4fR8aW91afK+cRtSD1VvPe03GFozOIs2pImKN/3bt58Y8+eKnJPlvQIeAZNM2IfvEp20fXbbqLspkiyKjLnSNMjVFEwiBVLRAWoDZlb2G1sqyyav58sYOnrK9KLBygDmafPJm+IVY3SWoicbyHw6MytQqFRxKCBbVElJDkcyusU6MiXzALFZepZlp5Bch3fWmFOQ0DNKWYcnevIZR9fP7GS4pqNQsn6cGP0TE9gpYAOXQANPnFkLaG/7qUWzynjlycV3jVHWu4l+1+fZSXLsFSTcBM+qBXA592c5twk5p8INW+RPzP6ByZw/0yuQ3nZ9CxSlKuv4xIC3TwxwsNCV+uvKKjLo3uOYppdPVbCytUz7nxiYplv8KFffRPCrO/URWlbXRzkEy9YnwxK651Sxp8AXz7nHzDbXpvgao3SuA/E+RgrY5pHSAZOmrAZe//Wa3soUOO/o5DjntOeHB4WQSxAkR/zsmtCAsf6Mq5huKftqB67NUeJTWAKiRVrNsLtcA7UhAyHQRES6QqFFOcBGU8tKK4GS0QMrHhrhGiMGTAkIKjQiHzRyW3R5cUCejj4Cpn1qHZ4ystcEC28ULSxVB8s5Ygenkfphf/NybRx3bvzsuNFaDkivEuOue9omW+NnKmhsco2X+GnLeKlJCRce9BqkGs2XHruW+BY9Ny2u1wu+3mlcJc3wkR09atdUKII+EWW1W/OYheUNNqjEkPmDRvdEOh959QL13NFVnkK+ZIIEu1RIS0UbE83F9I+e1lepjRZ8HZMLbo9OW+JdNz8xCx52e8nj4KJNXZkGEwuA9eJr8bwXGU9OMAX0jgNA3eaeBVIrGpEBrU+7IPdrVoExdjlWQm9gwoLdUQC9TpseX8CrJsxX80Y5KXnuEbHYVd0httyIbnJKldo9S5J3UWdsNKSWxjkSMCqHeODEB9xHtCh3lTN9b3FhuYvB0sP4mTAb05wriuqdNbme+fwxN+PxUiBDkYxIdyitQcIFbDxbTj6AW6S6j4MAorxAjmVekedLYg/F/mFDw2MnBZ4irdqaXnX0ASSbNdIIb9ZnSZEOtWYZzN7HBmPhZRB4sDZQnISHMHenTlv9czg2kHy4P7L9FZsxfk9DeuMQ17PrEk8o9GIfb7TwHms3jpz9nFjlQyqqae45h0XgvZmCNcK6MXhEytrlulwzFp2ml0D9qj5/J0csb20hMPHf5cgAFz8iPUI/9OZs7TN+xz6yh2P/GkKXLYSm0GIvMig+w5K6y7TjyDNjgcs7xGuL4oImQtn5soL+jXWWVH5iqekScOBJg+8ZzRUl7leasrZvNHSVUmS5NULJPHQ5OHTJQTbqiX/LBMPOnBt6yl3knfyKIv3WJg9MytCttxQpOSBkq9ikQF4VJv6UImUFs2yxk8LI+Av775LQ/0Si2jiAdDufcGYtDgVHVFZwUP3no0AOWIpfxxQ3ductJa/9Gk32oGj7uu12QRehkMkZtwmVb/KEqJOGKnJ1v5P1MabuzkGqE9Z2InLKFdgV9syufwLhmsNm+FTvzzt1HKAyLE1yFq7NuBQQS6x8zlvqVOdgFr2mSI6DuUetgRDOZ4qfx3sASRYYbjE1XrBsZ8vPW6FYs+ezZ3COYSHbC0I7qkX5nNjjjunEBl+DtvEZyBhiBm91gZ88U4fDI6XM+ro8ajevM7WTHdE/p8hY6mIwkXirkE517Y0ajpG27KIGsPVeKbSYQn3+wbhicJim677jmIPO1bwUW0cvKygh6pm9tsl7XGFN370lKlSpkaGpwQLma90EQ6bA7cjSDOCBLkAgZYEs6C9uxCIwepnvplD3uQBnmW29NlaAnErTlkpZjtIjGhi+FwoGHDH1NgUxFi8E+uLt5bFxwSSnEC0mVffF8+Rva20LW+xNFwv43J0zA4/q/FcccEYdenK6cRCPGcBsPlD8//5f/fRbP376vfF6440/CS+uGbBKUT7LyXWaFCAPOCoSU7AUN9OEpG2oEtX+3VYD4Jsm6HTbMRlAo53bPhBrx1oErMQ8iTIFw2fFGcm69UlPuoD7yUjE+QQ71Hgg6dhc+la20zsUwQnkr8ijYZBVFRUtyZyaMKsSofJlKGR9z9Zo6RlYyqFCTa+a39UKWnu9OfHRMZOB3ReiIW5nIvR4wcRH7QiHSIuszDXubXsE9SDa067k0qZbao+wBaGBZeux4uzg7ZWObnYLYCTJx9qO2HZe1lLKvm5gUrffMq91SBd1Em5oP2aXc9UjtCkIy46g9wt+DFX2JtWPgwXUFC/zsigMTj0zrm1HJSJRhdAns32pIS9AHBH3jEtyRqNzEO7v3sGR5kKh4Atlt5CK49lh3PGBm1oy3xzPOTv/m/LM5Vv4j/vv8qwn/YCY8txUrAKqSl0Rbaf1/5JdbQ4wVPOvUvPTzuous85rF2Wxo0zD3yXv8YmZlHStjDJ6EPeYL8frg+tETimjKmh81E51T1mvqNK8pRuf+Rz436WUdd7yHrgbzV1ks/GiKUfJFO4xFrtuO7RtRwhWeY1g1ak3TP4V+y9LK/+BPCuFfSvPj6Yi0N4XsaCnFM3VfLzDz1IFCY4bcczOdLJQtSn3fuSTJR6uClTTEy/2xe08j2bGGMbDvNG2KFFP2C1ZHRsicLlC1E5UW2PS06x7YlcFFoMLiOBVEJvF9YZHWBfdoQuNkelCdGqvK8T2yLOQ4RyqBWhU2y3tnQVSIolnQT/xLW10bLQQ1Xm6MUXDobe6CHrYPp+5fnaEyGQ1k0VWRUE2Fs+m0hzGxlvm8WJ2NOTF7ZE/WHSKXpFl9lwubzUYGTaaspV0tqpAxGnUTu7TnG9qSt/MzoIAP87M/eZqbcv2YG/REUO227aZaSZPyUyJ19Yism33JvD27KVk4qeZxdYkikc/5HmwaKrP32n1uzxT1iaLmzz/v5dmaj4KSxjrwC1xaqAwm5nJdeWUQlx/lebNp+/SnCA8etc6AHZGrdRw5FTIzkqio+nHOgW4w5OuLiSX3MMBPyTY/ubwSraqxbIdXYDA1+3eQC5ieD97O3b/eOqW362VZBJ3TzryxwjW4MecO2Z0PSzFpBMT5T89V0av3rnJLlbiO+4NAS3nPhtkIfm9AQM1rC75Y1IMCrTpMu5LRA+uB1vGqBtpEiU8tJx8gTeiHKkDWZYJ4WGoOJL5bYiGfRSKLXXZDvbz3n/unlvy7fCjYpiqsoO054MU5gkRMGhZ0eeFx1dLPMySw7BmwLNeGF8mWvKYvWokHspBVG/HxyeKxbkXXB0/E28smVxbPMUQAqVKhxYClF+0OL+LwyURUMS5WlC8sIIA/kaaob/O9NCPc/5fNwCfl5ift6mvi7efb1n/BxHTC7w=";

		String testEncoded = "eNpVUtluwjAQ%2FBUkJHiLj5AQ6GIJCgUqERDl6FtlOVaJyIUTjvx97UBKK1nyzs5qvDtr2ByUlOMPKc5KMljIPOffshEGg%2FZQiDTn1mq4lifLPi68y5AQp%2Bd03Z7rkZ7rthlUJIOLVHmYJoxY2KKAaqjllDjwpGDAxWk091nH7XqeC%2BgBIZZqPmZvMpCKR18xDxNA9xwkPJZsUa7SNDLZCoJIz0mhSmY7WqQGcFYROxRFlvcRul6vVlyKNM54Ulr6RoAMD%2BjZzOpsolzr3cKAbXaj9%2F0kmvizbOvbO385jaa%2BHX0u99sBIFMBAS8ko5hi3KVug9h9SvQBVOWBx6YR1mp69KXV1B69NIiDMbYw1pPeScjMm8M7qFhD%2Fk2C3oCSiaiHqxHIW5YmUldoZ39jQM8hXmfGX1Fo1%2BoeiecQSnrEdk7bTrynx7XxvCoxeqF2jVJyFzQAkBFBj3WixzfQ0b%2Fv8QP4xLRe&MD=V0VCX2RNeDBJVHJ6ZlNuN2l2NUE5eGd3RlE9PXxGZWRlcmFsX2FjczJzdGc%3D";

		String tesdDecode = URLDecoder.decode(testEncoded, "UTF-8");
		// System.out.println("tesdDecode:-" + tesdDecode);
		String arr[] = tesdDecode.split("&");
		String testEncodedPaReq = arr[0];
		// System.out.println("Pareq1" + testEncodedPaReq);

		String compresedD = "";
		try {
			String compressedData = RFC.compressAndEncode(pareqExample);
			//System.out.println("compressedDate:" + compressedData);
			byte[] ip = compressedData.getBytes();
			String retVal = RFC.decodeAndDecompress(compressedData);
			// System.out.println("Retval:" + retVal);

			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			// System.out.println("testDecodedPareq:" + testDecodedPareq);

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.parse(new InputSource(new StringReader(testDecodedPareq)));
			Element rootElement = document.getDocumentElement();
			// String acsTxnId = rootElement.getAttribute("acctID");

			acsTxnId = rootElement.getElementsByTagName("acctID").item(0).getTextContent();
			// System.out.println("acsTxnId:-"+acsTxnId);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}}

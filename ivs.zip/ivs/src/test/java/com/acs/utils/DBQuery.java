package com.acs.utils;

import com.uam.testcases.ACSMDDReport;

public class DBQuery {

	public static String cDay = null;
	public static String cMonth = null;
	public static String nMonth = null;
	public static String cYear = null;
	public static String cHour = null;
	public static String cMinutes = null;
	public static String cSeconds = null;

	public static String utcDay = null;
	public static String utcMonth = null;
	public static String utcYear = null;
	public static String utcHour = null;
	public static String utcMinutes = null;
	public static String ucSeconds = null;

	/*
	 * public static void main(String[] args) { SimpleDateFormat FORMATTER = new
	 * SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss"); Date currentDate = new Date();
	 * String dateAndTime = FORMATTER.format(currentDate); TimeZone utcTimeZone =
	 * TimeZone.getTimeZone("UTC"); FORMATTER.setTimeZone(utcTimeZone); String
	 * utcTime = FORMATTER.format(currentDate);
	 * 
	 * System.out.println("dateAndTime:-" + dateAndTime); String[] dateTime =
	 * dateAndTime.split("/"); cYear = dateTime[0]; cMonth = dateTime[1]; cDay =
	 * dateTime[2]; cHour = dateTime[3]; cMinutes = dateTime[4]; cSeconds =
	 * dateTime[5];
	 * 
	 * // UTC time Zone System.out.println("utcTime: " + utcTime); String[]
	 * utcDateTime = utcTime.split("/"); utcYear = utcDateTime[0]; utcMonth =
	 * utcDateTime[1]; utcDay = utcDateTime[2]; utcHour = utcDateTime[3]; utcMinutes
	 * = utcDateTime[4]; ucSeconds = utcDateTime[5];
	 * 
	 * LocalDateTime now = LocalDateTime.now(); nMonth = String.format("%02d",
	 * now.getMonthValue()); System.out.println("nMonth:-" + nMonth); }
	 */

	// Query for 1.0 protocol
	public static String NoOfVreq(String schema) {

		String vreqQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + utcYear + "" + nMonth
				+ " where request_date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2'";
		return vreqQuery;
	}

	public static String NoOfVres_Y(String schema) {

		String vresYQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='Y' and acs_version='1.0.2'";
		return vresYQuery;
	}

	public static String NoOfVres_N(String schema) {

		String vresNQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='N' and acs_version='1.0.2'";
		return vresNQuery;
	}

	public static String NoOfVres_U(String schema) {

		String vresUQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='U' and acs_version='1.0.2'";
		return vresUQuery;

	}

	public static String NoOfPAReq(String schema) {

		String PAReqQuery = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and error_code!='AC0408' and acs_version='1.0.2'";
		return PAReqQuery;
	}

	public static String NoofSuccessPARes(String schema) {

		String SuccessPARes = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2'";
		return SuccessPARes;
	}

	public static String PAReswithvalidAuthentication_Y(String schema) {

		String PAReswithvalidAuthentication_Y = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='Y' and acs_version='1.0.2'";
		return PAReswithvalidAuthentication_Y;
	}

	public static String PAReswithInvalidAuthentication_N(String schema) {

		String PAReswithInvalidAuthentication_N = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and acs_version='1.0.2'";
		return PAReswithInvalidAuthentication_N;
	}

	public static String TotalNoofAttemptedPARes_A(String schema) {

		String TotalNoofAttemptedPARes_A = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='A' and acs_version='1.0.2'";
		return TotalNoofAttemptedPARes_A;
	}

	public static String NoofUnauthenticatedPARes_Failed_U(String schema) {

		String NoofUnauthenticatedPARes_Failed_U = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='U' and acs_version='1.0.2'";
		return NoofUnauthenticatedPARes_Failed_U;
	}

	// Query for 2.0 protocol
	public static String NoofAreq(String schema) {

		String NoofAreq = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' ";
		return NoofAreq;
	}

	public static String NoofARes_Y(String schema) {

		String NoofARes_Y = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='y' ";
		return NoofARes_Y;
	}

	public static String NoofARes_N(String schema) {

		String NoofARes_N = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='N' ";
		return NoofARes_N;
	}

	public static String NoofARes_U(String schema) {

		String NoofARes_U = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='U' ";
		return NoofARes_U;
	}

	public static String NoofARes_R(String schema) {

		String NoofARes_R = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='R' ";
		return NoofARes_R;
	}

	public static String NoofARes_C(String schema) {

		String NoofARes_C = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='C' ";
		return NoofARes_C;
	}

	public static String NoofCreq(String schema) {

		String NoofCreq = "SELECT count(*) FROM " + schema + ".creq_cres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' ";
		return NoofCreq;
	}

	public static String NoofCRes_Y(String schema) {

		String NoofCRes_Y = "SELECT count(*) FROM " + schema + ".creq_cres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='Y' ";
		return NoofCRes_Y;
	}

	public static String NoofCRes_N(String schema) {

		String NoofCRes_N = "SELECT count(*) FROM " + schema + ".creq_cres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='N' ";
		return NoofCRes_N;
	}

	public static String NoofRreq(String schema) {

		String NoofRreq = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and message_version='2.1.0' ";
		return NoofRreq;
	}

	public static String NoofRres_Y(String schema) {

		String NoofRres_Y = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='Y' and message_version='2.1.0'";
		return NoofRres_Y;
	}

	public static String NoofRres_N(String schema) {

		String NoofRres_N = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and trans_status='N' and message_version='2.1.0' ";
		return NoofRres_N;
	}

	// DB Query for Amount Summary 1.0:

	public static String TotalAmount(String schema, String CountryCode)

	{
		String totalAmountINR = "SELECT sum(txn_amount) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and purchase_currency=" + CountryCode
				+ " and acs_version='1.0.2'";
		return totalAmountINR;
	}

	public static String PARes_Y(String schema, String CountryCode)

	{
		String PARes_Y = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='Y' and purchase_currency=" + CountryCode
				+ " and acs_version='1.0.2'";
		return PARes_Y;
	}

	public static String Pares_A(String schema, String CountryCode) {

		String Pares_A = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='A' and purchase_currency=" + CountryCode
				+ " and acs_version='1.0.2'";
		return Pares_A;
	}

	public static String Pares_N(String schema, String CountryCode)

	{
		String Pares_N = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and purchase_currency=" + CountryCode
				+ " and acs_version='1.0.2'";
		return Pares_N;
	}

	public static String Pares_U(String schema, String CountryCode) {

		String Pares_U = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and txn_status='U' and purchase_currency=" + CountryCode
				+ " and acs_version='1.0.2'";
		return Pares_U;
	}

	// DB Query for Amount Summary 2.0:

	public static String TotalAmount_2_0(String schema, String CountryCode)

	{
		String TotalAmount_2_0 = "SELECT sum(amount) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0'";
		return TotalAmount_2_0;
	}

	public static String Ares_Y(String schema, String CountryCode)

	{
		String Ares_Y = "SELECT sum(countAresY) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0' ";
		return Ares_Y;
	}

	public static String Ares_N(String schema, String CountryCode) {

		String Ares_N = "SELECT sum(countAresN) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0' ";
		return Ares_N;
	}

	public static String Ares_U(String schema, String CountryCode)

	{
		String Ares_U = "SELECT sum(countAresU) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0' ";
		return Ares_U;
	}

	public static String Ares_R(String schema, String CountryCode) {

		String Ares_R = "SELECT sum(countAresR) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0' ";
		return Ares_R;
	}

	public static String Ares_C(String schema, String CountryCode) {

		String Ares_C = "SELECT sum(countAresC) FROM " + schema + ".areq_ares_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes + "' and currencyCode=" + CountryCode
				+ " and message_version='2.1.0' ";
		return Ares_C;
	}

	// MDD Report 2.0 query preparation
	public static String TotalAreqCount(String schema) {
		String mddTotalAreqCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes + "' and message_version='2.1.0';";
		System.out.println("mddTotalAreqCountQuery: " + mddTotalAreqCountQuery);

		return mddTotalAreqCountQuery;
	}

	public static String mddAresYCount(String schema) {
		String mddAresYCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='Y';";
		return mddAresYCountQuery;
	}

	public static String mddAresNCount(String schema) {
		String mddAresNCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='N';";
		return mddAresNCountQuery;
	}

	public static String mddAresCCount(String schema) {
		String mddAresCCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='C';";
		return mddAresCCountQuery;
	}

	public static String mddAresRCount(String schema) {
		String mddAresRCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='R';";
		return mddAresRCountQuery;
	}

	public static String mddAresUCount(String schema) {
		String mddAresUCountQuery = "SELECT count(*) FROM " + schema + ".areq_ares_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='U';";
		return mddAresUCountQuery;
	}

	// mdd report Creq count
	public static String mddTotalCreqCount(String schema) {
		String mddTotalCreqCountQuery = "SELECT count(*) FROM " + schema + ".creq_cres_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes + "' and message_version='2.1.0';";
		return mddTotalCreqCountQuery;
	}

	public static String mddTotalCresCount(String schema) {
		String mddTotalCresCountQuery = "SELECT count(*) FROM " + schema + ".creq_cres_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes + "' and message_version='2.1.0';";
		return mddTotalCresCountQuery;
	}

	// Mdd Rreq count
	public static String mddTotalRreqCount(String schema) {
		String mddTotalRreqCountQuery = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes + "' and message_version='2.1.0';";
		return mddTotalRreqCountQuery;
	}

	public static String mddTotalRresCount(String schema) {
		String mddTotalRresCountQuery = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + ACSMDDReport.cYear + ""
				+ ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth
				+ "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-" + ACSMDDReport.cDay + " "
				+ ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes + "' and message_version='2.1.0';";
		return mddTotalRresCountQuery;
	}

	public static String mddRreqWithStatusYCount(String schema) {
		String mddRreqWithStatusYCountQuery = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + ACSMDDReport.cYear
				+ "" + ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-"
				+ ACSMDDReport.nMonth + "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-"
				+ ACSMDDReport.cDay + " " + ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='Y';";
		return mddRreqWithStatusYCountQuery;
	}

	public static String mddRreqWithStatusNCount(String schema) {
		String mddRreqWithStatusNCountQuery = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + ACSMDDReport.cYear
				+ "" + ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-"
				+ ACSMDDReport.nMonth + "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-"
				+ ACSMDDReport.cDay + " " + ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='N';";
		return mddRreqWithStatusNCountQuery;
	}

	public static String mddRreqWithStatusUCount(String schema) {
		String mddRreqWithStatusUCountQuery = "SELECT count(*) FROM " + schema + ".rreq_rres_txn_" + ACSMDDReport.cYear
				+ "" + ACSMDDReport.nMonth + " WHERE date_time between '" + ACSMDDReport.cYear + "-"
				+ ACSMDDReport.nMonth + "-01 00:00' AND '" + ACSMDDReport.cYear + "-" + ACSMDDReport.nMonth + "-"
				+ ACSMDDReport.cDay + " " + ACSMDDReport.utcHour + ":" + ACSMDDReport.utcMinutes
				+ "' and message_version='2.1.0' AND trans_status='U';";
		return mddRreqWithStatusUCountQuery;
	}

	// Query for Bin wise report for 1.0 protocol

	public static String BinId_Bin(String schema, String bins) {

		String BinId = "SELECT bin_id FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return BinId;
	}

	public static String card_Union(String schema, String bins) {

		String cardUnion = "SELECT card_union FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return cardUnion;
	}

	public static String CardType(String schema, String bins) {

		String cardType = "SELECT card_type FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return cardType;
	}

	public static String NoOfVreq_Bin(String schema, String bins) {

		String vreqQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + utcYear + "" + nMonth
				+ " where request_date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return vreqQuery;
	}

	public static String NoOfVres_Y_Bin(String schema, String bins) {

		String vresYQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='Y' and acs_version='1.0.2' and issuer_bin='" + bins + "' ";
		return vresYQuery;
	}

	public static String NoOfVres_N_Bin(String schema, String bins) {

		String vresNQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='N' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return vresNQuery;
	}

	public static String NoOfVres_U_Bin(String schema, String bins) {

		String vresUQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='U' and acs_version='1.0.2'and issuer_bin='" + bins + "'";
		return vresUQuery;

	}

	public static String NoOfPAReq_Bin(String schema, String bins) {

		String PAReqQuery = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and error_code!='AC0408' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return PAReqQuery;
	}

	public static String NoofSuccessPARes_Bin(String schema, String bins) {

		String SuccessPARes = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return SuccessPARes;
	}

	public static String PAReswithvalidAuthentication_Y_Bin(String schema, String bins) {

		String PAReswithvalidAuthentication_Y = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='Y' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return PAReswithvalidAuthentication_Y;
	}

	public static String PAReswithInvalidAuthentication_N_Bin(String schema, String bins) {

		String PAReswithInvalidAuthentication_N = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return PAReswithInvalidAuthentication_N;
	}

	public static String TotalNoofAttemptedPARes_A_Bin(String schema, String bins) {

		String TotalNoofAttemptedPARes_A = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='A' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return TotalNoofAttemptedPARes_A;
	}

	public static String NoofUnauthenticatedPARes_Failed_U_Bin(String schema, String bins) {

		String NoofUnauthenticatedPARes_Failed_U = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='U' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return NoofUnauthenticatedPARes_Failed_U;
	}

	// Query for MIS Summary report for 1.0

	public static String NoOfVreq_Mis(String schema, String cardUnion, String cardType) {

		String vreqQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + utcYear + "" + nMonth
				+ " where request_date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return vreqQuery;
	}

	public static String NoOfVres_Mis(String schema, String cardUnion, String cardType) {

		String vresYQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and  acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return vresYQuery;
	}

	public static String NoOfVres_Y_Mis(String schema, String cardUnion, String cardType) {

		String vresYQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='Y' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return vresYQuery;
	}

	public static String NoOfVres_N_Mis(String schema, String cardUnion, String cardType) {

		String vresNQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='N' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return vresNQuery;
	}

	public static String NoOfVres_U_Mis(String schema, String cardUnion, String cardType) {

		String vresUQuery = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='U' and acs_version='1.0.2'and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return vresUQuery;

	}

	public static String NoOfPAReq_Mis(String schema, String cardUnion, String cardType) {

		String PAReqQuery = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and error_code!='AC0408' and acs_version='1.0.2' and card_union='" + cardUnion
				+ "' and card_type='" + cardType + "'";
		return PAReqQuery;
	}

	public static String NoofSuccessPARes_Mis(String schema, String cardUnion, String cardType) {

		String SuccessPARes = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return SuccessPARes;
	}

	public static String PAReswithvalidAuthentication_Y_Mis(String schema, String cardUnion, String cardType) {

		String PAReswithvalidAuthentication_Y = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='Y' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return PAReswithvalidAuthentication_Y;
	}

	public static String PAReswithInvalidAuthentication_N_Mis(String schema, String cardUnion, String cardType) {

		String PAReswithInvalidAuthentication_N = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return PAReswithInvalidAuthentication_N;
	}

	public static String TotalNoofAttemptedPARes_A_Mis(String schema, String cardUnion, String cardType) {

		String TotalNoofAttemptedPARes_A = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='A' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return TotalNoofAttemptedPARes_A;
	}

	public static String NoofUnauthenticatedPARes_Failed_U_Mis(String schema, String cardUnion, String cardType) {

		String NoofUnauthenticatedPARes_Failed_U = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='U' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return NoofUnauthenticatedPARes_Failed_U;
	}

	// Query for Bin wise report for 2.0 protocol

	public static String BinId_Bin_2_0(String schema, String bins) {

		String BinId_Bin_2_0 = "SELECT bin_id FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return BinId_Bin_2_0;
	}

	public static String card_Union_2_0(String schema, String bins) {

		String card_Union_2_0 = "SELECT card_union FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return card_Union_2_0;
	}

	public static String CardType_2_0(String schema, String bins) {

		String CardType_2_0 = "SELECT card_type FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='" + bins
				+ "' limit 1";
		return CardType_2_0;
	}

	public static String Areq_Bin_2_0(String schema, String bins) {

		String Areq_Bin_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + utcYear + "" + nMonth
				+ " where request_date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return Areq_Bin_2_0;
	}

	public static String Ares_Y_Bin_2_0(String schema, String bins) {

		String Ares_Y_Bin_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='Y' and acs_version='1.0.2' and issuer_bin='" + bins + "' ";
		return Ares_Y_Bin_2_0;
	}

	public static String Ares_N_Bin_2_0(String schema, String bins) {

		String Ares_N_Bin_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='N' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Ares_N_Bin_2_0;
	}

	public static String Ares_U_Bin_2_0(String schema, String bins) {

		String Ares_U_Bin_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='U' and acs_version='1.0.2'and issuer_bin='" + bins + "'";
		return Ares_U_Bin_2_0;

	}

	public static String Ares_R_Bin_2_0(String schema, String bins) {

		String Ares_R_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and error_code!='AC0408' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Ares_R_Bin_2_0;
	}

	public static String Ares_C_Bin_2_0(String schema, String bins) {

		String Ares_C_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return Ares_C_Bin_2_0;
	}

	public static String Creq_Bin_2_0(String schema, String bins) {

		String Creq_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return Creq_Bin_2_0;
	}

	public static String Cres_Y_Bin_2_0(String schema, String bins) {

		String Cres_Y_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='Y' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Cres_Y_Bin_2_0;
	}

	public static String Cres_N_Bin_2_0(String schema, String bins) {

		String Cres_N_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and acs_version='1.0.2' and issuer_bin='"
				+ bins + "'";
		return Cres_N_Bin_2_0;
	}

	public static String Rreq_Bin_2_0(String schema, String bins) {

		String Rreq_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='A' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Rreq_Bin_2_0;
	}

	public static String Rres_Y_Bin_2_0(String schema, String bins) {

		String Rres_Y_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='A' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Rres_Y_Bin_2_0;
	}

	public static String Rres_N_Bin_2_0(String schema, String bins) {

		String Rres_N_Bin_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='U' and acs_version='1.0.2' and issuer_bin='" + bins + "'";
		return Rres_N_Bin_2_0;
	}

	// Query for MIS Summary report for 2.0

	public static String Areq_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Areq_Mis_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + utcYear + "" + nMonth
				+ " where request_date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return Areq_Mis_2_0;
	}

	public static String Ares_Y_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Ares_Y_Mis_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "' and  acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return Ares_Y_Mis_2_0;
	}

	public static String Ares_N_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Ares_N_Mis_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='Y' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Ares_N_Mis_2_0;
	}

	public static String Ares_U_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Ares_U_Mis_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='N' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Ares_U_Mis_2_0;
	}

	public static String Ares_R_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Ares_R_Mis_2_0 = "SELECT count(*) FROM " + schema + ".vereq_veres_" + cYear + "" + nMonth
				+ " where request_date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-"
				+ nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "' and auth_Status='U' and acs_version='1.0.2'and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Ares_R_Mis_2_0;

	}

	public static String Ares_C_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Ares_C_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and error_code!='AC0408' and acs_version='1.0.2' and card_union='" + cardUnion
				+ "' and card_type='" + cardType + "'";
		return Ares_C_Mis_2_0;
	}

	public static String Creq_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Creq_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in ('AC0408','AC0407') AND txn_status in('Y','N') and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return Creq_Mis_2_0;
	}

	public static String Cres_Y_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Cres_Y_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='Y' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Cres_Y_Mis_2_0;
	}

	public static String Cres_N_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Cres_N_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "'and error_code not in('AC0408', 'AC0407') and txn_status='N' and acs_version='1.0.2' and card_union='"
				+ cardUnion + "' and card_type='" + cardType + "'";
		return Cres_N_Mis_2_0;
	}

	public static String Rreq_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Rres_N_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='U' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Rres_N_Mis_2_0;
	}

	public static String Rres_Y_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Rres_Y_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='A' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Rres_Y_Mis_2_0;
	}

	public static String Rres_N_Mis_2_0(String schema, String cardUnion, String cardType) {

		String Rres_N_Mis_2_0 = "SELECT count(*) FROM " + schema + ".acs_txn_" + cYear + "" + nMonth
				+ " where date_time between '" + cYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-"
				+ cDay + " " + utcHour + ":" + utcMinutes
				+ "' and txn_status='U' and acs_version='1.0.2' and card_union='" + cardUnion + "' and card_type='"
				+ cardType + "'";
		return Rres_N_Mis_2_0;
	}

}

package com.acs.utils;

import java.util.Base64;

public class Base64Utility {

	
   public static void main(String[] args) {

		String str = "{\"threeDSServerTransID\":\"972ab5c7-7b8b-11e9-b4b8-f130f58abc36\",\"acsTransID\":\"98dc36c1-7b8b-11e9-837f-71e6e224aa34\",\"messageType\":\"CReq\",\"messageVersion\":\"2.1.0\",\"challengeWindowSize\":\"04\"}";
		String ss = encode(str);
		System.out.println(" Base 64 encoded value: " + ss);

		System.out.println("Base 64 decode value :" + decode(ss));
	}
	 

	public static String encode(String str) {
		byte[] arr = Base64.getEncoder().encode(str.getBytes());
		return new String(arr);
	}

	public static String decode(String str) {
		byte[] arr = str.getBytes();
		byte[] str2 = Base64.getDecoder().decode(arr);
		return new String(str2);
	}
}

package com.acs.utils;

import java.util.Iterator;
import java.util.logging.Level;

import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;

import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.appium.android.AppiumInitialSetup;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class GetAndroidHeaders extends AppiumInitialSetup {
    
	public static AndroidDriver<AndroidElement> aDriver;
    
	public GetAndroidHeaders(AndroidDriver<AndroidElement> driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public String getACSTxnIDFromHeaders(LogEntries logs)
    {
    	
    	JSONObject response = null;
        ChromeDriver driver = null;
        String acsTxnId = null;

        try
        {
      /*      ChromeOptions options = new ChromeOptions();
            // add whatever extensions you need
            // for example I needed one of adding proxy, and one for blocking
            // images
            // options.addExtensions(new File(file, "proxy.zip"));
            // options.addExtensions(new File("extensions",
            // "Block-image_v1.1.crx"));

            DesiredCapabilities cap = DesiredCapabilities.chrome();
            cap.setCapability(ChromeOptions.CAPABILITY, options);

            // set performance logger
            // this sends Network.enable to chromedriver
            LoggingPreferences logPrefs = new LoggingPreferences();
            logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
            cap.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);

            driver = new ChromeDriver(cap);

            // navigate to the page
            System.out.println("Navigate to " + url);
            driver.navigate().to(url);

            // and capture the last recorded url (it may be a redirect, or the
            // original url)
            String currentURL = driver.getCurrentUrl();

            // then ask for all the performance logs from this request
            // one of them will contain the Network.responseReceived method
            // and we shall find the "last recorded url" response 
             * */
             
         //   LogEntries logs = driver.manage().logs().get("performance");

            int status = -1;
            
           
         //   System.out.println("\nList of log entries:\n");

            for (Iterator<LogEntry> it = logs.iterator(); it.hasNext();)
            {
                LogEntry entry = it.next();

                try
                { JSONObject json = new JSONObject(entry.getMessage());

            //    System.out.println(json.toString());

                JSONObject message = json.getJSONObject("message");
                String method = message.getString("method");

                if (method != null && "Network.responseReceived".equals(method))
                {
                    JSONObject params = message.getJSONObject("params");

                     response = params.getJSONObject("response");
                    String messageUrl = response.getString("url");
               //     System.out.println("mesageurl: "+messageUrl);

                    if ( messageUrl.contains("creq/live/9111?id="))
                    {
                    	System.out.println("mesageurl: "+messageUrl);
                        status = response.getInt("status");
                        String arr[] = messageUrl.split("=");
                        acsTxnId = arr[1];
                        

                        System.out.println(
                                "---------- bingo !!!!!!!!!!!!!! returned response for "
                                        + messageUrl + ": " + status);

                        System.out.println(
                                "---------- bingo !!!!!!!!!!!!!! headers: "
                                        + response.get("headers"));
                    }
                }
            } catch (JSONException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            System.out.println("\nstatus code: " + status);
            System.out.println(
                    "---------- bingo !!!!!!!!!!!!!! ACS Txn ID: "
                            + acsTxnId);
        } finally
        {
            if (driver != null)
            {
              //  driver.quit();
            }
        }
		return acsTxnId;
    }
	
	
	/*public static void main(String[] args) {
		
		String url = "https://3ds2-ui-acsdcs.pc.enstage-sas.com/v1/acs/services/browser/creq/live/9111?id=680c49ff-6040-11e9-b817-35f648c25e01";
		if(url.contains("live/9111")) {
			String arr[] = url.split("=");
			System.out.println("Acs txn id ="+arr[1]);
		}
	}*/
}
package com.acs.utils;

import java.io.ByteArrayInputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.ParseException;
import java.util.Base64;

import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEDecrypter;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;

public class JWTEncryption {

//    private static final Logger logger = LoggerFactory.getLogger(JWTEncryption.class);

    
    public static String encryptPayload(String rawInputData, String encodedCert) {
//    	logger.trace("Raw Input Data {}", rawInputData);
    	String encryptedPayloadData = null;
		try {
			encryptedPayloadData = jweEncryption(rawInputData, encodedCert);
//			logger.trace("Encrypted Payload Data {}", encryptedPayloadData);
		} catch (Exception e) {
//			logger.error("Exception while encrypting OTP Generation Payload - {}" , e.getMessage());
		}
		return encryptedPayloadData;
	}
    
    public static void main(String[] args) {
		String requestJson="{\n" +
                "    \"Account_Number\": \"5568565500814562\",\n" +
                "    \"API_Version\": \"1.0\",\n" +
                "    \"Name_On_Card\": \"Bharat\",\n" +
                "    \"Primary_PH_Country_Code\": \"91\",\n" +
                "    \"Primary_PH_NUMBER\": \"7204258879\",\n" +
                "    \"Primary_Email\": \"Johny@gmail.com\",\n" +
                "    \"Secondary_Email\":\"John@gmail.com\",\n" +
                "    \"Lang_Preference\": \"en_US\",\n" +
                "    \"Status\": \"1\",\n" +
                "    \"API_REF_ID\": \"23423SFDFDF423\",\n" +
                "    \"Action\": \"REG\",\n" +
                "    \"BankId\": \"9111\"\n" +
                "}";
		String updaterequest="{\n" +
                "    \"Account_Number\": \"5568565500814562\",\n" +
                "    \"API_Version\": \"1.0\",\n" +
                "    \"Name_On_Card\": \"Subhash\",\n" +
                "    \"Primary_PH_Country_Code\": \"91\",\n" +
                "    \"Primary_PH_NUMBER\": \"7204258879\",\n" +
                "    \"Primary_Email\": \"Johny@gmail.com\",\n" +
                "    \"Secondary_Email\":\"John@gmail.com\",\n" +
                "    \"Lang_Preference\": \"en_US\",\n" +
                "    \"Status\": \"1\",\n" +
                "    \"API_REF_ID\": \"23423SFDFDF423\",\n" +
                "    \"Action\": \"UPD\",\n" +
                "    \"BankId\": \"9111\"\n" +
                "}";
		jweEncryption(updaterequest, null);
	}
    public static String jweEncryption(String requestJson, String encodedCert) {
        JWEObject jweObject = new JWEObject(new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A128GCM).keyID("rsa1")
                .build(),
                new Payload(requestJson));

        // Encrypt with the recipient's public key
        PublicKey serverPublicKey = generateServerPublicKey(encodedCert);
        try {
            jweObject.encrypt(new RSAEncrypter((RSAPublicKey) serverPublicKey));
        } catch (Exception e) {
            // TODO Auto-generated catch block
//            logger.error("FAILED - jweEncryption-cause{}", e);
        }
        System.out.println(jweObject.serialize());
        return jweObject.serialize();
    }

    private static PublicKey generateServerPublicKey(String encodedCert) {
        PublicKey publicKey = null;
        encodedCert = "MIIDejCCAmKgAwIBAgIEYDdHtjANBgkqhkiG9w0BAQsFADB/MQswCQYDVQQGEwJJTjESMBAGA1UECAwJS2FybmF0YWthMRIwEAYDVQQHDAlCYW5nYWxvcmUxHjAcBgNVBAoMFWVuU3RhZ2VTb2Z0d2FyZVB2dEx0ZDEoMCYGA1UEAwwfY3VzdC1lbnJvbGwtdWF0LmVuc3RhZ2UtdWF0LmNvbTAeFw0yMTAyMjUwNjQ2MTRaFw0yMjAyMjUwNjQ2MTRaMH8xCzAJBgNVBAYTAklOMRIwEAYDVQQIDAlLYXJuYXRha2ExEjAQBgNVBAcMCUJhbmdhbG9yZTEeMBwGA1UECgwVZW5TdGFnZVNvZnR3YXJlUHZ0THRkMSgwJgYDVQQDDB9jdXN0LWVucm9sbC11YXQuZW5zdGFnZS11YXQuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqKxcVBvqkhO/H8iZ1RIc+k1IdfV7WMA2OX21TCtbm86L+X9yS22Sv0MjyGIQRbjVv/PwCdLoCG889K6UsJZBPl9v9IjhhZbA0YmJ8E384i9sxRwjftgcX/1wvNT4SPqNoQ+h6odi8Mm4GwMd48lZTmffBtPEj/2drGbvLYHVROCY4oHtqgt2J8HjVwjdNNVlSvgYp4WVe3NEda+IkrQxt8p0Rtvhj8cQpck8gwLq/z6yQ5UsGF+2e0nKi/ZJG09at5bRt+gIvUyj30E8gw3+tWxIy46HWQYT1z4vsnPw8JnxBHDu0eK1O4EF3AOB8Hpu4SpdPYXNP2auN7MrGZNTiQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAfVPyalYBw8wULDfP++jep88JRT6to4TXd2PiAksn84zhqzm/YkLTzdWyJBQHIkIt3f7OuMQbqgF0SWe2R3zVSvoEoPWcg6SQlP/Ar5NilzhCWPyqKhNMcONvC0+cgpFe0Vj5xZKMFuVxr1/xXj59WeFI9vysgM9uO8mmOSgUscF6JFdfj4S6YsGgV5Q2ezjprwvCi15AlylVROpOymagT4wfL/L7hwHIek2AtE9ZnbLChRg5xmmWv7GkvOJaJ0BkKShIoBT5Sm38hQUJ7rRrXTHG1+u70RPXQQ7dIXTX7f+qzk4K7MpGNZlIhB9yaJVRxdOGArSv0imZJSSodBam9";
        try {
            java.security.cert.Certificate certificate = convertStringToCertificate(encodedCert);
            publicKey = certificate.getPublicKey();
        } catch (Exception e) {
//            logger.error("FAILED - generateServerPublicKeyFromString-cause{}", e);
        }

        return publicKey;
    }

    public static Certificate convertStringToCertificate(String input) {
        Certificate certificate = null;
        byte[] cert = null;
        if (input != null && !"".equals(input.trim())) {
            try {
                input = input.replace("-----BEGIN CERTIFICATE-----", "");
                input = input.replace("-----END CERTIFICATE-----", "");
                cert = Base64.getDecoder().decode(input.getBytes());
                CertificateFactory certificateFactory = CertificateFactory.getInstance("X509");

                certificate = certificateFactory.generateCertificate(new ByteArrayInputStream(cert));
            } catch (Exception var4) {
//                logger.error("convertStringToCertificate-{},", var4.getMessage(), var4);
            }
        }

        return certificate;
    }
    
    public String jweDecryption(String encryptedRequest) throws ParseException, 
    							JOSEException, InvalidKeySpecException, NoSuchAlgorithmException {
    	KeyFactory kf = KeyFactory.getInstance("RSA");
    	PrivateKey privateKey = null;
    	Payload payload = null;
//    	if (hsmClientSync != null) {
//    		logger.trace("Private Key Mode {}", cryptoCert.getPrivateKeyMode());
//    		if(null != cryptoCert && cryptoCert.getPrivateKeyMode() == PrivateKeyMode.ENCRYPTED) {
    			JWEObject jweObject = JWEObject.parse(encryptedRequest);
    			String encodedPrivateKey = generatePrivateKey();
//    			logger.trace("Private key to decrypt the request payload {}", encodedPrivateKey);
    			byte[] encodedPv = Base64.getDecoder().decode(encodedPrivateKey.getBytes());
    			PKCS8EncodedKeySpec keySpecPv = new PKCS8EncodedKeySpec(encodedPv);
    			privateKey = kf.generatePrivate(keySpecPv);
    			JWEDecrypter jweDecrypter = new RSADecrypter(privateKey);
    			
    			jweObject.decrypt(jweDecrypter);
    			payload = jweObject.getPayload();
//    			logger.trace("Decrypted Payload {}", payload);
//    		}
//    	}
//    	else {
//    		logger.error("HSM is null");
//    	}
    	return payload.toString();
    }
    
    private String generatePrivateKey()  {
    	String decryptedPrivateKey = null;
//    	decryptedPrivateKey = hsmClientSync.decrypt(cryptoCert.getPrivateKey());
    	decryptedPrivateKey = decryptedPrivateKey.replace("-----BEGIN PRIVATE KEY-----", "");
    	decryptedPrivateKey = decryptedPrivateKey.replace("-----END PRIVATE KEY-----", "");
    	decryptedPrivateKey = decryptedPrivateKey.trim().replaceAll("\r\n", "");
    	return decryptedPrivateKey;
    }

}

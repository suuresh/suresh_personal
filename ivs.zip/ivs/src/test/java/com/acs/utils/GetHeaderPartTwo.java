package com.acs.utils;

import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.support.PageFactory;

import com.acs.testcases.ACSInitialSetUp;

public class GetHeaderPartTwo extends ACSInitialSetUp {

	public WebDriver driver;

	public GetHeaderPartTwo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getACSTxnIDFromHeaders(String currentURL, String IssuerBankId, LogEntries logs) {
		JSONObject response = null;
		ChromeDriver driver = null;
		String acsTxnId = null;
		String paReq = null;
		String postData = null;
		int t = 6;

		try {
			// LogEntries logs = driver.manage().logs().get("performance");

			int status = -1;
			int count = 0;

			for (Iterator<LogEntry> it = logs.iterator(); it.hasNext();) {
				LogEntry entry = it.next();
				count++;
				//System.out.println("Total count:-" + count);
				try {
					JSONObject json = new JSONObject(entry.getMessage());

					// System.out.println(json.toString());

					JSONObject message = json.getJSONObject("message");
					//System.out.println("params:-" + message.get("params"));

					JSONObject params = message.getJSONObject("params");
					//System.out.println("params::"+params);
					
					if(!params.isEmpty() ) {
						//System.out.println("request123" + params.get("request"));
						//if ((message.get("params").toString()).contains("request")) {
						if(params.has("request")) {
							JSONObject request = params.getJSONObject("request");
							//System.out.println("57"+request.toString());
							// paReq=request.getString("postData").toString();
							// System.out.println("paReq:-"+paReq);
							// System.out.println("postData123:-"+request.getString("postData"));

							// System.out.println("Helloooeoeo:-" + request.getString("postData"));
							if(request.has("postData")) {
								String data = request.getString("postData").toString();
								if (data.contains("PaReq")) {
									postData = request.getString("postData").toString();
									// System.out.println("paReq12345:-" + postData);
									paReq = postData.substring(postData.indexOf("PaReq") + t);
								}
							}
						}
					}
					

					// System.out.println("FinallyDone123:-" + paReq);
					String method = message.getString("method");
					if (method != null && "Network.responseReceived".equals(method)) {
						JSONObject params1 = message.getJSONObject("params");

						response = params1.getJSONObject("response");
						String messageUrl = response.getString("url");
						// System.out.println("mesageurl: " + messageUrl);

						if (messageUrl.contains("creq/L/" + IssuerBankId + "/")) {
							// System.out.println("mesageurl: " + messageUrl);
							status = response.getInt("status");
							String arr[] = messageUrl.split(IssuerBankId + "/");
							acsTxnId = arr[1];

							/*
							 * System.out.println( "---------- bingo !!!!!!!!!!!!!! returned response for "
							 * + messageUrl + ": " + status);
							 * 
							 * System.out.println( "---------- bingo !!!!!!!!!!!!!! headers: " +
							 * response.get("headers"));
							 */
						}
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				/*
				 * if(count==20) { System.out.println("break-----"); break; }
				 */
			}

			// System.out.println("\nstatus code: " + status);
			// System.out.println("---------- bingo !!!!!!!!!!!!!! ACS Txn ID: " +
			// acsTxnId);
		} finally {
			if (driver != null) {
				// driver.quit();
			}
		}
		return paReq;
	}

	/*
	 * public static void main(String[] args) {
	 * 
	 * String url =
	 * "https://3ds2-ui-acsdcs.pc.enstage-sas.com/v1/acs/services/browser/creq/live/9111?id=680c49ff-6040-11e9-b817-35f648c25e01";
	 * if(url.contains("live/9111")) { String arr[] = url.split("=");
	 * System.out.println("Acs txn id ="+arr[1]); } }
	 */
}
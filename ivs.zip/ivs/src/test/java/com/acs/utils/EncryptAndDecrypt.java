package com.acs.utils;

import com.acs.libraries.Config;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class EncryptAndDecrypt {

	public static String EncryptnDecryptData(String CardNumber, String encryptOrDecrypt, String IssuerBankId) {

		RestAssured.baseURI = Config.BASE_ENCRYPTION_URI;
		String body = "{\r\n" + "	\"card_number\":\"" + CardNumber + "\",\r\n" + "	\"bank_id\": \""
				+ IssuerBankId + "\",\r\n" + "	\"endData\": \"" + encryptOrDecrypt + "\"\r\n" + "}";

		RequestSpecification request = RestAssured.given().log().all()
				.config(RestAssured.config().encoderConfig(
						EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
				.contentType("application/x-www-form-urlencoded; charset=UTF-8").body(body).request();

		Response response = request.post("/hsm/encryptcard");
		String resposeBody = response.body().asString();
		Gson g = new Gson();
		JsonObject obj = g.fromJson(resposeBody, JsonObject.class);
		String EncryorDecryptalue = obj.get("Result ").getAsString();
		System.out.println("Response Body :" + resposeBody);
		System.out.println(">>>> : " + EncryorDecryptalue);

		return EncryorDecryptalue;

	}

/*	public static void main(String[] args) {
		EncryptAndDecrypt enddata = new EncryptAndDecrypt();
		enddata.EncryptnDecryptData("4568560000011724", "N");
	}*/

}

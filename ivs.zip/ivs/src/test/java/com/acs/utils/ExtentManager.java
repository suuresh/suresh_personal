package com.acs.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;

//OB: ExtentReports extent instance created here. That instance can be reachable by getReporter() method.
 
public class ExtentManager {
	
    private static ExtentReports extent;
 
    public synchronized static ExtentReports getReporter(){
    	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");  
        Date date = new Date();  
        String currentdate = formatter.format(date);
        if(extent == null){
            //Set HTML reporting file location
            String workingDir = System.getProperty("user.dir");
            extent = new ExtentReports(workingDir+"/ExtentReports/ExtentReport-"+currentdate+".html", true);
        }
        return extent;
    }
}

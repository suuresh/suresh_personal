package com.acs.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.acs.libraries.Config;

public class DBConnection {

	public static String getValueFromDB(String queryString) {
		String dbValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				dbValue = rs.getString(1);
				System.out.println("dbValue:" + dbValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbValue;

	}

	public static String getValueFromDataBase(String query1, String queryString) {
		String dbValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is query1:" + query1);
			System.out.println("Statement Created is query2:" + queryString);

			stmt.executeQuery(query1);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				dbValue = rs.getString(1);
				System.out.println("dbValue:" + dbValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbValue;
	}

}

package com.acs.utils;

import java.util.HashMap;
import java.util.Map;

import com.acs.libraries.Config;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OTPFromDynamicConfig {

	public static String getOTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		String maxResendCount = null;
		String maxAttemptsCount = null;
		String maxFailureCount = null;
		String expiryMin = null;
		String uniquePerChannel = null;
		String forceNew = null;
		String otpCategory = null;
		String generateOtpFlag = null;
		String otpLength = null;
		String maxSoftBlock = null;
		String retryValidationSupported = null;

		if (IssuerBankId.equalsIgnoreCase("8546") || IssuerBankId.equalsIgnoreCase("8271")
				|| IssuerBankId.equalsIgnoreCase("8201")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "5";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		} else if (IssuerBankId.equalsIgnoreCase("8129")|| IssuerBankId.equalsIgnoreCase("8117")
				|| IssuerBankId.equalsIgnoreCase("4131")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "3";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "2";
			generateOtpFlag = "true";
			otpLength = "0";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		} else if (IssuerBankId.equalsIgnoreCase("8501") || IssuerBankId.equalsIgnoreCase("8196")
				|| IssuerBankId.equalsIgnoreCase("8116") || IssuerBankId.equalsIgnoreCase("8510")
				|| IssuerBankId.equalsIgnoreCase("8508") || IssuerBankId.equalsIgnoreCase("8507")
				|| IssuerBankId.equalsIgnoreCase("8513") || IssuerBankId.equalsIgnoreCase("8514")
				|| IssuerBankId.equalsIgnoreCase("8556") || IssuerBankId.equalsIgnoreCase("8562")
				|| IssuerBankId.equalsIgnoreCase("8172") ) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "3";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "3";
			retryValidationSupported = "true";
		} else if (IssuerBankId.equalsIgnoreCase("8263") || IssuerBankId.equalsIgnoreCase("8197")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "3";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "3";
			retryValidationSupported = "true";
		} else if (IssuerBankId.equalsIgnoreCase("8551")) {
			maxResendCount = "5";
			maxAttemptsCount = "3";
			maxFailureCount = "5";
			expiryMin = "3";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "3";
			retryValidationSupported = "true";
		}

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		RequestSpecification request = RestAssured.given().contentType("application/json");

		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", maxResendCount);
		otpMap.put("maxAttemptsCount", maxAttemptsCount);
		otpMap.put("maxFailureCount", maxFailureCount);
		otpMap.put("expiryMin", expiryMin);
		otpMap.put("uniquePerChannel", uniquePerChannel);
		otpMap.put("forceNew", forceNew);
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", generateOtpFlag);
		otpMap.put("otpLength", otpLength);
		otpMap.put("maxSoftBlock", maxSoftBlock);
		otpMap.put("retryValidationSupported", retryValidationSupported);
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- " + requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
		//System.out.println("resposeBody:- " + resposeBody);
		//System.out.println("OTP Response : " + resposeBody.asString());

		// String OtpValue =
		// request.post("/v1/otp/services/resendOTP").then().extract().path("otpValue");

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 0) {
					OtpValue = otp.getAsString();

				}

			}

		}

		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}

	public static String getExpressPayOTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		String maxResendCount = null;
		String maxAttemptsCount = null;
		String maxFailureCount = null;
		String expiryMin = null;
		String uniquePerChannel = null;
		String forceNew = null;
		String otpCategory = null;
		String generateOtpFlag = null;
		String otpLength = null;
		String maxSoftBlock = null;
		String retryValidationSupported = null;

		if (IssuerBankId.equalsIgnoreCase("8116") || IssuerBankId.equalsIgnoreCase("8117") 
				||  IssuerBankId.equalsIgnoreCase("8546") || IssuerBankId.equalsIgnoreCase("8055")
				||  IssuerBankId.equalsIgnoreCase("9111")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "5";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		} else if (IssuerBankId.equalsIgnoreCase("8131")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "5";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "2";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		}

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		System.out.println("OTP Base URl :"+ Config.BASE_OTPENGINE_URI);
		RequestSpecification request = RestAssured.given().contentType("application/json");

		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", maxResendCount);
		otpMap.put("maxAttemptsCount", maxAttemptsCount);
		otpMap.put("maxFailureCount", maxFailureCount);
		otpMap.put("expiryMin", expiryMin);
		otpMap.put("uniquePerChannel", uniquePerChannel);
		otpMap.put("forceNew", forceNew);
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", generateOtpFlag);
		otpMap.put("otpLength", otpLength);
		otpMap.put("maxSoftBlock", maxSoftBlock);
		otpMap.put("retryValidationSupported", retryValidationSupported);
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		commonMap.put("expiryMin", "5");
		
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		smsMap.put("expiryMin", "5");
		
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		emailMap.put("expiryMin", "5");
		
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		ivrMap.put("expiryMin", "5");
		
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- " + requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		// String OtpValue =
		// request.post("/v1/otp/services/resendOTP").then().extract().path("otpValue");

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 0) {
					OtpValue = otp.getAsString();

				}

			}

		}

		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}

	public static String getIVROTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		String maxResendCount = null;
		String maxAttemptsCount = null;
		String maxFailureCount = null;
		String expiryMin = null;
		String uniquePerChannel = null;
		String forceNew = null;
		String otpCategory = null;
		String generateOtpFlag = null;
		String otpLength = null;
		String maxSoftBlock = null;
		String retryValidationSupported = null;

		if (IssuerBankId.equalsIgnoreCase("8546")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "5";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "1";
			generateOtpFlag = "true";
			otpLength = "6";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		}

		else if (IssuerBankId.equalsIgnoreCase("8129")) {
			maxResendCount = "3";
			maxAttemptsCount = "3";
			maxFailureCount = "3";
			expiryMin = "3";
			uniquePerChannel = "true";
			forceNew = "true";
			otpCategory = "2";
			generateOtpFlag = "true";
			otpLength = "0";
			maxSoftBlock = "0";
			retryValidationSupported = "true";
		}

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		RequestSpecification request = RestAssured.given().contentType("application/json");

		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", maxResendCount);
		otpMap.put("maxAttemptsCount", maxAttemptsCount);
		otpMap.put("maxFailureCount", maxFailureCount);
		otpMap.put("expiryMin", expiryMin);
		otpMap.put("uniquePerChannel", uniquePerChannel);
		otpMap.put("forceNew", forceNew);
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", generateOtpFlag);
		otpMap.put("otpLength", otpLength);
		otpMap.put("maxSoftBlock", maxSoftBlock);
		otpMap.put("retryValidationSupported", retryValidationSupported);
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- " + requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		// String OtpValue =
		// request.post("/v1/otp/services/resendOTP").then().extract().path("otpValue");

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 2) {
					OtpValue = otp.getAsString();

				}

			}

		}

		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}

}

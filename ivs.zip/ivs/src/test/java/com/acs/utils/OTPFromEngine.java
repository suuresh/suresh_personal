package com.acs.utils;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import com.acs.libraries.Config;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OTPFromEngine {
	
	public static String getCustomerFetchOTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		//System.out.println("OTP Base url " + Config.BASE_OTPENGINE_URI);
		RequestSpecification request = RestAssured.given().contentType("application/json");

		String otpCategory = "2";
		
		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", "3");
		otpMap.put("maxAttemptsCount", "3");
		otpMap.put("maxFailureCount", "3");
		otpMap.put("expiryMin", "3");
		otpMap.put("uniquePerChannel", "true");
		otpMap.put("forceNew", "true");
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", "true");
		otpMap.put("otpLength", "0");
		otpMap.put("maxSoftBlock", "0");
		otpMap.put("retryValidationSupported", "true");
		
		if(IssuerBankId.contentEquals("8055")) {
			otpMap.put("expiryMin", "1");
		} else
		{
			otpMap.put("expiryMin", "3");
		}
		
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- "+requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
										     
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 0) {
					OtpValue = otp.getAsString();

				}

			}

		}		
		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}
	

	public static String getOTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		System.out.println("OTP Base url " + Config.BASE_OTPENGINE_URI);
		RequestSpecification request = RestAssured.given().contentType("application/json");

//	 JSONObject requestParams = new JSONObject();
		// Map<String, Object> requestParams = new HashMap<>();
		/*
		 * requestParams.put("clientRefId", acsTxnId); // Cast
		 * requestParams.put("issuerId", IssuerBankId); requestParams.put("linkData",
		 * CardNumber); requestParams.put("otpMask", "N");
		 * requestParams.put("otpCategory", "2"); requestParams.put("callerId", "acs2");
		 * requestParams.put("forceNew", "true"); requestParams.put("regenerateAttempt",
		 * "3"); requestParams.put("maxAttempts", "3"); requestParams.put("expiryMin",
		 * "3"); requestParams.put("otpLength", "6"); requestParams.put("otpType", "R");
		 */

		String otpCategory = "1";
		if(IssuerBankId.contentEquals("8545") || IssuerBankId.contentEquals("4131") || IssuerBankId.contentEquals("9114") ) {
			otpCategory = "2";
		}
		
		
		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", "3");
		otpMap.put("maxAttemptsCount", "3");
		otpMap.put("maxFailureCount", "3");
		otpMap.put("expiryMin", "3");
		otpMap.put("uniquePerChannel", "true");
		otpMap.put("forceNew", "true");
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", "true");
		otpMap.put("otpLength", "0");
		otpMap.put("maxSoftBlock", "0");
		otpMap.put("retryValidationSupported", "true");
		
		if(IssuerBankId.contentEquals("8055")) {
			otpMap.put("expiryMin", "1");
		} else
		{
			otpMap.put("expiryMin", "3");
		}
		
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- "+requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		/*
		 * JsonObject jsonObject = new Gson().fromJson(jsonString, JsonObject.class);
		 * System.out.println("otpValue"+jsonObject.get("otpVal").getAsString());
		 */
		/*
		 * // request.body(requestParams.toJSONString()); Response response =
		 * request.post("/otp/services/resendOTP");
		 * 
		 * String resposeBody = response.body().asString(); JSONObject obj = new
		 * JSONObject(); String otpValue = (String) obj.get("otpValue");
		 * System.out.println(resposeBody); // String otpValue = repsoneBody. return
		 * resposeBody;
		 */

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
										     
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		// String OtpValue =
		// request.post("/v1/otp/services/resendOTP").then().extract().path("otpValue");

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 0) {
					OtpValue = otp.getAsString();

				}

			}

		}
		/*
		 * ArrayList<String> Value =
		 * request.post("/v1/otp/services/resendOTP").then().extract().path("otpValues")
		 * ;
		 * 
		 * for (String s : Value) { System.out.println("OtpValues:- " + s);
		 * 
		 * }
		 */
		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}

	public static String getIVROTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId, String otpCategory) {

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		RequestSpecification request = RestAssured.given().contentType("application/json");
		System.out.println(Config.BASE_OTPENGINE_URI);
//	 JSONObject requestParams = new JSONObject();
		// Map<String, Object> requestParams = new HashMap<>();
		/*
		 * requestParams.put("clientRefId", acsTxnId); // Cast
		 * requestParams.put("issuerId", IssuerBankId); requestParams.put("linkData",
		 * CardNumber); requestParams.put("otpMask", "N");
		 * requestParams.put("otpCategory", "2"); requestParams.put("callerId", "acs2");
		 * requestParams.put("forceNew", "true"); requestParams.put("regenerateAttempt",
		 * "3"); requestParams.put("maxAttempts", "3"); requestParams.put("expiryMin",
		 * "3"); requestParams.put("otpLength", "6"); requestParams.put("otpType", "R");
		 */

		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", "3");
		otpMap.put("maxAttemptsCount", "3");
		otpMap.put("maxFailureCount", "3");
		otpMap.put("expiryMin", "3");
		otpMap.put("uniquePerChannel", "true");
		otpMap.put("forceNew", "true");
		otpMap.put("otpCategory", otpCategory);
		otpMap.put("generateOtpFlag", "true");
		otpMap.put("otpLength", "0");
		otpMap.put("maxSoftBlock", "0");
		otpMap.put("retryValidationSupported", "true");
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- "+requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		/*
		 * JsonObject jsonObject = new Gson().fromJson(jsonString, JsonObject.class);
		 * System.out.println("otpValue"+jsonObject.get("otpVal").getAsString());
		 */
		/*
		 * // request.body(requestParams.toJSONString()); Response response =
		 * request.post("/otp/services/resendOTP");
		 * 
		 * String resposeBody = response.body().asString(); JSONObject obj = new
		 * JSONObject(); String otpValue = (String) obj.get("otpValue");
		 * System.out.println(resposeBody); // String otpValue = repsoneBody. return
		 * resposeBody;
		 */

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		// String OtpValue =
		// request.post("/v1/otp/services/resendOTP").then().extract().path("otpValue");

		/*
		 * Extracting the otp from nested json response Date 28-07-2020
		 */
		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			// System.out.println("Name: " +nameNode.getAsString());
			// System.out.println(nameNode);
			JsonArray node = nameNode.getAsJsonArray();
			// System.out.println(nameNode.equals("otpVal"));
			// System.out.println(node.get("otpVal"));

			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				/*
				 * JsonElement channelId = last.get("channelId"); String chanId =
				 * channelId.toString(); System.out.println("chanId: "+chanId);
				 */

				JsonElement otp = last.get("otpVal");
				if (i == 2) {
					OtpValue = otp.getAsString();

				}

			}

		}
		/*
		 * ArrayList<String> Value =
		 * request.post("/v1/otp/services/resendOTP").then().extract().path("otpValues")
		 * ;
		 * 
		 * for (String s : Value) { System.out.println("OtpValues:- " + s);
		 * 
		 * }
		 */
		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}

	public static String get3RIOTPFromEngine(String CardNumber, String IssuerBankId, String acsTxnId) {

		RestAssured.baseURI = Config.BASE_OTPENGINE_URI;
		RequestSpecification request = RestAssured.given().contentType("application/json");

		Map<String, Object> requestParams = new HashMap<String, Object>();
		requestParams.put("clientRefId", acsTxnId);
		requestParams.put("issuerId", IssuerBankId);
		// requestParams.put("bin", "724");
		requestParams.put("linkData", CardNumber);
		requestParams.put("otpType", "R");
		requestParams.put("regenerateAttempt", "0");
		requestParams.put("maxAttempts", "0");
		// requestParams.put("requestDateTime", "20XXXXXX132901");
		// OTP map
		Map<String, Object> otpMap = new HashMap<String, Object>();
		otpMap.put("callerId", "acs2");
		otpMap.put("maxResendCount", "3");
		otpMap.put("maxAttemptsCount", "3");
		otpMap.put("maxFailureCount", "3");
		otpMap.put("expiryMin", "3");
		otpMap.put("uniquePerChannel", "true");
		otpMap.put("forceNew", "true");
		otpMap.put("otpCategory", "1");
		otpMap.put("generateOtpFlag", "true");
		otpMap.put("otpLength", "0");
		otpMap.put("maxSoftBlock", "0");
		otpMap.put("retryValidationSupported", "true");
		Map<String, Object> channelMap = new HashMap<String, Object>();
		Map<String, String> commonMap = new HashMap<>();
		Map<String, String> smsMap = new HashMap<>();
		Map<String, String> emailMap = new HashMap<>();
		Map<String, String> ivrMap = new HashMap<>();
		channelMap.put("common", commonMap);
		commonMap.put("otpMask", "N");
		commonMap.put("otpLength", "6");
		channelMap.put("sms", smsMap);
		smsMap.put("otpMask", "N");
		smsMap.put("otpLength", "6");
		channelMap.put("email", emailMap);
		emailMap.put("otpMask", "N");
		emailMap.put("otpLength", "6");
		channelMap.put("ivr", ivrMap);
		ivrMap.put("otpMask", "N");
		ivrMap.put("otpLength", "6");
		otpMap.put("channels", channelMap);
		requestParams.put("otp", otpMap);

		System.out.println("requestParams:- "+requestParams);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		String jsonString = gson.toJson(requestParams);
		System.out.println(jsonString);

		// request.body(requestParams);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otp/services/resendOTP");
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		String OtpValue = null;
		JsonParser parser = new JsonParser();
		JsonElement rootNode = parser.parse(resposeBody.asString());

		// System.out.println(rootNode.toString());

		if (rootNode.isJsonObject()) {
			JsonObject details = rootNode.getAsJsonObject();
			JsonElement nameNode = details.get("otpValues");
			
			JsonArray node = nameNode.getAsJsonArray();
			for (int i = 0; i < node.size(); i++) {
				JsonElement d = node.get(i);
				// System.out.println(node.get(i));
				JsonObject last = d.getAsJsonObject();
				
				JsonElement otp = last.get("otpVal");
				if (i == 0) {
					OtpValue = otp.getAsString();

				}

			}

		}
		
		System.out.println("OTP Values is :" + OtpValue);

		return OtpValue;

	}
	
	
	public static String getE2FAOtp(String CardNumber, String IssuerBankId, String acsTxnId) {

		RestAssured.baseURI = Config.BASE_E2FA_url;
		RequestSpecification request = RestAssured.given().contentType("application/json");

		String jsonString = "{"
				+ "    \"instanceId\": \""+IssuerBankId+"\","
				+ "    \"forceNew\": \"true\","
				+ "    \"passwordCategory\": \"OTP\","
				+ "    \"passwordMask\": \"N\","
				+ "    \"passwordLength\": \"6\","
				+ "    \"expiryMin\": \"3\","
				+ "    \"maxAttempts\": \"3\","
				+ "    \"authenticationsAllowed\": \"1\","
				+ "    \"apiUser\": \"hdfc_dc\","
				+ "    \"linkData\": \""+CardNumber+"\","
				+ "    \"refNo\": \"202307100456025244oX2hW7qG\","
				+ "    \"ornReferenceNumber\": \"abcd\","
				+ "    \"messageHash\": \"dynamic:genpwdreq:12:56KX/mOtPNz9w4KlcAacGcq5K4U=\""
				+ "}";
		System.out.println(jsonString);
		
		Map<String,String> m = new HashMap<String, String>();		
		m.put("apiUser", Config.BASE_E2FA_APIUSER);
		m.put("apiKey", Config.BASE_E2FA_APIKEY);
		
		
		request.headers(m);
		request.body(jsonString);

		Response resposeBody = request.post("/v1/otpservice/hdfc_acs/pwd/generate");
		System.out.println("resposeBody:- " + resposeBody);
		System.out.println("OTP Response : " + resposeBody.asString());

		JsonParser parser = new JsonParser();
		JsonElement obj = parser.parse(resposeBody.asString());
		
		JsonObject jo = obj.getAsJsonObject();
		JsonElement otp =  jo.get("passwordValue");
		System.out.println("OTP Values is :" + otp.getAsString());
		return otp.getAsString();		


	}


}

package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EventEmail {

	public WebDriver driver;

	public EventEmail(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]/div[text()='Event Email ']")
	private WebElement eventEmailHeader;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement eventEmailAddBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//input[@id='root']")
	private WebElement eventEmailConfigClass;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_OTP_SEND_enabled']")
	private WebElement eventEmailEventOTPSendChkBox;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_OTP_SEND_text']")
	private WebElement eventOTPSendTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_OTP_SEND_subject']")
	private WebElement eventOtpSendSubjectTextField;

	// RBA Event

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_RBA_DECLINE_enabled']")
	private WebElement eventRbaDeclineCheckbox;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_RBA_DECLINE_text']")
	private WebElement eventRbaDeclineTextTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_RBA_DECLINE_subject']")
	private WebElement eventRbaDeclineSubjectTextTextField;

	
	// Card Event Block
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_CARD_BLOCKED_enabled']")
	private WebElement eventCardBlockedEnabledChkbox;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_CARD_BLOCKED_text']")
	private WebElement eventCardBlockedTextTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//following::input[@id='root_eventTemplates_EVENT_CARD_BLOCKED_subject']")
	private WebElement eventCardBlockedSubjectTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement eventEmailRemoveBtn;
	
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement eventEmailSaveBtn;

	public WebElement getEventEmailAddBtn() {
		return eventEmailAddBtn;
	}

	public WebElement getEventEmailConfigClass() {
		return eventEmailConfigClass;
	}

	public WebElement getEventEmailEventOTPSendChkBox() {
		return eventEmailEventOTPSendChkBox;
	}

	public WebElement getEventOTPSendTextField() {
		return eventOTPSendTextField;
	}

	public WebElement getEventOtpSendSubjectTextField() {
		return eventOtpSendSubjectTextField;
	}

	public WebElement getEventRbaDeclineCheckbox() {
		return eventRbaDeclineCheckbox;
	}

	public WebElement getEventRbaDeclineTextTextField() {
		return eventRbaDeclineTextTextField;
	}

	public WebElement getEventRbaDeclineSubjectTextTextField() {
		return eventRbaDeclineSubjectTextTextField;
	}

	public WebElement getEventCardBlockedEnabledChkbox() {
		return eventCardBlockedEnabledChkbox;
	}

	public WebElement getEventCardBlockedSubjectTextField() {
		return eventCardBlockedSubjectTextField;
	}

	public WebElement getEventCardBlockedTextTextField() {
		return eventCardBlockedTextTextField;
	}

	public WebElement getEventEmailRemoveBtn() {
		return eventEmailRemoveBtn;
	}

	public WebElement getEventEmailHeader() {
		return eventEmailHeader;
	}

	public WebElement getEventEmailSaveBtn() {
		return eventEmailSaveBtn;
	}

}

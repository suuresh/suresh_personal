package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlowV1Page {

	public WebDriver driver;

	public FlowV1Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1 ')]]/div[text()='Flow V1 ']")
	private WebElement flowV1Header;

	@FindBy(xpath = "//div[contains(text(),'Flow V1')]/a")
	private WebElement flowV1ExpandPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement flowV1SaveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement flowV1AddConfigClassPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div//input[@id='root_0_configClass']")
	private WebElement flowV1ConfigClassTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div//textarea[@id='root_0_configValue']")
	private WebElement flowV1TextArea;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement flowV1ConfigClassRemoveButton;

	public WebElement getFlowV1ExpandPlusButton() {
		return flowV1ExpandPlusButton;
	}

	public WebElement getFlowV1SaveButton() {
		return flowV1SaveButton;
	}

	public WebElement getFlowV1AddConfigClassPlusButton() {
		return flowV1AddConfigClassPlusButton;
	}

	public WebElement getFlowV1ConfigClassTextField() {
		return flowV1ConfigClassTextField;
	}

	public WebElement getFlowV1TextArea() {
		return flowV1TextArea;
	}

	public WebElement getFlowV1ConfigClassRemoveButton() {
		return flowV1ConfigClassRemoveButton;
	}

	public WebElement getFlowV1Header() {
		return flowV1Header;
	}

}

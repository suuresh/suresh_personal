package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DatasourceConfig {

	public WebDriver driver;

	public DatasourceConfig(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Datasource Config')]]//div[text()='Datasource Config ']")
	private WebElement dataSourceConfigHeader;

	// Customer DB

	@FindBy(xpath = "//legend[text()='customerDb']/following::a[1]")
	private WebElement customerDbDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement customerDbSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement customerDbFirstRadioBtn;

	@FindBy(id = "root_customerDb_schema")
	private WebElement customerDbDataSourceSchemaTextField;

	@FindBy(id = "root_customerDb_username")
	private WebElement customerDbDataUserNameTextField;

	@FindBy(id = "root_customerDb_password")
	private WebElement customerDbDataPasswordTextField;

	@FindBy(id = "root_customerDb_minimumIdle")
	private WebElement customerDbMinimumIdleTextField;

	@FindBy(id = "root_customerDb_maximumPoolSize")
	private WebElement customerDbMaximumPoolSizeTextField;

//Transaction DB

	@FindBy(xpath = "//legend[text()='transactionDb']/following::a[1]")
	private WebElement transactionDbDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement transactionDbSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement transactionDbFirstRadioBtn;

	@FindBy(id = "root_transactionDb_schema")
	private WebElement transactionDbDataSourceSchemaTextField;

	@FindBy(id = "root_transactionDb_username")
	private WebElement transactionDbDataUserNameTextField;

	@FindBy(id = "root_transactionDb_password")
	private WebElement transactionDbDataPasswordTextField;

	@FindBy(id = "root_transactionDb_minimumIdle")
	private WebElement transactionDbMinimumIdleTextField;

	@FindBy(id = "root_transactionDb_maximumPoolSize")
	private WebElement transactionDbMaximumPoolSizeTextField;

	// Reporting Transaction DB

	@FindBy(xpath = "//legend[text()='reportingTransactionDb']/following::a[1]")
	private WebElement reportingTransDbDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement reportingTransDbSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement reportingTransDbFirstRadioBtn;

	@FindBy(id = "root_reportingTransactionDb_schema")
	private WebElement reportinTransDbDataSourceSchemaTextField;

	@FindBy(id = "root_reportingTransactionDb_username")
	private WebElement reportingTransDbDataUserNameTextField;

	@FindBy(id = "root_reportingTransactionDb_password")
	private WebElement reportingTransDbDataPasswordTextField;

	@FindBy(id = "root_reportingTransactionDb_minimumIdle")
	private WebElement reportingTransDbMinimumIdleTextField;

	@FindBy(id = "root_reportingTransactionDb_maximumPoolSize")
	private WebElement reportingTransDbMaximumPoolSizeTextField;

	// Reporting Xdc
	@FindBy(id = "root_reportingXdcTransactionDb_requiredCheck")
	private WebElement reportingXdcTransactionDropdown;

	// Do You Want To Add Reporting Xdc Transaction Db Database Configurations= Yes

	@FindBy(xpath = "//div[text()='reportingXdcTransactionDb db']/following::span[1]")
	private WebElement reportingXdcTransactionDbDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement reportingXdcTransactionSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement reportingXdcTransactionFirstRadioBtn;

	@FindBy(id = "root_reportingXdcTransactionDb_schema")
	private WebElement reportingXdcTranSchemaDbTextfield;

	@FindBy(id = "root_reportingXdcTransactionDb_username")
	private WebElement reportingXdcTransacDbUserNameTextField;

	@FindBy(id = "root_reportingXdcTransactionDb_password")
	private WebElement reportingXdcTransacDbPasswordTextField;

	@FindBy(id = "root_reportingXdcTransactionDb_minimumIdle")
	private WebElement reportingXdcTransacDbMinimumIdleTextField;

	@FindBy(id = "root_reportingXdcTransactionDb_maximumPoolSize")
	private WebElement reportingXdcTransacDbMaxPoolSizeTextField;

	// Legacy DB

	@FindBy(id = "root_legacyDb_requiredCheck")
	private WebElement legacyDbConfigurationDropdown;

	// Do You Want To Add 1.0 Legacy Database Configurations? =Yes

	@FindBy(xpath = "//div[text()='legacyDb db']/following::span[1]")
	private WebElement legacyDBDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyDBSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyDBFirstRadioBtn;

	@FindBy(id = "root_legacyDb_schema")
	private WebElement root_legacyDb_schemaTextField;

	@FindBy(id = "root_legacyDb_username")
	private WebElement legacyDb_usernameTextField;

	@FindBy(id = "root_legacyDb_password")
	private WebElement legacyDb_passwordTextField;

	@FindBy(id = "root_legacyDb_minimumIdle")
	private WebElement legacyDb_minimumIdleTextField;

	@FindBy(id = "root_legacyDb_maximumPoolSize")
	private WebElement legacyDb_maximumPoolSizeTextField;

	// Legacy Reporting DB
	@FindBy(id = "root_legacyReportingDb_requiredCheck")
	private WebElement legacyReportingDbConfigDropdown;

	@FindBy(xpath = "//div[text()='legacyReportingDb db']/following::span[1]")
	private WebElement legacyReportingDbDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyReportingDbSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyReportingDbFirstRadioBtn;

	@FindBy(id = "root_legacyReportingDb_schema")
	private WebElement legacyReportingDb_schemaTextField;

	@FindBy(id = "root_legacyReportingDb_username")
	private WebElement legacyReportingDb_usernameTextField;

	@FindBy(id = "root_legacyReportingDb_password")
	private WebElement legacyReportingDb_passwordTextField;

	@FindBy(id = "root_legacyReportingDb_minimumIdle")
	private WebElement legacyReportingDb_minimumIdleTextField;

	@FindBy(id = "root_legacyReportingDb_maximumPoolSize")
	private WebElement legacyReportingDb_maximumPoolSizeTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Datasource Config')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement saveBtnDataSourceConfig;

	public WebElement getCustomerDbDropdown() {
		return customerDbDropdown;
	}

	public WebElement getCustomerDbDataSourceSchemaTextField() {
		return customerDbDataSourceSchemaTextField;
	}

	public WebElement getCustomerDbDataUserNameTextField() {
		return customerDbDataUserNameTextField;
	}

	public WebElement getCustomerDbDataPasswordTextField() {
		return customerDbDataPasswordTextField;
	}

	public WebElement getCustomerDbMinimumIdleTextField() {
		return customerDbMinimumIdleTextField;
	}

	public WebElement getCustomerDbMaximumPoolSizeTextField() {
		return customerDbMaximumPoolSizeTextField;
	}

	public WebElement getTransactionDbDropdown() {
		return transactionDbDropdown;
	}

	public WebElement getTransactionDbDataSourceSchemaTextField() {
		return transactionDbDataSourceSchemaTextField;
	}

	public WebElement getTransactionDbDataUserNameTextField() {
		return transactionDbDataUserNameTextField;
	}

	public WebElement getTransactionDbDataPasswordTextField() {
		return transactionDbDataPasswordTextField;
	}

	public WebElement getTransactionDbMinimumIdleTextField() {
		return transactionDbMinimumIdleTextField;
	}

	public WebElement getTransactionDbMaximumPoolSizeTextField() {
		return transactionDbMaximumPoolSizeTextField;
	}

	public WebElement getReportingTransDbDropdown() {
		return reportingTransDbDropdown;
	}

	public WebElement getReportinTransDbDataSourceSchemaTextField() {
		return reportinTransDbDataSourceSchemaTextField;
	}

	public WebElement getReportingTransDbDataUserNameTextField() {
		return reportingTransDbDataUserNameTextField;
	}

	public WebElement getReportingTransDbDataPasswordTextField() {
		return reportingTransDbDataPasswordTextField;
	}

	public WebElement getReportingTransDbMinimumIdleTextField() {
		return reportingTransDbMinimumIdleTextField;
	}

	public WebElement getReportingTransDbMaximumPoolSizeTextField() {
		return reportingTransDbMaximumPoolSizeTextField;
	}

	public WebElement getReportingXdcTransactionDropdown() {
		return reportingXdcTransactionDropdown;
	}

	public WebElement getLegacyDbConfigurationDropdown() {
		return legacyDbConfigurationDropdown;
	}

	public WebElement getLegacyReportingDbDropdown() {
		return legacyReportingDbDropdown;
	}

	public WebElement getReportingXdcTransactionDbDropdown() {
		return reportingXdcTransactionDbDropdown;
	}

	public WebElement getReportingXdcTranSchemaDbTextfield() {
		return reportingXdcTranSchemaDbTextfield;
	}

	public WebElement getReportingXdcTransacDbUserNameTextField() {
		return reportingXdcTransacDbUserNameTextField;
	}

	public WebElement getReportingXdcTransacDbPasswordTextField() {
		return reportingXdcTransacDbPasswordTextField;
	}

	public WebElement getReportingXdcTransacDbMinimumIdleTextField() {
		return reportingXdcTransacDbMinimumIdleTextField;
	}

	public WebElement getReportingXdcTransacDbMaxPoolSizeTextField() {
		return reportingXdcTransacDbMaxPoolSizeTextField;
	}

	public WebElement getLegacyDBDropdown() {
		return legacyDBDropdown;
	}

	public WebElement getRoot_legacyDb_schemaTextField() {
		return root_legacyDb_schemaTextField;
	}

	public WebElement getLegacyDb_usernameTextField() {
		return legacyDb_usernameTextField;
	}

	public WebElement getLegacyDb_passwordTextField() {
		return legacyDb_passwordTextField;
	}

	public WebElement getLegacyDb_minimumIdleTextField() {
		return legacyDb_minimumIdleTextField;
	}

	public WebElement getLegacyDb_maximumPoolSizeTextField() {
		return legacyDb_maximumPoolSizeTextField;
	}

	public WebElement getLegacyReportingDbConfigDropdown() {
		return legacyReportingDbConfigDropdown;
	}

	public WebElement getLegacyReportingDb_schemaTextField() {
		return legacyReportingDb_schemaTextField;
	}

	public WebElement getLegacyReportingDb_usernameTextField() {
		return legacyReportingDb_usernameTextField;
	}

	public WebElement getLegacyReportingDb_passwordTextField() {
		return legacyReportingDb_passwordTextField;
	}

	public WebElement getLegacyReportingDb_minimumIdleTextField() {
		return legacyReportingDb_minimumIdleTextField;
	}

	public WebElement getLegacyReportingDb_maximumPoolSizeTextField() {
		return legacyReportingDb_maximumPoolSizeTextField;
	}

	public WebElement getSaveBtnDataSourceConfig() {
		return saveBtnDataSourceConfig;
	}

	public WebElement getTransactionDbFirstRadioBtn() {
		return transactionDbFirstRadioBtn;
	}

	public WebElement getTransactionDbSearchBox() {
		return transactionDbSearchBox;
	}

	public WebElement getCustomerDbSearchBox() {
		return customerDbSearchBox;
	}

	public WebElement getCustomerDbFirstRadioBtn() {
		return customerDbFirstRadioBtn;
	}

	public WebElement getReportingTransDbFirstRadioBtn() {
		return reportingTransDbFirstRadioBtn;
	}

	public WebElement getReportingTransDbSearchBox() {
		return reportingTransDbSearchBox;
	}

	public WebElement getReportingXdcTransactionFirstRadioBtn() {
		return reportingXdcTransactionFirstRadioBtn;
	}

	public WebElement getReportingXdcTransactionSearchBox() {
		return reportingXdcTransactionSearchBox;
	}

	public WebElement getLegacyDBSearchBox() {
		return legacyDBSearchBox;
	}

	public WebElement getLegacyDBFirstRadioBtn() {
		return legacyDBFirstRadioBtn;
	}

	public WebElement getLegacyReportingDbSearchBox() {
		return legacyReportingDbSearchBox;
	}

	public WebElement getLegacyReportingDbFirstRadioBtn() {
		return legacyReportingDbFirstRadioBtn;
	}

	public WebElement getDataSourceConfigHeader() {
		return dataSourceConfigHeader;
	}

}

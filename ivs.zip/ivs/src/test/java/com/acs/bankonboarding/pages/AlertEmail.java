package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlertEmail {

	public WebDriver driver;

	public AlertEmail(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email ')]]/div[text()='Alert Email ']")
	private WebElement alertEmailHeader;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email ')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement alertEmailAddBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email ')]]//following::input[@placeholder='configClass']")
	private WebElement alertEmailConfigClassTextField;

	// Select Alert Email
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email')]]//following::div[text()='Alert Email']/following::a[1]")
	private WebElement alertEmailDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement alertEmailSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement alertEmailFirstRadioBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement alertEmailRemoveBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert Email')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement alertEmailSaveBtn;

	public WebElement getAlertEmailHeader() {
		return alertEmailHeader;
	}

	public void setAlertEmailHeader(WebElement alertEmailHeader) {
		this.alertEmailHeader = alertEmailHeader;
	}

	public WebElement getAlertEmailAddBtn() {
		return alertEmailAddBtn;
	}

	public WebElement getAlertEmailConfigClassTextField() {
		return alertEmailConfigClassTextField;
	}

	public WebElement getAlertEmailDropdown() {
		return alertEmailDropdown;
	}

	public WebElement getAlertEmailSearchBox() {
		return alertEmailSearchBox;
	}

	public WebElement getAlertEmailFirstRadioBtn() {
		return alertEmailFirstRadioBtn;
	}

	public WebElement getAlertEmailRemoveBtn() {
		return alertEmailRemoveBtn;
	}

	public WebElement getAlertEmailSaveBtn() {
		return alertEmailSaveBtn;
	}
}

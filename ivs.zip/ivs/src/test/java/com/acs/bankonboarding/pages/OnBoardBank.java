package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OnBoardBank {

	public WebDriver driver;

	public OnBoardBank(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
	@FindBy(id = "root_BankName")
	private WebElement bankNameTextField;

	@FindBy(xpath = "//*[text()='TimeZone']/following::a[1]")
	private WebElement timeZoneDropdown;
	
	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement timeZoneSearchBox;
	
	@FindBy(xpath = "//div[text()='TimeZone']/following::label[@class='radio-label']")
	private WebElement timeZoneFirstRadioBtn;

	@FindBy(id = "root_BankCode")
	private WebElement bankCodeTextField;

	@FindBy(id = "root_BankID")
	private WebElement bankIdTextField;

	@FindBy(xpath = "//*[text()='Currency']/following::a[1]")
	private WebElement currencyDropdown;

	@FindBy(xpath = "//*[text()='Currency']/following::input[@placeholder='Search']")
	private WebElement currencySearchbox;

	@FindBy(xpath = "//input[@name='Currency']//following::label[1]")
	private WebElement currencyRadioButton;

	@FindBy(xpath = "//*[text()='Cluster']//following::a[1]")
	private WebElement clusterDropdown;

	@FindBy(id = "root_BankLogoURL")
	private WebElement bankLogoUrlTextField;

	@FindBy(xpath = "//*[text()='Enabled Maker Checker']//following::a[1]")
	private WebElement enabledMakerCheckerDrpdwn;

	@FindBy(xpath = "//*[text()='Enabled Maker Checker']//following::label[text()='Yes']")
	private WebElement enabledMakerCheckerYesRadioBtn;

	@FindBy(xpath = "//*[text()='Enabled Maker Checker']//following::label[text()='No']")
	private WebElement enabledMakerCheckerNoRadioBtn;

	@FindBy(xpath = "(//a[text()='Save'])[1]")
	private WebElement saveBtn;

	public WebElement getBankNameTextField() {
		return bankNameTextField;
	}

	public WebElement getTimeZoneDropdown() {
		return timeZoneDropdown;
	}

	public WebElement getBankCodeTextField() {
		return bankCodeTextField;
	}

	public WebElement getBankIdTextField() {
		return bankIdTextField;
	}

	public WebElement getCurrencyDropdown() {
		return currencyDropdown;
	}

	public WebElement getCurrencyRadioButton() {
		return currencyRadioButton;
	}

	public WebElement getClusterDropdown() {
		return clusterDropdown;
	}

	public WebElement getbankLogoUrlTextField() {
		return bankLogoUrlTextField;
	}

	public WebElement getEnabledMakerCheckerDrpdwn() {
		return enabledMakerCheckerDrpdwn;
	}

	public WebElement getEnabledMakerCheckerYesRadioBtn() {
		return enabledMakerCheckerYesRadioBtn;
	}

	public WebElement getEnabledMakerCheckerNoRadioBtn() {
		return enabledMakerCheckerNoRadioBtn;
	}

	public WebElement getTimeZoneSearchBox() {
		return timeZoneSearchBox;
	}

	public WebElement getTimeZoneFirstRadioBtn() {
		return timeZoneFirstRadioBtn;
	}

	public WebElement getCurrencySearchbox() {
		return currencySearchbox;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

}

package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EventSMS {

	public WebDriver driver;

	public EventSMS(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event SMS ')]]/div[text()='Event SMS ']")
	private WebElement eventSMSHeader;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event SMS ')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement eventSMSAddBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event SMS ')]]//input[@id='root']")
	private WebElement configClassTextField;

	@FindBy(id = "root_eventTemplates_EVENT_OTP_SEND_enabled")
	private WebElement eventTemplateOtpSendChkBox;

	@FindBy(id = "root_eventTemplates_EVENT_OTP_SEND_text")
	private WebElement eventTemplateOtpSendTextField;

	@FindBy(id = "root_eventTemplates_EVENT_RBA_DECLINE_enabled")
	private WebElement eventTemplateRBADeclineChkBox;

	@FindBy(id = "root_eventTemplates_EVENT_RBA_DECLINE_text")
	private WebElement eventTemplateRBADeclineTextField;

	@FindBy(id = "root_eventTemplates_EVENT_CARD_BLOCKED_enabled")
	private WebElement eventTemplateCardBlockedChkBox;

	@FindBy(id = "root_eventTemplates_EVENT_CARD_BLOCKED_text")
	private WebElement eventTemplatesCardBlockedTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'OTP Config ')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement eventSmsRemoveBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Event SMS ')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement eventSmsSaveBtn;

	public WebElement getEventConfigAddBtn() {
		return eventSMSAddBtn;
	}

	public WebElement getConfigClassTextField() {
		return configClassTextField;
	}

	public WebElement getEventTemplateOtpSendChkBox() {
		return eventTemplateOtpSendChkBox;
	}

	public WebElement getEventTemplateOtpSendTextField() {
		return eventTemplateOtpSendTextField;
	}

	public WebElement getEventTemplateRBADeclineChkBox() {
		return eventTemplateRBADeclineChkBox;
	}

	public WebElement getEventTemplateRBADeclineTextField() {
		return eventTemplateRBADeclineTextField;
	}

	public WebElement getEventTemplateCardBlockedChkBox() {
		return eventTemplateCardBlockedChkBox;
	}

	public WebElement getEventTemplatesCardBlockedTextField() {
		return eventTemplatesCardBlockedTextField;
	}

	public WebElement getEventSMSAddBtn() {
		return eventSMSAddBtn;
	}

	public WebElement getEventSmsSaveBtn() {
		return eventSmsSaveBtn;
	}

	public WebElement getEventSMSHeader() {
		return eventSMSHeader;
	}

}

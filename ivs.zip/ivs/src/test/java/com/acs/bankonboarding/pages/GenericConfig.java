package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GenericConfig {

	public WebDriver driver;

	public GenericConfig(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id = 'root_bankCode']")
	private WebElement bankCodeTextField;

	// HSM Section

	@FindBy(xpath = "//div[contains(@class,'customwidth_48 hsmSection')]//a[contains(@class,'')]")
	private WebElement hsmURLDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement hsmURLSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement hsmURLFirstRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://legacy-hsm2')]")
	private WebElement legacyHsm2RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://legacy-hsm1')]")
	private WebElement legacyHsm1RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://cmmn-hsm-1')]")
	private WebElement cmmnHsm1RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://common-hsm')]")
	private WebElement commonHsmRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://common-legacy-hsm')]")
	private WebElement commonLegacyHsmRadioBtn;

	// HSM DataEncKey Alg
	@FindBy(xpath = "(//*[text()='HSM DataEncKey Alg']//following::a[1])[1]")
	private WebElement hsmDataEncKeyAlgDropdown;

	@FindBy(xpath = "//label[contains(text(),'HMACSHA256')]")
	private WebElement HMACSHA256RadioBtn;

	@FindBy(xpath = "//div[@id='dropdown-menu']//div[2]//label[1]")
	private WebElement ACRadioBtn;

	// HSM DataEncKey encMode
	@FindBy(xpath = "(//*[text()='HSM DataEncKey encMode']//following::a[1])[1]")
	private WebElement hsmDataEncKeyEncModeDropdown;

	@FindBy(xpath = "//label[contains(text(),'01')]")
	private WebElement select01RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'09')]")
	private WebElement select09RadioBtn;

	// HSM DataEncKey key
	@FindBy(xpath = "//div[5]//div[1]//div[2]//div[1]//a[1]//span[1]")
	private WebElement hsmDataEncKeyKeyDropdown;

	@FindBy(xpath = "//*[@for='RAW_VALUE']")
	private WebElement rawValueRadioBtn;

	@FindBy(xpath = "//input[@id='root_hsm.dataEncKey.keyAlias']")
	private WebElement hsmDataEncKeyKeyAliasTextField;

	// HSM DataEncKey keyType
	@FindBy(xpath = "//div[7]//div[1]//div[2]//div[1]//a[1]")
	private WebElement hsmDataEncKeykeyTypeDropdown;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement hsmDataEncKeykeyAES256RadioBtn;

	// HSM DataEncKey providerType
	@FindBy(xpath = "//div[contains(@class,'customwidth_100 hello')]//a[contains(@class,'')]")
	private WebElement hsmDataEncKeyproviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_AC']")
	private WebElement hsmDataEncKeyproviderTypeHK_ACRadiobtn;

	// Legacy HSM Section

	@FindBy(xpath = "//div[contains(@class,'customwidth_48 hi')]//a[contains(@class,'')]")
	private WebElement legacyHsmUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyHsmUrlSearchBox;

	@FindBy(xpath = "(//label[@class='radio-label'])[1]")
	private WebElement legacyHsmUrlFirstRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://legacy-hsm2')]")
	private WebElement legacyLegacyhsm2RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://legacy-hsm1')]")
	private WebElement legacyLegacyhsm1RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://cmmn-hsm-1')]")
	private WebElement legacyCmmnhsm1RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://common-hsm')]")
	private WebElement legacyCommonhsmRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'ep://common-legacy-hsm')]")
	private WebElement legacyCommonLegacyhsmRadioBtn;

// HSM DataEncKey Alg
	@FindBy(xpath = "(//div[text()='HSM DataEncKey Alg']//following::a[1])[2]")
	private WebElement legacyHSMDataEncKeyAlgDropdown;

	@FindBy(xpath = "//label[contains(text(),'HMACSHA256')]")
	private WebElement legacyHMACSHA256RadioBtn;

	@FindBy(xpath = "//div[@id='dropdown-menu']//div[2]//label[1]")
	private WebElement legacyACRadioBtn;

	@FindBy(xpath = "(//div[text()='HSM DataEncKey encMode']//following::a[1])[2]")
	private WebElement legacyHSMDataEncKeyEncModeDropdown;

	@FindBy(xpath = "//label[contains(text(),'01')]")
	private WebElement legacy01RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'09')]")
	private WebElement legacy09RadioBtn;

	@FindBy(xpath = "(//div[text()='HSM DataEncKey key']//following::a[1])[2]")
	private WebElement legacyHSMDataEncKeykeyDropdown;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyRawValueRadioBtn;

	@FindBy(xpath = "//input[@placeholder='Enter legacyHsm DataEncKey keyAlias']")
	private WebElement legacyHSMDataEncKeyKeyAliasTextBox;

	@FindBy(xpath = "//div[14]//div[1]//div[2]//div[1]//a[1]")
	private WebElement legacyHSMDataEncKeykeyTypeDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown-content')]//div[contains(@class,'field')]")
	private WebElement legacyAES256RadioBtn;

	@FindBy(xpath = "//div[@data-tip='LegacyHSM DataEncKey providerType']//following::a[1]")
	private WebElement legacyLegacyHSMDataEncKeyproviderTypeDropdown;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyHK_ACRadioBtn;

	@FindBy(xpath = "//div[text()='Cache']/following::a[1]")
	private WebElement legacyCacheDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyCacheSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyCacheFirstRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'cache://rrrrrrrrrrr')]")
	private WebElement legacyCacherrrrrrRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'cache://common-cache')]")
	private WebElement legacyCacheCommonCacheRadioBtn;

	// Queue
	@FindBy(xpath = "//div[text()='Queue']/following::a[1]")
	private WebElement legacyQueueDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyQueueSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyQueueFirstRadioBtn;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyCommonQueuesRadioBtn;

	// Alert Service Url
	@FindBy(xpath = "//div[text()='Alert Service Url']//following::a[1]")
	private WebElement legacyAlertServiceUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyAlertServiceUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyAlertServiceUrlFirstRadioBtn;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyCommonAlertRadioBtn;

	// customer Service Url
	@FindBy(xpath = "//div[text()='customer Service Url']/following::a[1]")
	private WebElement legacyCustomerServiceUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyCustomerServiceUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyCustomerServiceUrlFirstRadioBtn;

	@FindBy(xpath = "//div[text()='customer Service Url']/following::a[1]/following::label[text()='ep://common-customer']")
	private WebElement legacyCommonCustomerRadioBtn;

	// otp Service Url

	@FindBy(xpath = "//div[text()='otp Service Url']/following::a[1]")
	private WebElement legacyOtpServiceUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyOtpServiceUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyOtpServiceUrlFirstRadioBtn;

	@FindBy(xpath = "//div[text()='otp Service Url']/following::a[1]/following::label[text()='ep://common-otp']")
	private WebElement legacyCommonOtpRadioBtn;

	// expiry Cache Url
	@FindBy(xpath = "//div[text()='expiry Cache Url']/following::a[1]")
	private WebElement legacyExpiryCacheUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyExpiryCacheUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyExpiryCacheUrlFirstRadioBtn;

	@FindBy(xpath = "//div[text()='expiry Cache Url']/following::a[1]/following::label[text()='ep://common-expiry']")
	private WebElement legacyCommonExpiryRadioBtn;

	// cdn Url
	@FindBy(xpath = "//div[22]//div[1]//div[2]//div[1]//a[1]")
	private WebElement legacyCdnUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyCdnUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyCdnUrlFirstRadioBtn;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyCdnUrlRadioBtn;

	// acs Url
	@FindBy(xpath = "//div[23]//div[1]//div[2]//div[1]//a[1]")
	private WebElement legacyACSUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement legacyACSUrlSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement legacyACSUrlFirstRadioBtn;

	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement legacyACSUIRadioBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Generic Config')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement saveBtnGenericConfig;

	// Customer Remote Data Sync Url
	@FindBy(xpath = "(//div[text()='Customer Remote Data Sync Url']/following::div/div/a[1])[1]")
	private WebElement CustomerRemoteDataSyncUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement CustomerRemoteDataSyncUrlSearchBox;

	@FindBy(xpath = "(//label[@class='radio-label'])[1]")
	private WebElement CustomerRemoteDataSyncUrlDropdownFirstValue;

	// 3ds Method Remote Data Sync Url
	@FindBy(xpath = "(//div[text()='3ds Method Remote Data Sync Url']/following::div/div/a[1])[1]")
	private WebElement ThreedsMethodRemoteDataSyncUrlDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement ThreedsMethodRemoteDataSyncUrlSearchBox;

	@FindBy(xpath = "(//label[@class='radio-label'])[1]")
	private WebElement ThreedsMethodRemoteDataSyncUrlDropdownFirstValue;

	@FindBy(xpath = "//textarea[@placeholder='Enter secretKey']")
	private WebElement secretKeyTextField;

	public WebElement getBankCodeTextField() {
		return bankCodeTextField;
	}

	public WebElement getHsmDataEncKeyKeyAliasTextField() {
		return hsmDataEncKeyKeyAliasTextField;
	}

	public WebElement getHsmDataEncKeykeyAES256RadioBtn() {
		return hsmDataEncKeykeyAES256RadioBtn;
	}

	public WebElement getHsmDataEncKeyproviderTypeHK_ACRadiobtn() {
		return hsmDataEncKeyproviderTypeHK_ACRadiobtn;
	}

	public WebElement getLegacyHSMDataEncKeyKeyAliasTextBox() {
		return legacyHSMDataEncKeyKeyAliasTextBox;
	}

	public WebElement getLegacyOtpServiceUrlDropdown() {
		return legacyOtpServiceUrlDropdown;
	}

	public WebElement getLegacyCommonOtpRadioBtn() {
		return legacyCommonOtpRadioBtn;
	}

	public WebElement getCustomerRemoteDataSyncUrlDropdown() {
		return CustomerRemoteDataSyncUrlDropdown;
	}

	public WebElement getCustomerRemoteDataSyncUrlSearchBox() {
		return CustomerRemoteDataSyncUrlSearchBox;
	}

	public WebElement getCustomerRemoteDataSyncUrlDropdownFirstValue() {
		return CustomerRemoteDataSyncUrlDropdownFirstValue;
	}

	public WebElement getThreedsMethodRemoteDataSyncUrlDropdown() {
		return ThreedsMethodRemoteDataSyncUrlDropdown;
	}

	public WebElement getThreedsMethodRemoteDataSyncUrlSearchBox() {
		return ThreedsMethodRemoteDataSyncUrlSearchBox;
	}

	public WebElement getThreedsMethodRemoteDataSyncUrlDropdownFirstValue() {
		return ThreedsMethodRemoteDataSyncUrlDropdownFirstValue;
	}

	public WebElement getSecretKeyTextField() {
		return secretKeyTextField;
	}

	public WebElement getbankCodeTextField() {
		return bankCodeTextField;
	}

	public WebElement getHsmURLDropdown() {
		return hsmURLDropdown;
	}

	public WebElement getLegacyHsm2RadioBtn() {
		return legacyHsm2RadioBtn;
	}

	public WebElement getLegacyHsm1RadioBtn() {
		return legacyHsm1RadioBtn;
	}

	public WebElement getCmmnHsm1RadioBtn() {
		return cmmnHsm1RadioBtn;
	}

	public WebElement getCommonHsmRadioBtn() {
		return commonHsmRadioBtn;
	}

	public WebElement getCommonLegacyHsmRadioBtn() {
		return commonLegacyHsmRadioBtn;
	}

	public WebElement getHsmDataEncKeyAlgDropdown() {
		return hsmDataEncKeyAlgDropdown;
	}

	public WebElement getHMACSHA256RadioBtn() {
		return HMACSHA256RadioBtn;
	}

	public WebElement getACRadioBtn() {
		return ACRadioBtn;
	}

	public WebElement getHsmDataEncKeyEncModeDropdown() {
		return hsmDataEncKeyEncModeDropdown;
	}

	public WebElement getSelect01RadioBtn() {
		return select01RadioBtn;
	}

	public WebElement getSelect09RadioBtn() {
		return select09RadioBtn;
	}

	public WebElement getHsmDataEncKeyKeyDropdown() {
		return hsmDataEncKeyKeyDropdown;
	}

	public WebElement getRawValueRadioBtn() {
		return rawValueRadioBtn;
	}

	public WebElement gethsmDataEncKeyKeyAliasTextField() {
		return hsmDataEncKeyKeyAliasTextField;
	}

	public WebElement getHsmDataEncKeykeyTypeDropdown() {
		return hsmDataEncKeykeyTypeDropdown;
	}

	public WebElement gethsmDataEncKeykeyAES256RadioBtn() {
		return hsmDataEncKeykeyAES256RadioBtn;
	}

	public WebElement getHsmDataEncKeyproviderTypeDropdown() {
		return hsmDataEncKeyproviderTypeDropdown;
	}

	public WebElement gethsmDataEncKeyproviderTypeHK_ACRadiobtn() {
		return hsmDataEncKeyproviderTypeHK_ACRadiobtn;
	}

	public WebElement getLegacyHsmUrlDropdown() {
		return legacyHsmUrlDropdown;
	}

	public WebElement getLegacyLegacyhsm2RadioBtn() {
		return legacyLegacyhsm2RadioBtn;
	}

	public WebElement getLegacyLegacyhsm1RadioBtn() {
		return legacyLegacyhsm1RadioBtn;
	}

	public WebElement getLegacyCmmnhsm1RadioBtn() {
		return legacyCmmnhsm1RadioBtn;
	}

	public WebElement getLegacyCommonhsmRadioBtn() {
		return legacyCommonhsmRadioBtn;
	}

	public WebElement getLegacyCommonLegacyhsmRadioBtn() {
		return legacyCommonLegacyhsmRadioBtn;
	}

	public WebElement getLegacyHSMDataEncKeyAlgDropdown() {
		return legacyHSMDataEncKeyAlgDropdown;
	}

	public WebElement getLegacyHMACSHA256RadioBtn() {
		return legacyHMACSHA256RadioBtn;
	}

	public WebElement getLegacyACRadioBtn() {
		return legacyACRadioBtn;
	}

	public WebElement getLegacyHSMDataEncKeyEncModeDropdown() {
		return legacyHSMDataEncKeyEncModeDropdown;
	}

	public WebElement getLegacy01RadioBtn() {
		return legacy01RadioBtn;
	}

	public WebElement getLegacy09RadioBtn() {
		return legacy09RadioBtn;
	}

	public WebElement getLegacyHSMDataEncKeykeyDropdown() {
		return legacyHSMDataEncKeykeyDropdown;
	}

	public WebElement getLegacyRawValueRadioBtn() {
		return legacyRawValueRadioBtn;
	}

	public WebElement getlegacyHSMDataEncKeyKeyAliasTextBox() {
		return legacyHSMDataEncKeyKeyAliasTextBox;
	}

	public WebElement getLegacyHSMDataEncKeykeyTypeDropdown() {
		return legacyHSMDataEncKeykeyTypeDropdown;
	}

	public WebElement getLegacyAES256RadioBtn() {
		return legacyAES256RadioBtn;
	}

	public WebElement getLegacyLegacyHSMDataEncKeyproviderTypeDropdown() {
		return legacyLegacyHSMDataEncKeyproviderTypeDropdown;
	}

	public WebElement getLegacyHK_ACRadioBtn() {
		return legacyHK_ACRadioBtn;
	}

	public WebElement getLegacyCacheDropdown() {
		return legacyCacheDropdown;
	}

	public WebElement getLegacyCacherrrrrrRadioBtn() {
		return legacyCacherrrrrrRadioBtn;
	}

	public WebElement getLegacyCacheCommonCacheRadioBtn() {
		return legacyCacheCommonCacheRadioBtn;
	}

	public WebElement getLegacyQueueDropdown() {
		return legacyQueueDropdown;
	}

	public WebElement getLegacyCommonQueuesRadioBtn() {
		return legacyCommonQueuesRadioBtn;
	}

	public WebElement getLegacyAlertServiceUrlDropdown() {
		return legacyAlertServiceUrlDropdown;
	}

	public WebElement getLegacyCommonAlertRadioBtn() {
		return legacyCommonAlertRadioBtn;
	}

	public WebElement getLegacyCustomerServiceUrlDropdown() {
		return legacyCustomerServiceUrlDropdown;
	}

	public WebElement getLegacyCommonCustomerRadioBtn() {
		return legacyCommonCustomerRadioBtn;
	}

	public WebElement getLegacyotpServiceUrlDropdown() {
		return legacyOtpServiceUrlDropdown;
	}

	public WebElement getLegacyExpiryCacheUrlDropdown() {
		return legacyExpiryCacheUrlDropdown;
	}

	public WebElement getLegacyCommonExpiryRadioBtn() {
		return legacyCommonExpiryRadioBtn;
	}

	public WebElement getLegacyCdnUrlDropdown() {
		return legacyCdnUrlDropdown;
	}

	public WebElement getLegacyCdnUrlRadioBtn() {
		return legacyCdnUrlRadioBtn;
	}

	public WebElement getLegacyACSUrlDropdown() {
		return legacyACSUrlDropdown;
	}

	public WebElement getLegacyACSUIRadioBtn() {
		return legacyACSUIRadioBtn;
	}

	public WebElement getGenericConfigSaveButton() {
		return saveBtnGenericConfig;
	}

	public WebElement getHsmURLSearchBox() {
		return hsmURLSearchBox;
	}

	public WebElement getHsmURLFirstRadioBtn() {
		return hsmURLFirstRadioBtn;
	}

	public WebElement getLegacyHsmUrlSearchBox() {
		return legacyHsmUrlSearchBox;
	}

	public WebElement getLegacyHsmUrlFirstRadioBtn() {
		return legacyHsmUrlFirstRadioBtn;
	}

	public WebElement getLegacyCacheSearchBox() {
		return legacyCacheSearchBox;
	}

	public WebElement getLegacyCacheFirstRadioBtn() {
		return legacyCacheFirstRadioBtn;
	}

	public WebElement getLegacyQueueSearchBox() {
		return legacyQueueSearchBox;
	}

	public WebElement getLegacyQueueFirstRadioBtn() {
		return legacyQueueFirstRadioBtn;
	}

	public WebElement getLegacyAlertServiceUrlSearchBox() {
		return legacyAlertServiceUrlSearchBox;
	}

	public WebElement getLegacyAlertServiceUrlFirstRadioBtn() {
		return legacyAlertServiceUrlFirstRadioBtn;
	}

	public WebElement getLegacyCustomerServiceUrlSearchBox() {
		return legacyCustomerServiceUrlSearchBox;
	}

	public WebElement getLegacyCustomerServiceUrlFirstRadioBtn() {
		return legacyCustomerServiceUrlFirstRadioBtn;
	}

	public WebElement getLegacyOtpServiceUrlSearchBox() {
		return legacyOtpServiceUrlSearchBox;
	}

	public WebElement getLegacyOtpServiceUrlFirstRadioBtn() {
		return legacyOtpServiceUrlFirstRadioBtn;
	}

	public WebElement getLegacyExpiryCacheUrlSearchBox() {
		return legacyExpiryCacheUrlSearchBox;
	}

	public WebElement getLegacyExpiryCacheUrlFirstRadioBtn() {
		return legacyExpiryCacheUrlFirstRadioBtn;
	}

	public WebElement getLegacyCdnUrlFirstRadioBtn() {
		return legacyCdnUrlFirstRadioBtn;
	}

	public WebElement getLegacyCdnUrlSearchBox() {
		return legacyCdnUrlSearchBox;
	}

	public WebElement getLegacyACSUrlFirstRadioBtn() {
		return legacyACSUrlFirstRadioBtn;
	}

	public WebElement getLegacyACSUrlSearchBox() {
		return legacyACSUrlSearchBox;
	}

	public WebElement getSaveBtnGenericConfig() {
		return saveBtnGenericConfig;
	}

}

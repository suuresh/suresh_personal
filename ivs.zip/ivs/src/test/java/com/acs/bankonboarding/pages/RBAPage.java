package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RBAPage {

	public WebDriver driver;

	public RBAPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]/div[text()='']")
	private WebElement rbaHeader;
	
	@FindBy(xpath = "//div[contains(text(),'RBA')]/a")
	private WebElement rbaExpandPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement RBASaveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement RBAAddConfigClassPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div//input[@id='root_0_configClass']")
	private WebElement RBAConfigClassTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div[contains(@class,'customwidth_100')]//a[contains(@class,'')]")
	private WebElement RBASelectDropDownField;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement rbaSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement rbaFirstRadioBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div[contains(@class,'customwidth_100')]//a[contains(@class,'')]")
	private WebElement RBASelectDropDownEntry;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement RBAConfigClassRemoveButton;

	public WebElement getRbaExpandPlusButtonExpandPlusButton() {
		return rbaExpandPlusButton;
	}

	public WebElement getRBASaveButton() {
		return RBASaveButton;
	}

	public WebElement getRBAAddConfigClassPlusButton() {
		return RBAAddConfigClassPlusButton;
	}

	public WebElement getRBAConfigClassTextField() {
		return RBAConfigClassTextField;
	}

	public WebElement getRBASelectDropDownField() {
		return RBASelectDropDownField;
	}

	public WebElement getRBASelectDropDownEntry() {
		return RBASelectDropDownEntry;
	}

	public WebElement getRBAConfigClassRemoveButton() {
		return RBAConfigClassRemoveButton;
	}

	public WebElement getRbaSearchBox() {
		return rbaSearchBox;
	}

	public WebElement getRbaFirstRadioBtn() {
		return rbaFirstRadioBtn;
	}

	public WebElement getRbaHeader() {
		return rbaHeader;
	}

	public WebElement getRbaExpandPlusButton() {
		return rbaExpandPlusButton;
	}

}

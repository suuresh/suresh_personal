package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckerOnboardBank {

	public WebDriver driver;

	public CheckerOnboardBank(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Approve']")
	private WebElement approveButton;

	@FindBy(xpath = "//a[text()='Reject']")
	private WebElement rejectButton;

	@FindBy(xpath = "//span[text()='Request Date & Time']/following::span[1]")
	private WebElement requestDateTimeValue;

	@FindBy(xpath = "//span[text()='Bank Name']/following::span[1]")
	private WebElement bankNameValue;

	@FindBy(xpath = "(//span[text()='Currency']/following::span[1])[1]")
	private WebElement currencyValue;

	@FindBy(xpath = "//span[text()='Status']/following::div[1]")
	private WebElement statusValue;

	@FindBy(xpath = "//textarea[@id='approveComment']")
	private WebElement commentTextArea;

	@FindBy(xpath = "//a[text()='CONFIRM']")
	private WebElement confirmButton;

	@FindBy(xpath = "//a[text()='CANCEL']")
	private WebElement cancelButton;

	public WebElement getApproveButton() {
		return approveButton;
	}

	public WebElement getRejectButton() {
		return rejectButton;
	}

	public WebElement getRequestDateTimeValue() {
		return requestDateTimeValue;
	}

	public WebElement getBankNameValue() {
		return bankNameValue;
	}

	public WebElement getCurrencyValue() {
		return currencyValue;
	}

	public WebElement getStatusValue() {
		return statusValue;
	}

	public WebElement getCommentTextArea() {
		return commentTextArea;
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

}

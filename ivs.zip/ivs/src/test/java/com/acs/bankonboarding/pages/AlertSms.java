package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlertSms {

	public WebDriver driver;

	public AlertSms(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]/div[text()='Alert SMS ']")
	private WebElement alertSmsHeader;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement alertSmsAddBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]//following::input[@id='root_0_configClass']")
	private WebElement alertSmsConfigClassTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]//following::div[text()='Alert Sms']/following::a[1]")
	private WebElement alertSmsDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement alertSmsSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement alertSmsFirstRadioBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement alertSmsRemoveBtn;
	
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement alertSmsSaveBtn;

	public WebElement getAlertSmsAddBtn() {
		return alertSmsAddBtn;
	}

	public WebElement getAlertSmsConfigClassTextField() {
		return alertSmsConfigClassTextField;
	}

	public WebElement getAlertSmsDropdown() {
		return alertSmsDropdown;
	}

	public WebElement getCustomerRemoveBtn() {
		return alertSmsRemoveBtn;
	}

	public WebElement getAlertSmsHeader() {
		return alertSmsHeader;
	}

	public WebElement getAlertSmsSearchBox() {
		return alertSmsSearchBox;
	}

	public WebElement getAlertSmsFirstRadioBtn() {
		return alertSmsFirstRadioBtn;
	}

	public WebElement getAlertSmsSaveBtn() {
		return alertSmsSaveBtn;
	}
}

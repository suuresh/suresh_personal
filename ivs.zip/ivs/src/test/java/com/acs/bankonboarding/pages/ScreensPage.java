package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ScreensPage {

	public WebDriver driver;

	public ScreensPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Screens  ')]]/div[text()='Screens  ']")
	private WebElement screensHeader;

	@FindBy(xpath = "//div[contains(text(),'Screens ')]/a")
	private WebElement screensExpandPlusBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Screens')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement screensSaveButton;

	// Authentication V1
	@FindBy(xpath = "(//*[contains(text(),'Authentication ')])[1]")
	private WebElement authenticationV1Button;

	@FindBy(xpath = "//select[@id='authenticationDivV1_slct']")
	private WebElement authV1SelectTemplateDropdown;

	@FindBy(xpath = "//div[contains(@class,'authenticationDivV1')]//div//a[contains(@class,'')]")
	private WebElement authV1MessageLanguageDropdown;

	@FindBy(xpath = "//label[contains(text(),'EN-English')]")
	private WebElement authV1MessageLanguageEnEnglishDropdownlist;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement authV1MessageLanguageDefaultDropdownlist;

	@FindBy(xpath = "//input[@id='authenticationDivV1_cssPath']")
	private WebElement authV1CssPathTextField;

	@FindBy(xpath = "//input[@id='authenticationDivV1_otpLeftLogo']")
	private WebElement authV1LeftLogoPathTextField;

	@FindBy(xpath = "//input[@id='authenticationDivV1_otpRightLogo']")
	private WebElement authV1RightLogoPathTextField;

	// Customer Information V1

	@FindBy(xpath = "//*[text()='Information V1']")
	private WebElement custInfoV1Button;

	@FindBy(xpath = "//select[@id='customerInfoDivV1_slct']")
	private WebElement custInfoV1SelectTemplateDropdown;

	@FindBy(xpath = "//div[contains(@class,'customerInfoDivV1')]//div//a[contains(@class,'')]")
	private WebElement custInfoV1MessageLanguageDropdown;

	@FindBy(xpath = "//label[contains(text(),'EN-English')]")
	private WebElement custInfoV1MessageLanguageEnEnglishDropdownlist;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement custInfoV1MessageLanguageDefaultDropdownlist;

	@FindBy(xpath = "//input[@id='customerInfoDivV1_cssPath']")
	private WebElement custInfoV1CssPathTextField;

	@FindBy(xpath = "//input[@id='customerInfoDivV1_otpLeftLogo']")
	private WebElement custInfoV1LeftLogoPathTextField;

	@FindBy(xpath = "//input[@id='customerInfoDivV1_otpRightLogo']")
	private WebElement custInfoV1RightLogoPathTextField;

	// Authentication V2
	@FindBy(xpath = "(//*[contains(text(),'Authentication ')])[2]")
	private WebElement authenticationV2Button;

	@FindBy(xpath = "//select[@id='authenticationDivV2_slct']")
	private WebElement authV2SelectTemplateDropdown;

	@FindBy(xpath = "//div[contains(@class,'authenticationDivV2')]//div//a[contains(@class,'')]")
	private WebElement authV2MessageLanguageDropdown;

	@FindBy(xpath = "//label[contains(text(),'EN-English')]")
	private WebElement authV2MessageLanguageEnEnglishDropdownlist;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement authV2MessageLanguageDefaultDropdownlist;

	@FindBy(xpath = "//input[@id='authenticationDivV2_cssPath']")
	private WebElement authV2CssPathTextField;

	@FindBy(xpath = "//input[@id='authenticationDivV2_otpLeftLogo']")
	private WebElement authV2LeftLogoPathTextField;

	@FindBy(xpath = "//input[@id='authenticationDivV2_otpRightLogo']")
	private WebElement authV2RightLogoPathTextField;

	// Customer Information V2

	@FindBy(xpath = "//*[text()='Information V2']")
	private WebElement custInfoV2Button;

	@FindBy(xpath = "//select[@id='customerInfoDivV2_slct']")
	private WebElement custInfoV2SelectTemplateDropdown;

	@FindBy(xpath = "//div[contains(@class,'customerInfoDivV2')]//div//a[contains(@class,'')]")
	private WebElement custInfoV2MessageLanguageDropdown;

	@FindBy(xpath = "//label[contains(text(),'EN-English')]")
	private WebElement custInfoV2MessageLanguageEnEnglishDropdownlist;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement custInfoV2MessageLanguageDefaultDropdownlist;

	@FindBy(xpath = "//input[@id='customerInfoDivV2_cssPath']")
	private WebElement custInfoV2CssPathTextField;

	@FindBy(xpath = "//input[@id='customerInfoDivV2_otpLeftLogo']")
	private WebElement custInfoV2LeftLogoPathTextField;

	@FindBy(xpath = "//input[@id='customerInfoDivV2_otpRightLogo']")
	private WebElement custInfoV2RightLogoPathTextField;

	// Screen select

	@FindBy(xpath = "//button[text()='Screen ']")
	private WebElement screenSelectButton;

	@FindBy(xpath = "//select[@id='screenSelectDiv_slct']")
	private WebElement screenSelectTemplateDropdown;

	@FindBy(xpath = "//div[contains(@class,'screenSelectDiv')]//div//a[contains(@class,'')]")
	private WebElement screenSelectMessageLanguageDropdown;

	@FindBy(xpath = "//label[contains(text(),'EN-English')]")
	private WebElement screenSelectMessageLanguageEnEnglishDropdownlist;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement screenSelectMessageLanguageDefaultDropdownlist;

	@FindBy(xpath = "//input[@id='screenSelectDiv_cssPath']")
	private WebElement screenSelectCssPathTextField;

	@FindBy(xpath = "//input[@id='screenSelectDiv_otpLeftLogo']")
	private WebElement screenSelectLeftLogoPathTextField;

	@FindBy(xpath = "//input[@id='screenSelectDiv_otpRightLogo']")
	private WebElement screenSelectRightLogoPathTextField;

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getScreensHeader() {
		return screensHeader;
	}

	public WebElement getScreensExpandPlusBtn() {
		return screensExpandPlusBtn;
	}

	public WebElement getScreensSaveButton() {
		return screensSaveButton;
	}

	public WebElement getAuthenticationV1Button() {
		return authenticationV1Button;
	}

	public WebElement getAuthV1SelectTemplateDropdown() {
		return authV1SelectTemplateDropdown;
	}

	public WebElement getAuthV1MessageLanguageDropdown() {
		return authV1MessageLanguageDropdown;
	}

	public WebElement getAuthV1MessageLanguageEnEnglishDropdownlist() {
		return authV1MessageLanguageEnEnglishDropdownlist;
	}

	public WebElement getAuthV1MessageLanguageDefaultDropdownlist() {
		return authV1MessageLanguageDefaultDropdownlist;
	}

	public WebElement getAuthV1CssPathTextField() {
		return authV1CssPathTextField;
	}

	public WebElement getAuthV1LeftLogoPathTextField() {
		return authV1LeftLogoPathTextField;
	}

	public WebElement getAuthV1RightLogoPathTextField() {
		return authV1RightLogoPathTextField;
	}

	public WebElement getCustInfoV1Button() {
		return custInfoV1Button;
	}

	public WebElement getCustInfoV1SelectTemplateDropdown() {
		return custInfoV1SelectTemplateDropdown;
	}

	public WebElement getCustInfoV1MessageLanguageDropdown() {
		return custInfoV1MessageLanguageDropdown;
	}

	public WebElement getCustInfoV1MessageLanguageEnEnglishDropdownlist() {
		return custInfoV1MessageLanguageEnEnglishDropdownlist;
	}

	public WebElement getCustInfoV1MessageLanguageDefaultDropdownlist() {
		return custInfoV1MessageLanguageDefaultDropdownlist;
	}

	public WebElement getCustInfoV1CssPathTextField() {
		return custInfoV1CssPathTextField;
	}

	public WebElement getCustInfoV1LeftLogoPathTextField() {
		return custInfoV1LeftLogoPathTextField;
	}

	public WebElement getCustInfoV1RightLogoPathTextField() {
		return custInfoV1RightLogoPathTextField;
	}

	public WebElement getAuthenticationV2Button() {
		return authenticationV2Button;
	}

	public WebElement getAuthV2SelectTemplateDropdown() {
		return authV2SelectTemplateDropdown;
	}

	public WebElement getAuthV2MessageLanguageDropdown() {
		return authV2MessageLanguageDropdown;
	}

	public WebElement getAuthV2MessageLanguageEnEnglishDropdownlist() {
		return authV2MessageLanguageEnEnglishDropdownlist;
	}

	public WebElement getAuthV2MessageLanguageDefaultDropdownlist() {
		return authV2MessageLanguageDefaultDropdownlist;
	}

	public WebElement getAuthV2CssPathTextField() {
		return authV2CssPathTextField;
	}

	public WebElement getAuthV2LeftLogoPathTextField() {
		return authV2LeftLogoPathTextField;
	}

	public WebElement getAuthV2RightLogoPathTextField() {
		return authV2RightLogoPathTextField;
	}

	public WebElement getCustInfoV2Button() {
		return custInfoV2Button;
	}

	public WebElement getCustInfoV2SelectTemplateDropdown() {
		return custInfoV2SelectTemplateDropdown;
	}

	public WebElement getCustInfoV2MessageLanguageDropdown() {
		return custInfoV2MessageLanguageDropdown;
	}

	public WebElement getCustInfoV2MessageLanguageEnEnglishDropdownlist() {
		return custInfoV2MessageLanguageEnEnglishDropdownlist;
	}

	public WebElement getCustInfoV2MessageLanguageDefaultDropdownlist() {
		return custInfoV2MessageLanguageDefaultDropdownlist;
	}

	public WebElement getCustInfoV2CssPathTextField() {
		return custInfoV2CssPathTextField;
	}

	public WebElement getCustInfoV2LeftLogoPathTextField() {
		return custInfoV2LeftLogoPathTextField;
	}

	public WebElement getCustInfoV2RightLogoPathTextField() {
		return custInfoV2RightLogoPathTextField;
	}

	public WebElement getScreenSelectButton() {
		return screenSelectButton;
	}

	public WebElement getScreenSelectTemplateDropdown() {
		return screenSelectTemplateDropdown;
	}

	public WebElement getScreenSelectMessageLanguageDropdown() {
		return screenSelectMessageLanguageDropdown;
	}

	public WebElement getScreenSelectMessageLanguageEnEnglishDropdownlist() {
		return screenSelectMessageLanguageEnEnglishDropdownlist;
	}

	public WebElement getScreenSelectMessageLanguageDefaultDropdownlist() {
		return screenSelectMessageLanguageDefaultDropdownlist;
	}

	public WebElement getScreenSelectCssPathTextField() {
		return screenSelectCssPathTextField;
	}

	public WebElement getScreenSelectLeftLogoPathTextField() {
		return screenSelectLeftLogoPathTextField;
	}

	public WebElement getScreenSelectRightLogoPathTextField() {
		return screenSelectRightLogoPathTextField;
	}

}

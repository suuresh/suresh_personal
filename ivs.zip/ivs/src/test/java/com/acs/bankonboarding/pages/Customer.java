package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Customer {

	public WebDriver driver;

	public Customer(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Customer ')]]/div[text()='Customer ']")
	private WebElement customerHeader;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Customer ')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement customerAddBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Customer ')]]//input[@placeholder='DEFAULT']")
	private WebElement customerConfigClass;

	// updated customer xpath date-14-04-2020
	// Customer fetch Mode
	@FindBy(xpath = "//div[contains(@class,'customwidth_150')]//div[1]//div[1]//div[2]//div[1]//a[1]")
	private WebElement customerFetchModeDropdown;
	
	@FindBy(xpath = "//label[contains(text(),'FILEUPLOAD')]")
	private WebElement customerFetchModeFileUpload;
	
	@FindBy(xpath = "//label[contains(text(),'SWITCH')]")
	private WebElement customerFetchModeSwitch;
	
	//cardStatusSource 
	
	@FindBy(xpath = "//div[contains(@class,'customwidth_150')]//div[contains(@class,'form-group field field-object')]//div[2]//div[1]//div[2]//div[1]//a[1]")
	private WebElement cardStatusSourceDropdown;
	
	@FindBy(xpath = "//label[contains(text(),'DB1.0')]")
	private WebElement cardStatusSourcDB1;
	
	@FindBy(xpath = "//label[contains(text(),'DB2.0')]")
	private WebElement cardStatusSourcDB2;
	
	//cacheCustomerData 
	@FindBy(xpath = "//div[contains(@class,'page__content configs')]//div[3]//div[1]//div[2]//div[1]//a[1]")
	private WebElement cacheCustomerDataDropdown;
	
	@FindBy(xpath = "//input[@id='1111']")
	private WebElement cacheCustomerDataSearchBox;
	
	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement cacheCustomerDataFirstOption;
	
	//switchUrl
	@FindBy(xpath = "//div[text()='switchUrl']/following::div/div/a[@class='button dropdown-btn is-fullwidth  ']")
	private WebElement switchUrlDropdown;
	
	@FindBy(xpath = "//input[@id='1111']")
	private WebElement switchUrlSearchBox;
	
	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement switchUrlFirstOption;
	
	//OpenPGP
	@FindBy(xpath = "//div[text()='Open PGP']/following::div/div/a[@class='button dropdown-btn is-fullwidth  ']")
	private WebElement OpenPGPDropdown;
	
	@FindBy(xpath = "//input[@id='1111']")
	private WebElement OpenPGPSearchBox;
	
	@FindBy(xpath = "//label[contains(@class,'radio-label')]")
	private WebElement OpenPGPFirstOption;
	
	

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Customer ')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement customerRemoveBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Customer ')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement customerSaveBtn;

	public WebElement getCustomerAddBtn() {
		return customerAddBtn;
	}

	public WebElement getCustomerFetchTypeDropdown() {
		return customerFetchModeDropdown;
	}

	public WebElement getCustomerRemoveBtn() {
		return customerRemoveBtn;
	}

	public WebElement getCustomerSaveBtn() {
		return customerSaveBtn;
	}

	public WebElement getCustomerHeader() {
		return customerHeader;
	}

	public WebElement getCustomerConfigClass() {
		return customerConfigClass;
	}

	public WebElement getCustomerFetchModeDropdown() {
		return customerFetchModeDropdown;
	}

	public WebElement getCustomerFetchModeFileUpload() {
		return customerFetchModeFileUpload;
	}

	public WebElement getCustomerFetchModeSwitch() {
		return customerFetchModeSwitch;
	}

	public WebElement getCardStatusSourceDropdown() {
		return cardStatusSourceDropdown;
	}

	public void setCardStatusSourceDropdown(WebElement cardStatusSourceDropdown) {
		this.cardStatusSourceDropdown = cardStatusSourceDropdown;
	}

	public WebElement getCardStatusSourcDB1() {
		return cardStatusSourcDB1;
	}

	public WebElement getCardStatusSourcDB2() {
		return cardStatusSourcDB2;
	}

	public WebElement getCacheCustomerDataDropdown() {
		return cacheCustomerDataDropdown;
	}

	public WebElement getCacheCustomerDataSearchBox() {
		return cacheCustomerDataSearchBox;
	}

	public WebElement getCacheCustomerDataFirstOption() {
		return cacheCustomerDataFirstOption;
	}

	public WebElement getSwitchUrlDropdown() {
		return switchUrlDropdown;
	}

	public WebElement getSwitchUrlSearchBox() {
		return switchUrlSearchBox;
	}

	public WebElement getSwitchUrlFirstOption() {
		return switchUrlFirstOption;
	}

	public WebElement getOpenPGPDropdown() {
		return OpenPGPDropdown;
	}

	public WebElement getOpenPGPSearchBox() {
		return OpenPGPSearchBox;
	}

	public WebElement getOpenPGPFirstOption() {
		return OpenPGPFirstOption;
	}

}

package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OTPConfig {

	public WebDriver driver;

	public OTPConfig(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'OTP Config')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')] ")
	private WebElement otpConfigAddBtn;

	@FindBy(xpath = "//input[@placeholder='otpMask']")
	private WebElement configClassTextBox;

	// otpMask
	@FindBy(xpath = "(//*[text()='otpMask']/following::div[@class='dropdown dropdown--type3 is-active']/div[1]/a[1])[1]")
	private WebElement otpMaskDropdown;

	@FindBy(xpath = "//*[@id='N']/following::label[1]")
	private WebElement numericDropdown;
	@FindBy(xpath = "//*[@id='A']/following::label[1]")
	private WebElement alphaDropdown;
	@FindBy(xpath = "//*[@id='B']/following::label[1]")
	private WebElement alphaNumericDropdown;

	// otpCategory
	@FindBy(xpath = "//*[@data-tip='otpCategory']/following::a[1]")
	private WebElement otpCategoryDropdown;

	@FindBy(xpath = "//label[contains(text(),'1')]")
	private WebElement otpCategory01Dropdown;
	@FindBy(xpath = "//label[contains(text(),'2')]")
	private WebElement otpCategory02Dropdown;

	// maxResendCount
	@FindBy(xpath = "(//*[text()='maxResendCount']/following::div/div/a[1])[1]")
	private WebElement maxResendCountDropdown;

	@FindBy(xpath = "//*[@data-tip='maxResendCount']/following::input[@id='1']/following::label[1]")
	private WebElement maxResendCount01Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxResendCount']/following::input[@id='2']/following::label[1]")
	private WebElement maxResendCount02Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxResendCount']/following::input[@id='3']/following::label[1]")
	private WebElement maxResendCount03Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxResendCount']/following::input[@id='4']/following::label[1]")
	private WebElement maxResendCount04Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxResendCount']/following::input[@id='5']/following::label[1]")
	private WebElement maxResendCount05Dropdown;

	// maxFailureCount
	@FindBy(xpath = "(//*[text()='maxFailureCount']/following::div/div/a[1])[1]")
	private WebElement maxFailureCountDropdown;

	@FindBy(xpath = "//*[@data-tip='maxFailureCount']/following::input[@id='1']/following::label[1]")
	private WebElement maxFailureCount01Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxFailureCount']/following::input[@id='2']/following::label[1]")
	private WebElement maxFailureCount02Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxFailureCount']/following::input[@id='3']/following::label[1]")
	private WebElement maxFailureCount03Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxFailureCount']/following::input[@id='4']/following::label[1]")
	private WebElement maxFailureCount04Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxFailureCount']/following::input[@id='5']/following::label[1]")
	private WebElement maxFailureCount05Dropdown;

	// Max Softblock
	@FindBy(xpath = "(//*[text()='maxSoftBlock']/following::div/div/a[1])[1]")
	private WebElement maxSoftBlockDropdown;

	@FindBy(xpath = "//*[@data-tip='maxSoftBlock']/following::input[@id='1']/following::label[1]")
	private WebElement maxSoftBlock01Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxSoftBlock']/following::input[@id='2']/following::label[1]")
	private WebElement maxSoftBlock02Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxSoftBlock']/following::input[@id='3']/following::label[1]")
	private WebElement maxSoftBlock03Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxSoftBlock']/following::input[@id='4']/following::label[1]")
	private WebElement maxSoftBlock04Dropdown;
	@FindBy(xpath = "//*[@data-tip='maxSoftBlock']/following::input[@id='5']/following::label[1]")
	private WebElement maxSoftBlock05Dropdown;

	// Force New
	@FindBy(xpath = "(//*[@data-tip='Force New']/following::a[@class='button dropdown-btn is-fullwidth  '])[1]")
	private WebElement forceNewDropdown;

	@FindBy(xpath = "//*[@data-tip='Force New']/following::a[1]/following::label[1]")
	private WebElement forceNewTrueDropdown;
	@FindBy(xpath = "//*[@data-tip='Force New']/following::a[1]/following::label[2]")
	private WebElement forceNewFalseDropdown;

	// ExpiryMin
	@FindBy(xpath = "//*[text()='expiryMin']/following::input[1]")
	private WebElement expiryMinTextField;

	// otpLength
	@FindBy(xpath = "(//*[text()='otpLength']/following::div/div/a[1])[1]")
	private WebElement otpLengthDropdown;

	@FindBy(xpath = "//*[@data-tip='otpLength']/following::input[@id='4']/following::label[1]")
	private WebElement otpLength04Dropdown;
	@FindBy(xpath = "//*[@data-tip='otpLength']/following::input[@id='6']/following::label[1]")
	private WebElement otpLength06Dropdown;
	@FindBy(xpath = "//*[@data-tip='otpLength']/following::input[@id='8']/following::label[1]")
	private WebElement otpLength08Dropdown;

	// Generate Otp Flag
	@FindBy(xpath = "//*[@data-tip='Generate Otp Flag']//following::a[1]")
	private WebElement generateOtpFlagDropdown;

	@FindBy(xpath = "//*[@data-tip='Generate Otp Flag']//following::label[contains(text(),'True')]")
	private WebElement generateOtpTrueDropdown;
	@FindBy(xpath = "//*[@data-tip='Generate Otp Flag']//following::label[contains(text(),'False')]")
	private WebElement generateOtpFalseDropdown;

	// callerId
	@FindBy(xpath = "//*[@data-tip='callerId']//following::a[1]")
	private WebElement callerIdDropdown;
	@FindBy(xpath = "//*[@data-tip='callerId']//following::input[@id='acs2']//following::label[1]")
	private WebElement callerIdACS2Dropdown;

	// Saving OTP config
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'OTP Config')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement saveBtnOtpConfig;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'OTP Config ')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement otpConfigRemoveBtn;
	
	//RetryValidationsupported
	@FindBy(xpath = "//div[contains(@class,'customwidth_148')]//div[11]//div[1]//div[2]//div[1]//a[1]")
	private WebElement RetryValidationsupportedDropdown;
	
	@FindBy(xpath = "//label[contains(text(),'True')]")
	private WebElement RetryValidationsupportedTrueRadioButton;
	
	public WebElement getRetryValidationsupportedDropdown() {
		return RetryValidationsupportedDropdown;
	}

	public WebElement getRetryValidationsupportedTrueRadioButton() {
		return RetryValidationsupportedTrueRadioButton;
	}

	public WebElement getRetryValidationsupportedFalseRadioButton() {
		return RetryValidationsupportedFalseRadioButton;
	}

	@FindBy(xpath = "//label[contains(text(),'False')]")
	private WebElement RetryValidationsupportedFalseRadioButton;

	public WebElement getOtpConfigAddBtn() {
		return otpConfigAddBtn;
	}

	public WebElement getConfigClassTextBox() {
		return configClassTextBox;
	}

	public WebElement getOtpMaskDropdown() {
		return otpMaskDropdown;
	}

	public WebElement getNumericDropdown() {
		return numericDropdown;
	}

	public WebElement getAlphaDropdown() {
		return alphaDropdown;
	}

	public WebElement getAlphaNumericDropdown() {
		return alphaNumericDropdown;
	}

	public WebElement getOtpCategoryDropdown() {
		return otpCategoryDropdown;
	}

	public WebElement getOtpCategory01Dropdown() {
		return otpCategory01Dropdown;
	}

	public WebElement getOtpCategory02Dropdown() {
		return otpCategory02Dropdown;
	}

	public WebElement getMaxResendCountDropdown() {
		return maxResendCountDropdown;
	}

	public WebElement getMaxResendCount01Dropdown() {
		return maxResendCount01Dropdown;
	}

	public WebElement getMaxResendCount02Dropdown() {
		return maxResendCount02Dropdown;
	}

	public WebElement getMaxResendCount03Dropdown() {
		return maxResendCount03Dropdown;
	}

	public WebElement getMaxResendCount04Dropdown() {
		return maxResendCount04Dropdown;
	}

	public WebElement getMaxResendCount05Dropdown() {
		return maxResendCount05Dropdown;
	}

	public WebElement getMaxFailureCountDropdown() {
		return maxFailureCountDropdown;
	}

	public WebElement getMaxFailureCount01Dropdown() {
		return maxFailureCount01Dropdown;
	}

	public WebElement getMaxFailureCount02Dropdown() {
		return maxFailureCount02Dropdown;
	}

	public WebElement getMaxFailureCount03Dropdown() {
		return maxFailureCount03Dropdown;
	}

	public WebElement getMaxFailureCount04Dropdown() {
		return maxFailureCount04Dropdown;
	}

	public WebElement getMaxFailureCount05Dropdown() {
		return maxFailureCount05Dropdown;
	}

	public WebElement getMaxSoftBlockDropdown() {
		return maxSoftBlockDropdown;
	}

	public WebElement getMaxSoftBlock01Dropdown() {
		return maxSoftBlock01Dropdown;
	}

	public WebElement getMaxSoftBlock02Dropdown() {
		return maxSoftBlock02Dropdown;
	}

	public WebElement getMaxSoftBlock03Dropdown() {
		return maxSoftBlock03Dropdown;
	}

	public WebElement getMaxSoftBlock04Dropdown() {
		return maxSoftBlock04Dropdown;
	}

	public WebElement getMaxSoftBlock05Dropdown() {
		return maxSoftBlock05Dropdown;
	}

	public WebElement getForceNewDropdown() {
		return forceNewDropdown;
	}

	public WebElement getForceNewTrueDropdown() {
		return forceNewTrueDropdown;
	}

	public WebElement getForceNewFalseDropdown() {
		return forceNewFalseDropdown;
	}

	public WebElement getExpiryMinTextField() {
		return expiryMinTextField;
	}

	public WebElement getOtpLengthDropdown() {
		return otpLengthDropdown;
	}

	public WebElement getOtpLength04Dropdown() {
		return otpLength04Dropdown;
	}

	public WebElement getOtpLength06Dropdown() {
		return otpLength06Dropdown;
	}

	public WebElement getOtpLength08Dropdown() {
		return otpLength08Dropdown;
	}

	public WebElement getGenerateOtpFlagDropdown() {
		return generateOtpFlagDropdown;
	}

	public WebElement getGenerateOtpTrueDropdown() {
		return generateOtpTrueDropdown;
	}

	public WebElement getGenerateOtpFalseDropdown() {
		return generateOtpFalseDropdown;
	}

	public WebElement getCallerIdDropdown() {
		return callerIdDropdown;
	}

	public WebElement getCallerIdACS2Dropdown() {
		return callerIdACS2Dropdown;
	}

	public WebElement getOtpConfigRemoveBtn() {
		return otpConfigRemoveBtn;
	}

	public WebElement getSaveBtnOtpConfig() {
		return saveBtnOtpConfig;
	}

}

package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LanguageDefaultPage {

	public WebDriver driver;

	public LanguageDefaultPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default ')]]/div[text()='Language Default ']")
	private WebElement languageDefaultHeader;


	@FindBy(xpath = "//div[contains(text(),'Language Default')]/a")
	private WebElement languageDefaultExpandPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement languageDefaultSaveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//fieldset[@id='root_paymentAuth']//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement languageDefaultAddPaymentAuthPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//fieldset[@id='root_nonPaymentAuth']//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement languageDefaultAddNonPaymentAuthPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//fieldset[@id='root_paymentAuth']//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement languageDefaultPaymentAuthKeyRemoveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//fieldset[@id='root_nonPaymentAuth']//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement languageDefaultNonPaymentAuthKeyRemoveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//input[@id='root_paymentAuth_0_key']")
	private WebElement languageDefaultAddPaymentAuthKeyTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//input[@id='root_paymentAuth_0_value']")
	private WebElement languageDefaultAddPaymentAuthValueTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//input[@id='root_nonPaymentAuth_0_key']")
	private WebElement languageDefaultAddNonPaymentAuthKeyTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language Default')]]//input[@id='root_nonPaymentAuth_0_value']")
	private WebElement languageDefaultAddNonPaymentAuthValueTextField;

	public WebElement getLanguageDefaultExpandPlusButton() {
		return languageDefaultExpandPlusButton;
	}

	public WebElement getLanguageDefaultSaveButton() {
		return languageDefaultSaveButton;
	}

	public WebElement getLanguageDefaultAddPaymentAuthPlusButton() {
		return languageDefaultAddPaymentAuthPlusButton;
	}

	public WebElement getLanguageDefaultAddNonPaymentAuthPlusButton() {
		return languageDefaultAddNonPaymentAuthPlusButton;
	}

	public WebElement getLanguageDefaultPaymentAuthKeyRemoveButton() {
		return languageDefaultPaymentAuthKeyRemoveButton;
	}

	public WebElement getLanguageDefaultNonPaymentAuthKeyRemoveButton() {
		return languageDefaultNonPaymentAuthKeyRemoveButton;
	}

	public WebElement getLanguageDefaultAddPaymentAuthKeyTextField() {
		return languageDefaultAddPaymentAuthKeyTextField;
	}

	public WebElement getLanguageDefaultAddPaymentAuthValueTextField() {
		return languageDefaultAddPaymentAuthValueTextField;
	}

	public WebElement getLanguageDefaultAddNonPaymentAuthKeyTextField() {
		return languageDefaultAddNonPaymentAuthKeyTextField;
	}

	public WebElement getLanguageDefaultAddNonPaymentAuthValueTextField() {
		return languageDefaultAddNonPaymentAuthValueTextField;
	}

	public WebElement getLanguageDefaultHeader() {
		return languageDefaultHeader;
	}

}

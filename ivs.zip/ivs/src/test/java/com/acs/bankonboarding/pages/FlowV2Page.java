package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlowV2Page {

	public WebDriver driver;

	public FlowV2Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2 ')]]/div[1]")
	private WebElement flowV2Header;

	@FindBy(xpath = "//div[contains(text(),'Flow V2')]/a")
	private WebElement flowV2ExpandPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement flowV2SaveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement flowV2AddConfigClassPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2')]]//div//input[@id='root_0_configClass']")
	private WebElement flowV2ConfigClassTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2')]]//div//textarea[@id='root_0_configValue']")
	private WebElement flowV2TextArea;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Flow V2')]]//div//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement flowV2ConfigClassRemoveButton;

	public WebElement getFlowV2ExpandPlusButton() {
		return flowV2ExpandPlusButton;
	}

	public WebElement getFlowV2SaveButton() {
		return flowV2SaveButton;
	}

	public WebElement getFlowV2AddConfigClassPlusButton() {
		return flowV2AddConfigClassPlusButton;
	}

	public WebElement getFlowV2ConfigClassTextField() {
		return flowV2ConfigClassTextField;
	}

	public WebElement getFlowV2TextArea() {
		return flowV2TextArea;
	}

	public WebElement getFlowV2ConfigClassRemoveButton() {
		return flowV2ConfigClassRemoveButton;
	}

	public WebElement getFlowV2Header() {
		return flowV2Header;
	}

}

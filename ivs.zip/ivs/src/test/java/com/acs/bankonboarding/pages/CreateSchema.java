package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateSchema {

	public WebDriver driver;

	public CreateSchema(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@placeholder='hostName']")
	private WebElement hostNameTextField;

	@FindBy(xpath = "//input[@placeholder='port']")
	private WebElement portTextField;

	@FindBy(xpath = "//input[@placeholder='userName']")
	private WebElement userNameTextField;

	@FindBy(xpath = "//input[@placeholder='password']")
	private WebElement passwordTextField;

	@FindBy(xpath = "(//div[text()='Data Center']/following::div[@class='dropdown dropdown--type3 is-active'])[1]")
	private WebElement dataCenterDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement dataCenterSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement dataCenterFirstRadioBtn;

	@FindBy(xpath = "(//div[text()='Data Center']/following::div[@class='dropdown dropdown--type3 is-active'])[2]")
	private WebElement databaseTypeDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement databaseTypeSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement databaseTypeFirstRadioBtn;

	@FindBy(xpath = "//a[text()='Create Schema']")
	private WebElement createSchemeButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement cancelButton;

	public WebElement getHostNameTextField() {
		return hostNameTextField;
	}

	public WebElement getPortTextField() {
		return portTextField;
	}

	public WebElement getUserNameTextField() {
		return userNameTextField;
	}

	public WebElement getPasswordTextField() {
		return passwordTextField;
	}

	public WebElement getDataCenterDropdown() {
		return dataCenterDropdown;
	}

	public WebElement getDataCenterSearchBox() {
		return dataCenterSearchBox;
	}

	public WebElement getDataCenterFirstRadioBtn() {
		return dataCenterFirstRadioBtn;
	}

	public WebElement getDatabaseTypeDropdown() {
		return databaseTypeDropdown;
	}

	public WebElement getDatabaseTypeSearchBox() {
		return databaseTypeSearchBox;
	}

	public WebElement getDatabaseTypeFirstRadioBtn() {
		return databaseTypeFirstRadioBtn;
	}

	public WebElement getCreateSchemeButton() {
		return createSchemeButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

}

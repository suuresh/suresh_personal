package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LanguageEnUsPage {

	public WebDriver driver;

	public LanguageEnUsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US ')]]/div[text()='Language en-US ']")
	private WebElement languageEnUsHeader;

	@FindBy(xpath = "//div[contains(text(),'Language en-US')]/a")
	private WebElement languageEnUsExpandPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement languageEnUsSaveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//fieldset[@id='root_paymentAuth']//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement languageEnUsAddPaymentAuthPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//fieldset[@id='root_nonPaymentAuth']//button[contains(@class,'btn btn-info btn-add col-xs-12')]")
	private WebElement languageEnUsAddNonPaymentAuthPlusButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//fieldset[@id='root_paymentAuth']//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement languageEnUsPaymentAuthKeyRemoveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//fieldset[@id='root_nonPaymentAuth']//button[contains(@class,'btn btn-danger array-item-remove')]")
	private WebElement languageEnUsNonPaymentAuthKeyRemoveButton;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//input[@id='root_paymentAuth_0_key']")
	private WebElement languageEnUsAddPaymentAuthKeyTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//input[@id='root_paymentAuth_0_value']")
	private WebElement languageEnUsAddPaymentAuthValueTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//input[@id='root_nonPaymentAuth_0_key']")
	private WebElement languageEnUsAddNonPaymentAuthKeyTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Language en-US')]]//input[@id='root_nonPaymentAuth_0_value']")
	private WebElement languageEnUsAddNonPaymentAuthValueTextField;

	public WebElement getLanguageEnUsExpandPlusButton() {
		return languageEnUsExpandPlusButton;
	}

	public WebElement getLanguageEnUsSaveButton() {
		return languageEnUsSaveButton;
	}

	public WebElement getLanguageEnUsAddPaymentAuthPlusButton() {
		return languageEnUsAddPaymentAuthPlusButton;
	}

	public WebElement getLanguageEnUsAddNonPaymentAuthPlusButton() {
		return languageEnUsAddNonPaymentAuthPlusButton;
	}

	public WebElement getLanguageEnUsPaymentAuthKeyRemoveButton() {
		return languageEnUsPaymentAuthKeyRemoveButton;
	}

	public WebElement getLanguageEnUsNonPaymentAuthKeyRemoveButton() {
		return languageEnUsNonPaymentAuthKeyRemoveButton;
	}

	public WebElement getLanguageEnUsAddPaymentAuthKeyTextField() {
		return languageEnUsAddPaymentAuthKeyTextField;
	}

	public WebElement getLanguageEnUsAddPaymentAuthValueTextField() {
		return languageEnUsAddPaymentAuthValueTextField;
	}

	public WebElement getLanguageEnUsAddNonPaymentAuthKeyTextField() {
		return languageEnUsAddNonPaymentAuthKeyTextField;
	}

	public WebElement getLanguageEnUsAddNonPaymentAuthValueTextField() {
		return languageEnUsAddNonPaymentAuthValueTextField;
	}

	public WebElement getLanguageEnUsHeader() {
		return languageEnUsHeader;
	}

}

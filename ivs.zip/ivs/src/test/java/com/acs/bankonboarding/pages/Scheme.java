package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Scheme {
	public WebDriver driver;

	public Scheme(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Scheme Header 
	@FindBy(xpath = "//div[text()='Please enable applicable Scheme']")
	private WebElement schemeHeader ;
	
	@FindBy(id = "master")
	private WebElement schemeEnableMasterChkbox;

	@FindBy(xpath = "(//div[contains(text(),'Scheme Mastercard ')]/a[1])[1]")
	private WebElement schemeMasterAddButton;

	@FindBy(xpath = "(//div[@data-tip='cardNetworkId']/following::div/div/a)[1]")
	private WebElement masterCardNetworkIdDropdown;

	@FindBy(xpath = "//label[contains(text(),'MASTER')]")
	private WebElement masterCardNetworkIdRadioBtn;

	@FindBy(xpath = "(//div[@data-tip='cardNetworkName']/following::div/div/a)[1]")
	private WebElement masterCardNetworkNameDropdown;

	@FindBy(xpath = "//label[contains(text(),'MASTER')]")
	private WebElement masterCardNetworkNameRadioBtn;

	// 2.O Enabled?
	@FindBy(xpath = "//select[@id='root_cavvInfo_legacyCheck2']")
	private WebElement masterEnable2dotODropdown;

	@FindBy(xpath = "//input[@id='root_cavvInfo_acsOperatorID']")
	private WebElement masterAcsOperatorIDTextField;

	@FindBy(id = "root_cavvInfo_acsReferenceNumber")
	private WebElement masterAcsReferenceNumberTextField;

	@FindBy(id = "root_cavvInfo_psImageUrl")
	private WebElement masterPsImageUrlTextField;

	// acsRreqClient
	@FindBy(xpath = "//div[text()='acsRreqClient']//following::a[1]")
	private WebElement masterAcsRreqClientDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement masterAcsRreqClientSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement masterAcsRreqClientFirstRadioBtn;

	@FindBy(xpath = "//label[@for='ep://acsRreq-client-wibmomaster']")
	private WebElement masterAcsRreqClientWibmoRadioBtn;

	// acsSigningCert
	@FindBy(xpath = "//div[text()='acsSigningCert']//following::a[1]")
	private WebElement masterAcsSigningCertDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement masterAcsSigningCertSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement masterAcsSigningCertFirstRadioBtn;

	@FindBy(id = "cert://acsSigning-cert-wibmomaster")
	private WebElement masterAcsSigningCertwibmoRadioBtn;

	// cavvInfo.type
	@FindBy(xpath = "//div[text()='cavvInfo.type']/following::span[text()='Select']")
	private WebElement masterCavvInfoTypeDropdown;

	@FindBy(xpath = "//label[contains(text(),'SPA1_HMAC')]")
	private WebElement cavvInfoTypeSPA1_HMACRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'SPA1_CVC2')]")
	private WebElement cavvInfoTypeSPA1_CVC2RadioBtn;

	@FindBy(xpath = "//label[contains(text(),'SPA2')]")
	private WebElement cavvInfoTypeSPA2RadioBtn;

	// cavvInfo.dataFormat
	@FindBy(xpath = "(//div[@data-tip='cavvInfo.dataFormat']//following::span[2])[1]")
	private WebElement cavvInfodataFormatTypeDropdown;

	@FindBy(xpath = "//label[@for='PAN|DSTxnID|AMOUNT|CUR']")
	private WebElement cavvInfodataFomatPAN_DSTxnID_AMOUNT_CURRadioBtn;

	// hmacKey.keyType
	@FindBy(xpath = "//div[@data-tip='hmacKey.keyType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement hmacKeykeyTypeDropDown;

	@FindBy(xpath = "//div[@data-tip='hmacKey.keyType']//following::label[@for='SDES']")
	private WebElement hmacKeykeyTypeSDESRadioBtn;

	// hmacKey.providerType
	@FindBy(xpath = "//div[@data-tip='hmacKey.providerType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement hmacKeyProviderTypeDropDown;

	@FindBy(xpath = "//div[@data-tip='hmacKey.keyType']//following::label[@for='HK_HC']")
	private WebElement hmacKeyProviderTypeHK_HCRadioBtn;

	// HmacKey.KeyAlias
	@FindBy(xpath = "//input[@placeholder='hmacKey.keyAlias']")
	private WebElement hmacKey_KeyAliasTextField;

	// hmacKey.encMode
	@FindBy(xpath = "//div[@data-tip='hmacKey.encMode']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement hmacKey_encModeDropdown;

	@FindBy(xpath = "//div[@data-tip='hmacKey.keyType']//following::label[@for='09']")
	private WebElement hmacKey_encMode09RadioBtn;

	// hmacKey.algorithm
	@FindBy(xpath = "//div[@data-tip='hmacKey.algorithm']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement hmacKey_algorithmDropdown;

	@FindBy(xpath = "//div[@data-tip='hmacKey.algorithm']//following::label[@for='02']")
	private WebElement hmacKey_algorithm02RadioBtn;

	// Key A cavvInfo.keyA.keyType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.keyType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyA_keyTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.keyType']//following::label[@for='SDES']")
	private WebElement cavvInfo_keyA_keyType_SDES_RadioBtn;

	// cavvInfo.keyA.providerType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.providerType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyA_providerTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.providerType']//following::label[@for='HK_AC']")
	private WebElement cavvInfo_keyA_providerType_HK_ACRadioBtn;

	// CavvInfo.KeyA.KeyAlias
	@FindBy(xpath = "//input[@placeholder='cavvInfo.keyA.keyAlias']")
	private WebElement CavvInfo_KeyA_KeyAliasTextField;

	// cavvInfo.keyA.encMode
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.encMode']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyA_encModeTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.encMode']//following::label[@for='09']")
	private WebElement cavvInfo_keyA_encModeType_09RadioBtn;

	// CavvInfo.KeyA.KeyValue
	@FindBy(xpath = "//input[@placeholder='cavvInfo.keyA.keyValue']")
	private WebElement CavvInfo_KeyA_KeyValueTextField;

	// Key B cavvInfo.keyB.keyType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.keyType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyB_keyTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.keyType']//following::label[@for='SDES']")
	private WebElement cavvInfo_keyB_keyType_SDES_RadioBtn;

	// cavvInfo.keyB.providerType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.providerType']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyB_providerTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.providerType']//following::label[@for='HK_AC']")
	private WebElement cavvInfo_keyB_providerType_HK_ACRadioBtn;

	// CavvInfo.KeyB.KeyAlias
	@FindBy(xpath = "//input[@placeholder='cavvInfo.keyB.keyAlias']")
	private WebElement CavvInfo_KeyB_KeyAliasTextField;

	// cavvInfo.keyB.encMode
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.encMode']//following::div[@class='dropdown dropdown--type3 is-active'][1]//a")
	private WebElement cavvInfo_keyB_encModeTypeDropdown;

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.encMode']//following::label[@for='09']")
	private WebElement cavvInfo_keyB_encModeType_09RadioBtn;

	// CavvInfo.KeyB.KeyValue
	@FindBy(xpath = "//input[@placeholder='cavvInfo.keyB.keyValue']")
	private WebElement CavvInfo_KeyB_KeyValueTextField;

	// 1.0 Enabled

	@FindBy(id = "root_legacyCavvInfo_legacyCheck")
	private WebElement enable1dotODropdown;

	// Legacy acsXmlSigningCert
	@FindBy(xpath = "//div[text()='acsXmlSigningCert']/following::a[1]")
	private WebElement legacyAcsXmlSigningCertDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement acsXmlSigningCertSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement acsXmlSigningCertFirstRadioBtn;

	// legacy CavvInfo.type
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.type']/following::a[1]")
	private WebElement legacyCavvInfoDropdown;

	@FindBy(xpath = "//label[contains(text(),'SPA1_HMAC')]")
	private WebElement legacyCavvInfoSPA1_HMACRadioBtn;

	@FindBy(xpath = "//label[contains(text(),'SPA1_CVC')]")
	private WebElement legacyCavvInfoSPA1_CVCRadioBtn;

	// legacy CavvInfo.dataFormat
	@FindBy(xpath = "//div[contains(text(),'legacyCavvInfo.dataFormat')]/following::span[1]")
	private WebElement legacyCavvInfoDataFormatDropdown;

	@FindBy(xpath = "//label[@for='PAN|DSTxnID|AMOUNT|CUR']")
	private WebElement PAN_DSTxnID_AMOUNT_CURRadioBtn;

	// Legacy hmacKey.keyType
	@FindBy(xpath = "//div[@data-tip='hmacKey.keyType']/following::span[1]")
	private WebElement legacyHmacKeyKeyTypeDropdown;

	@FindBy(xpath = "//label[@for='SDES']")
	private WebElement legacySDESRadioBtn;

	// Legacy hmacKey.providerType
	@FindBy(xpath = "//div[@data-tip='hmacKey.providerType']/following::span[1]")
	private WebElement legacyHmacKeyProviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_HC']")
	private WebElement legacyHKHCRadiobtn;

	// Legacy HmacKey.KeyAlias
	@FindBy(xpath = "//input[@id='root_legacyCavvInfo_hmacKey_keyAlias']")
	private WebElement legacyHmacKeyKeyAliasTextField;

	// Legacy hmacKey.encMode
	@FindBy(xpath = "//div[@data-tip='hmacKey.encMode']/following::a[1]")
	private WebElement legacyhmacKeyencModeDropdown;

	@FindBy(xpath = "//label[@for='09']")
	private WebElement legacyhmacKeyencMode09RadioBtn;

	// hmacKey.algorithm
	@FindBy(xpath = "//div[@data-tip='hmacKey.algorithm']/following::a[1]")
	private WebElement legacyHmacKeyAlgorithmDropdown;

	@FindBy(xpath = "//label[@for='02']")
	private WebElement legacyHmacKeyAlgorithm02RadioBtn;

	// Key A legacyCavvInfo.keyA.keyType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.keyType']/following::span[1]")
	private WebElement legacyCavvInfKeyAkeyTypeDropdown;

	@FindBy(xpath = "//*[@for='SDES']")
	private WebElement legacyCavvInfKeyAkeySDESRadioBtn;

	// legacyCavvInfo.keyA.providerType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.providerType']/following::span[1]")
	private WebElement legacyCavvInfokeyAproviderTypeDropdown;

	@FindBy(xpath = "//*[@for='HK_AC']")
	private WebElement legacyCavvInfokeyAproviderTypeHK_ACRadioBtn;

	// LegacyCavvInfo.KeyA.KeyAlias
	@FindBy(xpath = "//input[@id='root_legacyCavvInfo_keyA_keyAlias']")
	private WebElement LegacyCavvInfoKeyAKeyAliasTextField;

	// legacyCavvInfo.keyA.encMode
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.encMode']/following::span[1]")
	private WebElement legacyCavvInfokeyAencModeDropdown;

	@FindBy(xpath = "//*[@for='09']")
	private WebElement legacyCavvInfokeyAencMode09RadioBtn;

	// LegacyCavvInfo.KeyA.KeyValue
	@FindBy(xpath = "//input[@id='root_legacyCavvInfo_keyA_keyValue']")
	private WebElement LegacyCavvInfoKeyAKeyValueTextField;

	// Key B legacyCavvInfo.keyB.keyType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.keyType']/following::span[1]")
	private WebElement legacyCavvInfokeyBkeyTypeDropdown;

	@FindBy(xpath = "//*[@for='SDES']")
	private WebElement legacyCavvInfokeyBkeyTypeSDESRadioBtn;

	// legacyCavvInfo.keyB.providerType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.providerType']/following::span[1]")
	private WebElement legacyCavvInfokeyBproviderTypeDropdown;

	@FindBy(xpath = "//*[@for='HK_AC']")
	private WebElement legacyCavvInfokeyBproviderTypeHK_ACRadioBtn;

	// LegacyCavvInfo.KeyB.KeyAlias
	@FindBy(xpath = "//input[@id='root_legacyCavvInfo_keyB_keyAlias']")
	private WebElement legacyCavvInfoKeyBKeyAliasTextField;

	// legacyCavvInfo.keyB.encMode
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.encMode']/following::span[1]")
	private WebElement legacyCavvInfokeyBencModeDropdown;

	@FindBy(xpath = "//*[@for='09']")
	private WebElement legacyCavvInfokeyBencMode09RadioBtn;

	@FindBy(xpath = "//input[@id='root_legacyCavvInfo_keyB_keyValue']")
	private WebElement LegacyCavvInfoKeyBKeyValueTextField;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Scheme Mastercard ')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement masterSchemeSaveBtn;

	// Visa Scheme

	@FindBy(id = "visa")
	private WebElement schemeEnableViasChkbox;

	@FindBy(xpath = "(//div[@class='page__content configs'][div[contains(text(),'Scheme Visa')]]//following::a[1])[1]")
	private WebElement schemeVisaAddButton;

	// cardNetworkId
	@FindBy(xpath = "//div[@data-tip='cardNetworkId']//following::a[1]")
	private WebElement visaCardNetworkIdDropdown;

	@FindBy(xpath = "//label[@for='VISA']")
	private WebElement visaCardNetworkIdVisaRadioBtn;

	// cardNetworkName
	@FindBy(xpath = "//div[@data-tip='cardNetworkName']//following::a[1]")
	private WebElement visaCardNetworkNameDropdown;

	@FindBy(xpath = "//label[@for='VISA']")
	private WebElement visaCardNetworkNameVisaRadioBtn;

	// Visa 2.0 Enable

	@FindBy(id = "root_cavvInfo_legacyCheck2")
	private WebElement visaCard2dot0EnableDropdown;

	@FindBy(id = "root_cavvInfo_acsOperatorID")
	private WebElement visaAcsOperatorIDTextField;

	@FindBy(id = "root_cavvInfo_acsReferenceNumber")
	private WebElement visaAcsReferenceNumberTextField;

	@FindBy(id = "root_cavvInfo_psImageUrl")
	private WebElement visaPsImageUrlTextField;

	// cavvInfo.type
	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Please enable applicable Scheme')]]//following::div[text()='Scheme Visa ']/following::*[@data-tip='cavvInfo.type']/following::a[1]")
	private WebElement visaCavvInfoTypeDropdown;

	@FindBy(xpath = "//label[@for='CAVV']")
	private WebElement visaCavvRadioBtn;

	// cavvInfo.dataFormat
	@FindBy(xpath = "//div[@data-tip='cavvInfo.dataFormat']/following::span[1]")
	private WebElement visaCavvInfoDataFormatDropdown;

	@FindBy(xpath = "//label[@for='PAN|DSTxnID|AMOUNT|CUR']")
	private WebElement visaPanDstxnidAmountCurRadioBtn;

	// Key A cavvInfo.keyA.keyType

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.keyType']/following::span[1]")
	private WebElement visaCavvInfoKeyAKeyTypeDropdown;

	@FindBy(xpath = "//label[@for='SDES']")
	private WebElement visaSDESRadioBtn;

	// cavvInfo.keyA.providerType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.providerType']/following::span[1]")
	private WebElement visaCavvInfoKeyAProviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_AC']")
	private WebElement visaHK_ACRadioBtn;

	// CavvInfo.KeyA.KeyAlias
	@FindBy(id = "root_cavvInfo_keyA_keyAlias")
	private WebElement visaCavvInfoKeyAKeyAliasTextField;

	// cavvInfo.keyA.encMode
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyA.encMode']/following::span[1]")
	private WebElement visaCavvInfoKeyAEncModeDropdown;

	@FindBy(xpath = "//label[@for='09']")
	private WebElement visa09RadioBtn;

	// CavvInfo.KeyA.KeyValue
	@FindBy(id = "root_cavvInfo_keyA_keyValue")
	private WebElement visaCavvInfoKeyAKeyValueTextField;

	// Key B cavvInfo.keyB.keyType

	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.keyType']/following::span[1]")
	private WebElement visaCavvInfoKeyBKeyTypeDropdown;

	@FindBy(xpath = "//label[@for='SDES']")
	private WebElement visaSDESKeyBRadioBtn;

	// cavvInfo.keyB.providerType
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.providerType']/following::span[1]")
	private WebElement visaCavvInfoKeyBProviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_AC']")
	private WebElement visaHK_ACKeyBRadioBtn;

	// CavvInfo.KeyB.KeyAlias
	@FindBy(id = "root_cavvInfo_keyB_keyAlias")
	private WebElement visaCavvInfoKeyBKeyAliasTextField;

	// cavvInfo.keyB.encMode
	@FindBy(xpath = "//div[@data-tip='cavvInfo.keyB.encMode']/following::span[1]")
	private WebElement visaCavvInfoKeyBEncModeDropdown;

	@FindBy(xpath = "//label[@for='09']")
	private WebElement visa09KeyBRadioBtn;

	// CavvInfo.KeyB.KeyValue
	@FindBy(id = "root_cavvInfo_keyB_keyValue")
	private WebElement visaCavvInfoKeyBKeyValueTextField;

	// acsRreqClient
	@FindBy(xpath = "//div[text()='acsRreqClient']/following::a[1]")
	private WebElement visaAcsRreqClientDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement visaAcsRreqClientSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement visaAcsRreqClientFirstRadioBtn;

	// acsSigningCert
	@FindBy(xpath = "//div[text()='acsSigningCert']/following::a[1]")
	private WebElement visaAcsSigningCertDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement visaAcsSigningCertSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement visaAcsSigningCertFirstRadioBtn;

	// Visa 1.0 Enable

	@FindBy(id = "root_legacyCavvInfo_legacyCheck")
	private WebElement visaCard1dot0EnableDropdown;

	// legacyCavvInfo.type
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.type']/following::span[1]")
	private WebElement visaLegacyCavvInfoTypeDropdown;

	@FindBy(xpath = "//label[@for='CAVV']")
	private WebElement visaLegacyCavvRadioBtn;

	// legacyCavvInfo.dataFormat
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.dataFormat']/following::a[1]")
	private WebElement visaLegacyCavvInfoDataFormatTypeDropdown;

	@FindBy(xpath = "//label[@for='PAN|DSTxnID|AMOUNT|CUR']")
	private WebElement visaLegacyPanDstxnidAmountCurRadioBtn;

	// Key A legacyCavvInfo.keyA.keyType

	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.keyType']/following::span[1]")
	private WebElement visalegacyCavvInfokeyAkeyTypeDropdown;

	@FindBy(xpath = "//label[@for='SDES']")
	private WebElement visaLegacySDESRadioBtn;

	// legacyCavvInfo.keyA.providerType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.providerType']/following::span[1]")
	private WebElement visaLegacyCavvInfokeyAProviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_AC']")
	private WebElement visaLegacyHK_ACRadioBtn;

	// LegacyCavvInfo.KeyA.KeyAlias
	@FindBy(id = "root_legacyCavvInfo_keyA_keyAlias")
	private WebElement visaLegacyCavvInfoKeyAKeyAliasTextField;

	// legacyCavvInfo.keyA.encMode
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyA.encMode']/following::span[1]")
	private WebElement visalegacyCavvInfokeyAEncModeDropdown;

	@FindBy(xpath = "//label[@for='09']")
	private WebElement visaLegacy09RadioBtn;

	@FindBy(id = "root_legacyCavvInfo_keyA_keyValue")
	private WebElement visaRoot_legacyCavvInfo_keyA_keyValueTextField;

	// Key B legacyCavvInfo.keyB.keyType

	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.keyType']/following::span[1]")
	private WebElement visalegacyCavvInfokeyBkeyTypeDropdown;

	@FindBy(xpath = "//label[@for='SDES']")
	private WebElement visaLegacySDESKeyBRadioBtn;

	// legacyCavvInfo.keyB.providerType
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.providerType']/following::span[1]")
	private WebElement visaLegacyCavvInfokeyBProviderTypeDropdown;

	@FindBy(xpath = "//label[@for='HK_AC']")
	private WebElement visaLegacyHK_ACKeyBRadioBtn;

	// LegacyCavvInfo.KeyB.KeyAlias
	@FindBy(id = "root_legacyCavvInfo_keyB_keyAlias")
	private WebElement visaLegacyCavvInfoKeyBKeyAliasTextField;

	// legacyCavvInfo.keyB.encMode
	@FindBy(xpath = "//div[@data-tip='legacyCavvInfo.keyB.encMode']/following::span[1]")
	private WebElement visalegacyCavvInfokeyBEncModeDropdown;

	@FindBy(xpath = "//label[@for='09']")
	private WebElement visaLegacy09KeyBRadioBtn;

	// LegacyCavvInfo.KeyB.KeyValue
	@FindBy(id = "root_legacyCavvInfo_keyB_keyValue")
	private WebElement visaroot_legacyCavvInfo_keyB_keyValueTextField;

	// acsXmlSigningCert
	@FindBy(xpath = "//*[text()='acsXmlSigningCert']/following::a[1]")
	private WebElement viasAcsXmlSigningCertDropdown;

	@FindBy(xpath = "//*[@placeholder='Search']")
	private WebElement viasAcsXmlSigningCertSearchBox;

	@FindBy(xpath = "//input[@placeholder='Search']//following::label[@class='radio-label']")
	private WebElement viasAcsXmlSigningCertFirstRadioBtn;

	@FindBy(xpath = "//div[@class='page__content configs'][div[contains(text(),'Scheme Visa')]]//div[contains(@class,'page__header level')]//a[contains(@class,'')][contains(text(),'Save')]")
	private WebElement visaSchemeSaveBtn;

	public WebElement getSchemeEnableMasterChkbox() {
		return schemeEnableMasterChkbox;
	}

	public WebElement getSchemeMasterAddButton() {
		return schemeMasterAddButton;
	}

	public WebElement getMasterCardNetworkIdDropdown() {
		return masterCardNetworkIdDropdown;
	}

	public WebElement getMasterCardNetworkIdRadioBtn() {
		return masterCardNetworkIdRadioBtn;
	}

	public WebElement getMasterCardNetworkNameDropdown() {
		return masterCardNetworkNameDropdown;
	}

	public WebElement getMasterCardNetworkNameRadioBtn() {
		return masterCardNetworkNameRadioBtn;
	}

	public WebElement getMasterEnable2dotODropdown() {
		return masterEnable2dotODropdown;
	}

	public WebElement getMasterAcsOperatorIDTextField() {
		return masterAcsOperatorIDTextField;
	}

	public WebElement getMasterAcsReferenceNumberTextField() {
		return masterAcsReferenceNumberTextField;
	}

	public WebElement getMasterPsImageUrlTextField() {
		return masterPsImageUrlTextField;
	}

	public WebElement getMasterAcsRreqClientDropdown() {
		return masterAcsRreqClientDropdown;
	}

	public WebElement getMasterAcsRreqClientWibmoRadioBtn() {
		return masterAcsRreqClientWibmoRadioBtn;
	}

	public WebElement getMasterAcsSigningCertDropdown() {
		return masterAcsSigningCertDropdown;
	}

	public WebElement getMasterAcsSigningCertwibmoRadioBtn() {
		return masterAcsSigningCertwibmoRadioBtn;
	}

	public WebElement getMasterCavvInfoTypeDropdown() {
		return masterCavvInfoTypeDropdown;
	}

	public WebElement getCavvInfoTypeSPA1_HMACRadioBtn() {
		return cavvInfoTypeSPA1_HMACRadioBtn;
	}

	public WebElement getCavvInfoTypeSPA1_CVC2RadioBtn() {
		return cavvInfoTypeSPA1_CVC2RadioBtn;
	}

	public WebElement getCavvInfoTypeSPA2RadioBtn() {
		return cavvInfoTypeSPA2RadioBtn;
	}

	public WebElement getCavvInfodataFormatTypeDropdown() {
		return cavvInfodataFormatTypeDropdown;
	}

	public WebElement getCavvInfodataFomatPAN_DSTxnID_AMOUNT_CURRadioBtn() {
		return cavvInfodataFomatPAN_DSTxnID_AMOUNT_CURRadioBtn;
	}

	public WebElement getEnable1dotODropdown() {
		return enable1dotODropdown;
	}

	public WebElement getLegacyAcsXmlSigningCertDropdown() {
		return legacyAcsXmlSigningCertDropdown;
	}

	public WebElement getLegacyCavvInfoDropdown() {
		return legacyCavvInfoDropdown;
	}

	public WebElement getLegacyCavvInfoSPA1_HMACRadioBtn() {
		return legacyCavvInfoSPA1_HMACRadioBtn;
	}

	public WebElement getLegacyCavvInfoSPA1_CVCRadioBtn() {
		return legacyCavvInfoSPA1_CVCRadioBtn;
	}

	public WebElement getLegacyCavvInfoDataFormatDropdown() {
		return legacyCavvInfoDataFormatDropdown;
	}

	public WebElement getPAN_DSTxnID_AMOUNT_CURRadioBtn() {
		return PAN_DSTxnID_AMOUNT_CURRadioBtn;
	}

	public WebElement getLegacyHmacKeyKeyTypeDropdown() {
		return legacyHmacKeyKeyTypeDropdown;
	}

	public WebElement getLegacySDESRadioBtn() {
		return legacySDESRadioBtn;
	}

	public WebElement getLegacyHmacKeyProviderTypeDropdown() {
		return legacyHmacKeyProviderTypeDropdown;
	}

	public WebElement getLegacyHKHCRadiobtn() {
		return legacyHKHCRadiobtn;
	}

	public WebElement getLegacyHmacKeyKeyAliasTextField() {
		return legacyHmacKeyKeyAliasTextField;
	}

	public WebElement getLegacyhmacKeyencModeDropdown() {
		return legacyhmacKeyencModeDropdown;
	}

	public WebElement getLegacyhmacKeyencMode09RadioBtn() {
		return legacyhmacKeyencMode09RadioBtn;
	}

	public WebElement getlegacyHmacKeyAlgorithmDropdown() {
		return legacyHmacKeyAlgorithmDropdown;
	}

	public WebElement getLegacyHmacKeyAlgorithm02RadioBtn() {
		return legacyHmacKeyAlgorithm02RadioBtn;
	}

	public WebElement getLegacyCavvInfKeyAkeyTypeDropdown() {
		return legacyCavvInfKeyAkeyTypeDropdown;
	}

	public WebElement getLegacyCavvInfKeyAkeySDESRadioBtn() {
		return legacyCavvInfKeyAkeySDESRadioBtn;
	}

	public WebElement getLegacyCavvInfokeyAproviderTypeDropdown() {
		return legacyCavvInfokeyAproviderTypeDropdown;
	}

	public WebElement getLegacyCavvInfokeyAproviderTypeHK_ACRadioBtn() {
		return legacyCavvInfokeyAproviderTypeHK_ACRadioBtn;
	}

	public WebElement getLegacyCavvInfoKeyAKeyAliasTextField() {
		return LegacyCavvInfoKeyAKeyAliasTextField;
	}

	public WebElement getLegacyCavvInfokeyAencModeDropdown() {
		return legacyCavvInfokeyAencModeDropdown;
	}

	public WebElement getLegacyCavvInfokeyAencMode09RadioBtn() {
		return legacyCavvInfokeyAencMode09RadioBtn;
	}

	public WebElement getLegacyCavvInfoKeyAKeyValueTextField() {
		return LegacyCavvInfoKeyAKeyValueTextField;
	}

	public WebElement getLegacyCavvInfokeyBkeyTypeDropdown() {
		return legacyCavvInfokeyBkeyTypeDropdown;
	}

	public WebElement getLegacyCavvInfokeyBkeyTypeSDESRadioBtn() {
		return legacyCavvInfokeyBkeyTypeSDESRadioBtn;
	}

	public WebElement getLegacyCavvInfokeyBproviderTypeDropdown() {
		return legacyCavvInfokeyBproviderTypeDropdown;
	}

	public WebElement getLegacyCavvInfokeyBproviderTypeHK_ACRadioBtn() {
		return legacyCavvInfokeyBproviderTypeHK_ACRadioBtn;
	}

	public WebElement getLegacyCavvInfoKeyBKeyAliasTextField() {
		return legacyCavvInfoKeyBKeyAliasTextField;
	}

	public WebElement getLegacyCavvInfokeyBencModeDropdown() {
		return legacyCavvInfokeyBencModeDropdown;
	}

	public WebElement getLegacyCavvInfokeyBencMode09RadioBtn() {
		return legacyCavvInfokeyBencMode09RadioBtn;
	}

	public WebElement getLegacyCavvInfoKeyBKeyValueTextField() {
		return LegacyCavvInfoKeyBKeyValueTextField;
	}

	public WebElement getSchemeEnableViasChkbox() {
		return schemeEnableViasChkbox;
	}

	public WebElement getSchemeVisaAddButton() {
		return schemeVisaAddButton;
	}

	public WebElement getVisaCardNetworkIdDropdown() {
		return visaCardNetworkIdDropdown;
	}

	public WebElement getVisaCardNetworkIdVisaRadioBtn() {
		return visaCardNetworkIdVisaRadioBtn;
	}

	public WebElement getVisaCardNetworkNameDropdown() {
		return visaCardNetworkNameDropdown;
	}

	public WebElement getVisaCardNetworkNameVisaRadioBtn() {
		return visaCardNetworkNameVisaRadioBtn;
	}

	public WebElement getVisaCard2dot0EnableDropdown() {
		return visaCard2dot0EnableDropdown;
	}

	public WebElement getVisaAcsOperatorIDTextField() {
		return visaAcsOperatorIDTextField;
	}

	public WebElement getVisaAcsReferenceNumberTextField() {
		return visaAcsReferenceNumberTextField;
	}

	public WebElement getVisaPsImageUrlTextField() {
		return visaPsImageUrlTextField;
	}

	public WebElement getVisaCavvInfoTypeDropdown() {
		return visaCavvInfoTypeDropdown;
	}

	public WebElement getVisaCavvRadioBtn() {
		return visaCavvRadioBtn;
	}

	public WebElement getVisaCavvInfoDataFormatDropdown() {
		return visaCavvInfoDataFormatDropdown;
	}

	public WebElement getVisaPanDstxnidAmountCurRadioBtn() {
		return visaPanDstxnidAmountCurRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyAKeyTypeDropdown() {
		return visaCavvInfoKeyAKeyTypeDropdown;
	}

	public WebElement getVisaSDESRadioBtn() {
		return visaSDESRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyAProviderTypeDropdown() {
		return visaCavvInfoKeyAProviderTypeDropdown;
	}

	public WebElement getVisaHK_ACRadioBtn() {
		return visaHK_ACRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyAKeyAliasTextField() {
		return visaCavvInfoKeyAKeyAliasTextField;
	}

	public WebElement getVisaCavvInfoKeyAEncModeDropdown() {
		return visaCavvInfoKeyAEncModeDropdown;
	}

	public WebElement getVisa09RadioBtn() {
		return visa09RadioBtn;
	}

	public WebElement getVisaCavvInfoKeyAKeyValueTextField() {
		return visaCavvInfoKeyAKeyValueTextField;
	}

	public WebElement getVisaCavvInfoKeyBKeyTypeDropdown() {
		return visaCavvInfoKeyBKeyTypeDropdown;
	}

	public WebElement getVisaSDESKeyBRadioBtn() {
		return visaSDESKeyBRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyBProviderTypeDropdown() {
		return visaCavvInfoKeyBProviderTypeDropdown;
	}

	public WebElement getVisaHK_ACKeyBRadioBtn() {
		return visaHK_ACKeyBRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyBKeyAliasTextField() {
		return visaCavvInfoKeyBKeyAliasTextField;
	}

	public WebElement getVisaCavvInfoKeyBEncModeDropdown() {
		return visaCavvInfoKeyBEncModeDropdown;
	}

	public WebElement getVisa09KeyBRadioBtn() {
		return visa09KeyBRadioBtn;
	}

	public WebElement getVisaCavvInfoKeyBKeyValueTextField() {
		return visaCavvInfoKeyBKeyValueTextField;
	}

	public WebElement getVisaAcsRreqClientDropdown() {
		return visaAcsRreqClientDropdown;
	}

	public WebElement getVisaAcsRreqClientSearchBox() {
		return visaAcsRreqClientSearchBox;
	}

	public WebElement getVisaAcsSigningCertDropdown() {
		return visaAcsSigningCertDropdown;
	}

	public WebElement getVisaAcsSigningCertSearchBox() {
		return visaAcsSigningCertSearchBox;
	}

	public WebElement getVisaCard1dot0EnableDropdown() {
		return visaCard1dot0EnableDropdown;
	}

	public WebElement getVisaLegacyCavvInfoTypeDropdown() {
		return visaLegacyCavvInfoTypeDropdown;
	}

	public WebElement getVisaLegacyCavvRadioBtn() {
		return visaLegacyCavvRadioBtn;
	}

	public WebElement getVisaLegacyCavvInfoDataFormatTypeDropdown() {
		return visaLegacyCavvInfoDataFormatTypeDropdown;
	}

	public WebElement getVisaLegacyPanDstxnidAmountCurRadioBtn() {
		return visaLegacyPanDstxnidAmountCurRadioBtn;
	}

	public WebElement getVisalegacyCavvInfokeyAkeyTypeDropdown() {
		return visalegacyCavvInfokeyAkeyTypeDropdown;
	}

	public WebElement getVisaLegacySDESRadioBtn() {
		return visaLegacySDESRadioBtn;
	}

	public WebElement getVisaLegacyCavvInfokeyAProviderTypeDropdown() {
		return visaLegacyCavvInfokeyAProviderTypeDropdown;
	}

	public WebElement getVisaLegacyHK_ACRadioBtn() {
		return visaLegacyHK_ACRadioBtn;
	}

	public WebElement getVisaLegacyCavvInfoKeyAKeyAliasTextField() {
		return visaLegacyCavvInfoKeyAKeyAliasTextField;
	}

	public WebElement getVisalegacyCavvInfokeyAEncModeDropdown() {
		return visalegacyCavvInfokeyAEncModeDropdown;
	}

	public WebElement getVisaLegacy09RadioBtn() {
		return visaLegacy09RadioBtn;
	}

	public WebElement getVisaRoot_legacyCavvInfo_keyA_keyValueTextField() {
		return visaRoot_legacyCavvInfo_keyA_keyValueTextField;
	}

	public WebElement getVisalegacyCavvInfokeyBkeyTypeDropdown() {
		return visalegacyCavvInfokeyBkeyTypeDropdown;
	}

	public WebElement getVisaLegacySDESKeyBRadioBtn() {
		return visaLegacySDESKeyBRadioBtn;
	}

	public WebElement getVisaLegacyCavvInfokeyBProviderTypeDropdown() {
		return visaLegacyCavvInfokeyBProviderTypeDropdown;
	}

	public WebElement getVisaLegacyHK_ACKeyBRadioBtn() {
		return visaLegacyHK_ACKeyBRadioBtn;
	}

	public WebElement getVisaLegacyCavvInfoKeyBKeyAliasTextField() {
		return visaLegacyCavvInfoKeyBKeyAliasTextField;
	}

	public WebElement getVisalegacyCavvInfokeyBEncModeDropdown() {
		return visalegacyCavvInfokeyBEncModeDropdown;
	}

	public WebElement getVisaLegacy09KeyBRadioBtn() {
		return visaLegacy09KeyBRadioBtn;
	}

	public WebElement getVisaroot_legacyCavvInfo_keyB_keyValueTextField() {
		return visaroot_legacyCavvInfo_keyB_keyValueTextField;
	}

	public WebElement getViasAcsXmlSigningCertDropdown() {
		return viasAcsXmlSigningCertDropdown;
	}

	public WebElement getViasAcsXmlSigningCertSearchBox() {
		return viasAcsXmlSigningCertSearchBox;
	}

	public WebElement getMasterAcsRreqClientSearchBox() {
		return masterAcsRreqClientSearchBox;
	}

	public WebElement getMasterAcsRreqClientFirstRadioBtn() {
		return masterAcsRreqClientFirstRadioBtn;
	}

	public WebElement getMasterAcsSigningCertSearchBox() {
		return masterAcsSigningCertSearchBox;
	}

	public WebElement getMasterAcsSigningCertFirstRadioBtn() {
		return masterAcsSigningCertFirstRadioBtn;
	}

	public WebElement getHmacKeykeyTypeDropDown() {
		return hmacKeykeyTypeDropDown;
	}

	public WebElement getHmacKeykeyTypeSDESRadioBtn() {
		return hmacKeykeyTypeSDESRadioBtn;
	}

	public WebElement getHmacKeyProviderTypeDropDown() {
		return hmacKeyProviderTypeDropDown;
	}

	public WebElement getHmacKeyProviderTypeHK_HCRadioBtn() {
		return hmacKeyProviderTypeHK_HCRadioBtn;
	}

	public WebElement getHmacKey_KeyAliasTextField() {
		return hmacKey_KeyAliasTextField;
	}

	public WebElement getCavvInfo_keyA_keyTypeDropdown() {
		return cavvInfo_keyA_keyTypeDropdown;
	}

	public WebElement getHmacKey_algorithm02RadioBtn() {
		return hmacKey_algorithm02RadioBtn;
	}

	public WebElement getHmacKey_algorithmDropdown() {
		return hmacKey_algorithmDropdown;
	}

	public WebElement getHmacKey_encMode09RadioBtn() {
		return hmacKey_encMode09RadioBtn;
	}

	public WebElement getHmacKey_encModeDropdown() {
		return hmacKey_encModeDropdown;
	}

	public WebElement getCavvInfo_keyA_keyType_SDES_RadioBtn() {
		return cavvInfo_keyA_keyType_SDES_RadioBtn;
	}

	public WebElement getCavvInfo_keyA_providerTypeDropdown() {
		return cavvInfo_keyA_providerTypeDropdown;
	}

	public WebElement getCavvInfo_keyA_providerType_HK_ACRadioBtn() {
		return cavvInfo_keyA_providerType_HK_ACRadioBtn;
	}

	public WebElement getCavvInfo_KeyA_KeyAliasTextField() {
		return CavvInfo_KeyA_KeyAliasTextField;
	}

	public WebElement getCavvInfo_keyA_encModeTypeDropdown() {
		return cavvInfo_keyA_encModeTypeDropdown;
	}

	public WebElement getCavvInfo_keyA_encModeType_09RadioBtn() {
		return cavvInfo_keyA_encModeType_09RadioBtn;
	}

	public WebElement getCavvInfo_KeyA_KeyValueTextField() {
		return CavvInfo_KeyA_KeyValueTextField;
	}

	public WebElement getCavvInfo_keyB_keyTypeDropdown() {
		return cavvInfo_keyB_keyTypeDropdown;
	}

	public WebElement getCavvInfo_keyB_keyType_SDES_RadioBtn() {
		return cavvInfo_keyB_keyType_SDES_RadioBtn;
	}

	public WebElement getCavvInfo_keyB_providerTypeDropdown() {
		return cavvInfo_keyB_providerTypeDropdown;
	}

	public WebElement getCavvInfo_keyB_providerType_HK_ACRadioBtn() {
		return cavvInfo_keyB_providerType_HK_ACRadioBtn;
	}

	public WebElement getCavvInfo_KeyB_KeyAliasTextField() {
		return CavvInfo_KeyB_KeyAliasTextField;
	}

	public WebElement getCavvInfo_keyB_encModeTypeDropdown() {
		return cavvInfo_keyB_encModeTypeDropdown;
	}

	public WebElement getCavvInfo_keyB_encModeType_09RadioBtn() {
		return cavvInfo_keyB_encModeType_09RadioBtn;
	}

	public WebElement getCavvInfo_KeyB_KeyValueTextField() {
		return CavvInfo_KeyB_KeyValueTextField;
	}

	public WebElement getMasterSchemeSaveBtn() {
		return masterSchemeSaveBtn;
	}

	public WebElement getAcsXmlSigningCertSearchBox() {
		return acsXmlSigningCertSearchBox;
	}

	public WebElement getAcsXmlSigningCertFirstRadioBtn() {
		return acsXmlSigningCertFirstRadioBtn;
	}

	public WebElement getVisaAcsRreqClientFirstRadioBtn() {
		return visaAcsRreqClientFirstRadioBtn;
	}

	public WebElement getVisaAcsSigningCertFirstRadioBtn() {
		return visaAcsSigningCertFirstRadioBtn;
	}

	public WebElement getViasAcsXmlSigningCertFirstRadioBtn() {
		return viasAcsXmlSigningCertFirstRadioBtn;
	}

	public WebElement getVisaSchemeSaveBtn() {
		return visaSchemeSaveBtn;
	}

	public WebElement getSchemeHeader() {
		return schemeHeader;
	}

}

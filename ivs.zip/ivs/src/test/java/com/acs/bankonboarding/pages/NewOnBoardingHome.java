package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewOnBoardingHome {

	public WebDriver driver;

	public NewOnBoardingHome(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//select[@id='slct']")
	private WebElement selectClusterDropdown;

	@FindBy(id = "slct1")
	private WebElement cloningExistingBankDropdown;

	@FindBy(xpath = "//a[text()='Fetch Data']")
	private WebElement fetchDataButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement cancelButton;

	@FindBy(xpath = "//a[text()='Review & Submit']")
	private WebElement reviewSubmitButton;

	@FindBy(xpath = "(//*[@class='btn-icon'])[1]")
	private WebElement onBoardBankExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[2]")
	private WebElement genericConfigExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[3]")
	private WebElement datasourceConfigExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[4]")
	private WebElement otpConfigExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[5]")
	private WebElement eventSMSExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[6]")
	private WebElement eventEmailExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[7]")
	private WebElement customerExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[8]")
	private WebElement alertSMSExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[9]")
	private WebElement alertEmailExpandIcon;

	@FindBy(id = "master")
	private WebElement enableMasterCheckBox;

	@FindBy(id = "visa")
	private WebElement enableVisaCheckBox;

	@FindBy(xpath = "(//*[@class='btn-icon'])[10]")
	private WebElement rbaExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[11]")
	private WebElement languageDefaultExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[12]")
	private WebElement languageenUSExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[13]")
	private WebElement flowV1ExpandIcon;

	@FindBy(xpath = "(//*[@class='btn-icon'])[14]")
	private WebElement flowV2ExpandIcon;
	
	//Review Details page
	@FindBy(xpath = "//a[text()='Submit']")
	private WebElement SubmitButton;

	//Logout Admin Portal
	@FindBy(xpath = "//span[contains(text(),'Welcome')]")
	private WebElement logoutAdminPortalDropdown;
	
	@FindBy(xpath = "//span[contains(text(),'Sign Out')]")
	private WebElement signOutAdminPortalButton;

	
	public WebElement getCloningExistingBank() {
		return cloningExistingBankDropdown;
	}

	public WebElement getFetchDataButton() {
		return fetchDataButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getReviewSubmitButton() {
		return reviewSubmitButton;
	}

	public WebElement getOnBoardBankExpandIcon() {
		return onBoardBankExpandIcon;
	}

	public WebElement getGenericConfigExpandIcon() {
		return genericConfigExpandIcon;
	}

	public WebElement getDatasourceConfigExpandIcon() {
		return datasourceConfigExpandIcon;
	}

	public WebElement getSelectClusterDropdown() {
		return selectClusterDropdown;
	}

	public WebElement getOTPConfigExpandIcon() {
		return otpConfigExpandIcon;
	}

	public WebElement getEventSMSExpandIcon() {
		return eventSMSExpandIcon;
	}

	public WebElement getEventEmailExpandIcon() {
		return eventEmailExpandIcon;
	}

	public WebElement getEnableMasterCheckBox() {
		return enableMasterCheckBox;
	}

	public WebElement getEnableVisaCheckBox() {
		return enableVisaCheckBox;
	}

	public WebElement getRBAExpandIcon() {
		return rbaExpandIcon;
	}

	public WebElement getLanguageDefaultExpandIcon() {
		return languageDefaultExpandIcon;
	}

	public WebElement getLanguageenUSExpandIcon() {
		return languageenUSExpandIcon;
	}

	public WebElement getFlowV1ExpandIcon() {
		return flowV1ExpandIcon;
	}

	public WebElement getFlowV2ExpandIcon() {
		return flowV2ExpandIcon;
	}

	public WebElement getSubmitButton() {
		return SubmitButton;
	}

	public WebElement getLogoutAdminPortalDropdown() {
		return logoutAdminPortalDropdown;
	}

	public WebElement getSignOutAdminPortalButton() {
		return signOutAdminPortalButton;
	}

}
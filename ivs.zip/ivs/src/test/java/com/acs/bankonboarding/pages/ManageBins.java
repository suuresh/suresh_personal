package com.acs.bankonboarding.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageBins {
	public WebDriver driver;

	public ManageBins(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Add bin']")
	private WebElement plusAddBinButton;

	@FindBy(xpath = "//input[@placeholder='Bin Description']")
	private WebElement binDescriptionTextField;

	@FindBy(xpath = "//input[@placeholder='Issuer Bin']")
	private WebElement issuerBinTextField;

	@FindBy(xpath = "//input[@placeholder='Bin Start']")
	private WebElement binStartTextField;

	@FindBy(xpath = "//input[@placeholder='Bin End']")
	private WebElement binEndTextField;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Card Association Type')]/following::div[1]/div/a")
	private WebElement cardAssociationTypeDropdown;

	// Card Association Type
	@FindBy(xpath = "//label[text()='Master']")
	private WebElement cardAssociationMasterRadiBtn;

	@FindBy(xpath = "//label[text()='Visa']")
	private WebElement cardAssociationVisaRadiBtn;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Card Type')]/following::div[1]/div/a")
	private WebElement cardTypeDropdown;

	// Card type
	@FindBy(xpath = "//label[text()='Credit']")
	private WebElement cardTypeCreditRadioBtn;

	@FindBy(xpath = "//label[text()='Debit']")
	private WebElement cardTypeDebitRadioBtn;

	@FindBy(xpath = "//input[@placeholder='CardClassificationId']")
	private WebElement cardClassificationIdTextField;

	// Status
	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Status')]/following::div[1]/div/a")
	private WebElement statusDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement statusSearchBox;

	@FindBy(xpath = "(//input[@placeholder='Search']//following::label[@class='radio-label'])[1]")
	private WebElement statusFirstRadioBtn;

	@FindBy(xpath = "//label[text()='Active']")
	private WebElement statusActiveRadioBtn;

	// Configuration

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Generic')]/following::div[1]/div/a")
	private WebElement genericDropdown;

	@FindBy(xpath = "//label[@for='COMMON']")
	private WebElement genericCommonRadioBtn;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Data Source')]/following::div[1]/div/a")
	private WebElement dataSourceDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'OTP Engine')]/following::div[1]/div/a")
	private WebElement otpEngineDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Event Sms')]/following::div[1]/div/a")
	private WebElement eventSmsDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Event Email')]/following::div[1]/div/a")
	private WebElement eventEmailDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Customer')]/following::div[1]/div/a")
	private WebElement customerDropdown;

	@FindBy(xpath = "//label[text()='SWITCH']")
	private WebElement customerSwitch;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Alert Sms')]/following::div[1]/div/a")
	private WebElement alertSmsDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Alert Email')]/following::div[1]/div/a")
	private WebElement alertEmailDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Scheme')]/following::div[1]/div/a")
	private WebElement schemeDropdown;

	@FindBy(xpath = "//label[text()='MASTER']")
	private WebElement schemeMasterRadiBtn;

	@FindBy(xpath = "//label[text()='VISA']")
	private WebElement schemeVisaRadiBtn;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Rba Config')]/following::div[1]/div/a")
	private WebElement rbaConfigDropdown;

	@FindBy(xpath = "//label[text()='200123090652312 - TestRule']")
	private WebElement rbaConfigTestRuleRadiBtn;

	@FindBy(xpath = "(//div[contains(@class,'dropdown__title')][contains(text(),'Rba')]/following::div[1]/div/a)[2]")
	private WebElement rbaDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'UI Language')]/following::div[1]/div/a")
	private WebElement uiLanguageDropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Flow V1')]/following::div[1]/div/a")
	private WebElement flowV1Dropdown;

	@FindBy(xpath = "//div[contains(@class,'dropdown__title')][contains(text(),'Flow V2')]/following::div[1]/div/a")
	private WebElement flowV2Dropdown;

	@FindBy(xpath = "//label[contains(text(),'DEFAULT')]")
	private WebElement defaultRadioBtn;

	@FindBy(xpath = "//a[contains(text(),'Add Bin')]")
	private WebElement addBinButton;

	@FindBy(xpath = "//a[text()='Review Bins']")
	private WebElement reviewBinButton;

	@FindBy(xpath = "//a[text()='Submit']")
	private WebElement reviewBinSubmitButton;

	@FindBy(xpath = "//a[text()='Approve Bins']")
	private WebElement approveBinsButton;

	@FindBy(xpath = "//a[text()='Approve']")
	private WebElement approveButton;

	@FindBy(xpath = "//textarea[@id='approveComment']")
	private WebElement approveComment;

	@FindBy(xpath = "//a[text()='CONFIRM']")
	private WebElement approveConfirmButton;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_CUST_INFO_V1']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_CUST_INFO_V1Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_CUST_INFO_V1DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_CUST_INFO_V2']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_CUST_INFO_V2Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_CUST_INFO_V2DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_SELECT_V1']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_SELECT_V1Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_SELECT_V1DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_SELECT_V2']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_SELECT_V2Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_SELECT_V2DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_AUTH_V1']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_AUTH_V1Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_AUTH_V1DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_AUTH_V2']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_AUTH_V2Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_AUTH_V2DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_REGISTER_V1']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_REGISTER_V1Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_REGISTER_V1DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_REGISTER_V2']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_REGISTER_V2Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_REGISTER_V2DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_SET_PASS_V1']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_SET_PASS_V1Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_SET_PASS_V1DropdownDefaultList;

	@FindBy(xpath = "(//div[@data-tip='SCREEN_SET_PASS_V2']/following::div[@class='dropdown dropdown--type3 is-active']/div/a[1])[1]")
	private WebElement SCREEN_SET_PASS_V2Dropdown;

	@FindBy(xpath = "//label[text()='DEFAULT']")
	private WebElement SCREEN_SET_PASS_V2DropdownDefaultList;

	public WebElement getPlusAddBinButton() {
		return plusAddBinButton;
	}

	public WebElement getBinDescriptionTextField() {
		return binDescriptionTextField;
	}

	public WebElement getIssuerBinTextField() {
		return issuerBinTextField;
	}

	public WebElement getBinStartTextField() {
		return binStartTextField;
	}

	public WebElement getBinEndTextField() {
		return binEndTextField;
	}

	public WebElement getCardAssociationTypeDropdown() {
		return cardAssociationTypeDropdown;
	}

	public WebElement getCardAssociationMasterRadiBtn() {
		return cardAssociationMasterRadiBtn;
	}

	public WebElement getCardTypeDropdown() {
		return cardTypeDropdown;
	}

	public WebElement getCardTypeCreditRadioBtn() {
		return cardTypeCreditRadioBtn;
	}

	public WebElement getCardClassificationIdTextField() {
		return cardClassificationIdTextField;
	}

	public WebElement getStatusDropdown() {
		return statusDropdown;
	}

	public WebElement getStatusActiveRadioBtn() {
		return statusActiveRadioBtn;
	}

	public WebElement getGenericDropdown() {
		return genericDropdown;
	}

	public WebElement getGenericCommonRadioBtn() {
		return genericCommonRadioBtn;
	}

	public WebElement getDataSourceDropdown() {
		return dataSourceDropdown;
	}

	public WebElement getOtpEngineDropdown() {
		return otpEngineDropdown;
	}

	public WebElement getEventSmsDropdown() {
		return eventSmsDropdown;
	}

	public WebElement getEventEmailDropdown() {
		return eventEmailDropdown;
	}

	public WebElement getCustomerDropdown() {
		return customerDropdown;
	}

	public WebElement getCustomerSwitch() {
		return customerSwitch;
	}

	public WebElement getAlertSmsDropdown() {
		return alertSmsDropdown;
	}

	public WebElement getAlertEmailDropdown() {
		return alertEmailDropdown;
	}

	public WebElement getSchemeDropdown() {
		return schemeDropdown;
	}

	public WebElement getSchemeMasterRadiBtn() {
		return schemeMasterRadiBtn;
	}

	public WebElement getRbaConfigDropdown() {
		return rbaConfigDropdown;
	}

	public WebElement getRbaConfigTestRuleRadiBtn() {
		return rbaConfigTestRuleRadiBtn;
	}

	public WebElement getRbaDropdown() {
		return rbaDropdown;
	}

	public WebElement getUiLanguageDropdown() {
		return uiLanguageDropdown;
	}

	public WebElement getFlowV1Dropdown() {
		return flowV1Dropdown;
	}

	public WebElement getFlowV2Dropdown() {
		return flowV2Dropdown;
	}

	public WebElement getDefaultRadioBtn() {
		return defaultRadioBtn;
	}

	public WebElement getCardAssociationVisaRadiBtn() {
		return cardAssociationVisaRadiBtn;
	}

	public WebElement getCardTypeDebitRadioBtn() {
		return cardTypeDebitRadioBtn;
	}

	public WebElement getSchemeVisaRadiBtn() {
		return schemeVisaRadiBtn;
	}

	public WebElement getAddBinButton() {
		return addBinButton;
	}

	public WebElement getStatusSearchBox() {
		return statusSearchBox;
	}

	public WebElement getStatusFirstRadioBtn() {
		return statusFirstRadioBtn;
	}

	public WebElement getReviewBinButton() {
		return reviewBinButton;
	}

	public WebElement getReviewBinSubmitButton() {
		return reviewBinSubmitButton;
	}

	public WebElement getApproveBinsButton() {
		return approveBinsButton;
	}

	public WebElement getApproveButton() {
		return approveButton;
	}

	public WebElement getApproveComment() {
		return approveComment;
	}

	public WebElement getApproveConfirmButton() {
		return approveConfirmButton;
	}

	public WebElement getSCREEN_CUST_INFO_V1Dropdown() {
		return SCREEN_CUST_INFO_V1Dropdown;
	}

	public WebElement getSCREEN_CUST_INFO_V1DropdownDefaultList() {
		return SCREEN_CUST_INFO_V1DropdownDefaultList;
	}

	public WebElement getSCREEN_CUST_INFO_V2Dropdown() {
		return SCREEN_CUST_INFO_V2Dropdown;
	}

	public WebElement getSCREEN_CUST_INFO_V2DropdownDefaultList() {
		return SCREEN_CUST_INFO_V2DropdownDefaultList;
	}

	public WebElement getSCREEN_SELECT_V1Dropdown() {
		return SCREEN_SELECT_V1Dropdown;
	}

	public WebElement getSCREEN_SELECT_V1DropdownDefaultList() {
		return SCREEN_SELECT_V1DropdownDefaultList;
	}

	public WebElement getSCREEN_SELECT_V2Dropdown() {
		return SCREEN_SELECT_V2Dropdown;
	}

	public WebElement getSCREEN_SELECT_V2DropdownDefaultList() {
		return SCREEN_SELECT_V2DropdownDefaultList;
	}

	public WebElement getSCREEN_AUTH_V1Dropdown() {
		return SCREEN_AUTH_V1Dropdown;
	}

	public WebElement getSCREEN_AUTH_V1DropdownDefaultList() {
		return SCREEN_AUTH_V1DropdownDefaultList;
	}

	public WebElement getSCREEN_AUTH_V2Dropdown() {
		return SCREEN_AUTH_V2Dropdown;
	}

	public WebElement getSCREEN_AUTH_V2DropdownDefaultList() {
		return SCREEN_AUTH_V2DropdownDefaultList;
	}

	public WebElement getSCREEN_REGISTER_V1Dropdown() {
		return SCREEN_REGISTER_V1Dropdown;
	}

	public WebElement getSCREEN_REGISTER_V1DropdownDefaultList() {
		return SCREEN_REGISTER_V1DropdownDefaultList;
	}

	public WebElement getSCREEN_REGISTER_V2Dropdown() {
		return SCREEN_REGISTER_V2Dropdown;
	}

	public WebElement getSCREEN_REGISTER_V2DropdownDefaultList() {
		return SCREEN_REGISTER_V2DropdownDefaultList;
	}

	public WebElement getSCREEN_SET_PASS_V1Dropdown() {
		return SCREEN_SET_PASS_V1Dropdown;
	}

	public WebElement getSCREEN_SET_PASS_V1DropdownDefaultList() {
		return SCREEN_SET_PASS_V1DropdownDefaultList;
	}

	public WebElement getSCREEN_SET_PASS_V2Dropdown() {
		return SCREEN_SET_PASS_V2Dropdown;
	}

	public WebElement getSCREEN_SET_PASS_V2DropdownDefaultList() {
		return SCREEN_SET_PASS_V2DropdownDefaultList;
	}

}

package com.acs.libraries;


import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;



public class TestNGResultListener implements ITestListener{
	public static WebDriver driver = null;
	public String methodName; 
	//public GenericMethods generic = null;
	
	public void onTestStart(ITestResult result) {
				
	}

	public void onTestSuccess(ITestResult result) {
				
	}

	public void onTestFailure(ITestResult result) {
	//	generic = new GenericMethods();
		System.out.println(result.getName().toString().trim()+": Test Method is failed");
			methodName = result.getName().toString().trim();
			try {
				CaptureScreenshot(methodName);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}

	public void onTestSkipped(ITestResult result) {
	
		methodName = result.getName().toString().trim();
		
		try {
			CaptureScreenshot(methodName);
		} catch (IOException e) {
			
			e.printStackTrace();
		}		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
				
	}

	public void onStart(ITestContext context) {
				
	}

	public void onFinish(ITestContext context) {
				
	}
	
	public static void CaptureScreenshot(String methodName) throws IOException{
		
		  Calendar cal = new GregorianCalendar();
		  int month = cal.get(Calendar.MONTH); //12
		  int year = cal.get(Calendar.YEAR); //2017
		  int sec =cal.get(Calendar.SECOND);
		  int min =cal.get(Calendar.MINUTE);
		  int date = cal.get(Calendar.DATE);
		  int day =cal.get(Calendar.HOUR_OF_DAY);
		  
	//	  driver=TimeSheetInitialSetUp.driver;
		  
		  System.out.println("Taking screen shot for method:"+methodName);
		
		  String screenShotPath = System.getProperty("user.dir")+"\\Resources\\ScreenShots\\"+methodName+"_"+year+"_"+(month+1)+"-"+date+"_"+day+"_"+min+"_" +sec;
			
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try{
			FileUtils.copyFile(scrFile, new File(screenShotPath+".jpeg"));
		}catch(IOException e ){
			e.printStackTrace();
		}
		   
	}

}

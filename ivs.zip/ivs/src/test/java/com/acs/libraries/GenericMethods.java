package com.acs.libraries;

import static io.restassured.RestAssured.given;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.acs.utils.Base64Utility;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GenericMethods // extends ACSInitialSetUp {
{
	public WebDriver driver;
	public static Xls_Reader excel;
	// public Logger logger;

	public GenericMethods(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		// logger = Logger.getLogger(this.getClass().getName());
	}

	public void verifyTitle(String eTitle) {
		String aTitle = driver.getTitle();
		try {

			Assert.assertEquals(aTitle, eTitle);
			System.out.println(aTitle + " Title MATCHED with " + eTitle);

		} catch (Throwable t) {

			System.out.println(aTitle + " title NOT MATCHED with " + eTitle);
			ErrorCollector.addVerificationFailure(t);

		}
	}

	public void explicitWait(int durationInSec) {

		try {
			Thread.sleep(1000 * durationInSec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void verifyText(String aText, String eText) {
		try {

			Assert.assertEquals(aText, eText);
			System.out.println(aText + " is MATCHED with " + eText);

		} catch (Throwable t) {

			System.out.println(aText + " is NOT MATCHED with " + eText);
			ErrorCollector.addVerificationFailure(t);

		}
	}

	/**
	 * waitForElement() method contains set of instruction to wait for an element
	 * for given amount of time
	 * 
	 * @throws NumberFormatException, FileNotFoundException, IOException
	 * @param WebElement element,int timeoutSeconds
	 * @return boolean
	 * 
	 *         public static boolean waitForElement(WebElement element, WebDriver
	 *         driver) {
	 * 
	 *         try{ FluentWait<WebElement> wait=new FluentWait<WebElement>(element)
	 *         .withTimeout(30, TimeUnit.SECONDS)
	 *         .pollingEvery(100,TimeUnit.MILLISECONDS)
	 *         .ignoring(org.openqa.selenium.StaleElementReferenceException.class,org.openqa.selenium.NoSuchElementException.class)
	 *         .ignoring(org.openqa.selenium.InvalidSelectorException.class)
	 *         .ignoring(org.openqa.selenium.ElementNotVisibleException.class)
	 *         .ignoring(org.openqa.selenium.InvalidElementStateException.class)
	 *         .ignoring(org.openqa.selenium.InvalidElementStateException.class)
	 *         .ignoring(org.openqa.selenium.WebDriverException.class);
	 * 
	 *         wait.until(ExpectedConditions.visibilityOf(element)) { public boolean
	 *         apply(WebElement element) { return element.isDisplayed(); }
	 * 
	 *         public boolean test(WebElement t) { // TODO Auto-generated method
	 *         stub return false; } });
	 * 
	 *         return true;
	 * 
	 *         }catch(TimeoutException e){ return false; } }
	 * 
	 *         /** waitForElement() method contains set of instruction to wait for
	 *         an element for given amount of time specified in init.properties
	 * 
	 * @throws NumberFormatException, FileNotFoundException, IOException
	 * @param WebElement element
	 * @return boolean
	 * 
	 *         public static boolean waitForElement(WebElement element){
	 * 
	 *         try{ int
	 *         timeoutSeconds=Integer.parseInt(CommonUtils.InitProperties("element.waittime"));
	 *         FluentWait<WebElement> wait=new FluentWait<WebElement>(element)
	 *         .withTimeout(timeoutSeconds, TimeUnit.SECONDS)
	 *         .pollingEvery(100,TimeUnit.MILLISECONDS)
	 *         .ignoring(org.openqa.selenium.StaleElementReferenceException.class,org.openqa.selenium.NoSuchElementException.class)
	 *         .ignoring(org.openqa.selenium.InvalidSelectorException.class)
	 *         .ignoring(org.openqa.selenium.InvalidElementStateException.class)
	 *         .ignoring(org.openqa.selenium.WebDriverException.class,org.openqa.selenium.ElementNotVisibleException.class);
	 * 
	 *         wait.until(new Predicate<WebElement>() { public boolean
	 *         apply(WebElement element) { return element.isDisplayed(); }
	 * 
	 *         public boolean test(WebElement t) { // TODO Auto-generated method
	 *         stub return false; } }); return true;
	 * 
	 *         }catch(TimeoutException e){ return false; } }
	 **/
	public void waitForElementVisible(WebDriver driver, WebElement webelement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(webelement));

			System.out.println(webelement + ": webelement is visible");
		} catch (NoSuchElementException ingnored) {
			System.out.println(webelement + " : webelement is not visible");
			ErrorCollector.addVerificationFailure(ingnored);

		}
	}

	public void waitForElementClickable(WebDriver driver, WebElement webelement) {

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable(webelement));

		} catch (Throwable t) {
			System.out.println(webelement + ": Element is not clickable");
			ErrorCollector.addVerificationFailure(t);
		}
	}

	public void scrollThePageTillXpositionOfTheElement(WebElement webelement) {

		// WebElement element = driver.findElement(By.id(""));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, " + webelement.getLocation().x + ")");
		// element.click();
	}

	public void checkAlertDisplayed() {
		WebDriverWait wait = new WebDriverWait(driver, 3);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				// wait.until(ExpectedConditions.elementToBeSelected(element))

				System.out.println("Alert is present!");
				Alert alert = driver.switchTo().alert();
				System.out.println("Alert message is:" + alert.getText());
			}
		} catch (Throwable t) {
			System.out.println("alert is not displayed");
			ErrorCollector.addVerificationFailure(t);
		}
	}

	public void acceptAlertPopup() {
		try {
			driver.switchTo().alert().accept();

		} catch (Throwable t) {
			System.out.println("alert is not displayed");
			ErrorCollector.addVerificationFailure(t);
		}
	}

	public void dismissAlertPopup() {
		try {

			driver.switchTo().alert().dismiss();

		} catch (Throwable t) {

			System.out.println("alert is not displayed");
			ErrorCollector.addVerificationFailure(t);
		}
	}

	/* ********** Utility methods ****************** */

	// Reading data from excel file using dataProviders
	public Object[][] getData(String XlFileName, String sheetname) {

		excel = new Xls_Reader(Config.xlPath + XlFileName);
		int rowc = excel.getRowCount(sheetname);
		// System.out.println("Excell row count is intially :" + rowc);
		int colc = excel.getColumnCount(sheetname);

		Object[][] data = new Object[rowc - 1][colc];
		System.out.println("Row Count : " + rowc);
		System.out.println("Column count:" + colc);

		for (int rowNum = 2; rowNum <= rowc; rowNum++) { // 2

			// System.out.println("RowNum inside loop :"+rowNum);

			for (int colNum = 0; colNum < colc; colNum++) {
				// System.out.println("ColumnNum inside loop:"+colNum);
				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum); // -2
				// System.out.println(excel.getCellData(sheetname, colNum, rowNum));
			}
		}

		return data;
	}

	public static Object[][] getApiData(String XlFileName, String sheetname) {

		excel = new Xls_Reader(Config.xlPath + XlFileName);
		int rowc = excel.getRowCount(sheetname);
		System.out.println("Excell row count is intially :" + rowc);
		int colc = excel.getColumnCount(sheetname);

		Object[][] data = new Object[rowc - 1][colc];
		System.out.println("Row Count : " + rowc);
		System.out.println("Column count:" + colc);

		for (int rowNum = 2; rowNum <= rowc; rowNum++) { // 2

			// System.out.println("RowNum inside loop :"+rowNum);

			for (int colNum = 0; colNum < colc; colNum++) {
				// System.out.println("ColumnNum inside loop:"+colNum);
				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum); // -2
			}
		}

		return data;
	}

	public static long generateRandomDigits(int n) {
		long m = (long) Math.pow(10, n - 1);
		return m + new Random().nextInt();
	}
	
	public static long generateRandomDigitsNumber(int n) {
		long m = (long) Math.pow(10, n - 1);
		long num =  m + new Random().nextInt();
		String no = num+"";
		if(no.length() != n) {
			return generateRandomDigitsNumber(n);
		} else {
			return num;
		}
	}
	
	

	public static int generateRandomDigitsInInt(int n) {
		Random rand = new Random();
		int num = rand.nextInt(9000000) + 1000000;
		return num;
	}
	
	public static String getAcsTxnIdFromOTPTxn(String issuierId) {
		//SELECT * FROM rpktk_4131_indblr_blrrel_acs_txn.otp_txn_202308 where issuer_id='4131' order by insertedtime desc limit 1;
		
		String queryString = "SELECT client_refid FROM rpktk_4131_indblr_blrrel_acs_txn.otp_txn_" + generateTimeStampForTxnTable()
		+ " where issuer_id='" + issuierId + "' order by insertedtime desc limit 1;";
		String acsTxnId = null;

		try {
			Class.forName(Config.mysqldriver);
		
			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				acsTxnId = rs.getString(1);
				System.out.println("ACS Txn Id:" + acsTxnId);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return acsTxnId;

	}

	public static String getACSTxnIdFromMPIDB(String srvrTxnId) {

		String queryString = "SELECT ACCOUNT_ID FROM dw_payu_mpi.txn_" + generateTimeStamp()
				+ " where AGG_MERCH_SERVER_TXN_ID='" + srvrTxnId + "';";
		String acsTxnId = null;

		try {
			Class.forName(Config.ePayMPImysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.ePayMPImysqlurl, Config.ePayMPImysqluserName,
					Config.ePayMPImysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				acsTxnId = rs.getString(1);
				System.out.println("ACS Txn Id:" + acsTxnId);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return acsTxnId;

	}

	/***************
	 * Getting Language preference for the customer from DB
	 *******************/

	public static String getLanguagePreferencFromDB(String SchemaName, String encryptedCardNumber) {

		String queryString = "SELECT LANG_PREFERENCE FROM " + SchemaName + ".card_data where account_number='"
				+ encryptedCardNumber + "';";
		String LanguagePreferece = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				LanguagePreferece = rs.getString(1);
				System.out.println("maxattempts :" + LanguagePreferece);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return LanguagePreferece;

	}

	/**************** Getting OTP Details from DB ***********************/

	public static String getMaximumAllowedOTPattemptsFromDB(String SchemaName, String acsTxnId) {

		String queryString = "SELECT maxattempts FROM " + SchemaName + ".otp_txn_" + generateTimeStampForTxnTable()
				+ " where client_refid='" + acsTxnId + "';";
		String maxattempts = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				maxattempts = rs.getString(1);
				System.out.println("maxattempts :" + maxattempts);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return maxattempts;

	}
	
	
	public static String getGeneratedOTPFromDB(String SchemaName, String acsTxnId) {
		String queryString = "SELECT otpvalue FROM " + SchemaName + ".otp_txn_" + generateTimeStampForTxnTable()
		+ " where client_refid='" + acsTxnId + "';";
		String otpvalue = null;
		
		try {
			Class.forName(Config.mysqldriver);
		
			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				otpvalue = rs.getString(1);
				System.out.println("otpvalue : " + otpvalue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return otpvalue;
	}

	public static String getResendOTPCountFromDB(String SchemaName, String acsTxnId) {
		// SELECT resendcount,failureattempts FROM
		// krntk_8131_indblr_blrrel_acs_txn.otp_txn_202101
		String queryString = "SELECT resendcount FROM " + SchemaName + ".otp_txn_" + generateTimeStampForTxnTable()
				+ " where client_refid='" + acsTxnId + "';";
		String ResendOTPCount = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				ResendOTPCount = rs.getString(1);
				System.out.println("ResendOTPCount : " + ResendOTPCount);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ResendOTPCount;

	}

	public static String getInvalidOTPAttemptsFromDB(String SchemaName, String acsTxnId) {

		String queryString = "SELECT failureattempts FROM " + SchemaName + ".otp_txn_" + generateTimeStampForTxnTable()
				+ " where client_refid='" + acsTxnId + "';";
		String failureattempts = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				failureattempts = rs.getString(1);
				System.out.println("failureattempts :" + failureattempts);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return failureattempts;

	}

	public static String getStatusDetails(String SchemaName, String acsTxnId) {

		String queryString = "SELECT status_details FROM " + SchemaName + ".otp_txn_" + generateTimeStampForTxnTable()
				+ " where client_refid='" + acsTxnId + "';";
		String status = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;

	}

	/***************** Verify error description from DB **********************/
	public static String getErrorDescription(String schema, String utcYear, String utcMonth, String acsTransID) {

		String queryString = "SELECT error_description FROM " + schema + ".error_messages_" + utcYear + utcMonth
				+ " where acs_txn_id='" + acsTransID + "';";
		String status = null;
		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;
	}

	public static String getMessageVersion(String schema, String utcYear, String utcMonth, String acsTransID) {

		String queryString = "SELECT message_version FROM " + schema + ".error_messages_" + utcYear + utcMonth
				+ " where acs_txn_id='" + acsTransID + "';";
		String status = null;
		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;
	}

	public static String getErrorCode(String schema, String utcYear, String utcMonth, String acsTransID) {

		String queryString = "SELECT error_code FROM " + schema + ".error_messages_" + utcYear + utcMonth
				+ " where acs_txn_id='" + acsTransID + "';";
		String status = null;
		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;
	}

	public static String getErrorMessageType(String schema, String utcYear, String utcMonth, String acsTransID) {

		String queryString = "SELECT error_message_type FROM " + schema + ".error_messages_" + utcYear + utcMonth
				+ " where acs_txn_id='" + acsTransID + "';";
		String status = null;
		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	public static String getErrorComponent(String schema, String utcYear, String utcMonth, String acsTransID) {

		String queryString = "SELECT error_component FROM " + schema + ".error_messages_" + utcYear + utcMonth
				+ " where acs_txn_id='" + acsTransID + "';";
		String status = null;
		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				status = rs.getString(1);
				System.out.println("status :" + status);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;

	}

	/***************** End of OTP Details from DB **********************/
	public String extractKeyValueInUrl(String URL, String key) {
		String KeyValue = null;
		try {
			Pattern p = Pattern.compile(key + "([^&]+)");
			Matcher m = p.matcher(URL);
			while (m.find()) {
				KeyValue = m.group(1);
				System.out.println(key + m.group(1));

			}
		} catch (PatternSyntaxException ex) {
			// error handling
		}

		return KeyValue;
	}

	public String ExtractValuesFromXML(String Xml, String tagname) throws SAXException, IOException {
		String requestedValue = null;
		DocumentBuilder builder;
		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource src = new InputSource();
			src.setCharacterStream(new StringReader(Xml));

			Document doc = builder.parse(src);
			requestedValue = doc.getElementsByTagName(tagname).item(0).getTextContent();
			System.out.println(tagname + " : " + requestedValue);

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return requestedValue;
	}

	public String getencyrptedOTPFromDB(String IssuerBankId) {

		String queryString = "Select OTPVALUE from " + IssuerBankId + ".otp_txn_" + GenericMethods.generateTimeStamp()
				+ " order by last_updatedtime desc limit 1;";
		String encryptedOTPValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				encryptedOTPValue = rs.getString(1);
				System.out.println("OTP Value:" + encryptedOTPValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return encryptedOTPValue;

	}

	public String getencyrptedOTPFromUserMasterTable() {

		String queryString = "Select OTP_VALUE from " + Config.BASE_ADMIN_SCHEMA + ".user_master" + " where USER_ID='"
				+ Config.BASE_UAM_ADMIN_USER_NAME + "';";
		String encryptedOTPValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				encryptedOTPValue = rs.getString(1);
				System.out.println("OTP Value for the user:" + encryptedOTPValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return encryptedOTPValue;

	}

	public void updateRBADefault(String IssuerBankId) {

		String updatequeryString = "update " + Config.BASE_CONFIG_SCHEMA
				+ ".issuer_config set config_value ='{\"txnSourceType\":\"ACS\",\"rbaFlag\":true,\"rbaRequestUrl\":{\"connectType\":\"DIRECT\",\"endpointUrl\":\"http://192.168.108.79:8445/analyse/POS/request\"},\"rbaResultUrl\":{\"connectType\":\"DIRECT\",\"endpointUrl\":\"http://192.168.108.79:8445/analyse/POS/result\"},\"rbaAsyncFlag\":false,\"details\":\"true\",\"channelId\":\"3DS2.0\",\"rbaAckUrl\":{\"connectType\":\"DIRECT\",\"endpointUrl\":\"http://192.168.108.79:8445/analyse/POS/updateTxnStatus\"},\"rbaScript\":\"if(areq.getPurchaseAmount()!=null&&java.lang.Integer.parseInt(areq.getPurchaseAmount())>10000){authType=AuthType.FRICTIONLESS;}else{authType=AuthType.OTP;}\"}'"
				+ " where bank_id='" + IssuerBankId + "' and  config_type='RBA' and config_class='DEFAULT';";

		String RBACONFIG = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			System.out.println("Statement Created For Updating RBA Config : " + updatequeryString);
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			java.sql.PreparedStatement preparedStmt = connection.prepareStatement(updatequeryString);
			preparedStmt.executeUpdate();
			System.out.println("update Statement Executed ");

			Statement stmt = connection.createStatement();
			/*
			 * System.out.println("Statement Created For Updating Card status : "
			 * +updatequeryString); stmt.executeUpdate(updatequeryString);
			 */
			ResultSet rs = stmt.executeQuery(
					"SELECT config_value FROM " + Config.BASE_CONFIG_SCHEMA + ".issuer_config where bank_id='"
							+ IssuerBankId + "' and  config_type='RBA' and config_class='DEFAULT';");
			System.out.println("Query executed is :" + "SELECT config_value FROM " + Config.BASE_CONFIG_SCHEMA
					+ "where bank_id='" + IssuerBankId + "' and  config_type='RBA' and config_class='DEFAULT';");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				RBACONFIG = rs.getString(1);
				System.out.println("Updated RBA Config:" + RBACONFIG);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void AdminUnBlockCard(String EncryptedCardNumber, String IssuerBankId) {

		RestAssured.baseURI = Config.BASE_ADMIN_CARD_UNBLOCKING_URI;
		RestAssured.defaultParser = Parser.fromContentType("application/json");
		// Response response = RestAssured.given().contentType("application/json")

		RequestSpecification request = RestAssured.given().contentType("application/json");

		// Map<String, String> requestParams = new HashMap<>();
		JsonObject requestParams = new JsonObject();
		requestParams.addProperty("accountIdentifier", 9053);
		requestParams.addProperty("bankId", IssuerBankId);
		requestParams.addProperty("accountNumber", EncryptedCardNumber);
		requestParams.addProperty("acsTxnId", "1234ascd");
		requestParams.addProperty("action", "UNBLOCK");
		requestParams.addProperty("type", "SOFT");
		requestParams.addProperty("user", "demouser");

		request.body(requestParams);
		try {
			System.out.println("********* Admin Card Unblock entered ***********");
			String unBlockStatus = request.post("/admin/cdm/v1/managecards/actionOnCardInfo").then().extract()
					.path("responseDesc");
			System.out.println("Unbloacking status of the card :" + unBlockStatus);
		} catch (Exception e) {
			System.out.println("Card was unblocked, Exception while processing request: ***** " + e);
		}

	}

	public String updateCardStatusToActive(String enCryptedCardNumber, String IssuerBankId) {

		String updatequeryString = "update " + IssuerBankId
				+ ".card_data set status='1', attempts='0' where ACCOUNT_NUMBER='" + enCryptedCardNumber + "';";
		String cardStatus = null;

		try {
			Class.forName(Config.mysqldriver);

			System.out.println("Connected to DB");
			System.out.println("Statement Created For Updating Card status : " + updatequeryString);
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			java.sql.PreparedStatement preparedStmt = connection.prepareStatement(updatequeryString);
			preparedStmt.executeUpdate();
			System.out.println("update Statement Executed ");

			Statement stmt = connection.createStatement();
			/*
			 * System.out.println("Statement Created For Updating Card status : "
			 * +updatequeryString); stmt.executeUpdate(updatequeryString);
			 */
			ResultSet rs = stmt.executeQuery("SELECT status FROM " + IssuerBankId + ".card_data where ACCOUNT_NUMBER='"
					+ enCryptedCardNumber + "';");
			System.out.println("Query executed is :" + "SELECT status FROM " + IssuerBankId
					+ ".card_data where ACCOUNT_NUMBER='" + enCryptedCardNumber + "';");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				cardStatus = rs.getString(1);
				System.out.println("Card Status:" + cardStatus);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cardStatus;

	}

	public void deleteBankIdInDB(String bankid) {

		String deletequeryString1 = "delete from " + Config.BASE_ADMIN_SCHEMA + ".bank_product where BANK_ID='" + bankid
				+ "';";

		String deletequeryString2 = "delete from " + Config.BASE_ADMIN_SCHEMA + ".bank_master where BANK_ID='" + bankid
				+ "';";

		try {
			Class.forName(Config.mysqldriver);

			System.out.println("Connected to DB");
			System.out
					.println("Statement Created For deleting the bank from bank_product table : " + deletequeryString1);
			System.out
					.println("Statement Created For deleting the bank from bank_master table : " + deletequeryString2);

			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + deletequeryString1);
			stmt.executeUpdate(deletequeryString1);
			stmt.executeUpdate(deletequeryString2);
			System.out.println("Query executed");
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getACSTxnIDFromDB(String IssuerBankId) {

		String ACSTxnID = null;

		String queryString = "Select acs_txn_id from " + IssuerBankId + ".acs_txn_" + GenericMethods.generateTimeStamp()
				+ " order by date_time desc limit 1;";

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				ACSTxnID = rs.getString(1);
				System.out.println("ACSTxnID:" + ACSTxnID);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ACSTxnID;

	}

	public void insertencyrptedCardToDB(String encryptedCardValue, String IssuerBankId) {

		// String queryString = "Select OTPVALUE from
		// accosa2qa_acs_txn_8111.otp_txn_"+GenericMethods.generateTimeStamp()+" order
		// by last_updatedtime desc limit 1;";
		String queryString = "INSERT INTO " + IssuerBankId + ".card_data VALUES ('" + encryptedCardValue
				+ "', '6347', '12345', 'BANK_API', 'admin', '2222', '2312', 'mmyy', '2018-07-05', 'c', 'csk', 'dsdsdsd', '01', '999', '111111111111', '001', '2587413698', '004', '1234567890', 'subhash.chilka@wibmo.com', 'asasas@gmail.com', '5553826545874963', '', '', '', '3', '1', 'admin', '2018-11-16 18:48:05.000000', '2018-11-16', '2018-11-16 18:48:05.000000', '8112');";
		// String encryptedOTPValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			// System.out.println("Statement Created");
			// System.out.println("Insert Query is :"+queryString);
			stmt.executeUpdate(queryString);
			System.out.println("Query executed: " + queryString);
			// While Loop to iterate through all data and print results
			/*
			 * while (rs.next()) { encryptedOTPValue = rs.getString(1);
			 * System.out.println("OTP Value:"+encryptedOTPValue); }
			 */
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/* Setting Employee id with random number */

	public int verifyimageActive(WebElement imgElement) {
		int statusCode = 0;
		try {
			HttpClient client = HttpClientBuilder.create().build();
			HttpGet request = new HttpGet(imgElement.getAttribute("src"));
			HttpResponse response = client.execute(request);
			// verifying response code he HttpStatus should be 200 if not,
			// increment as invalid images count
			if (response.getStatusLine().getStatusCode() == 200) {
//				invalidImageCount++;
				statusCode = response.getStatusLine().getStatusCode();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return statusCode;

	}

	public void setRandomNumber(String sheetname, String colName) {

		excel = new Xls_Reader(Config.xlPath);
		int rowc = excel.getRowCount(sheetname);
		Random rand = new Random();
		for (int rowNum = 2; rowNum <= rowc; rowNum++) {
			int randomnumber = rand.nextInt(10000000);
			String randomdata = Integer.toString(randomnumber);
			excel.setCellData(sheetname, colName, rowNum, randomdata);

		}

	}

	// setting the excell sheet date to previous to previous sunday with MM/dd/YYYY
	// format

	public void setDateinExcell(String sheetname, String colName) {

		excel = new Xls_Reader(Config.xlPath);
		int rowc = excel.getRowCount(sheetname);
		String currentdate = GenericMethods.generateTimeStamp();
		SimpleDateFormat dateformate = new SimpleDateFormat("MM/dd/yyyy");
		Date date2 = null;

		try {
			date2 = dateformate.parse(currentdate);
		} catch (Exception e) {

			System.out.println(e.getCause());
		}

		Calendar cal = Calendar.getInstance();
		cal.setTime(date2);
		cal.add(Calendar.DAY_OF_WEEK, -(cal.get(Calendar.DAY_OF_WEEK) + 6));
		SimpleDateFormat dateformate1 = new SimpleDateFormat("MM/dd/yyyy");
		String privoustopreviousSunday = dateformate1.format(cal.getTime());
		System.out.println(privoustopreviousSunday);

		for (int rowNum = 2; rowNum <= rowc; rowNum++) {
			excel.setCellData(sheetname, colName, rowNum, privoustopreviousSunday);

		}

	}

	public void writingCardEncryptionValueToExcel(String sheetname, String colName, int rowNum,
			String cardEncryptedValue) {

		excel = new Xls_Reader(Config.xlPath);

		excel.setCellData(sheetname, colName, rowNum, cardEncryptedValue);

	}

	public static void writingToExcel(String XlFileName, String sheetname, String colName, int rowNum,
			String keyValue) {

		excel = new Xls_Reader(Config.xlPath + XlFileName);

		excel.setCellData(sheetname, colName, rowNum, keyValue);
		// System.out.println("Key Value is written in excel");

	}

	public void setCurrentDateInExcell(String sheetname, String colName) {

		excel = new Xls_Reader(Config.xlPath);
		int rowc = excel.getRowCount(sheetname);

		String CurrentDate = GenericMethods.generateTimeStamp();

		for (int rowNum = 2; rowNum <= rowc; rowNum++) {
			excel.setCellData(sheetname, colName, rowNum, CurrentDate);

		}

	}

	public void copyCellValueToSheet(String fromsheetname, String colName, String toSheetName) {

		excel = new Xls_Reader(Config.xlPath);
		int rowc = excel.getRowCount(fromsheetname);
		for (int rowNum = 2; rowNum <= rowc; rowNum++) {
			String cellValue = excel.getCellData(fromsheetname, colName, rowNum);
			excel.setCellData(toSheetName, colName, rowNum, cellValue);
		}

	}

	public void dynamicXpathForEmpId(String empId) throws Exception {
		try {

			driver.findElement(By.xpath("//tr[td[text()='" + empId + "']]//th/a")).click();

		} catch (AssertionError Ae) {
			Ae.printStackTrace();
		}
	}

	public void dynamicXpathForCurentDate() throws Exception {

		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH); // 3
		int year = cal.get(Calendar.YEAR); // 2014
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);
		try {
			System.out.println("current date:" + date);

			driver.findElement(By.xpath("//span[text()='04 Feb 2019']")).click();

		} catch (AssertionError Ae) {
			Ae.printStackTrace();
		}
	}

	public void dynamicXpathForDeptName(String DeptName) throws Exception {
		try {

			driver.findElement(By.xpath("//tr[td[2]/span/a[text()='" + DeptName + "']]//input[@type='checkbox']"))
					.click();

		} catch (AssertionError Ae) {
			Ae.printStackTrace();
		}
	}

	// Dynamic xpath for percentage field

	public void dynamicXpathForPersentage(String DeptName, String percentage) throws Exception {
		try {

			driver.findElement(By.xpath("//tr[td[2]/span/a[text()='" + DeptName + "']]//input[@type='text']"))
					.sendKeys(percentage);
			;

		} catch (AssertionError Ae) {
			Ae.printStackTrace();
		}
	}

	public void switchToWindow(WebDriver driver) {
		String parentWindow = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for (String windowHandle : handles) {
			if (!windowHandle.equals(parentWindow)) {
				driver.switchTo().window(windowHandle);
				// <!--Perform your operation here for new window-->
				// driver.close(); //closing child window
				// driver.switchTo().window(parentWindow); //cntrl to parent window
			}
		}
	}

	public void waitForPageLoaded(WebDriver driver) {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(expectation);
		} catch (Throwable error) {
			Assert.fail("Timeout waiting for Page Load Request to complete.");
		}
	}

	public void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(pageLoadCondition);
	}

	public void checkPageIsReady() {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Initially bellow given if condition will check ready state of page.
		if (js.executeScript("return document.readyState").toString().equals("complete")) {
			System.out.println("Page Is loaded.");
			return;
		}

		// This loop will rotate for 25 times to check If page Is ready after every 1
		// second.
		// You can replace your value with 25 If you wants to Increase or decrease wait
		// time.
		for (int i = 0; i < 30; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			// To check page ready state.
			if (js.executeScript("return document.readyState").toString().equals("complete")) {
				break;
			}
		}
	}

	// For Getting the current time stamp
	public static String mailscreenshotpath;

	public static String generateTimeStamp() {

		int count = 0;
		String timestamp;

		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH); // 3
		int year = cal.get(Calendar.YEAR); // 2014
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		// String timestamp = year+"_"+date+"_"+(month+1)+"_"+day+"_"+min+"_" +sec;
		// String timestamp = date+"/"+(month+1)+"/"+year;
		// String timestamp = (month + 1) + "/" + date + "/" + year;
		if (month < 9) {
			timestamp = year + "_" + "0" + (month + 1);

		} else {
			timestamp = year + "_" + (month + 1);

		}
		System.out.println("Created timestamp:" + timestamp);
		return timestamp;
	}

	public static String generateTimeStampForTxnTable() {

		int count = 0;
		String timestamp;

		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH); // 3
		int year = cal.get(Calendar.YEAR); // 2014
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		// String timestamp = year+"_"+date+"_"+(month+1)+"_"+day+"_"+min+"_" +sec;
		// String timestamp = date+"/"+(month+1)+"/"+year;
		// String timestamp = (month + 1) + "/" + date + "/" + year;
		if (month < 9) {
			timestamp = year + "" + "0" + (month + 1);

		} else {
			timestamp = year + "" + (month + 1);

		}
		System.out.println("Created timestamp:" + timestamp);
		return timestamp;
	}

	// For Taking the screen shots.
	public void CaptureScreenshot(WebDriver driver, String methodName) throws IOException {

		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH); // 3
		int year = cal.get(Calendar.YEAR); // 2014
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		mailscreenshotpath = System.getProperty("user.dir") + "\\src\\test\\Resources\\ScreenShots\\" + methodName + "_"
				+ year + "_" + (month + 1) + "-" + date + "_" + day + "_" + min + "_" + sec + ".jpeg";
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(mailscreenshotpath));
			System.out.println("Screen shot taken");
		} catch (Exception e) {
			System.out.println("Exception for screenshot mehtod : " + e);
		}

	}

	// For Taking the screen shots.
	public void CaptureScreenshotWithMethodName(String SSName) throws IOException {

		try {

			mailscreenshotpath = System.getProperty("user.dir") + "\\resources\\ScreenShots" + SSName + ".jpeg";

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(mailscreenshotpath));
		} catch (Exception e) {
			System.out.println("Exception while taking screen shot: " + e);
		}
	}

	GenericMethods generic = null;

	public boolean elementExistWithXpath(WebDriver d, String xpath, String SSName) throws IOException {
		try {
			driver.findElement(By.xpath(xpath));
			System.out.println("Element found with xpath:" + xpath);
			return true;
		} catch (NoSuchElementException ex) {
			System.out.println("Element not found with xpath:" + xpath);

			generic.CaptureScreenshot(d, SSName);
			return false;
		}
	}

	public boolean elementExistWithId(WebDriver d, String id, String SSName) throws IOException {
		try {
			driver.findElement(By.id(id));
			System.out.println("Element found with xpath:" + id);
			return true;
		} catch (NoSuchElementException ex) {
			System.out.println("Element not found with xpath:" + id);
			generic.CaptureScreenshot(d, SSName);
			return false;
		}
	}

	// for downloading file into local system.

	public static Robot robot;

	public void openNewWindow() throws AWTException {

		robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_T);
	}

	public static void downloadFile() throws AWTException {

		robot = new Robot();

		if (Config.BROWSER_NAME.equalsIgnoreCase("firefox")) {

			// robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} else if (Config.BROWSER_NAME.equalsIgnoreCase("chrome")) {

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		}
	}

	// for uploading a file
	public static void uploadFile(String filepath) {
		StringSelection file = new StringSelection(filepath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(file, null);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		// Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	// for accepting window popup
	public static void windowPopUpAccepting() {
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	// for cancealing window popup
	public static void widowPopUpCanceling() {
		robot.keyPress(KeyEvent.VK_CANCEL);
		robot.keyRelease(KeyEvent.VK_CANCEL);
	}

	// for mouse movements on windows applications
	public static void mouseMoveOnWindowPopUp() {
		robot.mouseMove(630, 420); // move mouse point to specific location 630, 420 are x and y coordinates
		robot.delay(1500); // delay is to make code wait for mentioned milliseconds before executing next
							// step
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // press left click
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // release left click
		robot.delay(1500);
		robot.keyPress(KeyEvent.VK_DOWN); // press keyboard arrow key to select Save radio button
		robot.keyPress(KeyEvent.VK_ENTER);
		// press enter key of keyboard to perform above selected action
	}

	public void selectByVisibleText(WebElement webelement, String text) {
		// System.out.println("Selecting by Text...");
		Select select = new Select(webelement);
		select.selectByVisibleText(text);

	}

	public static void selectByIndex(WebElement webelement, int index) {

		Select select = new Select(webelement);
		select.selectByIndex(index);
	}

	public static void selectByValue(WebElement webelement, String value) {

		Select select = new Select(webelement);
		select.selectByValue(value);
	}

	public void clickUsingJS(WebElement button) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", button);

	}

	public void waitForProgressBar() {
		long timeoutInSeconds = 30;
		if (driver.findElements(By.xpath("//div[@role='alert']")).size() > 0) {
			System.out.println("Waiting... for progress bar");
			new WebDriverWait(driver, timeoutInSeconds)
					.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@role='alert']")));
		}
	}

	public String getValueFromXml(String xml) {
		String value = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.parse(new InputSource(new StringReader(xml)));
			Element rootElement = document.getDocumentElement();
			// String acsTxnId = rootElement.getAttribute("acctID");

			value = rootElement.getElementsByTagName("acctID").item(0).getTextContent();
			// System.out.println("acsTxnId_Final:-"+value);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return value;

	}

	/*
	 * public boolean elementExist(WebDriver d, String element) { try {
	 * driver.findElement(By.xpath(xpath));
	 * logger.info("Element found with xpath:"+xpath); return true; }
	 * catch(NoSuchElementException ex) { return false; } }
	 */
	// all these methods are from keywrod driven testing frame work methods i am
	// trying to modify to support data driven

	/*
	 * public boolean elementExist(String xpath) { try {
	 * driver.findElement(By.xpath(xpath));
	 * logger.info("Element found with xpath:"+xpath); return true; }
	 * catch(NoSuchElementException ex) { return false; } }
	 * 
	 * 
	 * 
	 * public void verifyText(String xpath,String expectedText) {
	 * if(elementExist(xpath)) { String
	 * actualText=driver.findElement(By.xpath(xpath)).getText();
	 * if(actualText.equalsIgnoreCase(expectedText)) {
	 * logger.info("Text is correct:"+expectedText); } else { scriptStatus="FAIL";
	 * logger.error("FAIL:Text is not correct:Expected:"+expectedText+" Actual:"
	 * +actualText); } } else { scriptStatus="FAIL";
	 * logger.error("FAIL:verifyText();Element Not Found with the xpath:"+xpath ); }
	 * }
	 * 
	 * public void sendKeys(String xpath,String input) {
	 * 
	 * if(elementExist(xpath)) {
	 * driver.findElement(By.xpath(xpath)).sendKeys(input);
	 * logger.info("Entering \""+input+"\""); } else { scriptStatus="FAIL";
	 * logger.error("FAIL:sendKeys();Element Not Found with the xpath:"+xpath); } }
	 * 
	 * public void click(String xpath) {
	 * 
	 * if(elementExist(xpath)) { driver.findElement(By.xpath(xpath)).click();
	 * 
	 * } else { scriptStatus="FAIL";
	 * logger.error("FAIL:click(): Element Not Found with the xpath:"+xpath); } }
	 * 
	 * public void clearText(String xpath) { if(elementExist(xpath)) {
	 * driver.findElement(By.xpath(xpath)).clear(); } else { scriptStatus="FAIL";
	 * logger.error("FAIL:clearText();Element Not Found with the xpath:"+xpath); } }
	 * 
	 * public void waitForSeconds(String s) { try { int seconds =
	 * Integer.parseInt(s); Thread.sleep(1000 * seconds); logger.info("Wait for "+
	 * seconds + " seconds"); } catch(InterruptedException ex) {
	 * logger.error("invalid input for: waitForSeconds "); } }
	 * 
	 * 
	 * public void checkAlertDisplayed() { WebDriverWait wait = new
	 * WebDriverWait(driver, 3);
	 * 
	 * if(wait.until(ExpectedConditions.alertIsPresent())!=null){
	 * System.out.println("Alewrt is present!"); Alert alert =
	 * driver.switchTo().alert(); String logoutSmsg = alert.getText();
	 * alert.accept(); try{ Assert.assertEquals(logoutSmsg,
	 * "You Have Succesfully Logged Out!!"); }catch(Throwable t){
	 * System.out.println("alert message:"+logoutSmsg);
	 * ErrorCollector.addVerificationFailure(t); }
	 * 
	 * } }
	 * 
	 * public void acceptAlertPopup() { try { driver.switchTo().alert().accept();
	 * logger.info("Alert popup accepted: "); } catch(Exception ex) {
	 * scriptStatus="FAIL";
	 * logger.error("FAIL:acceptAlertPopup();Accept Alert popup failed:"); } }
	 * 
	 * public void dismissAlertPopup() { try { driver.switchTo().alert().dismiss();
	 * logger.info("Alert popup dismissed: "); } catch(Exception ex) {
	 * scriptStatus="FAIL";
	 * logger.error("FAIL:dismissAlertPopup();dismiss Alert popup failed:"); } }
	 * 
	 * public void verifyElementPresent(String xpath) { if(elementExist(xpath)) {
	 * 
	 * logger.info("Element found with xpath:"+xpath); } else { scriptStatus="FAIL";
	 * logger.error("Element not found with xpath:"+xpath); } }
	 * 
	 * public void verifyElementNotPresent(String xpath) { if(elementExist(xpath)) {
	 * scriptStatus="FAIL"; logger.error("Element found with xpath:"+xpath); } else
	 * { logger.info("Element not found with xpath:"+xpath); } }
	 * 
	 * 
	 * public static void mani(String[] args) { GenericMethods test = new
	 * GenericMethods();
	 * test.updateCardStatusToActive("v1HSFix1XiRN2C7jzPB3FRKRQBLNeeal");
	 * 
	 * }
	 */
	
	public String getAccuResponseCode(String responseData) {
		String accuResponseCode = null;
		if (responseData.contains("AccuGuid")) {			
			String arr[] = responseData.split(" :");
			String temp = arr[3];
			accuResponseCode = temp.replace("AccuRequestId", "");
			accuResponseCode = accuResponseCode.trim().replaceAll("[\n]{2,}", "");

			System.out.println("---------- bingo !!!!!!!!!!!!!! returned response for " + accuResponseCode);
			System.out.print("value");
		}
		return accuResponseCode;
		
	}
	
	private String getEncryptCardRequestBody(String card, String key) {
		
		String jsonbody="{"
				+ "	\"data\": \""+Base64Utility.encode(card)+"\","
				+ "	\"encId\": \"09\","
				+ "	\"keyAlias\": \""+key+"\","
				+ "	\"keyAliasType\": \"AES256\","
				+ "	\"mode\": \"HK_AC\""
				+ "	}";
		return jsonbody;
		
	}
	
	public String getEncryptedCard(String card, String key) {
		
		String jsonbody = getEncryptCardRequestBody(card, key);
		System.out.println(jsonbody);
		Reporter.log("JSON Request Body:   " + jsonbody);
		
		Response response = given()
				.accept(ContentType.JSON)
				.with()
				.contentType(ContentType.JSON)
				.and()
				.body(jsonbody)
				.when()
				.post(Config.BASE_ENCRYPT_URL);

		String responseBody = response.getBody().asString();
		// validate status code
		Reporter.log("Status Code" + response.getStatusCode());
		Reporter.log("Response of Encode String" + responseBody);
		response.then().statusCode(200);
		
		
		JsonPath jsonPathEvaluator = response.jsonPath();
		return jsonPathEvaluator.getString("data");
	}
	
	
	/* OOB AUTH Approve */
	//https://3ds2-ui-acsdcs.pc.enstage-sas.com/v1/oob/services/acs/txnAuthStatus/9055/55b911ca-c976-11ee-ad78-457b48e6fb14
	
	
	public static Response oobAuthApprove(String acsTxnId, String traceId, String bankId, String status) throws IOException {
		String url = Config.BASE_OOB_AUTH_URL+bankId+"/"+acsTxnId;
		String jsonbody = "{"
				+ "  \"txnId\": \""+acsTxnId+"\","
				+ "  \"traceId\": \""+traceId+"\","
				+ "  \"txnStatus\": \""+status+"\","
				+ "  \"timeStamp\": \"2024-02-12 12:33:46\","
				+ "  \"txnStatusUrl\": \""+url+"\""
				+ "}";
		
		System.out.println(jsonbody);
		
		Map<String,String> m = new HashMap<String, String>();
		m.put("clientId", Config.BASE_OOB_CLIENT_ID);	
		m.put("x-api-key", Config.BASE_OOB_x_api_key);
		m.put("txnId", acsTxnId);
		m.put("Content-Type", "application/json");
		
		
		Response oobAuthResponse = given()
				.headers(m)
				.body(jsonbody)
			.when().post(url);
		
		Reporter.log("Status Code" + oobAuthResponse.getStatusCode());
		Reporter.log("Response of Encode Generate OTP" + oobAuthResponse);
		oobAuthResponse.then().statusCode(200);
		return oobAuthResponse;
	}
}

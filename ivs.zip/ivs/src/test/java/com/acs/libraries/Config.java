/*
 * Declare some common parameters for scripts
 * You can change them to adapt your environment
 *
 */
package com.acs.libraries;

public class Config {

	/* You can change the Path of FireFox here based on your environment */

	public static final String GECKODRIVER_PATH = System.getProperty("user.dir")
			+ "/Browser_drivers/geckodriverV0.33.0.exe";

	public static final String CHROMEDRIVER_PATH = System.getProperty("user.dir")
			+ "/Browser_drivers/chromedriver_win_121.exe";

	public static final String LINUX_GECKODRIVER_PATH = System.getProperty("user.dir")
			+ "/Browser_drivers/geckodriver-linuxV0.23.0.exe";

	public static final String LINUX_CHROMEDRIVER_PATH = System.getProperty("user.dir")
			+ "/Browser_drivers/chromedriver_linux_120";

	public static final String MAC_GECKODRIVER_PATH = System.getProperty("user.dir")
			+ "/Browser_drivers/geckodriver-mac";

	public static final String MAC_CHROMEDRIVER_PATH = System.getProperty("user.dir") + "/Browser_drivers/";

	public static final String UPLOADINGFILES_PATH = System.getProperty("user.dir") + "/UploadingFiles/";

	// Production urls
	public static final String PRO_TRANSACTION_URL = "https://3ds2-ui-3dsserverdemo-bdc1.enstage-uat.com/Merchant-Simulator-dev/transaction.html";
	public static final String PRO_CARD_REGISTRATION = "https://secure-adiba-acs-custapi.wibmo.com/CustDetails.html";
	public static final String PRO_OTPENGINE_URI = "http://productionip:portnumber";

	public static final String PRO_UAM_URL = "https://secure-admin-ui.wibmo.com";
	public static final String PRO_UAM_ADMIN_USER_NAME = "federal";
	public static final String PRO_UAM_ADMIN_PASSWD = "password";
	public static final String PRO_UAM_ISSUER_BANK_NAME = "federal";
	public static final String PRO_UAM_ACQUIRER_BANK_NAME = "federal";
	public static final String PRO_UAM_WIBMO_BANK_NAME = "WIBMO";

	// DC2 urls.
	public static final String DC2_TRANSACTION_URL = "https://3ds2-cust-api-acsdc2.pc.enstage-sas.com/Merchant-Simulator-dc2/transaction.html";
	public static final String DC2_CARD_REGISTRATION = "https://3ds2-cust-api-acsdc2.pc.enstage-sas.com/checkout-simulator-dc2/CustDetails.html";

	public static final String DC2_UAM_URL = "https://3ds2-admin-uidc2.pc.enstage-sas.com";
	public static final String DC2_CARD_ENCRYPT_PATH = System.getProperty("user.dir")
			+ "/EnNDcrypt-Simulator/contact-form-in-html-and-css/cardEncrypt-DC2.html";
	public static final String DC2_OTPENGINE_URI = "http://192.168.105.205:8004";
	public static final String DC2_ENCRYPT_URI = "http://192.168.105.207:8015";

	public static final String DC2_CUSTOMER_DATA_SCHEMA = "accosa2qadc2_custdata_";
	public static final String DC2_ACS_TXN_SCHEMA = "accosa2qadc2_acs_txn_";
	public static final String DC2_3DSS_TXN_SCHEMA = "accosa2qadc2_acs_txn_";
	public static final String DC2_ADMIN_SCHEMA = "accosa2qadc2_admin";
	public static final String DC2_CONFIG_SCHEMA = "accosa2qadc2_config";

	public static final String DC2_UAM_ADMIN_USER_NAME = "federal";
	public static final String DC2_UAM_ADMIN_PASSWD = "password";

	public static final String DC2_UAM_ISSUER_BANK_NAME = "federal";
	public static final String DC2_UAM_ACQUIRER_BANK_NAME = "federal";

	// DCS Urls
	public static final String DCS_TRANSACTION_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/Merchant-Simulator-dcs/transaction.html";
	public static final String DCS_NEW_SIMULATOR_TRANSACTION_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/acs1-simulator-stg/cart_summary.html";																	
	public static final String DCS_MPI_SIMULATOR_TRANSACTION_URL = "https://mpitest-acs2stg-csr.pc.enstage-sas.com/wibmo/CameraStoreSiteACS2STG/gateway.jsp";
	public static final String DCS_CARD_REGISTRATION = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/checkout-simulator-dcs/CustDetails.html";
	public static final String DCS_UAM_URL = "https://3ds2-admin-uidcs.pc.enstage-sas.com";
	public static final String DCS_CARD_ENCRYPT_PATH = System.getProperty("user.dir")
			+ "/EnNDcrypt-Simulator/contact-form-in-html-and-css/cardEncrypt-DCS.html";
	public static final String DCS_OTPENGINE_URI = "http://192.168.108.160:5112";
			//"http://192.168.108.62:5004";
	public static final String DCS_ADMIN_CARD_UNBLOCKING_URL = "https://3ds2-admin-uidcs.pc.enstage-sas.com";

	public static final String DCS_IVR_TRANSACTION_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/acs1-simulator-stg/ivr_vereqFlow.html";														  
	public static final String DCS_IVR_VEREQ_URL = "http://192.168.108.160:5140/v1/acs/services/vereq/";
	public static final String DCS_IVR_PAREC_URL = "http://192.168.108.160:5144";
			//"http://192.168.108.63:5014/v1/acs/services/vereq/";
	public static final String DCS_ACS_SIMULATOR_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/3ds-merchant-dcs/ACSSimulator.html";
			//"https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/acs1-simulator-stg/ACSSimulator.html";
														
	public static final String DCS_ACS_SIMULATOR_AREQ_URL = "http://192.168.108.160:5124/v1/acs/services/areq/";
														  //"http://192.168.108.64:5007/v1/acs/services/areq/";
	public static final String DCS_PUSH_API_ENCRYPT_URL = "";
	public static final String DCS_PUSH_API_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/v1/enrollCardInfo/";
	
	public static final String DCS_deWhiteListed_API_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/v1/actionOnCustMerchant/";
	public static final String DCS_SaveErrorList_API_URL = "https://3ds2-cust-api-acsdcs.pc.enstage-sas.com/v1/acs/services/areq/";
	public static final String DCS_DS_FOR_RREQ_URL = "http://192.168.108.160:5200/v1/acsSimulator/rreq";
													  

	public static final String DCS_EXPRESS_MPI_URL = "https://payumpistaging-dw.pc.enstage-sas.com/MultiMPI/MerchantRequestProcessor/";
	public static final String DCS_EXPRESS_IVS_URL = "http://192.168.108.160:5124";
	public static final String DCS_EXPRESS_IVS_UI_URL = "https://3ds2-ui-acsdcs.pc.enstage-sas.com";
	
	/*E2FA*/
	public static final String DCS_E2FA_URL = "http://192.168.108.106:8091";
	public static final String DCS_E2FA_APIUSER = "hdfc_dc";
	public static final String DCS_E2FA_APIKEY = "testing";
	
	public static final String DCS_PVRQ_URL = "https://3ds2-api-3dsserverdcs.pc.enstage-sas.com/3dsserverapi/v3/pVrq/8126";
	public static final String DCS_PRQFRQ_URL = "https://3ds2-api-3dsserverdcs.pc.enstage-sas.com/3dsserverapi/v3/pRqFrq/indblr-blrrel/8126";
	
	//Express pay MPI data base details
	public static String ePayMPImysqldriver = "com.mysql.jdbc.Driver";
	public static String ePayMPImysqluserName = "accosa_user";
	public static String ePayMPImysqlpassword = "accosa2k4";
	public static String ePayMPImysqlurl = "jdbc:mysql://192.168.106.95:3306";


	public static final String DCS_ENCRYPT_URI = "http://192.168.108.64:5050";

	public static final String DCS_CUSTOMER_DATA_SCHEMA = "acs2qadcs_custdata_";
	public static final String DCS_ACS_TXN_SCHEMA = "acs2qadcs_acs_txn_";
	public static final String DCS_3DSS_TXN_SCHEMA = "acs2qadcs_3dss_txn_";
	public static final String DCS_ADMIN_SCHEMA = "acs2qadcs_admin";
	public static final String DCS_CONFIG_SCHEMA = "acs2qadcs_config";

	public static final String DCS_UAM_ADMIN_USER_NAME = "demouser";
	public static final String DCS_UAM_ADMIN_PASSWD = "Wibmo@123";
	
	public static final String DCS_UAM_ADMIN_MAKER_USER_NAME = "Automation";
	public static final String DCS_UAM_ADMIN_MAKER_PASSWD = "Wibmo@123";
//  User Name and password for checker
	public static final String DCS_UAM_ADMIN_CHECKER_USER_NAME = "demochecker";
	public static final String DCS_UAM_ADMIN_CHECKER_PASSWD = "Wibmo@123";
//	public static final String DCS_UAM_ISSUER_BANK_NAME = "National Bank";
	public static final String DCS_UAM_WIBMO_BANK_NAME = "Wibmo";
//	public static final String DCS_UAM_ACQUIRER_BANK_NAME = "Federal Bank";
	public static final String DCS_ANDROID_APK_FILE_PATH = System.getProperty("user.dir")
			+ "/APKFiles/wibmo-three-ds2-BIN_8126-Auto-DCS-28-June-2019.apk";
	
	public static final String DCS_OOB_AUTH_URL = "https://3ds2-ui-acsdcs.pc.enstage-sas.com/v1/oob/services/acs/txnAuthStatus/";
	public static final String DCS_OOB_CLIENT_ID = "5a491b0a-335e-4e90-a63a-b6e769b827d0";
	public static final String DCS_OOB_x_api_key = "bWav*j0C16F\"OlI U~#f>\\9^";
	
	public static String[] bankIdAlertPopup= {"8131","8562","8129","8191"};
	
	//UAT1XM ursl
	public static final String UAT1_TRANSACTION_URL = "https://3ds2-cust-api-acsuat1xm.pc.enstage-sas.com/Merchant-Simulator-uat1xm/transaction.html";
	public static final String UAT1_NEW_SIMULATOR_TRANSACTION_URL = "https://3ds2-cust-api-acsuat1xm.pc.enstage-sas.com/acs1-simulator-uat1xm/cart_summary.html";																   
	public static final String UAT1_MPI_SIMULATOR_TRANSACTION_URL = "https://mpitest-acs2ivs-csr.pc.enstage-sas.com/wibmo/CameraStoreSiteACS2IVS/gateway.jsp";
	public static final String UAT1_CARD_REGISTRATION = "https://3ds2-cust-api-acsuat1xm.pc.enstage-sas.com/checkout-simulator-uat1xm/CustDetails.html";
	public static final String UAT1_UAM_URL = "https://3ds2-admin-uiuat1xm.pc.enstage-sas.com/";
	public static final String UAT1_OTPENGINE_URI = "http://192.168.108.159:6112";
	public static final String UAT1_CORPORATE_ID = "wibmo";
	public static final String UAT1_EMPLOYEE_ID = "1958";
	public static final String UAT1_PUSH_API_ENCRYPT_URL = "https://3ds2-cust-api-acsuat1xm.pc.enstage-sas.com/v1/customer/encryptJson/PUSH_API/";
	public static final String UAT1_PUSH_API_URL = "https://3ds2-cust-api-acsuat1xm.pc.enstage-sas.com/v3/enrollCardInfo/";
	
	
	
	// UAT Urls
	public static final String UAT_TRANSACTION_URL = "https://3ds2-cust-api-acsuat.pc.enstage-sas.com/Merchant-Simulator-uat/transaction.html";
	public static final String UAT_NEW_SIMULATOR_TRANSACTION_URL = "https://3ds2-cust-api-acsuat.pc.enstage-sas.com/Merchant-Simulator-uat/cart_summary.html?";
	   
	public static final String UAT_MPI_SIMULATOR_TRANSACTION_URL = "https://mpitest-acs2uat-csr.pc.enstage-sas.com/wibmo/CameraStoreSiteACS2UAT/gateway.jsp";

	public static final String UAT_CARD_REGISTRATION = "https://3ds2-cust-api-acsuat.pc.enstage-sas.com/checkout-simulator-uat/CustDetails.html";
	public static final String UAT_UAM_URL = "https://3ds2-admin-uiuat.pc.enstage-sas.com";
	public static final String UAT_OTPENGINE_URI = "http://192.168.108.90:8812";
	public static final String UAT_ADMIN_CARD_UNBLOCKING_URL = "https://3ds2-admin-uiduat.pc.enstage-sas.co m";

	public static final String UAT_ENCRYPT_URI = "http://192.168.108.64:5050";

	public static final String UAT_UAM_ADMIN_USER_NAME = "demouser";
	public static final String UAT_UAM_ADMIN_PASSWD = "Wibmo@123";
	public static final String UAT_UAM_ISSUER_BANK_NAME = "National Bank";
	public static final String UAT_UAM_WIBMO_BANK_NAME = "Wibmo";
	public static final String UAT_UAM_ACQUIRER_BANK_NAME = "Federal Bank";
	public static final String UAT_ANDROID_APK_FILE_PATH = System.getProperty("user.dir")
			+ "/APKFiles/wibmo-three-ds2-BIN_8126-Auto-UAT-28-June-2019.apk";

	// CAA Urls
	public static final String CAA_TRANSACTION_URL = "https://stg1-cust-api-acs.pc.enstage-sas.com/Merchant-Simulator-stg1/cart_summary.html";
	public static final String CAA_CARD_REGISTRATION = "https://stg1-cust-api-acs.pc.enstage-sas.com/checkout-simulator-stg1/CustDetails.html";
	public static final String CAA_UAM_URL = "https://stg1-admin-ui-b1.pc.enstage-sas.com";
	public static final String CAA_OTPENGINE_URI = "http://192.168.108.87:5112";
	public static final String CAA_ADMIN_CARD_UNBLOCKING_URL = "https://stg1-admin-ui-b1.pc.enstage-sas.com";

	public static final String CAA_ENCRYPT_URI = "http://192.168.108.64:5050";

	public static final String CAA_UAM_ADMIN_USER_NAME = "demouser";
	public static final String CAA_UAM_ADMIN_PASSWD = "password";
	public static final String CAA_UAM_ISSUER_BANK_NAME = "ADIBA Bank";
	public static final String CAA_UAM_WIBMO_BANK_NAME = "Wibmo";
	public static final String CAA_UAM_ACQUIRER_BANK_NAME = "Federal Bank";
	public static final String CAA_ANDROID_APK_FILE_PATH = System.getProperty("user.dir")
			+ "/APKFiles/wibmo-three-ds2-BIN_8126-Auto-CAA-28-June-2019.apk";

	// Dev Urls
	public static final String PILOT_TRANSACTION_URL = "https://3ds2-cust-api-acsdev.enstage-uat.com/Merchant-Simulator-pilot/transaction.html";
	public static final String PILOT_CARD_REGISTRATION = "https://3ds2-cust-api-acsdev.enstage-uat.com/Merchant-Simulator-pilot/CustDetails.html";
	public static final String PILOT_OTPENGINE_URI = "http://192.168.108.53:6085";

	public static final String PILOT_ENCRYPT_URI = "http://192.168.108.61:6014";

	public static final String PILOT_CUSTOMER_DATA_SCHEMA = "accosa2dev_custdata_";
	public static final String PILOT_ACS_TXN_SCHEMA = "accosa2dev_acs_txn_";
	public static final String PILOT_3DSS_TXN_SCHEMA = "accosa2dev_3dss_txn_";
	public static final String PILOT_ADMIN_SCHEMA = "accosa2dev_admin";
	public static final String PILOT_CONFIG_SCHEMA = "accosa2dev_config";

	public static final String PILOT_UAM_ADMIN_USER_NAME = "federal";
	public static final String PILOT_UAM_ADMIN_PASSWD = "password";
	public static final String PILOT_UAM_ISSUER_BANK_NAME = "federal";
	public static final String PILOT_UAM_ACQUIRER_BANK_NAME = "federal";

	// CRT Urls
	public static final String CRT_TRANSACTION_URL = "https://3ds2-cust-api-acsdev.enstage-uat.com/Merchant-Simulator-dev/transaction.html";
	public static final String CRT_CARD_REGISTRATION = "";
	public static final String CRT_OTPENGINE_URI = "http://192.168.108.53:6085";

	public static final String CRT_ENCRYPT_URI = "http://192.168.108.61:6014";

	public static final String CRT_CUSTOMER_DATA_SCHEMA = "acs2crt_custdata_";
	public static final String CRT_ACS_TXN_SCHEMA = "acs2crt_acs_txn_";
	public static final String CRT_3DSS_TXN_SCHEMA = "acs2crt_3dss_txn_";
	public static final String CRT_ADMIN_SCHEMA = "acs2crt_admin";
	public static final String CRT_CONFIG_SCHEMA = "acs2crt_config";

	public static final String CRT_UAM_ADMIN_USER_NAME = "federal";
	public static final String CRT_UAM_ADMIN_PASSWD = "password";
	public static final String CRT_UAM_ISSUER_BANK_NAME = "federal";
	public static final String CRT_UAM_ACQUIRER_BANK_NAME = "federal";

	// Demo urls
	public static final String DEMO_TRANSACTION_URL = "https://3ds2-cust-api-acsdemo.pc.enstage-sas.com/Merchant-Simulator-demo/transaction.html";
	public static final String DEMO_CARD_REGISTRATION = "https://3ds2-cust-api-acsdemo.pc.enstage-sas.com/Merchant-Simulator-demo/CustDetails.html";
	public static final String DEMO_OTPENGINE_URI = "http://192.168.108.90:8519";

	public static final String DEMO_ENCRYPT_URI = "http://192.168.108.90:8562";

	public static final String DEMO_CUSTOMER_DATA_SCHEMA = "acs2demo_custdata_";
	public static final String DEMO_ACS_TXN_SCHEMA = "acs2demo_acs_txn_";
	public static final String DEMO_3DSS_TXN_SCHEMA = "acs2demo_3dss_txn_";
	public static final String DEMO_ADMIN_SCHEMA = "acs2demo_admin";
	public static final String DEMO_CONFIG_SCHEMA = "acs2demo_config";

	public static final String DEMO_UAM_URL = "https://3ds2-admin-uidemo.pc.enstage-sas.com/";
	public static final String DEMO_UAM_ADMIN_USER_NAME = "federal";
	public static final String DEMO_UAM_ADMIN_PASSWD = "password";

	public static final String DEMO_UAM_ISSUER_BANK_NAME = "federal";
	public static final String DEMO_UAM_ACQUIRER_BANK_NAME = "federal";

	public static final String MERCHANT_ID = "9876543210001";

	public static final String STATIC_PASSWORD = "hello";

	public static final String CARD_EXPIRY_DATE = "2404";
	public static final String CARD_HOLDER_NAME = "Automation test";

	public static final String PURCHASE_AMOUNT_MIN = "12";
	public static final String PURCHASE_AMOUNT_MAX = "1234";

	// Excell file path
	public static final String xlPath = System.getProperty("user.dir") + "/TestData/";

	// for Test report mailing configuration we can use the below parameters
	public static String smtphost = "http://192.168.104.76:8195";
	public static String smtpport = "8195";
	public static String frommailid = "subhash.chilka@wibmo.com";
	public static String mailpassword = "password";
	// { "3ds2.0dev@wibmo.com", "3ds2.0managers@wibmo.com", "3ds2.0qa@wibmo.com" }
	public static String[] sendmailto = { "subhash.chilka@wibmo.com" };
	public static String[] mailCCArr = { "subhash.chilka@wibmo.com" };
	public static String[] mailBCCArr = {};
	public static String subject = "Test Report";

	public static String messageBody = "TestMessage";
	public static String[] attachmentPath = { System.getProperty("user.dir") + "/ExtentReports/" };
	public static String attachmentName = "ExtentReportResults.html";

	public static String BROWSER_NAME = "Chrome";
	// For Database connection configuration

	// SQL DATABASE DETAILS
	public static String sqldriver = "net.sourceforge.jtds.jdbc.Driver";
	// public static String
	// dbConnectionUrl="jdbc:jtds:sqlserver://192.101.44.22;DatabaseName=monitor_eval";
	public static String dbUserName = "subhash";
	public static String dbPassword = "$ql$!!1";

	// MYSQL DATABASE DETAILS
	public static String mysqldriver = "com.mysql.jdbc.Driver";
	public static String mysqluserName = "acsqa";
	public static String mysqlpassword = "dbacs@#S20";
	public static String mysqlurl = "jdbc:mysql://192.168.110.36:3306";

	// Android Basic Test

	public static final String ANDROID_DEVICE_NAME = "f8188e73";
	public static final String ANDROID_VERSION = "9";
	public static final String ANDROID_DEVICE_ID = "172.31.2.204:5555";
	public static final String NODE_JS_PATH = "C:/Program Files/nodejs/node.exe";
	public static final String APPIUM_MAIN_PATH = "C:/Users/subhash.chilka/AppData/Local/Programs/Appium/resources/app/node_modules/appium/build/lib/main.js";
//	public static final String APPIUM_LOGS_PATH = System.getProperty("user.dir") + "\\Logs\\Appium.log";
	public static final String ANDRIOD_CARD_HOLDER_NAME = "Android Transaction";
	public static final String CARD_EXPIRY_YEAR = "24";
	public static final String CARD_EXPIRY_MONTH = "02";
	public static final String CARD_CVV = "123";

// Trident urls
	public static final String STAGING_TRIDENT_URL = "http://192.168.108.79:8089/TridentCSR/index.jsp";
	// old https://192.168.108.80:8443/TridentCSR/index.jsp
	public static final String STAGING_TRIDENT_USERNAME = "AUTO1";
	public static final String STAGING_TRIDENT_PASSWORD = "enstage-123";
	public static final String STAGING_TRIDENT_INSTANCEID = "*";
	public static final String STAGING_TRIDENT_BANKID = "9111";
	public static final String STAGING_TRIDENT_CHANNELID = "3DS2.0";

	public static final String PRO_TRIDENT_URL = "https://192.168.108.80:8443/TridentCSR/index.jsp";
	public static final String PRO_TRIDENT_USERNAME = "SWETHA";
	public static final String PRO_TRIDENT_PASSWORD = "enstage147";
	public static final String PRO_TRIDENT_INSTANCEID = "9111";
	public static final String PRO_TRIDENT_BANKID = "9111";
	public static final String PRO_TRIDENT_CHANNELID = "3DS2.0";
	
	
	// Rupay URL's
	public static final String UAT1_RUPAY_HOME_URL = "https://3ds2-acs2rupayuat1xm-b1-indblr-blrrel.pc.enstage-sas.com/rupaypit/RupayPit.jsp";
	public static final String UAT1_RUPAY_TRANSACTION_URL = "https://3ds2-acs2rupayuat1xm-b1-indblr-blrrel.pc.enstage-sas.com/pit/RedirectionClient_hash.jsp";
	
	// Rupay BEPG
	public static final String UAT1_BEPG_MPI_URL = "https://3ds2-acs2rupayuat1xm-b1-indblr-blrrel.pc.enstage-sas.com/rupay-web-v1/NPCI/BEPG/";

	// Setting Base Configuration
	public static String BASE_TRANSACTION_URL = Config.UAT1_TRANSACTION_URL;
	public static String BASE_NEW_SIMULATOR_TRANSACTION_URL = Config.UAT1_NEW_SIMULATOR_TRANSACTION_URL;
	public static String BASE_MPI_SIMULATOR_TRANSACTION_URL = Config.UAT1_MPI_SIMULATOR_TRANSACTION_URL;
	
	public static final String BASE_IVR_TRANSACTION_URL = Config.DCS_IVR_TRANSACTION_URL;
	public static final String BASE_IVR_VEREQ_IP = Config.DCS_IVR_VEREQ_URL;
	public static final String BASE_IVR_PAREQ_IP = Config.DCS_IVR_PAREC_URL;
	public static final String BASE_ACS_SIMULATOR_URL = Config.DCS_ACS_SIMULATOR_URL;
	public static final String BASE_ACS_SIMULATOR_AREQ_URL = Config.DCS_ACS_SIMULATOR_AREQ_URL;
	public static String BASE_PUSH_API_ENCRYPT_URL = Config.DCS_PUSH_API_ENCRYPT_URL;
	public static String BASE_PUSH_API_URL = Config.DCS_PUSH_API_URL;
	public static final String BASE_deWhiteListed_API_URL = Config.DCS_deWhiteListed_API_URL;
	
	public static final String BASE_EXPRESS_MPI_URL = Config.DCS_EXPRESS_MPI_URL;
	public static final String BASE_EXPRESS_IVR_URL = Config.DCS_EXPRESS_IVS_URL;
	public static final String BASE_EXPRESS_IVR_UI_URL = Config.DCS_EXPRESS_IVS_UI_URL;
	public static final String BASE_V9PG_TRANSACTION_URL = "https://devtest-sim.enstage-uat.com/";
//	public static final String ISSUER_BANK_ID = "9111";
//	public static final String ACQUIRER_BANK_ID = "8126";
	public static String BASE_ENVIRONMENT = "DCS";

	public static String BASE_OTPENGINE_URI = Config.UAT1_OTPENGINE_URI;
	public static final String BASE_ENCRYPTION_URI = Config.DCS_ENCRYPT_URI;
	public static final String BASE_CRAD_REGISTRATION_URL = Config.DCS_CARD_REGISTRATION;
	public static final String BASE_CARD_ENCRYPT_PATH = Config.DCS_CARD_ENCRYPT_PATH;
	public static String BASE_UAM_URL = Config.DCS_UAM_URL;
	public static final String BASE_ADMIN_CARD_UNBLOCKING_URI = Config.DCS_ADMIN_CARD_UNBLOCKING_URL;

//	public static final String BASE_CUSTOMER_DATA_SCHEMA = Config.DCS_CUSTOMER_DATA_SCHEMA + Config.ISSUER_BANK_ID;
	public static final String BASE_CONFIG_SCHEMA = Config.DCS_CONFIG_SCHEMA;
//	public static final String BASE_ACS_TXN_SCHEMA = Config.DCS_ACS_TXN_SCHEMA + Config.ISSUER_BANK_ID;
//	public static final String BASE_3DSS_TXN_SCHEMA = Config.DCS_3DSS_TXN_SCHEMA + Config.ACQUIRER_BANK_ID;

	public static final String BASE_ADMIN_SCHEMA = Config.DCS_ADMIN_SCHEMA;
	public static final String BASE_UAM_ADMIN_USER_NAME = Config.DCS_UAM_ADMIN_USER_NAME;
	public static final String BASE_UAM_ADMIN_PASSWD = Config.DCS_UAM_ADMIN_PASSWD;

	// For Checker
	public static final String BASE_UAM_ADMIN_CHECKER_USER_NAME = Config.DCS_UAM_ADMIN_CHECKER_USER_NAME;
	public static final String BASE_UAM_ADMIN_CHECKER_PASSWD = Config.DCS_UAM_ADMIN_CHECKER_PASSWD;

//	public static final String BASE_UAM_ISSUER_BANK_NAME = Config.DCS_UAM_ISSUER_BANK_NAME;
//	public static final String BASE_UAM_ACQUIRER_BANK_NAME = Config.DCS_UAM_ACQUIRER_BANK_NAME;
	public static final String BASE_UAM_WIBMO_BANK_NAME = Config.DCS_UAM_WIBMO_BANK_NAME;
	public static final String BASE_ANDROID_APK_FILE_PATH = Config.DCS_ANDROID_APK_FILE_PATH;

	public static final String BASE_TRIDENT_URL = Config.STAGING_TRIDENT_URL;
	public static final String BASE_TRIDENT_USERNAME = Config.STAGING_TRIDENT_USERNAME;
	public static final String BASE_TRIDENT_PASSWORD = Config.STAGING_TRIDENT_PASSWORD;
	public static final String BASE_TRIDENT_INSTANCEID = Config.STAGING_TRIDENT_INSTANCEID;
	public static final String BASE_TRIDENT_BANKID = Config.STAGING_TRIDENT_BANKID;
	public static final String BASE_TRIDENT_CHANNELID = Config.STAGING_TRIDENT_CHANNELID;
	
	public static final String BASE_RUPAY_HOME_URL = Config.UAT1_RUPAY_HOME_URL;
	public static final String BASE_RUPAY_TRANSACTION_URL = Config.UAT1_RUPAY_TRANSACTION_URL;
	
	public static final String BASE_BEPG_MPI_URL = Config.UAT1_BEPG_MPI_URL;
	
	public static String BASE_CORPORATE_ID = Config.UAT1_CORPORATE_ID;
	public static String BASE_EMPLOYEE_ID = Config.UAT1_EMPLOYEE_ID;
	
	public static String BASE_ENCRYPT_URL = "http://192.168.105.109:9555/pkcs11/SN";
	
	public static String BASE_E2FA_url = Config.DCS_E2FA_URL;
	public static String BASE_E2FA_APIUSER = Config.DCS_E2FA_APIUSER;			
	public static String BASE_E2FA_APIKEY = Config.DCS_E2FA_APIKEY;
	
	public static String BASE_OOB_AUTH_URL = Config.DCS_OOB_AUTH_URL;
	public static String BASE_OOB_CLIENT_ID = Config.DCS_OOB_CLIENT_ID;
	public static String BASE_OOB_x_api_key = Config.DCS_OOB_x_api_key;
	@SuppressWarnings("unused")
	public static void assignEnvironment() {
		//System.out.println("Set env");
		//System.out.println(Config.BASE_ENVIRONMENT);
		if(Config.BASE_ENVIRONMENT.contentEquals("UAT1")) {
			//System.out.println("Seting UAT1xm env");
			Config.BASE_TRANSACTION_URL = Config.UAT1_TRANSACTION_URL;
			Config.BASE_NEW_SIMULATOR_TRANSACTION_URL = Config.UAT1_NEW_SIMULATOR_TRANSACTION_URL;
			Config.BASE_MPI_SIMULATOR_TRANSACTION_URL = Config.UAT1_MPI_SIMULATOR_TRANSACTION_URL;
			Config.BASE_OTPENGINE_URI = Config.UAT1_OTPENGINE_URI;
			Config.BASE_UAM_URL = Config.UAT1_UAM_URL;
			Config.BASE_CORPORATE_ID = Config.UAT1_CORPORATE_ID;
			Config.BASE_EMPLOYEE_ID = Config.UAT1_EMPLOYEE_ID;
			Config.BASE_PUSH_API_ENCRYPT_URL = Config.UAT1_PUSH_API_ENCRYPT_URL;
			Config.BASE_PUSH_API_URL = Config.UAT1_PUSH_API_URL;
			
		} else if(Config.BASE_ENVIRONMENT.contentEquals("DCS")) {
			//System.out.println("Seting DCS env");
			Config.BASE_TRANSACTION_URL = Config.DCS_TRANSACTION_URL;
			Config.BASE_NEW_SIMULATOR_TRANSACTION_URL = Config.DCS_NEW_SIMULATOR_TRANSACTION_URL;
			Config.BASE_MPI_SIMULATOR_TRANSACTION_URL = Config.DCS_MPI_SIMULATOR_TRANSACTION_URL;
			Config.BASE_OTPENGINE_URI = Config.DCS_OTPENGINE_URI;
			Config.BASE_UAM_URL = Config.DCS_UAM_URL;
			Config.BASE_PUSH_API_ENCRYPT_URL = Config.DCS_PUSH_API_ENCRYPT_URL;
			Config.BASE_PUSH_API_URL = Config.DCS_PUSH_API_URL;
			Config.BASE_OOB_AUTH_URL = Config.DCS_OOB_AUTH_URL;
			Config.BASE_OOB_CLIENT_ID = Config.DCS_OOB_CLIENT_ID;
			Config.BASE_OOB_x_api_key = Config.DCS_OOB_x_api_key;
			
		} else if(Config.BASE_ENVIRONMENT.contentEquals("UAT")) {
			//System.out.println("Seting uat env");
			Config.BASE_TRANSACTION_URL = Config.UAT_TRANSACTION_URL;
			Config.BASE_NEW_SIMULATOR_TRANSACTION_URL = Config.UAT_NEW_SIMULATOR_TRANSACTION_URL;
			Config.BASE_MPI_SIMULATOR_TRANSACTION_URL = Config.UAT_MPI_SIMULATOR_TRANSACTION_URL;
			Config.BASE_OTPENGINE_URI = Config.UAT_OTPENGINE_URI;
			Config.BASE_UAM_URL = Config.UAT_UAM_URL;
		}
		else {
			System.out.println("Not set env");
		}
	}

}

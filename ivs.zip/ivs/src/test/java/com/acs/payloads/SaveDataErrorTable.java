package com.acs.payloads;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.payloads.DeWhitelistingRequestBodyHelper;
import com.acs.payloads.PushRequestBodyHelper;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.JWEEncryptionDeWhitelisting;
import com.acs.utils.JWEEncryptionDeWhitelisting;
import com.acs.utils.JWTEncryption;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.api.payuexpresspay.ApiMethods;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.bytebuddy.description.type.TypeList.Generic;

public class SaveDataErrorTable {
	
	static String cDay = null;
	static String cMonth = null;
	static String nMonth = null;
	static String cYear = null;
	static String cHour = null;
	static String cMinutes = null;
	static String cSeconds = null;

	static String utcDay = null;
	static String utcMonth = null;
	static String utcYear = null;
	static String utcHour = null;
	static String utcMinutes = null;
	static String ucSeconds = null;

	public String acsTxnId = null;
	public int invocationCount=0;
	public String runTimeAcsTransID=null;
	WebDriver driver = null;
	GenericMethods generic = new GenericMethods(driver);
	public String encryptedPayload = null;
	public String jsonbody = null;
	public Response response = null;
	public String responseasString = null;
	public JsonPath jsonPathEvaluator = null;
	public Xls_Reader excel;
	public String XlFileName=null;
	public String proxyUrl = null;
	public String  SavingDataErrorTable= null;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String OnBoradingXlFileName = null;
	public static Logger log = Logger.getLogger("devpinoyLogger");

	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
		"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
		"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename, String txn1_0sheetName, String txn2_0sheetName,String acstxn1_0sheetName,String acstxn2_0sheetName,String tridenttxn1_0sheetName,String tridenttxn2_0sheetName, String threedsstxn2_0sheetName) throws Exception {
		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");
		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0SheetName = txn1_0sheetName;
		Txn2_0SheetName = txn2_0sheetName;
		ACSTxn1_0SheetName = acstxn1_0sheetName;
		ACSTxn2_0SheetName = acstxn2_0sheetName;
		TridentTxn1_0SheetName = tridenttxn1_0sheetName;
		TridentTxn2_0SheetName = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0SheetName = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {
		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, "SavingDataErrorTable");
	}

	@Test(dataProvider = "DataSet")
	public void saveDataErrorTableApi(String IssuerBankId, String IssuerBankName,String threeDSServerTransID ,String dsTransID, String messageType,
			String messageVersion, String sdkTransID,String acsTransID, String errorCode,String errorComponent, String errorDescription, 
			String errorDetail, String errorMessageType, String schema, String Flow,  String TestCaseDiscription) throws Exception {
		
		SoftAssert sAssertion = new SoftAssert();
		
		//long clienttransactionid = GenericMethods.generateRandomDigits(15);
		
		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);
		// current Date and time

				System.out.println("dateAndTime:-" + dateAndTime);
				String[] dateTime = dateAndTime.split("/");
				cYear = dateTime[0];
				cMonth = dateTime[1];
				cDay = dateTime[2];
				cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
				cMinutes = dateTime[4];
				cSeconds = dateTime[5];

				// UTC time Zone
				System.out.println("utcTime: " + utcTime);
				String[] utcDateTime = utcTime.split("/");
				utcYear = utcDateTime[0];
				utcMonth = utcDateTime[1];
				utcDay = utcDateTime[2];
				utcHour = utcDateTime[3];
				utcMinutes = utcDateTime[4];
				ucSeconds = utcDateTime[5];
				
				LocalDateTime now = LocalDateTime.now();
				nMonth = String.format("%02d", now.getMonthValue());
				System.out.println("nMonth:-" + nMonth);
		
		int randomPIN = (int) (Math.random() * 90000) + 10000;
		String RandomNum = "" + randomPIN;
		
		String clienttransactionid=acsTransID.substring(5);
		runTimeAcsTransID = clienttransactionid+RandomNum;
		System.out.println("runTimeAcsTransID="+runTimeAcsTransID);
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, SavingDataErrorTable, "acsTxnId", invocationCount, "");	
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, SavingDataErrorTable, "acsTxnId", invocationCount, "");
				
		switch (Flow) {	
		case "Ares Request":
			System.out.println("************* Error Code list details in the screen Admin ******************");
			jsonbody = SaveErrorDataRequestBodyHelper.saveDataErrorTableRequestBody(IssuerBankId, threeDSServerTransID , dsTransID,
					messageType, messageVersion, sdkTransID, acsTransID,  errorCode, errorComponent, errorDescription,  errorDetail, 
					errorMessageType);
			System.out.println("Json Body : " + jsonbody);
			ApiMethods.errorCodeListDetailsScreenAdmin​Request(jsonbody, IssuerBankId);
			generic.explicitWait(5);
			System.out.println("utcYear="+utcYear);
			System.out.println("nMonth="+nMonth);
			String errorDesc=GenericMethods.getErrorDescription(schema, utcYear,nMonth,acsTransID);
			System.out.println("errorDesc="+errorDesc);
			String messageVer=GenericMethods.getMessageVersion(schema, utcYear,nMonth,acsTransID);
			String errorCode1=GenericMethods.getErrorCode(schema, utcYear,nMonth,acsTransID);
			String errorTypeMessage=GenericMethods.getErrorMessageType(schema, utcYear,nMonth,acsTransID);
			String errorCompo=GenericMethods.getErrorComponent(schema, utcYear,nMonth,acsTransID);
			sAssertion.assertEquals(errorDesc, "Required element missing");
			sAssertion.assertEquals(messageVer, "2.1.0");
			sAssertion.assertEquals(errorCode1, "201");
			sAssertion.assertEquals(errorTypeMessage, "Ares");
			sAssertion.assertEquals(errorCompo, "D");
			break;

	}
		sAssertion.assertAll();
	}
}


package com.acs.payloads;

public class SaveErrorDataRequestBodyHelper {

	public static String saveDataErrorTableRequestBody(String IssuerBankId, String threeDSServerTransID ,String dsTransID, String messageType,
			String messageVersion, String sdkTransID,String acsTransID, String errorCode,String errorComponent, String errorDescription,
			String errorDetail, String errorMessageType) {
		String jsonbody="{\n" +
				" \"threeDSServerTransID\":\""+threeDSServerTransID+"\",\r\n" +
				" \"dsTransID\":\""+dsTransID+"\",\r\n" +
				" \"messageType\":\""+messageType+"\",\r\n" +
				" \"messageVersion\":\""+messageVersion+"\",\r\n" +
				" \"sdkTransID\":\""+sdkTransID+"\",\r\n" +
				" \"acsTransID\":\""+acsTransID+"\",\r\n" +
				" \"errorCode\":\""+errorCode+"\",\r\n" +
				" \"errorComponent\":\""+errorComponent+"\",\r\n" +
				" \"errorDescription\":\""+errorDescription+"\",\r\n" +
				" \"errorDetail\":\""+errorDetail+"\",\r\n" +
				" \"errorMessageType\":\""+errorMessageType+"\"\r\n" +
				"}";

		return jsonbody;
	}


}

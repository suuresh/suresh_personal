package com.acs.payloads;

import com.acs.libraries.Config;

public class ThreeRIRequestBodyHelper {

	public static String Generate3RIIntialRequestBody(String PAN, String Amount, String MerchantName, String currencytype, String ProtocalVersion) {
		String currencyCode1 = null;
		String jsonbody =null;
		if (currencytype.equalsIgnoreCase("INR")) {
			currencyCode1 = "356";
		} else if (currencytype.equalsIgnoreCase("USD")) {
			currencyCode1 = "840";
		} else if (currencytype.equalsIgnoreCase("EUR")) {
			currencyCode1 = "978";
		} else if (currencytype.equalsIgnoreCase("EGP")) {
			currencyCode1 = "818";
		}
		
		 if(ProtocalVersion.equalsIgnoreCase("2.1.0")) {
		   jsonbody = "{" + 
				"  \"purchaseAmount\": \""+Amount+"\"," + 
				"  \"acctNumber\": \""+PAN+"\"," + 
				"  \"threeDSRequestorID\": \"10061597*9876543210508\"," + 
				"  \"threeDSRequestorName\": \""+MerchantName+"\"," + 
				"  \"merchantName\": \""+MerchantName+"\"," + 
				"  \"purchaseCurrency\": \""+currencyCode1+"\"," + 
				"  \"purchaseExponent\": \"2\"," + 
				"  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\"," + 
				"  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\"," + 
				"  \"threeDSServerOperatorID\": \"10061597\"," + 
				"  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				"  \"threeDSServerURL\": \"http://192.168.108.54:6122/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				"  \"acquirerBIN\": \"000000999\"," + 
				"  \"acquirerMerchantID\": \"9876543210361\"," + 
				"  \"addrMatch\": \"Y\"," + 
				"  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\"," + 
				"  \"browserIP\": \"192.168.109.1\"," + 
				"  \"browserJavaEnabled\": false," + 
				"  \"BrowserJavascriptEnabled\": false," + 
				"  \"browserLanguage\": \"en-GB\"," + 
				"  \"browserColorDepth\": \"24\"," + 
				"  \"browserScreenHeight\": \"768\"," + 
				"  \"browserScreenWidth\": \"1366\"," + 
				"  \"browserTZ\": \"-330\"," + 
				"  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\"," + 
				"  \"cardExpiryDate\": \"2212\"," + 
				"  \"deviceChannel\": \"02\"," + 
				"  \"dsReferenceNumber\": \"123456789\"," + 
				"  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
				"  \"dsURL\": \""+Config.DCS_DS_FOR_RREQ_URL+"\"," + 
				"  \"mcc\": \"7922\"," + 
				"  \"merchantCountryCode\": \"356\"," + 
				"  \"messageCategory\": \"01\"," + 
				"  \"messageType\": \"AReq\"," + 
				"  \"messageVersion\": \""+ProtocalVersion+"\"," + 
				"  \"purchaseDate\": \"20201203223521\"," + 
				"  \"recurringExpiry\": \"20250301\"," + 
				"  \"recurringFrequency\": \"1\"," + 
				"  \"transType\": \"01\"," + 
				"  \"threeDSCompInd\": \"N\"," + 
				"  \"threeDSRequestorAuthenticationInd\": \"02\"," + 
				"  \"threeRIInd\": \"01\"," + 
				"  \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/acsSimulator/getcres\"," + 
				"  \"messageExtension\": [" + 
				"    {" + 
				"      \"name\": \"Merchant Data\"," + 
				"      \"id\": \"A000000004-merchantData\"," + 
				"      \"criticalityIndicator\": \"false\"," + 
				"      \"data\": {" + 
				"        \"A000000004-merchantData\": {" + 
				"          \"scaExemptions\": \"05\"," + 
				"          \"merchantFraudRate\": \"1\"," + 
				"          \"acquirerCountryCode\": \"356\"," + 
				"          \"secureCorporatePaymentExemption\": \"Y\"" + 
				"        }" + 
				"      }" + 
				"    }," + 
				"    {" + 
				"      \"name\": \"ACS Data\"," + 
				"      \"id\": \"A000000004-acsData\"," + 
				"      \"criticalityIndicator\": \"false\"," + 
				"      \"data\": {" + 
				"        \"A000000004-acsData\": {" + 
				"          \"whitelistStatus\": \"Y\"" + 
				"        }" + 
				"      }" + 
				"    }" + 
				"  ]" + 
				"}" + 
				"" ;
		 } else if(ProtocalVersion.equalsIgnoreCase("2.2.0")){
			 
			 jsonbody = "{"
			 		+ "  \"purchaseAmount\": \""+Amount+"\","
			 		+ "  \"threeDSRequestorAuthenticationInfo\": null,"
			 		+ "  \"threeDSRequestorChallengeInd\": null,"
			 		+ "  \"threeDSRequestorID\": \"10061597*9876543210508\","
			 		+ "  \"threeDSRequestorName\": \""+MerchantName+"\","
			 		+ "  \"threeDSRequestorPriorAuthenticationInfo\": null,"
			 		+ "  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\","
			 		+ "  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\","
			 		+ "  \"threeDSServerOperatorID\": \"10061597\","
			 		+ "  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\","
			 		+ "  \"threeDSServerURL\": \"http://192.168.108.54:6122/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\","
			 		+ "  \"acctType\": null,"
			 		+ "  \"acquirerBIN\": \"000000999\","
			 		+ "  \"acquirerMerchantID\": \"9876543210346\","
			 		+ "  \"addrMatch\": \"Y\","
			 		+ "	  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\","
			 		+ "	  \"browserIP\": \"192.168.109.1\","
			 		+ "	  \"browserJavaEnabled\": \"false\","
			 		+ "	  \"browserJavascriptEnabled\": \"false\","
			 		+ "	  \"browserLanguage\": \"en-GB\","
			 		+ "	  \"browserColorDepth\": \"24\","
			 		+ "	  \"browserScreenHeight\": \"768\","
			 		+ "	  \"browserScreenWidth\": \"1366\","
			 		+ "	  \"browserTZ\": \"-330\","
			 		+ "	  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\","
			 		+ "  \"cardExpiryDate\": \"2212\","
			 		+ "  \"acctInfo\": null,"
			 		+ "  \"acctNumber\": \""+PAN+"\","
			 		+ "  \"acctID\": null,"
			 		+ "  \"billAddrCity\": null,"
			 		+ "  \"billAddrCountry\": null,"
			 		+ "  \"billAddrLine1\": null,"
			 		+ "  \"billAddrLine2\": null,"
			 		+ "  \"billAddrLine3\": null,"
			 		+ "  \"billAddrPostCode\": null,"
			 		+ "  \"billAddrState\": null,"
			 		+ "  \"email\": null,"
			 		+ "  \"homePhone\": null,"
			 		+ "  \"mobilePhone\": null,"
			 		+ "  \"cardholderName\": null,"
			 		+ "  \"shipAddrCity\": null,"
			 		+ "  \"shipAddrCountry\": null,"
			 		+ "  \"shipAddrLine1\": null,"
			 		+ "  \"shipAddrLine2\": null,"
			 		+ "  \"shipAddrLine3\": null,"
			 		+ "  \"shipAddrPostCode\": null,"
			 		+ "  \"shipAddrState\": null,"
			 		+ "  \"workPhone\": null,"
			 		+ "  \"deviceChannel\": \"02\","
			 		+ "  \"deviceInfo\": null,"
			 		+ "  \"deviceRenderOptions\": null,"
			 		+ "  \"dsReferenceNumber\": \"123456789\","
			 		+ "  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\","
			 		+ "  \"dsURL\": \"http://192.168.108.160:5200/v1/acsSimulator/rreq\","
			 		+ "  \"payTokenInd\": null,"
			 		+ "  \"purchaseInstalData\": null,"
			 		+ "  \"mcc\": \"7922\","
			 		+ "  \"merchantCountryCode\": \"356\","
			 		+ "  \"merchantName\": \""+MerchantName+"\","
			 		+ "  \"merchantRiskIndicator\": null,"
			 		+ "  \"messageCategory\": \"01\","
			 		+ "  \"messageType\": \"AReq\","
			 		+ "  \"messageVersion\": \"2.2.0\","
			 		+ "  \"purchaseCurrency\": \""+currencyCode1+"\","
			 		+ "  \"purchaseExponent\": \"2\","
			 		+ "  \"purchaseDate\": \"20201203223521\","
			 		+ "  \"recurringExpiry\": \"20240301\","
			 		+ "  \"recurringFrequency\": \"1\","
			 		+ "  \"sdkAppID\": null,"
			 		+ "  \"sdkEncData\": null,"
			 		+ "  \"sdkEphemPubKey\": null,"
			 		+ "  \"sdkReferenceNumber\": null,"
			 		+ "  \"sdkTransID\": null,"
			 		+ "  \"transType\": \"01\","
			 		+ "  \"acsTransID\": null,"
			 		+ "  \"threeDSCompInd\": \"N\","
			 		+ "  \"threeDSRequestorAuthenticationInd\": \"02\","
			 		+ "  \"threeRIInd\": \"01\","
			 		+ "  \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/acsSimulator/getcres\","
			 		+ "  \"sdkMaxTimeout\": null,"
			 		+ "  \"broadInfo\": null,"
			 		+ "  \"messageExtension\": ["
			 		+ "    {"
			 		+ "      \"name\": \"Merchant Data\","
			 		+ "      \"id\": \"A000000004-merchantData\","
			 		+ "      \"criticalityIndicator\": \"false\","
			 		+ "      \"data\": {"
			 		+ "        \"A000000004-merchantData\": {"
			 		+ "          \"scaExemptions\": \"05\","
			 		+ "          \"merchantFraudRate\": \"1\","
			 		+ "          \"acquirerCountryCode\": \"356\","
			 		+ "          \"secureCorporatePaymentExemption\": \"Y\""
			 		+ "        }"
			 		+ "      }"
			 		+ "    },"
			 		+ "    {"
			 		+ "      \"name\": \"ACS Data\","
			 		+ "      \"id\": \"A000000004-acsData\","
			 		+ "      \"criticalityIndicator\": \"false\","
			 		+ "      \"data\": {"
			 		+ "        \"A000000004-acsData\": {"
			 		+ "          \"whitelistStatus\": \"Y\""
			 		+ "        }"
			 		+ "      }"
			 		+ "    }"
			 		+ "  ]"
			 		+ "}"
			 		+ "";
			 
			 /*jsonbody = "{" + 
				 		"  \"purchaseAmount\": \""+Amount+"\"," + 
				 		"  \"acctNumber\": \""+PAN+"\"," + 
				 		"  \"threeDSRequestorID\": \"10061597*9876543210508\"," + 
				 		"  \"threeDSRequestorName\": \""+MerchantName+"\"," + 
				 		"  \"merchantName\": \""+MerchantName+"\"," + 
				 		"  \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/acsSimulator/getcres\"," + 
				 		"  \"dsURL\": \""+Config.DCS_DS_FOR_RREQ_URL+"\"," + 
				 		"  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\"," + 
				 		"  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\"," + 
				 		"  \"threeDSServerOperatorID\": \"10061597\"," + 
				 		"  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				 		"  \"threeDSServerURL\": \"http://192.168.108.54:6122/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				 		"  \"acquirerBIN\": \"000000999\"," + 
				 		"  \"acquirerMerchantID\": \"9996543210485\"," + 
				 		"  \"addrMatch\": \"Y\"," + 
				 		"  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*//*;q=0.8,application/signed-exchange;v=b3;q=0.9\"," + 
				 		"  \"browserIP\": \"192.168.109.1\"," + 
				 		"  \"browserJavaEnabled\": \"false\"," + 
				 		"  \"browserJavascriptEnabled\": false," + 
				 		"  \"browserLanguage\": \"en-GB\"," + 
				 		"  \"browserColorDepth\": \"24\"," + 
				 		"  \"browserScreenHeight\": \"768\"," + 
				 		"  \"browserScreenWidth\": \"1366\"," + 
				 		"  \"browserTZ\": \"-330\"," + 
				 		"  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\"," + 
				 		"  \"cardExpiryDate\": \"2512\"," + 
				 		"  \"deviceChannel\": \"02\"," + 
				 		"  \"dsReferenceNumber\": \"123456789\"," + 
				 		"  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
				 		"  \"mcc\": \"7922\"," + 
				 		"  \"merchantCountryCode\": \"356\"," + 
				 		"  \"messageCategory\": \"01\"," + 
				 		"  \"messageType\": \"AReq\"," + 
				 		"  \"messageVersion\": \""+ProtocalVersion+"\"," + 
				 		"  \"purchaseCurrency\": \""+currencyCode1+"\"," + 
				 		"  \"purchaseExponent\": \"2\"," + 
				 		"  \"purchaseDate\": \"20201203223521\"," + 
				 		"  \"recurringExpiry\": \"20250501\"," + 
				 		"  \"recurringFrequency\": \"1\"," + 
				 		"  \"transType\": \"01\"," + 
				 		"  \"threeDSCompInd\": \"N\"," + 
				 		"  \"threeDSRequestorAuthenticationInd\": \"02\"," + 
				 		"  \"threeRIInd\": \"01\"" + 
				 		"}";*/
			 
		 } else {
			 System.out.println("Protocal Version not matched");
		 }

		return jsonbody;
	}
	
	public static String Generate3RISubsequentRequestBody(String PAN, String Amount, String MerchantName, String currencytype, String ProtocalVersion, String ThreeDSReqPriorRef) {
		String currencyCode1 = null;
		String jsonbody = null;
		if (currencytype.equalsIgnoreCase("INR")) {
			currencyCode1 = "356";
		} else if (currencytype.equalsIgnoreCase("USD")) {
			currencyCode1 = "840";
		} else if (currencytype.equalsIgnoreCase("EUR")) {
			currencyCode1 = "978";
		} else if (currencytype.equalsIgnoreCase("EGP")) {
			currencyCode1 = "818";
		}
		
		if(ProtocalVersion.equalsIgnoreCase("2.1.0")) { 

		jsonbody = "{" + 
				"  \"purchaseAmount\": \""+Amount+"\"," + 
				"  \"acctNumber\": \""+PAN+"\"," + 
				"  \"threeDSRequestorID\": \"10061597*9876543210508\"," + 
				"  \"threeDSRequestorName\": \""+MerchantName+"\"," + 
				"  \"merchantName\": \""+MerchantName+"\"," + 
				"  \"messageCategory\": \"01\"," + 
				"  \"messageType\": \"AReq\"," + 
				"  \"messageVersion\": \""+ProtocalVersion+"\"," + 
				"  \"purchaseCurrency\": \""+currencyCode1+"\"," + 
				"  \"purchaseExponent\": \"2\"," + 
				"  \"dsURL\": \""+Config.DCS_DS_FOR_RREQ_URL+"\"," + 
				"   \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/acsSimulator/getcres\"," + 
				"  \"threeDSRequestorPriorAuthenticationInfo\": {" + 
				"  \"threeDSReqPriorRef\":\"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
				"  \"threeDSReqPriorAuthMethod\":\"01\"," + 
				"  \"threeDSReqPriorAuthTimestamp\":\"202102120915\"," + 
				"  \"threeDSReqPriorAuthData\":\"\"" + 
				"}," + 
				"  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\"," + 
				"  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\"," + 
				"  \"threeDSServerOperatorID\": \"10061597\"," + 
				"  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				"  \"threeDSServerURL\": \"http://192.168.108.54:6122/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
				"  \"acctType\": null," + 
				"  \"acquirerBIN\": \"000000999\"," + 
				"  \"acquirerMerchantID\": \"9876543210361\"," + 
				"  \"addrMatch\": \"Y\"," + 
				"  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\"," + 
				"  \"browserIP\": \"192.168.109.1\"," + 
				"  \"browserJavaEnabled\": false," + 
				"  \"browserJavascriptEnabled\": false," + 
				"  \"browserLanguage\": \"en-GB\"," + 
				"  \"browserColorDepth\": \"24\"," + 
				"  \"browserScreenHeight\": \"768\"," + 
				"  \"browserScreenWidth\": \"1366\"," + 
				"  \"browserTZ\": \"-330\"," + 
				"  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\"," + 
				"  \"cardExpiryDate\": \"2212\"," + 
				"  \"acctInfo\": null," + 
				"  \"deviceChannel\": \"02\"," + 
				"  \"dsReferenceNumber\": \"123456789\"," + 
				"  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
				"  \"mcc\": \"7922\"," + 
				"  \"merchantCountryCode\": \"356\"," + 
				"  \"purchaseDate\": \"20201203223521\"," + 
				"  \"recurringExpiry\": \"20250301\"," + 
				"  \"recurringFrequency\": \"1\"," + 
				"  \"transType\": \"01\"," + 
				"  \"threeDSCompInd\": \"N\"," + 
				"  \"threeDSRequestorAuthenticationInd\": \"02\"," + 
				"  \"threeRIInd\": \"01\"," + 
				"  \"messageExtension\": [" + 
				"    {" + 
				"      \"name\": \"Merchant Data\"," + 
				"      \"id\": \"A000000004-merchantData\"," + 
				"      \"criticalityIndicator\": \"false\"," + 
				"      \"data\": {" + 
				"        \"A000000004-merchantData\": {" + 
				"          \"scaExemptions\": \"05\"," + 
				"          \"merchantFraudRate\": \"1\"," + 
				"          \"acquirerCountryCode\": \"356\"," + 
				"          \"secureCorporatePaymentExemption\": \"Y\"" + 
				"        }" + 
				"      }" + 
				"    }," + 
				"    {" + 
				"      \"name\": \"ACS Data\"," + 
				"      \"id\": \"A000000004-acsData\"," + 
				"      \"criticalityIndicator\": \"false\"," + 
				"      \"data\": {" + 
				"        \"A000000004-acsData\": {" + 
				"          \"whitelistStatus\": \"Y\"" + 
				"        }" + 
				"      }" + 
				"    }" + 
				"  ]" + 
				"}" + 
				"" ;
		} else if(ProtocalVersion.equalsIgnoreCase("2.2.0")) {
			
			jsonbody = "{"
					+ "  \"purchaseAmount\": \""+Amount+"\","
					+ "  \"threeDSRequestorAuthenticationInfo\": null,"
					+ "  \"threeDSRequestorChallengeInd\": null,"
					+ "  \"threeDSRequestorID\": \"10061597*9876543210508\","
					+ "  \"threeDSRequestorName\": \""+MerchantName+"\","
					+ "  \"threeDSRequestorPriorAuthenticationInfo\": {"
					+ "  \"threeDSReqPriorRef\":\""+ThreeDSReqPriorRef+"\","
					+ "  \"threeDSReqPriorAuthMethod\":\"02\","
					+ "  \"threeDSReqPriorAuthTimestamp\":\"202102120915\","
					+ "  \"threeDSReqPriorAuthData\":\"01\""
					+ "},"
					+ "  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\","
					+ "  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\","
					+ "  \"threeDSServerOperatorID\": \"10061597\","
					+ "  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\","
					+ "  \"threeDSServerURL\": \"http://192.168.108.54:6122/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\","
					+ "  \"acctType\": null,"
					+ "  \"acquirerBIN\": \"000000999\","
					+ "  \"acquirerMerchantID\": \"9876543210346\","
					+ "  \"addrMatch\": \"Y\","
					+ "	  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\","
					+ "	  \"browserIP\": \"192.168.109.1\","
					+ "	  \"browserJavaEnabled\": \"false\","
					+ "	  \"browserJavascriptEnabled\": \"false\","
					+ "	  \"browserLanguage\": \"en-GB\","
					+ "	  \"browserColorDepth\": \"24\","
					+ "	  \"browserScreenHeight\": \"768\","
					+ "	  \"browserScreenWidth\": \"1366\","
					+ "	  \"browserTZ\": \"-330\","
					+ "	  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\","
					+ "  \"cardExpiryDate\": \"2212\","
					+ "  \"acctInfo\": null,"
					+ "  \"acctNumber\": \""+ PAN +"\","
					+ "  \"acctID\": null,"
					+ "  \"billAddrCity\": null,"
					+ "  \"billAddrCountry\": null,"
					+ "  \"billAddrLine1\": null,"
					+ "  \"billAddrLine2\": null,"
					+ "  \"billAddrLine3\": null,"
					+ "  \"billAddrPostCode\": null,"
					+ "  \"billAddrState\": null,"
					+ "  \"email\": null,"
					+ "  \"homePhone\": null,"
					+ "  \"mobilePhone\": null,"
					+ "  \"cardholderName\": null,"
					+ "  \"shipAddrCity\": null,"
					+ "  \"shipAddrCountry\": null,"
					+ "  \"shipAddrLine1\": null,"
					+ "  \"shipAddrLine2\": null,"
					+ "  \"shipAddrLine3\": null,"
					+ "  \"shipAddrPostCode\": null,"
					+ "  \"shipAddrState\": null,"
					+ "  \"workPhone\": null,"
					+ "  \"deviceChannel\": \"03\","
					+ "  \"deviceInfo\": null,"
					+ "  \"deviceRenderOptions\": null,"
					+ "  \"dsReferenceNumber\": \"123456789\","
					+ "  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\","
					+ "  \"dsURL\": \"http://192.168.108.53:6017/v1/acsSimulator/rreq\","
					+ "  \"payTokenInd\": null,"
					+ "  \"purchaseInstalData\": null,"
					+ "  \"mcc\": \"7922\","
					+ "  \"merchantCountryCode\": \"840\","
					+ "  \"merchantName\": \""+MerchantName+"\","
					+ "  \"merchantRiskIndicator\": null,"
					+ "  \"messageCategory\": \"01\","
					+ "  \"messageType\": \"AReq\","
					+ "  \"messageVersion\": \"2.2.0\","
					+ "  \"purchaseCurrency\": \""+currencyCode1+"\","
					+ "  \"purchaseExponent\": \"2\","
					+ "  \"purchaseDate\": \"20201203223521\","
					+ "  \"recurringExpiry\": \"20240301\","
					+ "  \"recurringFrequency\": \"1\","
					+ "  \"sdkAppID\": null,"
					+ "  \"sdkEncData\": null,"
					+ "  \"sdkEphemPubKey\": null,"
					+ "  \"sdkReferenceNumber\": null,"
					+ "  \"sdkTransID\": null,"
					+ "  \"transType\": \"01\","
					+ "  \"acsTransID\": null,"
					+ "  \"threeDSCompInd\": \"N\","
					+ "  \"threeDSRequestorAuthenticationInd\": \"02\","
					+ "  \"threeRIInd\": \"85\","
					+ "  \"notificationURL\": \"https://3ds2-ui-merchantpilot.enstage-uat.com/v1/acsSimulator/getcres\","
					+ "  \"sdkMaxTimeout\": null,"
					+ "  \"broadInfo\": null,"
					+ "  \"messageExtension\": ["
					+ "    {"
					+ "      \"name\": \"Merchant Data\","
					+ "      \"id\": \"A000000004-merchantData\","
					+ "      \"criticalityIndicator\": \"false\","
					+ "      \"data\": {"
					+ "        \"A000000004-merchantData\": {"
					+ "          \"scaExemptions\": \"05\","
					+ "          \"merchantFraudRate\": \"1\","
					+ "          \"acquirerCountryCode\": \"356\","
					+ "          \"secureCorporatePaymentExemption\": \"Y\""
					+ "        }"
					+ "      }"
					+ "    },"
					+ "    {"
					+ "      \"name\": \"ACS Data\","
					+ "      \"id\": \"A000000004-acsData\","
					+ "      \"criticalityIndicator\": \"false\","
					+ "      \"data\": {"
					+ "        \"A000000004-acsData\": {"
					+ "          \"whitelistStatus\": \"Y\""
					+ "        }"
					+ "      }"
					+ "    }"
					+ "  ]"
					+ "}"
					+ "";

			/*jsonbody = "{" + 
					"  \"purchaseAmount\": \""+Amount+"\"," + 
					"  \"threeDSRequestorAuthenticationInfo\": null," + 
					"  \"threeDSRequestorChallengeInd\": null," + 
					"  \"threeDSRequestorID\": \"10061597*9876543210508\"," + 
					"  \"threeDSRequestorName\": \""+MerchantName+"\"," + 
					"  \"threeDSRequestorPriorAuthenticationInfo\": {" + 
					"  \"threeDSReqPriorRef\":\"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
					"  \"threeDSReqPriorAuthMethod\":\"01\"," + 
					"  \"threeDSReqPriorAuthTimestamp\":\"202102120915\"," + 
					"  \"threeDSReqPriorAuthData\":\"\"" + 
					"}," + 
					"  \"threeDSRequestorURL\": \"http://test-wibmo-requestor.com/uat/test\"," + 
					"  \"threeDSServerRefNumber\": \"3DS_LOA_SER_WIBM_020100_0064\"," + 
					"  \"threeDSServerOperatorID\": \"10061597\"," + 
					"  \"threeDSServerTransID\": \"b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
					"  \"threeDSServerURL\": \"https://3ds2-ui-acsdcs.pc.enstage-sas.com/3dsserverapi/getrres/indblr-blrrel/L/8126/b8d2daaf-3589-11eb-bf76-93d94744325f\"," + 
					"  \"acctType\": null," + 
					"  \"acquirerBIN\": \"000000999\"," + 
					"  \"acquirerMerchantID\": \"9996543210485\"," + 
					"  \"addrMatch\": \"Y\"," + 
					"  \"browserAcceptHeader\": \"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*//*;q=0.8,application/signed-exchange;v=b3;q=0.9\"," + 
					"  \"browserIP\": \"192.168.109.1\"," + 
					"  \"browserJavaEnabled\": \"false\"," + 
					"  \"BrowserJavascriptEnabled\": \"false\"," + 
					"  \"browserLanguage\": \"en-GB\"," + 
					"  \"browserColorDepth\": \"24\"," + 
					"  \"browserScreenHeight\": \"768\"," + 
					"  \"browserScreenWidth\": \"1366\"," + 
					"  \"browserTZ\": \"-330\"," + 
					"  \"browserUserAgent\": \"mozilla/5.0 (x11; linux x86_64) applewebkit/537.36 (khtml, like gecko) chrome/79.0.3945.117 safari/537.36\"," + 
					"  \"cardExpiryDate\": \"2212\"," + 
					"  \"acctInfo\": null," + 
					"  \"acctNumber\": \""+PAN+"\"," + 
					"  \"acctID\": null," + 
					"  \"billAddrCity\": null," + 
					"  \"billAddrCountry\": null," + 
					"  \"billAddrLine1\": null," + 
					"  \"billAddrLine2\": null," + 
					"  \"billAddrLine3\": null," + 
					"  \"billAddrPostCode\": null," + 
					"  \"billAddrState\": null," + 
					"  \"email\": null," + 
					"  \"homePhone\": null," + 
					"  \"mobilePhone\": null," + 
					"  \"cardholderName\": null," + 
					"  \"shipAddrCity\": null," + 
					"  \"shipAddrCountry\": null," + 
					"  \"shipAddrLine1\": null," + 
					"  \"shipAddrLine2\": null," + 
					"  \"shipAddrLine3\": null," + 
					"  \"shipAddrPostCode\": null," + 
					"  \"shipAddrState\": null," + 
					"  \"workPhone\": null," + 
					"  \"deviceChannel\": \"03\"," + 
					"  \"deviceInfo\": null," + 
					"  \"deviceRenderOptions\": null," + 
					"  \"dsReferenceNumber\": \"123456789\"," + 
					"  \"dsTransID\": \"0c66efa8-918b-4ef0-8e02-8f0ee40034d7\"," + 
					"  \"dsURL\": \"http://192.168.108.62:5017/v1/acsSimulator/rreq\"," + 
					"  \"payTokenInd\": null," + 
					"  \"purchaseInstalData\": null," + 
					"  \"mcc\": \"7922\"," + 
					"  \"merchantCountryCode\": \"356\"," + 
					"  \"merchantName\": \""+MerchantName+"\"," + 
					"  \"merchantRiskIndicator\": null," + 
					"  \"messageCategory\": \"01\"," + 
					"  \"messageType\": \"AReq\"," + 
					"  \"messageVersion\": \"2.2.0\"," + 
					"  \"purchaseCurrency\": \""+currencyCode1+"\"," + 
					"  \"purchaseExponent\": \"2\"," + 
					"  \"purchaseDate\": \"20201203223521\"," + 
					"  \"recurringExpiry\": \"20220501\"," + 
					"  \"recurringFrequency\": \"1\"," + 
					"  \"sdkAppID\": null," + 
					"  \"sdkEncData\": null," + 
					"  \"sdkEphemPubKey\": null," + 
					"  \"sdkReferenceNumber\": null," + 
					"  \"sdkTransID\": null," + 
					"  \"transType\": \"01\"," + 
					"  \"acsTransID\": null," + 
					"  \"threeDSCompInd\": \"N\"," + 
					"  \"threeDSRequestorAuthenticationInd\": \"02\"," + 
					"  \"threeRIInd\": \"01\"," + 
					"  \"notificationURL\": \"https://3ds2-ui-merchantdcs.pc.enstage-sas.com/v1/acsSimulator/getcres\"," + 
					"  \"sdkMaxTimeout\": null," + 
					"  \"broadInfo\": null" + 
					"}";	*/
		}else {
			System.out.println("Protocal version is wrong");
		}

		return jsonbody;
	}

	
}

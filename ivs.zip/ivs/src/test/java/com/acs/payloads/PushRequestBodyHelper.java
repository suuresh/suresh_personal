package com.acs.payloads;

import com.acs.libraries.Config;

public class PushRequestBodyHelper {

	public static String pushRegisterRequestBody(String IssuerBankId, String PAN,String CardholderName, String PhoneNumber) {
	
		String jsonbody="{\n" +
                "    \"Account_Number\": \""+PAN+"\",\n" +
                "    \"API_Version\": \"1.0\",\n" +
                "    \"Name_On_Card\": \""+CardholderName+"\",\n" +
                "    \"Primary_PH_Country_Code\": \"91\",\n" +
                "    \"Primary_PH_NUMBER\": \""+PhoneNumber+"\",\n" +
                "    \"Primary_Email\": \"Johny@gmail.com\",\n" +
                "    \"Secondary_Email\":\"John@gmail.com\",\n" +
                "    \"Lang_Preference\": \"en_US\",\n" +
                "    \"Status\": \"1\",\n" +
                "    \"API_REF_ID\": \"23423SFDFDF423\",\n" +
                "    \"Action\": \"REG\",\n" +
                "    \"BankId\": \""+IssuerBankId+"\"\n" +
                "}";

		return jsonbody;
	}

	public static String pushUpdateRequestBody(String IssuerBankId, String PAN,String CardholderName, String PhoneNumber) {
		
		String jsonbody="{\n" +
                "    \"Account_Number\": \""+PAN+"\",\n" +
                "    \"API_Version\": \"1.0\",\n" +
                "    \"Name_On_Card\": \""+CardholderName+"\",\n" +
                "    \"Primary_PH_Country_Code\": \"91\",\n" +
                "    \"Primary_PH_NUMBER\": \""+PhoneNumber+"\",\n" +
                "    \"Primary_Email\": \"Johny@gmail.com\",\n" +
                "    \"Secondary_Email\":\"John@gmail.com\",\n" +
                "    \"Lang_Preference\": \"en_US\",\n" +
                "    \"Status\": \"1\",\n" +
                "    \"API_REF_ID\": \"23423SFDFDF423\",\n" +
                "    \"Action\": \"UPD\",\n" +
                "    \"BankId\": \""+IssuerBankId+"\"\n" +
                "}";

		return jsonbody;
	}
	
	public static String pushApiFieldValidationRequestBody(String IssuerBankId, String PAN,String apiVersion, String status,
		String apiRefId, String action, String CardholderName, String phPhoneNumber, String primaryEmail) {
		
		String jsonbody="{\n" +
                "    \"Account_Number\": \""+PAN+"\",\n" +
                "    \"API_Version\": \""+apiVersion+"\",\n" +
                "    \"Name_On_Card\": \""+CardholderName+"\",\n" +
                "    \"Primary_PH_Country_Code\": \"91\",\n" +
                "    \"Primary_PH_NUMBER\": \""+phPhoneNumber+"\",\n" +
                "    \"Primary_Email\": \""+primaryEmail+"\",\n" +
                "    \"Secondary_Email\":\"John@gmail.com\",\n" +
                "    \"Lang_Preference\": \"en_US\",\n" +
                "    \"Status\": \""+status+"\",\n" +
                "    \"API_REF_ID\": \""+apiRefId+"\",\n" +
                "    \"Action\": \""+action+"\",\n" +
                "    \"BankId\": \""+IssuerBankId+"\"\n" +
                "}";

		return jsonbody;
	}
	
	
	
}

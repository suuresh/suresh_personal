package com.acs.payloads;

public class DeWhitelistingRequestBodyHelper {

	public static String fetchRequestBody( String IssuerBankId,String Cardnumber, String apiVersion ,String ApiRefId) {

		String jsonbody="{\r\n" +
				" \"accountNumber\":\""+Cardnumber+"\",\r\n" +
				" \"apiVersion\":\""+apiVersion+"\",\r\n" +
				" \"apiRefId\":\""+ApiRefId+"\",\r\n" +
				" \"action\":\"FET\"\r\n" +
				"}";

		return jsonbody;
	}

	public static String deWhitelistedUpdateRequestBody(String IssuerBankId, String Cardnumber ,String apiVersion, 
			String ApiRefId, String merchantId, String merchantName, String status) {
		String jsonbody="{\r\n" +
				" \r\n" +
				" \"accountNumber\":\""+Cardnumber+"\",\r\n" +
				" \"apiVersion\":\""+apiVersion+"\",\r\n" +
				" \"apiRefId\":\""+ApiRefId+"\",\r\n" +
				" \"action\":\"UPD\",\r\n" +
				" \"merchantDetails\":[\r\n" +
				" {\"merchantId\":\""+merchantId+"\",\"merchantName\":\""+merchantName+"\",\"status\":"+status+"}]\r\n" +
				" \r\n" +
				"}";

		return jsonbody;
	}

	public static String deWhiteListingApiFieldValidationRequestBody( String PAN,String apiVersion, String apiRefId, String action) {

		String jsonbody="{\n" +
				"    \"Account_Number\": \""+PAN+"\",\n" +
				"    \"API_Version\": \""+apiVersion+"\",\n" +
				"    \"API_REF_ID\": \""+apiRefId+"\",\n" +
				"    \"Action\": \""+action+"\"\n" +
				"}";
		return jsonbody;
	}


}

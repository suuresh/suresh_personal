package com.acs.deWhitelisting;

import java.io.IOException;
import java.util.Random;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.payloads.DeWhitelistingRequestBodyHelper;
import com.acs.payloads.PushRequestBodyHelper;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.JWEEncryptionDeWhitelisting;
import com.acs.utils.JWEEncryptionDeWhitelisting;
import com.acs.utils.JWTEncryption;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.api.payuexpresspay.ApiMethods;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.bytebuddy.description.type.TypeList.Generic;

public class DeWhitelistingApiVerificationUpdate {

	public String acsTxnId = null;
	WebDriver driver = null;
	GenericMethods generic = new GenericMethods(driver);
	public String encryptedPayload = null;
	public String jsonbody = null;
	public Response response = null;
	public String responseasString = null;
	public JsonPath jsonPathEvaluator = null;
	public Xls_Reader excel;
	public String XlFileName=null;
	public String proxyUrl = null;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String OnBoradingXlFileName = null;
	public static Logger log = Logger.getLogger("devpinoyLogger");

	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
		"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
		"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename, String txn1_0sheetName, String txn2_0sheetName,String acstxn1_0sheetName,String acstxn2_0sheetName,String tridenttxn1_0sheetName,String tridenttxn2_0sheetName, String threedsstxn2_0sheetName) throws Exception {
		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");
		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, "deWhitelistingUpdate");
	}

	@Test(dataProvider = "DataSet")
	public void deWhitelistingApi(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String apiVersion, String ApiRefId, String merchantId, String merchantName, String status,String action,
			String Flow, String CardUnion,String TestCaseDiscription) throws Exception {
		SoftAssert sAssertion = new SoftAssert();

		switch (Flow) {	
		case "Update":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "200");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Updated existing Cust-Merchants status Succesfully");
			break;
			
		case "UpdateInvalidCardNumber":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "306");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Failed:Unable to update the cust-Merchant Data");
			break;
		case "UpdateInvalidBankId":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "400");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Access Denied");
			break;
		case "UpdateInvalidOnlyBankId":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "400");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Access Denied");
			break;
			
		case "UpdateInvalidMerchantId":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "200");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Insertion Failed for new Cust-Merchant,since new Merchants are not enabled by bank.");
			break;
		case "UpdateInvalidMerchantName":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "306");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Failed:Unable to update the cust-Merchant Data");
			break;
			
		case "UpdateInvalidApiRefId":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "306");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Failed:Unable to update the cust-Merchant Data");
			break;
		case "UpdateNullCardNumber":
			System.out.println("************* Update Flow ******************");
			jsonbody = DeWhitelistingRequestBodyHelper.deWhitelistedUpdateRequestBody(IssuerBankId, Cardnumber,apiVersion, ApiRefId,merchantId,merchantName,status);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWEEncryptionDeWhitelisting.jweEncryption(jsonbody, null);
			response = ApiMethods.deWhiteListedPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);
			jsonPathEvaluator = response.jsonPath();
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusCode"), "301");
			sAssertion.assertEquals(jsonPathEvaluator.getString("statusDesc"), "Validation Failed:Unable to process, PAN is empty");
			break;

	}
		sAssertion.assertAll();
	}
}


package com.acs.testcases;

import java.awt.AWTException;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.AddCardDetailsPage;

public class AddCardDetails extends ACSInitialSetUp{
	
	GenericMethods generic = new GenericMethods(driver);
	
	@BeforeMethod
	public void beforeAuthenticationMethod() {
		driver.get(Config.BASE_CRAD_REGISTRATION_URL);

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CardRegistration");
	}

	@Test(dataProvider = "DataSet")
	public void addCardDetails(String Cardnumber, String bankId, String MobileNumber) throws AWTException, InterruptedException, JSONException {

		SoftAssert sAssertion = new SoftAssert();
		// initialising the page objects
		AddCardDetailsPage addCardDetailsPage = new AddCardDetailsPage(driver);
		
		// Execution
		addCardDetailsPage.getAccountNumberField().clear();
		addCardDetailsPage.getAccountNumberField().sendKeys(Cardnumber);
		
		addCardDetailsPage.getBankIdField().click();
		Select bank = new Select(driver.findElement(By.id("bankid")));
		bank.selectByValue(bankId);
		
		addCardDetailsPage.getMobileNumberField().clear();
		addCardDetailsPage.getMobileNumberField().sendKeys(MobileNumber);

		// generic.explicitWait(3);

		addCardDetailsPage.getSendButton().click();
		
		generic.explicitWait(3);
		
		WebElement hiddenDiv = driver.findElement(By.cssSelector("#resp"));
		//String n = hiddenDiv.getText(); // does not work (returns "" as expected)
		
		String script = "return document.getElementById('resp').value";
		String n = (String) ((JavascriptExecutor) driver).executeScript(script, hiddenDiv);
		
		System.out.println("response :"+n);
		
		
		
		JSONObject obj = new JSONObject(n);
		boolean Result = (boolean) obj.get("success");
		
		System.out.println("Result is "+Result);
		
		sAssertion.assertEquals(Result, "success");
			                                                                        
		if(Result == true)
		{
			System.out.println("Card registered Successfully");
		}
		else
		{
			System.out.println("Registration failed");
		}	
		
		sAssertion.assertAll();
	}

}

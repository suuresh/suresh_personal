package com.acs.testcases;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;

import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class ACSInitialSetUp {

	public WebDriver driver;
	public Xls_Reader excel;
	int invocationCount = 2;
	public GenericMethods generic;
	public LogOutPage logout;
	public LoginPage loginPage;
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String XlFileName = null;
	public String OnBoradingXlFileName = null;
	public TridentLogOutPage tlogout;
	public TridentLoginPage tloginPage;
	public static AndroidDriver<AndroidElement> aDriver;
	public AppiumDriver<IOSElement> iDriver;
	public static AppiumDriverLocalService appiumService;
	public String proxyUrl = null;
	public WebDriverWait wait;
	public String downloadLocation = null;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	/*
	 * @BeforeTest(alwaysRun = true) public void BeforeStartingSuite() { generic =
	 * new GenericMethods(driver); log.info("Before test executing"); //
	 * generic.updateRBADefault(); log.info("Before test executed");
	 * 
	 * }
	 */

	@SuppressWarnings("deprecation")
	@Parameters({ "browser-name", "operating-system", "OnBoradingXlFileName", "XlFileName", "Txn1_0SheetName",
			"Txn2_0SheetName", "ACSTxn1_0SheetName", "ACSTxn2_0SheetName", "TridentTxn1_0SheetName",
			"TridentTxn2_0SheetName", "ThreeDSSTxn2_0SheetName", "ENV" })
	@BeforeTest
	public void preCondtion(String browser, String OS, String onboardingXlfile, String xlfilename,
			String txn1_0sheetName, String txn2_0sheetName, String acstxn1_0sheetName, String acstxn2_0sheetName,
			String tridenttxn1_0sheetName, String tridenttxn2_0sheetName, String threedsstxn2_0sheetName, String env)
			throws Exception {

		/*
		 * appiumService = AppiumDriverLocalService.buildService(new
		 * AppiumServiceBuilder() .usingDriverExecutable(new
		 * File(Config.NODE_JS_PATH)).withAppiumJS(new File(Config.APPIUM_MAIN_PATH))
		 * .withLogFile(new File(System.getProperty("user.dir") + "/Appium.log"))
		 * .withArgument(GeneralServerFlag.LOCAL_TIMEZONE)); appiumService.start();
		 * 
		 * File app = new File(
		 * System.getProperty("user.dir")+"/APKFiles/SMSPopup.apk"); DesiredCapabilities
		 * capabilities = new DesiredCapabilities();
		 * capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,
		 * Config.ANDROID_DEVICE_NAME);
		 * capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		 * capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,
		 * Config.ANDROID_VERSION); //
		 * capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		 * capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
		 * capabilities.setCapability("locationServicesAuthorized", true);
		 * capabilities.setCapability("autoGrantPermissions", "true");
		 * capabilities.setCapability("autoAcceptAlerts", "true");
		 * capabilities.setCapability(MobileCapabilityType.FULL_RESET, "false");
		 * capabilities.setCapability(MobileCapabilityType.NO_RESET, "true");
		 * capabilities.setCapability("appPackage", "net.everythingandroid.smspopup");
		 * capabilities.setCapability("appActivity",
		 * "net.everythingandroid.smspopup.ui.SmsPopupConfigActivity"); aDriver = new
		 * AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),
		 * capabilities); aDriver.manage().timeouts().implicitlyWait(40,
		 * TimeUnit.SECONDS); //
		 * aDriver.findElement(By.id("android:id/button1")).click();
		 */

		String envFromSysParams = System.getProperty("environment");
		log.debug("Environment :" + env);
		System.out.println("Environment :" + env);
		// Config.BASE_ENVIRONMENT = envFromSysParams;
		// Config.BASE_ENVIRONMENT = "DCS";
		Config.BASE_ENVIRONMENT = env;

		Config.assignEnvironment();
		// System.out.println("preCondtion");
		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		// System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;
		Txn1_0SheetName = txn1_0sheetName;
		Txn2_0SheetName = txn2_0sheetName;
		ACSTxn1_0SheetName = acstxn1_0sheetName;
		ACSTxn2_0SheetName = acstxn2_0sheetName;
		TridentTxn1_0SheetName = tridenttxn1_0sheetName;
		TridentTxn2_0SheetName = tridenttxn2_0sheetName;
		ThreeDSSTxn2_0SheetName = threedsstxn2_0sheetName;
		OnBoradingXlFileName = onboardingXlfile;

		System.out.println(OS);
		System.out.println(browser);

		if (OS.equalsIgnoreCase("windows")) {
			downloadLocation = "D:\\downloads";
			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.GECKODRIVER_PATH);
				driver = new FirefoxDriver();
				FirefoxOptions options = new FirefoxOptions();
				// options.setHeadless(true);
				driver = new FirefoxDriver(options);
				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				log.debug("opening the chrome browser");

				System.setProperty("webdriver.chrome.driver", Config.CHROMEDRIVER_PATH);
				System.setProperty("webdriver.chrome.logfile", "./chromedriver.log");
				System.setProperty("webdriver.chrome.verboseLogging", "true");

				ChromeOptions chromeOptions = new ChromeOptions();
				//DesiredCapabilities cap = DesiredCapabilities.chrome();

				Map<String, Object> prefs = new HashMap<>();
				prefs.put("download.default_directory", downloadLocation);
				chromeOptions.setExperimentalOption("prefs", prefs);

				// setProxy(proxyUrl, cap);
				//chromeOptions.addArguments("--headless=new");
				/*
				 * * // chromeOptions.addArguments("--disable-gpu");
				 * 
				 * chromeOptions.addArguments("window-size=1200x600");
				 * chromeOptions.addArguments("start-maximized"); //
				 * chromeOptions.addArguments("disable-infobars"); //
				 * chromeOptions.addArguments("--disable-extensions"); //
				 * chromeOptions.addArguments("--screenshot");
				 */
				// chromeOptions.addArguments("--no-sandbox");
				chromeOptions.setCapability("chromeOptions", chromeOptions);
				chromeOptions.setAcceptInsecureCerts(true);
				chromeOptions.setCapability("chrome.switches",
						Arrays.asList("--proxy-server=http://192.168.109.32:6558"));
				LoggingPreferences logPrefs = new LoggingPreferences();
				logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
				logPrefs.enable(LogType.DRIVER, Level.ALL);
				chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
				// cap.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
				chromeOptions.setExperimentalOption("w3c", false);
				driver = new ChromeDriver(chromeOptions);				 
			}
		} else if (OS.equalsIgnoreCase("linux")) {
			//System.out.println("Entered Linux");
			downloadLocation = "/home/acsapp/downloads";

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.LINUX_GECKODRIVER_PATH);
				FirefoxOptions options = new FirefoxOptions();
				//DesiredCapabilities cap = DesiredCapabilities.firefox();
				setProxyforFireFox(proxyUrl, options);
				options.setHeadless(true);

				driver = new FirefoxDriver(options);

				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {
				System.out.println("Entered Chrome");

				System.setProperty("webdriver.chrome.driver", Config.LINUX_CHROMEDRIVER_PATH);				
				System.setProperty("webdriver.chrome.logfile", "./chromedriver.log");
				System.setProperty("webdriver.chrome.verboseLogging", "true");
				
				ChromeOptions chromeOptions = new ChromeOptions();
				//DesiredCapabilities cap = DesiredCapabilities.chrome();
				
				
				chromeOptions.addArguments("headless");
				chromeOptions.addArguments("start-maximized");
				chromeOptions.addArguments("window-size=1200x600");				
				//chromeOptions.addArguments("--incognito");
				/*
				 * chromeOptions.addArguments("--remote-allow-origins=*");
				 * chromeOptions.addArguments("--disable-web-security");
				 * chromeOptions.addArguments("--ignore-certificate-errors-spki-list");
				 * chromeOptions.addArguments("--ignore-ssl-errors");
				 */
				chromeOptions.addArguments("--enable-javascript");
				
				/*
				 * chromeOptions.addArguments("--no-sandbox");
				 * chromeOptions.addArguments("--disable-dev-shm-usage");
				 * chromeOptions.addArguments("--disable-gpu");
				 * chromeOptions.addArguments("--privileged");
				 * chromeOptions.setBinary("/usr/bin/google-chrome");
				 * chromeOptions.addArguments("--disable-web-security");
				 */
				
				//chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
				//chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-logging"});
				
				

				/*
				 * * // chromeOptions.addArguments("--disable-gpu");
				 * 
				 * chromeOptions.addArguments("window-size=1200x600");
				 * chromeOptions.addArguments("start-maximized"); //
				 * chromeOptions.addArguments("disable-infobars"); //
				 * chromeOptions.addArguments("--disable-extensions"); //
				 * chromeOptions.addArguments("--screenshot");
				 */
				// chromeOptions.addArguments("--no-sandbox");
				//setProxy(proxyUrl, chromeOptions);
				
				chromeOptions.setCapability("chromeOptions", chromeOptions);
				chromeOptions.setAcceptInsecureCerts(true);
				chromeOptions.setCapability("chrome.switches",
						Arrays.asList("--proxy-server=http://192.168.109.32:6558"));
				
				Map<String, Object> prefs = new HashMap<>();
				prefs.put("download.default_directory", downloadLocation);
				chromeOptions.setExperimentalOption("prefs", prefs);
				
				
				LoggingPreferences logPrefs = new LoggingPreferences();
				logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
				logPrefs.enable(LogType.DRIVER, Level.ALL);
				// chromeOptions.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
				chromeOptions.setCapability("goog:loggingPrefs", logPrefs);
				chromeOptions.setExperimentalOption("w3c", false);
				chromeOptions.setAcceptInsecureCerts(true);
				
				driver = new ChromeDriver(chromeOptions);
				
				
				System.out.println(driver);
			}
		} else if (OS.equalsIgnoreCase("mac")) {

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
				driver = new FirefoxDriver();

				// this is how applogs will be generated.
				log.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				driver = new ChromeDriver();
			}
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);
		System.out.println("***********Browser Opened Succesfully**********");
		generic = new GenericMethods(driver);
		loginPage = new LoginPage(driver);
		logout = new LogOutPage(driver);
		tloginPage = new TridentLoginPage(driver);
		tlogout = new TridentLogOutPage(driver);
		// otpFromMobile = new ReadOTP(driver);

	}

	private void setProxy(String proxyUrl, ChromeOptions chromeOptions) {
		if (proxyUrl != null) {
			// Setting proxy properties for driver
			Proxy proxy = new Proxy();
			proxy.setHttpProxy(proxyUrl);
			proxy.setSslProxy(proxyUrl);

			chromeOptions.setCapability("proxy", proxy);
		}
	}

	private void setProxyforFireFox(String proxyUrl, FirefoxOptions options) {
		if (proxyUrl != null) {
			// Setting proxy properties for driver
			Proxy proxy = new Proxy();
			proxy.setHttpProxy(proxyUrl);
			proxy.setSslProxy(proxyUrl);

			options.setCapability("proxy", proxy);
		}
	}

	@AfterTest
	public void postCondtion() throws Exception {
		if (driver != null)
			driver.quit();
//		ReadOTP.uninstallSMSAPK();
		// appiumService.stop();
	}

	@BeforeMethod
	public void beforeMehtodLogin() {
		// generic.explicitWait(1);
		// driver.get(Config.BASE_TRANSACTION_URL);
		// LogEntries logs = driver.manage().logs().get("performance");
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {

		if (result.getStatus() == ITestResult.SUCCESS) {

			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// generic.getACSTxnIDFromDB());
		}
		log.debug("Invocationcount= " + invocationCount);
		invocationCount++;
	}
}

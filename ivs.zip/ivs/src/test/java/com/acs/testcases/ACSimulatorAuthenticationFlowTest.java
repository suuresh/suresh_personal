package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.ACSSimulatorCheckOutPage;
import com.acs.pages.ACSSimulatorReponsePage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;

import com.acs.pages.StaticPasswordPage;
import com.acs.payloads.AreqRequestBodyHelper;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class ACSimulatorAuthenticationFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_ACS_SIMULATOR_URL);
		//System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, "ACS_Simulator");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String TestCaseID, String IssuerBankId, String IssuerBankName,
			String AccquirerBankId, String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow,
			String merchantname, String TransactionAmount, String CurrencyType, String CardUnionType, String TxnType,
			String AuthPayCredStatus, String DafAdvice, String ThreeRIInd, String Score, String Decision,
			String ReasonCode1, String acsTxnId, String CavvOrAvv, String ThreeDSTxnId, String RiskengineClientID,
			String RiskScore, String RiskSuggestion, String OtpExpiryTime, String PageExpiryTime,
			String OtpExpiryMessage, String ResendOTPMessage, String MaxResendOTPMessage, String OtpBlankMessage,
			String OtpLessthanMessage, String InvalidOTPMessage, String CardNotRegisteredText, String CCPageText,
			String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		ACSSimulatorCheckOutPage checkoutpage = new ACSSimulatorCheckOutPage(driver);
		ACSSimulatorReponsePage responsepage = new ACSSimulatorReponsePage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;

		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "RiskSuggestion", invocationCount, "");
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		/*
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "AcsTxnId", invocationCount, ""); GenericMethods.writingToExcell(XlFileName,
		 * ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "ThreeDSTxnId", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "RiskengineClientID", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "RiskScore", invocationCount, ""); GenericMethods.writingToExcell(XlFileName,
		 * ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");
		 */
		System.out.println("***Test Started*****");
		System.out.println("TestCaseID: "+TestCaseID + "Flow: " + Flow + "Card Number : " + Cardnumber + "TxnType: " + TxnType);
		//System.out.println("Flow: " + Flow);
		//System.out.println("Merchant Name : " + merchantname);
		//System.out.println("Card Number : " + Cardnumber);
		//System.out.println("Protocal Version : " + ProtocalVersion);
		//System.out.println("TxnType: " + TxnType);

		// putting try catch block to handle popup
		try {

			checkoutpage.getAcsAreqURLInputField().clear();
			checkoutpage.getAcsAreqURLInputField().sendKeys(Config.BASE_ACS_SIMULATOR_AREQ_URL + IssuerBankId);

			String areqResponse = null;
			if (TxnType.contentEquals("NPA") ) {
				areqResponse = AreqRequestBodyHelper.generateNPAAreqBody(Cardnumber, ThreeRIInd);
			} else if (TxnType.contentEquals("DAF")) {
				areqResponse = AreqRequestBodyHelper.generateDAFAreqBody(Cardnumber, AuthPayCredStatus, DafAdvice);
			} else if(TxnType.contains("CustomerFetch") || TxnType.contains("CAAV7") || TxnType.contentEquals("") || TxnType.contentEquals("CardBasedAuth")) {
				areqResponse = AreqRequestBodyHelper.generateCustomerFetchBody(Cardnumber);
			} else if(TxnType.contentEquals("SwitchCard")) {
				areqResponse = AreqRequestBodyHelper.generateEMIRequestBody(Cardnumber, TransactionAmount, merchantname, CurrencyType, ProtocalVersion);
			} else if(TxnType.contentEquals("MasterCardSmartAuthentication")) {
				areqResponse = AreqRequestBodyHelper.generateMasterCardSmartAuthRequestBody(Cardnumber, Score, Decision, ReasonCode1);
			} else if(TxnType.contentEquals("TravelMessageExtension")) {
				areqResponse = AreqRequestBodyHelper.generateTravelMessageExtRequestBody(Cardnumber);
			}

			System.out.println("Prepared Areq : " + areqResponse);
			generic.explicitWait(2);
			checkoutpage.getAreqPayloadInputField().click();
			checkoutpage.getAreqPayloadInputField().clear();
			generic.explicitWait(2);
			
			WebElement textareaelement = driver.findElement(By.id("areq_id"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].value='" + areqResponse + "'", textareaelement);
			generic.explicitWait(2);
			checkoutpage.getAreqSubmitButton().click();

			String CAVVValue = null;

			switch (Flow) {

			case "FrictionLess":
				log.info(Flow + "Started");
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(),
							"ECI : 05", "ECI Value Validation");
					
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("A"), "CAVV value validation");
					}					 
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(),
							"ECI : 02", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("j"), "CAVV value validation");
					}
				}

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				//GenericMethods.writingToExcell(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				//GenericMethods.writingToExcell(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount, CAVVValue);

				break;
				
			case "Deny":
				log.info(Flow + "Started");
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(),
							"ECI : 05", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("A"), "CAVV value validation");
					}
					 
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(),
							"ECI : 02", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("j"), "CAVV value validation");
					}
				}

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				//GenericMethods.writingToExcell(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				//GenericMethods.writingToExcell(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount, CAVVValue);
				break;

			case "Static":

				generic.explicitWait(3);
				staticpaw.getStaticPasswordField().sendKeys(Config.STATIC_PASSWORD);
				// generic.explicitWait(3);
				staticpaw.getStaticPasswordSubmitButton().click();

				// generic.explicitWait(5);

				break;

			case "Challenge":
				log.info(Flow + "Started");

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					//System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								//System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else {
								System.out.println("image url: " + imgElement.getAttribute("src"));
							}
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						//System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}
					
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
				} else {
					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					//System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					//System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				
				if(TxnType.contentEquals("CardBasedAuth")) {
					otpValue = OTPFromEngine.getCustomerFetchOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				}else {
					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				}

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(3);				

				otp.getOtpSubmitButton().click();
				generic.explicitWait(2);
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));

				sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(),
							"ECI : 05", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("A"), "CAVV value validation");
					}					
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(),
							"ECI : 02", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("j"), "CAVV value validation");
					}
				}

				// Writing the real value from the response page.
				//System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount,
						CAVVValue);

				break;
				
			case "BrowserBack":
				log.info(Flow + "Started");
				
				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					//System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								//System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else {
								//System.out.println("image url: " + imgElement.getAttribute("src"));
							}
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					//System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					//System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				driver.navigate().back();
				
				generic.explicitWait(600);				

				// Writing the real value from the response page.
				//System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				break;
				
			case "Resend":
				log.info(Flow + "Started");
				if(TxnType.contentEquals("SwitchCard")) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
				}
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);

					

					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {

					

					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					//System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						//System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpResendButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));

				System.out.println(otp.getResendOTPMessage().getText());

				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), ResendOTPMessage);

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(),
							"ECI : 05", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("A"), "CAVV value validation");
					}
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(),
							"ECI : 02", "ECI Value Validation");
					if (TxnType.contentEquals("NPA")) {
						CAVVValue = AreqRequestBodyHelper
								.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
						sAssertion.assertTrue(CAVVValue.startsWith("j"), "CAVV value validation");
					}
				}

				// Writing the real value from the response page.
				//System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount,
						CAVVValue);

				break;

			case "PageExpiry":
				
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}

					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				} else {

					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}
				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				//generic.explicitWait(60);
				generic.explicitWait(3);
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");				

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				//System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);

					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}

					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {

					if(TxnType.contentEquals("SwitchCard")) {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
					}
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));

					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					//System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								//System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						//System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.				
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));
				generic.explicitWait(3);
				otp.getOtpTextField().sendKeys(otpValue);
				otp.getOtpSubmitButton().click();

				System.out.println(otp.getResendOTPMessage().getText());
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), OtpExpiryMessage);
						
				generic.explicitWait(3);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "BlockCard":
				log.info(Flow + "Started");
				if(TxnType.contentEquals("SwitchCard")) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
				}
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
				//System.out.println("OTP page and Submit Button Displayed for BlockCard Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));

					sAssertion.assertTrue(otp.getInvalidOTPMessage().getText().contains( InvalidOTPMessage));
							

					/*
					 * sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
					 * "You have entered an incorrect OTP. Please enter the 6-digit OTP with reference ID"
					 * );
					 */
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					generic.explicitWait(3);
					//System.out.println(driver.findElements(By.xpath("//button[@id='submitBtn']")).size());
					if(driver.findElements(By.xpath("//button[@id='submitBtn']")).size() != 0) {
						otp.getCardBlockedContinueButton().click();
					}
					

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for BlockCard
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));

					sAssertion.assertTrue(otp.getInvalidOTPMessage().getText().contains(InvalidOTPMessage));

					/*
					 * sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
					 * "The code you entered is incorrect please try again.");
					 */
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					//System.out.println("Customer care page and submit button is displayed");
					System.out.println(CardNotRegisteredText);
					System.out.println(otp.getCardNotRegisteredText().getText());
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);
							

					otp.getCardBlockedContinueButton().click();
				}
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				//System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Cancelled":
				if(TxnType.contentEquals("SwitchCard")) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
				}
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
				//System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for Cancel
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				System.out.println(otp.getResendOTPMessage().getText());
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), ResendOTPMessage);
				otp.getOtpResendButton().click();
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				System.out.println(otp.getResendOTPMessage().getText());
				
				sAssertion.assertTrue(otp.getResendOTPMessage().getText().contains(MaxResendOTPMessage));
				
				// sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				// "This is your last attempt. An OTP with reference ID");
				otp.getOtpCancelButton().click();
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				//System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Failed":
				
				if(TxnType.contentEquals("SwitchCard")) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));	
				}
				//System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					// System.out.println("Cutomer Care page and Submit Button Displayed for Failed
					// Card");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				}
				System.out.println(CardNotRegisteredText);
				System.out.println(otp.getCardNotRegisteredText().getText());
				
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CardNotRegisteredText));

				otp.getCardNotRegisteredContinueButton().click();
				 

				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				
				if(TxnType.contentEquals("SwitchCard")) {
					sAssertion.assertEquals(responsepage.getTransactionStatusR().getText(), "Status : R");
				} else {
					sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");
				}
				
				

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				
				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				
				break;

			case "OtpPage":

				NetWorklogs = driver.manage().logs().get("performance");
				//System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				//System.out.println("Current URL : " + currentURL);
				acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("acsTxnId:"+acsTxnId);
				// validating blank otp
				
				otp.getOtpSubmitButton().click();
				generic.explicitWait(2);
				
				System.out.println("OtpBlankMessage:"+OtpBlankMessage);
				
				if(TxnType.contentEquals("SwitchCard")) {
					Alert blankOtp = driver.switchTo().alert();
					String aBlankOtpText = blankOtp.getText();
					sAssertion.assertEquals(aBlankOtpText, OtpBlankMessage);
					blankOtp.accept();
				} else {
					sAssertion.assertEquals(otp.getErrorText().getText(), OtpBlankMessage);
				}
				
				

				// validating less than 6 digit otp
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("345");
				otp.getOtpSubmitButton().click();
				generic.explicitWait(2);

				// validating less than 6 digit otp text
				System.out.println("OtpLessthanMessage" + OtpLessthanMessage);
				if(TxnType.contentEquals("SwitchCard")) {
					Alert lessThanSixOtpSubmit = driver.switchTo().alert();
					String lessThanSixOtpText = lessThanSixOtpSubmit.getText();
					sAssertion.assertEquals(lessThanSixOtpText, OtpLessthanMessage);
					lessThanSixOtpSubmit.accept();
				} else {
					sAssertion.assertEquals(otp.getErrorText().getText(), OtpLessthanMessage);
				}
				
				// Entering alpha numeric
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("12h$X0");
				otp.getOtpSubmitButton().click();

				
				// sAssertion.assertEquals(aAlphaNumText, eAlphaNumText);
				sAssertion.assertTrue(otp.getInvalidOTPMessage().getText().contains(InvalidOTPMessage));

				otp.getOtpCancelButton().click();
				generic.explicitWait(2);
				
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");
				
				
				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				
				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				
				break;

			case "Blocked":
				log.info("Testing blocked");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				//System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");
				System.out.println(CCPageText);
				System.out.println(otp.getCardNotRegisteredText().getText());
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CCPageText));
				
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
					try {
						otp.getCardNotRegisteredContinueButton().click();
					} catch (Exception e) {
						//System.out.println("Handling unexpected popup");

						Alert alert = driver.switchTo().alert();
						//System.out.println("Type of alert: " + alert.getText());
						alert.accept();
					}
					
					if(TxnType.contentEquals("SwitchCard")) {
						sAssertion.assertEquals(responsepage.getTransactionStatusR().getText(), "Status : R");
					} else {
						sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");
					}

					// Writing the real value from the response page.
					GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
					//System.out.println("Canceled the Transaction");

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				} else {

					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getCardNotRegisteredContinueButton().click();
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
					if(TxnType.contentEquals("SwitchCard")) {
						sAssertion.assertEquals(responsepage.getTransactionStatusR().getText(), "Status : R");
					} else {
						sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");
					}

					// Writing the real value from the response page.
					GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
					//System.out.println("Canceled the Transaction");

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				}
				break;
			
			}
		} catch (

		UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

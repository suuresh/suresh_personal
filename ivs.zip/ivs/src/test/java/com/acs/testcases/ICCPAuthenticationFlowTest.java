package com.acs.testcases;

import java.awt.AWTException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.pages.MultiSelectPage;
import com.acs.pages.OTPPage;
import com.acs.pages.PgResponsePage;
import com.acs.pages.SingleSelectPage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.EncryptAndDecrypt;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.appium.android.ReadOTP;
import com.google.gson.JsonObject;

import io.appium.java_client.AppiumDriver;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.CardEncryptHomePage;
import com.acs.pages.CheckOutPage;
import com.acs.pages.MerchantDetailsPage;

public class ICCPAuthenticationFlowTest extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;
	String acsTxnIdFromHeaders;
	String cavvOrAvv;
	String threeDsTransactionId;
	LogEntries NetWorklogs;
	private int invalidImageCount;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		System.out.println(Config.BASE_TRANSACTION_URL);
		driver.get(Config.BASE_TRANSACTION_URL);
		generic.explicitWait(2);
		System.out.println("Title of the page : " + driver.getTitle());
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println(XlFileName);
		System.out.println(Txn2_0SheetName);
		return generic.getData(XlFileName, Txn2_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String MerchantName,
			String TransactionAmount, String CurrencyType, String CardUnionType, String AcsTxnId, String CavvOrAvv,
			String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage, String ResendOTPMessage,
			String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText, String CCPageText,
			String TestCaseDiscription) throws Exception {

		System.out.println("****** Test Started ********");
		ExtentTestManager.getTest().setDescription(TestCaseDiscription);
		SoftAssert sAssertion = new SoftAssert();
		// initialising the page objects
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		PgResponsePage responsepage = new PgResponsePage(driver);
		OTPPage otp = new OTPPage(driver);
		MerchantDetailsPage mdp = new MerchantDetailsPage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		SingleSelectPage single = new SingleSelectPage(driver);
		MultiSelectPage multi = new MultiSelectPage(driver);
		CardEncryptHomePage enNDcryptPage = new CardEncryptHomePage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		ReadOTP otpFromMobile = new ReadOTP(driver);
		String mySMS = null;
		String currentURL = null;
		acsTxnIdFromHeaders = null;
		cavvOrAvv = null;
		threeDsTransactionId = null;

		// Clear the excel
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		checkoutpage.getAddToCartButton().click();
		generic.explicitWait(2);
		// System.out.println("Clicked on Add To Cart button");
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(MerchantName);

		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(CurrencyType);

		// generic.explicitWait(3);

		checkoutpage.getCheckOutButton().click();
		generic.explicitWait(6);
		// System.out.println("Clicked on Checkout button");
		System.out.println("Flow: " + Flow);

		switch (Flow) {

		case "MerchantDetailsValidation":
			driver.switchTo().frame("foo");

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			mdp.getCorporateId().clear();
			mdp.getSubmitButton().click();
			sAssertion.assertEquals(mdp.getAlertBox1().getText(), "Corporate Id cannot be blank");

			mdp.getCorporateId().sendKeys("Test");
			mdp.getEmployeeId().clear();
			mdp.getSubmitButton().click();
			sAssertion.assertEquals(mdp.getAlertBox2().getText(), "Employee Id cannot be blank");

			mdp.getEmployeeId().sendKeys("test");
			mdp.getSubmitButton().click();
			sAssertion.assertEquals(mdp.getSuccessMessage().getText(),
					"Please enter valid credentials to proceed with the transaction.");

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			generic.explicitWait(2);

			break;
		case "MerchantDetailsCancelled":
			driver.switchTo().frame("foo");
			
			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			mdp.getCancelButton().click();
			generic.explicitWait(2);

			break;
		case "MerchantDetailsPageExpiry":
			driver.switchTo().frame("foo");
			
			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			generic.explicitWait(Integer.parseInt(PageExpiryTime));
			break;

		case "FrictionLess":

			log.info(Flow + "Started");
			// acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			// System.out.println("acsTxnIdFromHeaders: "+acsTxnIdFromHeaders);
			break;

		case "Static":

			driver.switchTo().frame("foo");
			generic.explicitWait(3);
			staticpaw.getStaticPasswordField().sendKeys(Config.STATIC_PASSWORD);
			// generic.explicitWait(3);
			staticpaw.getStaticPasswordSubmitButton().click();
			// generic.explicitWait(5);
			break;

		case "Challenge":

			log.info(Flow + "Started");

			driver.switchTo().frame("foo");

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			generic.explicitWait(2);

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			String otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromHeaders);
			otp.getOtpField().sendKeys(otpValue);
			generic.explicitWait(1);
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			break;

		case "Single":

			driver.switchTo().frame("foo");
			generic.explicitWait(3);

			single.getEmailRadioButton().click();
			// single.getMobileRadioButton().click();

			single.getNextButton().click();

			// generic.explicitWait(5);

			break;

		case "Multi":

			driver.switchTo().frame("foo");

			multi.getBangaloreCheckBox().click();
			multi.getPuneCheckBox().click();

			/*
			 * multi.getAndraCheckBox().click(); multi.getChennaiCheckBox().click();
			 * multi.getDalaCheckBox().click(); multi.getDelhiCheckBox().click();
			 * multi.getMysoreCheckBox().click(); multi.getPuneCheckBox().click();
			 */
			// generic.explicitWait(3);
			multi.getNextButton().click();

			break;

		case "OTPCloseBrowser":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			driver.switchTo().frame("foo");
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();
			
			break;

		case "OTPExpiry":
			
			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromHeaders);
			// System.out.println(otpValue);
			System.out.println(OtpExpiryTime);
			generic.explicitWait(Integer.parseInt(OtpExpiryTime));
			System.out.println("Time completed");

			generic.explicitWait(2);

			otp.getOtpField().sendKeys(otpValue);

			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(3);
			System.out.println("Clicked otp Button");
			
			//The One-Time PIN (OTP) you entered has already expired. Please request for a new one by clicking Resend OTP.
			//OtpExpiryMessage
			
			//sAssertion.assertEquals(otp.getResendOTPMessage().getText(), OtpExpiryMessage);

						
			otp.getOtpCancelButton().click();
			
			generic.explicitWait(2);
			break;

		case "Blocked":

			log.info("Testing blocked");
			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			System.out.println(otp.getCardNotRegisteredText().getText());
			System.out.println(CCPageText);
			
			sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CCPageText);

			otp.getContinueBtn().click();
			generic.explicitWait(2);
			break;

		case "BlockCard":
			log.info(Flow + "Started");

			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();
			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			
			/*
			 * wait.until(ExpectedConditions
			 * .visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
			 */

			generic.explicitWait(2);
			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			System.out.println(otp.getErrorText().getText());
			System.out.println(InvalidOTPMessage);

			sAssertion.assertEquals(otp.getErrorText().getText(), InvalidOTPMessage);
			// "The OTP code you entered is incorrect please try again.");

			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			if (IssuerBankId.contentEquals("")) {
				otp.getOtpField().sendKeys("123456");
				otp.getSBICSubmitBtn().click();
				generic.explicitWait(2);

				otp.getOtpField().sendKeys("123456");
				otp.getSBICSubmitBtn().click();
				generic.explicitWait(2);
			}

			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// acsTxnIdFromHeaders);
			// aDriver.findElement(By.id("net.everythingandroid.smspopup:id/button1")).click();
			break;

		case "Cancelled":

			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);


			generic.explicitWait(2);
			otp.getOtpCancelButton().click();
			log.info("Canceled the Transaction");
			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// acsTxnIdFromHeaders);
			// aDriver.findElement(By.id("net.everythingandroid.smspopup:id/button1")).click();
			break;

		case "Failed":
			generic.explicitWait(2);
			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			/*
			 * if (IssuerBankId.contentEquals("8111") && IssuerBankId.contentEquals("8198"))
			 * { System.out.println("Donothing"); } else { driver.switchTo().frame("foo"); }
			 */

			if (IssuerBankId.contentEquals("8198")) {
				System.out.println("Donothing");
			} else {
				System.out.println(otp.getCardNotRegisteredText().getText());
				System.out.println(CardNotRegisteredText);

				sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);

				// "Dear Customer, Your contact details could are not available with the bank
				// for online transactions. Please visit your nearest branch to update your
				// contact details. For any queries, please contact the bank customer care at:
				// Phone:- 1234567890, Email:- customercare@bank.com");
				// "Dear Customer, Your contact details are not available with the bank for
				// online transactions. Please visit your nearest branch to update your contact
				// details or please contact the bank customer care at +021-111-124-444.");
				otp.getContinueBtn().click();
			}

			break;

		case "Resend":

			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			
			otp.getOtpResendButton().click();
			System.out.println("1");
			generic.explicitWait(2);
			otp.getOtpResendButton().click();
			System.out.println("2");
			generic.explicitWait(2);
			otp.getOtpResendButton().click();
			System.out.println("3");
			generic.explicitWait(2);
			

			if (IssuerBankId.contentEquals("8198")) {
				otp.getOtpResendButton().click();
				generic.explicitWait(2);
				otp.getOtpResendButton().click();
				generic.explicitWait(2);
			} else {
				System.out.println("else case");
				System.out.println(otp.getErrorText().getText());
				System.out.println(MaxResendOTPMessage);
				sAssertion.assertEquals(otp.getErrorText().getText(), MaxResendOTPMessage);
				generic.explicitWait(2);
			}

			otp.getOtpCancelButton().click();
			break;

		case "OtpPage":

			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			

			// Validate empty otp
			otp.getOtpField().clear();
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			String errorText = "Please enter the OTP.";
			sAssertion.assertEquals(otp.getErrorText().getText(), errorText);

			// validating less than 6 digit otp
			otp.getOtpField().clear();
			otp.getOtpField().sendKeys("345");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			errorText = "OTP you received cannot be less than 6 digits.";
			sAssertion.assertEquals(otp.getErrorText().getText(), errorText);

			// Validate with in correct code
			otp.getOtpField().clear();
			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			// errorText = "The OTP code you entered is incorrect please try again.";
			sAssertion.assertEquals(otp.getErrorText().getText(), InvalidOTPMessage);
			break;

		case "PageExpiry":

			driver.switchTo().frame("foo");
			
			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);
			
			mdp.getCorporateId().clear();
			mdp.getCorporateId().sendKeys(Config.BASE_CORPORATE_ID);

			mdp.getEmployeeId().clear();
			mdp.getEmployeeId().sendKeys(Config.BASE_EMPLOYEE_ID);

			mdp.getSubmitButton().click();

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			generic.explicitWait(Integer.parseInt(PageExpiryTime));
			System.out.println("PageExpiryTime"+PageExpiryTime);
			generic.explicitWait(5);
			// generic.explicitWait(425);
			
			break;

		}

		if (Flow.contentEquals("MerchantDetailsValidation")) {
			System.out.println("Close the browser");
		} else if (Flow.contentEquals("MerchantDetailsCancelled")) {
			System.out.println("Cancelled");
			mdp.getYesBtn().click();
			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
		} else if(Flow.contentEquals("MerchantDetailsPageExpiry")) {
			System.out.println("PageExpiry");
			//String parentWindow = driver.getWindowHandle();
			//System.out.println("parentWindow"+parentWindow);
			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();
			generic.explicitWait(3);
			
			//driver.switchTo().frame("foo");
			
			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			
		} else if (Flow.contentEquals("Frictionless")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			} else {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
			}
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Frictionless");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		} else if (Flow.contentEquals("OTPCloseBrowser") || Flow.contentEquals("OtpPage")) {
			log.info("Browser Closed");
			System.out.println("Browser Closed");
		} else if (Flow.contentEquals("OTPExpiry")) {
			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
		} else if (Flow.contentEquals("Blocked")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			} else {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			}
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();

		} else if (Flow.contentEquals("Cancelled") || Flow.contentEquals("BlockCard")
				|| Flow.contentEquals("Failed") || Flow.contentEquals("PageExpiry")
				|| Flow.contentEquals("Resend")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		} else {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			} else {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
			}
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getRreqStatusValue().getText(), "Y");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		}
		this.writeRequiredFieldsToExcel();
		log.info(Flow + " Completed");
		sAssertion.assertAll();
		invocationCount++;

	}

	private void writeRequiredFieldsToExcel() {

		// Writing the real value from the response page.

		// AcsTxnId
		if (acsTxnIdFromHeaders != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
		}

		// CavvOrAvv
		if (cavvOrAvv != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, cavvOrAvv);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, cavvOrAvv);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, cavvOrAvv);
		}

		// ThreeDSTxnId
		if (threeDsTransactionId != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
		}
	}

	private String getTransactionId(GetHeaders getHeaders, String IssuerBankId) {
		generic.explicitWait(5);
		NetWorklogs = driver.manage().logs().get("performance");
		// System.out.println("NETWORK LOGS: " + NetWorklogs);
		String currentURL = driver.getCurrentUrl();
		// System.out.println("Current URL : " + currentURL);
		String acsTxnIdFromHeaders = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
		return acsTxnIdFromHeaders;
	}

	private void verifyImages(SoftAssert sAssertion) {
		try {
			invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {
					// String imgSRCUrl = imgElement.getAttribute("src");
					// int statuscode =generic.verifyimageActive(imgElement);
					HttpClient client = HttpClientBuilder.create().build();
					// HttpHost proxyhost = new HttpHost(proxyUrl);
					HttpGet request = new HttpGet(imgElement.getAttribute("src"));
					// HttpResponse response = client.execute(proxyhost, request);
					HttpResponse response = client.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						invalidImageCount++;
						System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

					} else
						System.out.println("image url: " + imgElement.getAttribute("src"));
					int respCode = response.getStatusLine().getStatusCode();
					String resposeCode = respCode + "";
					sAssertion.assertEquals(resposeCode, "200");
				}
				System.out.println("Total no. of invalid images are " + invalidImageCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}

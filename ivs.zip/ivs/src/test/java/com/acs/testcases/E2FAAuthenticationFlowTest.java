package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;

import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class E2FAAuthenticationFlowTest extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, Txn2_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String acsTxnId, String CavvOrAvv,
			String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage, String ResendOTPMessage,
			String MaxResendOTPMessage, String OtpBlankMessage, String OtpLessthanMessage, String InvalidOTPMessage,
			String CardNotRegisteredText, String CCPageText, String decs) throws Exception {
		System.out.println("************************** Test Started ****************");
		System.out.println("Flow:: " + Flow);
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		NewSimulatorCheckOutPage checkoutpage = new NewSimulatorCheckOutPage(driver);
		NewSimulatorResponsePage responsepage = new NewSimulatorResponsePage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskSuggestion", invocationCount, "");
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		System.out.println("Merchant Name : " + merchantname);
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(merchantname);

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		System.out.println("Amout : " + amount);
		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		System.out.println("Currency : " + currencytype);
		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(currencytype);

		System.out.println("Acquirer Bank Id : " + AccquirerBankId);
		checkoutpage.getAcquirerIDField().clear();
		checkoutpage.getAcquirerIDField().sendKeys(AccquirerBankId);
		System.out.println("Protocal Version : " + ProtocalVersion);

		// putting try catch block to handle popup
		try {
			String versionCheckUrl = checkoutpage.getVersionCheckURLFeild().getAttribute("value");
			System.out.println("Version check url from simulator : " + versionCheckUrl);
			String arr[] = versionCheckUrl.split("pVrq/");
			System.out.println("Splitter version Check url is : " + arr[0]);
			String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
			//System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
			checkoutpage.getVersionCheckURLFeild().clear();
			checkoutpage.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
			
			System.out.println("Checkout page button name::"+checkoutpage.getSubmitButton().getText());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,300)");
			js.executeScript("arguments[0].click();", checkoutpage.getSubmitButton());
			//checkoutpage.getSubmitButton().click();
			
			generic.explicitWait(5);

			System.out.println("Clicked on Checkout button");

			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Submit paReq']")));
				checkoutpage.getSubmitPaReqButton().click();
				System.out.println("Clicked on PaReq button");

			}

			switch (Flow) {

			case "FrictionLess":
				log.info(Flow + "Started");
				System.out.println("FrictionLess started");
				//driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
				System.out.println("Title of the page : " + driver.getTitle());
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				System.out.println(responsepage.getTransactionStatusValue().getText());
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05", "ECI Value Validation");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"),
							"CAVV value validation");
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02", "ECI Value Validation");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"),
							"CAVV value validation");
				}

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;
			case "Challenge":
				System.out.println("Challenge Flow");
				log.info(Flow + "Started");
				generic.explicitWait(5);
				//driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
				System.out.println("Title of the page : " + driver.getTitle());				
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					System.out.println("In Challenge pv 2.1.0");
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='submitBtn1']")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

				} else {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					//System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					//System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					//System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					//System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				generic.explicitWait(2);

				otpValue = OTPFromEngine.getE2FAOtp(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"));
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"));
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				break;
			case "OTPCloseBrowser":

				generic.explicitWait(5);

				acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
				System.out.println("acsTxnId: " + acsTxnId);

				generic.explicitWait(2);

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "Resend":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

					// generic.explicitWait(2);
				} else {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpResendButton().click();
				
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='success mid-content'])[1]")));
				

				System.out.println(otp.getResendOTPMessage().getText());
				System.out.println(ResendOTPMessage);

				sAssertion.assertTrue(otp.getResendOTPMessage().getText().contains(ResendOTPMessage));

				otpValue = OTPFromEngine.getE2FAOtp(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"));
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"));
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;

			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				generic.explicitWait(5);
				
				System.out.println("Title of the page : " + driver.getTitle());
				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);
				
				acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
				System.out.println("acsTxnId: " + acsTxnId);
				
				
				System.out.println("PageExpiryTime:"+ PageExpiryTime);
				generic.explicitWait(Integer.parseInt(PageExpiryTime));	
				//generic.explicitWait(60);
				generic.explicitWait(3);

				String currentWindowHandle = driver.getWindowHandle();
				
				Alert alert1 = driver.switchTo().alert();
				System.out.println("Type of alert: " + alert1.getText());
				alert1.accept();
				
				driver.switchTo().window(currentWindowHandle);
				WebElement yesElement2 = driver.findElement(By.id("id_truebtn1"));
				yesElement2.click();
				 
				

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

					// generic.explicitWait(2);
				} else {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getE2FAOtp(Cardnumber, IssuerBankId, acsTxnId);

				// Waiting Explicitly for OTP to be expired.
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));
				generic.explicitWait(10);
				System.out.println("time Completed");
				
				otp.getOtpTextField().sendKeys(otpValue);
				otp.getOtpSubmitButton().click();
				 
				System.out.println("getOtpSubmitButton Clicked");

				System.out.println(otp.getResendOTPMessage().getText());
				System.out.println(OtpExpiryMessage);

				//sAssertion.assertEquals(otp.getResendOTPMessage().getText(), OtpExpiryMessage);
				sAssertion.assertTrue(otp.getResendOTPMessage().getText().contains(OtpExpiryMessage));
				otp.getCancelTxnBtn().click();
				WebElement yesElement1 = driver.findElement(By.id("id_truebtn1"));
				
				yesElement1.click();
				generic.explicitWait(3);
				
				
				
				
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
				 
				// Writing the real value from the response page.
				/*
				 * GenericMethods.writingToExcell(XlFileName, Txn2_0SheetName, "ThreeDSTxnId",
				 * invocationCount, responsepage.getThreeDSServerTransID().getText());
				 */
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				/*
				 * GenericMethods.writingToExcell(XlFileName, ACSTxn2_0SheetName,
				 * "ThreeDSTxnId", invocationCount,
				 * responsepage.getThreeDSServerTransID().getText());
				 */

				// writing to 3DSS file
				/*
				 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
				 * "AcsTxnId", invocationCount, acsTxnId);
				 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
				 * "ThreeDSTxnId", invocationCount,
				 * responsepage.getThreeDSServerTransID().getText());
				 */
				break;

			case "BlockCard":
				log.info(Flow + "Started");
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				System.out.println("OTP page and Submit Button Displayed for BlockCard Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='success mid-content'])[1]")));
					

					System.out.println(otp.getInvalidOTPMessage().getText());
					System.out.println(InvalidOTPMessage);

					// sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
					// InvalidOTPMessage);
					sAssertion.assertTrue(otp.getInvalidOTPMessage().getText().contains(InvalidOTPMessage));

					// "The OTP you entered is incorrect please try again.");
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();

					/*
					 * System.out.println("CardNotRegisteredText");
					 * System.out.println(otp.getCardNotRegisteredText().getText());
					 * System.out.println(CardNotRegisteredText);
					 * sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(
					 * CardNotRegisteredText)); otp.getCardBlockedContinueButton().click();
					 */

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for BlockCard
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='success mid-content'])[1]")));
					sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
							"The code you entered is incorrect please try again.");
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					System.out.println("Customer care page and submit button is displayed");
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
							"Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately.");

					otp.getCardBlockedContinueButton().click();
				}

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				/*
				 * // writing to 3DSS file GenericMethods.writingToExcel(XlFileName,
				 * ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				 * GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName,
				 * "ThreeDSTxnId", invocationCount,
				 * responsepage.getThreeDSServerTransID().getText());
				 */

				break;

			case "Cancelled":
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for Cancel
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='success mid-content'])[1]")));


				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code has been re-sent to your registered device.");
				 */

				otp.getOtpResendButton().click();
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='success mid-content'])[1]")));

				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "Maximum Attempts Exceeded. You may cancel the transaction.");
				 */

				System.out.println(otp.getResendOTPMessage().getText());
				System.out.println(MaxResendOTPMessage);

				sAssertion.assertTrue(otp.getResendOTPMessage().getText().contains(MaxResendOTPMessage));

				otp.getOtpCancelButton().click();
				
				//WebElement textEelement = driver.findElement(By.id("id_confrmdiv1"));
				WebElement yesElement = driver.findElement(By.id("id_truebtn1"));
				
				yesElement.click();
				
				//sAssertion.assertEquals(textEelement.getText(), "Are you sure you want to Cancel the transaction?");
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				/*
				 * // writing to 3DSS file GenericMethods.writingToExcel(XlFileName,
				 * ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				 * GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName,
				 * "ThreeDSTxnId", invocationCount,
				 * responsepage.getThreeDSServerTransID().getText());
				 */
				break;

			case "Failed":
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='submitBtn']")));

				/* Verifying images are displayed or not */
				//this.verifyImages(sAssertion);

				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);
					generic.explicitWait(2);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					// System.out.println("Cutomer Care page and Submit Button Displayed for Failed
					// Card");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}

				System.out.println("CardNotRegisteredText :: Failed");
				System.out.println(otp.getCardNotRegisteredText().getText());
				System.out.println(CardNotRegisteredText);

				
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CardNotRegisteredText));

				/*
				 * sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(
				 * "Dear Customer, Your contact details could are not available with the bank for online transactions."
				 * ), "Unregisterd card message validation");
				 */

				// Dear Customer, Your contact details are not available with the bank for
				// online transactions. Please visit your nearest branch to update your contact
				// details or please contact the bank customer care at +65 6950 1132.

				// "Dear Customer, Your contact details could are not available with the bank
				// for online transactions. Please visit your nearest branch to update your
				// contact details. For any queries, please contact the bank customer care at:
				// Phone:- 1234567890, Email:- customercare@bank.com");

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Failed the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				/*
				 * // writing to 3DSS file GenericMethods.writingToExcel(XlFileName,
				 * ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				 * GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName,
				 * "ThreeDSTxnId", invocationCount,
				 * responsepage.getThreeDSServerTransID().getText());
				 */
				break;

			case "OtpPage":
				/*
				 * Validation point: 1.Blank otp text 2.Less the 6 digit otp 3.Alphanumeric otp
				 * 4.Wibmo logo
				 */
				
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
				System.out.println("acsTxnId: " + acsTxnId);

				// Validating logos
				/*
				 * 
				 * String aWibmoLogo =
				 * "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/common/images/wibmo_logo.png";
				 * String aBankLogo =
				 * "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/participant/krntk/images/krntk_logo.jpg";
				 * String eWibmoLogo =
				 * driver.findElement(By.xpath("//img[@id='footerRightLogo']")).getAttribute(
				 * "src"); String eBankLogo =
				 * driver.findElement(By.xpath("//img[@id='leftLogo']")).getAttribute("src");
				 * System.out.println("eWibmoLogo:-" + eWibmoLogo);
				 * sAssertion.assertEquals(aWibmoLogo, eWibmoLogo);
				 * sAssertion.assertEquals(aBankLogo, eBankLogo);
				 */

				// TODO
				// validating blank otp
				otp.getOtpSubmitButton().click();
				generic.explicitWait(2);

				// Alert blankOtp = driver.switchTo().alert();
				// String aBlankOtpText = blankOtp.getText();
				System.out.println(otp.getErrorText().getText());
				System.out.println(OtpBlankMessage);
				sAssertion.assertEquals(otp.getErrorText().getText(), OtpBlankMessage);

				// blankOtp.accept();
				// TODO
				// validating less than 6 digit otp
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("345");
				otp.getOtpSubmitButton().click();
				generic.explicitWait(2);

				System.out.println(otp.getErrorText().getText());
				System.out.println(OtpLessthanMessage);

				// Alert lessThanSixOtpSubmit = driver.switchTo().alert();
				// String lessThanSixOtpText = lessThanSixOtpSubmit.getText();
				// lessThanSixOtpSubmit.accept();

				// validating less than 6 digit otp text
				sAssertion.assertEquals(otp.getErrorText().getText(), OtpLessthanMessage);

				// Entering alpha numeric
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("12h$X0");
				otp.getOtpSubmitButton().click();

				System.out.println(otp.getInvalidOTPMessage().getText());
				System.out.println(InvalidOTPMessage);

				// sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
				// InvalidOTPMessage);
				sAssertion.assertTrue(otp.getInvalidOTPMessage().getText().contains(InvalidOTPMessage));

				// Writing the real value from the response page.

				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Blocked":
				log.info("Testing blocked");
				generic.explicitWait(5);
				System.out.println("Title of the page : " + driver.getTitle());
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Submit')]")));

				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");

				System.out.println(otp.getCardNotRegisteredText().getText());
				System.out.println(CCPageText);

				// sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				// CCPageText);
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CCPageText));
				// "Dear Customer, Your transaction cannot be processed currently as your card
				// has been blocked for online transactions due to multiple invalid attempts.
				// Please try again after 24hours or contact your bank for assistance
				// immediately.");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));

					acsTxnId = this.getTransactionId(getHeaders, IssuerBankId);
					System.out.println("acsTxnId: " + acsTxnId);

					generic.explicitWait(2);
					try {
						otp.getCardNotRegisteredContinueButton().click();
					} catch (Exception e) {
						System.out.println("Handling unexpected popup");

						Alert alert = driver.switchTo().alert();
						System.out.println("Type of alert: " + alert.getText());
						alert.accept();
					}

					sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					/*
					 * // writing to 3DSS file GenericMethods.writingToExcel(XlFileName,
					 * ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
					 * GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName,
					 * "ThreeDSTxnId", invocationCount,
					 * responsepage.getThreeDSServerTransID().getText());
					 */

				} else {

					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getCardNotRegisteredContinueButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
					sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

					// Writing the real value from the response page.
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					// writing to 3DSS file
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());
				}
				break;

			}
		} catch (

		UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

	private String getTransactionId(GetHeaders getHeaders, String IssuerBankId) {
		generic.explicitWait(5);
		NetWorklogs = driver.manage().logs().get("performance");
		//System.out.println("NETWORK LOGS: " + NetWorklogs);
		String currentURL = driver.getCurrentUrl();
		//System.out.println("Current URL : " + currentURL);
		String acsTxnIdFromHeaders = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
		return acsTxnIdFromHeaders;
	}

	private void verifyImages(SoftAssert sAssertion) {
		try {
			invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			//System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {
					// String imgSRCUrl = imgElement.getAttribute("src");
					// int statuscode =generic.verifyimageActive(imgElement);
					HttpClient client = HttpClientBuilder.create().build();
					// HttpHost proxyhost = new HttpHost(proxyUrl);
					HttpGet request = new HttpGet(imgElement.getAttribute("src"));
					// HttpResponse response = client.execute(proxyhost, request);
					HttpResponse response = client.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						invalidImageCount++;
						//System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

					} else {
						System.out.println("image url: " + imgElement.getAttribute("src"));
					}
						
					int respCode = response.getStatusLine().getStatusCode();
					String resposeCode = respCode + "";
					sAssertion.assertEquals(resposeCode, "200");
				}
				//System.out.println("Total no. of invalid images are " + invalidImageCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}

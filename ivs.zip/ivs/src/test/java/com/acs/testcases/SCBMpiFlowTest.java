
package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.cassandra.thrift.Cassandra.system_add_column_family_args;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.utils.DBConnection;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.CardHolderDetailsPage;

public class SCBMpiFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1, enabled = true)
	public void mpiauthenticationTest(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage,
			String acsTxnId, String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String ResendOTPMessage, String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText,
			String CCPageText, String decs) throws Exception {
		
		System.out.println("***************** Test Started *****************");
		System.out.println("Flow "+ Flow);
		System.out.println("*************************************************");
		

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		// StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskSuggestion", invocationCount, "");

		//System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");

		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			//System.out.println("Clicked on Checkout button");

			// For Karnataka Bank
			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(5);
			}
			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			//System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			//System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			//System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr[] = tesdDecode.split("&");
			String testEncodedPaReq = arr[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);

			switch (Flow) {

			case "Challenge":
				log.info(Flow + "Started");

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
				// document.getElementByName('acctId').value").toString();

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					//System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								//System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				//System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				/*
				 * String Pares = vars.get("PaRes"); Pares = Pares.toString(); String finalPARes
				 * = RFC.decodeAndDecompress(Pares);
				 */
				// log.info("Decoded string is:" +finalPARes);
				// vars.put("finalPARES",finalPARes);
				// String Pareq=getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId,
				// NetWorklogs);
				// otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId,
				// acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * NetWorklogs = driver.manage().logs().get("performance");
				 * System.out.println("NETWORK LOGS: " + NetWorklogs); currentURL =
				 * driver.getCurrentUrl(); System.out.println("Current URL : " + currentURL);
				 * acsTxnId = getHeaders.getFormDataOfFinalPage(currentURL, NetWorklogs);
				 */
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				//System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				//System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				//System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;
			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				generic.explicitWait(3);
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}
				
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				System.out.println("OtpExpiry");
				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				System.out.println("Waiting for 3 min..." + OtpExpiryTime);
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));
				generic.explicitWait(5);
				System.out.println("Time Completed");
				otp.getOtpTextField().sendKeys(otpValue);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				//WebElement otpExpiry = driver.findElement(By.xpath("//p[@class='hei mid-content']"));
				System.out.println(otp.getCIBOtpExpire().getText());
				System.out.println(OtpExpiryMessage);
				sAssertion.assertEquals(otp.getCIBOtpExpire().getText(), OtpExpiryMessage);
				
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "BlockCard":
				log.info(Flow + "Started");

				System.out.println("acsTxnId:- " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
				WebElement invalidOtpText = driver.findElement(By.xpath("//p[@class='hei mid-content']"));
				sAssertion.assertEquals(invalidOtpText.getText(), InvalidOTPMessage);
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[text()='Continue' or text()='CONTINUE' or @id='submitBtn']")));
				System.out.println("Customer care page and submit button is displayed");

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String BOBCustPage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(BOBCustPage.contains(CCPageText));
						flag = true;
					}
				}

				if (flag = false) {
					System.out.println(otp.getCardNotRegisteredText().getText());
					System.out.println(CCPageText);
					
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CCPageText);
					System.out.println("Checkpoint--1");
				} else {
					System.out.println("Done..");
				}

				otp.getCardBlockedContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Cancelled":
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(35);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
				WebElement resendText = driver.findElement(By.xpath("//p[@class='hei mid-content']"));
				
				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='otp__send success']")));
				//WebElement resendText = driver.findElement(By.xpath("//p[@class='otp__send success']"));
				
				//sAssertion.assertEquals(resendText.getText(), ResendOTPMessage);
				System.out.println(resendText.getText());
				System.out.println(ResendOTPMessage);
				sAssertion.assertTrue(resendText.getText().contains(ResendOTPMessage));
				generic.explicitWait(35);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				
				generic.explicitWait(35);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
				WebElement MaxresendText = driver.findElement(By.xpath("//p[@class='hei mid-content']"));
				
				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@id='messagesPort']")));
				//WebElement MaxresendText = driver.findElement(By.xpath("//p[@id='messagesPort']"));
				System.out.println(MaxresendText.getText());
				System.out.println(MaxResendOTPMessage);
				sAssertion.assertTrue(MaxresendText.getText().contains(MaxResendOTPMessage),
						"Max resent message Verification");

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpCancelButton().click();
				} else {
					otp.getTmlotpCancelButton().click();
					generic.explicitWait(2);
					for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
						if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
							System.out.println("Handling Alert for Bank id -" + IssuerBankId);
							driver.switchTo().alert().accept();

						}
					}
				}

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Failed":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				WebElement cardNotReg = driver.findElement(By.xpath("//p[@class='hei mid-content']"));

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String CardNotRegMessage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(CardNotRegMessage.contains(CardNotRegisteredText), "Unregistered card");
						flag = true;
					}
				}
				
				if (flag = false) {
					// sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
					// CardNotRegisteredText);
					sAssertion.assertTrue(cardNotReg.getText().contains(CardNotRegisteredText),
							"Failed scenario validation");
					System.out.println("Failed Scenario");
				} else {
					System.out.println("Done..");
				}

				

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Blocked":
				log.info("Testing blocked");
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");

				WebElement AusfBank = driver.findElement(By.xpath("//div[@class='hei mid-content cust']"));
				
				System.out.println("ccPageText:- " + AusfBank.getText());
				System.out.println("ccPageText:- " + CCPageText);
				
				sAssertion.assertEquals(AusfBank.getText(), CCPageText);
				// sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				// CCPageText);
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);
				otp.getCardNotRegisteredContinueButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			case "OtpPage":
				/*
				 * Validation point: 1.Blank otp text 2.Less the 6 digit otp 3.Alphanumeric otp
				 * 4.Wibmo logo
				 */
				System.out.println("Otp page validation");
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[contains(@class,'submit_Automate') or @id='submitBtn']")));

				// Validating logo
				String aWibmoLogo = "https://s3.ap-south-1.amazonaws.com/in-mum-wibmo-acs/static/common/images/wbmo.png";
				String aBankLogo = "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/participant/scibk/images/scibk_logo.jpg";
				// String eWibmoLogo =
				// driver.findElement(By.xpath("//body/div[@id='container']/div[1]/div[2]/img[1]")).getAttribute("src");
				String eBankLogo = driver.findElement(By.xpath("//img[@id='renderImage']")).getAttribute("src");
				// System.out.println("eWibmoLogo:-" + eWibmoLogo);
				// sAssertion.assertEquals(aWibmoLogo, eWibmoLogo);
				sAssertion.assertEquals(aBankLogo, eBankLogo);

				// validating blank otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
					// validating blank otp text
					String eBlankSubmitText = "OtpValue cannot be blank";
					sAssertion.assertEquals(otp.getAusfBlankOtp().getText(), eBlankSubmitText, "Blank otp validation");

				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// validating less than 6 digit otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getOtpTextField().sendKeys("123");
					otp.getRkrotpSubmitButton().click();

				} else {
					otp.getOtpTextField().sendKeys("123");
					otp.getTmlotpSubmitButton().click();
					String eLessThanSixOtpText = "OTP you received cannot be less than 6 digits.";
					System.out.println("Ausf less 6 digit message:- " + otp.getAusfBlankOtp().getText());
					sAssertion.assertEquals(otp.getAusfBlankOtp().getText(), eLessThanSixOtpText);
					generic.explicitWait(2);

				}

				// Entering alpha numeric
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("12h$X0");
				otp.getRkrotpSubmitButton().click();
				String eAlphaNumText = "OTP you received cannot be less than 6 digits.";
				sAssertion.assertEquals(otp.getAusfBlankOtp().getText(), eAlphaNumText);
				
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				
				break;
				
				

			}

		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

	@DataProvider
	public Object[][] CaptureCustDetails() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateCard");
	}

	@Test(dataProvider = "CaptureCustDetails", priority = 2, enabled = true)
	public void CaptureCustDetails(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String TemplateType, String Flow, String merchantId, String amount,
			String MobileCode, String MobileNumber, String ProtocolVersion, String IssuerBin, String CardNumber,
			String Email_Id, String Desc) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		ExtentTestManager.getTest().setDescription(Desc);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);

		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

		// Creating card number

		long randomNumber = (long) (Math.random() * 100000 + 4533300000L);
		System.out.println("Random number : " + randomNumber);
		String createdCardNumber = IssuerBin + randomNumber;
		System.out.println("Card numbers is : " + createdCardNumber);

		System.out.println("Card Number : " + createdCardNumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(createdCardNumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
		checkoutpage.getSubmitButton().click();
		generic.explicitWait(8);
		System.out.println("Clicked on Checkout button");
		otp.getCardNotRegisteredContinueButton().click();

		String last4digitCard = createdCardNumber.substring(12, 16);
		// Validating entry in DB

		String dbEntry = DBConnection
				.getValueFromDB("SELECT count(*) FROM ausfb_8527_acs2_cust.card_data where account_identifier='"
						+ last4digitCard + "'");
		sAssertion.assertEquals(dbEntry, "1");
		// Login in Admin portal
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

		ExtentTestManager.getTest().setDescription(Desc);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		cardHolderDetailsPage.getManageCardHolderDetailsLink().click();

		// Fetch Customer details by Card
		cardHolderDetailsPage.getCardNumberTextfield().sendKeys(createdCardNumber);
		cardHolderDetailsPage.getSearchButton().click();
		generic.explicitWait(3);

		String expectedCard = createdCardNumber.substring(createdCardNumber.length() - 4);
		System.out.println("expectedCard :" + expectedCard);
		// Click on edit
		driver.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
				+ "')]/following::div[@class='flex-table__cell column md']/div/div")).click();

		// Update MobileCode and Mobile Number
		cardHolderDetailsPage.getMobileCodeDropdown().click();
		cardHolderDetailsPage.getMobileCodeSearchField().sendKeys(MobileCode);
		cardHolderDetailsPage.getFirstMobileCodelist().click();

		cardHolderDetailsPage.getEditMobileTextfield().clear();
		cardHolderDetailsPage.getEditMobileTextfield().sendKeys(MobileNumber);

		// Update Email
		cardHolderDetailsPage.getEditEmailTextfield().clear();
		cardHolderDetailsPage.getEditEmailTextfield().sendKeys(Email_Id);

		// Click on Save
		cardHolderDetailsPage.getSaveChangesButton().click();

		// waiting 3 min to cache reload
		generic.explicitWait(190);

		// Perform a successful transaction from MPI Simulator
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		String currentURL = null;
		invocationCount++;

		System.out.println("Card Number : " + createdCardNumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(createdCardNumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");

		// putting try catch block to handle pop-up
		try {
			checkoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			System.out.println("Clicked on Checkout button");

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr[] = tesdDecode.split("&");
			String testEncodedPaReq = arr[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);

			switch (Flow) {

			case "Challenge":
				log.info(Flow + "Started");

				generic.explicitWait(2);

				otpValue = OTPFromEngine.getOTPFromEngine(createdCardNumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getTmlotpSubmitButton().click();
				generic.explicitWait(2);

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				break;
			}
			// For deleting entry from DB
			/*
			 * String deleteDbEntry = DBConnection.
			 * getValueFromDB("SELECT count(*) FROM ausfb_8527_acs2_cust.card_data where account_identifier='"
			 * +last4digitCard+"'"); sAssertion.assertEquals(dbEntry, "0");
			 */
		} catch (Exception e) {
			System.out.println("Exception e: " + e);
		}
		sAssertion.assertAll();

	}

}

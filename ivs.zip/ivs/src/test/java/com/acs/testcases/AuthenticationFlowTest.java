package com.acs.testcases;

import java.awt.AWTException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.pages.MultiSelectPage;
import com.acs.pages.OTPPage;
import com.acs.pages.PgResponsePage;
import com.acs.pages.SingleSelectPage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.EncryptAndDecrypt;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.appium.android.ReadOTP;
import com.google.gson.JsonObject;

import io.appium.java_client.AppiumDriver;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.CardEncryptHomePage;
import com.acs.pages.CheckOutPage;

public class AuthenticationFlowTest extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;
	String acsTxnIdFromHeaders;
	String cavvOrAvv;
	String threeDsTransactionId;
	LogEntries NetWorklogs;
	private int invalidImageCount;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		System.out.println(Config.BASE_TRANSACTION_URL);
		driver.get(Config.BASE_TRANSACTION_URL);
		generic.explicitWait(5);
		System.out.println("Title of the page : " + driver.getTitle());
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println(XlFileName);
		System.out.println(Txn2_0SheetName);
		return generic.getData(XlFileName, Txn2_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String MerchantName,
			String TransactionAmount, String CurrencyType, String CardUnionType, String AcsTxnId, String CavvOrAvv,
			String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage, String ResendOTPMessage,
			String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText, String CCPageText,
			String TestCaseDiscription) throws Exception {

		System.out.println("****** Test Started ********");
		ExtentTestManager.getTest().setDescription(TestCaseDiscription);
		SoftAssert sAssertion = new SoftAssert();
		// initialising the page objects
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		PgResponsePage responsepage = new PgResponsePage(driver);
		OTPPage otp = new OTPPage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		SingleSelectPage single = new SingleSelectPage(driver);
		MultiSelectPage multi = new MultiSelectPage(driver);
		CardEncryptHomePage enNDcryptPage = new CardEncryptHomePage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		ReadOTP otpFromMobile = new ReadOTP(driver);
		String mySMS = null;
		String currentURL = null;
		acsTxnIdFromHeaders = null;
		cavvOrAvv = null;
		threeDsTransactionId = null;

		// Clear the excel
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		checkoutpage.getAddToCartButton().click();
		generic.explicitWait(2);
		// System.out.println("Clicked on Add To Cart button");
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(MerchantName);

		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(CurrencyType);

		// generic.explicitWait(3);

		checkoutpage.getCheckOutButton().click();
		generic.explicitWait(5);
		// System.out.println("Clicked on Checkout button");
		System.out.println("Flow: " + Flow);

		switch (Flow) {

		case "FrictionLess":

			log.info(Flow + "Started");
			// acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			// System.out.println("acsTxnIdFromHeaders: "+acsTxnIdFromHeaders);
			break;

		case "Static":

			driver.switchTo().frame("foo");
			generic.explicitWait(3);
			staticpaw.getStaticPasswordField().sendKeys(Config.STATIC_PASSWORD);
			// generic.explicitWait(3);
			staticpaw.getStaticPasswordSubmitButton().click();
			// generic.explicitWait(5);
			break;

		case "Challenge":

			log.info(Flow + "Started");

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			generic.explicitWait(5);
			driver.switchTo().frame("foo");

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			/*
			 * mySMS =
			 * aDriver.findElement(By.id("net.everythingandroid.smspopup:id/messageTextView"
			 * )).getText(); String otpValue = otpFromMobile.readOTPinSMS(mySMS);
			 */
			// Reading SMS from the POPUP Appp

			// To connect to mobile and read otp pleas use below code.
			// otpFromMobile.launchAppium();
			// String otpValue1=otpFromMobile.readOTP();

			/*
			 * If otp need to take from DB and decrypt and submit use below code.
			 * log.info("Switched to frame"); String enCryptedOTP =
			 * generic.getencyrptedOTPFromDB(); String dcryptedjson = null; String
			 * dcryptedOTPValue = null; log.info("Encrypted OTP Value is :" + enCryptedOTP);
			 * // driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"n");
			 * generic.openNewWindow(); //
			 * driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"n");
			 * log.info("Opned a new window"); generic.explicitWait(1);
			 * 
			 * Set<String> ids = driver.getWindowHandles(); Iterator<String> it =
			 * ids.iterator(); String currentWindow = it.next(); String newWindow =
			 * it.next(); driver.switchTo().window(newWindow); //
			 * driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, //
			 * Keys.PAGE_DOWN); log.info("Switched to new Window");
			 * log.info("Encryption file path is : " + Config.BASE_CARD_ENCRYPT_PATH);
			 * driver.get("file:///" + Config.BASE_CARD_ENCRYPT_PATH);
			 * log.info("opened the card encryption page");
			 * enNDcryptPage.getEnNDcryptTextField().clear(); log.info("cleared");
			 * enNDcryptPage.getEnNDcryptTextField().sendKeys(enCryptedOTP);
			 * log.info("enterred"); enNDcryptPage.getBankIdTextField().clear();
			 * enNDcryptPage.getBankIdTextField().sendKeys(Config.ISSUER_BANK_ID);
			 * enNDcryptPage.getSelectDrpDwon().click(); log.info("dropdownClicked"); Select
			 * options = new Select(enNDcryptPage.getSelectDrpDwon()); //
			 * options.selectByValue("decrypt"); options.selectByIndex(1);
			 * log.info("dropdown selected");
			 * 
			 * enNDcryptPage.getSubmitButton().click(); dcryptedjson =
			 * enNDcryptPage.getEnOrDcryptResult().getText(); //
			 * driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, //
			 * Keys.PAGE_DOWN); driver.close(); // driver.switchTo().defaultContent();
			 * log.info("dcrypted OTP Value: " + dcryptedjson);
			 * 
			 * JSONObject obj = new JSONObject(dcryptedjson); dcryptedOTPValue = (String)
			 * obj.get("Result");
			 * 
			 * log.info("dcryptedOTPValue:" + dcryptedOTPValue);
			 * 
			 * // Switch back to original browser (first window)
			 * driver.switchTo().window(currentWindow); driver.switchTo().frame("foo");
			 * 
			 * 
			 */

			String otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromHeaders);
			otp.getOtpField().sendKeys(otpValue);
			generic.explicitWait(1);
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}

			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// acsTxnIdFromHeaders);
			// aDriver.findElement(By.id("net.everythingandroid.smspopup:id/button1")).click();

			break;

		case "Single":

			driver.switchTo().frame("foo");
			generic.explicitWait(3);

			single.getEmailRadioButton().click();
			// single.getMobileRadioButton().click();

			single.getNextButton().click();

			// generic.explicitWait(5);

			break;

		case "Multi":

			driver.switchTo().frame("foo");

			multi.getBangaloreCheckBox().click();
			multi.getPuneCheckBox().click();

			/*
			 * multi.getAndraCheckBox().click(); multi.getChennaiCheckBox().click();
			 * multi.getDalaCheckBox().click(); multi.getDelhiCheckBox().click();
			 * multi.getMysoreCheckBox().click(); multi.getPuneCheckBox().click();
			 */
			// generic.explicitWait(3);
			multi.getNextButton().click();

			break;

		case "OTPCloseBrowser":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			driver.switchTo().frame("foo");
			break;

		case "OTPExpiry":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromHeaders);
			// System.out.println(otpValue);

			generic.explicitWait(Integer.parseInt(OtpExpiryTime));
			System.out.println("Time completed");
			generic.explicitWait(20);
			System.out.println("Time completed");
			driver.switchTo().frame("foo");

			otp.getOtpField().sendKeys(otpValue);

			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}

			System.out.println("Clicked otp Button");

			generic.explicitWait(2);
			break;

		case "Blocked":

			log.info("Testing blocked");

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			driver.switchTo().frame("foo");
			sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CCPageText);

			// "Dear Customer, Your transaction cannot be processed currently as your card
			// has been blocked for online transactions due to multiple invalid attempts.
			// Please try again after 24hours or contact your bank for assistance
			// immediately.");
			// "Dear Customer, Your transaction cannot be processed currently as your card
			// has been blocked for online transactions due to multiple invalid OTP attemps.
			// Please try again after 24 hours or contact your bank at +021-111-124-444 for
			// assistance immediately.");
			otp.getContinueBtn().click();
			generic.explicitWait(2);
			break;

		case "BlockCard":
			log.info(Flow + "Started");

			/* Verifying images are displayed or not */
			verifyImages(sAssertion);
			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			driver.switchTo().frame("foo");
			/*
			 * wait.until(ExpectedConditions
			 * .visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
			 */

			generic.explicitWait(2);
			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			System.out.println(otp.getCardNotRegisteredText().getText());
			System.out.println(InvalidOTPMessage);

			sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), InvalidOTPMessage);
			// "The OTP code you entered is incorrect please try again.");

			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);

			if (IssuerBankId.contentEquals("")) {
				otp.getOtpField().sendKeys("123456");
				otp.getSBICSubmitBtn().click();
				generic.explicitWait(2);

				otp.getOtpField().sendKeys("123456");
				otp.getSBICSubmitBtn().click();
				generic.explicitWait(2);
			}

			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// acsTxnIdFromHeaders);
			// aDriver.findElement(By.id("net.everythingandroid.smspopup:id/button1")).click();
			break;

		case "Cancelled":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			driver.switchTo().frame("foo");
			generic.explicitWait(2);
			otp.getOtpCancelButton().click();
			log.info("Canceled the Transaction");
			// generic.writingACSTxnIDToExcell("CardDetails", "AcsTxnId", invocationCount,
			// acsTxnIdFromHeaders);
			// aDriver.findElement(By.id("net.everythingandroid.smspopup:id/button1")).click();
			break;

		case "Failed":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			if (IssuerBankId.contentEquals("8111") && IssuerBankId.contentEquals("8198")) {
				System.out.println("Donothing");
			} else {
				driver.switchTo().frame("foo");
			}

			if (IssuerBankId.contentEquals("8198")) {
				System.out.println("Donothing");
			} else {
				System.out.println(otp.getCardNotRegisteredText().getText());
				System.out.println(CardNotRegisteredText);

				sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);

				// "Dear Customer, Your contact details could are not available with the bank
				// for online transactions. Please visit your nearest branch to update your
				// contact details. For any queries, please contact the bank customer care at:
				// Phone:- 1234567890, Email:- customercare@bank.com");
				// "Dear Customer, Your contact details are not available with the bank for
				// online transactions. Please visit your nearest branch to update your contact
				// details or please contact the bank customer care at +021-111-124-444.");
				otp.getContinueBtn().click();
			}

			break;

		case "Resend":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			driver.switchTo().frame("foo");
			otp.getOtpResendButton().click();
			generic.explicitWait(2);
			otp.getOtpResendButton().click();
			generic.explicitWait(2);
			otp.getOtpResendButton().click();
			generic.explicitWait(2);

			if (IssuerBankId.contentEquals("8198")) {
				otp.getOtpResendButton().click();
				generic.explicitWait(2);
				otp.getOtpResendButton().click();
				generic.explicitWait(2);
			} else {
				// String maxAttemptText = "Maximum Attempts Exceeded. You may cancel the
				// transaction.";
				sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), MaxResendOTPMessage);
				generic.explicitWait(2);
			}

			otp.getOtpCancelButton().click();
			break;

		case "OtpPage":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);
			driver.switchTo().frame("foo");

			// Validate empty otp
			otp.getOtpField().clear();
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			String errorText = "Please enter the OTP.";
			sAssertion.assertEquals(otp.getErrorText().getText(), errorText);

			// validating less than 6 digit otp
			otp.getOtpField().clear();
			otp.getOtpField().sendKeys("345");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			errorText = "OTP you received cannot be less than 6 digits.";
			sAssertion.assertEquals(otp.getErrorText().getText(), errorText);

			// Validate with in correct code
			otp.getOtpField().clear();
			otp.getOtpField().sendKeys("123456");
			if (IssuerBankId.contentEquals("8198")) {
				otp.getSBICSubmitBtn().click();
			} else {
				otp.getOtpSubmitButton().click();
			}
			generic.explicitWait(2);
			// errorText = "The OTP code you entered is incorrect please try again.";
			sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), InvalidOTPMessage);
			break;

		case "PageExpiry":

			/* Verifying images are displayed or not */
			this.verifyImages(sAssertion);

			acsTxnIdFromHeaders = this.getTransactionId(getHeaders, IssuerBankId);
			System.out.println("acsTxnIdFromHeaders: " + acsTxnIdFromHeaders);

			generic.explicitWait(Integer.parseInt(PageExpiryTime));
			generic.explicitWait(5);
			// generic.explicitWait(425);
			driver.switchTo().frame("foo");
			break;

		}

		if (Flow.equalsIgnoreCase("Frictionless")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			} else {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
			}
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Frictionless");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		} else if (Flow.equalsIgnoreCase("OTPCloseBrowser") || Flow.equalsIgnoreCase("OtpPage")) {
			log.info("Browser Closed");
			System.out.println("Browser Closed");
		} else if (Flow.equalsIgnoreCase("OTPExpiry")) {

			sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), OtpExpiryMessage);
			// "OTP expired, please click resend button to generate OTP");

		} else if (Flow.equalsIgnoreCase("Blocked")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			} else {

				sAssertion.assertEquals(responsepage.getEciValue().getText(), "");
			}
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

			// generic.AdminUnBlockCard(EncryptAndDecrypt.EncryptnDecryptData(Cardnumber,
			// "N", IssuerBankId), IssuerBankId);
			// generic.updateCardStatusToActive(EncryptAndDecrypt.EncryptnDecryptData(Cardnumber,
			// "N"));
			/*
			 * String encryptedjson = null;
			 * 
			 * generic.openNewWindow(); generic.explicitWait(1);
			 * 
			 * Set<String> ids = driver.getWindowHandles(); Iterator<String> it =
			 * ids.iterator(); String currentWindow = it.next(); String newWindow =
			 * it.next(); driver.switchTo().window(newWindow); driver.get("file:///" +
			 * Config.BASE_CARD_ENCRYPT_PATH);
			 * 
			 * enNDcryptPage.getEnNDcryptTextField().clear();
			 * enNDcryptPage.getEnNDcryptTextField().sendKeys(Cardnumber);
			 * enNDcryptPage.getBankIdTextField().clear();
			 * enNDcryptPage.getBankIdTextField().sendKeys(Config.ISSUER_BANK_ID);
			 * 
			 * enNDcryptPage.getSelectDrpDwon().click();
			 * 
			 * Select options = new Select(enNDcryptPage.getSelectDrpDwon()); //
			 * options.selectByValue("decrypt"); options.selectByIndex(0);
			 * enNDcryptPage.getSubmitButton().click(); encryptedjson =
			 * enNDcryptPage.getEnOrDcryptResult().getText();
			 * 
			 * JSONObject obj = new JSONObject(encryptedjson); String encryptedCardNumber =
			 * (String) obj.get("Result "); log.info("Encrypted CardNumber: " +
			 * encryptedCardNumber);
			 * 
			 * // change the card status to active
			 * 
			 * generic.updateCardStatusToActive(encryptedCardNumber); //
			 * generic.explicitWait(8); driver.close();
			 * driver.switchTo().window(currentWindow);
			 */

		} else if (Flow.equalsIgnoreCase("Cancelled") || Flow.equalsIgnoreCase("BlockCard")
				|| Flow.equalsIgnoreCase("Failed") || Flow.equalsIgnoreCase("PageExpiry")
				|| Flow.equalsIgnoreCase("Resend")) {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "07");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		} else {

			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			} else {
				sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
			}
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getRreqStatusValue().getText(), "Y");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			cavvOrAvv = responsepage.getCavvValue().getText();
			// threeDsTransactionId = responsepage.getThreeDSServerTransID().getText();

		}
		this.writeRequiredFieldsToExcel();
		log.info(Flow + " Completed");
		sAssertion.assertAll();
		invocationCount++;

	}

	private void writeRequiredFieldsToExcel() {

		// Writing the real value from the response page.

		// AcsTxnId
		if (acsTxnIdFromHeaders != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
					acsTxnIdFromHeaders);
		}

		// CavvOrAvv
		if (cavvOrAvv != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, cavvOrAvv);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, cavvOrAvv);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
					cavvOrAvv);
		}

		// ThreeDSTxnId
		if (threeDsTransactionId != null) {
			GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
			GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
					threeDsTransactionId);
		}
	}

	private String getTransactionId(GetHeaders getHeaders, String IssuerBankId) {
		generic.explicitWait(5);
		NetWorklogs = driver.manage().logs().get("performance");
		// System.out.println("NETWORK LOGS: " + NetWorklogs);
		String currentURL = driver.getCurrentUrl();
		// System.out.println("Current URL : " + currentURL);
		String acsTxnIdFromHeaders = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
		return acsTxnIdFromHeaders;
	}

	private void verifyImages(SoftAssert sAssertion) {
		try {
			invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {
					// String imgSRCUrl = imgElement.getAttribute("src");
					// int statuscode =generic.verifyimageActive(imgElement);
					HttpClient client = HttpClientBuilder.create().build();
					// HttpHost proxyhost = new HttpHost(proxyUrl);
					HttpGet request = new HttpGet(imgElement.getAttribute("src"));
					// HttpResponse response = client.execute(proxyhost, request);
					HttpResponse response = client.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						invalidImageCount++;
						System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

					} else
						System.out.println("image url: " + imgElement.getAttribute("src"));
					int respCode = response.getStatusLine().getStatusCode();
					String resposeCode = respCode + "";
					sAssertion.assertEquals(resposeCode, "200");
				}
				System.out.println("Total no. of invalid images are " + invalidImageCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}


package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPLanguagePage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class CIBMpiFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void mpiauthenticationTest(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage,
			String acsTxnId, String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String ResendOTPMessage, String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText,
			String CCPageText, String decs) throws Exception {

		/*
		 * String[] s1=decs.split(":"); for(String s2:s1) {
		 * ExtentTestManager.getTest().setDescription(s2); }
		 */

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskSuggestion", invocationCount, "");

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(5);
			System.out.println("Clicked on Checkout button");

			// For Karnatak Bank
			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(8);
			}
			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */
			if (Flow.equalsIgnoreCase("InActiveBin")) {
				System.out.println("Skipping the Pareq");
			} else {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
			}

			if (String.valueOf(otp.getEnglishLangNBEbank().isDisplayed()).equalsIgnoreCase("true")) {
				// Change UI in English
				otp.getEnglishLangNBEbank().click();
			}

			switch (Flow) {

			case "Static":

				generic.explicitWait(3);
				staticpaw.getStaticPasswordField().sendKeys(Config.STATIC_PASSWORD);
				// generic.explicitWait(3);
				staticpaw.getStaticPasswordSubmitButton().click();

				// generic.explicitWait(5);

				break;

			case "Challenge":
				log.info(Flow + "Started");

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
				// document.getElementByName('acctId').value").toString();

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				/*
				 * String Pares = vars.get("PaRes"); Pares = Pares.toString(); String finalPARes
				 * = RFC.decodeAndDecompress(Pares);
				 */
				// log.info("Decoded string is:" +finalPARes);
				// vars.put("finalPARES",finalPARes);
				// String Pareq=getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId,
				// NetWorklogs);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * NetWorklogs = driver.manage().logs().get("performance");
				 * System.out.println("NETWORK LOGS: " + NetWorklogs); currentURL =
				 * driver.getCurrentUrl(); System.out.println("Current URL : " + currentURL);
				 * acsTxnId = getHeaders.getFormDataOfFinalPage(currentURL, NetWorklogs);
				 */
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "Resend":
				log.info(Flow + "Started");

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
				// document.getElementByName('acctId').value").toString();
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getTmlotpResendButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content challengeInfoText' or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code has been re-sent to your registered device.");

				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;
			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				generic.explicitWait(3);
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}
				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			case "OTPExpiry":
				log.info(Flow + "Started");
				System.out.println("OtpExpiry");
				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				System.out.println("Waiting for 3 min..." + OtpExpiryTime);
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));

				generic.explicitWait(5);
				otp.getOtpTextField().sendKeys(otpValue);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code you entered is incorrect please try again.");
				 */
				sAssertion.assertEquals(otp.getCIBOtpExpire().getText(), OtpExpiryMessage);
				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "BlockCard":
				log.info(Flow + "Started");
				System.out.println("acsTxnId:- " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content challengeInfoText' or @class='text_left'or@class='mid-content'or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				/*
				 * sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
				 * "The code you entered is incorrect please try again.");
				 */
				sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(), InvalidOTPMessage);
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[text()='Continue' or text()='CONTINUE' or text()='Close']")));
				System.out.println("Customer care page and submit button is displayed");
				/*
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * "Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately."
				 * );
				 */

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String BOBCustPage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(BOBCustPage.contains(CCPageText));
						flag = true;
					}
				}

				if (flag = false) {
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CCPageText);
					System.out.println("Checkpoint--1");
				} else {
					System.out.println("Done..");
				}

				otp.getCardBlockedContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Canceled":
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				otp.getTmlotpResendButton().click();
				generic.explicitWait(2);

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[contains(@class,'reSendOtp_Automate') or contains(@href,'resend_otp')or @class='sub_line'or @ id='otpResend' or @id='reSend'])[1]")));
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code has been re-sent to your registered device.");
				 */
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), ResendOTPMessage);

				otp.getTmlotpResendButton().click();
				generic.explicitWait(2);

				otp.getTmlotpResendButton().click();
				generic.explicitWait(2);

				otp.getTmlotpResendButton().click();
				generic.explicitWait(2);

				otp.getTmlotpResendButton().click();
				generic.explicitWait(2);

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[contains(@class,'reSendOtp_Automate') or contains(@href,'resend_otp')or @class='sub_line'or @ id='otpResend' or @id='reSend'])[1]")));

				// sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				// MaxResendOTPMessage);
				sAssertion.assertFalse(otp.getTmlotpResendButton().isDisplayed(), "Verifying Disabled Resend button");

				otp.getTmlotpCancelButton().click();
				// driver.findElement(By.xpath("//button[@class='alert__btn
				// alert__btn__ok']")).click();
				Alert cancelAlert = driver.switchTo().alert();
				cancelAlert.accept();

				/*
				 * if (TemplateType.equalsIgnoreCase("Rocker")) {
				 * otp.getRkrotpCancelButton().click(); } else {
				 * otp.getTmlotpCancelButton().click(); generic.explicitWait(2); for (int i = 0;
				 * i < Config.bankIdAlertPopup.length; i++) { if
				 * (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
				 * System.out.println("Handling Alert for Bank id -" + IssuerBankId);
				 * driver.switchTo().alert().accept();
				 * 
				 * } } }
				 */

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Failed":
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[text()='Continue' or text()='CONTINUE' or text()='Close']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				/*
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * "Dear Customer, Your contact details could are not available with the bank for online transactions. Please visit your nearest branch to update your contact details. For any queries, please contact the bank customer care at: Phone:- 1234567890, Email:- customercare@bank.com"
				 * );
				 */
				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String CardNotRegMessage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(CardNotRegMessage.contains(CardNotRegisteredText));
						flag = true;
					}
					if (flag = false) {
						sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);
						System.out.println("Failed Scenario");
					} else {
						System.out.println("Done..");
					}

				}

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Blocked":
				log.info("Testing blocked");
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[text()='Continue' or text()='CONTINUE' or text()='Close']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");
				/*
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * "Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately."
				 * );
				 */
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CCPageText),
						"Blocked card verification");
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);
				otp.getCardNotRegisteredContinueButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "OtpPage":
				/*
				 * Validation point: 1.Blank otp text 2.Less the 6 digit otp 3.Alphanumeric otp
				 * 4.Wibmo logo. 5Bank logos
				 */
				System.out.println("Otp page validation");
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//*[contains(@class,'submit_Automate') or @id='submitBtn']")));

				// Validating Islami bank logos
				// String aWibmoLogo =
				// "https://s3.ap-south-1.amazonaws.com/in-mum-wibmo-acs/static/common/images/wbmo.png";
				String aBankLogo = "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/participant/cibbk/images/cibbk_logo.jpg";
				// String eWibmoLogo =
				// driver.findElement(By.xpath("//body/div[2]/img[1]")).getAttribute("src");
				String eBankLogo = driver.findElement(By.xpath("//img[@id='renderImage']")).getAttribute("src");
				// System.out.println("eWibmoLogo:-" + eWibmoLogo);
				// sAssertion.assertEquals(aWibmoLogo, eWibmoLogo);
				sAssertion.assertEquals(aBankLogo, eBankLogo);

				// Validating page timeout text
				/*
				 * WebElement pageTimeout =
				 * driver.findElement(By.xpath("//*[contains(text(),'automatically ')]"));
				 * boolean pageTimeoutDisplayed = pageTimeout.isDisplayed();
				 * 
				 * sAssertion.assertEquals(Boolean.toString(pageTimeoutDisplayed), "true");
				 */

				// validating blank otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpCIBSubmitButton().click();
				}
				generic.explicitWait(2);

				System.out.println("Handling Alert for Bank id -" + IssuerBankId);
				String eBlankSubmitText = "The OTP you have entered is invalid. Please enter the correct OTP sent to your registered mobile number";

				String blankSubmitText = otp.getNBEblankOtptext().getText();

				// validating blank otp text
				sAssertion.assertEquals(blankSubmitText, eBlankSubmitText);

				// validating less than 6 digit otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getOtpTextField().sendKeys("12345");
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getOtpTextField().sendKeys("12345");
					otp.getTmlotpCIBSubmitButton().click();
					generic.explicitWait(2);
				}
				System.out.println("Handling Alert for Bank id -" + IssuerBankId);
				String eLessThanSixOtpText = "The OTP you have entered is invalid. Please enter the correct OTP sent to your registered mobile number";

				String lessThanSixOtpText = otp.getNBEblankOtptext().getText();

				// validating less than 6 digit otp text
				sAssertion.assertEquals(lessThanSixOtpText, eLessThanSixOtpText);

				// Entering alpha numeric
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("12h$X0");
				otp.getTmlotpCIBSubmitButton().click();
				String eAlphaNumText = "The OTP you have entered is invalid. Please enter the correct OTP sent to your registered mobile number";
				sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(), eAlphaNumText);
				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Invalid":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Invalid Card");

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String CardNotRegMessage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(CardNotRegMessage.contains(CardNotRegisteredText));
						flag = true;
					}
					if (flag = false) {
						sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);
						System.out.println("Failed Scenario");
					} else {
						System.out.println("Done..");
					}

				}

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "InActiveBin":
				System.out.println("InActive Bin");
				generic.explicitWait(3);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");
				/*
				 * sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().
				 * contains("PARes Status: N"), "Pares Status");
				 */
				sAssertion.assertTrue(
						responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: null"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");
				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "otpCloseBrowser":

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "InvalidCard":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");
				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String CardNotRegMessage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(CardNotRegMessage.contains(CardNotRegisteredText));
						flag = true;
					}
					if (flag = false) {
						sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);
						System.out.println("Failed Scenario");
					} else {
						System.out.println("Done..");
					}
				}

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");
				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			}

		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}
	

	@DataProvider
	public Object[][] LanguageDataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, "Language");
	}

	@Test(dataProvider = "LanguageDataSet", invocationCount = 1)
	public void customerLanguageSelectionVerification(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String EncryptedCardNumber, String ProtocalVersion, String Flow, String TxnType, String merchantId,
			String merchantname, String amount, String CardUnionType, String LannguagePref, String ChallengeInfoText,
			String acsTxnId, String CavvOrAvv, String SchemaName, String decs) throws Exception {

		/*
		 * String[] s1=decs.split(":"); for(String s2:s1) {
		 * ExtentTestManager.getTest().setDescription(s2); }
		 */

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
//		MPIOTPPage otp = new MPIOTPPage(driver);
		MPIOTPLanguagePage langPage = new MPIOTPLanguagePage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

		// WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "Language", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "Language", "CavvOrAvv", invocationCount, "");

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(5);
			System.out.println("Clicked on Checkout button");
		//	acsTxnId = langPage.getAcsTxnIdElement().getAttribute("value");

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			*/ 
			if (Flow.equalsIgnoreCase("InActiveBin")) {
				System.out.println("Skipping the Pareq");
			} else {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
			}

			switch (Flow) {

			case "Challenge":
				log.info(Flow + "Started");
				generic.explicitWait(2);
				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				for (int i = 1; i < 7; i++) {
					String[] otpVal = otpValue.split("");

					driver.findElement(By.xpath("(//div/input[@class='otp__error'])[" + i + "]"))
							.sendKeys(otpVal[i - 1]);
				}
				generic.explicitWait(1);
				
				Select dropdwon = new Select(driver.findElement(By.id("langSwtich")));
				System.out.println("Selected Language : "+dropdwon.getFirstSelectedOption().getText());
				
				if (dropdwon.getFirstSelectedOption().getText().equalsIgnoreCase(LannguagePref)) {
					System.out.println("PreferedLanguage already got selected");
				
				} else {
					langPage.getLanguageDropDown().click();
					dropdwon.selectByValue(LannguagePref);
					
				}
				generic.explicitWait(2);
				System.out.println("Preffered language is : "+LannguagePref);
				if(LannguagePref.equalsIgnoreCase("english")) {
					langPage.getOtpEnglishSubmitButton().click();
					System.out.println("Clicked on English SubmitButton");
				} else {
					langPage.getOtpArabicSubmitButton().click();
					System.out.println("Clicked on Arabic SubmitButton");
					generic.explicitWait(2);
				}

				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);
				
				sAssertion.assertEquals(GenericMethods.getLanguagePreferencFromDB(SchemaName, EncryptedCardNumber), LannguagePref);

				GenericMethods.writingToExcel(XlFileName, "Language", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "Language", "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			}

		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.dismiss();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

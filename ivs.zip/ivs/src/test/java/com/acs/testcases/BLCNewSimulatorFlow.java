
package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.RFC;

public class BLCNewSimulatorFlow extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, Txn2_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String acsTxnId, String ThreeDSTxnId,
			String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion, String decs)
			throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		NewSimulatorCheckOutPage checkoutpage = new NewSimulatorCheckOutPage(driver);
		NewSimulatorResponsePage responsepage = new NewSimulatorResponsePage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
// 		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "RiskSuggestion", invocationCount, "");
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");

		System.out.println("Merchant Name : " + merchantname);
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(merchantname);

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		System.out.println("Amout : " + amount);
		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		System.out.println("Currency : " + currencytype);
		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(currencytype);

		System.out.println("Acquirer Bank Id : " + AccquirerBankId);
		checkoutpage.getAcquirerIDField().clear();
		checkoutpage.getAcquirerIDField().sendKeys(AccquirerBankId);
		System.out.println("Protocal Version : " + ProtocalVersion);

		// putting try catch block to handle pop-up
		try {
			String versionCheckUrl = checkoutpage.getVersionCheckURLFeild().getAttribute("value");
			System.out.println("Version check url from simulator : " + versionCheckUrl);
			String arr[] = versionCheckUrl.split("pVrq/");
			System.out.println("Splitter version Check url is : " + arr[0]);
			String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
			System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
			checkoutpage.getVersionCheckURLFeild().clear();
			checkoutpage.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
			checkoutpage.getSubmitButton().click();

			System.out.println("Clicked on Checkout button");

			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Submit paReq']")));
				checkoutpage.getSubmitPaReqButton().click();
				System.out.println("Clicked on PaReq button");

			}

			switch (Flow) {

			case "FrictionLess":
				log.info(Flow + "Started");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"));
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"));
				}

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						responsepage.getAcsTransID().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;

			case "Challenge":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				System.out.println("otpValue:-" + otpValue);
				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"));
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"));
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				break;

			case "Resend":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {
					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpResendButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code has been re-sent to your registered device.");

				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("A"));
				} else {
					sAssertion.assertEquals(responsepage.getEciValue().getText(), "02");
					sAssertion.assertTrue(responsepage.getCAVVValue().getText().startsWith("j"));
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getCAVVValue().getText());
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {
					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				generic.explicitWait(240);
				otp.getOtpTextField().sendKeys(otpValue);
				otp.getOtpSubmitButton().click();
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code you entered is incorrect please try again.");
				generic.explicitWait(301);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;
				
			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				generic.explicitWait(300);
				generic.explicitWait(3);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
	
				break;

			case "BlockCard":
				log.info(Flow + "Started");
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for BlockCard Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
					sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
							"The code you entered is incorrect, try again.");
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for BlockCard
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
					sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
							"The code you entered is incorrect please try again.");
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					System.out.println("Customer care page and submit button is displayed");
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
							"Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately.");

					otp.getCardBlockedContinueButton().click();
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				break;

			case "Canceled":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for Cancel
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code has been re-sent to your registered device.");
				otp.getOtpResendButton().click();
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), "Maximum Attempts Exceeded. You may cancel the transaction.");
				otp.getOtpCancelButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				break;

			case "Failed":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					// System.out.println("Cutomer Care page and Submit Button Displayed for Failed
					// Card");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}

				sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
						"Dear Customer, Your contact details could are not available with the bank for online transactions. Please visit your nearest branch to update your contact details. For any queries, please contact the bank customer care at: Phone:- 1234567890, Email:- customercare@bank.com");
				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Failed the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());

				// writing to 3DSS file
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
						acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
						responsepage.getThreeDSServerTransID().getText());
				break;

			case "Blocked":
				log.info("Testing blocked");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");
				sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
						"Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately.");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
					try {
						otp.getCardNotRegisteredContinueButton().click();
					} catch (Exception e) {
						System.out.println("Handling unexpected popup");

						Alert alert = driver.switchTo().alert();
						System.out.println("Type of alert: " + alert.getText());
						alert.accept();
					}
					sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "R");
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					// writing to 3DSS file
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

				} else {

					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
					otp.getCardNotRegisteredContinueButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
					sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "N");

					// Writing the real value from the response page.
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
					GenericMethods.writingToExcel(XlFileName, Txn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					// writing to acs file
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());

					// writing to 3DSS file
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "AcsTxnId", invocationCount,
							acsTxnId);
					GenericMethods.writingToExcel(XlFileName, ThreeDSSTxn2_0SheetName, "ThreeDSTxnId", invocationCount,
							responsepage.getThreeDSServerTransID().getText());
				}
				break;

			}
		} catch (UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

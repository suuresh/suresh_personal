package com.acs.testcases;
import java.util.List;
import org.testng.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.testng.xml.Parser;
import org.testng.xml.XmlSuite;

import org.xml.sax.SAXException;
public class MainClass
{
    
	public static void main(String[] args) throws FileNotFoundException, ParserConfigurationException, SAXException, IOException
    {
      /*  TestNG testng = new TestNG();
        TestListenerAdapter adapter = new TestListenerAdapter();
        List<String> suites = new ArrayList<String>();
       // testng.addListener(adapter);
        suites.add("Suite.xml");
        testng.setTestSuites(suites);
        testng.setParallel("parallel");
        testng.setSuiteThreadPoolSize(5);
        testng.setOutputDirectory(System.getProperty("user.dir")+"//target");
        testng.run();
    */
    	String arg1 = args[0];
    		TestNG testng = new TestNG(); 
  
   // 		testng.addListener(adapter);
    		if(arg1.equalsIgnoreCase("Sanity")) {
    		testng.setXmlSuites((List <XmlSuite>)(new Parser(System.getProperty("user.dir")+"/ACS_Admin_Sanity_TestSuite.xml").parse()));		
    		testng.setSuiteThreadPoolSize(4);
    		}else if(arg1.equalsIgnoreCase("Regression")) {
    			testng.setXmlSuites((List <XmlSuite>)(new Parser(System.getProperty("user.dir")+"/ACS_Admin_Regression_TestSuite.xml").parse()));		
        		testng.setSuiteThreadPoolSize(11);
    		}else {
    			System.out.println("Test type Argument is not mentioned");
    		}
    		testng.run();
    }
}

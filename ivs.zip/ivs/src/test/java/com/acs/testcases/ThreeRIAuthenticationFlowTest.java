package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.ACSSimulatorCheckOutPage;
import com.acs.pages.ACSSimulatorReponsePage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;

import com.acs.pages.StaticPasswordPage;
import com.acs.payloads.AreqRequestBodyHelper;
import com.acs.payloads.ThreeRIRequestBodyHelper;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class ThreeRIAuthenticationFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_ACS_SIMULATOR_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, "3RI");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String AcsTxnId, String ThreeDSTxnId,
			String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion, String decs)
			throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		ACSSimulatorCheckOutPage checkoutpage = new ACSSimulatorCheckOutPage(driver);
		ACSSimulatorReponsePage responsepage = new ACSSimulatorReponsePage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "3RI", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "3RI", "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "3RI", "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "3RI", "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "3RI", "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "3RI", "RiskSuggestion", invocationCount, "");
		
		System.out.println("Merchant Name : " + merchantname);
		System.out.println("Card Number : " + Cardnumber);
		System.out.println("Amout : " + amount);
		System.out.println("Currency : " + currencytype);
		System.out.println("Protocal Version : " + ProtocalVersion);
		System.out.println("AcsTxnId : " + AcsTxnId);
		System.out.println("ThreeDSReqPriorRef : " + acsTxnId);
		

		// putting try catch block to handle popup
		try {
			checkoutpage.getAcsAreqURLInputField().clear();
			checkoutpage.getAcsAreqURLInputField().sendKeys(Config.BASE_ACS_SIMULATOR_AREQ_URL+IssuerBankId);
			String areq =null;
			if(Flow.equalsIgnoreCase("Challenge")) {
			areq = ThreeRIRequestBodyHelper.Generate3RIIntialRequestBody(Cardnumber, amount, merchantname, currencytype,ProtocalVersion);
			System.out.println("3RI Initial  Areq : "+areq);
			} else if(Flow.equalsIgnoreCase("FrictionLess")) {
				areq = ThreeRIRequestBodyHelper.Generate3RISubsequentRequestBody(Cardnumber, amount, merchantname, currencytype, ProtocalVersion, acsTxnId);
				System.out.println("3RI Subsequent  Areq : "+areq);
			} else {
				areq = ThreeRIRequestBodyHelper.Generate3RISubsequentRequestBody(Cardnumber, amount, merchantname, currencytype, ProtocalVersion, "");
				System.out.println("3RI Subsequent  Areq : "+areq);
			}
			
			checkoutpage.getAreqPayloadInputField().click();
			checkoutpage.getAreqPayloadInputField().clear();
			generic.explicitWait(2);
			WebElement textareaelement = driver.findElement(By.id("areq_id"));
			JavascriptExecutor js = (JavascriptExecutor ) driver;
			js.executeScript("arguments[0].value='"+areq+"'", textareaelement);
			generic.explicitWait(3);
			
			checkoutpage.getAreqSubmitButton().click();
			generic.explicitWait(2);
					
			String CAVVValue = null;

			switch (Flow) {			
			case "WithoutPriorTxn":
				log.info(Flow + "Started");
				break;
			case "FrictionLess":
				log.info(Flow + "Started");
				generic.explicitWait(3);
			//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(), "ECI : 05","ECI Value Validation");
					CAVVValue = AreqRequestBodyHelper.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
					sAssertion.assertTrue(CAVVValue.startsWith("A"),"CAVV value validation");
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(), "ECI : 02","ECI Value Validation");
					CAVVValue = AreqRequestBodyHelper.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
					sAssertion.assertTrue(CAVVValue.startsWith("j"),"CAVV value validation");
				}

				// Writing the real value from the response page.
				generic.explicitWait(2);
				GenericMethods.writingToExcel(XlFileName, "3RI", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));				
				
				GenericMethods.writingToExcel(XlFileName, "3RI", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file 
				GenericMethods.writingToExcel(XlFileName, "3RI_Txn", "AcsTxnId", invocationCount,
						AreqRequestBodyHelper
								.acsTxnExtractionFromString(responsepage.getAcsTransactionIDStmnt().getText()));
				GenericMethods.writingToExcel(XlFileName, "3RI_Txn", "CavvOrAvv", invocationCount, CAVVValue);
				 

				break;

			case "Challenge":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
				//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {
		
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromEngine.get3RIOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				otp.getOtpSubmitButton().click();
			//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");
				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(), "ECI : 05","ECI Value Validation");
					CAVVValue = AreqRequestBodyHelper.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
					sAssertion.assertTrue(CAVVValue.startsWith("A"),"CAVV value validation");
				} else {
					sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(), "ECI : 02","ECI Value Validation");
					CAVVValue = AreqRequestBodyHelper.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
					sAssertion.assertTrue(CAVVValue.startsWith("j"),"CAVV value validation");
				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				
				GenericMethods.writingToExcel(XlFileName, "3RI", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "3RI", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "3RI_Txn", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "3RI_Txn", "CavvOrAvv", invocationCount, CAVVValue);
				 
				
				break;

			}
		} catch (UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.ACSSimulatorCheckOutPage;
import com.acs.pages.ACSSimulatorReponsePage;
import com.acs.pages.NewSimulatorOTPPage;

import com.acs.payloads.AreqRequestBodyHelper;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

import io.restassured.response.Response;

public class OOBAuthenticationFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	LogEntries NetWorklogs1;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_ACS_SIMULATOR_URL);
		// System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, "OOB");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String TestCaseID, String IssuerBankId, String IssuerBankName,
			String AccquirerBankId, String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow,
			String merchantname, String TransactionAmount, String CurrencyType, String CardUnionType, String TxnType,
			String AuthType, String ApproveStatus, String ExpieryTime, String acsTxnId, String CavvOrAvv, String ThreeDSTxnId, String RiskengineClientID,
			String RiskScore, String RiskSuggestion, String OtpExpiryTime, String PageExpiryTime,
			String OtpExpiryMessage, String ResendOTPMessage, String MaxResendOTPMessage, String OtpBlankMessage,
			String OtpLessthanMessage, String InvalidOTPMessage, String CardNotRegisteredText, String CCPageText,
			String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		ACSSimulatorCheckOutPage checkoutpage = new ACSSimulatorCheckOutPage(driver);
		ACSSimulatorReponsePage responsepage = new ACSSimulatorReponsePage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		String currentURL = null;
		invocationCount++;

		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "OOB", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB", "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB", "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB", "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB", "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB", "RiskSuggestion", invocationCount, "");
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OOB_Txn", "RiskSuggestion", invocationCount, "");

		System.out.println("***Test Started*****");
		System.out.println("TestCaseID: " + TestCaseID);
		System.out.println("Flow: " + Flow);
		System.out.println("Merchant Name : " + merchantname);
		System.out.println("Card Number : " + Cardnumber);
		System.out.println("Protocal Version : " + ProtocalVersion);
		System.out.println("TxnType: " + TxnType);

		// putting try catch block to handle popup
		try {

			checkoutpage.getAcsAreqURLInputField().clear();
			checkoutpage.getAcsAreqURLInputField().sendKeys(Config.BASE_ACS_SIMULATOR_AREQ_URL + IssuerBankId);

			String areqResponse = null;
			
			if(AuthType.contentEquals("Push") || AuthType.contentEquals("Biometric") ) {
				areqResponse = AreqRequestBodyHelper.generateCustomerFetchBody(Cardnumber);
			} else if(AuthType.contentEquals("Offline")) {
				
			}
			
			

			System.out.println("Prepared Areq : " + areqResponse);
			generic.explicitWait(2);
			checkoutpage.getAreqPayloadInputField().click();
			checkoutpage.getAreqPayloadInputField().clear();
			generic.explicitWait(2);

			WebElement textareaelement = driver.findElement(By.id("areq_id"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].value='" + areqResponse + "'", textareaelement);
			generic.explicitWait(5);
			checkoutpage.getAreqSubmitButton().click();

			String CAVVValue = null;

			switch (Flow) {
			case "Challenge":
				log.info(Flow + "Started");

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
				} else {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				
				
				/* OOB FLOW Starts */
				/* Select Auth Mode */
				if(AuthType.contentEquals("Push")) {
					otp.getPushRadioBtn().click();
				} else if(AuthType.contentEquals("Biometric")) {
					otp.getBiometricRadioBtn().click();
				} else if(AuthType.contentEquals("Offline")) {
					otp.getOfflineRadioBtn().click();
				}

				otp.getOtpSubmitButton().click();
				
				generic.explicitWait(5);
				
				// Approve for the Auth
				NetWorklogs1 = driver.manage().logs().get("driver");
				String traceId = getHeaders.getACSTraceIDFromHeaders(currentURL, IssuerBankId, NetWorklogs1);
				
				System.out.println("Trace Id:"+ traceId);
				
				Response response1 = null;
				
				if(ApproveStatus.contentEquals("APPROVED")) {
					response1 = GenericMethods.oobAuthApprove(acsTxnId, traceId, IssuerBankId, ApproveStatus);
					sAssertion.assertEquals(responsepage.getTransactionStatusY().getText(), "Status : Y");

					if (CardUnionType.equalsIgnoreCase("Visa")) {
						sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroFiveSuccessStmnt().getText(),
								"ECI : 05", "ECI Value Validation");
						if (TxnType.contentEquals("NPA")) {
							CAVVValue = AreqRequestBodyHelper
									.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
							sAssertion.assertTrue(CAVVValue.startsWith("A"), "CAVV value validation");
						}
					} else {
						sAssertion.assertEquals(responsepage.getAcsTransactionECIZeroTwoSuccessStmnt().getText(),
								"ECI : 02", "ECI Value Validation");
						if (TxnType.contentEquals("NPA")) {
							CAVVValue = AreqRequestBodyHelper
									.cavvOrAvvExtractionFromString(responsepage.getCavvValueStmnt().getText());
							sAssertion.assertTrue(CAVVValue.startsWith("j"), "CAVV value validation");
						}
					}
				} else if(ApproveStatus.contentEquals("DECLINED")) {
					response1 = GenericMethods.oobAuthApprove(acsTxnId, traceId, IssuerBankId, ApproveStatus);
					System.out.println("Declined");
				} else if(ApproveStatus.contentEquals("EXPIRED")) {
					generic.explicitWait(Integer.parseInt(ExpieryTime));
					System.out.println("EXPIRED");
				} else if(ApproveStatus.contentEquals("CANCELLED")) {
					generic.explicitWait(Integer.parseInt(ExpieryTime));
					System.out.println("CANCELLED");
				}
				
				
				
				String authResponse = response1.getBody().asString();
				System.out.println(authResponse);
				generic.explicitWait(3);
				
				

				// Writing the real value from the response page.
				// System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "CavvOrAvv", invocationCount, CAVVValue);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "CavvOrAvv", invocationCount, CAVVValue);

				break;

			case "BrowserBack":
				log.info(Flow + "Started");

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					System.out.println("Clicked on Checkout button");

					/*
					 * Getting ACSTcnId from Pareq Date-28-07-2020
					 */

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					System.out.println("Pareq:-" + paReq);
					String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
					// System.out.println("tesdDecode:-" + tesdDecode);
					String arr1[] = tesdDecode.split("&");
					String testEncodedPaReq = arr1[0];
					String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
					System.out.println("testDecodedPareq:-" + testDecodedPareq);
					acsTxnId = generic.getValueFromXml(testDecodedPareq);
					System.out.println("acsTxnId:-" + acsTxnId);
					generic.explicitWait(2);
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				driver.navigate().back();

				generic.explicitWait(600);

				// Writing the real value from the response page.
				// System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "PageExpiry":

				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					if (TxnType.contentEquals("SwitchCard")) {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					}

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				} else {

					if (TxnType.contentEquals("SwitchCard")) {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					}
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}
				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				// generic.explicitWait(60);
				generic.explicitWait(3);
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));

				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				// generic.explicitWait(3);
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);

					if (TxnType.contentEquals("SwitchCard")) {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					}

					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);
				} else {

					if (TxnType.contentEquals("SwitchCard")) {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
					} else {
						wait.until(
								ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
					}
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));

					// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
					// document.getElementByName('acctId').value").toString();
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
					generic.explicitWait(2);
				}

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
							// sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));
				generic.explicitWait(3);
				otp.getOtpTextField().sendKeys(otpValue);
				otp.getOtpSubmitButton().click();

				System.out.println(otp.getResendOTPMessage().getText());
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), OtpExpiryMessage);

				generic.explicitWait(3);

				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Cancelled":
				if (TxnType.contentEquals("SwitchCard")) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='submit']")));
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submitBtn']")));
				}
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				if (ProtocalVersion.equalsIgnoreCase("2.1.0") || ProtocalVersion.equalsIgnoreCase("2.2.0")) {
					// generic.explicitWait(3);
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);

				} else {
					// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					// System.out.println("OTP page and Submit Button Displayed for Cancel
					// Scenario");
					acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				}
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				System.out.println(otp.getResendOTPMessage().getText());
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), ResendOTPMessage);
				otp.getOtpResendButton().click();
				otp.getOtpResendButton().click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[@class='hei mid-content'])[1]")));
				System.out.println(otp.getResendOTPMessage().getText());

				sAssertion.assertTrue(otp.getResendOTPMessage().getText().contains(MaxResendOTPMessage));

				// sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				// "This is your last attempt. An OTP with reference ID");
				otp.getOtpCancelButton().click();
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));
				sAssertion.assertEquals(responsepage.getTransactionStatusN().getText(), "Status : N");

				// Writing the real value from the response page.
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator", "AcsTxnId", invocationCount, acsTxnId);
				System.out.println("Canceled the Transaction");

				// writing to acs file
				GenericMethods.writingToExcel(XlFileName, "ACS_Simulator_Txn", "AcsTxnId", invocationCount, acsTxnId);

				break;
			}

		} catch (

		UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

package com.acs.testcases;

import java.io.IOException;
import java.util.Random;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.acs.payloads.PushRequestBodyHelper;
import com.acs.utils.JWTEncryption;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.api.payuexpresspay.ApiMethods;
import com.trident.pages.TridentLogOutPage;
import com.trident.pages.TridentLoginPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.bytebuddy.description.type.TypeList.Generic;

public class PushApiVerification {

	int invocationCount = 2;
	public String acsTxnId = null;
	WebDriver driver = null;
	GenericMethods generic = new GenericMethods(driver);

	public String encryptedPayload = null;
	public String jsonbody = null;
	public Response response = null;
	public String responseasString = null;
	public JsonPath jsonPathEvaluator = null;
	public Xls_Reader excel;

	public String XlFileName = null;
	public String proxyUrl = null;
	
	public String Txn1_0SheetName = null;
	public String Txn2_0SheetName = null;
	public String ACSTxn1_0SheetName = null;
	public String ACSTxn2_0SheetName = null;
	public String TridentTxn1_0SheetName = null;
	public String TridentTxn2_0SheetName = null;
	public String ThreeDSSTxn2_0SheetName = null;
	public String OnBoradingXlFileName = null;
	public static Logger log = Logger.getLogger("devpinoyLogger");

	@SuppressWarnings("deprecation")
	@Parameters({"XlFileName"})
	@BeforeTest
	public void preCondtion(String xlfilename) throws Exception {

		PropertyConfigurator.configure(System.getProperty("user.dir") + "/log4j.properties");

		String proxyHost = System.getProperty("http.proxyHost");
		String proxyPort = System.getProperty("http.proxyPort");
		log.debug("http.proxyHost - " + proxyHost + ":" + proxyPort);
		System.out.println("http.proxyHost - " + proxyHost + ":" + proxyPort);
		if (proxyPort != null && proxyHost != null) {
			proxyUrl = proxyHost.trim() + ":" + proxyPort.trim();
		}
		log.debug("Proxy Url - " + proxyUrl);
		System.out.println("Proxy Url - " + proxyHost + ":" + proxyPort);
		XlFileName = xlfilename;

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, "pushApiReg");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1, priority = 0, enabled = true)
	public void pushapiRegistration(String IssuerBankId, String IssuerBankName, String Binrange, String Cardnumber,
			String CardholderName, String PhoneNumber, String ProtocalVersion, String Flow, String CardUnionType,
			String decs) throws Exception {

		SoftAssert sAssertion = new SoftAssert();

		// long randumnumber = GenericMethods.generateRandomDigits(11);
		Long randumnumber = (long) Math.floor(Math.random() * 9000000000L);
		System.out.println("Binrange : " + Binrange);
		String generatedCardNumber = Binrange + String.valueOf(randumnumber);
		System.out.println("Generated Card : " + generatedCardNumber);
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "pushApiReg", "Cardnumber", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "pushApiUpd", "Cardnumber", invocationCount, "");

		switch (Flow) {

		case "Register":
			System.out.println("************* Registration Flow ******************");
			jsonbody = PushRequestBodyHelper.pushRegisterRequestBody(IssuerBankId, generatedCardNumber, CardholderName,
					PhoneNumber);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
			response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);

			jsonPathEvaluator = response.jsonPath();
			// System.out.println("Final response----"+response1.getBody().asString());
			// Reporter.log(response1.getBody().asString());
			/*
			 * int updaterowcount = invocationCount+1;
			 * System.out.println("Updated card row number : "+updaterowcount);
			 */
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "00");
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Cardholder Enrolled Succesfully");
			GenericMethods.writingToExcel(XlFileName, "pushApiReg", "Cardnumber", invocationCount,
					generatedCardNumber);
			GenericMethods.writingToExcel(XlFileName, "pushApiUpd", "Cardnumber", invocationCount,
					generatedCardNumber);

			break;

		case "Update":
			System.out.println("************* Update Flow ******************");
			jsonbody = PushRequestBodyHelper.pushUpdateRequestBody(IssuerBankId, Cardnumber, CardholderName,
					PhoneNumber);
			encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
			response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);

			jsonPathEvaluator = response.jsonPath();
			System.out.println("Final response----" + response.getBody().asString());
			Reporter.log(response.getBody().asString());

			sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "00");
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"),
					"Cardholder Profile Updated Succesfully");

			break;
		}

		sAssertion.assertAll();
		invocationCount++;
	}

	@DataProvider
	public Object[][] DataSet1() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, "pushApiUpd");
	}

	@Test(dataProvider = "DataSet1", invocationCount = 1, priority = 1, enabled = true)
	public void pushapiUpdation(String IssuerBankId, String IssuerBankName, String Binrange, String Cardnumber,
			String CardholderName, String PhoneNumber, String ProtocalVersion, String Flow, String CardUnionType,
			String decs) throws Exception {

		SoftAssert sAssertion = new SoftAssert();

		// long randumnumber = GenericMethods.generateRandomDigits(11);
		Long randumnumber = (long) Math.floor(Math.random() * 9000000000L);
		System.out.println("Binrange : " + Binrange);
		String generatedCardNumber = Binrange + String.valueOf(randumnumber);
		System.out.println("Generated Card : " + generatedCardNumber);
		// Setting the value as null before writing the all values.
		// GenericMethods.writingToExcell(XlFileName, "pushApiUpd", "Cardnumber",
		// invocationCount, "");

		switch (Flow) {

		case "Register":
			System.out.println("************* Registration Flow ******************");
			jsonbody = PushRequestBodyHelper.pushRegisterRequestBody(IssuerBankId, generatedCardNumber, CardholderName,
					PhoneNumber);
			System.out.println("Json Body : " + jsonbody);
			encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
			response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
			responseasString = response.getBody().asString();
			System.out.println("Response String: " + responseasString);

			jsonPathEvaluator = response.jsonPath();
			// System.out.println("Final response----"+response1.getBody().asString());
			// Reporter.log(response1.getBody().asString());
			int updaterowcount = invocationCount + 1;
			System.out.println("Updated card row number : " + updaterowcount);
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "00");
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Cardholder Enrolled Succesfully");
			GenericMethods.writingToExcel(XlFileName, "pushApi", "Cardnumber", invocationCount, generatedCardNumber);
			GenericMethods.writingToExcel(XlFileName, "pushApi", "Cardnumber", updaterowcount, generatedCardNumber);

			break;

		case "Update":
			System.out.println("************* Update Flow ******************");
			jsonbody = PushRequestBodyHelper.pushUpdateRequestBody(IssuerBankId, Cardnumber, CardholderName,
					PhoneNumber);
			encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
			response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);

			jsonPathEvaluator = response.jsonPath();
			System.out.println("Final response----" + response.getBody().asString());
			Reporter.log(response.getBody().asString());

			sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "00");
			sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"),
					"Cardholder Profile Updated Succesfully");

			break;
		}

		sAssertion.assertAll();
		invocationCount++;
	}

	
	@DataProvider
	public Object[][] DataSet2() throws IOException {

		Reporter.log("Reading data from excell file");
		return GenericMethods.getApiData(XlFileName, "pushApiField");
	}
	
	@Test(dataProvider = "DataSet2", invocationCount = 1, priority = 2)
	public void pushapiFieldValidation(String IssuerBankId, String IssuerBankName, String Binrange, String Cardnumber,
			String CardholderName, String PhoneNumber, String ProtocalVersion, String Flow, String CardUnionType,
			String decs) throws Exception {

		
		SoftAssert sAssertion = new SoftAssert();
		Long randumnumber = (long) Math.floor(Math.random() * 9000000000L);
		System.out.println("Binrange : " + Binrange);
		String generatedCardNumber = Binrange + String.valueOf(randumnumber);
		System.out.println("Generated Card : " + generatedCardNumber);

		System.out.println("************* Registration Filed Validation Pan Empty ******************");
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody("", "", "", "", "", "", "", "", "");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"),
				"Validation Failed:Unable to process PAN is empty");

		System.out.println("************* Registration Filed Validation with Bankid, PAN,  ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "", "", "", "", "",
				"", "");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:Any one Mandatory either PRIMARY_PH_NUMBER or PRIMARY_EMAIL");

		System.out.println("************* Registration Filed Validation with Bankid, PAN, PHPhonenumber, apiVersion ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody("", generatedCardNumber, "1.0", "", "", "","", PhoneNumber, "");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:BIN not available");

		System.out.println("************* Registration Filed Validation with Bankid, PAN, email, apiVersion, status ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "1", "", "",	"", "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:API_REF_ID is empty");
		
		System.out.println("************* Registration Filed Validation with bankid, PAN, apiVersion, status, email, apiRefId ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "1", "23423SFDFDF423", "", "", "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:ACTION is empty");
		
		System.out.println("************* Registration Filed Validation with bankid, PAN, apiVersion, status, email, apiRefId, action ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "1", "23423SFDFDF423", "UPD", "", "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:Invalid NAME_ON_CARD");
		
		System.out.println("************* Registration Filed Validation with bankid, PAN, apiVersion, email, apiRefId, action, cardholdername ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "", "23423SFDFDF423", "REG", CardholderName, "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "01");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Validation Failed:Invalid STATUS");
		
		System.out.println("************* Registration Filed Validation with bankid, PAN, apiVersion, email, apiRefId, action, cardholdername, Status ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "1", "23423SFDFDF423", "UPD",CardholderName, "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "03");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Update Failed:Customer Record not available");
		
		System.out.println("************* Registration Filed Validation with bankid, PAN, apiVersion, email, apiRefId, action, cardholdername, Status ******************");
		/*
		 * String IssuerBankId, String PAN,String apiVersion, String status, String
		 * apiRefId, String action, String CardholderName, String phPhoneNumber, String
		 * primaryEmail)
		 */
		jsonbody = PushRequestBodyHelper.pushApiFieldValidationRequestBody(IssuerBankId, generatedCardNumber, "1.0", "1", "23423SFDFDF423", "REG",CardholderName, "", "subhash@gmail.com");
		System.out.println("Json Body : " + jsonbody);
		encryptedPayload = JWTEncryption.jweEncryption(jsonbody, null);
		response = ApiMethods.pushApiPostRequest(encryptedPayload, IssuerBankId);
		responseasString = response.getBody().asString();
		System.out.println("Response String: " + responseasString);
		jsonPathEvaluator = response.jsonPath();
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_code"), "00");
		sAssertion.assertEquals(jsonPathEvaluator.getString("status_desc"), "Cardholder Enrolled Succesfully");

		sAssertion.assertAll();
		invocationCount++;
	}

}

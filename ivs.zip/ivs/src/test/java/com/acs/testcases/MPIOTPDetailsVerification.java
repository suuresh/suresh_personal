package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.pages.StaticPasswordPage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class MPIOTPDetailsVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, "OTPDetails1_0");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void OTPDetailsVerificationTest(String IssuerBankId, String IssuerBankName,String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String Email, String PhoneNumber, String OtpMaxAttempts,
			String acsTxnId, String CavvOrAvv,String SchemaName, String decs) throws Exception {

		/*
		 * String[] s1=decs.split(":"); for(String s2:s1) {
		 * ExtentTestManager.getTest().setDescription(s2); }
		 */
		
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		StaticPasswordPage staticpaw = new StaticPasswordPage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "OTPDetails1_0", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "OTPDetails1_0", "CavvOrAvv", invocationCount, "");
		

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(5);
			System.out.println("Clicked on Checkout button");

			// For Karnatak Bank
			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(8);
			}
			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */
			if (Flow.equalsIgnoreCase("InActiveBin")) {
				System.out.println("Skipping the Pareq");
			} else {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
			}

			switch (Flow) {

			case "Challenge":
				log.info(Flow + "Started");

				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							
							if (imgElement.getAttribute("src") != "") {
								// HttpHost proxyhost = new HttpHost(proxyUrl);
								HttpGet request = new HttpGet(imgElement.getAttribute("src"));
								// HttpResponse response = client.execute(proxyhost, request);
								HttpResponse response = client.execute(request);
								if (response.getStatusLine().getStatusCode() != 200) {
									invalidImageCount++;
									System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

								} else
									System.out.println("image url: " + imgElement.getAttribute("src"));
								int respCode = response.getStatusLine().getStatusCode();
								String resposeCode = respCode + "";
								sAssertion.assertEquals(resposeCode, "200");
							}							
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				
				String MaximumAllowedOTPattempts = GenericMethods.getMaximumAllowedOTPattemptsFromDB(SchemaName, acsTxnId);
				String ResendOTPCount = GenericMethods.getResendOTPCountFromDB(SchemaName, acsTxnId);
				String InvalidOTPAttempts = GenericMethods.getInvalidOTPAttemptsFromDB(SchemaName, acsTxnId);
				String status = GenericMethods.getStatusDetails(SchemaName, acsTxnId);
				
				sAssertion.assertEquals(MaximumAllowedOTPattempts, OtpMaxAttempts, "Maxium Allowed OTP Attempts not matched with 3.");
				sAssertion.assertEquals(ResendOTPCount, "0", "1st Resend Count Mimatched.");
				sAssertion.assertEquals(InvalidOTPAttempts, "0", "1st Invalied Attempts mismatched.");
				sAssertion.assertEquals(status, "OTP GENERATED", "1st status mismatched");
				
		//		otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys("123456");
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
					generic.explicitWait(1);
					
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
					
				}
		
				sAssertion.assertEquals(GenericMethods.getMaximumAllowedOTPattemptsFromDB(SchemaName, acsTxnId), OtpMaxAttempts, "Maxium Allowed OTP Attempts not matched with 3.");
				sAssertion.assertEquals(GenericMethods.getResendOTPCountFromDB(SchemaName, acsTxnId), "0", "2nd Resend Count Mimatched.");
				sAssertion.assertEquals(GenericMethods.getInvalidOTPAttemptsFromDB(SchemaName, acsTxnId), "1", "2nd invalid attepts mismatched");
				sAssertion.assertEquals(GenericMethods.getStatusDetails(SchemaName, acsTxnId), "OTP VERIFY FAILED", "2nd status mismatched");
				
				otp.getOtpTextField().sendKeys("123456");
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
					generic.explicitWait(1);
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(1);
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				
				
				sAssertion.assertEquals(GenericMethods.getMaximumAllowedOTPattemptsFromDB(SchemaName, acsTxnId), OtpMaxAttempts, "Maxium Allowed OTP Attempts not matched with 3.");
				sAssertion.assertEquals(GenericMethods.getResendOTPCountFromDB(SchemaName, acsTxnId), "1", "3rd Resend Count Mimatched.");
				sAssertion.assertEquals(GenericMethods.getInvalidOTPAttemptsFromDB(SchemaName, acsTxnId), "2","3rd invalid attepts mismatched");
				sAssertion.assertEquals(GenericMethods.getStatusDetails(SchemaName, acsTxnId), "OTP GENERATED", "3rd status mismatched");
				
			
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
					generic.explicitWait(1);
					
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(1);
				}
				
				sAssertion.assertEquals(GenericMethods.getMaximumAllowedOTPattemptsFromDB(SchemaName, acsTxnId), OtpMaxAttempts, "Maxium Allowed OTP Attempts not matched with 3.");
				sAssertion.assertEquals(GenericMethods.getResendOTPCountFromDB(SchemaName, acsTxnId), "2", "4th Resend Count Mimatched.");
				sAssertion.assertEquals(GenericMethods.getInvalidOTPAttemptsFromDB(SchemaName, acsTxnId), "2","4th invalid attepts mismatched");
				sAssertion.assertEquals(GenericMethods.getStatusDetails(SchemaName, acsTxnId), "OTP VERIFIED", "4th status mismatched");
				
				
				
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());


				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, "OTPDetails1_0", "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, "OTPDetails1_0", "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;		

			}

		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

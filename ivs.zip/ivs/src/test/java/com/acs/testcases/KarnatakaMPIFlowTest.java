package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class KarnatakaMPIFlowTest extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void karnatakaMpiauthenticationTest(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage,
			String acsTxnId, String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String ResendOTPMessage, String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText,
			String CCPageText, String decs) throws Exception {

		System.out.println("*********************** Test Stated *********************");
		System.out.println("Flow ::" + Flow);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskSuggestion", invocationCount, "");

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");

		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			// System.out.println("Clicked on Checkout button");

			// For Karnataka Bank
			/*
			 * if (IssuerBankId.equalsIgnoreCase("8131")) {
			 * driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
			 * generic.explicitWait(5); }
			 */
			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			// System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			// System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			// System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr[] = tesdDecode.split("&");
			String testEncodedPaReq = arr[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			// System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);

			switch (Flow) {

			case "OtpDest2":
				log.info(Flow + "Started");

				generic.explicitWait(2);
				// Otp Destination :Email address
				driver.findElement(By.xpath("(//*[@name='otpDestinationOption'])[2]")).click();
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "OtpDest3":
				log.info(Flow + "Started");

				generic.explicitWait(2);
				// Otp Destination :Mobile number
				driver.findElement(By.xpath("(//*[@name='otpDestinationOption'])[3]")).click();
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "OtpDest4":
				log.info(Flow + "Started");

				generic.explicitWait(2);
				// Otp Destination :Email/Mobile does not match,
				driver.findElement(By.xpath("(//*[@name='otpDestinationOption'])[4]")).click();
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(2);
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Email/Mobile does not match");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				String mobileDoesntMatchMessage = otp.getKarnatakaCardNotRegText().getText();
				// System.out.println("mobileDoesntMatchMessage : "+mobileDoesntMatchMessage);
				// System.out.println("CardNotRegisteredText : "+CardNotRegisteredText);
				sAssertion.assertTrue(mobileDoesntMatchMessage.contains(CardNotRegisteredText),
						"EmailMobile does not match");

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Challenge":
				log.info(Flow + "Started");

				generic.explicitWait(2);
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "Resend":
				log.info(Flow + "Started");
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getTmlotpResendButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code has been re-sent to your registered device.");

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("PageExpiry");
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				generic.explicitWait(6);
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;

			case "OTPExpiry":
				log.info(Flow + "Started");
				System.out.println("OtpExpiry");
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				System.out.println("Waiting for 3 min..." + OtpExpiryTime);
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));
				generic.explicitWait(5);

				otp.getOtpTextField().sendKeys(otpValue);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code you entered is incorrect please try again.");
				 */
				WebElement OtpExpiry = driver.findElement(By.xpath("//div[@id='customerExpiry']"));
				System.out.println("OtpExpiry message:" + OtpExpiry.getText());
				sAssertion.assertTrue(OtpExpiry.getText().contains(OtpExpiryMessage), "Otp expiry validation");
				// sAssertion.assertEquals(OtpExpiry.getText(), OtpExpiryMessage);

				// clicking on continue
				driver.findElement(By.xpath("(//a[@id='csContinueLabel'])[2]")).click();
				generic.explicitWait(2);

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						System.out.println("Handling Alert for Bank id -" + IssuerBankId);
						driver.switchTo().alert().accept();

					}
				}

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "BlockCard":
				log.info(Flow + "Started");
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				// System.out.println("OTP page and Submit Button Displayed for BlockCard
				// Scenario");
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				// System.out.println("acsTxnId:- " + acsTxnId);
				generic.explicitWait(5);
				otp.getOtpTextField().sendKeys("123456");

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
				}
				System.out.println("otp Send1");
				generic.explicitWait(2);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or@class='mid-content'or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				/*
				 * sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
				 * "The code you entered is incorrect please try again.");
				 */
				System.out.println(otp.getInvalidOTPMessage().getText());
				System.out.println(InvalidOTPMessage);
				sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(), InvalidOTPMessage);

				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
				}
				System.out.println("otp Send2");
				generic.explicitWait(5);

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or@class='mid-content'or @id='error_text'or@class='headerDiv mid-content'])[1]")));

				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					System.out.println("otp Send3");
				}

				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Customer care page and submit button is displayed");

				/*
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * "Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately."
				 * );
				 */

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String BOBCustPage = otp.getCardNotRegisteredText().getText();
						System.out.println(BOBCustPage);
						System.out.println(CCPageText);
						sAssertion.assertTrue(BOBCustPage.contains(CCPageText));
						flag = true;
					}
				}

				if (flag = false) {
					sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CCPageText);
					System.out.println("Checkpoint--1");
				} else {
					System.out.println("Done..");
				}

				otp.getCardBlockedContinueButton().click();
				System.out.println("Continue clicked");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				// System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Canceled":
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code has been re-sent to your registered device.");
				 */
				sAssertion.assertEquals(otp.getKarnatakaResendText().getText(), ResendOTPMessage);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "Maximum Attempts Exceeded. You may cancel the transaction.");
				 */
				sAssertion.assertEquals(otp.getKarnatakaResendText().getText(), MaxResendOTPMessage);

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpCancelButton().click();
				} else {
					otp.getTmlotpCancelButton().click();
					generic.explicitWait(2);
					for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
						if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
							System.out.println("Handling Alert for Bank id -" + IssuerBankId);
							driver.switchTo().alert().accept();

						}
					}
				}

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Failed":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");

				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");

				for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
					if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
						String CardNotRegMessage = otp.getCardNotRegisteredText().getText();
						sAssertion.assertTrue(CardNotRegMessage.contains(CardNotRegisteredText));
						flag = true;
					}

					if (flag = false) {
						sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(), CardNotRegisteredText);
						System.out.println("Failed Scenario");
					} else {
						System.out.println("Done..");
					}

				}

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Blocked":
				log.info("Testing blocked");
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Blocked Card");
				/*
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * "Dear Customer, Your transaction cannot be processed currently as your card has been blocked for online transactions due to multiple invalid attempts. Please try again after 24hours or contact your bank for assistance immediately."
				 * );
				 */
				// sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				// CCPageText);
				sAssertion.assertTrue(otp.getCardNotRegisteredText().getText().contains(CCPageText));
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);
				otp.getCardNotRegisteredContinueButton().click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			case "OtpPage":
				/*
				 * Validation point: 1.Blank otp text 2.Less the 6 digit otp 3.Alphanumeric otp
				 * 4.Wibmo logo
				 */
				generic.explicitWait(2);
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(4);
				System.out.println("Otp page validation");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='otpValue']")));

				// Validating logos
				String aWibmoLogo = "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/common/images/wibmo_logo.png";
				String aBankLogo = "https://accosa-ivs.s3.ap-south-1.amazonaws.com/accosa-ivs/v1/participant/krntk/images/krntk_logo.jpg";
				String eWibmoLogo = driver.findElement(By.xpath("//img[@id='footerRightLogo']")).getAttribute("src");
				String eBankLogo = driver.findElement(By.xpath("//img[@id='leftLogo']")).getAttribute("src");
				System.out.println("eWibmoLogo:-" + eWibmoLogo);
				sAssertion.assertEquals(aWibmoLogo, eWibmoLogo);
				sAssertion.assertEquals(aBankLogo, eBankLogo);

				// validating blank otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
					for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
						if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
							System.out.println("Handling Alert for Bank id -" + IssuerBankId);
							String eBlankSubmitText = "OTP you received cannot be blank.";
							Alert blankSubmit = driver.switchTo().alert();
							String blankSubmitText = blankSubmit.getText();
							blankSubmit.accept();
							// validating blank otp text
							sAssertion.assertEquals(blankSubmitText, eBlankSubmitText);
						}
					}
				}

				// validating less than 6 digit otp
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getOtpTextField().sendKeys("12345");
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getOtpTextField().sendKeys("12345");
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
					for (int i = 0; i < Config.bankIdAlertPopup.length; i++) {
						if (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
							System.out.println("Handling Alert for Bank id -" + IssuerBankId);
							String eLessThanSixOtpText = "OTP you received cannot be less than 6 digits.";
							Alert lessThanSixOtpSubmit = driver.switchTo().alert();
							String lessThanSixOtpText = lessThanSixOtpSubmit.getText();
							lessThanSixOtpSubmit.accept();
							// validating less than 6 digit otp text
							sAssertion.assertEquals(lessThanSixOtpText, eLessThanSixOtpText);
						}
					}
				}

				// Entering alpha numeric
				otp.getOtpTextField().clear();
				otp.getOtpTextField().sendKeys("12h$X0");
				otp.getTmlotpSubmitButton().click();

				String eAlphaNumText = "OTP verification failed. Please enter valid OTP sent by the bank.";
				String aAlphaNumText = driver.findElement(By.xpath("//div[@id='error_text']")).getText();
				sAssertion.assertEquals(aAlphaNumText, eAlphaNumText);
				break;
			case "CancelLandingPage":

				driver.findElement(By.xpath("//img[@id='cancelBtn']")).click();
				generic.explicitWait(3);

				String eCancelAlertText = "Are you sure you want to Cancel? Your transaction may get declined. Click \"Ok\" to continue or \"Cancel\" to return to the authentication page.";
				Alert cancelAlert = driver.switchTo().alert();
				String aCancelAlertText = cancelAlert.getText();

				sAssertion.assertEquals(aCancelAlertText, eCancelAlertText);
				cancelAlert.accept();
				System.out.println("aCancelAlertText:-" + aCancelAlertText);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "ContactYourBranch":

				/*
				 * driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				 * generic.explicitWait(3);
				 * driver.findElement(By.xpath("//a[contains(text(),'Contact your branch')]")).
				 * click();
				 */
				generic.explicitWait(3);

				// String contactUrBranch =
				// driver.findElement(By.xpath("//div[@id='customer']")).getText();
				String contactUrBranch = driver
						.findElement(By.xpath("//div[@class='section-data customer-note normal mid-content']"))
						.getText();

				sAssertion.assertTrue(contactUrBranch.contains(CardNotRegisteredText));

				otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			}

		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

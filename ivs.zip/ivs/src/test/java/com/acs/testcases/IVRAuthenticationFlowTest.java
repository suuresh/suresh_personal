package com.acs.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.IVRCheckOutPage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;

public class IVRAuthenticationFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String otpValue = null;
	public String transactionStatus = null;
	public String eci = null;
	public String cavv = null;
	String paReq = null;
	public String PaResXml = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_IVR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, "Txn1_0_IVR");
	}
	
	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void ivrauthenticationTest(String IssuerBankId, String IssuerBankName, 
			String Cardnumber, String ProtocalVersion, String Flow, String Transtype, String CardUnionType, String OtpExpiryTime, 
			String OtpType, String acsTxnId, String CavvOrAvv, String decs) throws Exception {
		
		System.out.println("********************* Test Started ********************");
		System.out.println("Card No "+ Cardnumber);

		/*
		 * String[] s1=decs.split(":"); for(String s2:s1) {
		 * ExtentTestManager.getTest().setDescription(s2); }
		 */

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		IVRCheckOutPage ivrcheckout = new IVRCheckOutPage(driver);
		// Initializing the page objects
		
		String veReqPayloadPart1 = "<ThreeDSecure>" + 
				"<Message id='421531'>" + 
				"<VEReq>" + 
				"<version>1.0.2</version>" + 
				"<pan>";
		String veReqPayloadPart2 =	"</pan>" + 
				"<Merchant>" + 
				"<acqBIN>111111</acqBIN>" + 
				"<merID>12AB,cd/34-EF -g,5/H-67</merID>" + 
				"<password>password</password>" + 
				"<name>Merchant name</name>" + 
				"<country>004</country>" + 
				"<url>http://www.amazon.com/checkout.asp</url>" + 
				"</Merchant>" + 
				"<Browser>" + 
				"<deviceCategory>0</deviceCategory>" + 
				"<accept />" + 
				"<userAgent />" + 
				"</Browser>" + 
				"<Extension id='visa.3ds.india_ivr' critical='false' >" + 
				"<npc356chphoneidformat>I</npc356chphoneidformat>" + 
				"<npc356chphoneid>16505551234</npc356chphoneid>" + 
				"<npc356pareqchannel>DIRECT</npc356pareqchannel>" + 
				"<npc356shopchannel>IVR</npc356shopchannel>" + 
				"<npc356availauthchannel>SMS</npc356availauthchannel>" + 
				"</Extension>" + 
				"</VEReq>" + 
				"</Message>" + 
				"</ThreeDSecure>"	;
		
		String PareqPauLoadPart1 ="<ThreeDSecure>" + 
				"<Message id='43549531'>" + 
				"<PAReq>" + 
				"<version>1.0.2</version>" + 
				"<Merchant>" + 
				"<acqBIN>11111111111</acqBIN>" + 
				"<merID>M1-V</merID>" + 
				"<name>eBay.co.in</name>" + 
				"<country>840</country>" + 
				"<url>https://www.merchant.com</url>" + 
				"</Merchant>" + 
				"<Purchase>" + 
				"<xid>0zfld1WiDkysKDVsXzLa3wAHBwE=</xid>" + 
				"<date>20030225 17:59:13</date>" + 
				"<amount>Rs. 1000.00</amount>" + 
				"<purchAmount>100000</purchAmount>" + 
				"<currency>840</currency>" + 
				"<exponent>2</exponent>" + 
				"</Purchase>" + 
				"<CH>" + 
				"<acctID>";
		String PareqPauLoadPart2 = "</acctID>" + 
				"<expiry>0808</expiry>" + 
				"</CH>" + 
				"<Extension id='visa.3ds.india_ivr' critical='false'>" + 
				"<npc356authuserdata>" + 
				"<attribute name='OTP2' value='";
		String PareqPauLoadPart3 = "' encrypted='false' status='Y'></attribute>" + 
				"</npc356authuserdata>" + 
				"<npc356authitpdata>" + 
				"<attribute authenticated=' ' identifier=' '></attribute>" + 
				"</npc356authitpdata>" + 
				"</Extension>" + 
				"</PAReq>" + 
				"</Message>" + 
				"</ThreeDSecure>" ;
		
		String veReqFinalPayload = veReqPayloadPart1 + Cardnumber + veReqPayloadPart2;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "CavvOrAvv", invocationCount, "");
		
		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "CavvOrAvv", invocationCount, "");
		
		generic.explicitWait(3);
        System.out.println("Payload : "+ veReqFinalPayload);
        
        ivrcheckout.getVereqUrlTextField().clear();
        ivrcheckout.getVereqUrlTextField().sendKeys(Config.BASE_IVR_VEREQ_IP +IssuerBankId);
        ivrcheckout.getVeReqPayloadTextarea().click();
        ivrcheckout.getVeReqPayloadTextarea().clear();
        generic.explicitWait(3);
        
        ivrcheckout.getVeReqPayloadTextarea().sendKeys(veReqPayloadPart1+Cardnumber+veReqPayloadPart2);
       // String EnteredText=ivrcheckout.getVeReqPayloadTextarea().getText();
        generic.explicitWait(3);
      
        ivrcheckout.getVeReqGetResponseButton().click();
        
        generic.explicitWait(5);
        
        //Extracting ACS Txn id from the VeRes xml
        String vresxml = ivrcheckout.getVeResTextarea().getText();
        System.out.println("vres : "+vresxml);
        String acsTxnIdFromVeres = generic.ExtractValuesFromXML(vresxml,"acctID");
        String url = generic.ExtractValuesFromXML(vresxml,"url");
        String[] url1 = url.split(".com");
        //System.out.println(Config.BASE_IVR_PAREQ_IP + url1[1]);
        
        ivrcheckout.getPaReqNavigateButton().click();
        String IVROTP = null;
        
        //Getting the IVR OTP from the OTP Engine        
		if (IssuerBankId.equalsIgnoreCase("8546")) {
			IVROTP = OTPFromDynamicConfig.getIVROTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromVeres);
		} else {
			IVROTP = OTPFromEngine.getIVROTPFromEngine(Cardnumber, IssuerBankId, acsTxnIdFromVeres, OtpType);
		}

		switch (Flow) {
		
		case "Challenge":
			
			//Submiting the PaReq 
			
			ivrcheckout.getVereqUrlTextField().clear();
			ivrcheckout.getVereqUrlTextField().click();
			ivrcheckout.getVereqUrlTextField().sendKeys(Config.BASE_IVR_PAREQ_IP+url1[1]);
			//ivrcheckout.getVereqUrlTextField().sendKeys(url);
			
			generic.explicitWait(1);
	        ivrcheckout.getPaReqPayloadTextarea().clear();
	        ivrcheckout.getPaReqPayloadTextarea().click();
	        ivrcheckout.getPaReqPayloadTextarea().sendKeys(PareqPauLoadPart1+acsTxnIdFromVeres+PareqPauLoadPart2+IVROTP+PareqPauLoadPart3);
	        ivrcheckout.getPaReqGetResponseButton().click();
	        generic.explicitWait(10);
	        PaResXml = ivrcheckout.getPaResPayloadTextarea().getText();
	        System.out.println("Pares : " +PaResXml);
	        
			transactionStatus =generic.ExtractValuesFromXML(PaResXml,"status");
			eci = generic.ExtractValuesFromXML(PaResXml,"eci");
			cavv = generic.ExtractValuesFromXML(PaResXml,"cavv");
			
			System.out.println("Transaction Status : "+transactionStatus);
			System.out.println("ECI Value : "+eci);
			System.out.println("CAVV Value : "+cavv);
			
			sAssertion.assertEquals(transactionStatus, "Y");
			if (CardUnionType.equalsIgnoreCase("Visa")) {
				sAssertion.assertEquals(eci, "05");
				sAssertion.assertTrue(cavv.startsWith("A"));
			} else {
				sAssertion.assertEquals(eci, "02");
				sAssertion.assertTrue(cavv.startsWith("j"));
			}

			// Writing the real value from the response page.
			System.out.println("Challenge Flow Invocation Count : " + invocationCount);

			GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "CavvOrAvv", invocationCount, cavv);
		
			// writing to acs file
			GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "CavvOrAvv", invocationCount,cavv);
			break;
			
		case "ExpiredOTP":
			generic.explicitWait(305);
			//Submiting the PaReq 
			ivrcheckout.getVereqUrlTextField().clear();
			ivrcheckout.getVereqUrlTextField().click();
			ivrcheckout.getVereqUrlTextField().sendKeys(Config.BASE_IVR_PAREQ_IP+url1[1]);
			
	        ivrcheckout.getPaReqPayloadTextarea().clear();
	        ivrcheckout.getPaReqPayloadTextarea().click();
	        ivrcheckout.getPaReqPayloadTextarea().sendKeys(PareqPauLoadPart1+acsTxnIdFromVeres+PareqPauLoadPart2+IVROTP+PareqPauLoadPart3);
	        ivrcheckout.getPaReqGetResponseButton().click();
	        generic.explicitWait(10);
	        PaResXml = ivrcheckout.getPaResPayloadTextarea().getText();
	        System.out.println("Pares : " +PaResXml);
	        
			transactionStatus =generic.ExtractValuesFromXML(PaResXml,"status");
						
			System.out.println("Transaction Status : "+transactionStatus);
						
			System.out.println("Challenge Flow Invocation Count : " + invocationCount);
			
			sAssertion.assertEquals(transactionStatus, "N");

			GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			
			// writing to acs file
			GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			break;
		case "InvalidOTP":
			IVROTP = "654321";
			ivrcheckout.getVereqUrlTextField().clear();
			ivrcheckout.getVereqUrlTextField().click();
			ivrcheckout.getVereqUrlTextField().sendKeys(Config.BASE_IVR_PAREQ_IP+url1[1]);
			
			generic.explicitWait(1);
	        ivrcheckout.getPaReqPayloadTextarea().clear();
	        ivrcheckout.getPaReqPayloadTextarea().click();
	        ivrcheckout.getPaReqPayloadTextarea().sendKeys(PareqPauLoadPart1+acsTxnIdFromVeres+PareqPauLoadPart2+IVROTP+PareqPauLoadPart3);
	        ivrcheckout.getPaReqGetResponseButton().click();
	        generic.explicitWait(10);
	        PaResXml = ivrcheckout.getPaResPayloadTextarea().getText();
	        System.out.println("Pares : " +PaResXml);
	        
			transactionStatus =generic.ExtractValuesFromXML(PaResXml,"status");
			//eci = generic.ExtractValuesFromXML(PaResXml,"eci");
			//cavv = generic.ExtractValuesFromXML(PaResXml,"cavv");
			
			System.out.println("Transaction Status : "+transactionStatus);
			//System.out.println("ECI Value : "+eci);
			//System.out.println("CAVV Value : "+cavv);
			
			sAssertion.assertEquals(transactionStatus, "N");
			

			// Writing the real value from the response page.
			System.out.println("Challenge Flow Invocation Count : " + invocationCount);

			GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			GenericMethods.writingToExcel(XlFileName, "Txn1_0_IVR", "CavvOrAvv", invocationCount, cavv);
		
			// writing to acs file
			GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "AcsTxnId", invocationCount, acsTxnIdFromVeres);
			GenericMethods.writingToExcel(XlFileName, "ACSTxn1_0_IVR", "CavvOrAvv", invocationCount,cavv);
			break;

		}
			

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

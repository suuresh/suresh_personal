
package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;

public class RBLMpiFlowTest extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;
	String parentWindowHandle = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		log.info("Reading data from excell file");
		System.out.println("XlFile Name In TestClass : " + XlFileName);
		return generic.getData(XlFileName, Txn1_0SheetName);
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void RblMpiauthenticationTest(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String OtpExpiryTime, String PageExpiryTime, String OtpExpiryMessage,
			String acsTxnId, String CavvOrAvv, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String ResendOTPMessage, String MaxResendOTPMessage, String InvalidOTPMessage, String CardNotRegisteredText,
			String CCPageText, String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// initializing the page objects
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

//			WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;
		// Setting the value as null before writing the all values.
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "RiskSuggestion", invocationCount, "");

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");

		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			System.out.println("Clicked on Checkout button");

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr[] = tesdDecode.split("&");
			String testEncodedPaReq = arr[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);

			switch (Flow) {

			case "Challenge":
				log.info(Flow + "Started");

				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							int respCode = response.getStatusLine().getStatusCode();
							String resposeCode = respCode + "";
							sAssertion.assertEquals(resposeCode, "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				// otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId,
				// acsTxnId);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				 otp.getOtpTextField().sendKeys(otpValue);

				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = otpValue.split("");

					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}
*/
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "Resend":
				log.info(Flow + "Started");
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);

				/* Verifying images are displayed or not */
				try {
					invalidImageCount = 0;
					List<WebElement> imagesList = driver.findElements(By.tagName("img"));
					System.out.println("Total no. of images are " + imagesList.size());
					for (WebElement imgElement : imagesList) {
						if (imgElement != null) {
							// String imgSRCUrl = imgElement.getAttribute("src");
							// int statuscode =generic.verifyimageActive(imgElement);
							HttpClient client = HttpClientBuilder.create().build();
							// HttpHost proxyhost = new HttpHost(proxyUrl);
							HttpGet request = new HttpGet(imgElement.getAttribute("src"));
							// HttpResponse response = client.execute(proxyhost, request);
							HttpResponse response = client.execute(request);
							if (response.getStatusLine().getStatusCode() != 200) {
								invalidImageCount++;
								System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

							} else
								System.out.println("image url: " + imgElement.getAttribute("src"));
							sAssertion.assertEquals(response.getStatusLine().getStatusCode(), "200");
						}
						System.out.println("Total no. of invalid images are " + invalidImageCount);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getTmlotpResendButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or @id='error_text'or@class='headerDiv mid-content'])[1]")));
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
						"The code has been re-sent to your registered device.");

				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				generic.explicitWait(1);

				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();

				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "PageExpiry":
				log.info(Flow + "Started");
				System.out.println("OTP PageExpiry");

				generic.explicitWait(Integer.parseInt(PageExpiryTime));
				generic.explicitWait(6);
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				break;
			case "OTPExpiry":
				log.info(Flow + "Started");
				System.out.println("OtpExpiry");

				System.out.println("ACS Txn Id is : " + acsTxnId);
				otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				// Waiting Explicitly for OTP to be expired.
				System.out.println("Waiting for 3 min..." + OtpExpiryTime);
				generic.explicitWait(Integer.parseInt(OtpExpiryTime));

				generic.explicitWait(5);
				otp.getOtpTextField().sendKeys(otpValue);
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = otpValue.split("");

					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * sAssertion.assertEquals(otp.getResendOTPMessage().getText(),
				 * "The code you entered is incorrect please try again.");
				 */
				sAssertion.assertEquals(otp.getResendOTPMessage().getText(), OtpExpiryMessage);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "BlockCard":
				log.info(Flow + "Started");

				System.out.println("acsTxnId:- " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpTextField().sendKeys("123456");
				//String wrongOtp="123456";
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = wrongOtp.split("");
					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or@class='mid-content'or @id='error_text'or@class='headerDiv mid-content'])[1]")));

				sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(), InvalidOTPMessage);
				otp.getOtpTextField().sendKeys("123456");
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = wrongOtp.split("");
					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = wrongOtp.split("");
					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				/*
				 * wait.until(ExpectedConditions .visibilityOfElementLocated(By.
				 * xpath("//*[text()='Continue' or text()='CONTINUE']")));
				 */
				System.out.println("Customer care page and submit button is displayed");

				WebElement BlockedCCPage = driver
						.findElement(By.xpath("//p[@class='hei mid-content mid-content__bg']"));
				System.out.println("CCPageText" + BlockedCCPage);

				System.out.println("Blocked card meaages:-" + BlockedCCPage.getText());

				sAssertion.assertTrue(BlockedCCPage.getText().contains(CCPageText), "Blocked card Message");

				/*
				 * for (int i = 0; i < Config.bankIdAlertPopup.length; i++) { if
				 * (IssuerBankId.equals(Config.bankIdAlertPopup[i])) { String BOBCustPage =
				 * otp.getCardNotRegisteredText().getText();
				 * sAssertion.assertTrue(BOBCustPage.contains(CCPageText)); flag = true; } }
				 * 
				 * if (flag = false) {
				 * sAssertion.assertEquals(otp.getCardNotRegisteredText().getText(),
				 * CCPageText);
				 * 
				 * } else { System.out.println("Done.."); }
				 */
				// otp.getCardBlockedContinueButton().click();
				// waiting for final page navigation
				generic.explicitWait(310);

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Canceled":
				System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='mid-content']")));

				WebElement resendText = driver.findElement(By.xpath("//p[@class='mid-content']"));
				sAssertion.assertEquals(resendText.getText(), ResendOTPMessage);
				// waiting for 30 sec for active resend link as per requirement
				generic.explicitWait(30);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}

				generic.explicitWait(30);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpResendButton().click();
				} else {
					otp.getTmlotpResendButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='mid-content']")));
				WebElement MaxresendText = driver.findElement(By.xpath("//p[@class='mid-content']"));
				sAssertion.assertEquals(MaxresendText.getText(), MaxResendOTPMessage);
				generic.explicitWait(5);
				// Validating disappear resends button after max resends
				if (driver.findElements(By.xpath("//span[text()='Resend OTP']")).size() >= 1) {
					boolean resend = driver.findElement(By.xpath("//span[text()='Resend OTP']")).isDisplayed();
					System.out.println("resend:-" + resend);
					// sAssertion.assertEquals(resend, "false", "Resend link visibility");
					sAssertion.assertFalse(resend);
				}

				/*
				 * if (TemplateType.equalsIgnoreCase("Rocker")) {
				 * otp.getRkrotpCancelButton().click(); } else {
				 * otp.getTmlotpCancelButton().click(); generic.explicitWait(2); for (int i = 0;
				 * i < Config.bankIdAlertPopup.length; i++) { if
				 * (IssuerBankId.equals(Config.bankIdAlertPopup[i])) {
				 * System.out.println("Handling Alert for Bank id -" + IssuerBankId);
				 * driver.switchTo().alert().accept();
				 * 
				 * } } }
				 */

				// waiting for final page navigation
				generic.explicitWait(320);

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			case "Failed":
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Continue ⇾')]")));
				System.out.println("Cutomer Care page and Submit Button Displayed for Failed Card");
				WebElement cardNotRegistered = driver
						.findElement(By.xpath("//p[@class='hei mid-content mid-content__bg']"));
				// sAssertion.assertEquals(cardNotRegistered.getText(), CardNotRegisteredText);
				sAssertion.assertTrue(cardNotRegistered.getText().contains(CardNotRegisteredText),
						"Card not registered Message");
				driver.findElement(By.xpath("//button[contains(text(),'Continue ⇾')]")).click();

				// otp.getCardNotRegisteredContinueButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;

			case "Blocked":
				log.info("Testing blocked");
				/*
				 * wait.until(ExpectedConditions .visibilityOfElementLocated(By.
				 * xpath("//*[text()='Continue' or text()='CONTINUE']")));
				 */
				WebElement ccPage = driver.findElement(By.xpath("//p[@class='hei mid-content mid-content__bg']"));
				System.out.println("CCPageText" + CCPageText);

				System.out.println("Blocked card meaages:-" + ccPage.getText());

				sAssertion.assertTrue(ccPage.getText().contains(CCPageText), "Blocked card Message");
				// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
				generic.explicitWait(2);
				// otp.getCardNotRegisteredContinueButton().click();
				// waiting for final page navigation
				generic.explicitWait(310);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : N"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: N"),
						"Pares Status");
				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("VERes Status: Y"),
						"VERES Starus");

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 07"),
							"ECI Value Verification");

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 00"),
							"ECI Value Verification");

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);

				break;
			case "International":
				log.info("International Transactions");
				parentWindowHandle = driver.getWindowHandle();
				System.out.println(
						"Intrenational Transaction Disabled meaages:-" + otp.getRblLandingPageText().getText());

				sAssertion.assertTrue(
						otp.getRblLandingPageText().getText().contains("disabled for online/international transaction"),
						"Internation transaction message");
				otp.getRblLandingPageWebLink().click();
				for (String handle : driver.getWindowHandles()) {
					if (!handle.equals(parentWindowHandle)) {
						driver.switchTo().window(handle);
						driver.close();
					}
				}

				driver.switchTo().window(parentWindowHandle);
				otp.getRblLandingPageContinueButton().click();

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				// otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId,
				// acsTxnId);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

				otp.getOtpTextField().sendKeys(otpValue);
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = otpValue.split("");
					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			case "ECOM":
				log.info("ECOM online Transactions");
				parentWindowHandle = driver.getWindowHandle();
				System.out.println(
						"Online Transaction Transaction Disabled meaages:-" + otp.getRblLandingPageText().getText());

				sAssertion.assertTrue(otp.getRblLandingPageText().getText().contains("disabled for online transaction"),
						"Internation transaction message");
				otp.getRblLandingPageWebLink().click();

				for (String handle : driver.getWindowHandles()) {
					if (!handle.equals(parentWindowHandle)) {
						driver.switchTo().window(handle);
						driver.close();
					}
				}

				driver.switchTo().window(parentWindowHandle);
				generic.explicitWait(2);
				otp.getRblLandingPageContinueButton().click();

				System.out.println("ACS Txn Id is : " + acsTxnId);
				generic.explicitWait(2);

				// otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId,
				// acsTxnId);
				otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
				System.out.println("OTP Value is : " + otpValue);
				
				otp.getOtpTextField().sendKeys(otpValue);
				/*for (int i = 1; i < 7; i++) {
					String[] otpVal = otpValue.split("");
					driver.findElement(By.xpath("//input[@id='codeBox" + i + "']")).sendKeys(otpVal[i - 1]);
				}*/
				generic.explicitWait(1);
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}

				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center/text()[3]")));
				System.out.println("Transaction Status Text : " + responsepage.getSuccessTransactionStatus().getText());
				System.out.println("CAVV Value : " + responsepage.getSuccessTransactionCAVVText().getText());

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
						"Transaction staty Y verification");

				sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("PARes Status: Y"));

				if (CardUnionType.equalsIgnoreCase("Visa")) {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 05"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("A"));

				} else {
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("ECI : 02"),
							"ECI Value Verification");
					sAssertion.assertTrue(responsepage.getSuccessTransactionCAVVText().getText().startsWith("j"));

				}

				// Writing the real value from the response page.
				System.out.println("Challenge Flow Invocation Count : " + invocationCount);

				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, Txn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				// Writing to acs file
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "AcsTxnId", invocationCount, acsTxnId);
				GenericMethods.writingToExcel(XlFileName, ACSTxn1_0SheetName, "CavvOrAvv", invocationCount,
						responsepage.getSuccessTransactionCAVVText().getText());

				break;

			}

		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		log.info(Flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

}

package com.acs.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;

import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.pages.RupayCheckOutPage;
import com.acs.pages.RupayOTPPage;
import com.acs.pages.RupayResponsePage;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

public class RupayAuthenticationFlowTest extends ACSInitialSetUp {
	/* Modified By Suuresh */
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;	
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	String RupayTxn = "RupayTxn";
	String RupayTxnVerify = "RupayTxnVerify";

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		System.out.println(Config.BASE_RUPAY_HOME_URL);
		driver.get(Config.BASE_RUPAY_HOME_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {
		log.info("Reading data from excell file");
		return generic.getData(XlFileName, "RupayTxn");
	}

	@Test(dataProvider = "DataSet", invocationCount = 1)
	public void authenticationTest(String issuerBankId, String issuerBankName, String accquirerBankId,
			String acquirerBankName, String userId, String password, String cardNumber, String expDate, String CVV,
			String hashKey, String merchantName, String transactionAmount, String currencyCode, String flow,
			String currencyType, String cardUnionType, String rupayTxnId, String authInitTxnId, String guid,
			String threeDSTxnId, String riskengineClientID, String riskScore, String riskSuggestion,
			String otpExpiryTime, String pageExpiryTime, String otpExpiryMessage, String resendOTPMessage,
			String maxResendOTPMessage, String otpBlankMessage, String otpLessthanMessage, String invalidOTPMessage,
			String cardNotRegisteredText, String CCPageText, String testCaseDiscription) throws Exception {

		System.out.println("************************** Test Started ****************");
		System.out.println("Flow:: " + flow);

		ExtentTestManager.getTest().setDescription(testCaseDiscription);
		SoftAssert sAssertion = new SoftAssert();
		// generic.explicitWait(5);
		// Initializing the page objects
		RupayCheckOutPage checkoutpage = new RupayCheckOutPage(driver);
		RupayResponsePage responsePage = new RupayResponsePage(driver);
		RupayOTPPage otpPage = new RupayOTPPage(driver);

//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		String cardholder_id = null;
		String guidString = null;
		String authinitResponse = null;
		String errorCode = null;
		String responseBody = null;
		String accuResponseCode = null;
		WebElement element = null;
		String authResponseData = null;
		String status = null;
		String transactionId = null;
		invocationCount++;

		// Setting the value as null before writing the all values. AuthInitTxnId
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "RupayTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "AuthInitTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "Guid", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxn, "RiskSuggestion", invocationCount, "");

		// writing to acs file
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "RupayTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "AuthInitTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "ThreeDSTxnId", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "RiskengineClientID", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "RiskScore", invocationCount, "");
		GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "RiskSuggestion", invocationCount, "");

		// Writing to 3DSSS file
		/*
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "AcsTxnId", invocationCount, ""); GenericMethods.writingToExcell(XlFileName,
		 * ThreeDSSTxn2_0SheetName, "CavvOrAvv", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "ThreeDSTxnId", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "RiskengineClientID", invocationCount, "");
		 * GenericMethods.writingToExcell(XlFileName, ThreeDSSTxn2_0SheetName,
		 * "RiskScore", invocationCount, ""); GenericMethods.writingToExcell(XlFileName,
		 * ThreeDSSTxn2_0SheetName, "RiskSuggestion", invocationCount, "");
		 */
		generic.explicitWait(1);

		transactionId = GenericMethods.generateRandomDigits(15) + "";
		// System.out.println("Transaction Id:" + transactionId);

		initCheckOutPage(checkoutpage, userId, password, cardNumber, expDate, CVV, hashKey, merchantName,
				transactionAmount, currencyCode, transactionId);

		generic.explicitWait(2);

		// putting try catch block to handle popup
		try {

			checkoutpage.getTransactionBtn().click();
			generic.explicitWait(10);

			authinitResponse = checkoutpage.getResposeData().getText();
			// System.out.println("authinitResponse:" + authinitResponse);

			if (flow.contentEquals("Failed")) {

				errorCode = generic.ExtractValuesFromXML(authinitResponse, "errorcode");
				sAssertion.assertEquals(errorCode, "56");

			} else {

				cardholder_id = generic.ExtractValuesFromXML(authinitResponse, "cardholder_id");
				// System.out.println("cardholder_id:" + cardholder_id);

				guidString = generic.ExtractValuesFromXML(authinitResponse, "issuer_guid");
				// System.out.println("guidString:" + guidString);

				currentURL = driver.getCurrentUrl();
				// System.out.println(currentURL);
				// Redirect to Transaction page
				driver.get(Config.BASE_RUPAY_TRANSACTION_URL);

				// System.out.println("Redirecting to new URL");

				generic.explicitWait(3);

				otpPage.getAccuCardholderId().clear();
				otpPage.getAccuCardholderId().sendKeys(cardholder_id);

				otpPage.getHashKey().clear();
				otpPage.getHashKey().sendKeys(hashKey);

				otpPage.getTxnId().clear();
				otpPage.getTxnId().sendKeys(transactionId);

				otpPage.getSendAPReqBtn().click();
				generic.explicitWait(2);
			}

			switch (flow) {
			case "Challenge":
				log.info(flow + "Started");
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));

				// System.out.println("Enterd challenge flow");
				/* Verifying images are displayed or not */
				this.verifyImages(sAssertion);

				// Get the OTP
				otpValue = OTPFromEngine.getOTPFromEngine(cardNumber, issuerBankId, cardholder_id);
				// System.out.println(otpValue);
				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys(otpValue);
				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(2);

				responseBody = responsePage.getResponseBody().getText();
				// System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU000");
				// Redicect to checkoutpage page
				driver.get(Config.BASE_RUPAY_HOME_URL);
				generic.explicitWait(2);

				initCheckOutPage(checkoutpage, userId, password, cardNumber, expDate, CVV, hashKey, merchantName,
						transactionAmount, currencyCode, transactionId);
				checkoutpage.getResposeData().clear();
				checkoutpage.getResposeData().sendKeys(authinitResponse);
				element = checkoutpage.getGuid();
				((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('style', 'display: block;')",
						element);
				checkoutpage.getGuid().clear();
				checkoutpage.getGuid().sendKeys(guidString);

				checkoutpage.getAuthResultBtn().click();
				generic.explicitWait(10);

				authResponseData = checkoutpage.getAuthResponseData().getText();

				status = generic.ExtractValuesFromXML(authResponseData, "status");
				// System.out.println("status:" + status);

				sAssertion.assertEquals(status, "SUCCESS");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;

			case "Resend":
				// generic.explicitWait(300);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));
				/* Verifying images are displayed or not */
				// this.verifyImages(sAssertion);
				generic.explicitWait(2);

				otpPage.getOtpResendButton().click();
				generic.explicitWait(2);

				System.out.println(otpPage.getResendOTPMessageText().getText());
				System.out.println(resendOTPMessage);

				sAssertion.assertEquals(otpPage.getResendOTPMessageText().getText(), resendOTPMessage);
				// sAssertion.assertTrue(otpPage.getResendOTPMessageText().getText().contains(resendOTPMessage));

				// Get the OTP
				otpValue = OTPFromEngine.getOTPFromEngine(cardNumber, issuerBankId, cardholder_id);
				// System.out.println(otpValue);
				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys(otpValue);
				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(2);

				responseBody = responsePage.getResponseBody().getText();
				// System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU000");
				// Redicect to checkoutpage page
				driver.get(Config.BASE_RUPAY_HOME_URL);
				generic.explicitWait(2);

				initCheckOutPage(checkoutpage, userId, password, cardNumber, expDate, CVV, hashKey, merchantName,
						transactionAmount, currencyCode, transactionId);
				checkoutpage.getResposeData().clear();
				checkoutpage.getResposeData().sendKeys(authinitResponse);
				element = checkoutpage.getGuid();
				((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('style', 'display: block;')",
						element);
				checkoutpage.getGuid().clear();
				checkoutpage.getGuid().sendKeys(guidString);

				checkoutpage.getAuthResultBtn().click();
				generic.explicitWait(10);

				authResponseData = checkoutpage.getAuthResponseData().getText();

				status = generic.ExtractValuesFromXML(authResponseData, "status");
				// System.out.println("status:" + status);

				sAssertion.assertEquals(status, "SUCCESS");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);

				break;
			case "Cancelled":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));

				/* Verifying images are displayed or not */
				// this.verifyImages(sAssertion);

				otpPage.getOtpCancelButton().click();

				generic.explicitWait(2);

				responseBody = responsePage.getResponseBody().getText();
				System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU200");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);

				break;
			case "OTPPage":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));

				/* Verifying images are displayed or not */
				// this.verifyImages(sAssertion);

				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(1);
				System.out.println(otpPage.getOtpMessage().getText());
				System.out.println(otpBlankMessage);
				sAssertion.assertEquals(otpPage.getOtpMessage().getText(), otpBlankMessage);

				// validating less than 6 digit otp
				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys("123");
				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(1);

				System.out.println(otpPage.getOtpMessage().getText());
				System.out.println(otpLessthanMessage);
				sAssertion.assertEquals(otpPage.getOtpMessage().getText(), otpLessthanMessage);

				// Entering alpha numeric
				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys("123456");
				otpPage.getOtpSubmitButton().click();

				System.out.println(otpPage.getResendOTPMessageText().getText());
				System.out.println(invalidOTPMessage);
				sAssertion.assertTrue(otpPage.getResendOTPMessageText().getText().contains(invalidOTPMessage));

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;

			case "OTPExpiry":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));
				otpValue = OTPFromEngine.getOTPFromEngine(cardNumber, issuerBankId, cardholder_id);

				// Waiting Explicitly for OTP to be expired.
				generic.explicitWait(Integer.parseInt(otpExpiryTime));
				generic.explicitWait(5);
				System.out.println("time Completed");
				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys(otpValue);
				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(2);

				System.out.println(otpPage.getResendOTPMessageText().getText());
				System.out.println(otpExpiryMessage);

				sAssertion.assertEquals(otpPage.getResendOTPMessageText().getText(), otpExpiryMessage);

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;

			case "PageExpiry":
				generic.explicitWait(Integer.parseInt(pageExpiryTime));
				generic.explicitWait(5);

				responseBody = responsePage.getResponseBody().getText();
				System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU400");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;

			case "BlockCard":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='btn btn__submit']")));

				/* Verifying images are displayed or not */
				// this.verifyImages(sAssertion);

				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys("123456");
				otpPage.getOtpSubmitButton().click();
				generic.explicitWait(2);
				System.out.println(otpPage.getResendOTPMessageText().getText());
				System.out.println(invalidOTPMessage);
				sAssertion.assertTrue(otpPage.getResendOTPMessageText().getText().contains(invalidOTPMessage));

				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys("123456");
				otpPage.getOtpSubmitButton().click();

				otpPage.getOtpField().clear();
				otpPage.getOtpField().sendKeys("123456");
				otpPage.getOtpSubmitButton().click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='success__msg']")));

				System.out.println(otpPage.getCardNotRegisteredText().getText());
				System.out.println(cardNotRegisteredText);
				sAssertion.assertTrue(otpPage.getCardNotRegisteredText().getText().contains(cardNotRegisteredText));

				otpPage.getContinueBtn().click();

				generic.explicitWait(2);

				responseBody = responsePage.getResponseBody().getText();
				System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU100");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;

			case "Blocked":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='success__msg']")));

				System.out.println(otpPage.getCardNotRegisteredText().getText());
				System.out.println(cardNotRegisteredText);
				sAssertion.assertTrue(otpPage.getCardNotRegisteredText().getText().contains(cardNotRegisteredText));

				otpPage.getContinueBtn().click();

				generic.explicitWait(2);

				responseBody = responsePage.getResponseBody().getText();
				System.out.println("responseBody:" + responseBody);
				accuResponseCode = generic.getAccuResponseCode(responseBody);
				sAssertion.assertEquals(accuResponseCode, "ACCU100");

				// Add to excel
				updateExcel(transactionId, cardholder_id, guidString);
				break;
			}

		} catch (UnhandledAlertException e) {
			System.out.println("Handling unexpected popup");

			Alert alert = driver.switchTo().alert();
			System.out.println("Type of alert: " + alert.getText());
			alert.accept();

			ErrorCollector.addVerificationFailure(e);
		}

		log.info(flow + " Completed");
		sAssertion.assertAll();
		System.out.println("Invocation count : " + invocationCount);

	}

	private void updateExcel(String transactionId, String cardholder_id, String guidString) {

		if (transactionId != null) {
			GenericMethods.writingToExcel(XlFileName, RupayTxn, "AuthInitTxnId", invocationCount, transactionId);
			GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "AuthInitTxnId", invocationCount, transactionId);
		}

		if (cardholder_id != null) {
			GenericMethods.writingToExcel(XlFileName, RupayTxn, "RupayTxnId", invocationCount, cardholder_id);
			GenericMethods.writingToExcel(XlFileName, RupayTxnVerify, "RupayTxnId", invocationCount, cardholder_id);
		}

		if (guidString != null) {
			GenericMethods.writingToExcel(XlFileName, RupayTxn, "Guid", invocationCount, guidString);
		}

	}

	private void initCheckOutPage(RupayCheckOutPage checkoutpage, String userId, String password, String cardNumber,
			String expDate, String CVV, String hashKey, String merchantName, String transactionAmount,
			String currencyCode, String transactionId) {

		// System.out.println("UserId:"+userId);
		checkoutpage.getUserID().clear();
		checkoutpage.getUserID().sendKeys(userId);
		// generic.explicitWait(1);

		// System.out.println("Password:"+password);
		checkoutpage.getPassword().clear();
		checkoutpage.getPassword().sendKeys(password);
		// generic.explicitWait(1);

		// System.out.println("CardNumber:"+cardNumber);
		checkoutpage.getCardNumber().clear();
		checkoutpage.getCardNumber().sendKeys(cardNumber);
		// generic.explicitWait(1);

		// System.out.println("ExpDate:"+expDate);
		checkoutpage.getExpDate().clear();
		checkoutpage.getExpDate().sendKeys(expDate);

		// System.out.println("CVV:"+CVV);
		checkoutpage.getCvv().clear();
		checkoutpage.getCvv().sendKeys(CVV);

		// System.out.println("HashKey:"+hashKey);
		checkoutpage.getHashKey().clear();
		checkoutpage.getHashKey().sendKeys(hashKey);

		// System.out.println("MerchantName:"+merchantName);
		checkoutpage.getMerchantName().clear();
		checkoutpage.getMerchantName().sendKeys(merchantName);

		// System.out.println("Transaction Amount:"+transactionAmount);
		checkoutpage.getAmount().clear();
		checkoutpage.getAmount().sendKeys(transactionAmount);

		// System.out.println("CurrencyCode:"+currencyCode);
		checkoutpage.getCurrencyCode().clear();
		checkoutpage.getCurrencyCode().sendKeys(currencyCode);

		checkoutpage.getTransId().clear();
		checkoutpage.getTransId().sendKeys(transactionId);
	}

	

	private void verifyImages(SoftAssert sAssertion) {
		try {
			invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			// System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {

					HttpClient client = HttpClientBuilder.create().build();

					HttpGet request = new HttpGet(imgElement.getAttribute("src"));

					HttpResponse response = client.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						invalidImageCount++;
						// System.out.println("Image :" + imgElement.getAttribute("src") + " : Not
						// displayed");
					} else
						System.out.println("image url: " + imgElement.getAttribute("src"));

					int respCode = response.getStatusLine().getStatusCode();
					String resposeCode = respCode + "";
					sAssertion.assertEquals(resposeCode, "200");
				}
				// System.out.println("Total no. of invalid images are " + invalidImageCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}

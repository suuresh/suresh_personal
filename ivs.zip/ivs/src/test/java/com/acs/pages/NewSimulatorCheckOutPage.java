package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewSimulatorCheckOutPage {
	public WebDriver driver;
	
	public NewSimulatorCheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name = "merchant_id")
	private WebElement merchantIdDropDown;

	@FindBy(name = "cardNo")
	private WebElement cardNumberField;

	@FindBy(name = "expiry")
	private WebElement cardExpiryField;
	
	@FindBy(name = "cvv")
	private WebElement cvvNumberField;

	@FindBy(id = "purchase_amount")
	private WebElement purchaseAmountField;
	
	@FindBy(name = "currency")
	private WebElement currencyDropDown;
	
	@FindBy(xpath = "//select[@id='countryCode']")
	private WebElement countryCodeField;

	@FindBy(name = "acquirerID")
	private WebElement acquirerIDField;
	
	@FindBy(xpath = "//input[@id='merchantAuthRespUrl']")
	private WebElement merchantAuthRespUrlField;
	
	@FindBy(xpath = "//input[@id='versionCheckUrl']")
	private WebElement versionCheckURLFeild;
	
	@FindBy(name = "acquirerBIN")
	private WebElement acquirerBINField;
	                
	@FindBy(xpath = "//button[@id='idForm']")
	private WebElement submitButton;
	
	@FindBy(xpath = "//input[@value='Submit paReq']")
	private WebElement submitPaReqButton;
	
	public WebElement getCountryCodeField() {
		return countryCodeField;
	}

	public WebElement getMerchantAuthRespUrlField() {
		return merchantAuthRespUrlField;
	}

	public WebElement getVersionCheckURLFeild() {
		return versionCheckURLFeild;
	}
	
	public WebElement getSubmitPaReqButton() {
		return submitPaReqButton;
	}

	public WebElement getMerchantIdDropDown() {
		return merchantIdDropDown;
	}

	public WebElement getCardNumberField() {
		return cardNumberField;
	}

	public WebElement getCardExpiryField() {
		return cardExpiryField;
	}

	public WebElement getCvvNumberField() {
		return cvvNumberField;
	}

	public WebElement getPurchaseAmountField() {
		return purchaseAmountField;
	}

	public WebElement getCurrencyDropDown() {
		return currencyDropDown;
	}

	public WebElement getAcquirerIDField() {
		return acquirerIDField;
	}

	public WebElement getAcquirerBINField() {
		return acquirerBINField;
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}
}

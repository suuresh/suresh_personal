package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RupayOTPPage {
	
	public WebDriver driver;

	public RupayOTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@id='AccuCardholderId']")
	private WebElement accuCardholderId;
	
	@FindBy(xpath = "//*[@id='hashKey']")
	private WebElement hashKey;
	
	@FindBy(xpath = "//*[@id='txnId']")
	private WebElement txnId;
	
	@FindBy(xpath = "//*[@value='Send APReq']")
	private WebElement sendAPReqBtn;
	
	@FindBy(xpath="//*[@id='otpValue']")
	private WebElement otpField;
	
	//*[@class='btn btn__submit']
	@FindBy(xpath = "//*[text()='SUBMIT']")
	private WebElement otpSubmitButton;
	
	@FindBy(xpath ="//*[@id = 'resendBtn']")
	private WebElement otpResendButton;	

	@FindBy(xpath ="//*[text()='CANCEL' or @id='otpReset']")
	private WebElement otpCancelButton;
	
	@FindBy(xpath = "//div[@id='challengeErrorDiv']")
	private WebElement resendOTPMessageText;
	
	@FindBy(xpath = "//*[@id='alertBox']")
	private WebElement otpMessage;
	
	@FindBy(xpath ="//*[@id='successMsg']")
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath = "//*[text()='CONTINUE']")
	private WebElement continueButton;
	
	/*******/
	

	@FindBy(xpath="//*[@id=\"enterOtpForm\"]/div/div[2]/text()")
	private WebElement authenticationText;	
	
	@FindBy(xpath ="//button[text()='CONFIRM']")
	private WebElement cardNotRegisteredContinueButton;
	
	
	
	
	

	
	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getAuthenticationText() {
		return authenticationText;
	}

	public WebElement getOtpField() {
		return otpField;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}
	
	
	public WebElement getAccuCardholderId() {
		return accuCardholderId;
	}

	public WebElement getHashKey() {
		return hashKey;
	}

	public WebElement getTxnId() {
		return txnId;
	}

	public WebElement getSendAPReqBtn() {
		return sendAPReqBtn;
	}
	
	public WebElement getResendOTPMessageText() {
		return resendOTPMessageText;
	}
	
	public WebElement getOtpMessage() {
		return otpMessage;
	}
	
	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}
	
	public WebElement getContinueBtn() {
		return continueButton;
	}
	


}

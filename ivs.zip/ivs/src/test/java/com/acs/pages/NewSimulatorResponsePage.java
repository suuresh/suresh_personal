package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewSimulatorResponsePage {
	public WebDriver driver;
	
	public NewSimulatorResponsePage(WebDriver driver) {
		//System.out.println("NewSimulatorResponsePage");
		this.driver = driver;
		PageFactory.initElements(driver, this);
		//System.out.println("NewSimulatorResponsePage");
	}
	
	@FindBy(xpath = "//td[@id='transStatus']")
	private WebElement transactionStatusValue;
	
	@FindBy(xpath = "//td[@id='eci']")
	private WebElement eciValue;
	
	@FindBy(xpath ="//td[@id='cavv']")
	private WebElement CAVVValue;
	
	@FindBy(xpath ="//td[@id='threeDSServerTransID']")
	private WebElement threeDSServerTransID;
	
	@FindBy(xpath ="//td[@id='acsTransID']")
	private WebElement acsTransID;
	
	@FindBy(xpath ="//td[@id='dsTransID']")
	private WebElement dsTransID;

	public WebElement getTransactionStatusValue() {
		return transactionStatusValue;
	}

	public WebElement getEciValue() {
		return eciValue;
	}

	public WebElement getCAVVValue() {
		return CAVVValue;
	}

	public WebElement getThreeDSServerTransID() {
		return threeDSServerTransID;
	}

	public WebElement getAcsTransID() {
		return acsTransID;
	}

	public WebElement getDsTransID() {
		return dsTransID;
	}
	
}

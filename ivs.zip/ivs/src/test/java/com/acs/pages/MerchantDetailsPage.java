package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MerchantDetailsPage {
	
	public WebDriver driver;

	public MerchantDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(xpath="//*[@id='corporateId']")
	private WebElement corporateId;
	
	@FindBy(xpath="//*[@id='employeeId']")
	private WebElement employeeId;	
	
	@FindBy(xpath="//*[@id='alertBox1']")
	private WebElement alertBox1;

	@FindBy(xpath="//*[@id='alertBox2']")
	private WebElement alertBox2;
	
	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement submitButton;
	
	@FindBy(xpath = "//*[text()='Cancel']")
	private WebElement cancelButton;
	
	@FindBy(xpath="//*[@class='success']")
	private WebElement successMessage;
	
	@FindBy(xpath="//*[@id='id_truebtn']")
	private WebElement yesBtn;
	
			
	public WebElement getCorporateId() {
		return corporateId;
	}
	
	public WebElement getEmployeeId() {
		return employeeId;
	}
	public WebElement getAlertBox1() {
		return alertBox1;
	}
	
	public WebElement getAlertBox2() {
		return alertBox2;
	}
	public WebElement getSubmitButton() {
		return submitButton;
	}
	
	public WebElement getCancelButton() {
		return cancelButton;
	}
	
	public WebElement getSuccessMessage() {
		return successMessage;
	}
	
	public WebElement getYesBtn() {
		return yesBtn;
	}
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCardDetailsPage {
	
	public WebDriver driver;
    
	public AddCardDetailsPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	
	@FindBy(id="pan")
	private WebElement accountNumberField;

	@FindBy(id="bankid")
	private WebElement bankIdField;
	
	//@FindBy(id="phone")
	@FindBy(xpath="(//input[@type='text'])[2]")
	private WebElement mobileNumberField;
	
	@FindBy(id="resp")
	private WebElement responseField;
	
	@FindBy(xpath="//button[text()='send']")
	private WebElement sendButton;

	public WebElement getAccountNumberField() {
		return accountNumberField;
	}

	public WebElement getBankIdField() {
		return bankIdField;
	}

	public WebElement getMobileNumberField() {
		return mobileNumberField;
	}

	public WebElement getResponseField() {
		return responseField;
	}

	public WebElement getSendButton() {
		return sendButton;
	}

}
package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

	public class CardEncryptHomePage
		{
		    public WebDriver driver;
		    
			public CardEncryptHomePage(WebDriver driver){
				this.driver=driver;
				PageFactory.initElements(driver,this);
			}
			
			@FindBy(name="card_number")
			private WebElement enNDcryptTextField;
			
			@FindBy(xpath="//*[@id=\"form-div\"]/form/p[3]/select")
			private WebElement selectDrpDwon;
			
			@FindBy(xpath="//*[@id=\"form-div\"]/form/p[3]/select/option[1]")
			private WebElement SelectEncryptOption;

			@FindBy(xpath="//*[@id=\"form-div\"]/form/p[3]/select/option[2]")
			private WebElement SelectDcryptOption;
			
			@FindBy(xpath="//*[@id=\"form-div\"]/form/div/input")
			private WebElement submitButton;
			              
		//	@FindBy(xpath="//pre[contains(text(),'{\"Result \":\"')]")
			
			@FindBy(xpath="//pre[contains(text(),'{\"Result \":\"')]")
			private WebElement enOrDcryptResult;
			
			@FindBy(xpath="//*[@name=\"bank_id\"]")
			private WebElement bankIdTextField;

			
			public WebElement getBankIdTextField() {
				return bankIdTextField;
			}

			public WebElement getEnNDcryptTextField() {
				return enNDcryptTextField;
			}

			public WebElement getSubmitButton() {
				return submitButton;
			}

			public WebElement getSelectDrpDwon() {
				return selectDrpDwon;
			}

			public WebElement getSelectEncryptOption() {
				return SelectEncryptOption;
			}

			public WebElement getSelectDcryptOption() {
				return SelectDcryptOption;
			}

			public WebElement getEnOrDcryptResult() {
				return enOrDcryptResult;
			}


	}

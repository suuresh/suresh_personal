package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RupayCheckOutPage {
	public WebDriver driver;

	public RupayCheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@id='userID']")
	private WebElement userID;
	
	@FindBy(xpath = "//input[@id='password']")
	private WebElement password;
	
	@FindBy(xpath = "//input[@id='cardNumber']")
	private WebElement cardNumber;
	
	@FindBy(xpath = "//input[@id='expDate']")
	private WebElement expDate;
	
	@FindBy(xpath = "//input[@id='cvv']")
	private WebElement cvv;
	
	@FindBy(xpath = "//input[@id='hashKey']")
	private WebElement hashKey;
	
	@FindBy(xpath = "//input[@id='merchantName']")
	private WebElement merchantName;
	
	@FindBy(xpath = "//input[@id='amount']")
	private WebElement amount;
	
	@FindBy(xpath = "//input[@id='currencyCode']")
	private WebElement currencyCode;
	
	@FindBy(xpath = "//input[@id='transId']")
	private WebElement transId;
	
	@FindBy(xpath = "//input[@value='Transaction']")
	private WebElement transactionBtn;
	
	@FindBy(xpath = "//textarea[@id='resposeData']")
	private WebElement resposeData;
	
	@FindBy(xpath = "//button[normalize-space()='Auth-Result']")
	private WebElement authResultBtn;
	
	@FindBy(xpath = "//textarea[@id='authResponseData']")
	private WebElement authResponseData;

	@FindBy(xpath = "//input[@id='guid']")
	private WebElement guid;

	
	public WebElement getPassword() {
		return password;
	}

	public WebElement getCardNumber() {
		return cardNumber;
	}

	public WebElement getExpDate() {
		return expDate;
	}

	public WebElement getCvv() {
		return cvv;
	}

	public WebElement getHashKey() {
		return hashKey;
	}

	public WebElement getMerchantName() {
		return merchantName;
	}

	public WebElement getAmount() {
		return amount;
	}

	public WebElement getCurrencyCode() {
		return currencyCode;
	}

	public WebElement getTransId() {
		return transId;
	}

	public WebElement getTransactionBtn() {
		return transactionBtn;
	}

	public WebElement getResposeData() {
		return resposeData;
	}

	public WebElement getAuthResultBtn() {
		return authResultBtn;
	}

	public WebElement getAuthResponseData() {
		return authResponseData;
	}

	public WebElement getUserID() {
		return userID;
	}
	
	public WebElement getGuid() {
		return guid;
	}

}

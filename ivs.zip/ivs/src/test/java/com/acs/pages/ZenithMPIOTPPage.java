package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ZenithMPIOTPPage {
	public WebDriver driver;

	public ZenithMPIOTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='flex-item1']//img")
	private WebElement bankLogo;

	@FindBy(xpath = "//div[@class='flex-item2']//img")
	private WebElement cardUnionLogo;

	@FindBy(xpath = "//h1[contains(text(),'Purchase Authentication')]")
	private WebElement purchaseAuthenticationHeading;

	@FindBy(xpath = "//p[@class='hei mid-content']")
	private WebElement purchaseAuthenticationText;

	@FindBy(xpath = "//label[@class='lbl1']")
	private WebElement otpTextFieldLabel;

	@FindBy(xpath = "//*[contains(@class,'otpValue_Automate') or @name='otpValue' or @id='otpValue']")
	private WebElement otpTextField;

	@FindBy(xpath = "//input[@name='acctId']")
	private WebElement acsTxnIdXpath;

	/******** Tymeleaf webElements ********/
	@FindBy(xpath = "//*[contains(@class,'submit_Automate') or @id='submitBtn' or @type='submit']")
	private WebElement tmlotpSubmitButton;
	
	@FindBy(xpath = "//*[@id='submitBtn']")
	private WebElement tmlotpCIBSubmitButton;

	public WebElement getTmlotpCIBSubmitButton() {
		return tmlotpCIBSubmitButton;
	}

	@FindBy(xpath = "//*[text()='Continue' or text()='CONTINUE']")
	private WebElement tmlCCContinueButton;

	public WebElement getTmlCCContinueButton() {
		return tmlCCContinueButton;
	}

	@FindBy(xpath = "//*[contains(@class,'reSendOtp_Automate') or contains(@href,'resend_otp')or @ id='otpResend' or @id='reSend']")
	private WebElement tmlotpResendButton;

	@FindBy(xpath = "//*[contains(text(),'CANCEL')or @id='cancelBtn' or @id='otpReset']")
	private WebElement tmlotpCancelButton;

	/******** Rocker webElements ********/
	@FindBy(className = "submit")
	private WebElement rkrotpSubmitButton;

	@FindBy(xpath = "//*[contains(@class,'reSendOtp_Automate') or contains(@href,'resend_otp')or @id='resendButton' or@ id='otpResend' or @id='reSend']")
	private WebElement rkrotpResendButton;

	@FindBy(xpath = "//*[contains(text(),'CANCEL')or @id='cancelBtn' or @id='cancelButton'or@id='otpReset']")
	private WebElement rkrotpCancelButton;

	/*** Rocker elments *****/

	@FindBy(xpath = "//span[@class='timer-cls']")
	private WebElement otpPageTimerAlertText;

	@FindBy(xpath = "//span[@class='need-help']")
	private WebElement otpPageHelpText;

	@FindBy(xpath = "//div[@id='myDIV']")
	private WebElement contactBankText;

	@FindBy(xpath = "//*[contains(@class,'continue_Automate') or text()='Continue' or text()='Close' or text()='CONTINUE']")
	private WebElement cardNotRegisteredContinueButton;

	@FindBy(xpath = "//p[@class='hei mid-content']")
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath = "//*[@id='customerDiv']")
	private WebElement karnatakaCardNotRegText;

	public WebElement getKarnatakaCardNotRegText() {
		return karnatakaCardNotRegText;
	}

	@FindBy(xpath = "//button[normalize-space()='CONTINUE']")
	private WebElement cardBlockedContinueButton;

	@FindBy(xpath = "//p[@class='hei mid-content']")
	private WebElement cardBlockedText;

	@FindBy(xpath = "//P[@class='mid-content']")
	private WebElement invalidOTPMessage;

	@FindBy(xpath = "//P[@class='mid-content']")
	private WebElement resendOTPMessage;

	@FindBy(xpath = "//span[@id='alertBox']")
	private WebElement kenyaBlankOtp;

	@FindBy(xpath = "//div[@class='err-container']")
	private WebElement AusfBlankOtp;

	@FindBy(xpath = "//*[@class='hei mid-content']")
	private WebElement AusfWrongOtp;
	
	@FindBy(xpath = "//*[@id='challengeInfoTextDiv']")
	private WebElement CIBOtpExpire;

	public WebElement getCIBOtpExpire() {
		return CIBOtpExpire;
	}

	public WebElement getAusfWrongOtp() {
		return AusfWrongOtp;
	}

	public WebElement getAusfBlankOtp() {
		return AusfBlankOtp;
	}

	/********* RBL Landing page specific web elements ***************************/

	@FindBy(xpath = "//button[@id='btn-cancel']")
	private WebElement rblLandingPageCancelButton;

	@FindBy(xpath = "//button[@id='ContinueWeb']")
	private WebElement rblLandingPageContinueButton;

	@FindBy(xpath = "//a[contains(text(),'Website link')]")
	private WebElement rblLandingPageWebLink;

	@FindBy(xpath = "//form[@id='enterDeviceForm']/p")
	private WebElement rblLandingPageText;
	
	@FindBy(xpath="//*[@id='englishLang']")
	private WebElement englishLangNBEbank;
	
	@FindBy(xpath="//p[@class='err-container' or @class='text_left']")
	private WebElement NBEblankOtptext;
				 
	public WebElement getNBEblankOtptext() {
		return NBEblankOtptext;
	}

	public WebElement getEnglishLangNBEbank() {
		return englishLangNBEbank;
	}


	public WebElement getRblLandingPageText() {
		return rblLandingPageText;
	}

	public WebElement getRblLandingPageCancelButton() {
		return rblLandingPageCancelButton;
	}

	public WebElement getRblLandingPageContinueButton() {
		return rblLandingPageContinueButton;
	}

	public WebElement getRblLandingPageWebLink() {
		return rblLandingPageWebLink;
	}

	/**************** RBL Landiong page specific Web Elements ends *************/

	public WebElement getKenyaBlankOtp() {
		return kenyaBlankOtp;
	}

	public WebElement getBankLogo() {
		return bankLogo;
	}

	public WebElement getCardUnionLogo() {
		return cardUnionLogo;
	}

	public WebElement getPurchaseAuthenticationHeading() {
		return purchaseAuthenticationHeading;
	}

	public WebElement getPurchaseAuthenticationText() {
		return purchaseAuthenticationText;
	}

	public WebElement getOtpTextFieldLabel() {
		return otpTextFieldLabel;
	}

	public WebElement getOtpTextField() {
		return otpTextField;
	}

	public WebElement getAcsTxnIdXpath() {
		return acsTxnIdXpath;
	}

	public WebElement getTmlotpSubmitButton() {
		return tmlotpSubmitButton;
	}

	public WebElement getTmlotpResendButton() {
		return tmlotpResendButton;
	}

	public WebElement getTmlotpCancelButton() {
		return tmlotpCancelButton;
	}

	public WebElement getRkrotpSubmitButton() {
		return rkrotpSubmitButton;
	}

	public WebElement getRkrotpResendButton() {
		return rkrotpResendButton;
	}

	public WebElement getRkrotpCancelButton() {
		return rkrotpCancelButton;
	}

	public WebElement getOtpPageTimerAlertText() {
		return otpPageTimerAlertText;
	}

	public WebElement getOtpPageHelpText() {
		return otpPageHelpText;
	}

	public WebElement getContactBankText() {
		return contactBankText;
	}

	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}

	public WebElement getCardBlockedContinueButton() {
		return cardBlockedContinueButton;
	}

	public WebElement getCardBlockedText() {
		return cardBlockedText;
	}

	public WebElement getInvalidOTPMessage() {
		return invalidOTPMessage;
	}

	public WebElement getResendOTPMessage() {
		return resendOTPMessage;
	}

}

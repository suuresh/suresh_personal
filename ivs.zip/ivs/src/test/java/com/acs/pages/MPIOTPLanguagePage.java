package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MPIOTPLanguagePage {
	public WebDriver driver;

	public MPIOTPLanguagePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "langSwtich")
	private WebElement languageDropDown;

	@FindBy(id = "otp")
	private WebElement otpEnterTextBox;
	
	@FindBy(id = "first")
	private WebElement otpTextFirstCharField;
	
	@FindBy(id = "second")
	private WebElement otpTextSecondCharField;
	
	@FindBy(id = "third")
	private WebElement otpTextThirdCharField;
	
	@FindBy(id = "fourth")
	private WebElement otpTextFourthCharField;
	
	@FindBy(id = "fifth")
	private WebElement otpTextFifthCharField;
	
	@FindBy(id = "sixth")
	private WebElement otpTextSixthCharField;
	
	@FindBy(id = "submitBtn")
	private WebElement otpEnglishSubmitButton;
	
	@FindBy(id = "submitBtn_arabic")
	private WebElement otpArabicSubmitButton;
	
	@FindBy(id = "arabicResendBtn")
	private WebElement otpEnglishReSendButton;
	
	@FindBy(id = "arabic_btn_div")
	private WebElement otpArabicReSendButton;
	
	@FindBy(xpath = "(//p[@class='challengeInfotext'])[1]")
	private WebElement otpChallengeInfoText;
	
	@FindBy(xpath = "//input[@name='acctId']")
	private WebElement acsTxnIdElement;

	public WebElement getOtpChallengeInfoText() {
		return otpChallengeInfoText;
	}

	public WebElement getAcsTxnIdElement() {
		return acsTxnIdElement;
	}

	public WebElement getLanguageDropDown() {
		return languageDropDown;
	}

	public WebElement getOtpEnterTextBox() {
		return otpEnterTextBox;
	}

	public WebElement getOtpTextFirstCharField() {
		return otpTextFirstCharField;
	}

	public WebElement getOtpTextSecondCharField() {
		return otpTextSecondCharField;
	}

	public WebElement getOtpTextThirdCharField() {
		return otpTextThirdCharField;
	}

	public WebElement getOtpTextFourthCharField() {
		return otpTextFourthCharField;
	}

	public WebElement getOtpTextFifthCharField() {
		return otpTextFifthCharField;
	}

	public WebElement getOtpTextSixthCharField() {
		return otpTextSixthCharField;
	}

	public WebElement getOtpEnglishSubmitButton() {
		return otpEnglishSubmitButton;
	}

	public WebElement getOtpArabicSubmitButton() {
		return otpArabicSubmitButton;
	}

	public WebElement getOtpEnglishReSendButton() {
		return otpEnglishReSendButton;
	}

	public WebElement getOtpArabicReSendButton() {
		return otpArabicReSendButton;
	}
	

}

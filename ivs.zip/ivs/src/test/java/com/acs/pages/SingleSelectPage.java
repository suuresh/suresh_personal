package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SingleSelectPage {
	
	public WebDriver driver;

	public SingleSelectPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id=\"singleSelectAppForm\"]/div/div[3]/div[1]/div/input[1]")
	private WebElement emailRadioButton;
	
	@FindBy(xpath = "//*[@id=\"singleSelectAppForm\"]/div/div[3]/div[1]/div/input[2]")
	private WebElement mobileRadioButton;
	
	@FindBy(id="submit")
	private WebElement nextButton;

	
	public WebElement getEmailRadioButton() {
		return emailRadioButton;
	}

	public WebElement getMobileRadioButton() {
		return mobileRadioButton;
	}

	public WebElement getNextButton() {
		return nextButton;
	}

	
	
	
	
	
	
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AUSFOTPPage {
	
	public WebDriver driver;

	public AUSFOTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id=\"enterOtpForm\"]/div/div[2]/text()")
	private WebElement authenticationText;
	
	@FindBy(xpath="//*[@id=\"otpValue\" or @name='otpValueSoftware']")
	private WebElement otpField;
	
	//*[@id="enterOtpForm"]/div[1]/button
	@FindBy(xpath = "//*[@id=\"submitBtn\"]")
	private WebElement otpSubmitButton;
	
	@FindBy(id = "otpResend")
	private WebElement otpResendButton;
	
	//@FindBy(id ="cancelButton")
	@FindBy(id ="otpReset")
	private WebElement otpCancelButton;
	
	@FindBy(xpath ="//button[text()='CONFIRM']")
	private WebElement cardNotRegisteredContinueButton;
	
	@FindBy(xpath ="//*[@class='hei mid-content cust' or @class='hei mid-content']")	
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath = "//*[@id='challengeInfoTextDiv' or @id='challengeInfoText']")
	private WebElement challengeInfoText;
	
	@FindBy(xpath = "//*[@id='messagesPort' or @id='maxResendText']")
	private WebElement messagesPortText;
	
	@FindBy(xpath = "(//*[@id='challengeInfoTextDiv'])[1]")
	private WebElement otpChallengeInfoText;

	
	
	@FindBy(xpath = "//button[text()='CONTINUE']")
	private WebElement continueButton;
	
	@FindBy(xpath = "//div[@class='err-container']")
	private WebElement errorText;
	
	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getAuthenticationText() {
		return authenticationText;
	}

	public WebElement getOtpField() {
		return otpField;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}

	public WebElement getContinueBtn() {
		return continueButton;
	}
	
	public WebElement getErrorText() {
		return errorText;
	}
	
	public WebElement getMessagePortText() {
		return messagesPortText;
	}
	
	public WebElement getChallengeInfoText() {
		return challengeInfoText;
	}
	
	public WebElement getOtpChallengeInfoText() {
		return otpChallengeInfoText;
	}
	
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MPICheckOutPage {
	public WebDriver driver;

	public MPICheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@name='pan']")
	private WebElement cardNumberField;
	
	@FindBy(xpath = "//select[@name='merchant_id']")
	private WebElement merchantTextField;
	
	@FindBy(xpath = "//input[@name='expiry']")
	private WebElement cardExpiryField;
	
	@FindBy(xpath = "//input[@name='cvv']")
	private WebElement cardCVVField;
	
	@FindBy(xpath = "//input[@name='qty']")
	private WebElement quantityField;
	
	@FindBy(xpath = "//input[@name='purchase_amount']")
	private WebElement purchaseAmountField;
	
	public WebElement getQuantityField() {
		return quantityField;
	}

	public WebElement getPurchaseAmountField() {
		return purchaseAmountField;
	}

	public WebElement getCurrencyField() {
		return currencyField;
	}

	@FindBy(xpath = "//select[@name='currency']")
	private WebElement currencyField;
	
	@FindBy(xpath = "//body//td[@class='mainText']//td//td[1]//input[1]")
	private WebElement submitButton;

	public WebElement getCardNumberField() {
		return cardNumberField;
	}

	public WebElement getMerchantTextField() {
		return merchantTextField;
	}

	public WebElement getCardExpiryField() {
		return cardExpiryField;
	}

	public WebElement getCardCVVField() {
		return cardCVVField;
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MPIResponsePage {
	public WebDriver driver;

	public MPIResponsePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/*********For Successful Transaction final response page. *********/
	//table[1]//table[1]//table[1]//br[2]
	@FindBy(xpath="//blockquote[1]/center[1]")
	private WebElement successTransactionStatus;
	
	@FindBy(xpath="//blockquote/center/text()[4]")
	private WebElement successTransactionECICode;
	
	@FindBy(xpath="//blockquote/center/text()[6]")
	private WebElement successTransactionId;
	
	@FindBy(xpath="//blockquote/center/b[1]/font")
	private WebElement successTransactionIdText;
	
	@FindBy(xpath="//blockquote/center/text()[5]")
	private WebElement successTransactionXID;
		
	@FindBy(xpath="//blockquote/center/text()[7]")
	private WebElement successTransactionVerifiedStatus;
	
	@FindBy(xpath="//blockquote/center/text()[10]")
	private WebElement successTransactionPAResStatus;
	
	@FindBy(xpath="//blockquote/center/b[2]/font")
	private WebElement successTransactionCAVVText;
	
	@FindBy(xpath="//blockquote/center/text()[12]")
	private WebElement successTransactionPARESSyntaxText;

	@FindBy(xpath="//blockquote/center/text()[15]")
	private WebElement successTransactionPARESErrorNullText;
	
	
	/********** For Canceled Transactionn final response page ********************/
	
	@FindBy(xpath="//blockquote/center/text()[3]")
	private WebElement cancelTransactionStatus;
	
	@FindBy(xpath="//blockquote/center/text()[4]")
	private WebElement cancelTransactionECICode;
	
	@FindBy(xpath="//blockquote/center/text()[5]")
	private WebElement cancelTransactionId;
	
	@FindBy(xpath="//blockquote/center/b[1]/font")
	private WebElement cancelTransactionIdText;
	
	@FindBy(xpath="//blockquote/center/text()[6]")
	private WebElement cancelTransactionXID;
		
	@FindBy(xpath="//blockquote/center/text()[7]")
	private WebElement cancelTransactionVResStatus;
	
	@FindBy(xpath="//blockquote/center/text()[8]")
	private WebElement cancelTransactionPAResStatus;
	
	@FindBy(xpath="//blockquote/center/text()[9]")
	private WebElement cancelTransactionPAResVerified;
	
	@FindBy(xpath="//blockquote/center/text()[10]")
	private WebElement cancelTransactionErrorCode;
	
	@FindBy(xpath="//blockquote/center/text()[11]")
	private WebElement cancelTransactionErrorMessage;
	
	@FindBy(xpath="//blockquote/center/text()[12]")
	private WebElement cancelTransactionMessgeHASH;

	@FindBy(xpath="//blockquote/center/text()[15]")
	private WebElement cancelTransactionPARESErrorNullText;

	public WebElement getSuccessTransactionStatus() {
		return successTransactionStatus;
	}

	public WebElement getSuccessTransactionECICode() {
		return successTransactionECICode;
	}

	public WebElement getSuccessTransactionId() {
		return successTransactionId;
	}

	public WebElement getSuccessTransactionIdText() {
		return successTransactionIdText;
	}

	public WebElement getSuccessTransactionXID() {
		return successTransactionXID;
	}

	public WebElement getSuccessTransactionVerifiedStatus() {
		return successTransactionVerifiedStatus;
	}

	public WebElement getSuccessTransactionPAResStatus() {
		return successTransactionPAResStatus;
	}

	public WebElement getSuccessTransactionCAVVText() {
		return successTransactionCAVVText;
	}

	public WebElement getSuccessTransactionPARESSyntaxText() {
		return successTransactionPARESSyntaxText;
	}

	public WebElement getSuccessTransactionPARESErrorNullText() {
		return successTransactionPARESErrorNullText;
	}

	public WebElement getCancelTransactionStatus() {
		return cancelTransactionStatus;
	}

	public WebElement getCancelTransactionECICode() {
		return cancelTransactionECICode;
	}

	public WebElement getCancelTransactionId() {
		return cancelTransactionId;
	}

	public WebElement getCancelTransactionIdText() {
		return cancelTransactionIdText;
	}

	public WebElement getCancelTransactionXID() {
		return cancelTransactionXID;
	}

	public WebElement getCancelTransactionVResStatus() {
		return cancelTransactionVResStatus;
	}

	public WebElement getCancelTransactionPAResStatus() {
		return cancelTransactionPAResStatus;
	}

	public WebElement getCancelTransactionPAResVerified() {
		return cancelTransactionPAResVerified;
	}

	public WebElement getCancelTransactionErrorCode() {
		return cancelTransactionErrorCode;
	}

	public WebElement getCancelTransactionErrorMessage() {
		return cancelTransactionErrorMessage;
	}

	public WebElement getCancelTransactionMessgeHASH() {
		return cancelTransactionMessgeHASH;
	}

	public WebElement getCancelTransactionPARESErrorNullText() {
		return cancelTransactionPARESErrorNullText;
	}
		
	
}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PgResponsePage {
	
	
	public WebDriver driver;

	public PgResponsePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/*@FindBy(xpath = "/html/body/table/tbody/tr[1]/td[2]")
	private WebElement transactionStatusValue;
	
	@FindBy(xpath = "/html/body/table/tbody/tr[2]/td[2]")
	private WebElement eciValue;
	
	@FindBy(xpath ="/html/body/table/tbody/tr[4]/td[2]")
	private WebElement mpiErrorCodeValue;
	
	@FindBy(xpath ="/html/body/table/tbody/tr[6]/td[2]")
	private WebElement vresStatusValue;
	
	@FindBy(xpath ="/html/body/table/tbody/tr[7]/td[2]")
	private WebElement paresStatusValue;
	*/
	
	/*@FindBy(xpath = "//tr[td[text()='Status']]/td[3]")
	private WebElement transactionStatusValue;
	
	@FindBy(xpath = "//tr[td[text()='ECI']]/td[3]")
	private WebElement eciValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorCode']]/td[3]")
	private WebElement errorCodeValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorDesc']]/td[3]")
	private WebElement errorDescValue;
	
	@FindBy(xpath ="//tr[td[text()='CAVV']]/td[3]")
	private WebElement CAVVValue;
	
	@FindBy(xpath ="//tr[td[contains(text(),'ARes')]]/td[3]")
	private WebElement aresStatusValue;

	@FindBy(xpath ="//tr[td[contains(text(),'RReq')]]/td[3]")
	private WebElement rReqStatusValue;

	*/
	//T-Shirt final page
	@FindBy(xpath = "//tr[td[text()='Status']]/td[2]")
	private WebElement transactionStatusValue;
	
	@FindBy(xpath = "//tr[td[text()='ECI']]/td[2]")
	private WebElement eciValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorCode']]/td[2]")
	private WebElement errorCodeValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorDesc']]/td[2]")
	private WebElement errorDescValue;
	
	@FindBy(xpath ="//tr[td[text()='CAVV']]/td[2]")
	private WebElement CAVVValue;
	
	@FindBy(xpath ="//tr[td[contains(text(),'ARes')]]/td[2]")
	private WebElement aresStatusValue;

	@FindBy(xpath ="//tr[td[contains(text(),'RReq')]]/td[2]")
	private WebElement rReqStatusValue;

	
	public WebElement getAresStatusValue() {
		return aresStatusValue;
	}

	public WebElement getErrorCodeValue() {
		return errorCodeValue;
	}
	
	public WebElement getErrorDescValue() {
		return errorDescValue;
	}

	public WebElement getRreqStatusValue() {
		return rReqStatusValue;
	}
	
	public WebElement getCavvValue() {
		return CAVVValue;
	}

	public WebElement getTransactionStatusValue() {
		return transactionStatusValue;
	}

	public WebElement getEciValue() {
		return eciValue;
	}
	
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EMIOTPPage {
	public WebDriver driver;
	
	public EMIOTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@class='flex-item1']//img")
	private WebElement bankLogo;
	
	@FindBy(xpath="//div[@class='flex-item2']//img")
	private WebElement cardUnionLogo;
	
	
	@FindBy(xpath="//label[@class='lbl1']")
	private WebElement otpTextFieldLabel;
	
	@FindBy(xpath="//form[@id='otpPin']//input[@name='otpPinValue']")
	private WebElement otpTextField;
	
						
	@FindBy(xpath="//form[@id='otpPin']//button[text()='CONFIRM']")
	private WebElement otpSubmitButton;
	
	@FindBy(xpath="//*[@id='otpResend' or @id='resendButton']")
	private WebElement otpResendButton;
	
	@FindBy(xpath="//*[@id='cancelButton' or @ id='otpReset' or @id='cancelBtn']")
	private WebElement otpCancelButton;
 
	@FindBy(xpath ="//button[@class='submit' or @id='submitBtn']") 
	private WebElement cardNotRegisteredContinueButton;
	
	@FindBy(xpath ="//p[@class='hei mid-content' or @id='challengeInfoText']")
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath ="//*[text()='Continue' or text()='CONTINUE']")
	private WebElement cardBlockedContinueButton;
	
	@FindBy(xpath ="//p[@class='hei mid-content']")
	private WebElement cardBlockedText;
	
	@FindBy(xpath="//p[@class='hei mid-content challengeInfoText' or @id='challengeInfoTextDiv' or @class='hei mid-content']")	
	private WebElement invalidOTPMessage;
	
	@FindBy(xpath="//p[@class='hei mid-content' or @id='resendInfoTextDiv']")
	private WebElement resendOTPMessage;
	
	@FindBy(xpath="(//*[@class='hei mid-content' or @class='sub_line' or@id='resendInfoTextDiv'])[1]")
	private WebElement cibResendOTPMessage;
	
	@FindBy(xpath = "//p[@id='challengeInfoText']")
	private WebElement otpExpiredMessage;
	
	@FindBy(xpath = "//div[@class='err-container']")
	private WebElement errorText;
	
	public WebElement getCibResendOTPMessage() {
		return cibResendOTPMessage;
	}
	
	@FindBy(xpath="//*[@id='englishLang']")
	private WebElement englishLangNBEbank;
	
	@FindBy(xpath="//p[@class='err-container']")
	private WebElement NBEblankOtptext;

	//HSBC INDIA Cusotmer care page text xpaths.
	
	@FindBy(xpath="//p[1]/span[1]")
	private WebElement hsbcCCPageText;
	
	@FindBy(xpath="//p[1]")
	private WebElement hsbcInactiveCardText;
	
	
	@FindBy(xpath = "//ul[@id='emiList']/li[1]")
	private WebElement sixMonthsEmiOption;
	
	@FindBy(xpath = "//input[@value='6']/following-sibling::p/span[2]")
	private WebElement sixMonthsEmiValue;
	
	@FindBy(xpath = "//ul[@id='emiList']/li[2]")
	private WebElement twelveMonthsEmiOption;
	
	@FindBy(xpath = "//input[@value='12']/following-sibling::p/span[2]")
	private WebElement twelveMonthsEmiValue;
	
	@FindBy(xpath = "//ul[@id='emiList']/li[3]")
	private WebElement twentyfourMonthsEmiOption;
	
	@FindBy(xpath = "//input[@value='24']/following-sibling::p/span[2]")
	private WebElement twentyfourMonthsEmiValue;
	
	
	@FindBy(xpath = "//input[@id='confirmEmi']")
	private WebElement confirmEmi;
	
	
	
	public WebElement getConfirmEmi() {
		return confirmEmi;
	}

	public WebElement getOtpExpiredMessage() {
		return otpExpiredMessage;
	}

	public WebElement getSixMonthsEmiOption() {
		return sixMonthsEmiOption;
	}

	public WebElement getSixMonthsEmiValue() {
		return sixMonthsEmiValue;
	}

	public WebElement getTwelveMonthsEmiOption() {
		return twelveMonthsEmiOption;
	}

	public WebElement getTwelveMonthsEmiValue() {
		return twelveMonthsEmiValue;
	}

	public WebElement getTwentyfourMonthsEmiOption() {
		return twentyfourMonthsEmiOption;
	}

	public WebElement getTwentyfourMonthsEmiValue() {
		return twentyfourMonthsEmiValue;
	}

	public WebElement getHsbcInactiveCardText() {
		return hsbcInactiveCardText;
	}

	@FindBy(xpath="//button[@id='submitBtn']")
	private WebElement hsbcCCContinueButton;

	public WebElement getHsbcCCPageText() {
		return hsbcCCPageText;
	}

	public WebElement getHsbcCCContinueButton() {
		return hsbcCCContinueButton;
	}

	public WebElement getNBEblankOtptext() {
		return NBEblankOtptext;
	}

	public WebElement getEnglishLangNBEbank() {
		return englishLangNBEbank;
	}

	public WebElement getBankLogo() {
		return bankLogo;
	}

	public WebElement getCardUnionLogo() {
		return cardUnionLogo;
	}

	
	
	public WebElement getOtpTextFieldLabel() {
		return otpTextFieldLabel;
	}

	public WebElement getOtpTextField() {
		return otpTextField;
	}

	
	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}

	public WebElement getCardBlockedContinueButton() {
		return cardBlockedContinueButton;
	}

	public WebElement getCardBlockedText() {
		return cardBlockedText;
	}

	public WebElement getInvalidOTPMessage() {
		return invalidOTPMessage;
	}

	public WebElement getResendOTPMessage() {
		return resendOTPMessage;
	}
	
	public WebElement getOTPExpiredMessage(){
		return otpExpiredMessage;
	}
	
	public WebElement getErrorText() {
		return errorText;
	}
}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MultiSelectPage {
	
	public WebDriver driver;

	public MultiSelectPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id='selectedValue'][1]")
	private WebElement puneCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][2]")
	private WebElement delhiCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][3]")
	private WebElement chennaiCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][4]")
	private WebElement dalaCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][5]")
	private WebElement bangaloreCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][6]")
	private WebElement mysoreCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][7]")
	private WebElement andraCheckBox;
	
	@FindBy(xpath="//*[@id='selectedValue'][8]")
	private WebElement orisaCheckBox;

	@FindBy(id="submit")
	private WebElement nextButton;
	
	
	public WebElement getNextButton() {
		return nextButton;
	}

	public WebElement getPuneCheckBox() {
		return puneCheckBox;
	}

	public WebElement getDelhiCheckBox() {
		return delhiCheckBox;
	}

	public WebElement getChennaiCheckBox() {
		return chennaiCheckBox;
	}

	public WebElement getBangaloreCheckBox() {
		return bangaloreCheckBox;
	}

	public WebElement getDalaCheckBox() {
		return dalaCheckBox;
	}

	public WebElement getMysoreCheckBox() {
		return mysoreCheckBox;
	}

	public WebElement getAndraCheckBox() {
		return andraCheckBox;
	}

	public WebElement getOrisaCheckBox() {
		return orisaCheckBox;
	}
	

	

}

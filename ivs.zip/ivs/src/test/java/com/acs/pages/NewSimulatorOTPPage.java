package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewSimulatorOTPPage {
	public WebDriver driver;
	
	public NewSimulatorOTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@class='flex-item1']//img")
	private WebElement bankLogo;
	
	@FindBy(xpath="//div[@class='flex-item2']//img")
	private WebElement cardUnionLogo;
	
	@FindBy(xpath="//h1[contains(text(),'Purchase Authentication')]")
	private WebElement purchaseAuthenticationHeading;
	
	@FindBy(xpath="//p[@class='hei mid-content']")
	private WebElement purchaseAuthenticationText;
	
	@FindBy(xpath="//label[@class='lbl1']")
	private WebElement otpTextFieldLabel;
	
	@FindBy(xpath="//input[@id='otpValue' or @name='otpValue' or @name='otpValueSoftware']")
	private WebElement otpTextField;
	
	@FindBy(xpath="//input[@name='acctId']")
	private WebElement acsTxnIdXpath;
						
	@FindBy(xpath="//*[@id='submitBtn' or @id='submitBtn1' or @class='submit']")
	private WebElement otpSubmitButton;
	
	@FindBy(xpath="//*[@id='otpResend' or @id='reSend' or @id='resendButton']")
	private WebElement otpResendButton;
	
	@FindBy(xpath="//*[@id='cancelButton' or @class='btn cancel__btn' or @ id='otpReset' or @id='cancelBtn']")
	private WebElement otpCancelButton;
	
	@FindBy(xpath ="//span[@class='timer-cls']")
	private WebElement otpPageTimerAlertText;
		
	@FindBy(xpath ="//span[@class='need-help']")
	private WebElement otpPageHelpText;
	
	@FindBy(xpath ="//div[@id='myDIV']")
	private WebElement contactBankText;
		
//	@FindBy(xpath ="//button[@class='submit']") 
//	private WebElement cardNotRegisteredContinueButton;
//	 
	@FindBy(xpath ="//button[@class='submit' or @id='submitBtn']") 
	private WebElement cardNotRegisteredContinueButton;
	
	@FindBy(xpath ="//p[@class='hei mid-content' or @id='challengeInfoText']")
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath ="//*[text()='Continue' or text()='CONTINUE']")
	private WebElement cardBlockedContinueButton;
	
	@FindBy(xpath ="//*[text()='CANCEL']")
	private WebElement cancelTxnBtn;
	
	@FindBy(xpath ="//p[@class='hei mid-content']")
	private WebElement cardBlockedText;
	
	@FindBy(xpath="//*[@class='hei mid-content challengeInfoText' or @id='challengeInfoTextOtp' or @id='challengeInfoTextDiv' or @class='hei mid-content']")	
	private WebElement invalidOTPMessage;
	
	@FindBy(xpath="//*[@class='hei mid-content' or @id='challengeInfoTextOtp' or @id='resendInfoTextDiv']")
	private WebElement resendOTPMessage;
	
	
	@FindBy(xpath="(//*[@class='hei mid-content' or @class='sub_line' or@id='resendInfoTextDiv'])[1]")
	private WebElement cibResendOTPMessage;
	
	@FindBy(xpath = "//p[@id='challengeInfoText']")
	private WebElement otpExpiredMessage;
	
	@FindBy(xpath = "//*[@class='err-container' or @id='alertBox2']")
	private WebElement errorText;
	
	public WebElement getCibResendOTPMessage() {
		return cibResendOTPMessage;
	}
	
	@FindBy(xpath="//*[@id='englishLang']")
	private WebElement englishLangNBEbank;
	
	@FindBy(xpath="//p[@class='err-container']")
	private WebElement NBEblankOtptext;

	//HSBC INDIA Cusotmer care page text xpaths.
	
	@FindBy(xpath="//p[1]/span[1]")
	private WebElement hsbcCCPageText;
	
	@FindBy(xpath="//p[1]")
	private WebElement hsbcInactiveCardText;
		
	public WebElement getHsbcInactiveCardText() {
		return hsbcInactiveCardText;
	}

	@FindBy(xpath="//button[@id='submitBtn']")
	private WebElement hsbcCCContinueButton;
	
	
	@FindBy(xpath = "//input[@value='PUSH']")
	private WebElement pushRadioBtm;
	
	@FindBy(xpath = "//input[@value='BIOMETRIC']")
	private WebElement biometricRadioBtm;
	
	@FindBy(xpath = "//input[@value='OFFLINE']")
	private WebElement offlineRadioBtm;
	
	
	public WebElement getOfflineRadioBtn() {
		return offlineRadioBtm;
	}
	
	public WebElement getBiometricRadioBtn() {
		return biometricRadioBtm;
	}
	
	public WebElement getPushRadioBtn() {
		return pushRadioBtm;
	}
	
	

	public WebElement getHsbcCCPageText() {
		return hsbcCCPageText;
	}

	public WebElement getHsbcCCContinueButton() {
		return hsbcCCContinueButton;
	}

	public WebElement getNBEblankOtptext() {
		return NBEblankOtptext;
	}

	public WebElement getEnglishLangNBEbank() {
		return englishLangNBEbank;
	}

	public WebElement getBankLogo() {
		return bankLogo;
	}

	public WebElement getCardUnionLogo() {
		return cardUnionLogo;
	}

	public WebElement getPurchaseAuthenticationHeading() {
		return purchaseAuthenticationHeading;
	}

	public WebElement getPurchaseAuthenticationText() {
		return purchaseAuthenticationText;
	}

	public WebElement getOtpTextFieldLabel() {
		return otpTextFieldLabel;
	}

	public WebElement getOtpTextField() {
		return otpTextField;
	}

	public WebElement getAcsTxnIdXpath() {
		return acsTxnIdXpath;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getOtpPageTimerAlertText() {
		return otpPageTimerAlertText;
	}

	public WebElement getOtpPageHelpText() {
		return otpPageHelpText;
	}

	public WebElement getContactBankText() {
		return contactBankText;
	}

	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}

	public WebElement getCardBlockedContinueButton() {
		return cardBlockedContinueButton;
	}
	public WebElement getCancelTxnBtn() {
		return cancelTxnBtn;
	}
	
	public WebElement getCardBlockedText() {
		return cardBlockedText;
	}

	public WebElement getInvalidOTPMessage() {
		return invalidOTPMessage;
	}

	public WebElement getResendOTPMessage() {
		return resendOTPMessage;
	}
	
	public WebElement getOTPExpiredMessage(){
		return otpExpiredMessage;
	}
	
	public WebElement getErrorText() {
		return errorText;
	}
}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V9PGCheckOutPage {
	public WebDriver driver;

	public V9PGCheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		
	@FindBy(name = "merchant-id")
	private WebElement merchantIdDropDown;

	@FindBy(name = "number")
	private WebElement cardNumberField;

	@FindBy(name = "expiry")
	private WebElement cardExpiryField;
	
	@FindBy(name = "first-name")
	private WebElement cardHolderNameField;
	
	@FindBy(name = "cvv")
	private WebElement cvvNumberField;

	@FindBy(name = "amount")
	private WebElement purchaseAmountField;
	
	@FindBy(xpath = "//span[@id='select2-input-field-container']")
	private WebElement currencyDropDownField;
	
	@FindBy(xpath = "//input[@class='select2-search__field']")
	private WebElement currencyDropDownSearchField;
					 
	@FindBy(xpath = "//li[contains(text(), '\"+currencytype+\"')]")
	private WebElement currencyDropDownSearchedCurrencyType;
		
	@FindBy(xpath="//select[@name='acquirer-id']")
	private WebElement acquirerIdDropDown;
	
	@FindBy(xpath="//span[@id='select2-column-center-container']")
	private WebElement enviromentNameDropDownField;
	
	@FindBy(xpath="//input[@class='select2-search__field']")
	private WebElement enviromentNameDropDownSearchField;
	
	@FindBy(xpath="//li[contains(text(), 'DCS')]")
	private WebElement enviromentNameDropDownSearchedEnviField;

	@FindBy(xpath = "//button[contains(text(), 'Submit')]")
	private WebElement checkOutButton;

	public WebElement getMerchantIdDropDown() {
		return merchantIdDropDown;
	}

	public WebElement getCardNumberField() {
		return cardNumberField;
	}

	public WebElement getCardExpiryField() {
		return cardExpiryField;
	}

	public WebElement getCardHolderNameField() {
		return cardHolderNameField;
	}

	public WebElement getCurrencyDropDownField() {
		return currencyDropDownField;
	}

	public WebElement getCurrencyDropDownSearchField() {
		return currencyDropDownSearchField;
	}

	public WebElement getCurrencyDropDownSearchedCurrencyType() {
		return currencyDropDownSearchedCurrencyType;
	}

	public WebElement getCvvNumberField() {
		return cvvNumberField;
	}

	public WebElement getPurchaseAmountField() {
		return purchaseAmountField;
	}

	public WebElement getAcquirerIdDropDown() {
		return acquirerIdDropDown;
	}

	public WebElement getEnviromentNameDropDownField() {
		return enviromentNameDropDownField;
	}

	public WebElement getEnviromentNameDropDownSearchField() {
		return enviromentNameDropDownSearchField;
	}

	public WebElement getEnviromentNameDropDownSearchedEnviField() {
		return enviromentNameDropDownSearchedEnviField;
	}

	public WebElement getCheckOutButton() {
		return checkOutButton;
	}

	

}

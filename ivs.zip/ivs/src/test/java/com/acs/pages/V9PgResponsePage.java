package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class V9PgResponsePage {
	
	
	public WebDriver driver;

	public V9PgResponsePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//V9 Flow  final page
	@FindBy(xpath = "//td[@id='transStatus']")
	private WebElement transactionStatusValue;
	
	@FindBy(xpath = "//td[@id='eci']")
	private WebElement eciValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorCode']]/td[2]")
	private WebElement errorCodeValue;
	
	@FindBy(xpath ="//tr[td[text()='ErrorDesc']]/td[2]")
	private WebElement errorDescValue;
	
	@FindBy(xpath ="//tr[td[text()='CAVV']]/td[2]")
	private WebElement CAVVValue;
	
	@FindBy(xpath ="//font[@id='authType']")
	private WebElement aresStatusValue;

	@FindBy(xpath ="//tr[td[contains(text(),'RReq')]]/td[2]")
	private WebElement rReqStatusValue;

	
	public WebElement getAresStatusValue() {
		return aresStatusValue;
	}

	public WebElement getErrorCodeValue() {
		return errorCodeValue;
	}
	
	public WebElement getErrorDescValue() {
		return errorDescValue;
	}

	public WebElement getRreqStatusValue() {
		return rReqStatusValue;
	}

	public WebElement getTransactionStatusValue() {
		return transactionStatusValue;
	}

	public WebElement getEciValue() {
		return eciValue;
	}
	
	

}

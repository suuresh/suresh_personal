package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OTPPage {
	
	public WebDriver driver;

	public OTPPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id=\"enterOtpForm\"]/div/div[2]/text()")
	private WebElement authenticationText;
	
	@FindBy(xpath="//*[@name=\"otpValue\"]")
	private WebElement otpField;
	
	//*[@id="enterOtpForm"]/div[1]/button
	@FindBy(xpath = "//*[@id=\"enterOtpForm\"]/div[1]/button")
	private WebElement otpSubmitButton;
	
	@FindBy(xpath = "//*[@id='submitBtn']")
	private WebElement otpSBICSubmitBtn;
	
	@FindBy(id = "otpResend")
	private WebElement otpResendButton;
	
	//@FindBy(id ="cancelButton")	
	@FindBy(xpath ="//*[text()='Cancel' or @id='otpReset']")
	private WebElement otpCancelButton;
	
	@FindBy(xpath ="//button[text()='CONFIRM']")
	private WebElement cardNotRegisteredContinueButton;
	
	@FindBy(xpath ="//*[@class='hei mid-content' or @class='default-message']")
	private WebElement cardNotRegisteredText;
	
	@FindBy(xpath = "//button[text()='CONTINUE']")
	private WebElement continueButton;
	
	@FindBy(xpath = "//*[@class='err-container' or @class='success']")
	private WebElement errorText;
	
	public WebElement getCardNotRegisteredContinueButton() {
		return cardNotRegisteredContinueButton;
	}

	public WebElement getAuthenticationText() {
		return authenticationText;
	}

	public WebElement getOtpField() {
		return otpField;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getCardNotRegisteredText() {
		return cardNotRegisteredText;
	}

	public WebElement getContinueBtn() {
		return continueButton;
	}
	
	public WebElement getErrorText() {
		return errorText;
	}
	
	public WebElement getSBICSubmitBtn() {
		return otpSBICSubmitBtn;
	}

}

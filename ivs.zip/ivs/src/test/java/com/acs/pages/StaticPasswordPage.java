package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StaticPasswordPage {
	
	public WebDriver driver;

	public StaticPasswordPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id="otpValue")
	private WebElement staticPasswordField;
	
	@FindBy(xpath = "//*[@id=\"enterOtpForm\"]/div/div[3]/div[1]/a")
	private WebElement staticPasswordSubmitButton;
	
	@FindBy(id ="cancelButton")
	private WebElement staticPasswordCancelButton;

	
	public WebElement getStaticPasswordField() {
		return staticPasswordField;
	}

	public WebElement getStaticPasswordSubmitButton() {
		return staticPasswordSubmitButton;
	}

	public WebElement getStaticPasswordCancelButton() {
		return staticPasswordCancelButton;
	}
	
	
	
	
	

}

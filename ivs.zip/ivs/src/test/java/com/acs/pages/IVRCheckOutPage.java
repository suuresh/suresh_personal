package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class IVRCheckOutPage {
	public WebDriver driver;

	public IVRCheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "url")
	private WebElement vereqUrlTextField;
	
	@FindBy(xpath = "//textarea[@id='vereq_id']")
	private WebElement veReqPayloadTextarea;
	
	@FindBy(id = "veres_id")
	private WebElement veResTextarea;
	
	@FindBy(id = "vereq_btn_id")
	private WebElement veReqGetResponseButton;
	
	@FindBy(id = "pareq_btn_id")
	private WebElement paReqNavigateButton;
	
	@FindBy(id = "pareq_id")
	private WebElement paReqPayloadTextarea;
	
	@FindBy(xpath = "//textarea[@id='pares_id']")
	private WebElement paResPayloadTextarea;
	
	@FindBy(id = "pareq_btn_id")
	private WebElement paReqGetResponseButton;

	
	public WebElement getVereqUrlTextField() {
		return vereqUrlTextField;
	}

	public WebElement getVeReqPayloadTextarea() {
		return veReqPayloadTextarea;
	}

	public WebElement getVeResTextarea() {
		return veResTextarea;
	}

	public WebElement getVeReqGetResponseButton() {
		return veReqGetResponseButton;
	}

	public WebElement getPaReqNavigateButton() {
		return paReqNavigateButton;
	}

	public WebElement getPaReqPayloadTextarea() {
		return paReqPayloadTextarea;
	}

	public WebElement getPaResPayloadTextarea() {
		return paResPayloadTextarea;
	}

	public WebElement getPaReqGetResponseButton() {
		return paReqGetResponseButton;
	}
	
	

}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ACSSimulatorReponsePage {
	public WebDriver driver;

	public ACSSimulatorReponsePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//h1[contains(text(),'Transaction Failed!')]")
	private WebElement transactionStatusFailedStmt;
	
	@FindBy(xpath = "//p[contains(text(),'Challenge Transaction')]")
	private WebElement challengeTransactionType;
	
	@FindBy(xpath = "//p[contains(text(),'Status : N')]")
	private WebElement transactionStatusN;
	
	@FindBy(xpath = "//p[contains(text(),'Status : R')]")
	private WebElement transactionStatusR;
	
	@FindBy(xpath = "//p[contains(text(),'Acs transaction ID : ')]")
	private WebElement acsTransactionIDStmnt;
	
	@FindBy(xpath = "//p[contains(text(),'AuthenticationValue : ')]")
	private WebElement cavvValueStmnt;
	
	@FindBy(xpath = "//p[contains(text(),'ECI : 07')]")
	private WebElement acsTransactionECIZeroSevenFailedStmnt;
	
	@FindBy(xpath = "//p[contains(text(),'ECI : 05')]")
	private WebElement acsTransactionECIZeroFiveSuccessStmnt;
	
	@FindBy(xpath = "//p[contains(text(),'ECI : 02')]")
	private WebElement acsTransactionECIZeroTwoSuccessStmnt;
		
	@FindBy(xpath = "//h1[contains(text(),'Transaction Success!')]")
	private WebElement transactionStatusSuccessStmnt;
	
	@FindBy(xpath = "//p[contains(text(),'Frictionless Transaction')]")
	private WebElement frictionlessTransactionType;
	
	@FindBy(xpath = "//p[contains(text(),'Status : Y')]")
	private WebElement transactionStatusY;

	public WebElement getTransactionStatusFailedStmt() {
		return transactionStatusFailedStmt;
	}

	public WebElement getChallengeTransactionType() {
		return challengeTransactionType;
	}

	public WebElement getTransactionStatusN() {
		return transactionStatusN;
	}

	public WebElement getTransactionStatusR() {
		return transactionStatusR;
	}

	public WebElement getAcsTransactionIDStmnt() {
		return acsTransactionIDStmnt;
	}

	public WebElement getCavvValueStmnt() {
		return cavvValueStmnt;
	}

	public WebElement getAcsTransactionECIZeroSevenFailedStmnt() {
		return acsTransactionECIZeroSevenFailedStmnt;
	}

	public WebElement getAcsTransactionECIZeroFiveSuccessStmnt() {
		return acsTransactionECIZeroFiveSuccessStmnt;
	}
	
	public WebElement getAcsTransactionECIZeroTwoSuccessStmnt() {
		return acsTransactionECIZeroTwoSuccessStmnt;
	}

	public WebElement getTransactionStatusSuccessStmnt() {
		return transactionStatusSuccessStmnt;
	}

	public WebElement getFrictionlessTransactionType() {
		return frictionlessTransactionType;
	}

	public WebElement getTransactionStatusY() {
		return transactionStatusY;
	}
		
}

package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutPage {
	public WebDriver driver;

	public CheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@value='Add to cart']")
	private WebElement addToCartButton;

	@FindBy(name = "merchant_id")
	private WebElement merchantIdDropDown;

	@FindBy(name = "pan")
	private WebElement cardNumberField;

	@FindBy(name = "expiry")
	private WebElement cardExpiryField;
	
	@FindBy(name = "cvv")
	private WebElement cvvNumberField;

	@FindBy(id = "purchase_amount")
	private WebElement purchaseAmountField;

	@FindBy(xpath = "//button[@class='btn btn-primary btn-sm']")
	private WebElement checkOutButton;

	

	@FindBy(name = "currency")
	private WebElement currencyDropDown;

	public WebElement getAddToCartButton() {
		return addToCartButton;
	}

	public WebElement getCvvNumberField() {
		return cvvNumberField;
	}
	
	public WebElement getMerchantIdDropDown() {
		return merchantIdDropDown;
	}

	public WebElement getCardNumberField() {
		return cardNumberField;
	}

	public WebElement getCardExpiryField() {
		return cardExpiryField;
	}

	public WebElement getPurchaseAmountField() {
		return purchaseAmountField;
	}

	public WebElement getCheckOutButton() {
		return checkOutButton;
	}
	
	public WebElement getCurrencyDropDown() {
		return currencyDropDown;
	}

}

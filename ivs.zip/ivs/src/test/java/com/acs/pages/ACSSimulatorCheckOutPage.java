package com.acs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ACSSimulatorCheckOutPage {
	public WebDriver driver;

	public ACSSimulatorCheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@id='SimulUrl']")
	private WebElement simulatorURLInputField;
	
	@FindBy(xpath = "//input[@id='aReqUrl']")
	private WebElement acsAreqURLInputField;
	
	@FindBy(xpath = "//textarea[@id='areq_id']")
	private WebElement areqPayloadInputField;
	
	@FindBy(xpath = "//button[@id='areq_btn_id']")
	private WebElement areqSubmitButton;

	public WebElement getSimulatorURLInputField() {
		return simulatorURLInputField;
	}

	public WebElement getAcsAreqURLInputField() {
		return acsAreqURLInputField;
	}

	public WebElement getAreqPayloadInputField() {
		return areqPayloadInputField;
	}

	public WebElement getAreqSubmitButton() {
		return areqSubmitButton;
	}

}

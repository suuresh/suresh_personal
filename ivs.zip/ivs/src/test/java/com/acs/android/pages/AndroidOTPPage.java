package com.acs.android.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class AndroidOTPPage {
	
	public AppiumDriver aDriver;

	public AndroidOTPPage(AppiumDriver aDriver) {
		this.aDriver = aDriver;
		PageFactory.initElements(aDriver, this);
	}
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/submitAuthenticationButton")
	private WebElement OTPSubmitButton;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/challengeDataEntry")
	private WebElement OTPTextField;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/menu_cancel")
	private WebElement cancelButton;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/resendInfoButton")
	private WebElement resendButton;

	public WebElement getOTPSubmitButton() {
		return OTPSubmitButton;
	}

	public WebElement getOTPTextField() {
		return OTPTextField;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getResendButton() {
		return resendButton;
	}
	
	
}

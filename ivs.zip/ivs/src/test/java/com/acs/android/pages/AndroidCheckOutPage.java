package com.acs.android.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class AndroidCheckOutPage {
	
	public AppiumDriver aDriver;

	public AndroidCheckOutPage(AppiumDriver aDriver) {
		this.aDriver = aDriver;
		PageFactory.initElements(aDriver, this);
	}
	
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/currency_symbol")
	private WebElement currencySymbol;
	
	@FindBy(xpath = "//android:id/text1[@text='INR']")
	private WebElement currencyType;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/amount")
	private WebElement amountTextField;
	
	@FindBy(className = "android.widget.RadioButton")
	private WebElement tShirtSizeRadioButton;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/buyNow")
	private WebElement buyNowButton;
		
	@FindBy(id = "com.android.packageinstaller:id/permission_allow_button")
	private WebElement permissionAllowButton;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/makePaymentBtn")
	private WebElement continueButton;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/card_number")
	private WebElement cardNumberTextField;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/cardHolderNameEditTxt")
	private WebElement cardHolderNameTextFiled;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/edit_exp_yyyy")
	private WebElement cardExpiryYearTextField;
		
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/edit_exp_mm")
	private WebElement cardExpiryDateTextField;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/cvv")
	private WebElement cardCVVTextField;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/makePaymentBtn")
	private WebElement makePaymentButton;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/submitAuthenticationButton")
	private WebElement otpSubmitButton;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/btnContinue")
	private WebElement continueShopingButton;
	
	public WebElement getCurrencySymbol() {
		return currencySymbol;
	}

	public WebElement getCurrencyType() {
		return currencyType;
	}

	public WebElement getAmountTextField() {
		return amountTextField;
	}

	public WebElement gettShirtSizeRadioButton() {
		return tShirtSizeRadioButton;
	}

	public WebElement getBuyNowButton() {
		return buyNowButton;
	}

	public WebElement getPermissionAllowButton() {
		return permissionAllowButton;
	}

	public WebElement getContinueButton() {
		return continueButton;
	}

	public WebElement getCardNumberTextField() {
		return cardNumberTextField;
	}

	public WebElement getCardHolderNameTextFiled() {
		return cardHolderNameTextFiled;
	}

	public WebElement getCardExpiryYearTextField() {
		return cardExpiryYearTextField;
	}

	public WebElement getCardExpiryDateTextField() {
		return cardExpiryDateTextField;
	}

	public WebElement getCardCVVTextField() {
		return cardCVVTextField;
	}

	public WebElement getMakePaymentButton() {
		return makePaymentButton;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getContinueShopingButton() {
		return continueShopingButton;
	}
	
	
	
	
	
	
	
	

}

package com.acs.android.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class AndroidResponsePage {
	
	public AppiumDriver aDriver;

	public AndroidResponsePage(AppiumDriver aDriver) {
		this.aDriver = aDriver;
		PageFactory.initElements(aDriver, this);
	}
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/txnStatus")
	private WebElement transactionStatus;
	
	@FindBy(id = "com.wibmo.threeds2.sdk.sampleapp:id/txnDesc")
	private WebElement transactionDescription;
	
	public WebElement getTransactionStatus() {
		return transactionStatus;
	}

	public WebElement getTransactionDescription() {
		return transactionDescription;
	}

}

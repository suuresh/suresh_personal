package com.uam.testcases;

import java.io.IOException;
import java.util.List;
import org.apache.commons.lang3.math.NumberUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.mailReader;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AuditTrialPage;
import com.uam.pages.NewUserPermissionPage;

public class ViewClearPermissionVerification extends ACSInitialSetUp {

	int invocationCount = 1;
	int randomPIN;
	public static String RandomLoginID;
	public static String Randomgroupname;

	/*@BeforeMethod
	public void beforeVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}*/

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ViewClearPermission");
	}

	@SuppressWarnings("static-access")
	@Test(dataProvider = "DataSet", priority = 1, enabled = true)
	public void createUser(String IssuerBankId, String IssuerBankName, String firstName, String lastName, String loginId, 
			String countryCode, String mobileNum,String email, String status, String AutomationType,String StatusAfterMakerChecker,
			String bankListName,String Groupname, String product, String acsTrnxReport, String manageCardblock, String Decs) throws InterruptedException {

		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		NewUserPermissionPage newUser = new NewUserPermissionPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;
		ExtentTestManager.getTest().setDescription(Decs);
		System.out.println("row num" + invocationCount);


		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName1 : bankList) {
			if (bankName1.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName1.click();
				break;
			}
		}

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageUsersLink().click();
		generic.explicitWait(2);
		newUser.getUserCreatePlusButton().click();

		/*----------------------Create User------------------------*/
		/* random number generation for Login ID */
		randomPIN = (int) (Math.random() * 90000) + 10000;
		String RandomNum = "" + randomPIN;
		RandomLoginID = "LoginID" + RandomNum;
		System.out.println("Login ID is " + RandomLoginID);
		newUser.getUserFirstNameTextField().clear();
		newUser.getUserFirstNameTextField().sendKeys(RandomLoginID);
		//newUser.getUserLastNameTextField().sendKeys(lastName);
		newUser.getUserLoginIdTextField().clear();

		if (AutomationType.equals("Regression")) {			
			newUser.getUserLoginIdTextField().sendKeys(RandomLoginID);
			generic.writingToExcel(XlFileName, "CreateUser", "LoginID", invocationCount, RandomLoginID);
		} else {
			System.out.println("Executing Functional");
			newUser.getUserLoginIdTextField().sendKeys(loginId);
		}
		// selecting the country code
		newUser.getUserCodeDropDownField().click();
		newUser.getUserCodeSearch().sendKeys(countryCode);
		newUser.getUserCodeCheckBox().click();
		generic.explicitWait(2);

		// Selecting the Mobile number and Email ID
		newUser.getUserMobileNumberTextField().sendKeys(mobileNum);
		newUser.getUserEmailIdTextField().sendKeys(email);


		// Selecting Status='Inactive'
		newUser.getUserStatusDropDownField().click();
		newUser.getUserStatusFieldInactive().click();


		// javascript Executor to scroll to particular web element
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1000)");

		/* Clicking create user button once after fill mandatory data */
		newUser.getCreateUserButton().click();
		System.out.println("clicked create user");
		generic.explicitWait(15);

		// Searching created users with paginations
		newUser.getListPerPageDropDown().click();
		newUser.getList30PerPageRadioButton().click();

		if (AutomationType.equals("Regression")) {
			System.out.println("searching randome Login user");
			newUser.getSearchByLoginIDTextField().sendKeys(RandomLoginID);
		} else {
			System.out.println("searching Functional login user");
			newUser.getSearchByLoginIDTextField().sendKeys(loginId);
		}

		// pagination
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("(//div[text()='" + RandomLoginID
					+ "']/following::div[@data-id='tooltip']/following::div/div/div[1])[1]")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}
		// generic.explicitWait(2);
		// System.out.println("start clicking next page");
		// newUser.getClickNextPage().click();

		// Assertion cases
		sAssertion.assertEquals(newUser.getListedName().getText(), firstName + " " + lastName,
				"FirstName or Lastname is NOT in match");
		sAssertion.assertEquals(newUser.getListedLoginId().getText(), RandomLoginID, "Login ID NOT match");
		sAssertion.assertEquals(newUser.getListedEmail().getText(), email, "Email ID is not Matching");
		sAssertion.assertEquals(newUser.getListedMobile().getText(), "+ " + countryCode + " " + mobileNum,
				"Mobile Number is not matching");
		sAssertion.assertEquals(newUser.getListedStatus().getText(), status, "Status is not matching");
		generic.explicitWait(2);
		newUser.getEdituser().click();
		generic.explicitWait(2);
		// Selecting Status='Active'  Upadting status
		newUser.getUserStatusDropDownField().click();
		newUser.getUserStatusField().click();
		//Select bank Name
		//newUser.getBankList().click();
		newUser.getBankList().sendKeys(bankListName);
		newUser.getSelectBank().click();
		generic.explicitWait(2);
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)");
		newUser.getBtnSaveChanged().click();
		generic.explicitWait(2);


		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		// adminhomepage.getManageBankLink().click();
		adminhomepage.getManageGroupsLink().click();

		// Click on Create Group plus button
		newUser.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		RandomNum = "" + randomPIN;
		Randomgroupname = "AutoGroup" + RandomNum;
		System.out.println("Group name is " + Randomgroupname);
		newUser.getGroupNameTextField().sendKeys(Randomgroupname);
		generic.writingToExcel(XlFileName, "CreateGroup", "GroupName", invocationCount, Randomgroupname);

		// newUser.getGroupNameTextField().sendKeys(Groupname);
		newUser.getGroupProductsSelectDropDown().click();
		generic.explicitWait(15);
		//************ Adding permissions to ACS product group *****************//*

		if (product.equalsIgnoreCase("ACS")) {
			newUser.getGroupProductACSRadioButton().click();
			generic.explicitWait(2);
			js.executeScript("window.scrollBy(0,200)");
			if (acsTrnxReport.equalsIgnoreCase("View")) {
				newUser.getACSTrnxReportViewCheckBox().click();
				System.out.println(" Cliked View");
				generic.explicitWait(2);
			} else if (acsTrnxReport.equalsIgnoreCase("View_Clear")) {
				newUser.getACSTransactionReportViewClearCheckBox().click();
				System.out.println("view clear clicked");
				generic.explicitWait(2);
			}
			generic.explicitWait(2);
			// Manage block card permission
			if (manageCardblock.equalsIgnoreCase("View")) {
				newUser.getACSMangeBlockCardViewCheckBox().click();
				System.out.println("Manage block view clicked");
				generic.explicitWait(2);
			} else if (manageCardblock.equalsIgnoreCase("Manage")) {
				newUser.getACSManageBlockCardManageCheckBox().click();
				System.out.println("Manage block Manage clicked");
				generic.explicitWait(2);
			}
			else if (manageCardblock.equalsIgnoreCase("ViewClear")) {
				newUser.getACSManageBlockCardViewClearCheckBox().click();
				System.out.println("Manage block Manage clicked");
				generic.explicitWait(2);
			}
			
			// Clicking on create group button
			//js.executeScript("arguments[0].scrollIntoView();", newUser.getGroupCreateButton());
			js.executeScript("window.scrollBy(0,-1000)");
			js.executeScript("window.scrollTo(0,document.body.scrollTop)");
			generic.explicitWait(5);

			js.executeScript("window.scrollTo(0,document.body.scrollTop)",  newUser.getGroupCreateButton());
			generic.explicitWait(2);
			newUser.getGroupCreateButton().click();
			generic.explicitWait(2);
			newUser.getListPerPageDropDown().click();
			newUser.getList30PerPageRadioButton().click();
			newUser.getSeacrhByGroupName().sendKeys(Randomgroupname);
			generic.explicitWait(12);

			// Pagination
			int paginationSize1 = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize1 - 4; i++) {
				if (driver
						.findElements(
								By.xpath("//div[text()='" + Randomgroupname + "']/following::div[@data-tip='Edit']"))
								.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			generic.explicitWait(2);
			// Assertion to verify group is created for ACS product
			sAssertion.assertEquals(newUser.getListedGroupName().getText(), Randomgroupname,
					"GroupName created is not matching");
			sAssertion.assertEquals(newUser.getListedProductName().getText(), product,
					"Product created is not matching");
			sAssertion.assertEquals(newUser.getStatus().getText(), "Active", "Status is NOT Active");
		}

		//************ Adding permissions to UAM product group *****************//*
		else if (product.equalsIgnoreCase("UAM")) {
			System.out.println("Welcome to UAM permission");

			newUser.getGroupProductUAMRadioButton().click();
			generic.explicitWait(2);

			js.executeScript("window.scrollBy(0,200)");

			// Clicking on create group button
			js.executeScript("window.scrollBy(0,-1000)");
			newUser.getGroupCreateButton().click();
			generic.explicitWait(2);
			newUser.getListPerPageDropDown().click();
			newUser.getList30PerPageRadioButton().click();
			newUser.getSeacrhByGroupName().sendKeys(Randomgroupname);

			// Pagination
			int paginationSize2 = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize2 - 4; i++) {
				if (driver
						.findElements(
								By.xpath("//div[text()='" + Randomgroupname + "']/following::div[@data-tip='Edit']"))
								.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}
			generic.explicitWait(2);
			// Assertion to verify group is created for 3DS product
			sAssertion.assertEquals(newUser.getListedGroupName().getText(), Randomgroupname,
					"GroupName created is not matching");
			sAssertion.assertEquals(newUser.getListedProductName().getText(), product,
					"Product created is not matching");
			sAssertion.assertEquals(newUser.getStatus().getText(), "Active", "Status is NOT Active");
			sAssertion.assertAll();

		} 

		newUser.getAssignUser().click();
		newUser.getSearchUser().sendKeys(RandomLoginID);
		//driver.findElement(By.xpath("//label[@for='"+RandomLoginID+"']")).click();
		newUser.getSelectUser().click();
		generic.explicitWait(10);
		newUser.getBtnAssignUsers().click();
		generic.explicitWait(5);
		logout.logout();
		generic.explicitWait(3);
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(3);
		loginPage.getLinkSetPassword().click();
		loginPage.getLoginIDTextField().sendKeys(RandomLoginID);

		String captchaValue=driver.findElement(By.xpath("(//div[@class='mar-20']/span)[2]")).getText();
		System.out.println("captchaValue="+captchaValue);
		loginPage.getEnterCaptcha().sendKeys(captchaValue);
		loginPage.getBtnSendOtp().click();
		generic.explicitWait(50);
		String adminOtp=mailReader.OutlookMailReader("Inbox", "OTP Alert", "is your OTP to login to ACCOSA 2.0", 6);
		System.out.println("Admin OTP is  : "+adminOtp);
		loginPage.getOtpTextField().sendKeys(adminOtp);
		loginPage.getBtnOtpSubmit().click();
		generic.explicitWait(5);

		loginPage.getTextSetPassword().sendKeys("Wibmo@123");
		loginPage.getTextConfirmPassword().sendKeys("Wibmo@123");
		loginPage.getBtnSubmit().click();
		generic.explicitWait(5);

		generic.explicitWait(1);
		loginPage.login(RandomLoginID,"Wibmo@123" );

		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		List<WebElement> bankList1 = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName1 : bankList1) {
			if (bankName1.getText().equalsIgnoreCase("National Bank")) {
				bankName1.click();
				break;
			}
		}

		sAssertion.assertEquals(newUser.getNewUser().getText(), "Welcome,"+ RandomLoginID+ "Status is not matching");
	}
	
	@Test(dataProvider = "DataSet", priority = 2, enabled = true)
	public void validateViewTransactionReport(String IssuerBankId, String IssuerBankName, String firstName, String lastName, String loginId,
			String countryCode, String mobileNum, String email, String status, String AutomationType,String StatusAfterMakerChecker, 
			String bankListName,String Groupname, String product, String acsTrnxReport, String manageCardblock, String Decs) throws InterruptedException {

		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(RandomLoginID, "Wibmo@123");

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		NewUserPermissionPage newUser = new NewUserPermissionPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;
		ExtentTestManager.getTest().setDescription(Decs);
		System.out.println("row num" + invocationCount);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AuditTrialPage tranVali = new AuditTrialPage(driver);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName1 : bankList) {
			if (bankName1.getText().equalsIgnoreCase("National Bank")) {
				bankName1.click();
				break;
			}
		}
		generic.explicitWait(1);
		tranVali.getLinkACS().click();
		generic.explicitWait(1);
		tranVali.getAcsReportDashboards().click();
		tranVali.getAcsTransactionReport().click();
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions1 = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions1.selectByValue("0");
		acsTxnPage.getApplyButton().click();
		tranVali.getBtnFetchReport().click();
		generic.explicitWait(5);
		//tranVali.getTableRecordEntityAction().click();
		String testCardNumber=newUser.getClearCardNum().getText();
		System.out.println("testCardNumber="+testCardNumber);
		boolean isNumeric = testCardNumber.chars().allMatch( Character::isDigit );
		sAssertion.assertEquals(isNumeric, false, "View card number is not in the clear format");
		sAssertion.assertAll();
	}

	@Test(dataProvider = "DataSet", priority = 3, enabled = true)
	public void validateViewClearManageBlockCard(String IssuerBankId, String IssuerBankName, String firstName, String lastName, String loginId,
			String countryCode, String mobileNum, String email, String status, String AutomationType,String StatusAfterMakerChecker, 
			String bankListName,String Groupname, String product, String acsTrnxReport, String manageCardblock, String Decs) throws InterruptedException {

		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(RandomLoginID, "Wibmo@123");

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		NewUserPermissionPage newUser = new NewUserPermissionPage(driver);
		SoftAssert sAssertion = new SoftAssert();
		invocationCount++;
		ExtentTestManager.getTest().setDescription(Decs);
		System.out.println("row num" + invocationCount);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AuditTrialPage tranVali = new AuditTrialPage(driver);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName1 : bankList) {
			if (bankName1.getText().equalsIgnoreCase("National Bank")) {
				bankName1.click();
				break;
			}
		}
		generic.explicitWait(1);
		tranVali.getLinkACS().click();
		generic.explicitWait(1);
		tranVali.getAcsOperations().click();
		tranVali.getAcsManageBlockedCards().click();
		generic.explicitWait(5);
		String manageBlockCardText=tranVali.getValidateTextManageBlockedCard().getText();
		System.out.println("textAcsMis="+manageBlockCardText);
		sAssertion.assertEquals(manageBlockCardText, "Manage Blocked Cards", "Manage Blocked Cards assertion text is not matched");
		String testCardNumber=newUser.getBlockClearCardNum().getText();
		System.out.println("Block Card Number="+testCardNumber);
		boolean isNumeric = testCardNumber.chars().allMatch( Character::isDigit );
		sAssertion.assertEquals(isNumeric, true, "View card number is not in the clear format");
		sAssertion.assertAll();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		System.out.println("Sucessfully Logout");
	}

}

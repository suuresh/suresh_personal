package com.uam.testcases;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AuditTrailByCardPage;
import com.uam.pages.CardHolderDetailsPage;
import com.uam.pages.LogOutPage;
import com.uam.pages.ManageBlockedCardPage;

public class AuditTrailByCard extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	LogEntries NetWorklogs;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	String acsTxnId = null;

	/*
	 * public static String TotalCount(String schema) { String TotalItemCount=
	 * 
	 * return TotalItemCount;
	 * 
	 * }
	 */

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] BlockingCard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AuditTrialForCard");
	}

	@Test(dataProvider = "BlockingCard", priority = 1, enabled = true)
	public void BlockingCard(String IssuerBankId, String IssuerBankName, String BlockingCardDetail, String Status,
			String Comment, String ActiveCardDetails, String EditCardDetails, String IssuerBin, String CardNumber,
			String UnblockingComment, String Action, String ActionStatus, String UserId, String Source,
			String AccountNumber, String CountryCode, String UpdatedCountryCode, String MobileNumber,
			String UpdatedMobile, String EmailId, String UpdatedEmailId, String Schema, String Desc) {
		System.out.println("=======Navigating to ManageBlockCard=======");
		System.out.println("Action:"+ Action);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AuditTrailByCardPage auditTrialByCaredPage = new AuditTrailByCardPage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(Desc);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		generic.explicitWait(3);

		// Using Switch case
		switch (Action) {
		case "BlockedCard":		
			
			// Navigating to ManageBlockCard
			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			generic.explicitWait(2);
			adminhomepage.getManageBlockedCardsLink().click();
			generic.explicitWait(5);

			// Blocking the card
			manageBlockCardPage.getBlockCardPlusButton().click();
			generic.explicitWait(8);
			manageBlockCardPage.getCardNumberTextField().sendKeys(BlockingCardDetail);
			manageBlockCardPage.getStatusDropdown().click();
			if (Status.equalsIgnoreCase("SOFTBLOCK")) {
				System.out.println("Softblock..");
				manageBlockCardPage.getSoftBlockDropdownlist().click();
			} else if (Status.equalsIgnoreCase("HOTLIST")) {
				System.out.println("Hotlist..");
				manageBlockCardPage.getHotListDropdownList().click();
			} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
				System.out.println("Hardblock..");
				manageBlockCardPage.getHardBlockDropdownList().click();
			}

			// Comment and Save
			manageBlockCardPage.getCommentTextField().sendKeys(Comment);
			generic.explicitWait(3);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-250)", "");
			manageBlockCardPage.getBlockingCard_SaveButton().click();

			generic.explicitWait(6);
			System.out.println("Card is blocked");
			// Verify Blocked card

			manageBlockCardPage.getFilteredByDropdown().click();
			if (Status.equalsIgnoreCase("SOFTBLOCK")) {
				System.out.println("Softblock..");
				manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
			} else if (Status.equalsIgnoreCase("HOTLIST")) {
				System.out.println("Hotlist..");
				manageBlockCardPage.getFilteredByDropdownHotList().click();
			} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
				System.out.println("Hardblock..");
				manageBlockCardPage.getFilteredByDropdownHardBlock().click();
			}

			String last4Digit = ActiveCardDetails.substring(ActiveCardDetails.length() - 4);
			System.out.println("Last4Digit:- " + last4Digit);
			// manageBlockCardPage.getSearchBox().sendKeys(last4Digit);
			// Adding new CR for Advance search
			if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
				manageBlockCardPage.getAdvanceSearchPlusSign().click();
			}

			generic.explicitWait(2);
			manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
			manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(ActiveCardDetails);
			manageBlockCardPage.getSearchButton().click();

			if (driver.findElements(By.xpath(
					"//div[text()='Card number']/../following::div/div/div[contains(text(),'" + last4Digit + "')]"))
					.size() >= 0) {
				System.out.println("Card is blocked sucessfully");
				driver.findElement(By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
						+ last4Digit + "')]/following::div/div/div[@class='options__edit']")).click();
			} else {
				System.out.println("Card is not blocked");
			}

			// Active the card
			/*
			 * manageBlockCardPage.getUnBlock_StatusDropdown().click(); if
			 * (Status.equalsIgnoreCase("SOFTBLOCK")) {
			 * System.out.println("Activated Softblock..");
			 * manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click(); } else if
			 * (Status.equalsIgnoreCase("HOTLIST")) {
			 * System.out.println("Activated Hotlist..");
			 * manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click(); } else if
			 * (Status.equalsIgnoreCase("HARDBLOCK")) {
			 * System.out.println("Activated Hardblock..");
			 * manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click(); }
			 * 
			 * manageBlockCardPage.getUnBlock_CommentTextField().sendKeys(UnblockingComment)
			 * ;
			 * 
			 * JavascriptExecutor js1 = (JavascriptExecutor) driver;
			 * js1.executeScript("arguments[0].click();",
			 * manageBlockCardPage.getUnBlock_SaveChangesButton()); //
			 * manageBlockCardPage.getUnBlock_SaveChangesButton().click();
			 * generic.explicitWait(6); // Verify successful message
			 * System.out.println("Verify success message");
			 */

			// Navigating to AuditTrialByCard

			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			auditTrialByCaredPage.getAuditTrailByCardSideLink().click();

			// Verify Audit Trial by card

			/*
			 * auditTrialByCaredPage.getAuditTrialByCard_CalenderIcon().click();
			 * auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect().click();
			 * 
			 * Select LeftHoursOptions = new
			 * Select(auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect());
			 * LeftHoursOptions.selectByValue("0");
			 * auditTrialByCaredPage.getApplyButton().click();
			 */

			auditTrialByCaredPage.getAuditTrialByCard_ResetButton().click();

			auditTrialByCaredPage.getAuditTrialByCard_AdvanceSearchButton().click();
			auditTrialByCaredPage.getAuditTrialByCard_CardNumberTextField().sendKeys(BlockingCardDetail);
			auditTrialByCaredPage.getAuditTrialByCard_FetchReportButton().click();

			driver.findElement(By.xpath("//div[text()='" + Action + "']")).click();
			generic.explicitWait(3);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionText().getText(), Action);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionStatusText().getText(),
					ActionStatus);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardSourceText().getText(), Source);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAccNumText().getText(), AccountNumber);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardUserIdText().getText(), UserId);
			break;

		case "updateBlockUnblock":
			
			// Navigating to ManageBlockCard
			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			generic.explicitWait(2);
			adminhomepage.getManageBlockedCardsLink().click();
			generic.explicitWait(8);

			String last4DigitV = ActiveCardDetails.substring(ActiveCardDetails.length() - 4);
			System.out.println("Last4Digit:- " + last4DigitV);

			// Verify card is blocked if so then unblock

			String[] block = { "SOFTBLOCK", "HARDBLOCK", "HOTLIST" };
			for (String cardType : block) {
				System.out.println("Checking in CardType: " + cardType);

				manageBlockCardPage.getFilteredByDropdown().click();
				// manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
				driver.findElement(By.xpath("//label[@for='" + cardType + "']")).click();
				generic.explicitWait(8);

				// generic.waitForProgressBar();
				// manageBlockCardPage.getSearchBox().clear();
				// manageBlockCardPage.getSearchBox().sendKeys(last4DigitV);

				// Adding new CR for Advance search
				if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
					manageBlockCardPage.getAdvanceSearchPlusSign().click();
				}

				generic.explicitWait(6);
				manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
				manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(ActiveCardDetails);
				manageBlockCardPage.getSearchButton().click();
				generic.explicitWait(2);
				if (driver
						.findElements(By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
								+ last4DigitV + "')]"))
						.size() > 0) {
					System.out.println("Card is blocked...");
					driver.findElement(
							By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
									+ last4DigitV + "')]/following::div/div/div[@class='options__edit']"))
							.click();
					manageBlockCardPage.getUnBlock_StatusDropdown().click();
					manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
					manageBlockCardPage.getUnBlock_CommentTextField().sendKeys(UnblockingComment);

					JavascriptExecutor js1 = (JavascriptExecutor) driver;
					js1.executeScript("arguments[0].click();", manageBlockCardPage.getUnBlock_SaveChangesButton());
					// manageBlockCardPage.getUnBlock_SaveChangesButton().click();
					generic.explicitWait(6);
					// Verify successful message
					System.out.println("Card is active now");
					break;
				} else {
					System.out.println("Card is in active state");
				}

				System.out.println("All Done");

			}

			// Navigating to AuditTrialByCard

			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			auditTrialByCaredPage.getAuditTrailByCardSideLink().click();

			// Verify Audit Trial by card

			/*
			 * auditTrialByCaredPage.getAuditTrialByCard_CalenderIcon().click();
			 * auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect().click();
			 * 
			 * Select LeftHoursOptions = new
			 * Select(auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect());
			 * LeftHoursOptions.selectByValue("0");
			 * auditTrialByCaredPage.getApplyButton().click();
			 */

			auditTrialByCaredPage.getAuditTrialByCard_ResetButton().click();

			auditTrialByCaredPage.getAuditTrialByCard_AdvanceSearchButton().click();
			auditTrialByCaredPage.getAuditTrialByCard_CardNumberTextField().sendKeys(BlockingCardDetail);
			auditTrialByCaredPage.getAuditTrialByCard_FetchReportButton().click();
			// Changed By Suresh
			driver.findElement(
					By.xpath("//div[text()='Action']/../following::div/div/div[contains(text(),'"
							+ Action + "')]"))
					.click();
			
			
			
			//driver.findElement(By.xpath("//div[contains(text()='" + Action + "')]")).click();
			//div[contains(text(),'updateBlockUnblock')]
			generic.explicitWait(3);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionText().getText(), Action);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionStatusText().getText(),
					ActionStatus);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardSourceText().getText(), Source);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAccNumText().getText(), AccountNumber);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardUserIdText().getText(), UserId);

			break;

		case "edit":
			CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
			// Navigating to ManageBlockCard
			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			generic.explicitWait(2);
			cardHolderDetailsPage.getManageCardHolderDetailsLink().click();

			// Fetch Customer details by Card
			cardHolderDetailsPage.getCardNumberTextfield().sendKeys(EditCardDetails);
			cardHolderDetailsPage.getSearchButton().click();
			generic.explicitWait(3);

			String expectedCard = EditCardDetails.substring(EditCardDetails.length() - 4);
			//System.out.println("expectedCard :" + expectedCard);
			// Click on edit
			/*
			 * driver.findElement(By.xpath(
			 * "//div[text()='PAN']/../following::div/div/div[contains(text(),'" +
			 * expectedCard +
			 * "')]/following::div[@class='flex-table__cell column md']/div/div")).click();
			 */

			// Click on edit
			driver.findElement(
					By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
					+ "')]/following::div[@class='options__edit']")).click();
			// Update MobileCode and Mobile Number
			cardHolderDetailsPage.getMobileCodeDropdown().click();
			cardHolderDetailsPage.getMobileCodeSearchField().sendKeys(UpdatedCountryCode);
			cardHolderDetailsPage.getFirstMobileCodelist().click();

			cardHolderDetailsPage.getEditMobileTextfield().clear();
			cardHolderDetailsPage.getEditMobileTextfield().sendKeys(UpdatedMobile);

			// Update Email
			cardHolderDetailsPage.getEditEmailTextfield().clear();
			cardHolderDetailsPage.getEditEmailTextfield().sendKeys(UpdatedEmailId);

			// Click on Save
			cardHolderDetailsPage.getSaveChangesButton().click();

			generic.explicitWait(8);
			cardHolderDetailsPage.getCardNumberTextfield().sendKeys(EditCardDetails);
			cardHolderDetailsPage.getSearchButton().click();

			generic.explicitWait(5);

			String expectedMobileWithoutSpChar = UpdatedCountryCode + UpdatedMobile;
			String expectedEmail = EmailId;

			System.out.println("expectedMobileWithoutSpChar:-" + expectedMobileWithoutSpChar);
			System.out.println("expectedEmail:-" + expectedEmail);

			// Changed by Suresh
			String actualMobile = driver
					.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'"
							+ expectedCard + "')]/following::div[5]"))
					.getText();
			// Changed by Suresh
			String actualEmail = driver
					.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'"
							+ expectedCard + "')]/following::div[6]"))
					.getText();

			String actualMobileWithoutSpChar = actualMobile.replaceAll("[^a-zA-Z0-9]", "");
			System.out.println("actualMobileWithoutSpChar:-" + actualMobileWithoutSpChar);
			System.out.println("actualEmail:-" + actualEmail);

			// sAssertion.assertEquals(ActualtimeAtActionPerformed,
			// expectedLastUpdatedDateandTime);
			sAssertion.assertEquals(actualMobileWithoutSpChar, expectedMobileWithoutSpChar);
			sAssertion.assertEquals(actualEmail, expectedEmail);

			// Navigating to AuditTrialByCard

			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			auditTrialByCaredPage.getAuditTrailByCardSideLink().click();

			// Verify Audit Trial by card

			/*
			 * auditTrialByCaredPage.getAuditTrialByCard_CalenderIcon().click();
			 * auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect().click();
			 * 
			 * Select LeftHoursOptions = new
			 * Select(auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect());
			 * LeftHoursOptions.selectByValue("0");
			 * auditTrialByCaredPage.getApplyButton().click();
			 */

			auditTrialByCaredPage.getAuditTrialByCard_ResetButton().click();

			auditTrialByCaredPage.getAuditTrialByCard_AdvanceSearchButton().click();
			auditTrialByCaredPage.getAuditTrialByCard_CardNumberTextField().sendKeys(EditCardDetails);
			auditTrialByCaredPage.getAuditTrialByCard_FetchReportButton().click();

			// Changed By Suresh
			driver.findElement(
					By.xpath("//div[text()='Action']/../following::div/div/div[contains(text(),'"
							+ Action + "')]"))
					.click();
			// driver.findElement(By.xpath("//div[text()='" + Action + "']")).click();
			generic.explicitWait(3);
			//System.out.println("Action:"+auditTrialByCaredPage.getAuditTrailByCardActionText().getText()+","+ Action);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionText().getText(), Action);
			//System.out.println("ActionStatus:"+auditTrialByCaredPage.getAuditTrailByCardActionStatusText().getText()+","+ ActionStatus);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionStatusText().getText(),
					ActionStatus);
			//System.out.println("Source:"+auditTrialByCaredPage.getAuditTrailByCardSourceText().getText()+","+ Source);
			//System.out.println("AccountNumber:"+auditTrialByCaredPage.getAuditTrailByCardAccNumText().getText()+","+ AccountNumber);
			
			System.out.println("UserId:"+auditTrialByCaredPage.getAuditTrailByCardUserIdText().getText()+","+ UserId);
			
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardSourceText().getText(), Source);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAccNumText().getText(), AccountNumber);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardUserIdText().getText(), UserId);

			// Validate Modification
			System.out.println("CountryCode:"+auditTrialByCaredPage.getAuditTrailByCardBeforeChange_CountryCodeText().getText()+","+ CountryCode);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardBeforeChange_CountryCodeText().getText(),
					CountryCode);
			System.out.println("UpdatedCountryCode:"+auditTrialByCaredPage.getAuditTrailByCardAfterChange_CountryCodeText().getText()+","+ UpdatedCountryCode);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAfterChange_CountryCodeText().getText(),
					UpdatedCountryCode);
			
			
			//System.out.println("Before Mobile:"+auditTrialByCaredPage.getAuditTrailByCardBeforeChange_MobileText().getText()+","+MobileNumber);
			//System.out.println("After Mobile:"+auditTrialByCaredPage.getAuditTrailByCardAfterChange_MobileText().getText()+","+UpdatedMobile);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardBeforeChange_MobileText().getText(),
					MobileNumber);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAfterChange_MobileText().getText(),
					UpdatedMobile);

			// scrolling down
			JavascriptExecutor js1 = (JavascriptExecutor) driver;
			js1.executeScript("window.scrollBy(0,250)", "");

			generic.explicitWait(3);
			
			//System.out.println("Before Email:"+auditTrialByCaredPage.getAuditTrailByCardBeforeChange_emailIdText().getText()+","+EmailId);
			//System.out.println("After Email:"+auditTrialByCaredPage.getAuditTrailByCardAfterChange_emailIdText().getText()+","+UpdatedEmailId);
			
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardBeforeChange_emailIdText().getText(),
					EmailId);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAfterChange_emailIdText().getText(),
					UpdatedEmailId);

			break;

		case "create":

			generic.explicitWait(3);
			invocationCount++;
			GenericMethods.writingToExcel(XlFileName, "CreateCardAdmin", "CardNumber", invocationCount, "");
			CardHolderDetailsPage cardHolderDetailsCreatePage = new CardHolderDetailsPage(driver);
			// Navigating to ManageBlockCard
			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			adminhomepage.getAddACardLink().click();
			generic.explicitWait(2);
			// cardHolderDetailsPage.getManageCardHolderDetailsLink().click();
			// long randomNumber = GenericMethods.generateRandomDigits(10);
			long randomNumber = (long) (Math.random() * 100000 + 4533300000L);

			System.out.println("Random number : " + randomNumber);
			String createdCardNumber = IssuerBin + randomNumber;
			System.out.println("Card numbers is : " + createdCardNumber);

			generic.explicitWait(1);
			cardHolderDetailsCreatePage.getCreateCardTextField().sendKeys(createdCardNumber);
			cardHolderDetailsCreatePage.getCreateCardDetailsMobileCodeDropDown().click();
			cardHolderDetailsCreatePage.getCreateCardDetailsMobileCountryCodeTextField().sendKeys(CountryCode);
			cardHolderDetailsCreatePage.getCreateCardDetailsMobileCountryCodeRadioButton().click();
			cardHolderDetailsCreatePage.getCreateCardDetailsMobileNumberTextField().sendKeys(MobileNumber);
			cardHolderDetailsCreatePage.getCreateCardDetailsEmailTextField().sendKeys(EmailId);
			// cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
			cardHolderDetailsCreatePage.getCreateCardDetailsPlusButton().click();
			generic.explicitWait(1);
			GenericMethods.writingToExcel(XlFileName, "CreateCardAdmin", "CardNumber", invocationCount,
					createdCardNumber);

			// Navigating to AuditTrialByCard

			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			auditTrialByCaredPage.getAuditTrailByCardSideLink().click();

			// Verify Audit Trial by card

			/*
			 * auditTrialByCaredPage.getAuditTrialByCard_CalenderIcon().click();
			 * auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect().click();
			 * 
			 * Select LeftHoursOptions = new
			 * Select(auditTrialByCaredPage.getAuditTrialByCard_LeftHoursSelect());
			 * LeftHoursOptions.selectByValue("0");
			 * auditTrialByCaredPage.getApplyButton().click();
			 */

			auditTrialByCaredPage.getAuditTrialByCard_ResetButton().click();

			auditTrialByCaredPage.getAuditTrialByCard_AdvanceSearchButton().click();
			auditTrialByCaredPage.getAuditTrialByCard_CardNumberTextField().sendKeys(createdCardNumber);
			auditTrialByCaredPage.getAuditTrialByCard_FetchReportButton().click();

			// Changed By Suresh
			driver.findElement(
					By.xpath("//div[text()='Action']/../following::div/div/div[contains(text(),'"
							+ Action + "')]"))
					.click();
			// driver.findElement(By.xpath("//div[text()='" + Action + "']")).click();
			generic.explicitWait(3);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionText().getText(), Action);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardActionStatusText().getText(),
					ActionStatus);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardSourceText().getText(), Source);
			// sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardAccNumText().getText(),
			// AccountNumber);
			sAssertion.assertEquals(auditTrialByCaredPage.getAuditTrailByCardUserIdText().getText(), UserId);
			break;

		case "TotalCount":

			adminhomepage.getSideBarLinkACS().click();
			adminhomepage.getOperationsLink().click();
			auditTrialByCaredPage.getAuditTrailByCardSideLink().click();

			break;

		}
		sAssertion.assertAll();
	}

	@AfterMethod
	public void logout() {
		LogOutPage logout = new LogOutPage(driver);
		logout.logout();
		System.out.println("Sucessfully Logout");
	}
}

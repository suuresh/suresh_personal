package com.uam.testcases;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.SelectLanguagePage;

public class SelectLanguageFieldVerfication extends ACSInitialSetUp {
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
	}

	@Test(enabled=true, priority = 0, description="Validating Accosa Welcome title message and Selected Bank Name")
	public void validateAccosaWelcomeTitleSelectedBankTitleSelectLanguageDeutche() {
		ExtentTestManager.getTest().setDescription("Validating Accosa Welcome title message and Selected Bank Name.");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Deutsche");
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getTextWelcomeAccosa().getText(),"Derzeit ausgewählte Bank ist National Bank", "Derzeit ausgewählte Bank ist National Bank text mismatch" );
		sAssertion.assertEquals(language.getTextBankSelection().getText(),"WILLKOMMEN BEI ACCOSA IVSTM" , "WILLKOMMEN BEI ACCOSA IVSTM text mismatch" );
		sAssertion.assertAll();
	}

	@Test(enabled=true,  priority = 1, description="Validating advanced search field name Acs Transcation")
	public void validateAdvancedSearchFieldNameSelectLanguageDeutche() {
		ExtentTestManager.getTest().setDescription("Validating advanced search field name Acs Transcation");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		// Create object of the Select class
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
	//	Select select = new Select(WebElement selectLanguageDropdown);
		//language.getSelectLanguageDropdown().click();
		generic.explicitWait(1);
		se.selectByValue("Deutsche");
		//language.getSelectLanguageDeutche().click();
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsTransactionReport().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getAcsTranHeaderLabel().getText(),"Rufen Sie den ACS-Transaktionsbericht ab", "Rufen Sie den ACS-Transaktionsbericht ab text mismatch" );
		sAssertion.assertEquals(language.getLblAdvancedSearch().getText(),"Erweiterte Suche", "Erweiterte Suche text mismatch" );
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getLblFetchReport().getText().equalsIgnoreCase("Bericht abrufen"), true, "Bericht abrufen text mismatch");
		sAssertion.assertEquals(language.getLblReset().getText().equalsIgnoreCase("Zurücksetzen"),true , "Zurücksetzen text mismatch");
		generic.explicitWait(1);
		language.getPlusLinkAdvancedSearch().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getLblCardNumber().getText().equalsIgnoreCase("Kartennummer"), true, "Kartennummer text mismatch");
		sAssertion.assertEquals(language.getLblMerchantId().getText().equalsIgnoreCase("Händler-ID"), true, "Händler-ID text mismatch");
		sAssertion.assertEquals(language.getLblAcsTranId().getText().equalsIgnoreCase("ACS-Transaktions-ID"), true, "ACS-Transaktions-ID text mismatch");
		sAssertion.assertEquals(language.getLblAuthType().getText().equalsIgnoreCase("Authentifizierungsart"), true, "Authentifizierungsart text mismatch");
		sAssertion.assertEquals(language.getLblDeviceChannel().getText().equalsIgnoreCase("Gerätekanal"), true, "Gerätekanal text mismatch");
		sAssertion.assertEquals(language.getLblCardUnion().getText().equalsIgnoreCase("Karte Union"), true, "Karte Union text mismatch");
		sAssertion.assertEquals(language.getLblCardType().getText().equalsIgnoreCase("Speicherkarten-Typ"), true, "Speicherkarten-Typ text mismatch");
		sAssertion.assertEquals(language.getLblTranStatus().getText().equalsIgnoreCase("Transaktionsstatus"), true, "Transaktionsstatus text mismatch");
		sAssertion.assertEquals(language.getLblBinNumber().getText().equalsIgnoreCase("BIN-Nummer"), true, "BIN-Nummer text mismatch");
		sAssertion.assertEquals(language.getLblDataCenter().getText().equalsIgnoreCase("Data Center"), true, "Data Center text mismatch");
		sAssertion.assertEquals(language.getLblEnvironment().getText().equalsIgnoreCase("Umgebung"), true, "Umgebung text mismatch");
		sAssertion.assertEquals(language.getLblRiskScoreRange().getText().equalsIgnoreCase("Risk Score Range"), true, "Risk Score Range text mismatch");
		sAssertion.assertEquals(language.getLblRuleSetId().getText().equalsIgnoreCase("Ruleset Id"), true, "Ruleset Id text mismatch");
		sAssertion.assertEquals(language.getLblRiskEngineClientId().getText().equalsIgnoreCase("Risk Engine Client ID"), true, "Risk Engine Client ID text mismatch");
		sAssertion.assertEquals(language.getLblProductionNode().getText().equalsIgnoreCase("Production Node"), true, "Production Node text mismatch");
		sAssertion.assertEquals(language.getLblTransactionType().getText().equalsIgnoreCase("Art der Transaktion"), true, "Art der Transaktion text mismatch");
		sAssertion.assertEquals(language.getLblClientId().getText().equalsIgnoreCase("Client Id"), true, "Client Id text mismatch");
		sAssertion.assertEquals(language.getLblProtocalVersion().getText().equalsIgnoreCase("Protokoll version"), true, "Protokoll version text mismatch");
		sAssertion.assertAll();
	}

	@Test(enabled=true, priority =2, description="ACS Transaction report column Name")
	public void validateAdvancedReportColumnNameSelectLanguageDeutche() {
		ExtentTestManager.getTest().setDescription("ACS Transaction report column Name");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Deutsche");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsTransactionReport().click();
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();
		language.getLblFetchReport().click();
		generic.explicitWait(5);
		sAssertion.assertEquals(language.getLbltimeStamp().getText().equalsIgnoreCase("Zeitstempel"), true, "Time Stamp text mismatch");
		sAssertion.assertEquals(language.getLblCardNumberReportResult().getText().equalsIgnoreCase("Kartennummer"), true, "Card Number text mismatch");
		sAssertion.assertEquals(language.getLblProtocalVer().getText().equalsIgnoreCase("Protokoll"+ "\n" +"version"), true, "Protocol Version text mismatch");
		sAssertion.assertEquals(language.getLblMerchName().getText().equalsIgnoreCase("Händler"+ "\n" +"Name"), true, "Merchant Name text mismatch");
		sAssertion.assertEquals(language.getLblTranAmount().getText().equalsIgnoreCase("Trans."+ "\n" +"Menge"), true, "Trans. Amount text mismatch");
		sAssertion.assertEquals(language.getLblTranType().getText().equalsIgnoreCase("Trans."+ "\n" +"Art"), true, "Trans. Type text mismatch");
		sAssertion.assertEquals(language.getLblCardTypeReportResult().getText().equalsIgnoreCase("Karte"+ "\n" +"Art"), true, "Card Type text mismatch");
		sAssertion.assertEquals(language.getLblCardUnionReportResult().getText().equalsIgnoreCase("Karte"+ "\n" +"Union"), true, "Card Union text mismatch");
		sAssertion.assertEquals(language.getLblDataCentre().getText().equalsIgnoreCase("Daten"+ "\n" +"Centre"), true, "Data Centre text mismatch");
		sAssertion.assertEquals(language.getLblDeviceChannelReportResult().getText().equalsIgnoreCase("Gerät"+ "\n" +"Kanal"), true, "Device Channel text mismatch");
		sAssertion.assertEquals(language.getLblAuthenticationType().getText().equalsIgnoreCase("Authentifizierung"+ "\n" +" Art"), true, "Authe... Type text mismatch");
		sAssertion.assertEquals(language.getLblStatus().getText().equalsIgnoreCase("Status"), true, "Status text mismatch");
		sAssertion.assertAll();
	}

	@Test(enabled=true, priority =3, description="Validating MDD Report Header")
	public void validateMddReportHeadeSelectLanguageDeutche() {
		ExtentTestManager.getTest().setDescription("Validating MDD Report Header");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Deutsche");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsMddReport().click();
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();
		language.getLblFetchReport().click();
		generic.explicitWait(5);
		sAssertion.assertEquals(language.getLblMddReportHeader1().getText().equalsIgnoreCase("MDD Report"), true, "MDD Report text mismatch");
		sAssertion.assertEquals(language.getLblMddReportHeader2().getText().equalsIgnoreCase("Ergebnisse melden"), true, "Ergebnisse melden text mismatch");	
		sAssertion.assertAll();
	}
	@Test(enabled=true, priority =4, description="Validating Dashboard Report Header")
	public void validateDashboardReportHeaderSelectLanguageDeutche() {
		ExtentTestManager.getTest().setDescription("Validating Dashboard Report Header");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Deutsche");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsDashboard().click();
		generic.explicitWait(2);
		sAssertion.assertEquals(language.getLblAcsHighlight().getText().equalsIgnoreCase("ACS Höhepunkte"), true, "ACS Höhepunkte text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranINR().getText().equalsIgnoreCase("Gesamtzahl der Transaktionen (EUR)"), true, "Gesamtzahl der Transaktionen (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblTotalAmountINR().getText().equalsIgnoreCase("Gesamtmenge (EUR)"), true, "Gesamtmenge (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblAvgAmountSpendINR().getText().equalsIgnoreCase("Durchschn. Ausgegebener Betrag (EUR)"), true, "Durchschn. Ausgegebener Betrag (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblAuthRate().getText().equalsIgnoreCase("Authentifizierungsrate"), true, "Authentifizierungsrate text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranAllCur().getText().equalsIgnoreCase("Gesamtzahl der Transaktionen(All Currencies)"), true, "Gesamtzahl der Transaktionen(All Currencies) text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranNonINR().getText().equalsIgnoreCase("Total Number of TransactionsNon(EUR)"), true, "Total Number of TransactionsNon(EUR) text mismatch");
		sAssertion.assertEquals(language.getLblTotalAmountNonINR().getText().equalsIgnoreCase("GesamtmengeNon(EUR)"), true, "GesamtmengeNon(EUR) text mismatch");
		sAssertion.assertEquals(language.getLblCardUsageBreakDown().getText().equalsIgnoreCase("Aufschlüsselung der Kartennutzung"), true, "Aufschlüsselung der Kartennutzung text mismatch");
		sAssertion.assertEquals(language.getLblFrictionlessTran().getText().equalsIgnoreCase("Reibungslose Transaktionen"), true, "Reibungslose Transaktionen text mismatch");
		sAssertion.assertEquals(language.getLblChallengedTran().getText().equalsIgnoreCase("Herausgeforderte Transaktionen"), true, "Herausgeforderte Transaktionen text mismatch");
		sAssertion.assertEquals(language.getLblDeclinedTran().getText().equalsIgnoreCase("Abgelehnte Transaktionen"), true, "Abgelehnte Transaktionen text mismatch");
		sAssertion.assertEquals(language.getLblFailureTran().getText().equalsIgnoreCase("Failure Transactions"), true, "Failure Transactions text mismatch");
		sAssertion.assertEquals(language.getLblInsight().getText().equalsIgnoreCase("Einblicke"), true, "Einblicke text mismatch");
		sAssertion.assertEquals(language.getLblTransactionTrends().getText().equalsIgnoreCase("Transaktionstrends"), true, "Transaktionstrends text mismatch");
		sAssertion.assertAll();
	}
	//========Espanola language
	
	@Test(enabled=true, priority = 5, description="Validating Accosa Welcome title message and Selected Bank Name.")
	public void validateAccosaWelcomeTitleSelectedBankTitleSelectLanguageEspanola() {
		ExtentTestManager.getTest().setDescription("Validating Accosa Welcome title message and Selected Bank Name.");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(3);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Española");
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getTextWelcomeAccosa().getText(),"El banco actualmente seleccionado es National Bank", "El banco actualmente seleccionado es National Bank text mismatch" );
		sAssertion.assertEquals(language.getTextBankSelection().getText(),"BIENVENIDOS A ACCOSA IVSTM", "BIENVENIDOS A ACCOSA IVSTM text mismatch" );
		sAssertion.assertAll();
	}

	@Test(enabled=true,priority = 6, description="Validating advanced search field name Acs Transcation")
	public void validateAdvancedSearchFieldNameSelectLanguageEspanola() {
		ExtentTestManager.getTest().setDescription("Validating advanced search field name Acs Transcation");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Española");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsTransactionReport().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getAcsTranHeaderLabel().getText(),"Fetch Informe de transacciones de ACS", "Fetch Informe de transacciones de ACS text mismatch" );
		sAssertion.assertEquals(language.getLblAdvancedSearch().getText(),"Búsqueda Avanzada" , "Búsqueda Avanzada text mismatch");
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getLblFetchReport().getText().equalsIgnoreCase("Fetch Informe"), true, "Fetch Informe text mismatch");
		sAssertion.assertEquals(language.getLblReset().getText().equalsIgnoreCase("Reiniciar"),true, "Reiniciar text mismatch" );
		generic.explicitWait(1);
		language.getPlusLinkAdvancedSearch().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(language.getLblCardNumber().getText().equalsIgnoreCase("Número De Tarjeta"), true, "Número De Tarjeta text mismatch");
		sAssertion.assertEquals(language.getLblMerchantId().getText().equalsIgnoreCase("Identificación Del Comerciante"), true, "Identificación Del Comerciante text mismatch");
		sAssertion.assertEquals(language.getLblAcsTranId().getText().equalsIgnoreCase("ID De Transacción De ACS"), true, "ID De Transacción De ACS text mismatch");
		sAssertion.assertEquals(language.getLblAuthType().getText().equalsIgnoreCase("tipo de autenticación"), true, "tipo de autenticación text mismatch");
		sAssertion.assertEquals(language.getLblDeviceChannel().getText().equalsIgnoreCase("Canal del dispositivo"), true, "Canal del dispositivo text mismatch");
		sAssertion.assertEquals(language.getLblCardUnion().getText().equalsIgnoreCase("Unión de tarjetas"), true, "Unión de tarjetas text mismatch");
		sAssertion.assertEquals(language.getLblCardType().getText().equalsIgnoreCase("Card Type"), true, "Card Type text mismatch");
		sAssertion.assertEquals(language.getLblTranStatus().getText().equalsIgnoreCase("estado de la transacción"), true, "estado de la transacción text mismatch");
		sAssertion.assertEquals(language.getLblBinNumber().getText().equalsIgnoreCase("Número de BIN"), true, "Número de BIN text mismatch");
		sAssertion.assertEquals(language.getLblDataCenter().getText().equalsIgnoreCase("Data Center"), true, "Data Center text mismatch");
		sAssertion.assertEquals(language.getLblEnvironment().getText().equalsIgnoreCase("Ambiente"), true, "Ambiente text mismatch");
		sAssertion.assertEquals(language.getLblRiskScoreRange().getText().equalsIgnoreCase("Risk Score Range"), true, "Risk Score Range text mismatch");
		sAssertion.assertEquals(language.getLblRuleSetId().getText().equalsIgnoreCase("Ruleset Id"), true, "Ruleset Id text mismatch");
		sAssertion.assertEquals(language.getLblRiskEngineClientId().getText().equalsIgnoreCase("Risk Engine Client ID"), true, "Risk Engine Client ID text mismatch");
		sAssertion.assertEquals(language.getLblProductionNode().getText().equalsIgnoreCase("Production Node"), true, "Production Node text mismatch");
		sAssertion.assertEquals(language.getLblTransactionType().getText().equalsIgnoreCase("tipo de transacción"), true, "tipo de transacción text mismatch");
		sAssertion.assertEquals(language.getLblClientId().getText().equalsIgnoreCase("Client Id"), true, "Client Id text mismatch");
		sAssertion.assertEquals(language.getLblProtocalVersion().getText().equalsIgnoreCase("VersiÃ³n de protocolo"), true, "VersiÃ³n de protocolo text mismatch");
		sAssertion.assertAll();
	}

	@Test(enabled=true, priority =7, description="ACS Transaction report column Name")
	public void validateAdvancedReportColumnNameSelectLanguageEspanola() {
		ExtentTestManager.getTest().setDescription("ACS Transaction report column Name");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Española");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsTransactionReport().click();
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();
		language.getLblFetchReport().click();
		generic.explicitWait(5);
		sAssertion.assertEquals(language.getLbltimeStamp().getText().equalsIgnoreCase("Sello de tiempo"), true, "Sello de tiempo text mismatch");
		sAssertion.assertEquals(language.getLblCardNumberReportResult().getText().equalsIgnoreCase("Número de tarjeta"), true, "Número de tarjeta text mismatch");
		sAssertion.assertEquals(language.getLblProtocalVer().getText().equalsIgnoreCase("VersiÃ³n"+ "\n" +"de protocolo"), true, "VersiÃ³nde protocolo text mismatch");
		sAssertion.assertEquals(language.getLblMerchName().getText().equalsIgnoreCase("Comerciante"+ "\n" +"Nombre"), true, "ComercianteNombre text mismatch");
		sAssertion.assertEquals(language.getLblTranAmount().getText().equalsIgnoreCase("Trans."+ "\n" +"Cantidad"), true, "Trans.Cantidad text mismatch");
		sAssertion.assertEquals(language.getLblTranType().getText().equalsIgnoreCase("Trans."+ "\n" +"Tipo"), true, "Trans.Tipo text mismatch");
		sAssertion.assertEquals(language.getLblCardTypeReportResult().getText().equalsIgnoreCase("Tarjeta"+ "\n" +"Tipo"), true, "TarjetaTipo text mismatch");
		sAssertion.assertEquals(language.getLblCardUnionReportResult().getText().equalsIgnoreCase("Tarjeta"+ "\n" +"Unión"), true, "TarjetaUnión text mismatch");
		sAssertion.assertEquals(language.getLblCardUnionReportResult().getText().equalsIgnoreCase("Datoss"+ "\n" +"Centre"), true, "DatossCentre text mismatch");
		sAssertion.assertEquals(language.getLblDeviceChannelReportResult().getText().equalsIgnoreCase("Dispositivo"+ "\n" +"Canal"), true, "DispositivoCanal text mismatch");
		sAssertion.assertEquals(language.getLblAuthenticationType().getText().equalsIgnoreCase("Autenticación"+ "\n" +" Tipo"), true, "Autenticación Tipo text mismatch");
		sAssertion.assertEquals(language.getLblStatus().getText().equalsIgnoreCase("Estado"), true, "Estado text mismatch");
		sAssertion.assertAll();
	}

	@Test(enabled=true, priority =8, description="Validating MDD Report Header")
	public void validateMddReportHeadeSelectLanguageEspanola() {
		ExtentTestManager.getTest().setDescription("Validating MDD Report Header");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Española");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsMddReport().click();
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();
		language.getLblFetchReport().click();
		generic.explicitWait(5);
		sAssertion.assertEquals(language.getLblMddReportHeader1().getText().equalsIgnoreCase("MDD Report"), true, "MDD Report text mismatch");
		sAssertion.assertEquals(language.getLblMddReportHeader2().getText().equalsIgnoreCase("Informe de resultados"), true, "Informe de resultados text mismatch");	
		sAssertion.assertAll();
	}
	@Test(enabled=true, priority =9, description="Validating Dashboard Report Header")
	public void validateDashboardReportHeaderSelectLanguageEspanola() {
		ExtentTestManager.getTest().setDescription("Validating Dashboard Report Header");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SelectLanguagePage language = new SelectLanguagePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(2);
		Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
		generic.explicitWait(1);
		se.selectByValue("Española");
		generic.explicitWait(1);
		language.getLinkACS().click();
		language.getAcsReportDashboards().click();
		language.getAcsDashboard().click();
		generic.explicitWait(2);
		sAssertion.assertEquals(language.getLblAcsHighlight().getText().equalsIgnoreCase("ACS Reflejos"), true, "ACS Reflejos text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranINR().getText().equalsIgnoreCase("Número total de transacciones (EUR)"), true, "Número total de transacciones (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblTotalAmountINR().getText().equalsIgnoreCase("Cantidad total (EUR)"), true, "Cantidad total (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblAvgAmountSpendINR().getText().equalsIgnoreCase("Cantidad de gasto promedio (EUR)"), true, "Cantidad de gasto promedio (EUR) text mismatch");
		sAssertion.assertEquals(language.getLblAuthRate().getText().equalsIgnoreCase("Tasa de autentificación"), true, "Tasa de autentificación text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranAllCur().getText().equalsIgnoreCase("Número total de transacciones(All Currencies)"), true, "Número total de transacciones(All Currencies) text mismatch");
		sAssertion.assertEquals(language.getLblTotalNumberTranNonINR().getText().equalsIgnoreCase("Total Number of TransactionsNon(EUR)"), true, "Total Number of TransactionsNon(EUR) text mismatch");
		sAssertion.assertEquals(language.getLblTotalAmountNonINR().getText().equalsIgnoreCase("Cantidad totalNon(EUR)"), true, "Cantidad totalNon(EUR) text mismatch");
		sAssertion.assertEquals(language.getLblCardUsageBreakDown().getText().equalsIgnoreCase("Desglose de Uso de Tarjetas"), true, "Desglose de Uso de Tarjetas text mismatch");
		sAssertion.assertEquals(language.getLblFrictionlessTran().getText().equalsIgnoreCase("Transacciones Sin Fricción"), true, "Transacciones Sin Fricción text mismatch");
		sAssertion.assertEquals(language.getLblChallengedTran().getText().equalsIgnoreCase("Transacciones Desafiadas"), true, "Transacciones Desafiadas text mismatch");
		sAssertion.assertEquals(language.getLblDeclinedTran().getText().equalsIgnoreCase("Transacciones rechazadas"), true, "Transacciones rechazadas text mismatch");
		sAssertion.assertEquals(language.getLblFailureTran().getText().equalsIgnoreCase("Failure Transactions"), true, "Failure Transactions text mismatch");	
		sAssertion.assertEquals(language.getLblInsight().getText().equalsIgnoreCase("Insights"), true, "Insights text mismatch");	
		sAssertion.assertEquals(language.getLblTransactionTrends().getText().equalsIgnoreCase("Tendencias de transacciones"), true, "Tendencias de transacciones text mismatch");
		sAssertion.assertAll();
	}
	
	//========English language
	
		@Test(enabled=true, priority = 10, description="Validating Accosa Welcome title message and Selected Bank Name")
		public void validateAccosaWelcomeTitleSelectedBankTitleSelectLanguageEnglish() {
			ExtentTestManager.getTest().setDescription("Validating Accosa Welcome title message and Selected Bank Name.");
			SoftAssert sAssertion = new SoftAssert();
			AdminHomePage adminhomepage = new AdminHomePage(driver);
			SelectLanguagePage language = new SelectLanguagePage(driver);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
			adminhomepage.getDropDownHeader().click();
			adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
			generic.explicitWait(1);
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase("National Bank")) {
					bankName.click();
					break;
				}
			}
			generic.explicitWait(3);
			Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
			generic.explicitWait(1);
			se.selectByValue("English");
			generic.explicitWait(1);
			sAssertion.assertEquals(language.getTextWelcomeAccosa().getText(),"Currently selected bank is National Bank" ,"Currently selected bank is National Bank text mismatch");
			sAssertion.assertEquals(language.getTextBankSelection().getText(),"WELCOME TO ACCOSA IVSTM","WELCOME TO ACCOSA IVSTM text mismatch" );
			sAssertion.assertAll();
		}

		@Test(enabled=true, priority = 11, description="Validating advanced search field name Acs Transcation")
		public void validateAdvancedSearchFieldNameSelectLanguageEnglish() {
			ExtentTestManager.getTest().setDescription("Validating fetch Acs Transcation.");
			SoftAssert sAssertion = new SoftAssert();
			AdminHomePage adminhomepage = new AdminHomePage(driver);
			SelectLanguagePage language = new SelectLanguagePage(driver);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
			adminhomepage.getDropDownHeader().click();
			adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
			generic.explicitWait(1);
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase("National Bank")) {
					bankName.click();
					break;
				}
			}
			generic.explicitWait(2);
			Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
			generic.explicitWait(1);
			se.selectByValue("English");
			generic.explicitWait(1);
			language.getLinkACS().click();
			language.getAcsReportDashboards().click();
			language.getAcsTransactionReport().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(language.getAcsTranHeaderLabel().getText(),"Fetch ACS Transaction Report","Fetch ACS Transaction Report mismatch" );
			sAssertion.assertEquals(language.getLblAdvancedSearch().getText(),"Advanced Search", "Advanced Search text mismatch" );
			generic.explicitWait(1);
			sAssertion.assertEquals(language.getLblFetchReport().getText().equalsIgnoreCase("Fetch Report"), true, "Fetch Report text mismatch");
			sAssertion.assertEquals(language.getLblReset().getText().equalsIgnoreCase("Reset"),true,"reset text mismatch" );
			generic.explicitWait(1);
			language.getPlusLinkAdvancedSearch().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(language.getLblCardNumber().getText(),"Card Number", "Card Number label text mismatch");
			sAssertion.assertEquals(language.getLblMerchantId().getText(),"Merchant ID", "Merchant ID  label text mismatch");
			sAssertion.assertEquals(language.getLblAcsTranId().getText(),"ACS Transaction ID",  "ACS Transaction ID label text mismatch");
			sAssertion.assertEquals(language.getLblAuthType().getText(),"Authentication Type", "Authentication Type  label text mismatch");
			sAssertion.assertEquals(language.getLblDeviceChannel().getText(),"Device Channel", " Device Channel label text mismatch");
			sAssertion.assertEquals(language.getLblCardUnion().getText(),"Card Union", " Card Union label text mismatch");
			sAssertion.assertEquals(language.getLblCardType().getText(),"Card Type", "Card Type  label text mismatch");
			sAssertion.assertEquals(language.getLblTranStatus().getText(),"Transaction Status", " Transaction Status label text mismatch");
			sAssertion.assertEquals(language.getLblBinNumber().getText(),"BIN Number", " BIN Number label text mismatch");
			sAssertion.assertEquals(language.getLblDataCenter().getText(),"Data Center", "Data Center  label text mismatch");
			sAssertion.assertEquals(language.getLblEnvironment().getText(),"Environment", "Environment  label text mismatch");
			sAssertion.assertEquals(language.getLblRiskScoreRange().getText(),"Risk Score Range", "Risk Score Range  label text mismatch");
			sAssertion.assertEquals(language.getLblRuleSetId().getText(),"Ruleset Id", "Ruleset Id  label text mismatch");
			sAssertion.assertEquals(language.getLblRiskEngineClientId().getText(),"Risk Engine Client ID", " Risk Engine Client ID label text mismatch");
			sAssertion.assertEquals(language.getLblProductionNode().getText(), "Production Node", " Production Node label text mismatch");
			sAssertion.assertEquals(language.getLblTransactionType().getText(), "Transaction Type", " Transaction Type label text mismatch");
			sAssertion.assertEquals(language.getLblClientId().getText(), "Client Id", " Client Id label text mismatch");
			sAssertion.assertEquals(language.getLblProtocalVersion().getText(),"Protocol Version", "Protocol Version label text mismatch");
			sAssertion.assertAll();
		}

		@Test(enabled=true, priority =12, description="ACS Transaction report column Name")
		public void validateAdvancedReportColumnNameSelectLanguageEnglish() {
			ExtentTestManager.getTest().setDescription("Validating Transaction report Header label name");
			SoftAssert sAssertion = new SoftAssert();
			AdminHomePage adminhomepage = new AdminHomePage(driver);
			SelectLanguagePage language = new SelectLanguagePage(driver);
			AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
			adminhomepage.getDropDownHeader().click();
			adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
			generic.explicitWait(1);
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase("National Bank")) {
					bankName.click();
					break;
				}
			}
			generic.explicitWait(2);
			Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
			generic.explicitWait(1);
			se.selectByValue("English");
			generic.explicitWait(1);
			language.getLinkACS().click();
			language.getAcsReportDashboards().click();
			language.getAcsTransactionReport().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			language.getLblFetchReport().click();
			generic.explicitWait(5);
			sAssertion.assertEquals(language.getLbltimeStamp().getText().equalsIgnoreCase("Time Stamp"), true, "Time Stamp text mismatch");
			sAssertion.assertEquals(language.getLblCardNumberReportResult().getText().equalsIgnoreCase("Card Number"), true, "Card Number text mismatch");
			sAssertion.assertEquals(language.getLblProtocalVer().getText().equalsIgnoreCase("Protocol"+ "\n" +"Version"), true, "ProtocolVersion text mismatch");
			sAssertion.assertEquals(language.getLblMerchName().getText().equalsIgnoreCase("Merchant"+ "\n" +"Name"), true, "Merchant Name text mismatch");
			sAssertion.assertEquals(language.getLblTranAmount().getText().equalsIgnoreCase("Trans."+ "\n" +"Amount"), true, "Trans. Amount text mismatch");
			sAssertion.assertEquals(language.getLblTranType().getText().equalsIgnoreCase("Trans."+ "\n" +"Type"), true, "Trans. Type text mismatch");
			sAssertion.assertEquals(language.getLblCardTypeReportResult().getText().equalsIgnoreCase("Card"+ "\n" +"Type"), true, "Card Type text mismatch");
			sAssertion.assertEquals(language.getLblCardTypeReportResult().getText().equalsIgnoreCase("Card"+ "\n" +"Union"), true, "Card Union text mismatch");
			sAssertion.assertEquals(language.getLblDataCentre().getText().equalsIgnoreCase("Data"+ "\n" +"Centre"), true, "Data Centre text mismatch");
			sAssertion.assertEquals(language.getLblDataCentre().getText().equalsIgnoreCase("Device"+ "\n" +"Channel"), true, "Device Channel text mismatch");
			sAssertion.assertEquals(language.getLblAuthenticationType().getText().equalsIgnoreCase("Authentication"+ "\n" +" Type"), true, "Authentication Typ etext mismatch");
			sAssertion.assertEquals(language.getLblStatus().getText().equalsIgnoreCase("Status"), true, "Status text mismatch");
			sAssertion.assertAll();
		}

		@Test(enabled=true, priority =13, description="Validating MDD Report Header")
		public void validateMddReportHeadeSelectLanguageEnglish() {
			ExtentTestManager.getTest().setDescription("Validating MDD Report Header");
			SoftAssert sAssertion = new SoftAssert();
			AdminHomePage adminhomepage = new AdminHomePage(driver);
			SelectLanguagePage language = new SelectLanguagePage(driver);
			AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
			adminhomepage.getDropDownHeader().click();
			adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
			generic.explicitWait(1);
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase("National Bank")) {
					bankName.click();
					break;
				}
			}
			generic.explicitWait(2);
			Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
			generic.explicitWait(1);
			se.selectByValue("English");
			generic.explicitWait(1);
			language.getLinkACS().click();
			language.getAcsReportDashboards().click();
			language.getAcsMddReport().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			language.getLblFetchReport().click();
			generic.explicitWait(5);
			sAssertion.assertEquals(language.getLblMddReportHeader1().getText().equalsIgnoreCase("MDD Report"), true, "MDD Report text mismatch");
			sAssertion.assertEquals(language.getLblMddReportHeader2().getText().equalsIgnoreCase("Report Results"), true, "Report Results text mismatch");	
			sAssertion.assertAll();
		}
		@Test(enabled=true, priority =14, description="Validating Dashboard Report Header")
		public void validateDashboardReportHeaderSelectLanguageEnglish() {
			ExtentTestManager.getTest().setDescription("Validating Dashboard Report Header");
			SoftAssert sAssertion = new SoftAssert();
			AdminHomePage adminhomepage = new AdminHomePage(driver);
			SelectLanguagePage language = new SelectLanguagePage(driver);
			AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
			adminhomepage.getDropDownHeader().click();
			adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
			generic.explicitWait(1);
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase("National Bank")) {
					bankName.click();
					break;
				}
			}
			generic.explicitWait(2);
			Select se = new Select(driver.findElement(By.xpath("//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")));
			generic.explicitWait(1);
			se.selectByValue("English");
			generic.explicitWait(1);
			language.getLinkACS().click();
			language.getAcsReportDashboards().click();
			language.getAcsDashboard().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(language.getLblAcsHighlight().getText().equalsIgnoreCase("ACS Highlights"), true, "ACS Highlights text mismatch");
			sAssertion.assertEquals(language.getLblTotalNumberTranINR().getText().equalsIgnoreCase("Total Number of Transactions (EUR)"), true, "Total Number of Transactions (EUR)text mismatch");
			sAssertion.assertEquals(language.getLblTotalAmountINR().getText().equalsIgnoreCase("Total Amount (EUR)"), true, "Total Amount (EUR) text mismatch");
			sAssertion.assertEquals(language.getLblAvgAmountSpendINR().getText().equalsIgnoreCase("Avg Amount Spend (EUR)"), true, "Avg Amount Spend (EUR) text mismatch");
			sAssertion.assertEquals(language.getLblAuthRate().getText().equalsIgnoreCase("Authentication Rate"), true, "Authentication Rate text mismatch");
			sAssertion.assertEquals(language.getLblTotalNumberTranAllCur().getText().equalsIgnoreCase("Total Number of Transactions(All Currencies)"), true, "Total Number of Transactions(All Currencies) text mismatch");
			sAssertion.assertEquals(language.getLblTotalNumberTranNonINR().getText().equalsIgnoreCase("Total Number of TransactionsNon(EUR)"), true, "Total Number of TransactionsNon(EUR) text mismatch");
			sAssertion.assertEquals(language.getLblTotalAmountNonINR().getText().equalsIgnoreCase("Total AmountNon(EUR)"), true, "Total AmountNon(EUR) text mismatch");
			sAssertion.assertEquals(language.getLblCardUsageBreakDown().getText().equalsIgnoreCase("Cards Usage Breakdown"), true, "Cards Usage Breakdown text mismatch");
			sAssertion.assertEquals(language.getLblFrictionlessTran().getText().equalsIgnoreCase("Frictionless Transactions"), true, "Frictionless Transactions text mismatch");
			sAssertion.assertEquals(language.getLblChallengedTran().getText().equalsIgnoreCase("Challenged Transactions"), true, "Challenged Transactions text mismatch");
			sAssertion.assertEquals(language.getLblDeclinedTran().getText().equalsIgnoreCase("Declined Transactions"), true, "Declined Transactions text mismatch");
			sAssertion.assertEquals(language.getLblFailureTran().getText().equalsIgnoreCase("Failure Transactions"), true, "Failure Transactions text mismatch");	
			sAssertion.assertEquals(language.getLblInsight().getText().equalsIgnoreCase("Insights"), true, "Insights text mismatch");	
			sAssertion.assertEquals(language.getLblTransactionTrends().getText().equalsIgnoreCase("Transaction Trends"), true, "Transaction Trends text mismatch");
			sAssertion.assertAll();
		}


	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());
	}
}

package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class ACSTxn1_0_IVRVerification extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ACSTxn1_0_IVR");
	}

	@Test(dataProvider = "DataSet")
	public void adminIVRTxnVerification(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String ProtocalVersion, String Flow, String Transtype, String CardUnionType, String OtpExpiryTime,
			String OtpType, String acsTxnId, String CavvOrAvv, String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);
		// driver.findElement(By.xpath("//span[text()='" + IssuerBankName + " Bank" +
		// "']")).click();
		// driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);
		// adminhomepage.getAcsIssuerBankNameLinkInDropDown().click();
		// adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();
		System.out.println("Clicked on Transactions Report Link");
		System.out.println("Flow is : " + Flow);

		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);
		System.out.println("Txn ID : " + acsTxnId);
		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null") || acsTxnId == "") {
			System.out.println("Acs txn id is null ");
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);

			acsTxnPage.getFetchReportButton().click();
			System.out.println("Clicked on Fetch Report button");
			generic.explicitWait(5);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			generic.explicitWait(2);
			// int doubleAmount = Integer.parseInt(amount);
			String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
			String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);

			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//div[contains(@class,'flex-table__body')]//div[1]//div[3]")));

			if (acsTxnPage.getTxnRecordCardNumber().getText().contains("xxxx")) {
				sAssertion.assertEquals(acsTxnPage.getTxnRecordCardNumber().getText(),
						firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber);
			} else {
				sAssertion.assertEquals(acsTxnPage.getTxnRecordCardNumber().getText(), Cardnumber);
			}

			sAssertion.assertEquals(acsTxnPage.getTxnRecordProtocalVersion().getText(), ProtocalVersion);

			sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnAmount().getText(), "1,000.00 USD");

			sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnType().getText(), "  IVR");

			acsTxnPage.getTxnFirstRecordInTheList().click();
			System.out.println("Clicked on displayed record to go to details report");

			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//div[span[text()='Card Number']]/div/span")));

			if (acsTxnPage.getAcstxnDetailPageCardNumberValue().getText().contains("xxxx")) {
				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageCardNumberValue().getText(),
						firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber);
			} else {
				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageCardNumberValue().getText(), Cardnumber);
			}

			sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageMerchantNameValue().getText().toLowerCase(),
					"ebay.co.in");
			sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageTransactionAmountValue().getText(), "1,000.00 USD");
			sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageDeviceChannelValue().getText(), "Browser");

			generic.explicitWait(2);

			sAssertion.assertAll();
		}

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

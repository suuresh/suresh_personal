package com.uam.testcases;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.mailReader;
import com.uam.pages.AdminHomePage;
import com.uam.pages.ForgotPasswordPage;
import com.uam.pages.LoginPage;
import com.uam.pages.TwoFactorAuthenticationPage;

public class ForgotPasswordVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
//		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
//		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ForgotPassword");
	}

	@Test(dataProvider = "DataSet",priority=1)
	public void forgotPassword(String userName, String Password, String	decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ForgotPasswordPage forgotpassword = new ForgotPasswordPage(driver);
		LoginPage loginpage = new LoginPage(driver);
		TwoFactorAuthenticationPage twofa = new TwoFactorAuthenticationPage(driver);

		Random rand = new Random();
        int rand_int1 = rand.nextInt(1000);
		
		forgotpassword.getForgotPasswordTextLink().click();
		loginpage.getLoginIDTextField().sendKeys(userName);
		twofa.getEnterCaptchTextArea().sendKeys(twofa.getCatpchText().getText());
		twofa.getSendOTPButton().click();
		generic.explicitWait(50);
		String adminOtp=mailReader.OutlookMailReader("Inbox", "OTP Alert", "is your OTP to login to ACCOSA 2.0", 6);
		System.out.println("Admin OTP is  : "+adminOtp);
		twofa.getEnterOTPTextArea().sendKeys(adminOtp);
		twofa.getOTPSubmitButton().click();
		String modifiedpassword = "Auto@"+String.valueOf(rand_int1);
		
		forgotpassword.getPasswordTextField().sendKeys(modifiedpassword);
		forgotpassword.getConfirmPasswordTextField().sendKeys(modifiedpassword);
		forgotpassword.getResetPassowordSubmitButton().click();
		
		loginpage.getLoginIDTextField().sendKeys(userName);
		loginpage.getPasswordTextField().sendKeys(modifiedpassword);
		System.out.println("Modified Password : "+modifiedpassword);
		loginpage.getLoginButton().click();
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("Wibmo");
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("Wibmo")) {
				bankName.click();
				break;
			}
		}
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + "wibmo");
		
		GenericMethods.writingToExcel(XlFileName, "ForgotPassword", Password, 2, modifiedpassword);
		sAssertion.assertAll();

	}
	
	
	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

package com.uam.testcases;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBQuery;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.ACSMDDPage;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class ACSTxnFiltersVerification extends ACSInitialSetUp {

	// date and time varibles
	public static String cDay = null;
	public static String cMonth = null;
	public static String nMonth = null;
	public static String cYear = null;
	public static String cHour = null;
	public static String cMinutes = null;
	public static String cSeconds = null;

	public static String utcDay = null;
	public static String utcMonth = null;
	public static String utcYear = null;
	public static String utcHour = null;
	public static String utcMinutes = null;
	public static String ucSeconds = null;
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "TxnFilters");
	}

	@Test(dataProvider = "DataSet")
	public void adminTxnVerification(String IssuerBankId, String IssuerBankName, String BinId, String decs)
			throws Exception {
		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = dateTime[3];
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);
		
		
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		ACSMDDPage acsmddpage = new ACSMDDPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);
		if (IssuerBankId.equalsIgnoreCase("8271")) {
			/*
			 * driver.findElement(By.xpath("//span[text()='" + IssuerBankName + " Bank" +
			 * "']")).click();
			 */
			driver.findElement(By.xpath("//span[contains(text(),'" + IssuerBankName + "')]")).click();
		} else {
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
					bankName.click();
					break;
				}
			}
		}
		// driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		if (IssuerBankId.equalsIgnoreCase("8271")) {
			System.out.println("Bank Name is not validating for saib bank");
		} else {
			sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + IssuerBankName);
		}

		// adminhomepage.getAcsIssuerBankNameLinkInDropDown().click();
		// adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();

	    acsmddpage.getDatePicker().click();
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), "5");
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), "31");
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}
		acsmddpage.getApplyButton().click();
		/*
		 * System.out.println("Clicked on Transactions Report Link");
		 * System.out.println("Flow is : " + Flow);
		 * 
		 * acsTxnPage.getAcsCalenderIcon().click();
		 * acsTxnPage.getAcsLeftHoursSelect().click(); Select acsLeftHoursOptions = new
		 * Select(acsTxnPage.getAcsLeftHoursSelect());
		 * acsLeftHoursOptions.selectByValue("0"); acsTxnPage.getApplyButton().click();
		 */

		acsTxnPage.getAcsAdevanceSearchButton().click();

		// Checking Auth Type filter.

		acsTxnPage.getAuthenticationTypeField().click();
		acsTxnPage.getAuthenticationTypeFrictionLess().click();
//		acsTxnPage.getAuthenticationTypeField().click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Frictionless");
		
		sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText(), "   FrictionLess",
				"Txn Record Auth Type mismatched");
//		acsTxnPage.getAuthenticationTypeField().click();
		acsTxnPage.getClearTheFiltersText().click();
		System.out.println("FrictionLess Verification completed");

		acsTxnPage.getAuthenticationTypeChallenge().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Challege");
		

		sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText(), "   Challenge",
				"Txn Record Auth Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();
		System.out.println("Challenge Verification completed");

		// Checking Device Channel Filter.
		acsTxnPage.getDeviceChannelField().click();
		acsTxnPage.getDeviceChannelBrowser().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Device Browser");
		
		sAssertion.assertEquals(acsTxnPage.getTxnRecordDeviceChannel().getText(), "  Browser",
				"Txn Record Device Channel mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Card Union Filter.
		acsTxnPage.getCardUnionField().click();
		acsTxnPage.getCardUnionMaster().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for CardUnion Master");
		

		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnCardUnionImage().getAttribute("src"),
				"https://3ds2-admin-uidcs.pc.enstage-sas.com/040e9ee6615290fb1edaf66fa60b575f.png",
				"Txn Record Master Card union image mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		acsTxnPage.getCardUnionVisa().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for CardUnion Visa");
		

		sAssertion.assertNotEquals(acsTxnPage.getTxnRecordTxnCardUnionImage().getAttribute("src"),
				"https://3ds2-admin-uidcs.pc.enstage-sas.com/040e9ee6615290fb1edaf66fa60b575f.png",
				"Txn Record Visa Card union image mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Card Type Filters
		acsTxnPage.getCardTypeField().click();
		acsTxnPage.getCardTypeDebit().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Card Type Debit");
		
		sAssertion.assertEquals(acsTxnPage.getTxnRecordCardType().getText(), " Debit", "Txn Record Card Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		acsTxnPage.getCardTypeCredit().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Card Type Credit");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordCardType().getText(), " Credit", "Txn Record Card Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Transaction status
		acsTxnPage.getTransactionStatusField().click();
		acsTxnPage.getTransactionStatusSuccess().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn Success");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordStatus().getAttribute("data-tip"), "SUCCESS",
				"Txn Record Status SUCCESS mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();
		
		acsTxnPage.getTransactionStatusFailure().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn Failure");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordStatus().getAttribute("data-tip"), "FAILURE",
				"Txn Record Status FAILURE mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		acsTxnPage.getTransactionStatusRejected().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn Rejected");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordStatus().getAttribute("data-tip"), "REJECTED",
				"Txn Record Status REJECTED mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Bin Number Filter
		acsTxnPage.getBinNumberField().click();
		acsTxnPage.getBinNumberSearchField().click();
		acsTxnPage.getBinNumberSearchField().sendKeys(BinId);
		acsTxnPage.getBinNumberSearchedCheckBox().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Bin Number");
		String firstSixDigitsOfTheDisplayedCardNumber = acsTxnPage.getTxnRecordCardNumber().getText().substring(0, 6);
		sAssertion.assertEquals(firstSixDigitsOfTheDisplayedCardNumber, BinId, "Txn Record Card Bin mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Data Center Filter
		acsTxnPage.getDataCenterField().click();
		acsTxnPage.getDataCenterBlr().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for data Center");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordDataCenter().getText(), "   blrrel",
				"Txn Record Data Center mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();
		acsTxnPage.getDataCenterField().click();

		// Checking Rule Set id Filter
		acsTxnPage.getRuleSetIdField().click();
		acsTxnPage.getRuleSetIdSearchField().click();
		acsTxnPage.getRuleSetIdSearchField().sendKeys("210112130434875");
		acsTxnPage.getRuleSetIdSearchedCheckBox().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Rule Set ID");
//		sAssertion.assertEquals(acsTxnPage.getTxnRecordDataCenter().getText(), "blrrel", "Txn Record Card Bin mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();
		acsTxnPage.getRuleSetIdField().click();

		// Checking Transaction Type filters
		acsTxnPage.getTransactionTypeField().click();
		acsTxnPage.getTransactionTypeECOM().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn ECOM");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnType().getText(), "  ECOM", "Txn Record Transaction Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		acsTxnPage.getTransactionTypeExpressPay().click();
		js.executeScript("window.scrollBy(0,300)", "");
	//	acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn Expresspay");
//		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnType().getText(), "EXPRESSPAY", "Txn Record Transaction Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		acsTxnPage.getTransactionTypeIVR().click();
		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Txn IVR");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnType().getText(), "  IVR", "Txn Record Transaction Type mismatched");
		js.executeScript("window.scrollBy(0,-300)", "");
		acsTxnPage.getClearTheFiltersText().click();

		// Checking Protocol Version filters
		acsTxnPage.getProtocolVersionField().click();
		acsTxnPage.getProtocolVersionOneDotO().click();
		generic.explicitWait(2);
		acsTxnPage.getProtocolVersionOneDotOSelected().click();
//		js.executeScript("window.scrollBy(0,300)", "");
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Protocol 1.0.2");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordProtocalVersion().getText(), "1.0.2", "Txn Record Protocol Version mismatched");
		acsTxnPage.getProtocolVersionOneDotOSelected().click();
		acsTxnPage.getClearTheFiltersText().click();
		
		acsTxnPage.getProtocolVersionTwoDotO().click();
		acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		generic.explicitWait(2);
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Fetch Report button for Potocol 2.1.0");
//		js.executeScript("window.scrollBy(0,300)", "");
		sAssertion.assertEquals(acsTxnPage.getTxnRecordProtocalVersion().getText(), "2.1.0", "Txn Record Protocol Version mismatched");
		acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		acsTxnPage.getClearTheFiltersText().click();

		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

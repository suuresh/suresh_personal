package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LoginPage;
import com.uam.pages.OtpDetailDuringInfligtTran;

public class AuditForOtp extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	String otpValue = null;
	String paReq = null;

	// Transaction AuditLogs 1.0
	public static final String alertOtpReSend2dot0 = "Resend OTP label=SUCCESS";
	public static final String alertOtpWrong2dot0 = "OTP validation lable SUCCESS/FAILED=N";
	public static final String alertOtpSoftBlock2dot0 = "OTP validation lable SUCCESS/FAILED=SOFT_BLOCK";
	public static final String alertOtpSuccess2dot0 = "OTP validation lable SUCCESS/FAILED=Y";
	public static final String alertOtpExpiry2dot0 = "";

	public static final String alertOtpReSend1dot0 = "Resend OTP label=SUCCESS";
	public static final String alertOtpWrongdot0 = "OTP validation lable SUCCESS/FAILED=N";
	public static final String alertOtpSoftBlock1dot0 = "OTP validation lable SUCCESS/FAILED=SOFT_BLOCK";
	public static final String alertOtpSuccess1dot0 = "OTP validation lable SUCCESS/FAILED=Y";
	public static final String alertOtpExpiry1dot0 = "";

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] OtpDetailsDuringInfiligtTxn() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AuditForOtp");
	}

	@Test(dataProvider = "OtpDetailsDuringInfiligtTxn", priority = 1, enabled = true)
	public void OtpDetailsDuringInfiligtTxn(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String MerchantId,
			String MerchantName, String TransactionAmount, String CurrencyType, String CardUnion, String EmailId,
			String MobileNumber, String MaximumOtpAttempt, String ResendOTPCount, String InvalidOTPAttempts,
			String LastOTPStatusResend, String LastOTPStatusInvalid, String OtpExpiryTime, String SchemaName, String Desc) {

		ExtentTestManager.getTest().setDescription(Desc);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		NewSimulatorCheckOutPage checkoutpage = new NewSimulatorCheckOutPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		// MPIOTPPage otpMpi = new MPIOTPPage(driver);
		OtpDetailDuringInfligtTran otpDetail = new OtpDetailDuringInfligtTran(driver);
		// GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		ArrayList<String> auditLogList = new ArrayList<String>();
		String currentURL = null;
		invocationCount++;
		if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
//		WebDriverWait wait = new WebDriverWait(driver, 15);

			System.out.println("Merchant Name : " + MerchantName);
			Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
			merchantoptions.selectByVisibleText(MerchantName);

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage.getCardNumberField().clear();
			checkoutpage.getCardNumberField().sendKeys(Cardnumber);

			checkoutpage.getCardExpiryField().clear();
			checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			System.out.println("Amout : " + TransactionAmount);
			checkoutpage.getPurchaseAmountField().clear();
			checkoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

			System.out.println("Currency : " + CurrencyType);
			checkoutpage.getCurrencyDropDown().click();
			Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
			currencyoptions.selectByVisibleText(CurrencyType);

			System.out.println("Acquirer Bank Id : " + AccquirerBankId);
			checkoutpage.getAcquirerIDField().clear();
			checkoutpage.getAcquirerIDField().sendKeys(AccquirerBankId);
			System.out.println("Protocal Version : " + ProtocalVersion);

			// putting try catch block to handle popup
			try {
				String versionCheckUrl = checkoutpage.getVersionCheckURLFeild().getAttribute("value");
				System.out.println("Version check url from simulator : " + versionCheckUrl);
				String arr[] = versionCheckUrl.split("pVrq/");
				System.out.println("Splitter version Check url is : " + arr[0]);
				String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
				System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
				checkoutpage.getVersionCheckURLFeild().clear();
				checkoutpage.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
				checkoutpage.getSubmitButton().click();

				System.out.println("Clicked on Checkout button");

				if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Submit paReq']")));
					checkoutpage.getSubmitPaReqButton().click();
					System.out.println("Clicked on PaReq button");

				}

				switch (Flow) {

				case "Challenge":
					log.info(Flow + "Started");
					// generic.explicitWait(3);
					if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
						// generic.explicitWait(3);
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL);
						acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
						// generic.explicitWait(2);
					} else {
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
						// document.getElementByName('acctId').value").toString();
						// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
						System.out.println("Clicked on Checkout button");

						/*
						 * Getting ACSTcnId from Pareq Date-28-07-2020
						 */

						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL);
						paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
						System.out.println("Pareq:-" + paReq);
						String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
						// System.out.println("tesdDecode:-" + tesdDecode);
						String arr1[] = tesdDecode.split("&");
						String testEncodedPaReq = arr1[0];
						String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
						System.out.println("testDecodedPareq:-" + testDecodedPareq);
						acsTxnId = generic.getValueFromXml(testDecodedPareq);
						System.out.println("acsTxnId:-" + acsTxnId);
						generic.explicitWait(2);
					}

					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);
					
					
					// Check OTP IS encrypted in or not
					
					String encryptedOtp = GenericMethods.getGeneratedOTPFromDB(SchemaName, acsTxnId);
					
					sAssertion.assertTrue(encryptedOtp.length()>6);

					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

					otp.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);

					otp.getOtpSubmitButton().click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@id='transStatus']")));

					break;

				case "OTPExpiry":
					log.info(Flow + "Started");
					// generic.explicitWait(3);

					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					// generic.explicitWait(2);

					System.out.println("ACS Txn Id is : " + acsTxnId);
					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
					// Waiting Explicitly for OTP to be expired.
					generic.explicitWait(240);
					otp.getOtpTextField().sendKeys(otpValue);
					otp.getOtpSubmitButton().click();
					generic.explicitWait(3);

					break;

				case "BlockCard":
					log.info(Flow + "Started");
					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					System.out.println("OTP page and Submit Button Displayed for BlockCard Scenario");

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
					generic.explicitWait(2);
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					wait.until(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='hei mid-content']")));
					sAssertion.assertEquals(otp.getInvalidOTPMessage().getText(),
							"The code you entered is incorrect please try again.");
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();
					otp.getOtpTextField().sendKeys("123456");
					otp.getOtpSubmitButton().click();

					break;

				case "Canceled":

					wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//button[contains(text(),'CONFIRM')]")));
					System.out.println("OTP page and Submit Button Displayed for Cancel Scenario");

					NetWorklogs = driver.manage().logs().get("performance");
					System.out.println("NETWORK LOGS: " + NetWorklogs);
					currentURL = driver.getCurrentUrl();
					System.out.println("Current URL : " + currentURL);
					acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);

					otp.getOtpResendButton().click();
					generic.explicitWait(2);
					otp.getOtpResendButton().click();
					generic.explicitWait(2);
					otp.getOtpResendButton().click();
					generic.explicitWait(2);
					otp.getOtpCancelButton().click();
					generic.explicitWait(2);
					break;
				}
			} catch (Exception e) {
				// TODO: handle exception
			}

		} else {

			driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
			generic.explicitWait(5);
			// initializing the page objects
			MPICheckOutPage mpiCheckoutpage = new MPICheckOutPage(driver);

			/*
			 * String currentURL = null; invocationCount++;
			 */

			System.out.println("Card Number : " + Cardnumber);
			mpiCheckoutpage.getCardNumberField().clear();
			mpiCheckoutpage.getCardNumberField().sendKeys(Cardnumber);

			generic.selectByVisibleText(mpiCheckoutpage.getMerchantTextField(), MerchantId);

			mpiCheckoutpage.getCardExpiryField().clear();
			mpiCheckoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			mpiCheckoutpage.getCardCVVField().clear();
			mpiCheckoutpage.getCardCVVField().sendKeys("111");

			mpiCheckoutpage.getQuantityField().clear();
			mpiCheckoutpage.getQuantityField().sendKeys("1");

			mpiCheckoutpage.getPurchaseAmountField().clear();
			mpiCheckoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

			generic.selectByVisibleText(mpiCheckoutpage.getCurrencyField(), "INR");
			generic.explicitWait(3);
			mpiCheckoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			System.out.println("Clicked on Checkout button");

			// For Karnataka Bank

			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(5);
			}
			// MPIOTPPage otp = new MPIOTPPage(driver);
			if (String.valueOf(otp.getEnglishLangNBEbank().isDisplayed()).equalsIgnoreCase("true")) {
				// Change UI in English
				otp.getEnglishLangNBEbank().click();
			}

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */
			try {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
			} catch (Exception x) {
				System.out.println("Exception for 2.0 " + x);
			}
			// Re-send OTP

			/*
			 * int n = Integer.parseInt(ResendOTPCount); for (int i = 1; i <= n; i++) {
			 * otpDetail.getOtpResendButton().click(); generic.explicitWait(2); }
			 * 
			 * // InValidOtp int v = Integer.parseInt(InvalidOTPAttempts); for (int j = 1; j
			 * <= v; j++) { otpDetail.getOtpTextField().clear();
			 * otpDetail.getOtpTextField().sendKeys("982312");
			 * otpDetail.getOtpSubmitButton().click(); }
			 */

			// Another approach
			otpDetail.getOtpResendButton().click();
			generic.explicitWait(2);
			otpDetail.getOtpResendButton().click();
			generic.explicitWait(2);
		}

		// Verify Audit for Otp Detail in Admin portal
		generic.explicitWait(5);
		LoginPage lp = new LoginPage(driver);
		driver.get(Config.BASE_UAM_URL);
		// driver.manage().window().maximize();
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		generic.explicitWait(3);

		// Navigating to Audit logs
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();
		System.out.println("Clicked on Transactions Report Link");
		System.out.println("Flow is : " + Flow);

		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);

		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null")) {
			System.out.println("Acs txn id is null ");
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);
		}

		acsTxnPage.getFetchReportButton().click();
		System.out.println("Clicked on Fetch Report button");
		generic.explicitWait(4);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'flex-table__body')]//div[1]//div[3]")));

		acsTxnPage.getTxnFirstRecordInTheList().click();
		System.out.println("Clicked on displayed record to go to details report");

		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[span[text()='Card Number']]/div/span")));

		// verify Audit logs
		generic.explicitWait(3);
		acsTxnPage.getDetailedTransactionOutputExpandLink().click();
		generic.explicitWait(1);
		acsTxnPage.getTransactionAuditLogs().click();

		List<WebElement> custJourney = driver
				.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
		for (WebElement auditLogs : custJourney) {

			auditLogList.add(auditLogs.getText());
		}
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {

		} else {
			System.out.println("Assert for 2.0 protocol");
			if (Flow.equalsIgnoreCase("Challenge")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpSuccess2dot0), "Challenge Audit logs");
			} else if (Flow.equalsIgnoreCase("BlockCard")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpWrong2dot0), "BlockCard Audit Validation");
				sAssertion.assertTrue(auditLogList.contains(alertOtpSoftBlock2dot0), "BlockCard Audit Validation");
			} else if (Flow.equalsIgnoreCase("Canceled")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReSend2dot0), "Canceled Audit logs");
			} else if (Flow.equalsIgnoreCase("OTPExpiry")) {
				//sAssertion.assertTrue(auditLogList.contains(alertOtpExpiry2dot0), "OtpExpiry Audit logs");
			}
		}
		sAssertion.assertAll();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}

}

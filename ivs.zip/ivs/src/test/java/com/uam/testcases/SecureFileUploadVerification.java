package com.uam.testcases;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.DBQuery;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.ACSMDDPage;
import com.uam.pages.AcsSmsMisPage;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.CustomerDataUploadPage;
import com.uam.pages.SecureFileUpload;

public class SecureFileUploadVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	/*
	 * @DataProvider public Object[][] SecureFile() throws IOException {
	 * 
	 * System.out.println("Reading data from excell file"); return
	 * generic.getData(XlFileName, "SecureFile"); }
	 */
	@Test
	public void validateSecureFileUpload() {

		ExtentTestManager.getTest().setDescription("Validating static fields in Secure file Upload Page.");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		SecureFileUpload securefile = new SecureFileUpload(driver);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}

		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + "National Bank");
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		securefile.getSecureFileUploadLink().click();
		generic.explicitWait(2);
		sAssertion.assertEquals(securefile.getSecureFileUploadPageHeading().getText(), "Secure File Generate");
		sAssertion.assertEquals(securefile.getPublickeyHeading().getText(),
				"Please upload public key (.txt extension) *");
		sAssertion.assertEquals(securefile.getCsvFileHeading().getText(), "Please upload a CSV file to encrypt*");
		
		securefile.getGeneratePGPFileButton().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(securefile.getErrorMessageIfNofilesuploaded().getText(),
				"Please upload a vaild public key and CSV file.");
		generic.explicitWait(5);
		
		securefile.getPublicKeyInputField().sendKeys(Config.UPLOADINGFILES_PATH + "One_Successul_Record__NoHeader.csv");
		generic.explicitWait(1);
		sAssertion.assertEquals(securefile.getErrorMessageForPublicFileExtension().getText(),
				"Please upload a vaild text file (.txt extension)");
		
		generic.explicitWait(5);
		securefile.getCsvFileInputField().sendKeys(Config.UPLOADINGFILES_PATH + "Success_20_Records_NoHeader.pgp");
		generic.explicitWait(1);
		sAssertion.assertEquals(securefile.getErrorMessageForCsvFileExtention().getText(),
				"Please upload a vaild csv file.");
		
		generic.explicitWait(5);
		securefile.getPublicKeyInputField().clear();
		securefile.getPublicKeyInputField().sendKeys(Config.UPLOADINGFILES_PATH + "Invalid_public_key.txt");
		securefile.getCsvFileInputField().clear();
		securefile.getCsvFileInputField().sendKeys(Config.UPLOADINGFILES_PATH + "One_Successul_Record__NoHeader.csv");
		securefile.getGeneratePGPFileButton().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(securefile.getErrorMessageForInvalidPublicKeyFile().getText(),
				"Please verify the public key.");
		
		generic.explicitWait(5);
		securefile.getPublicKeyInputField().clear();
		securefile.getPublicKeyInputField().sendKeys(Config.UPLOADINGFILES_PATH + "public_key.txt");
		securefile.getCsvFileInputField().clear();
		securefile.getCsvFileInputField().sendKeys(Config.UPLOADINGFILES_PATH + "One_Successul_Record__NoHeader.csv");
		securefile.getGeneratePGPFileButton().click();
		generic.explicitWait(1);
		sAssertion.assertEquals(securefile.getSuccessMessageForGeneratePGPFile().getText(),
				"Successfully downloaded encrypted .pgp file.");
		generic.explicitWait(5);
		
		securefile.getCancelButton().click();
		
		sAssertion.assertAll();
		
	}
	
	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}

}

package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class TxnVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName,"CardDetails");
	}

	@Test(dataProvider = "DataSet")
	public void adminTxnVerification(String Cardnumber, String Flow, String merchantname, String amount,
			String currencytype, String CardUnionType, String acsTxnId, String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);

		adminhomepage.getDropDownHeader().click();
//		adminhomepage.getAcsIssuerBankNameLinkInDropDown().click();
		// adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();

		// adminhomepage.getAcsFetchTransactionReportLink().click();
		acsTxnPage.getAcsAdevanceSearchButton().click();
		if (Flow.equalsIgnoreCase("FrictionLess")||Flow.equalsIgnoreCase("Failed")||Flow.equalsIgnoreCase("Blocked")) {
			acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);
			
			// acsTxnPage.getAcsTxnIDTextField().sendKeys(generic.getACSTxnIDFromDB());
		}
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(1);

		sAssertion.assertEquals(acsTxnPage.getTxnRecordMerchantName().getText(), merchantname);
		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnAmount().getText(), amount + " " + currencytype);

		switch (Flow) {

		case "FrictionLess":

			sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText(), Flow);

			break;

		case "Static":

			break;

		case "Challenge":

			sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText(), Flow);

			break;

		case "Single":

			break;

		case "Multi":

			break;

		case "Blocked":

			break;

		case "BlockCard":

			break;

		case "Canceled":

			break;

		}

		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();

	}
}

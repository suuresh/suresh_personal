package com.uam.testcases;

import java.io.IOException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.PgResponsePage;
import com.acs.testcases.ACSInitialSetUp;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminACSRBAPage;
import com.uam.pages.AdminHomePage;

public class UAMPagesVerification extends ACSInitialSetUp{
	
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;
	
	@BeforeMethod
	public void beforeAuthenticationMethod() {
		driver.get(Config.BASE_UAM_URL);
		
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		
	}
	
	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName,"RBAScript");
	}
	

	@Test(priority=0)
	public void HomePageVerification() {
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		
		SoftAssert sAssertion = new SoftAssert();
		sAssertion.assertTrue(adminhomepage.getSideBarLinkACS().isDisplayed());
		sAssertion.assertTrue(adminhomepage.getSideBarLinkUAM().isDisplayed());	
		sAssertion.assertTrue(adminhomepage.getSideBarLinkUAM().isDisplayed());
	}
	
	@Test(priority=1)
	public void ACSTxnPageVerification() {
}
	
	@Test(priority=1)
	public void ThreeDSTxnPageVerification() {
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		
		SoftAssert sAssertion = new SoftAssert();
		sAssertion.assertTrue(adminhomepage.getSideBarLinkACS().isDisplayed());
		sAssertion.assertTrue(adminhomepage.getSideBarLinkUAM().isDisplayed());	
	}
	
	
	@AfterMethod
	public void afterMethod() {
		logout.logout();
	//	driver.quit();

	}
	
}

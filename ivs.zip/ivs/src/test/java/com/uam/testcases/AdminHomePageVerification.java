package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LoginPage;

public class AdminHomePageVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	
	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	
	@Test()
	public void adminTxnVerification() throws Exception {

		ExtentTestManager.getTest().setDescription("Admin Home Page Element Verification");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage homepage = new AdminHomePage(driver);
		sAssertion.assertTrue(homepage.getProjectLogo().isDisplayed());
		log.info("Project logo is displayed");
		sAssertion.assertEquals(homepage.getHeaderAccosaProjectName().getText(), "ACCOSA IVSTM");
		sAssertion.assertEquals(homepage.getHeaderBankDropDown().getText(), "SELECT A BANK");
		sAssertion.assertTrue(homepage.getHeaderLanguageDropDown().isDisplayed());
		sAssertion.assertTrue(homepage.getHeaderUserProfileDropDown().isDisplayed());
		sAssertion.assertTrue(homepage.getSideBarLinkACS().isDisplayed());
		sAssertion.assertEquals(homepage.getSideBarLinkACS().getText(), "ACS");
		sAssertion.assertTrue(homepage.getSideBarLink3DSS().isDisplayed());
		sAssertion.assertEquals(homepage.getSideBarLink3DSS().getText(), "3DSS");
		sAssertion.assertTrue(homepage.getSideBarLinkUAM().isDisplayed());
		sAssertion.assertEquals(homepage.getSideBarLinkUAM().getText(), "UAM");
		
		sAssertion.assertTrue(homepage.getHomepageWelcomeMessageTitle().isDisplayed());
		sAssertion.assertEquals(homepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		
		sAssertion.assertTrue(homepage.getHomepageWelcomeMessage().isDisplayed());
		sAssertion.assertEquals(homepage.getHomepageWelcomeMessage().getText(), "Please select a bank to proceed.");
		
		sAssertion.assertTrue(homepage.getFooterCopyRightText().isDisplayed());
		sAssertion.assertEquals(homepage.getFooterCopyRightText().getText(), "Copyright © 2019 Wibmo Inc.");
		
		sAssertion.assertAll();
		System.out.println("Admin Home Page Element verification is finished");

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
	//	logout.logout();
		// driver.quit();

	}
}

package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.ManageBanksPage;

public class CreateBank extends ACSInitialSetUp {

	int invocationCount = 1;
	public static String RandombankID;
	public static String RandombankCode;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateBank");
	}

	@Test(dataProvider = "DataSet", priority = 0)
	public void createBank(String bnkname, String bnkcode, String bnkid, String timezone, String currencytype,
			String clustername, String logourl, String enable, String acsproduct, String threedsproduct,
			String uamproduct, String ACSScreen1, String ACSScreen2, String ACSScreen3, String ACSScreen4,
			String ACSScreen5, String threedsScreen1, String threedsScreen2, String threedsScreen3,
			String threedsScreen4, String threedsScreen5, String UAMScreen1, String UAMScreen2, String UAMScreen3,
			String UAMScreen4, String UAMScreen5, String Decs) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBanksPage mngbankpage = new ManageBanksPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;
		ExtentTestManager.getTest().setDescription(Decs);
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageBankLink().click();
		mngbankpage.getCreateBankPlusButton().click();
		generic.explicitWait(2);
		// DO Hack
		mngbankpage.getCreateBankCancelButton().click();
		generic.explicitWait(2);
		mngbankpage.getCreateBankPlusButton().click();
		
		generic.explicitWait(2);
		mngbankpage.getBankNameTextField().clear();
		mngbankpage.getBankNameTextField().sendKeys(bnkname);
		mngbankpage.getTimezonedropdown().click();
		mngbankpage.getTimezoneSearchfield().sendKeys(timezone);
		mngbankpage.getTimezoneselect().click();
		generic.explicitWait(2);

		// mngbankpage.getBankCodeTextField().sendKeys(bnkcode);

		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RandomNum = "" + randomPIN;
		RandombankCode = "test" + RandomNum;
		System.out.println("Bank Code is " + RandombankCode);
		mngbankpage.getBankCodeTextField().sendKeys(RandombankCode);
		generic.writingToExcel(XlFileName, "CreateBank", "BankCode", invocationCount, RandombankCode);

		// mngbankpage.getBankIdTextField().sendKeys(bnkid);

		randomPIN = (int) (Math.random() * 9000) + 1000;
		RandomNum = "" + randomPIN;
		RandombankID = RandomNum;
		System.out.println("Bank ID is " + RandombankID);
		mngbankpage.getBankIdTextField().sendKeys(RandombankID);
		generic.writingToExcel(XlFileName, "CreateBank", "BankID", invocationCount, RandombankID);
		generic.writingToExcel(XlFileName, "CreateBank", "BankCode", invocationCount, "test" + RandombankID);

		generic.explicitWait(2);
		mngbankpage.getCurrencySelectDropDownField().click();
		generic.explicitWait(2);
		mngbankpage.getCurrencySearchfield().sendKeys(currencytype);
		generic.explicitWait(2);
		mngbankpage.getSelectCurrency().click();
		generic.explicitWait(2);
		// driver.findElement(By.xpath("//label[contains(text(),'"+currencytype+"')]")).click();

		// mngbankpage.getBucketsTextField().sendKeys(buckets);

		mngbankpage.getClusterdropdown().click();
		generic.explicitWait(2);
		if (clustername.equalsIgnoreCase("dcs")) {
			mngbankpage.getSelectdcs().click();
		} else if (clustername.equalsIgnoreCase("3ds2dcs")) {
			mngbankpage.getSelect3ds2dcs().click();
		} else if (clustername.equalsIgnoreCase("rbadcs")) {
			mngbankpage.getSelectrbadcs().click();
		}

		mngbankpage.getBankLogoURLTextField().sendKeys(logourl);

		mngbankpage.getMakerchecker().click();

		generic.explicitWait(2);
		if (enable.equalsIgnoreCase("Yes")) {
			mngbankpage.getSelectMakerYes().click();
		} else if (enable.equalsIgnoreCase("No")) {
			mngbankpage.getSelect3ds2dcs().click();
		}
		// mngbankpage.getSelectcmakerchecker().sendKeys(enable);

		generic.explicitWait(2);
		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("arguments[0].scrollIntoView();",
		 * mngbankpage.getProductUAMCheckBox());
		 */
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");

		if (acsproduct.equalsIgnoreCase("Yes")) {
			mngbankpage.getProductACSCheckBox().click();
		}
		generic.explicitWait(2);
		if (threedsproduct.equalsIgnoreCase("Yes")) {
			mngbankpage.getProduct3DSCheckBox().click();
		}
		generic.explicitWait(2);
		if (uamproduct.equalsIgnoreCase("Yes")) {
			mngbankpage.getProductUAMCheckBox().click();

		}
		js.executeScript("window.scrollBy(0,-500)");
		// js.executeScript("arguments[0].scrollIntoView();",
		// mngbankpage.getCreateBankButton());
		generic.explicitWait(2);

		WebElement button = driver.findElement(By.xpath("//a[text()='Create Bank']"));

		System.out.println("select createbank 2");
		// mngbankpage.getCreateBankButton().click();
		// Perform Click on LOGIN button using JavascriptExecutor
		js.executeScript("arguments[0].click();", button);
		System.out.println("select createbank 3");
		generic.explicitWait(3);
		
		js.executeScript("window.scrollBy(0,-300)");
		generic.explicitWait(3);
		
		mngbankpage.getListPerPageDropDown().click();
		mngbankpage.getList30PerPageRadioButton().click();
		mngbankpage.getSearchByBankIdTextField().sendKeys(RandombankID);

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("//div[text()='" + RandombankID + "']/following::div[@data-tip='Edit']"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		sAssertion.assertEquals(mngbankpage.getListedBankName().getText(), bnkname);
		sAssertion.assertEquals(mngbankpage.getListedBankId().getText(), RandombankID);
		// sAssertion.assertEquals(mngbankpage.getListedBucketName().getText(), );
		sAssertion.assertEquals(mngbankpage.getListedCurrencyOfBank().getText(), currencytype);
		// String producttext = mngbankpage.getListedProductsOfBank().getText();
		// sAssertion.assertAll();

		if (acsproduct.equalsIgnoreCase("Yes") && threedsproduct.equalsIgnoreCase("Yes")
				&& uamproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("ACS"));
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("3DS"));
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("UAM"));
			// sAssertion.assertAll();

		} else if (acsproduct.equalsIgnoreCase("Yes") && threedsproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("ACS"));
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("3DS"));
			// sAssertion.assertAll();

		} else if (acsproduct.equalsIgnoreCase("Yes") && uamproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("ACS"));
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("UAM"));
			// sAssertion.assertAll();

		} else if (threedsproduct.equalsIgnoreCase("Yes") && uamproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("3DS"));
			sAssertion.assertTrue(mngbankpage.getListedProductsOfBank().getText().contains("UAM"));
			// sAssertion.assertAll();

		} else if (threedsproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertEquals(mngbankpage.getListedProductsOfBank().getText(), "3DS");
			// sAssertion.assertAll();

		} else if (acsproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertEquals(mngbankpage.getListedProductsOfBank().getText(), "ACS");
			// sAssertion.assertAll();

		} else if (uamproduct.equalsIgnoreCase("Yes")) {
			sAssertion.assertEquals(mngbankpage.getListedProductsOfBank().getText(), "UAM");
			// sAssertion.assertAll();
		}

		sAssertion.assertAll();

		// generic.deleteBankIdInDB(bnkid);
	}

	@DataProvider
	public Object[][] AssignDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateBank");
	}

	@Test(dataProvider = "AssignDataSet", priority = 1)
	public void assignScreens(String bnkname, String bnkcode, String bnkid, String timezone, String currencytype,
			String clustername, String logourl, String enable, String acsproduct, String threedsproduct,
			String uamproduct, String ACSScreen1, String ACSScreen2, String ACSScreen3, String ACSScreen4,
			String ACSScreen5, String threedsScreen1, String threedsScreen2, String threedsScreen3,
			String threedsScreen4, String threedsScreen5, String UAMScreen1, String UAMScreen2, String UAMScreen3,
			String UAMScreen4, String UAMScreen5, String Decs) {

		ExtentTestManager.getTest().setDescription(Decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBanksPage mngbankpage = new ManageBanksPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageBankLink().click();

		generic.explicitWait(2);

		mngbankpage.getListPerPageDropDown().click();
		mngbankpage.getList30PerPageRadioButton().click();
		mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		mngbankpage.getAssignScreenButton().click();
		System.out.println("Entering assign screens");
		mngbankpage.getProductDropdown().click();
		System.out.println("Select the product dropdown");

		// ASSIGN SCREEN FOR 3DSS,ACS and UAM PRODUCTS
		if (acsproduct.equalsIgnoreCase("Yes") && threedsproduct.equalsIgnoreCase("Yes")
				&& uamproduct.equalsIgnoreCase("Yes")) {
			System.out.println("Start Assigning screens for 3DSS, ACS and UAM");

			/*---------3DSS Products screens--------------*/
			System.out.println("Entering screens for 3DSS product");

			mngbankpage.getProduct3DSCheckBox().click();
			generic.explicitWait(2);

			/*
			 * boolean se = mngbankpage.getCheckbox().isSelected();
			 * System.out.println("checkpoint1"+se);
			 * if(String.valueOf(se).equalsIgnoreCase("false")) {
			 * 
			 * System.out.println("checkpoint2"); mngbankpage.getScreenSelect().click();
			 * System.out.println("selecting if 3dss dashboard not selected"); }
			 */

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen1);
			System.out.println("selecting 3dsss screen1");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3dss dashboard if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Acquirer Configuration if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to 3DSS products
			mngbankpage.getAssignButton().click();

			// Search the bank from pagination
			mngbankpage.getListPerPageDropDown().click();
			mngbankpage.getList30PerPageRadioButton().click();
			mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			mngbankpage.getAssignScreenButton().click();
			System.out.println("Entering assign screens");
			mngbankpage.getProductDropdown().click();
			System.out.println("Select the product dropdown");

			/*---------ACS Products screens--------------*/

			System.out.println("Entering screens for ACS product");

			mngbankpage.getProductACSCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting ACS trnx report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Blocked Cards report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);

			// Search the bank from pagination
			mngbankpage.getListPerPageDropDown().click();
			mngbankpage.getList30PerPageRadioButton().click();
			mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			mngbankpage.getAssignScreenButton().click();
			System.out.println("Entering assign screens");
			mngbankpage.getProductDropdown().click();
			System.out.println("Select the product dropdown");

			// Start assigning the screens for UAM product
			/*---------UAM Product screen--------------*/

			System.out.println("Entering screens for UAM product");

			mngbankpage.getProductUAMCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage User if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Groups if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}
			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);
		} /* End of assigning screens for 3DSS, ACS and UAN */

		else if (acsproduct.equalsIgnoreCase("Yes") && uamproduct.equalsIgnoreCase("Yes")) {

			/*---------ACS Products screens--------------*/

			System.out.println("Entering screens for ACS product");

			mngbankpage.getProductACSCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting ACS trnx report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Blocked Cards report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);

			// Search the bank from pagination
			mngbankpage.getListPerPageDropDown().click();
			mngbankpage.getList30PerPageRadioButton().click();
			mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			mngbankpage.getAssignScreenButton().click();
			System.out.println("Entering assign screens");
			mngbankpage.getProductDropdown().click();
			System.out.println("Select the product dropdown");

			/*---------UAM Product screen--------------*/

			System.out.println("Entering screens for UAM product");

			mngbankpage.getProductUAMCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage User if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Groups if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}
			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);

		} /* end of assigning screens for ACS and UAM */

		else if (threedsproduct.equalsIgnoreCase("Yes") && uamproduct.equalsIgnoreCase("Yes")) {

			/*---------3DSS Products screens--------------*/
			System.out.println("Entering screens for 3DSS product");

			mngbankpage.getProduct3DSCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen1);
			System.out.println("selecting 3dsss screen1");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3dss dashboard if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Acquirer Configuration if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to 3DSS products
			mngbankpage.getAssignButton().click();

			// Search the bank from pagination
			mngbankpage.getListPerPageDropDown().click();
			mngbankpage.getList30PerPageRadioButton().click();
			mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			mngbankpage.getAssignScreenButton().click();
			System.out.println("Entering assign screens");
			mngbankpage.getProductDropdown().click();
			System.out.println("Select the product dropdown");

			/*---------UAM Product screen--------------*/

			System.out.println("Entering screens for UAM product");

			mngbankpage.getProductUAMCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage User if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Groups if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}
			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);

		} /* end of assigning screens for 3DS and UAM */

		else if (acsproduct.equalsIgnoreCase("Yes") && threedsproduct.equalsIgnoreCase("Yes")) {

			/*---------ACS Products screens--------------*/

			System.out.println("Entering screens for ACS product");

			mngbankpage.getProductACSCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting ACS trnx report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Blocked Cards report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);

			// Search the bank from pagination
			mngbankpage.getListPerPageDropDown().click();
			mngbankpage.getList30PerPageRadioButton().click();
			mngbankpage.getSearchByBankIdTextField().sendKeys(bnkid);

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + bnkid + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			mngbankpage.getAssignScreenButton().click();
			System.out.println("Entering assign screens");
			mngbankpage.getProductDropdown().click();
			System.out.println("Select the product dropdown");

			/*---------UAM Product screen--------------*/

			System.out.println("Entering screens for UAM product");

			mngbankpage.getProductUAMCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage User if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Groups if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}
			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);
		}
		// ASSIGN SCREEN FOR ACS PRODUCTS
		else if (acsproduct.equalsIgnoreCase("Yes")) {

			/*---------ACS Products screens--------------*/

			System.out.println("Entering screens for ACS product");

			mngbankpage.getProductACSCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting ACS trnx report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Blocked Cards report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(ACSScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Alert report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);
		}

		else if (threedsproduct.equalsIgnoreCase("Yes")) {
			/*---------3DSS Products screens--------------*/
			System.out.println("Entering screens for 3DSS product");

			mngbankpage.getProduct3DSCheckBox().click();
			generic.explicitWait(2);

			/*
			 * boolean se = mngbankpage.getCheckbox().isSelected();
			 * System.out.println("checkpoint1"+se);
			 * if(String.valueOf(se).equalsIgnoreCase("false")) {
			 * 
			 * System.out.println("checkpoint2"); mngbankpage.getScreenSelect().click();
			 * System.out.println("selecting if 3dss dashboard not selected"); }
			 */

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen1);
			System.out.println("selecting 3dsss screen1");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3dss dashboard if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Acquirer Configuration if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(threedsScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting 3DSS transaction report if NOT selected");
			}

			// Once all screens selected, click on Assign screen to 3DSS products
			mngbankpage.getAssignButton().click();

		}

		else if (uamproduct.equalsIgnoreCase("Yes")) {

			/*---------UAM Product screen--------------*/

			System.out.println("Entering screens for UAM product");

			mngbankpage.getProductUAMCheckBox().click();
			generic.explicitWait(2);

			mngbankpage.getScreenSelect().click();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen1);
			System.out.println("selecting ACS Trnx report");
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage User if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen2);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Groups if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen3);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen4);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}

			mngbankpage.getScreenSearch().clear();
			mngbankpage.getScreenSearch().sendKeys(UAMScreen5);
			generic.explicitWait(2);

			if (mngbankpage.getCheckbox().isSelected() == false) {
				mngbankpage.getScreenSelect().click();
				generic.explicitWait(2);
				System.out.println("selecting Manage Banks if NOT selected");
			}
			// Once all screens selected, click on Assign screen to ACS products
			mngbankpage.getAssignButton().click();
			generic.explicitWait(2);
		}

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();

	}
}

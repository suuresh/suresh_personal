package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LoginPage;

public class LoginPageVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	
	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
	//	loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	
	@Test()
	public void adminTxnVerification() throws Exception {

		ExtentTestManager.getTest().setDescription("Login Page Verification");
		SoftAssert sAssertion = new SoftAssert();
		LoginPage loginpage = new LoginPage(driver);
//		sAssertion.assertEquals(generic.verifyimageActive(loginpage.getProjectLogo()), 200);
		sAssertion.assertEquals(loginpage.getAccosaProjectName().getText(), "ACCOSA IVSTM");
		sAssertion.assertEquals(loginpage.getLoginPageHeadingText().getText(), "Log In");
		sAssertion.assertEquals(loginpage.getLoginWarningMessageText().getText(), "Warning: Unauthorized access to this system is forbidden and will be prosecuted by law. By accessing this system, you agree that your actions may be monitored if unauthorized usage is suspected.");
		sAssertion.assertEquals(loginpage.getLoginIdTextBoxLableText().getText(), "Login ID");
		sAssertion.assertTrue(loginpage.getLoginIDTextField().isDisplayed());
		sAssertion.assertEquals(loginpage.getPasswordTextBoxLableText().getText(), "Password");
		sAssertion.assertTrue(loginpage.getPasswordTextField().isDisplayed());
		sAssertion.assertTrue(loginpage.getForgotPasswordLinkText().isDisplayed());
		sAssertion.assertTrue(loginpage.getLoginButton().isDisplayed());
		sAssertion.assertTrue(loginpage.getSetPasswordLinkText().isDisplayed());
		sAssertion.assertAll();
		System.out.println("Login Page Element verification is finished");

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
	//	logout.logout();
		// driver.quit();

	}
}

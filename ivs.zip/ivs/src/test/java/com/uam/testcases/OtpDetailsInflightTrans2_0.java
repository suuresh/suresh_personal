package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.pages.StaticPasswordPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromDynamicConfig;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LoginPage;
import com.uam.pages.OtpDetailDuringInfligtTran;

public class OtpDetailsInflightTrans2_0 extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	private int invalidImageCount;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	@DataProvider
	public Object[][] OtpDetailsInflightTransFor2_0() throws IOException {

		log.info("Reading data from excell file");
		return generic.getData(XlFileName, "OtpDetails2_0");
	}

	@Test(dataProvider = "OtpDetailsInflightTransFor2_0", invocationCount = 1)
	public void OtpDetailsInflightTransFor2_0(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String MerchantId,
			String MerchantName, String TransactionAmount, String CurrencyType, String CardUnion, String EmailId,
			String MobileNumber, String MaximumOtpAttempt, String ResendOTPCount, String InvalidOTPAttempts,
			String LastOTPStatusResend, String LastOTPStatusInvalid, String Desc) throws Exception {

		ExtentTestManager.getTest().setDescription(Desc);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		NewSimulatorCheckOutPage checkoutpage = new NewSimulatorCheckOutPage(driver);
		NewSimulatorOTPPage otp = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		OtpDetailDuringInfligtTran otpDetail = new OtpDetailDuringInfligtTran(driver);
//		WebDriverWait wait = new WebDriverWait(driver, 15);
		String currentURL = null;
		invocationCount++;

		System.out.println("Merchant Name : " + MerchantName);
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(MerchantName);

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		System.out.println("Amout : " + TransactionAmount);
		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

		System.out.println("Currency : " + CurrencyType);
		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(CurrencyType);

		System.out.println("Acquirer Bank Id : " + AccquirerBankId);
		checkoutpage.getAcquirerIDField().clear();
		checkoutpage.getAcquirerIDField().sendKeys(AccquirerBankId);
		System.out.println("Protocal Version : " + ProtocalVersion);

		// putting try catch block to handle pop-up
		try {
			String versionCheckUrl = checkoutpage.getVersionCheckURLFeild().getAttribute("value");
			System.out.println("Version check url from simulator : " + versionCheckUrl);
			String arr[] = versionCheckUrl.split("pVrq/");
			System.out.println("Splitter version Check url is : " + arr[0]);
			String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
			System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
			checkoutpage.getVersionCheckURLFeild().clear();
			checkoutpage.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
			checkoutpage.getSubmitButton().click();

			if (String.valueOf(otp.getEnglishLangNBEbank().isDisplayed()).equalsIgnoreCase("true")) {
				// Change UI in English
				otp.getEnglishLangNBEbank().click();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("Clicked on Checkout button");

		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Submit paReq']")));
			checkoutpage.getSubmitPaReqButton().click();
			System.out.println("Clicked on PaReq button");

		}

		// After submitting checkoutPage

		// generic.explicitWait(3);
		if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
			// generic.explicitWait(3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='submitBtn']")));
			NetWorklogs = driver.manage().logs().get("performance");
			System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			System.out.println("Current URL : " + currentURL);
			acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			// generic.explicitWait(2);
		} else {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='submitBtn']")));
			// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
			// document.getElementByName('acctId').value").toString();
			// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
			System.out.println("Clicked on Checkout button");

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr1[] = tesdDecode.split("&");
			String testEncodedPaReq = arr1[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);
			generic.explicitWait(2);
		}

		/* Verifying images are displayed or not */
		try {
			invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {
					// String imgSRCUrl = imgElement.getAttribute("src");
					// int status code =generic.verifyimageActive(imgElement);
					HttpClient client = HttpClientBuilder.create().build();
					// HttpHost proxyhost = new HttpHost(proxyUrl);
					HttpGet request = new HttpGet(imgElement.getAttribute("src"));
					// HttpResponse response = client.execute(proxyhost, request);
					HttpResponse response = client.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						invalidImageCount++;
						System.out.println("Image :" + imgElement.getAttribute("src") + " : Not displayed");

					} else
						System.out.println("image url: " + imgElement.getAttribute("src"));
					int respCode = response.getStatusLine().getStatusCode();
					String resposeCode = respCode + "";
					sAssertion.assertEquals(resposeCode, "200");
				}
				System.out.println("Total no. of invalid images are " + invalidImageCount);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

		System.out.println("ACS Txn Id is : " + acsTxnId);
		generic.explicitWait(2);

		otpValue = OTPFromDynamicConfig.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

		System.out.println("OtpDetails:-" + otpValue);
		// otp.getOtpTextField().sendKeys(otpValue);
		generic.explicitWait(1);

		// otp.getOtpSubmitButton().click();

		// Another approach
		/*
		 * otpDetail.getOtpResendButton().click(); generic.explicitWait(2);
		 * otpDetail.getOtpResendButton().click(); generic.explicitWait(2);
		 */

		otp.getOtpResendButton().click();
		generic.explicitWait(2);
		otp.getOtpResendButton().click();
		generic.explicitWait(2);

		// Validating on Admin portal

		String currentWin = driver.getWindowHandle();
		System.out.println("currentWin: " + currentWin);

		((JavascriptExecutor) driver).executeScript("window.open()");

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));

		/*
		 * Set<String> tab = driver.getWindowHandles(); for (String win : tab) { if
		 * (!win.equals(tab)) { driver.switchTo().window(win);
		 */

		LoginPage lp = new LoginPage(driver);
		driver.get(Config.BASE_UAM_URL);
		// driver.manage().window().maximize();
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		generic.explicitWait(3);

		// Navigating to Otp Usages
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();

		otpDetail.getOtpUsageReportSideLink().click();
		generic.explicitWait(2);
		otpDetail.getOtpUsageCardNumber().clear();
		otpDetail.getOtpUsageCardNumber().sendKeys(Cardnumber);
		otpDetail.getOtpUsageSearchButton().click();
		generic.explicitWait(5);

		// Validate fields
		sAssertion.assertEquals(otpDetail.getOtpUsageAcsTxnIdText().getText(), acsTxnId, "Verifing Acs Txn Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageEmailIdText().getText(), EmailId, "Verifing Email Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageMobileNumberText().getText(), MobileNumber,
				"Verifing MobileNumber");
		sAssertion.assertEquals(otpDetail.getOtpUsageMaximumOtpAllowedText().getText(), MaximumOtpAttempt,
				"Verifing MaximumOtpAttempt");
		sAssertion.assertEquals(otpDetail.getOtpUsageResendOtpCountText().getText(), ResendOTPCount,
				"Verifing ResendOTPCount");
		/*
		 * sAssertion.assertEquals(otpDetail.getOtpUsageInvalidOtpAttemptsText().getText
		 * (), InvalidOTPAttempts, "Verifying InvalidOTPAttempts");
		 */
		sAssertion.assertEquals(otpDetail.getOtpUsageLastOTPStatusText().getText(), LastOTPStatusResend,
				"Verifing LastOTPStatus");
		// sAssertion.assertAll();

		// otp.getOtpTextField().sendKeys("123456");
		generic.explicitWait(3);
		driver.switchTo().window(tabs.get(0));
		generic.explicitWait(4);

		// Invalid otp
		otp.getOtpTextField().clear();
		otp.getOtpTextField().sendKeys("123456");
		otp.getOtpSubmitButton().click();
		generic.explicitWait(2);
		otp.getOtpTextField().clear();
		otp.getOtpTextField().sendKeys("123456");
		otp.getOtpSubmitButton().click();

		generic.explicitWait(2);
		driver.switchTo().window(tabs.get(1));
		generic.explicitWait(2);

		otpDetail.getOtpUsageCardNumber().clear();
		otpDetail.getOtpUsageCardNumber().sendKeys(Cardnumber);
		otpDetail.getOtpUsageSearchButton().click();
		generic.explicitWait(5);

		// Validate fields
		sAssertion.assertEquals(otpDetail.getOtpUsageAcsTxnIdText().getText(), acsTxnId, "Verifing Acs Txn Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageEmailIdText().getText(), EmailId, "Verifing Email Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageMobileNumberText().getText(), MobileNumber,
				"Verifing MobileNumber");
		sAssertion.assertEquals(otpDetail.getOtpUsageMaximumOtpAllowedText().getText(), MaximumOtpAttempt,
				"Verifing MaximumOtpAttempt");
		/*
		 * sAssertion.assertEquals(otpDetail.getOtpUsageResendOtpCountText().getText(),
		 * ResendOTPCount, "Verifying ResendOTPCount");
		 */
		sAssertion.assertEquals(otpDetail.getOtpUsageInvalidOtpAttemptsText().getText(), InvalidOTPAttempts,
				"Verifing InvalidOTPAttempts");
		sAssertion.assertEquals(otpDetail.getOtpUsageLastOTPStatusText().getText(), LastOTPStatusInvalid,
				"Verifing LastOTPStatus");

		generic.explicitWait(2);
		driver.switchTo().window(tabs.get(0));
		// otpDetail.getOtpCancelButton().click();
		otp.getOtpCancelButton().click();

		if (IssuerBankId.equalsIgnoreCase("8551")) {
			Alert cancelAlert = driver.switchTo().alert();
			cancelAlert.accept();
		}

		sAssertion.assertAll();
	}

}

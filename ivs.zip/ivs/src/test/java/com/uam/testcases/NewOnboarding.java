package com.uam.testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.acs.bankonboarding.pages.NewOnBoardingHome;
import com.acs.bankonboarding.pages.OnBoardBank;
import com.acs.bankonboarding.pages.RBAPage;
import com.acs.bankonboarding.pages.Scheme;
import com.acs.bankonboarding.pages.ScreensPage;
import com.acs.bankonboarding.pages.DatasourceConfig;
import com.acs.bankonboarding.pages.EventSMS;
import com.acs.bankonboarding.pages.FlowV1Page;
import com.acs.bankonboarding.pages.FlowV2Page;
import com.acs.bankonboarding.pages.GenericConfig;
import com.acs.bankonboarding.pages.LanguageDefaultPage;
import com.acs.bankonboarding.pages.LanguageEnUsPage;
import com.acs.bankonboarding.pages.ManageBins;
import com.acs.bankonboarding.pages.OTPConfig;
import com.acs.bankonboarding.pages.EventEmail;
import com.acs.bankonboarding.pages.AlertSms;
import com.acs.bankonboarding.pages.CreateSchema;
import com.acs.bankonboarding.pages.Customer;
import com.acs.bankonboarding.pages.AlertEmail;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;

public class NewOnboarding extends ACSInitialSetUp {

	public void clickUsingJS(WebElement button) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", button);
		System.out.println("Clicked by JS");
	}

	public void moveToElement(WebElement e) {
		System.out.println("Moving to element");
		Actions action = new Actions(driver);
		action.moveToElement(e).perform();
	}

	String eText = "✓ Changes Saved successfully";
	String expectedOnBoardStatus = "Pending for Approval";
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount1 = 0;
	int invocationCount2 = 0;
	int countAuth = 0;
	int countNonAuth = 0;
	boolean check = false;
	public static String bankCode;

	@BeforeTest
	public void loginAdminPortal() {

		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Exiting from Before test");

	}

	@Test(priority = 1)
	public void NavigateToOnboardPage() {
		System.out.println("=============Navigating to Onboard Page===============");

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		// Selecting a bank
		adminhomepage.getDropDownHeaderIcon().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(Config.BASE_UAM_WIBMO_BANK_NAME);
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Navigating to onboarding Bank
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();

		// scrolling down to OnboardingBanksLink
		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("window.scrollBy(0,250)", "");
		 */
		adminhomepage.getOnboardingBanksLink().click();

		System.out.println("On the onBoarding Page");
	}

	@DataProvider
	public Object[][] OnboardBank() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "NewOnboardBank");
	}

	@Test(dataProvider = "OnboardBank", priority = 2)
	public void OnboardBank(String BankName, String TimeZone, String BankCode, String BankID, String Currency,
			String BankLogoURL, String EnableMakerChecker, String ClusterName, String CloneExistingBank,
			String AutomationType, String decs) throws Exception {
		System.out.println("========OnboardBank===========");
		ExtentTestManager.getTest().setDescription(decs);

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		OnBoardBank onbardBank = new OnBoardBank(driver);
		NewOnBoardingHome newOnBoardingHome = new NewOnBoardingHome(driver);
		// clicking on New Onboarding
		moveToElement(adminhomepage.getNewOnboardingButton());
		adminhomepage.getNewOnboardingButton().click();

		// Selecting Cluster
		generic.explicitWait(2);
		// GenericMethods.selectByVisibleText(newOnBoardingHome.getSelectClusterDropdown(),
		// ClusterName);
		generic.selectByVisibleText(newOnBoardingHome.getSelectClusterDropdown(), ClusterName);
		// Cloning Bank
		if (CloneExistingBank.equalsIgnoreCase("No")) {
			System.out.println("Freshly OnBoarding Bank");
		} else {
			System.out.println("Cloning Bank Name: " + CloneExistingBank);
			generic.selectByVisibleText(newOnBoardingHome.getCloningExistingBank(), CloneExistingBank);
			newOnBoardingHome.getFetchDataButton().click();
			generic.explicitWait(2);
			String alertMessage = driver.findElement(By.xpath("(//*[@role='alert'])[1]")).getText();
			System.out.println("alertMessage:-" + alertMessage);
			String expectedMessage = "Data fetched succesfully.";
			assertEquals(alertMessage, expectedMessage);
		}
		// Filling OnBoard Bank
		onbardBank.getBankNameTextField().sendKeys(BankName);

		generic.explicitWait(2);
		onbardBank.getTimeZoneDropdown().click();
		onbardBank.getTimeZoneSearchBox().sendKeys(TimeZone);
		onbardBank.getTimeZoneFirstRadioBtn();

		generic.explicitWait(2);
		onbardBank.getBankCodeTextField().sendKeys(BankCode);

		// Putting random bank id for temporary
		if (AutomationType.equals("Regression")) {
			System.out.println("Executing Regression");
			int randomPIN = (int) (Math.random() * 9000) + 1000;
			bankCode = "" + randomPIN;
			System.out.println("bankCode:-" + bankCode);
			onbardBank.getBankIdTextField().sendKeys(bankCode);
		} else {
			System.out.println("Executing Functional");
			onbardBank.getBankIdTextField().sendKeys(BankID);
		}

		generic.explicitWait(2);
		onbardBank.getCurrencyDropdown().click();
		onbardBank.getCurrencySearchbox().sendKeys(Currency);
		onbardBank.getCurrencyRadioButton();

		generic.explicitWait(2);

		onbardBank.getbankLogoUrlTextField().sendKeys(BankLogoURL);
		onbardBank.getEnabledMakerCheckerDrpdwn().click();
		onbardBank.getEnabledMakerCheckerYesRadioBtn().click();

		// Scrolling up

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");

		// moveToElement(onbardBank.getSaveBtn());
		onbardBank.getSaveBtn().click();
		System.out.println("Saving OnBoard Bank");
		generic.explicitWait(2);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Onboard Bank')]]//div//span[1]"))
				.getText();

		System.out.println("aText:-" + aText);
		// sAssertion.assertEquals(aText, eText);
		assertEquals(aText, eText);
		System.out.println("Verified Changes Saved successfully");

	}

	@DataProvider
	public Object[][] GenericConfig() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "GenericConfig");
	}

	@Test(dataProvider = "GenericConfig", priority = 3)
	public void GenericConfig(String BankCode, String HSM_URL, String HSM_DataEncKey_Alg, String HSM_DataEncKey_encMode,
			String HSM_DataEncKey_key, String HSM_DataEncKey_KeyAlias, String HSM_DataEncKey_keyType,
			String HSM_DataEncKey_providerType, String Legacy_HSM_URL, String Legacy_HSM_DataEncKey_Alg,
			String Legacy_HSM_DataEncKey_encMode, String Legacy_HSM_DataEncKey_key,
			String Legacy_HSM_DataEncKey_KeyAlias, String Legacy_HSM_DataEncKey_keyType,
			String Legacy_HSM_DataEncKey_providerType, String Cache, String Queue, String Alert_Service_Url,
			String customer_Service_Url, String otp_Service_Url, String expiry_Cache_Url, String cdn_Url,
			String acs_Url, String CustomerRemoteDataSyncUrl, String ThreedsMethodRemoteDataSyncUrl, String SecretKey,
			String decs) throws Exception {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("===========GenericConfig============");
		ExtentTestManager.getTest().setDescription(decs);

		NewOnBoardingHome newOnBoardingHome = new NewOnBoardingHome(driver);
		GenericConfig genericConfig = new GenericConfig(driver);
		generic.explicitWait(3);

		if (driver.findElements(By.xpath("//input[@id='root_bankCode']")).size() <= 0)

		{
			generic.explicitWait(3);
			newOnBoardingHome.getGenericConfigExpandIcon().click();
			driver.findElement(By.xpath("//div[contains(text(),'Generic Config ')]/a")).click();
			generic.explicitWait(3);
		}
		genericConfig.getbankCodeTextField().clear();
		genericConfig.getbankCodeTextField().sendKeys(BankCode);

		// HSM URL
		genericConfig.getHsmURLDropdown().click();
		genericConfig.getHsmURLSearchBox().sendKeys(HSM_URL);
		genericConfig.getHsmURLFirstRadioBtn().click();

		genericConfig.getHsmDataEncKeyAlgDropdown().click();
		if (HSM_DataEncKey_Alg == "HMACSHA256") {
			genericConfig.getHMACSHA256RadioBtn().click();

		} else {
			genericConfig.getACRadioBtn().click();
		}

		genericConfig.getHsmDataEncKeyEncModeDropdown().click();
		if (HSM_DataEncKey_encMode == "09") {
			genericConfig.getSelect09RadioBtn().click();
		} else {
			genericConfig.getSelect01RadioBtn().click();
		}

		genericConfig.getHsmDataEncKeyKeyDropdown().click();
		genericConfig.getRawValueRadioBtn().click();

		genericConfig.gethsmDataEncKeyKeyAliasTextField().sendKeys(HSM_DataEncKey_KeyAlias);
		genericConfig.getHsmDataEncKeykeyTypeDropdown().click();
		genericConfig.gethsmDataEncKeykeyAES256RadioBtn().click();

		genericConfig.getHsmDataEncKeyproviderTypeDropdown().click();
		genericConfig.gethsmDataEncKeyproviderTypeHK_ACRadiobtn().click();

		// Legacy HSM Section
		genericConfig.getLegacyHsmUrlDropdown().click();
		genericConfig.getLegacyHsmUrlSearchBox().sendKeys(Legacy_HSM_URL);
		genericConfig.getLegacyHsmUrlFirstRadioBtn().click();

		// Legacy HSM DataEncKey Alg
		genericConfig.getLegacyHSMDataEncKeyAlgDropdown().click();
		if (Legacy_HSM_DataEncKey_Alg == "HMACSHA256") {
			genericConfig.getLegacyHMACSHA256RadioBtn().click();
		} else {
			genericConfig.getLegacyACRadioBtn().click();
		}

		// HSM DataEncKey encMode
		genericConfig.getLegacyHSMDataEncKeyEncModeDropdown().click();
		if (Legacy_HSM_DataEncKey_encMode == "01") {
			genericConfig.getLegacy01RadioBtn().click();
		} else {
			genericConfig.getLegacy09RadioBtn().click();
		}

		// HSM DataEncKey key
		genericConfig.getLegacyHSMDataEncKeykeyDropdown().click();
		genericConfig.getLegacyRawValueRadioBtn().click();

		genericConfig.getlegacyHSMDataEncKeyKeyAliasTextBox().sendKeys(Legacy_HSM_DataEncKey_KeyAlias);

		// This step is skipping for now -HSM DataEncKey keyType
		generic.explicitWait(2);
		/*
		 * genericConfig.getLegacyHSMDataEncKeykeyTypeDropdown().click();
		 * genericConfig.getLegacyAES256RadioBtn().click();
		 */

		// LegacyHSM DataEncKey providerType
		genericConfig.getLegacyLegacyHSMDataEncKeyproviderTypeDropdown().click();
		genericConfig.getLegacyHK_ACRadioBtn().click();

		// Cache
		genericConfig.getLegacyCacheDropdown().click();
		genericConfig.getLegacyCacheSearchBox().sendKeys(Cache);
		genericConfig.getLegacyCacheFirstRadioBtn().click();

		// Queue
		genericConfig.getLegacyQueueDropdown().click();
		genericConfig.getLegacyQueueSearchBox().sendKeys(Queue);
		genericConfig.getLegacyQueueFirstRadioBtn().click();

		// Alert Service Url
		genericConfig.getLegacyAlertServiceUrlDropdown().click();
		genericConfig.getLegacyAlertServiceUrlSearchBox().sendKeys(Alert_Service_Url);
		genericConfig.getLegacyAlertServiceUrlFirstRadioBtn().click();

		// customer Service Url
		genericConfig.getLegacyCustomerServiceUrlDropdown().click();
		genericConfig.getLegacyCustomerServiceUrlSearchBox().sendKeys(customer_Service_Url);
		genericConfig.getLegacyCustomerServiceUrlFirstRadioBtn().click();

		// otp Service Url
		genericConfig.getLegacyotpServiceUrlDropdown().click();
		genericConfig.getLegacyOtpServiceUrlSearchBox().sendKeys(otp_Service_Url);
		genericConfig.getLegacyOtpServiceUrlFirstRadioBtn().click();

		// expiry Cache Url
		genericConfig.getLegacyExpiryCacheUrlDropdown().click();
		genericConfig.getLegacyExpiryCacheUrlSearchBox().sendKeys(expiry_Cache_Url);
		genericConfig.getLegacyExpiryCacheUrlFirstRadioBtn().click();

		// cdn Url
		genericConfig.getLegacyCdnUrlDropdown().click();
		genericConfig.getLegacyCdnUrlSearchBox().sendKeys(cdn_Url);
		genericConfig.getLegacyCdnUrlFirstRadioBtn().click();

		// acs Url
		genericConfig.getLegacyACSUrlDropdown().click();
		genericConfig.getLegacyACSUrlSearchBox().sendKeys(acs_Url);
		genericConfig.getLegacyACSUrlFirstRadioBtn().click();

		// Customer Remote Data Sync Url
		genericConfig.getCustomerRemoteDataSyncUrlDropdown().click();
		genericConfig.getCustomerRemoteDataSyncUrlSearchBox().sendKeys(CustomerRemoteDataSyncUrl);
		genericConfig.getCustomerRemoteDataSyncUrlDropdownFirstValue().click();

		// 3ds Method Remote Data Sync Url
		genericConfig.getThreedsMethodRemoteDataSyncUrlDropdown().click();
		genericConfig.getThreedsMethodRemoteDataSyncUrlSearchBox().sendKeys(ThreedsMethodRemoteDataSyncUrl);
		genericConfig.getThreedsMethodRemoteDataSyncUrlDropdownFirstValue().click();

		genericConfig.getSecretKeyTextField().sendKeys(SecretKey);

		// Clicking on Save button
		generic.explicitWait(2);
		/*
		 * Actions action=new Actions(driver); WebElement
		 * saveBtn=driver.findElement(By.xpath("(//a[text()='Save'])[1]"));
		 * action.moveToElement(saveBtn);
		 */
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		generic.explicitWait(3);
		// genericConfig.getSaveBtnGenericConfig().click();
		/*
		 * JavascriptExecutor js1 = (JavascriptExecutor) driver;
		 * js1.executeScript("arguments[0].click();",
		 * genericConfig.getSaveBtnGenericConfig());
		 */
		clickUsingJS(genericConfig.getSaveBtnGenericConfig());
		// generic.scrollThePageTillXpositionOfTheElement(genericConfig.getSaveBtnGenericConfig());
		System.out.println("Saving Generic Config module");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Generic Config ')]]//div//span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Verified Changes Saved successfully");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] DataSourceConfig() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "DataSourceConfig");
	}

	@Test(dataProvider = "DataSourceConfig", priority = 4)
	public void DataSourceConfig(String CustomerDb_Db, String CustomerDb_DataSource_Schema, String CustomerDb_Username,
			String CustomerDb_Password, String CustomerDb_MinimumIdle, String CustomerDb_MaximumPoolSize,
			String TransactionDb, String TransactionDb_DataSource_Schema, String TransactionDb_Username,
			String TransactionDb_Password, String TransactionDb_MinimumIdle, String TransactionDb_MaximumPoolSize,
			String ReportingTransactionDb, String ReportingTransactionDb_DataSource_Schema,
			String ReportingTransactionDb_Username, String ReportingTransactionDb_Password,
			String ReportingTransactionDb_MinimumIdle, String ReportingTransactionDb_MaximumPoolSize,
			String Do_You_Want_To_Add_Reporting_Xdc_Transaction_Db_Database_Configurations,
			String reportingXdcTransactionDb_db, String ReportingXdcTransactionDb_DataSource_Schema,
			String ReportingXdcTransactionDb_Username, String ReportingXdcTransactionDb_Password,
			String ReportingXdcTransactionDb_MinimumIdle, String ReportingXdcTransactionDb_MaximumPoolSize,
			String Do_You_Want_To_Add_1_Legacy_Database_Configurations, String legacyDb_db,
			String egacyDb_DataSource_Schema, String LegacyDb_Username, String LegacyDb_Password,
			String LegacyDb_MinimumIdle, String LegacyDb_MaximumPoolSize,
			String Do_You_Want_To_Add_1_Legacy_Reporting_Database_Configurations, String legacyReportingDb_db,
			String LegacyReportingDb_DataSource_Schema, String LegacyReportingDb_Username,
			String LegacyReportingDb_Password, String LegacyReportingDb_MinimumIdle,
			String LegacyReportingDb_MaximumPoolSize, String decs) {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("===========DataSourceConfig============");
		ExtentTestManager.getTest().setDescription(decs);

		DatasourceConfig datasourceConfig = new DatasourceConfig(driver);
		// generic.scrollThePageTillXpositionOfTheElement(datasourceConfig.getCustomerDbDropdown());
		moveToElement(datasourceConfig.getDataSourceConfigHeader());
		// generic.moveToElement(datasourceConfig.getDataSourceConfigHeader());
		generic.explicitWait(2);
		// CustomerDb
		System.out.println("Filling CustomerDb");
		datasourceConfig.getCustomerDbDropdown().click();
		datasourceConfig.getCustomerDbSearchBox().sendKeys(CustomerDb_Db);
		datasourceConfig.getCustomerDbFirstRadioBtn().click();

		datasourceConfig.getCustomerDbDataSourceSchemaTextField().sendKeys(CustomerDb_DataSource_Schema);
		datasourceConfig.getCustomerDbDataUserNameTextField().sendKeys(CustomerDb_Username);
		datasourceConfig.getCustomerDbDataPasswordTextField().sendKeys(CustomerDb_Password);
		datasourceConfig.getCustomerDbMinimumIdleTextField().sendKeys(CustomerDb_MinimumIdle);
		datasourceConfig.getCustomerDbMaximumPoolSizeTextField().sendKeys(CustomerDb_MaximumPoolSize);

		// Transaction DB
		System.out.println("Filling Transaction DB");
		datasourceConfig.getTransactionDbDropdown().click();
		datasourceConfig.getTransactionDbSearchBox().sendKeys(TransactionDb);
		datasourceConfig.getTransactionDbFirstRadioBtn().click();

		datasourceConfig.getTransactionDbDataSourceSchemaTextField().sendKeys(TransactionDb_DataSource_Schema);
		datasourceConfig.getTransactionDbDataUserNameTextField().sendKeys(TransactionDb_Username);
		datasourceConfig.getTransactionDbDataPasswordTextField().sendKeys(TransactionDb_Password);
		datasourceConfig.getTransactionDbMinimumIdleTextField().sendKeys(TransactionDb_MinimumIdle);
		datasourceConfig.getTransactionDbMaximumPoolSizeTextField().sendKeys(TransactionDb_MaximumPoolSize);

		// Reporting Transaction DB
		System.out.println("Filling Reporting Transaction DB");
		datasourceConfig.getReportingTransDbDropdown().click();
		datasourceConfig.getReportingTransDbSearchBox().sendKeys(ReportingTransactionDb);
		datasourceConfig.getReportingTransDbFirstRadioBtn().click();

		datasourceConfig.getReportinTransDbDataSourceSchemaTextField()
				.sendKeys(ReportingTransactionDb_DataSource_Schema);
		datasourceConfig.getReportingTransDbDataUserNameTextField().sendKeys(ReportingTransactionDb_Username);
		datasourceConfig.getReportingTransDbDataPasswordTextField().sendKeys(ReportingTransactionDb_Password);
		datasourceConfig.getReportingTransDbMinimumIdleTextField().sendKeys(ReportingTransactionDb_MinimumIdle);
		datasourceConfig.getReportingTransDbMaximumPoolSizeTextField().sendKeys(ReportingTransactionDb_MaximumPoolSize);

		// Do_You_Want_To_Add_Reporting_Xdc_Transaction_Db_Database_Configurations

		if (Do_You_Want_To_Add_Reporting_Xdc_Transaction_Db_Database_Configurations == "Yes") {
			generic.selectByVisibleText(datasourceConfig.getReportingXdcTransactionDropdown(), "Yes");

			datasourceConfig.getReportingXdcTransactionDbDropdown().click();
			datasourceConfig.getReportingXdcTransactionSearchBox().sendKeys(reportingXdcTransactionDb_db);
			datasourceConfig.getReportingXdcTransactionFirstRadioBtn().click();

			datasourceConfig.getReportingXdcTranSchemaDbTextfield()
					.sendKeys(ReportingXdcTransactionDb_DataSource_Schema);
			datasourceConfig.getReportingXdcTransacDbUserNameTextField().sendKeys(ReportingXdcTransactionDb_Username);
			datasourceConfig.getReportingXdcTransacDbPasswordTextField().sendKeys(ReportingXdcTransactionDb_Password);
			datasourceConfig.getReportingXdcTransacDbMinimumIdleTextField()
					.sendKeys(ReportingXdcTransactionDb_MinimumIdle);
			datasourceConfig.getReportingXdcTransacDbMaxPoolSizeTextField()
					.sendKeys(ReportingXdcTransactionDb_MaximumPoolSize);

		} else {
			System.out.println("Don't want to Add Reporting Xdc Transaction Db Database Configurations");
		}

		// Do_You_Want_To_Add_1_Legacy_Database_Configurations

		if (Do_You_Want_To_Add_1_Legacy_Database_Configurations == "Yes") {
			generic.selectByVisibleText(datasourceConfig.getLegacyDbConfigurationDropdown(), "Yes");

			datasourceConfig.getLegacyDBDropdown().click();
			datasourceConfig.getLegacyDBSearchBox().sendKeys(legacyDb_db);
			datasourceConfig.getLegacyDBFirstRadioBtn().click();

			datasourceConfig.getRoot_legacyDb_schemaTextField().sendKeys(egacyDb_DataSource_Schema);
			datasourceConfig.getLegacyDb_usernameTextField().sendKeys(LegacyDb_Username);
			datasourceConfig.getLegacyDb_passwordTextField().sendKeys(LegacyDb_Password);
			datasourceConfig.getLegacyDb_minimumIdleTextField().sendKeys(LegacyDb_MinimumIdle);
			datasourceConfig.getLegacyDb_maximumPoolSizeTextField().sendKeys(LegacyDb_MaximumPoolSize);
		} else {
			System.out.println("Don't want to  Add 1.0 Legacy Database Configurations");
		}

		// Do You Want To Add 1.0 Legacy Reporting Database Configurations

		if (Do_You_Want_To_Add_1_Legacy_Reporting_Database_Configurations == "Yes") {
			generic.selectByVisibleText(datasourceConfig.getLegacyReportingDbConfigDropdown(), "Yes");

			datasourceConfig.getLegacyReportingDbDropdown().click();
			datasourceConfig.getLegacyReportingDbSearchBox().sendKeys(legacyReportingDb_db);
			datasourceConfig.getLegacyReportingDbFirstRadioBtn().click();

			datasourceConfig.getLegacyReportingDb_schemaTextField().sendKeys(LegacyReportingDb_DataSource_Schema);
			datasourceConfig.getLegacyReportingDb_usernameTextField().sendKeys(LegacyReportingDb_Username);
			datasourceConfig.getLegacyReportingDb_passwordTextField().sendKeys(LegacyReportingDb_Password);
			datasourceConfig.getLegacyReportingDb_minimumIdleTextField().sendKeys(LegacyReportingDb_MinimumIdle);
			datasourceConfig.getLegacyReportingDb_maximumPoolSizeTextField()
					.sendKeys(LegacyReportingDb_MaximumPoolSize);
		} else {
			System.out.println("Don't want to  Add 1.0 Legacy Reporting Database Configurations");
		}

		// Saving Data Source Config
		// datasourceConfig.getSaveBtnDataSourceConfig().click();
		clickUsingJS(datasourceConfig.getSaveBtnDataSourceConfig());
		System.out.println("Saving Data Source Config");
		generic.explicitWait(3);
		String aText = driver.findElement(By.xpath(
				"//div[@class='page__content configs'][div[contains(text(),'Datasource Config ')]]//div//span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(5);

	}

	@DataProvider
	public Object[][] OTPConfig() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "OTPConfig");
	}

	@Test(dataProvider = "OTPConfig", priority = 5)
	public void OTPConfig(String Config_Class, String Config_value_otpMask, String otpCategory, String maxResendCount,
			String maxFailureCount, String maxSoftBlock, String Force_New, String ExpiryMin, String otpLength,
			String Generate_Otp_Flag, String callerId, String RetryValidationsupported, String decs) {

		System.out.println("===========OTPConfig============");
		ExtentTestManager.getTest().setDescription(decs);
		OTPConfig otpConfig = new OTPConfig(driver);

		// Adding OTP module
		if (driver.findElements(By.xpath("//input[@placeholder='otpMask']")).size() <= 0) {
			System.out.println("Adding OTP module");
			otpConfig.getOtpConfigAddBtn().click();
		}

		otpConfig.getConfigClassTextBox().sendKeys(Config_Class);

		// Select otpMask
		otpConfig.getOtpMaskDropdown().click();
		if (Config_value_otpMask == "Numeric") {
			otpConfig.getNumericDropdown().click();
		} else if (Config_value_otpMask == "Alpha") {
			otpConfig.getAlphaDropdown().click();
		} else if (Config_value_otpMask == "AlphaNumeric") {
			otpConfig.getAlphaNumericDropdown().click();
		}

		// Select otpCategory
		otpConfig.getOtpCategoryDropdown().click();
		if (otpCategory == "1") {
			otpConfig.getOtpCategory01Dropdown().click();
		} else if (otpCategory == "2") {
			otpConfig.getOtpCategory02Dropdown().click();
		}

		// Select maxResendCount
		otpConfig.getMaxResendCountDropdown().click();
		if (maxResendCount == "1") {
			otpConfig.getMaxResendCount01Dropdown().click();
		} else if (maxResendCount == "2") {
			otpConfig.getMaxResendCount02Dropdown().click();
		} else if (maxResendCount == "3") {
			otpConfig.getMaxResendCount03Dropdown().click();
		} else if (maxResendCount == "4") {
			otpConfig.getMaxResendCount04Dropdown().click();
		} else if (maxResendCount == "5") {
			otpConfig.getMaxResendCount05Dropdown().click();
		}
		// Select maxFailureCount
		otpConfig.getMaxFailureCountDropdown().click();

		if (maxResendCount == "1") {
			otpConfig.getMaxFailureCount01Dropdown().click();
		} else if (maxResendCount == "2") {
			otpConfig.getMaxFailureCount02Dropdown().click();
		} else if (maxResendCount == "3") {
			otpConfig.getMaxFailureCount03Dropdown().click();
		} else if (maxResendCount == "4") {
			otpConfig.getMaxFailureCount04Dropdown().click();
		} else if (maxResendCount == "5") {
			otpConfig.getMaxFailureCount05Dropdown().click();
		}

		// Select maxSoftBlock
		otpConfig.getMaxSoftBlockDropdown().click();
		if (maxResendCount == "1") {
			otpConfig.getMaxSoftBlock01Dropdown().click();
		} else if (maxResendCount == "2") {
			otpConfig.getMaxSoftBlock02Dropdown().click();
		} else if (maxResendCount == "3") {
			otpConfig.getMaxSoftBlock03Dropdown().click();
		} else if (maxResendCount == "4") {
			otpConfig.getMaxSoftBlock04Dropdown().click();
		} else if (maxResendCount == "5") {
			otpConfig.getMaxSoftBlock05Dropdown().click();
		}
		System.out.println("Select Force New");

		// Select Force New
		otpConfig.getForceNewDropdown().click();
		generic.explicitWait(3);
		if (Force_New == "true") {
			otpConfig.getForceNewTrueDropdown().click();
		} else if (Force_New == "false") {
			otpConfig.getForceNewFalseDropdown().click();
		}

		// Select ExpiryMin
		// otpConfig.getExpiryMinTextField().sendKeys(ExpiryMin);

		// Select otpLength
		otpConfig.getOtpLengthDropdown().click();
		if (otpLength == "4") {
			otpConfig.getOtpLength04Dropdown().click();
		} else if (otpLength == "6") {
			otpConfig.getOtpLength06Dropdown().click();
		} else if (otpLength == "8") {
			otpConfig.getOtpLength08Dropdown().click();
		}

		// Select Generate Otp Flag
		otpConfig.getGenerateOtpFlagDropdown().click();

		if (Generate_Otp_Flag == "true") {

			otpConfig.getGenerateOtpTrueDropdown().click();
		} else if (Generate_Otp_Flag == "false") {
			otpConfig.getGenerateOtpFalseDropdown().click();
		}

		// Select callerId
		otpConfig.getCallerIdDropdown().click();
		otpConfig.getCallerIdACS2Dropdown().click();

		// Retry Validation supported
		otpConfig.getRetryValidationsupportedDropdown().click();
		if (RetryValidationsupported.equalsIgnoreCase("True")) {
			otpConfig.getRetryValidationsupportedTrueRadioButton().click();
		} else if (RetryValidationsupported.equalsIgnoreCase("False")) {
			otpConfig.getRetryValidationsupportedFalseRadioButton().click();
		}

		// Saving OTP Config
		// otpConfig.getSaveBtnOtpConfig().click();
		clickUsingJS(otpConfig.getSaveBtnOtpConfig());
		System.out.println("Saving OTP config module");
		generic.explicitWait(2);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'OTP Config ')]]//div//span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] EventSmsConfig() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "EventSmsConfig");
	}

	@Test(dataProvider = "EventSmsConfig", priority = 6)
	public void EventSmsConfig(String Config_Class, String Do_You_Want_To_Enabled_EVENT_OTP_SEND,
			String EVENT_OTP_SEND_Text, String Do_You_Want_To_Enabled_EVENT_RBA_DECLINE, String EVENT_RBA_DECLINE_Text,
			String Do_You_Want_To_Enabled_EVENT_CARD_BLOCKED, String EVENT_CARD_BLOCKED_Text, String decs) {

		System.out.println("==========EventSmsConfig===========");
		ExtentTestManager.getTest().setDescription(decs);
		EventSMS eventSms = new EventSMS(driver);

		moveToElement(eventSms.getEventSMSHeader());
		generic.explicitWait(2);
		// Adding EventSmsConfig module
		if (driver.findElements(By.xpath("//legend[@id='root_eventTemplates__title']")).size() <= 0) {
			System.out.println("Adding EventSmsConfig module");
			eventSms.getEventSMSAddBtn().click();
		}

		eventSms.getConfigClassTextField().sendKeys(Config_Class);
		if (Do_You_Want_To_Enabled_EVENT_OTP_SEND == "Checked") {
			eventSms.getEventTemplateOtpSendChkBox().click();
			eventSms.getEventTemplateOtpSendTextField().sendKeys(EVENT_OTP_SEND_Text);
		}

		else if (Do_You_Want_To_Enabled_EVENT_RBA_DECLINE == "Checked") {
			eventSms.getEventTemplateRBADeclineChkBox().click();
			eventSms.getEventTemplateRBADeclineTextField().sendKeys(EVENT_RBA_DECLINE_Text);
		} else if (Do_You_Want_To_Enabled_EVENT_CARD_BLOCKED == "Checked") {
			eventSms.getEventTemplateCardBlockedChkBox().click();
			eventSms.getEventTemplatesCardBlockedTextField().sendKeys(EVENT_CARD_BLOCKED_Text);
		}

		clickUsingJS(eventSms.getEventSmsSaveBtn());
		System.out.println("Saving EventSmsConfig");
		generic.explicitWait(2);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Event SMS ')]]//div//span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);
	}

	@DataProvider
	public Object[][] EventEmail() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "EventEmail");
	}

	@Test(dataProvider = "EventEmail", priority = 7)
	public void EventEmail(String Config_Class, String Do_You_Want_To_Enabled_EVENT_OTP_SEND,
			String EVENT_OTP_SEND_Text, String EVENT_OTP_SEND_Subject, String Do_You_Want_To_Enabled_EVENT_RBA_DECLINE,
			String EVENT_RBA_DECLINE_Text, String EVENT_RBA_DECLINE_Subject,
			String Do_You_Want_To_Enabled_EVENT_CARD_BLOCKED, String EVENT_CARD_BLOCKED_Text,
			String EVENT_CARD_BLOCKED_Subject, String decs) {

		System.out.println("==========EventEmail===========");
		ExtentTestManager.getTest().setDescription(decs);
		EventEmail eventEmail = new EventEmail(driver);

		moveToElement(eventEmail.getEventEmailHeader());
		generic.explicitWait(2);
		// Adding EventEmail module
		if (driver.findElements(By.xpath("//input[@id='root_eventTemplates_EVENT_OTP_SEND_enabled']")).size() <= 0) {
			System.out.println("Adding EventSmsConfig module");
			eventEmail.getEventEmailAddBtn().click();
		}

		eventEmail.getEventEmailConfigClass().sendKeys(Config_Class);
		if (Do_You_Want_To_Enabled_EVENT_OTP_SEND == "Checked") {
			eventEmail.getEventEmailEventOTPSendChkBox().click();
			eventEmail.getEventOTPSendTextField().sendKeys(EVENT_OTP_SEND_Text);
			eventEmail.getEventOtpSendSubjectTextField().sendKeys(EVENT_OTP_SEND_Subject);
		} else if (Do_You_Want_To_Enabled_EVENT_RBA_DECLINE == "Checked") {
			eventEmail.getEventRbaDeclineCheckbox().click();
			eventEmail.getEventRbaDeclineTextTextField().sendKeys(EVENT_RBA_DECLINE_Text);
			eventEmail.getEventRbaDeclineSubjectTextTextField().sendKeys(EVENT_RBA_DECLINE_Subject);
		} else if (Do_You_Want_To_Enabled_EVENT_CARD_BLOCKED == "Checked") {
			eventEmail.getEventCardBlockedEnabledChkbox().click();
			eventEmail.getEventCardBlockedTextTextField().sendKeys(EVENT_CARD_BLOCKED_Text);
			eventEmail.getEventCardBlockedSubjectTextField().sendKeys(EVENT_CARD_BLOCKED_Subject);
		}

		clickUsingJS(eventEmail.getEventEmailSaveBtn());
		System.out.println("Saving EventEmail");
		generic.explicitWait(2);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Event Email ')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);
	}

	@DataProvider
	public Object[][] Customer() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "Customer");
	}

	@Test(dataProvider = "Customer", priority = 8)
	public void Customer(String Config_Class, String Customer_Fetch_Type, String cardStatusSource,
			String cacheCustomerData, String switchUrl, String Open_PGP, String decs) {

		System.out.println("==========Customer===========");
		ExtentTestManager.getTest().setDescription(decs);
		Customer customer = new Customer(driver);

		moveToElement(customer.getCustomerHeader());
		generic.explicitWait(2);
		// Adding EventEmail module
		if (driver.findElements(By.xpath("//div[@data-tip='Customer Fetch Type']")).size() <= 0) {
			System.out.println("Adding Customer module");
			generic.explicitWait(2);
			customer.getCustomerAddBtn().click();
		}

		System.out.println("LockDown1");
		customer.getCustomerConfigClass().sendKeys(Config_Class);
		customer.getCustomerFetchTypeDropdown().click();
		generic.explicitWait(3);
		// Customer fetch Type

		switch (Customer_Fetch_Type) {
		case "FILEUPLOAD":
			System.out.println("FILEUPLOAD");
			customer.getCustomerFetchModeFileUpload().click();
			generic.explicitWait(3);

			customer.getOpenPGPDropdown().click();
			customer.getCacheCustomerDataSearchBox().sendKeys(Open_PGP);
			customer.getCacheCustomerDataFirstOption().click();
			break;

		/*
		 * case "FILEUPLOAD2.0": System.out.println("FILEUPLOAD2.0");
		 * customer.getCustomerFetchFileUpload02Dropdown().click(); break;
		 */

		case "SWITCH":
			System.out.println("SWITCH ");
			customer.getCustomerFetchModeSwitch().click();
			generic.explicitWait(3);

			customer.getSwitchUrlDropdown().click();
			customer.getSwitchUrlSearchBox().sendKeys(switchUrl);
			customer.getSwitchUrlFirstOption().click();
			break;

		/*
		 * case "ENROLLMENT-SERVER": System.out.println("ENROLLMENT-SERVER ");
		 * customer.getCustomerFetchEnrollmentServerDropdown().click(); break;
		 */

		}
		/*
		 * if (Customer_Fetch_Type == "FILEUPLOAD1.0") {
		 * System.out.println("Checkpoint1");
		 * customer.getCustomerFetchFileUpload01Dropdown().click(); } else if
		 * (Customer_Fetch_Type == "FILEUPLOAD2.0") { System.out.println("Checkpoint2");
		 * customer.getCustomerFetchFileUpload02Dropdown().click(); } else if
		 * (Customer_Fetch_Type == "SWITCH") { System.out.println("Checkpoint3");
		 * customer.getCustomerFetchSwitchDropdown().click(); } else if
		 * (Customer_Fetch_Type == "ENROLLMENT-SERVER") {
		 * System.out.println("Checkpoint4");
		 * customer.getCustomerFetchEnrollmentServerDropdown().click(); }
		 */

		// customerFetchMode

		/*
		 * customer.getCustomerFetchModeDropdown().click(); generic.explicitWait(2);
		 * customer.getCustomerFetchModeFederalSwitchRadioBtn().click();
		 * 
		 * // customerFetchInterval customer.getCustomerFetchIntervalDropdown().click();
		 * generic.explicitWait(2);
		 * customer.getCustomerFetchIntervalAlwaysSwitchRadioBtn().click();
		 * generic.explicitWait(2);
		 */

		customer.getCardStatusSourceDropdown().click();
		if (cardStatusSource.equals("DB1.0")) {
			System.out.println("DB1.0");
			customer.getCardStatusSourcDB1().click();
		} else if (cardStatusSource.equals("DB2.0")) {
			System.out.println("DB2.0");
			customer.getCardStatusSourcDB2().click();
		}

		customer.getCacheCustomerDataDropdown().click();
		customer.getCacheCustomerDataSearchBox().sendKeys(cacheCustomerData);
		customer.getCacheCustomerDataFirstOption().click();

		clickUsingJS(customer.getCustomerSaveBtn());
		System.out.println("Saving Customer");
		generic.explicitWait(2);
		String aText = driver
				.findElement(By
						.xpath("//div[@class='page__content configs'][div[contains(text(),'Customer ')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
	}

	@DataProvider
	public Object[][] AlertSMS() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "AlertSMS");
	}

	@Test(dataProvider = "AlertSMS", priority = 9)
	public void AlertSMS(String Config_Class, String Alert_Sms, String decs) {

		System.out.println("==========AlertSMS===========");
		ExtentTestManager.getTest().setDescription(decs);
		AlertSms alertSms = new AlertSms(driver);

		moveToElement(alertSms.getAlertSmsHeader());
		generic.explicitWait(2);
		// Adding EventEmail module
		if (driver.findElements(By.xpath("//input[@placeholder='configClass']")).size() <= 0) {
			System.out.println("Adding AlertSMS module");
			alertSms.getAlertSmsAddBtn().click();
		}
		alertSms.getAlertSmsConfigClassTextField().sendKeys(Config_Class);
		alertSms.getAlertSmsDropdown().click();
		alertSms.getAlertSmsSearchBox().sendKeys(Alert_Sms);
		alertSms.getAlertSmsFirstRadioBtn().click();

		clickUsingJS(alertSms.getAlertSmsSaveBtn());
		System.out.println("Saving AlertSMS");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By
						.xpath("//div[@class='page__content configs'][div[contains(text(),'Alert SMS ')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
	}

	@DataProvider
	public Object[][] AlertEmail() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "AlertEmail");
	}

	@Test(dataProvider = "AlertEmail", priority = 10)
	public void AlertEmail(String Config_Class, String Alert_Email, String decs) {

		System.out.println("==========AlertEmail===========");
		ExtentTestManager.getTest().setDescription(decs);
		AlertEmail alertEmail = new AlertEmail(driver);
		moveToElement(alertEmail.getAlertEmailHeader());
		generic.explicitWait(2);
		// Adding EventEmail module
		if (driver.findElements(By.xpath("//input[@placeholder='configClass']")).size() <= 0) {
			System.out.println("Adding AlertEmail module");
			alertEmail.getAlertEmailAddBtn().click();
		}

		alertEmail.getAlertEmailConfigClassTextField().sendKeys(Config_Class);
		alertEmail.getAlertEmailDropdown().click();
		alertEmail.getAlertEmailSearchBox().sendKeys(Alert_Email);
		alertEmail.getAlertEmailFirstRadioBtn().click();

		clickUsingJS(alertEmail.getAlertEmailSaveBtn());
		System.out.println("Saving AlertEmail");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Alert Email')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);
	}

	@DataProvider
	public Object[][] SchemeMaster() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "SchemeMaster");
	}

	@Test(dataProvider = "SchemeMaster", priority = 11)
	public void SchemeMaster(String Enable_Master, String cardNetworkId, String cardNetworkName,
			String Master2Dot0Enabled, String Master1Dot0Enabled, String AcsOperatorID, String AcsReferenceNumber,
			String PsImageUrl, String acsRreqClient, String acsSigningCert, String cavvInfoDOTtype,
			String cavvInfoDOTdataFormat, String hmacKeyDOTkeyType, String hmacKeyDOTproviderType,
			String HmacKeyDOTKeyAlias, String hmacKeyDOTencMode, String hmacKeyDOTalgorithm,
			String cavvInfoDOTkeyADOTkeyType, String cavvInfoDOTkeyADOTproviderType, String CavvInfoDOTKeyADOTKeyAlias,
			String cavvInfoDOTkeyADOTencMode, String CavvInfoDOTKeyADOTKeyValue, String cavvInfoDOTkeyBDOTkeyType,
			String cavvInfoDOTkeyBDOTproviderType, String CavvInfoDOTKeyBDOTKeyAlias, String cavvInfoDOTkeyBDOTencMode,
			String CavvInfoDOTKeyBDOTKeyValue, String acsXmlSigningCert, String legacyCavvInfoDOTtype,
			String legacyCavvInfoDOTdataFormat, String legacyhmacKeyDOTkeyType, String legacyhmacKeyDOTproviderType,
			String legacyHmacKeyDOTKeyAlias, String legacyhmacKeyDOTencMode, String legacyhmacKeyDOTalgorithm,
			String legacyCavvInfo_keyA_keyType, String legacyCavvInfo_keyA_providerType,
			String LegacyCavvInfo_KeyA_KeyAlias, String legacyCavvInfo_keyA_encMode,
			String LegacyCavvInfo_KeyA_KeyValue, String legacyCavvInfo_keyB_keyType,
			String LegacyCavvInfo_keyB_providerType, String LegacyCavvInfo_KeyB_KeyAlias,
			String LegacyCavvInfo_keyB_encMode, String LegacyCavvInfo_KeyB_KeyValue, String decs) {

		System.out.println("==========SchemeMaster===========");
		ExtentTestManager.getTest().setDescription(decs);
		Scheme scheme = new Scheme(driver);

		scheme.getSchemeEnableMasterChkbox().click();
		scheme.getSchemeMasterAddButton().click();

		scheme.getMasterCardNetworkIdDropdown().click();
		scheme.getMasterCardNetworkIdRadioBtn().click();

		scheme.getMasterCardNetworkNameDropdown().click();
		scheme.getMasterCardNetworkNameRadioBtn().click();

		// 2.O Enabled?
		if (Master2Dot0Enabled.equalsIgnoreCase("Yes")) {
			generic.explicitWait(3);
			generic.selectByVisibleText(scheme.getMasterEnable2dotODropdown(), "Yes");
			scheme.getMasterAcsOperatorIDTextField().sendKeys(AcsOperatorID);
			scheme.getMasterAcsReferenceNumberTextField().sendKeys(AcsReferenceNumber);
			scheme.getMasterPsImageUrlTextField().sendKeys(PsImageUrl);
			// acsRreqClient
			scheme.getMasterAcsRreqClientDropdown().click();
			scheme.getMasterAcsRreqClientSearchBox().sendKeys(acsRreqClient);
			scheme.getMasterAcsRreqClientFirstRadioBtn().click();
			// acsSigningCert
			scheme.getMasterAcsSigningCertDropdown().click();
			scheme.getMasterAcsSigningCertSearchBox().sendKeys(acsSigningCert);
			scheme.getMasterAcsSigningCertFirstRadioBtn().click();
			// cavvInfo.dataFormat
			scheme.getCavvInfodataFormatTypeDropdown().click();
			scheme.getCavvInfodataFomatPAN_DSTxnID_AMOUNT_CURRadioBtn().click();
			// cavvInfo.type
			scheme.getMasterCavvInfoTypeDropdown().click();
			if (cavvInfoDOTtype.equals("SPA1_HMAC") || cavvInfoDOTtype.equals("SPA2")) {
				System.out.println("Test1");
				if (cavvInfoDOTtype.equals("SPA1_HMAC"))
					scheme.getCavvInfoTypeSPA1_HMACRadioBtn().click();
				else {
					scheme.getCavvInfoTypeSPA2RadioBtn().click();
				}
				// hmacKey.keyType
				scheme.getHmacKeykeyTypeDropDown().click();
				scheme.getHmacKeykeyTypeSDESRadioBtn().click();
				// hmacKey.providerType
				scheme.getHmacKeyProviderTypeDropDown().click();
				scheme.getHmacKeyProviderTypeHK_HCRadioBtn().click();
				// HmacKey.KeyAlias
				scheme.getHmacKey_KeyAliasTextField().sendKeys(HmacKeyDOTKeyAlias);
				// hmacKey.encMode
				scheme.getHmacKey_encModeDropdown().click();
				scheme.getHmacKey_encMode09RadioBtn().click();
				// hmacKey.algorithm
				scheme.getHmacKey_algorithmDropdown().click();
				scheme.getHmacKey_algorithm02RadioBtn().click();
			} else if (cavvInfoDOTtype.equals("SPA1_CVC2")) {
				scheme.getCavvInfoTypeSPA1_CVC2RadioBtn().click();
				// Key A cavvInfo.keyA.keyType
				scheme.getCavvInfo_keyA_keyTypeDropdown().click();
				scheme.getCavvInfo_keyA_keyType_SDES_RadioBtn().click();
				// cavvInfo.keyA.providerType
				scheme.getCavvInfo_keyA_providerTypeDropdown().click();
				scheme.getCavvInfo_keyA_providerType_HK_ACRadioBtn().click();
				// CavvInfo.KeyA.KeyAlias
				scheme.getCavvInfo_KeyA_KeyAliasTextField().sendKeys(CavvInfoDOTKeyADOTKeyAlias);
				// cavvInfo.keyA.encMode
				scheme.getCavvInfo_keyA_encModeTypeDropdown().click();
				scheme.getCavvInfo_keyA_encModeType_09RadioBtn().click();
				// CavvInfo.KeyA.KeyValue
				scheme.getCavvInfo_KeyA_KeyValueTextField().sendKeys(CavvInfoDOTKeyADOTKeyValue);

				// Key B cavvInfo.keyB.keyType
				scheme.getCavvInfo_keyB_keyTypeDropdown().click();
				scheme.getCavvInfo_keyB_keyType_SDES_RadioBtn().click();
				// cavvInfo.keyB.providerType
				scheme.getCavvInfo_keyB_providerTypeDropdown().click();
				scheme.getCavvInfo_keyB_providerType_HK_ACRadioBtn().click();
				// CavvInfo.KeyB.KeyAlias
				scheme.getCavvInfo_KeyB_KeyAliasTextField().sendKeys(CavvInfoDOTKeyBDOTKeyAlias);
				// cavvInfo.keyB.encMode
				scheme.getCavvInfo_keyB_encModeTypeDropdown().click();
				scheme.getCavvInfo_keyB_encModeType_09RadioBtn().click();
				// CavvInfo.KeyB.KeyValue
				scheme.getCavvInfo_KeyB_KeyValueTextField().sendKeys(CavvInfoDOTKeyBDOTKeyValue);
			}
		}

		// 1.O Enabled?
		if (Master1Dot0Enabled.equals("Yes")) {
			generic.selectByVisibleText(scheme.getEnable1dotODropdown(), "Yes");

			// acsXmlSigningCert
			scheme.getLegacyAcsXmlSigningCertDropdown().click();
			scheme.getAcsXmlSigningCertSearchBox().sendKeys(acsXmlSigningCert);
			scheme.getAcsXmlSigningCertFirstRadioBtn().click();
			// legacyCavvInfo.dataFormat
			scheme.getLegacyCavvInfoDataFormatDropdown().click();
			scheme.getPAN_DSTxnID_AMOUNT_CURRadioBtn().click();
			// legacyCavvInfo.type
			scheme.getLegacyCavvInfoDropdown().click();

			if (legacyCavvInfoDOTtype.equals("SPA1_HMAC")) {
				scheme.getLegacyCavvInfoSPA1_HMACRadioBtn().click();
				// hmacKey.keyType
				scheme.getLegacyHmacKeyKeyTypeDropdown().click();
				generic.explicitWait(2);
				scheme.getLegacySDESRadioBtn().click();

				// hmacKey.providerType
				scheme.getLegacyHmacKeyProviderTypeDropdown().click();
				scheme.getLegacyHKHCRadiobtn().click();
				// Legacy HmacKey.KeyAlias
				scheme.getLegacyHmacKeyKeyAliasTextField().sendKeys(legacyHmacKeyDOTKeyAlias);
				// hmacKey.encMode
				scheme.getLegacyhmacKeyencModeDropdown().click();
				scheme.getLegacyhmacKeyencMode09RadioBtn().click();
				// hmacKey.algorithm
				scheme.getlegacyHmacKeyAlgorithmDropdown().click();
				scheme.getLegacyHmacKeyAlgorithm02RadioBtn().click();
			} else if (legacyCavvInfoDOTtype.equals("SPA1_CVC")) {
				scheme.getLegacyCavvInfoSPA1_CVCRadioBtn().click();
				// Key A legacyCavvInfo.keyA.keyType
				scheme.getLegacyCavvInfKeyAkeyTypeDropdown().click();
				scheme.getLegacyCavvInfKeyAkeySDESRadioBtn().click();

				// legacyCavvInfo.keyA.providerType
				scheme.getLegacyCavvInfokeyAproviderTypeDropdown().click();
				scheme.getLegacyCavvInfokeyAproviderTypeHK_ACRadioBtn().click();
				// LegacyCavvInfo.KeyA.KeyAlias
				scheme.getLegacyCavvInfoKeyAKeyAliasTextField().sendKeys(LegacyCavvInfo_KeyA_KeyAlias);
				// legacyCavvInfo.keyA.encMode
				scheme.getLegacyCavvInfokeyAencModeDropdown().click();
				scheme.getLegacyCavvInfokeyAencMode09RadioBtn().click();
				// LegacyCavvInfo.KeyA.KeyValue
				scheme.getLegacyCavvInfoKeyAKeyValueTextField().sendKeys(LegacyCavvInfo_KeyA_KeyAlias);
				// Key B legacyCavvInfo.keyB.keyType
				scheme.getLegacyCavvInfokeyBkeyTypeDropdown().click();
				scheme.getLegacyCavvInfokeyBkeyTypeSDESRadioBtn().click();
				// legacyCavvInfo.keyB.providerType
				scheme.getLegacyCavvInfokeyBproviderTypeDropdown().click();
				scheme.getLegacyCavvInfokeyBproviderTypeHK_ACRadioBtn().click();
				// LegacyCavvInfo.KeyB.KeyAlias
				scheme.getLegacyCavvInfoKeyBKeyAliasTextField().sendKeys(LegacyCavvInfo_KeyB_KeyAlias);
				// legacyCavvInfo.keyB.encMode
				scheme.getLegacyCavvInfokeyBencModeDropdown().click();
				scheme.getLegacyCavvInfokeyBencMode09RadioBtn().click();
				// LegacyCavvInfo.KeyB.KeyValue
				scheme.getLegacyCavvInfoKeyBKeyValueTextField().click();
			}
		}
		// Saving Scheme Master
		clickUsingJS(scheme.getMasterSchemeSaveBtn());
		System.out.println("Saving Master Scheme");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Scheme Master')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);
	}

	@DataProvider
	public Object[][] SchemeVisa() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "SchemeVisa");
	}

	@Test(dataProvider = "SchemeVisa", priority = 12)
	public void SchemeVisa(String Enable_Visa, String cardNetworkId, String cardNetworkName, String Enabled2Dot0,
			String Enabled1Dot0, String AcsOperatorID, String AcsReferenceNumber, String PsImageUrl,
			String cavvInfo_type, String cavvInfo_dataFormat, String cavvInfo_keyA_keyType,
			String cavvInfo_keyA_providerType, String CavvInfo_KeyA_KeyAlias, String cavvInfo_keyA_encMode,
			String CavvInfo_KeyA_KeyValue, String cavvInfo_keyB_keyType, String cavvInfo_keyB_providerType,
			String CavvInfo_KeyB_KeyAlias, String cavvInfo_keyB_encMode, String CavvInfo_KeyB_KeyValue,
			String acsRreqClient, String acsSigningCert, String legacyCavvInfo_type, String legacyCavvInfo_dataFormat,
			String legacyCavvInfo_keyA_keyType, String legacyCavvInfo_keyA_providerType,
			String LegacyCavvInfo_KeyA_KeyAlias, String legacyCavvInfo_keyA_encMode,
			String LegacyCavvInfo_KeyA_KeyValue, String legacyCavvInfo_keyB_keyType,
			String legacyCavvInfo_keyB_providerType, String LegacyCavvInfo_KeyB_KeyAlias,
			String legacyCavvInfo_keyB_encMode, String LegacyCavvInfo_KeyB_KeyValue, String acsXmlSigningCert,
			String decs) {

		System.out.println("==========SchemeVisa===========");
		ExtentTestManager.getTest().setDescription(decs);
		Scheme scheme = new Scheme(driver);
		AlertSms alertSms = new AlertSms(driver);

		// Scrolling up
		moveToElement(alertSms.getAlertSmsHeader());
		generic.explicitWait(3);

		scheme.getSchemeEnableViasChkbox().click();
		scheme.getSchemeVisaAddButton().click();

		// cardNetworkId
		scheme.getVisaCardNetworkIdDropdown().click();
		scheme.getVisaCardNetworkIdVisaRadioBtn().click();

		// cardNetworkName
		scheme.getVisaCardNetworkNameDropdown().click();
		scheme.getVisaCardNetworkNameVisaRadioBtn().click();

		// 2.O Enabled?
		if (Enabled2Dot0.equals("Yes")) {
			generic.selectByVisibleText(scheme.getVisaCard2dot0EnableDropdown(), "Yes");
			scheme.getVisaAcsOperatorIDTextField().sendKeys(AcsOperatorID);
			scheme.getVisaAcsReferenceNumberTextField().sendKeys(AcsReferenceNumber);
			scheme.getVisaPsImageUrlTextField().sendKeys(PsImageUrl);
			// cavvInfo.dataFormat
			scheme.getVisaCavvInfoDataFormatDropdown().click();
			scheme.getVisaPanDstxnidAmountCurRadioBtn().click();
			// cavvInfo.type
			scheme.getVisaCavvInfoTypeDropdown().click();
			scheme.getVisaCavvRadioBtn().click();
			// Key A cavvInfo.keyA.keyType
			scheme.getVisaCavvInfoKeyAKeyTypeDropdown().click();
			scheme.getVisaSDESRadioBtn().click();
			// cavvInfo.keyA.providerType
			scheme.getVisaCavvInfoKeyAProviderTypeDropdown().click();
			scheme.getVisaHK_ACRadioBtn().click();
			// CavvInfo.KeyA.KeyAlias
			scheme.getVisaCavvInfoKeyAKeyAliasTextField().sendKeys(CavvInfo_KeyA_KeyAlias);
			// cavvInfo.keyA.encMode
			scheme.getVisaCavvInfoKeyAEncModeDropdown().click();
			scheme.getVisa09RadioBtn().click();
			// CavvInfo.KeyA.KeyValue
			scheme.getVisaCavvInfoKeyAKeyValueTextField().sendKeys(CavvInfo_KeyA_KeyValue);

			// KeyB cavvInfo.keyB.keyType
			scheme.getVisaCavvInfoKeyBKeyTypeDropdown().click();
			scheme.getVisaSDESKeyBRadioBtn().click();
			// cavvInfo.keyB.providerType
			scheme.getVisaCavvInfoKeyBProviderTypeDropdown().click();
			scheme.getVisaHK_ACKeyBRadioBtn().click();
			// CavvInfo.KeyB.KeyAlias
			scheme.getVisaCavvInfoKeyBKeyAliasTextField().sendKeys(CavvInfo_KeyB_KeyAlias);
			// cavvInfo.keyB.encMode
			scheme.getVisaCavvInfoKeyBEncModeDropdown().click();
			scheme.getVisa09KeyBRadioBtn().click();
			// CavvInfo.KeyB.KeyValue
			scheme.getVisaCavvInfoKeyBKeyValueTextField().sendKeys(CavvInfo_KeyB_KeyValue);
			// acsRreqClient
			scheme.getVisaAcsRreqClientDropdown().click();
			scheme.getVisaAcsRreqClientSearchBox().sendKeys(acsRreqClient);
			scheme.getVisaAcsRreqClientFirstRadioBtn().click();
			// acsSigningCert
			scheme.getVisaAcsSigningCertDropdown().click();
			scheme.getVisaAcsSigningCertSearchBox().sendKeys(acsSigningCert);
			scheme.getVisaAcsSigningCertFirstRadioBtn().click();
		}

		if (Enabled1Dot0.equals("Yes")) {
			generic.selectByVisibleText(scheme.getVisaCard1dot0EnableDropdown(), "Yes");
			// legacyCavvInfo.type
			scheme.getVisaLegacyCavvInfoTypeDropdown().click();
			scheme.getVisaLegacyCavvRadioBtn().click();
			// legacyCavvInfo.dataFormat
			scheme.getVisaLegacyCavvInfoDataFormatTypeDropdown().click();
			scheme.getVisaLegacyPanDstxnidAmountCurRadioBtn().click();

			// Key A legacyCavvInfo.keyA.keyType
			scheme.getVisalegacyCavvInfokeyAkeyTypeDropdown().click();
			scheme.getVisaLegacySDESRadioBtn().click();
			// legacyCavvInfo.keyA.providerType
			scheme.getVisaLegacyCavvInfokeyAProviderTypeDropdown().click();
			scheme.getVisaLegacyHK_ACRadioBtn().click();
			// LegacyCavvInfo.KeyA.KeyAlias
			scheme.getVisaLegacyCavvInfoKeyAKeyAliasTextField().sendKeys(CavvInfo_KeyA_KeyAlias);
			// legacyCavvInfo.keyA.encMode
			scheme.getVisalegacyCavvInfokeyAEncModeDropdown().click();
			scheme.getVisaLegacy09RadioBtn().click();
			// LegacyCavvInfo.KeyA.KeyValue
			scheme.getVisaRoot_legacyCavvInfo_keyA_keyValueTextField().sendKeys(CavvInfo_KeyA_KeyValue);

			// Key B legacyCavvInfo.keyB.keyType
			scheme.getVisalegacyCavvInfokeyBkeyTypeDropdown().click();
			scheme.getVisaLegacySDESKeyBRadioBtn().click();
			// legacyCavvInfo.keyB.providerType
			scheme.getVisaLegacyCavvInfokeyBProviderTypeDropdown().click();
			scheme.getVisaLegacyHK_ACKeyBRadioBtn().click();
			// LegacyCavvInfo.KeyB.KeyAlias
			scheme.getVisaLegacyCavvInfoKeyBKeyAliasTextField().sendKeys(CavvInfo_KeyB_KeyAlias);
			// legacyCavvInfo.keyB.encMode
			scheme.getVisalegacyCavvInfokeyBEncModeDropdown().click();
			scheme.getVisaLegacy09KeyBRadioBtn().click();
			//// LegacyCavvInfo.KeyB.KeyValue
			scheme.getVisaroot_legacyCavvInfo_keyB_keyValueTextField().sendKeys(CavvInfo_KeyB_KeyValue);
			// acsXmlSigningCert
			scheme.getViasAcsXmlSigningCertDropdown().click();
			scheme.getViasAcsXmlSigningCertSearchBox().sendKeys(acsXmlSigningCert);
			scheme.getViasAcsXmlSigningCertFirstRadioBtn().click();
		}
		System.out.println("Before saving");
		// Saving Scheme Visa
		clickUsingJS(scheme.getVisaSchemeSaveBtn());
		System.out.println("Saving Visa Scheme");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By.xpath(
						"//div[@class='page__content configs'][div[contains(text(),'Scheme Visa')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] RBA() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "RBA");
	}

	@Test(dataProvider = "RBA", priority = 13)
	public void RBA(String Config_Class, String RBA, String decs) {
		System.out.println("=========RBA==========");
		ExtentTestManager.getTest().setDescription(decs);
		RBAPage rba = new RBAPage(driver);
		moveToElement(rba.getRbaHeader());
		generic.explicitWait(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");
		generic.explicitWait(2);
		// Adding RBA module

		if (driver.findElements(By.xpath(
				"//div[@class='page__content configs'][div[contains(text(),'RBA')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]"))
				.size() <= 0) {
			rba.getRbaExpandPlusButton().click();

			if (driver.findElements(By.xpath("//input[@placeholder='configClass']")).size() <= 0) {
				System.out.println("Adding RBA module");
				generic.explicitWait(3);
				rba.getRBAAddConfigClassPlusButton().click();
			}
		}
		rba.getRBAConfigClassTextField().sendKeys(Config_Class);
		rba.getRBASelectDropDownField().click();
		rba.getRbaSearchBox().sendKeys(RBA);
		rba.getRbaFirstRadioBtn().click();

		clickUsingJS(rba.getRBASaveButton());
		System.out.println("Saving RBA");
		generic.explicitWait(3);
		String aText = driver
				.findElement(By.xpath("//div[@class='page__content configs'][div[contains(text(),'RBA')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] LanguageDefault() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "LanguageDefault");
	}

	@Test(dataProvider = "LanguageDefault", priority = 14, enabled = true)
	public void LanguageDefaultPaymentAuth(String PaymentAuth_Key, String PaymentAuth_Value, String NonPaymentAuth_Key,
			String NonPaymentAuth_Value, String decs) {
		System.out.println("=========LanguageDefault_PaymentAuth==========");
		ExtentTestManager.getTest().setDescription(decs);
		LanguageDefaultPage languageDefault = new LanguageDefaultPage(driver);

		/*
		 * if (check == false) {
		 * moveToElement(languageDefault.getLanguageDefaultHeader());
		 * languageDefault.getLanguageDefaultExpandPlusButton().click(); check = true; }
		 */

		moveToElement(languageDefault.getLanguageDefaultAddPaymentAuthPlusButton());
		if (!NonPaymentAuth_Key.equalsIgnoreCase("") || !PaymentAuth_Key.equals("Save")) {
			languageDefault.getLanguageDefaultAddPaymentAuthPlusButton().click();
			driver.findElement(By.xpath("//input[@id='root_paymentAuth_" + invocationCount1 + "_key']"))
					.sendKeys(PaymentAuth_Key);
			driver.findElement(By.xpath("//input[@id='root_paymentAuth_" + invocationCount1 + "_value']"))
					.sendKeys(PaymentAuth_Value);
			countAuth++;
			System.out.println("countAuth:- " + countAuth);
		}
		invocationCount1++;
		System.out.println("invocationCount1: " + invocationCount1);
	}

	@Test(dataProvider = "LanguageDefault", priority = 15, enabled = true)
	public void LanguageDefaultNonPaymentAuth(String PaymentAuth_Key, String PaymentAuth_Value,
			String NonPaymentAuth_Key, String NonPaymentAuth_Value, String decs) {
		System.out.println("=========LanguageDefault_NonPaymentAuth==========");
		ExtentTestManager.getTest().setDescription(decs);
		LanguageDefaultPage languageDefault = new LanguageDefaultPage(driver);

		moveToElement(languageDefault.getLanguageDefaultAddNonPaymentAuthPlusButton());
		if (!NonPaymentAuth_Key.equalsIgnoreCase("")) {
			languageDefault.getLanguageDefaultAddNonPaymentAuthPlusButton().click();
			driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" + invocationCount2 + "_key']"))
					.sendKeys(NonPaymentAuth_Key);
			driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" + invocationCount2 + "_value']"))
					.sendKeys(NonPaymentAuth_Value);
			countNonAuth++;
			System.out.println("countNonAuth:- " + countNonAuth);
		}
		invocationCount2++;
		System.out.println("invocationCount2:-" + invocationCount2);

		if (PaymentAuth_Key.equals("Save")) {
			// Saving LanguageDefault
			moveToElement(languageDefault.getLanguageDefaultSaveButton());
			generic.explicitWait(2);
			clickUsingJS(languageDefault.getLanguageDefaultSaveButton());
			System.out.println("Saving LanguageDefault");
			generic.explicitWait(2);
			String aText = driver.findElement(By.xpath(
					"//div[@class='page__content configs'][div[contains(text(),'Language Default ')]]/div/span[1]"))
					.getText();
			assertEquals(aText, eText);
			System.out.println("Successfully message verified");
			// initializing invocationCount to zero
			invocationCount1 = 0;
			invocationCount2 = 0;
			generic.explicitWait(3);
		}
	}

	/*
	 * if (!NonPaymentAuth_Key.equalsIgnoreCase("")) { count2++;
	 * System.out.println("NonPaymentAuth_Key_Count:- " + count2); //
	 * moveToElement(languageDefault.getLanguageDefaultAddNonPaymentAuthPlusButton()
	 * ); // generic.explicitWait(2);
	 * languageDefault.getLanguageDefaultAddNonPaymentAuthPlusButton().click();
	 * driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" +
	 * invocationCount + "_key']")) .sendKeys(NonPaymentAuth_Key);
	 * driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" +
	 * invocationCount + "_value']")) .sendKeys(NonPaymentAuth_Value); }
	 */
	@DataProvider
	public Object[][] Language_en_US() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "Language_en_US");
	}

	@Test(dataProvider = "Language_en_US", priority = 16, enabled = true)
	public void Language_en_US_PaymentAuth(String PaymentAuth_Key, String PaymentAuth_Value, String NonPaymentAuth_Key,
			String NonPaymentAuth_Value, String decs) {
		System.out.println("=========Language_en_US_PaymentAuth==========");
		ExtentTestManager.getTest().setDescription(decs);
		LanguageEnUsPage languageEnPage = new LanguageEnUsPage(driver);

		/*
		 * if (check == false) { moveToElement(languageEnPage.getLanguageEnUsHeader());
		 * languageEnPage.getLanguageEnUsExpandPlusButton().click(); check = true; }
		 */
		if (!PaymentAuth_Key.equals("")) {
			if (!PaymentAuth_Key.equals("Save")) {
				System.out.println("Checkpoint1");
				languageEnPage.getLanguageEnUsAddPaymentAuthPlusButton().click();
				driver.findElement(By.xpath("//input[@id='root_paymentAuth_" + invocationCount1 + "_key']"))
						.sendKeys(PaymentAuth_Key);
				driver.findElement(By.xpath("//input[@id='root_paymentAuth_" + invocationCount1 + "_value']"))
						.sendKeys(PaymentAuth_Value);
			}
		}
		invocationCount1++;

	}

	@Test(dataProvider = "Language_en_US", priority = 17, enabled = true)
	public void Language_en_US_NonPaymentAuth(String PaymentAuth_Key, String PaymentAuth_Value,
			String NonPaymentAuth_Key, String NonPaymentAuth_Value, String decs) {
		System.out.println("=========Language_en_US_NonPaymentAuth==========");
		ExtentTestManager.getTest().setDescription(decs);
		LanguageEnUsPage languageEnPage = new LanguageEnUsPage(driver);

		if (!NonPaymentAuth_Key.equalsIgnoreCase("")) {
			System.out.println("Checkpoint2");
			languageEnPage.getLanguageEnUsAddNonPaymentAuthPlusButton().click();
			driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" + invocationCount2 + "_key']"))
					.sendKeys(NonPaymentAuth_Key);
			driver.findElement(By.xpath("//input[@id='root_nonPaymentAuth_" + invocationCount2 + "_value']"))
					.sendKeys(NonPaymentAuth_Value);
		}
		invocationCount2++;

		if (PaymentAuth_Key.equals("Save")) {
			// Saving LanguageDefault
			moveToElement(languageEnPage.getLanguageEnUsSaveButton());
			generic.explicitWait(2);
			clickUsingJS(languageEnPage.getLanguageEnUsSaveButton());
			System.out.println("Saving Language_en_US");
			generic.explicitWait(2);
			String aText = driver.findElement(By.xpath(
					"//div[@class='page__content configs'][div[contains(text(),'Language en-US ')]]/div/span[1]"))
					.getText();
			assertEquals(aText, eText);
			System.out.println("Successfully message verified");
			// initializing invocationCount to zero
			invocationCount1 = 0;
			invocationCount2 = 0;
			generic.explicitWait(3);
		}
	}

	@DataProvider
	public Object[][] FlowV1() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "FlowV1");
	}

	@Test(dataProvider = "FlowV1", priority = 18)
	public void FlowV1(String Config_Class, String Flow_V1, String decs) {
		System.out.println("=========FlowV1==========");
		ExtentTestManager.getTest().setDescription(decs);
		FlowV1Page flowV1Page = new FlowV1Page(driver);
		moveToElement(flowV1Page.getFlowV1Header());
		generic.explicitWait(2);

		if (driver.findElements(By.xpath(
				"//div[@class='page__content configs'][div[contains(text(),'Flow V1')]]//div//button[contains(@class,'btn btn-info btn-add col-xs-12')]"))
				.size() <= 0) {
			System.out.println("Clicking on expand button");
			flowV1Page.getFlowV1ExpandPlusButton().click();

		}

		if (driver.findElements(By.xpath("//input[@placeholder='configClass']")).size() <= 0) {
			System.out.println("Adding FlowV1 module");
			flowV1Page.getFlowV1AddConfigClassPlusButton().click();
		}

		flowV1Page.getFlowV1ConfigClassTextField().sendKeys(Config_Class);
		flowV1Page.getFlowV1TextArea().sendKeys(Flow_V1);

		clickUsingJS(flowV1Page.getFlowV1SaveButton());
		System.out.println("Saving flow V1");
		generic.explicitWait(3);
		String aText = driver
				.findElement(
						By.xpath("//div[@class='page__content configs'][div[contains(text(),'Flow V1 ')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message verified");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] FlowV2() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "FlowV2");
	}

	@Test(dataProvider = "FlowV2", priority = 19)
	public void FlowV2(String Config_Class, String Flow_V2, String decs) {
		System.out.println("=========Flow_V2==========");
		ExtentTestManager.getTest().setDescription(decs);
		FlowV2Page flowv2Page = new FlowV2Page(driver);
		moveToElement(flowv2Page.getFlowV2Header());
		generic.explicitWait(2);

		if (driver.findElements(By.xpath("//input[@placeholder='configClass']")).size() <= 0) {
			System.out.println("Adding FlowV1 module");
			flowv2Page.getFlowV2AddConfigClassPlusButton().click();
		}

		flowv2Page.getFlowV2ConfigClassTextField().sendKeys(Config_Class);
		flowv2Page.getFlowV2TextArea().sendKeys(Flow_V2);

		clickUsingJS(flowv2Page.getFlowV2SaveButton());
		System.out.println("Saving flow V2");
		generic.explicitWait(3);
		String aText = driver
				.findElement(
						By.xpath("//div[@class='page__content configs'][div[contains(text(),'Flow V2 ')]]/div/span[1]"))
				.getText();
		assertEquals(aText, eText);
		System.out.println("Successfully message for FlowV2 verified");
		generic.explicitWait(3);

	}

	@DataProvider
	public Object[][] AuthV1() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "AuthV1");
	}

	@Test(dataProvider = "AuthV1", priority = 20)
	public void AuthV1(String ScreenType1, String AuthV1_SelectTemplate, String AuthV1_MessageLanguage,
			String AuthV1_CSSPath, String AuthV1_LeftLogoPath, String AuthV1_RightLogoPath, String decs) {
		System.out.println("=========Screen1-AuthV1==========");
		ExtentTestManager.getTest().setDescription(decs);
		ScreensPage screenPage1 = new ScreensPage(driver);
		generic.explicitWait(3);
		// moveToElement(screenPage1.getScreensHeader());

		if (driver.findElements(By.xpath("//select[@id='authenticationDivV1_slct']")).size() <= 0) {
			System.out.println("Clicking on Screen expand button");
			screenPage1.getScreensExpandPlusBtn().click();
		}

		if (ScreenType1.equalsIgnoreCase("Yes")) {
			screenPage1.getAuthenticationV1Button().click();
			generic.selectByVisibleText(screenPage1.getAuthV1SelectTemplateDropdown(), AuthV1_SelectTemplate);
			screenPage1.getAuthV1MessageLanguageDropdown().click();
			if (AuthV1_MessageLanguage.equalsIgnoreCase("EN-English")) {
				screenPage1.getAuthV1MessageLanguageEnEnglishDropdownlist().click();
			} else if (AuthV1_MessageLanguage.equalsIgnoreCase("DEFAULT")) {
				screenPage1.getAuthV1MessageLanguageDefaultDropdownlist().click();
			}
			screenPage1.getAuthV1CssPathTextField().clear();
			screenPage1.getAuthV1CssPathTextField().sendKeys(AuthV1_CSSPath);
			screenPage1.getAuthV1LeftLogoPathTextField().clear();
			screenPage1.getAuthV1LeftLogoPathTextField().sendKeys(AuthV1_LeftLogoPath);
			screenPage1.getAuthV1RightLogoPathTextField().clear();
			screenPage1.getAuthV1RightLogoPathTextField().sendKeys(AuthV1_RightLogoPath);

			// Saving AuthV1
			moveToElement(screenPage1.getScreensHeader());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-250)", "");
			generic.explicitWait(2);
			clickUsingJS(screenPage1.getScreensSaveButton());
			System.out.println("Saving AuthV1");
			String abc = screenPage1.getAuthenticationV1Button().getCssValue("color");
			System.out.println("CssValue:- " + abc);
			System.out.println("Testing2:-" + screenPage1.getAuthenticationV1Button().getCssValue("background-color"));

		} else {
			System.out.println("Screen 1 is not required");
		}

	}

	@DataProvider
	public Object[][] CustV1() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "CustV1");
	}

	@Test(dataProvider = "CustV1", priority = 21)
	public void CustV1(String ScreenType2, String CustV1_SelectTemplate, String CustV1_MessageLanguage,
			String CustV1_CSSPath, String CustV1_LeftLogoPath, String CustV1_RightLogoPath, String decs) {
		System.out.println("=========Screeb2-CustV1==========");
		ExtentTestManager.getTest().setDescription(decs);
		ScreensPage screenPage2 = new ScreensPage(driver);
		generic.explicitWait(3);
		// moveToElement(screenPage1.getScreensHeader());

		if (driver.findElements(By.xpath("//select[@id='authenticationDivV1_slct']")).size() <= 0) {
			System.out.println("Clicking on Screen expand button");
			screenPage2.getScreensExpandPlusBtn().click();
		}

		if (ScreenType2.equalsIgnoreCase("Yes")) {
			// Customer information V1
			System.out.println("Filling Customer Info V1 ");
			moveToElement(screenPage2.getScreensHeader());
			generic.explicitWait(2);
			screenPage2.getCustInfoV1Button().click();
			generic.explicitWait(2);
			generic.selectByVisibleText(screenPage2.getCustInfoV1SelectTemplateDropdown(), CustV1_SelectTemplate);
			screenPage2.getCustInfoV1MessageLanguageDropdown().click();
			if (CustV1_MessageLanguage.equalsIgnoreCase("EN-English")) {
				screenPage2.getCustInfoV1MessageLanguageEnEnglishDropdownlist().click();
			} else if (CustV1_MessageLanguage.equalsIgnoreCase("DEFAULT")) {
				screenPage2.getCustInfoV1MessageLanguageDefaultDropdownlist().click();
			}
			screenPage2.getCustInfoV1CssPathTextField().clear();
			screenPage2.getCustInfoV1CssPathTextField().sendKeys(CustV1_CSSPath);
			screenPage2.getCustInfoV1LeftLogoPathTextField().clear();
			screenPage2.getCustInfoV1LeftLogoPathTextField().sendKeys(CustV1_LeftLogoPath);
			screenPage2.getCustInfoV1RightLogoPathTextField().clear();
			screenPage2.getCustInfoV1RightLogoPathTextField().sendKeys(CustV1_RightLogoPath);
			System.out.println(" All completed");
			moveToElement(screenPage2.getScreensHeader());

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-250)", "");
			generic.explicitWait(2);

			// Saving CustV1
			clickUsingJS(screenPage2.getScreensSaveButton());
			System.out.println("Saving Screen1");
			generic.explicitWait(3);
			String aText = driver
					.findElement(By.xpath(
							"//div[@class='page__content configs'][div[contains(text(),'Screens')]]/div/span[1]"))
					.getText();
			assertEquals(aText, eText);
			System.out.println("Successfully message for Screen2 verified");
			generic.explicitWait(3);
		} else {
			System.out.println("Screen2-CustV1 is not required");
		}

	}

	@DataProvider
	public Object[][] AuthV2() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "AuthV2");
	}

	@Test(dataProvider = "AuthV2", priority = 22, enabled = true)
	public void AuthV2(String ScreenType3, String AuthV2_SelectTemplate, String AuthV2_MessageLanguage,
			String AuthV2_CSSPath, String AuthV2_LeftLogoPath, String AuthV2_RightLogoPath, String decs) {
		System.out.println("=========Screens3-AuthV2==========");
		ExtentTestManager.getTest().setDescription(decs);
		ScreensPage screenPage3 = new ScreensPage(driver);
		generic.explicitWait(2);

		if (ScreenType3.equalsIgnoreCase("Yes")) {
			screenPage3.getAuthenticationV2Button().click();
			generic.selectByVisibleText(screenPage3.getAuthV2SelectTemplateDropdown(), AuthV2_SelectTemplate);
			screenPage3.getAuthV2MessageLanguageDropdown().click();
			if (AuthV2_MessageLanguage.equalsIgnoreCase("EN-English")) {
				screenPage3.getAuthV2MessageLanguageEnEnglishDropdownlist().click();
			} else if (AuthV2_MessageLanguage.equalsIgnoreCase("DEFAULT")) {
				screenPage3.getAuthV2MessageLanguageDefaultDropdownlist().click();
			}
			screenPage3.getAuthV2CssPathTextField().clear();
			screenPage3.getAuthV2CssPathTextField().sendKeys(AuthV2_CSSPath);
			screenPage3.getAuthV2LeftLogoPathTextField().clear();
			screenPage3.getAuthV2LeftLogoPathTextField().sendKeys(AuthV2_LeftLogoPath);
			screenPage3.getAuthV2RightLogoPathTextField().clear();
			screenPage3.getAuthV2RightLogoPathTextField().sendKeys(AuthV2_RightLogoPath);

			// Saving AuthV2
			moveToElement(screenPage3.getScreensHeader());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-250)", "");
			generic.explicitWait(2);
			clickUsingJS(screenPage3.getScreensSaveButton());
			System.out.println("Saving AuthV2");

		} else {
			System.out.println("Screens3-AuthV2 is not required");
		}
	}

	@DataProvider
	public Object[][] CustV2() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "CustV2");
	}

	@Test(dataProvider = "CustV2", priority = 23, enabled = true)
	public void CustV2(String ScreenType4, String CustV2_SelectTemplate, String CustV2_MessageLanguage,
			String CustV2_CSSPath, String CustV2_LeftLogoPath, String CustV2_RightLogoPath, String decs) {
		System.out.println("=========Screens4-CustV2==========");
		ExtentTestManager.getTest().setDescription(decs);
		ScreensPage screenPage4 = new ScreensPage(driver);
		generic.explicitWait(2);

		if (ScreenType4.equalsIgnoreCase("Yes")) {
			// Customer information V2
			System.out.println("Filling Customer Info V2 ");
			moveToElement(screenPage4.getScreensHeader());
			generic.explicitWait(2);
			screenPage4.getCustInfoV2Button().click();
			generic.selectByVisibleText(screenPage4.getCustInfoV2SelectTemplateDropdown(), CustV2_SelectTemplate);
			screenPage4.getCustInfoV2MessageLanguageDropdown().click();
			if (CustV2_MessageLanguage.equalsIgnoreCase("EN-English")) {
				screenPage4.getCustInfoV2MessageLanguageEnEnglishDropdownlist().click();
			} else if (CustV2_MessageLanguage.equalsIgnoreCase("DEFAULT")) {
				screenPage4.getCustInfoV2MessageLanguageDefaultDropdownlist().click();
			}
			screenPage4.getCustInfoV2CssPathTextField().clear();
			screenPage4.getCustInfoV2CssPathTextField().sendKeys(CustV2_CSSPath);
			screenPage4.getCustInfoV2LeftLogoPathTextField().clear();
			screenPage4.getCustInfoV2LeftLogoPathTextField().sendKeys(CustV2_LeftLogoPath);
			screenPage4.getCustInfoV2RightLogoPathTextField().clear();
			screenPage4.getCustInfoV2RightLogoPathTextField().sendKeys(CustV2_RightLogoPath);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-250)", "");
			generic.explicitWait(2);

			// Saving CustV2
			clickUsingJS(screenPage4.getScreensSaveButton());
			System.out.println("Saving Screen1");
			generic.explicitWait(3);
			String aText = driver
					.findElement(By.xpath(
							"//div[@class='page__content configs'][div[contains(text(),'Screens')]]/div/span[1]"))
					.getText();
			assertEquals(aText, eText);
			System.out.println("Successfully message for Screen1 verified");
			generic.explicitWait(3);

		} else {
			System.out.println("Screens4-CustV2 is not reqired");
		}
	}

	@Test(priority = 24)
	public void ReviewAndSubmit() {
		System.out.println("=========ReviewAndSubmit==========");

		NewOnBoardingHome newOnBoardingHomePage = new NewOnBoardingHome(driver);
		generic.explicitWait(2);
		moveToElement(newOnBoardingHomePage.getReviewSubmitButton());
		generic.explicitWait(2);
		clickUsingJS(newOnBoardingHomePage.getReviewSubmitButton());
		System.out.println("Review and Submitting");
		generic.explicitWait(2);
		clickUsingJS(newOnBoardingHomePage.getSubmitButton());
		generic.explicitWait(2);

		// Verifying status

		String actualOnBoardStatus = driver
				.findElement(
						By.xpath("//div[text()='" + bankCode + "']/following::div[@data-tip='Pending for Approval']"))
				.getText();
		assertEquals(actualOnBoardStatus, expectedOnBoardStatus);
		System.out.println("'Pending for Approval' message is verified");
		generic.explicitWait(3);
	}

	@DataProvider
	public Object[][] CreateSchema() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "CreateSchema");
	}

	@Test(dataProvider = "CreateSchema", priority = 24)
	public void CreateSchema(String HostName, String Port, String UserName, String Password, String DataCenter,
			String DatabaseType, String decs) {
		System.out.println("=============CreateSchema==============");
		CreateSchema createScheme = new CreateSchema(driver);
		ExtentTestManager.getTest().setDescription(decs);

		// clicking Create schema
		driver.findElement(By.xpath("//div[@class='flex-table__row columns odd'][div[text()='" + NewOnboarding.bankCode
				+ "']]/div[@class='flex-table__cell column']//div//div//a[text()='Create Schema']")).click();

		// Create Scheme page
		createScheme.getHostNameTextField().sendKeys(HostName);
		createScheme.getPortTextField().sendKeys(Port);
		createScheme.getUserNameTextField().sendKeys(UserName);
		createScheme.getPasswordTextField().sendKeys(Password);

		createScheme.getDataCenterDropdown().click();
		createScheme.getDatabaseTypeSearchBox().sendKeys(DataCenter);
		createScheme.getDatabaseTypeFirstRadioBtn().click();

		createScheme.getDatabaseTypeDropdown().click();
		createScheme.getDatabaseTypeSearchBox().sendKeys(DatabaseType);
		createScheme.getDatabaseTypeFirstRadioBtn().click();

		createScheme.getCreateSchemeButton().click();
		generic.explicitWait(3);
		String SuccessMessage = driver
				.findElement(
						By.xpath("//div[@class='Toastify__toast-container Toastify__toast-container--top-center']"))
				.getText();
		System.out.println("SuccessMessage:-" + SuccessMessage);
		boolean aText = SuccessMessage.contains("Successfully Created");
		boolean eText = true;
		assertEquals(aText, eText);
		generic.explicitWait(5);
		driver.navigate().back();
	}

	@DataProvider
	public Object[][] ManageBins() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "ManageBins");
	}

	@Test(dataProvider = "ManageBins", priority = 25)
	public void ManageBins(String BinDescription, String IssuerBin, String BinStart, String BinEnd,
			String CardAssociationType, String CardType, String CardClassificationId, String Status, String Generic,
			String DataSource, String OTPEngine, String EventSms, String EventEmail, String Customer, String AlertSms,
			String AlertEmail, String Scheme, String RbaConfig, String Rba, String UILanguage, String FlowV1,
			String FlowV2, String SCREEN_CUST_INFO_V1, String SCREEN_CUST_INFO_V2, String SCREEN_SELECT_V1,
			String SCREEN_SELECT_V2, String SCREEN_AUTH_V1, String SCREEN_AUTH_V2, String SCREEN_REGISTER_V1,
			String SCREEN_REGISTER_V2, String SCREEN_SET_PASS_V1, String SCREEN_SET_PASS_V2, String decs) {
		System.out.println("=============ManageBins==============");
		ManageBins manageBins = new ManageBins(driver);
		ExtentTestManager.getTest().setDescription(decs);

		// clicking Manage Bins
		driver.findElement(By.xpath("//div[@class='flex-table__row columns odd'][div[text()='" + NewOnboarding.bankCode
				+ "']]/div[@class='flex-table__cell column']//div//div//a[text()='Manage Bins']")).click();

		// clicking on Add Bin to test
		generic.explicitWait(2);
		manageBins.getPlusAddBinButton().click();
		generic.explicitWait(2);
		manageBins.getBinDescriptionTextField().sendKeys(BinDescription);
		manageBins.getIssuerBinTextField().sendKeys(IssuerBin);
		manageBins.getBinStartTextField().sendKeys(BinStart);
		manageBins.getBinEndTextField().sendKeys(BinEnd);

		// select Card Association Type
		manageBins.getCardAssociationTypeDropdown().click();
		if (CardAssociationType.equals("Master")) {
			manageBins.getCardAssociationMasterRadiBtn().click();

		} else if (CardAssociationType.equals("Master")) {
			manageBins.getCardAssociationVisaRadiBtn().click();
		}

		// select Card Type
		manageBins.getCardTypeDropdown().click();
		if (CardType.equals("Credit")) {
			manageBins.getCardTypeCreditRadioBtn().click();
		} else if (CardType.equals("Debit")) {
			manageBins.getCardTypeDebitRadioBtn().click();
		}
		// Card Classification Id
		manageBins.getCardClassificationIdTextField().sendKeys(CardClassificationId);
		manageBins.getStatusDropdown().click();
		manageBins.getStatusActiveRadioBtn();

		// Status
		manageBins.getStatusDropdown().click();
		if (driver.findElements(By.xpath("//input[@placeholder='Search']")).size() <= 0) {
			System.out.println("Clicking again");
			driver.findElement(By.xpath(
					"//div[contains(@class,'dropdown__title')][contains(text(),'Status')]/following::div[1]/div/a"))
					.click();

		}
		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("arguments[0].click();", manageBins.getStatusDropdown());
		 */
		generic.explicitWait(2);
		manageBins.getStatusSearchBox().sendKeys(Status);
		manageBins.getStatusFirstRadioBtn().click();

		generic.explicitWait(3);
		// Configuration
		manageBins.getGenericDropdown().click();
		manageBins.getGenericCommonRadioBtn().click();
		generic.explicitWait(2);
		manageBins.getDataSourceDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getOtpEngineDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getEventSmsDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getEventEmailDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getCustomerDropdown().click();
		manageBins.getCustomerSwitch().click();

		manageBins.getAlertSmsDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getAlertEmailDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		// select schema
		manageBins.getSchemeDropdown().click();
		if (Scheme.equals("MASTER")) {
			manageBins.getSchemeMasterRadiBtn().click();
		} else if (Scheme.equals("VISA")) {
			manageBins.getSchemeVisaRadiBtn().click();
		}

		// Rba Config
		manageBins.getRbaConfigDropdown().click();
		manageBins.getRbaConfigTestRuleRadiBtn().click();

		// select rba
		manageBins.getRbaDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getUiLanguageDropdown().click();
		manageBins.getDefaultRadioBtn().click();

		manageBins.getFlowV1Dropdown().click();
		manageBins.getDefaultRadioBtn().click();
		manageBins.getFlowV2Dropdown().click();
		manageBins.getDefaultRadioBtn().click();

		// Select Screens :
		if (SCREEN_CUST_INFO_V1.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_CUST_INFO_V1Dropdown().click();
			manageBins.getSCREEN_CUST_INFO_V1DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_CUST_INFO_V1");
		}

		if (SCREEN_CUST_INFO_V2.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_CUST_INFO_V2Dropdown().click();
			manageBins.getSCREEN_CUST_INFO_V2DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_CUST_INFO_V2");
		}

		if (SCREEN_SELECT_V1.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_SELECT_V1Dropdown().click();
			manageBins.getSCREEN_SELECT_V1DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_SELECT_V1");
		}

		if (SCREEN_SELECT_V2.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_SELECT_V2Dropdown().click();
			manageBins.getSCREEN_SELECT_V2DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_SELECT_V2");
		}

		if (SCREEN_AUTH_V1.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_AUTH_V1Dropdown().click();
			manageBins.getSCREEN_AUTH_V1DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_AUTH_V1");
		}

		if (SCREEN_AUTH_V2.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_AUTH_V2Dropdown().click();
			manageBins.getSCREEN_AUTH_V2DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_AUTH_V2");
		}

		if (SCREEN_REGISTER_V1.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_REGISTER_V1Dropdown().click();
			manageBins.getSCREEN_REGISTER_V1DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_REGISTER_V1");
		}

		if (SCREEN_REGISTER_V2.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_REGISTER_V2Dropdown().click();
			manageBins.getSCREEN_REGISTER_V2DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_REGISTER_V2");
		}

		if (SCREEN_SET_PASS_V1.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_SET_PASS_V1Dropdown().click();
			manageBins.getSCREEN_SET_PASS_V1DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_SET_PASS_V1");
		}

		if (SCREEN_SET_PASS_V2.equalsIgnoreCase("DEFAULT")) {
			manageBins.getSCREEN_SET_PASS_V2Dropdown().click();
			manageBins.getSCREEN_SET_PASS_V2DropdownDefaultList().click();
		} else {
			System.out.println("No SCREEN_SET_PASS_V2");
		}

		// Adding Bin
		/*
		 * Actions action = new Actions(driver);
		 * action.moveToElement(manageBins.getAddBinButton()).perform();
		 */
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", manageBins.getAddBinButton());
		generic.explicitWait(2);
		js.executeScript("window.scrollBy(0,-250)", "");
		generic.explicitWait(2);
		manageBins.getAddBinButton().click();
	}

	@AfterTest
	public void LogoutAdminPortal() {

		NewOnBoardingHome newonboardingHomePage = new NewOnBoardingHome(driver);
		newonboardingHomePage.getLogoutAdminPortalDropdown().click();
		newonboardingHomePage.getLogoutAdminPortalDropdown().click();
		System.out.println("Logout Successfully");
	}
}

package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.ACSClusterConfigurationPage;
import com.uam.pages.AdminHomePage;

public class ACSClusterConfiguration extends ACSInitialSetUp {

	int invocationCount = 1;
	public static String RandomclusterID;

	public void moveToElement(WebElement e) {
		Actions action = new Actions(driver);
		action.moveToElement(e).perform();
	}

	@BeforeMethod
	public void beforeVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateCluster");
	}

	@Test(dataProvider = "DataSet", priority = 0)
	public void createClusterConfig(String groupname, String clustername, String hostlive, String hostcanary,
			String datacenter, String resourcetype, String certificate, String configjson, String status,
			String AutomationType) {
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ACSClusterConfigurationPage cluster = new ACSClusterConfigurationPage(driver);
		
		ExtentTestManager.getTest().setDescription("Creating the Cluster");
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;

		System.out.println("row num" + invocationCount);

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the ACS from left side bar and then select Manage cluster
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		cluster.getAcsManageCCDTextLink().click();
		generic.explicitWait(2);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)");

		// click on create cluster configuration link
		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		/* Create cluster configuration */

		// Selecting Group name from dropdown values
		cluster.getAcsCCDGroupSelectField().click();
		generic.explicitWait(2);
		cluster.getAcseCCDGroupSelectSearchField().sendKeys(groupname);
		cluster.getAcsCCDGroupRadioButton().click();

		// Generate random number for the cluster name
		if (AutomationType.equals("Regression")) {
			/* random number generation for cluster */
			int randomPIN = (int) (Math.random() * 9000) + 1000;
			String RandomNum = "" + randomPIN;
			RandomclusterID = "Cluster" + RandomNum;
			System.out.println("cluster is " + RandomclusterID);
			cluster.getAcsCCDNameField().sendKeys(RandomclusterID);
			generic.writingToExcel(XlFileName, "CreateCluster", "Cluster", invocationCount, RandomclusterID);
		} else {
			System.out.println("Executing Functional");
			cluster.getAcsCCDNameField().sendKeys(clustername);
		}

		// enter Host live
		cluster.getAcsCCDHostLiveField().sendKeys(hostlive);

		// enter Host Canary
		cluster.getAcsCCDHostCanaryField().sendKeys(hostcanary);

		// Selecting Data Center from dropdown
		cluster.getAcsCCDDataCenterSelectField().click();
		generic.explicitWait(2);
		cluster.getAcsCCDDataCenterSearchField().sendKeys(datacenter);
		cluster.getAcsCCDDataCenterRadioButton().click();

		// Selecting ResourceType from dropdown
		cluster.getAcsCCDResourceTypeSelectField().click();
		generic.explicitWait(2);
		cluster.getAcsCCDResourceTypeSearchField().sendKeys(resourcetype);
		cluster.getAcsCCDResourceRadioButton().click();

		// Enter certificate and config JSON text values
		cluster.getAcsCertificateTextField().sendKeys(certificate);
		cluster.getAcsConfigJSONTextField().sendKeys(configjson);

		// JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");

		cluster.getAcsCCDStatusSelectField().click();
		if (status.equalsIgnoreCase("Yes")) {
			cluster.getAcsCCDStatusYes().click();
		} else {
			cluster.getAcsCCDStatusNo().click();
		}

		// Click on create cluster
		js.executeScript("window.scrollBy(0,-500)");
		cluster.getAcsCreateCCDButton().click();
		System.out.println("clicked create clutsr");
		generic.explicitWait(2);

		// Search field with clustername
		cluster.getListperPageDropdown().click();
		cluster.getList30PerPageRadioButton().click();

		if (AutomationType.equals("Regression")) {
			System.out.println("searching randome cluster generated");
			cluster.getSearchByClusterName().sendKeys(RandomclusterID);
		} else {
			System.out.println("Functional: searching cluster");
			cluster.getSearchByClusterName().sendKeys(clustername);
		}
		generic.explicitWait(2);

		System.out.println("Pagination starts");

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("((//div[text()='" + RandomclusterID
					+ "'])[1]/following::div[@class='flex-table__cell column sm']/div/a[1])[1]")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		// Assertion cases
		sAssertion.assertEquals(cluster.getListedGroupname().getText(), groupname, "Group name is not matching");
		sAssertion.assertEquals(cluster.getListedclustername().getText(), RandomclusterID,
				"Cluster name is not matching");
		sAssertion.assertEquals(cluster.getListedResourcetype().getText(), resourcetype,
				"Resource type is not matching");
		sAssertion.assertEquals(cluster.getListedDatacenter().getText(), datacenter, "DataCenter ID is not matching");
		sAssertion.assertEquals(cluster.getListedHostlive().getText(), hostlive, "Host live is not matching");
		sAssertion.assertEquals(cluster.getListedHostcanary().getText(), hostcanary, "Host Canary is not matching");

		sAssertion.assertAll();

		cluster.getEditClusterButton().click();
		generic.explicitWait(2);
		js.executeScript("window.scrollBy(0,500)");

		if (cluster.getAcsCCDStatusSelectField().getText().equalsIgnoreCase(status)) {
			sAssertion.assertTrue(true, "Status not matching");
			sAssertion.assertAll();
			System.out.println("Status macthng to YES");
		} else {
			System.out.println("Status NOT matching ");
		}

		/*
		 * moveToElement(cluster.getListedStatus()); String tooltip =
		 * cluster.getListedStatus().getText();
		 * System.out.println("Stattus text is"+tooltip);
		 * 
		 * sAssertion.assertEquals(tooltip, status, "Status is not matching");
		 * sAssertion.assertAll();
		 */

	}

	@DataProvider
	public Object[][] EditDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateCluster");
	}

	@Test(dataProvider = "EditDataSet", priority = 1)
	public void editCluster(String groupname, String clustername, String hostlive, String hostcanary, String datacenter,
			String resourcetype, String certificate, String configjson, String status, String AutomationType) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ACSClusterConfigurationPage cluster = new ACSClusterConfigurationPage(driver);
		ExtentTestManager.getTest().setDescription("Editing the Created Clusters");
		SoftAssert sAssertion = new SoftAssert();
		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the ACS from left side bar and then select Manage cluster
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		cluster.getAcsManageCCDTextLink().click();
		generic.explicitWait(2);

		// Searching created users with paginations

		cluster.getListperPageDropdown().click();
		cluster.getList30PerPageRadioButton().click();

		cluster.getSearchByClusterName().sendKeys(clustername);

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("((//div[text()='" + clustername
					+ "'])[1]/following::div[@class='flex-table__cell column sm']/div/a[1])[1]")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}
		/*-----------------Editing the cluster created--------------*/
		if (cluster.getListedclustername().getText().equals(clustername)) {
			System.out.println("click Edit for the clusters created");

			cluster.getEditClusterButton().click();
			cluster.getAcsCCDHostLiveField().clear();
			cluster.getAcsCCDHostLiveField().sendKeys(hostcanary);

			cluster.getAcsCCDHostCanaryField().clear();
			cluster.getAcsCCDHostCanaryField().sendKeys(hostlive);

			cluster.getAcsCCDResourceTypeSelectField().click();
			cluster.getAcsCCDResourceTypeSearchField().sendKeys(resourcetype);
			cluster.getAcsCCDResourceRadioButton().click();

			cluster.getAcsCertificateTextField().clear();
			cluster.getAcsCertificateTextField().sendKeys(certificate + "edit");

			cluster.getAcsConfigJSONTextField().clear();
			cluster.getAcsConfigJSONTextField().sendKeys(configjson + "edit");

			cluster.getAcsCCDStatusSelectField().click();

			if (status.equalsIgnoreCase("Yes")) {
				cluster.getAcsCCDStatusNo().click();
			} else {
				cluster.getAcsCCDStatusYes().click();
			}

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-500)");

			cluster.getSaveChanges().click();
			generic.explicitWait(2);

			// Search field with clustername
			cluster.getListperPageDropdown().click();
			cluster.getList30PerPageRadioButton().click();

			cluster.getSearchByClusterName().sendKeys(clustername);

			generic.explicitWait(2);

			System.out.println("Pagination starts");

			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver
						.findElements(By.xpath("((//div[text()='" + clustername
								+ "'])[1]/following::div[@class='flex-table__cell column sm']/div/a[1])[1]"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			// Assertion

			sAssertion.assertEquals(cluster.getListedResourcetype().getText(), resourcetype,
					"Resource type is not matching");
			sAssertion.assertEquals(cluster.getListedDatacenter().getText(), datacenter,
					"DataCenter ID is not matching");
			sAssertion.assertEquals(cluster.getListedHostlive().getText(), hostcanary, "Host live is not matching");
			sAssertion.assertEquals(cluster.getListedHostcanary().getText(), hostlive, "Host Canary is not matching");
			sAssertion.assertAll();

			cluster.getEditClusterButton().click();
			generic.explicitWait(2);
			js.executeScript("window.scrollBy(0,500)");

			if (status.equalsIgnoreCase("Yes")) {
				sAssertion.assertNotEquals(cluster.getAcsCCDStatusSelectField().getText(), status,
						"Status Yes not matching with edited");
				sAssertion.assertAll();
			} else {
				sAssertion.assertNotEquals(cluster.getAcsCCDStatusSelectField().getText(), status,
						"Status NO not matching with edited");
				sAssertion.assertAll();
			}

		}

	}

	@Test(priority = 2)
	public void verificationClusterfield() {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ACSClusterConfigurationPage cluster = new ACSClusterConfigurationPage(driver);
		ExtentTestManager.getTest().setDescription("Verifying the Fiedl Validation");
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;

		System.out.println("row num" + invocationCount);

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the ACS from left side bar and then select Manage cluster
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		cluster.getAcsManageCCDTextLink().click();
		generic.explicitWait(2);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)");

		// click on create cluster configuration link
		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		String expectedClusterName = "Cluster Name is a required property";
		String expectedDataCenterId = "Data CenterId is a required property";
		String expectedHostlive = "Host Live is a required property";
		String expectedHostCanary = "Host Canary is a required property";
		String expectedGroupname = "Group Name is a required property";

		/*------------------ Click on create cluster without entering values for the fields--------------- */

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedClusterName, cluster.getClusterMessage().getText() + " is a required property",
				"Cluster name field message not matching");
		sAssertion.assertEquals(expectedDataCenterId,
				cluster.getDataCenterMessage().getText() + " is a required property",
				"DataCenter id field message not matching");
		sAssertion.assertEquals(expectedHostlive, cluster.getHostLiverMessage().getText() + " is a required property",
				"HostLive field message not matching");
		sAssertion.assertEquals(expectedHostCanary,
				cluster.getHostCanaryMessage().getText() + " is a required property",
				"HostCanary field message not matching");
		sAssertion.assertEquals(expectedGroupname, cluster.getGroupNameMessage().getText() + " is a required property",
				"Groupd name field message not matching");
		sAssertion.assertAll();

		/*------------------ Click on create cluster By only entering values for group name field--------------- */
		cluster.getAcsCCDGroupSelectField().click();
		cluster.getAcseCCDGroupSelectSearchField().sendKeys("dcs");
		cluster.getAcsCCDGroupRadioButton().click();

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedClusterName, cluster.getClusterMessage().getText() + " is a required property",
				"Cluster name field message not matching");
		sAssertion.assertEquals(expectedDataCenterId,
				cluster.getDataCenterMessage().getText() + " is a required property",
				"DataCenter id field message not matching");
		sAssertion.assertEquals(expectedHostlive, cluster.getHostLiverMessage().getText() + " is a required property",
				"HostLive field message not matching");
		sAssertion.assertEquals(expectedHostCanary,
				cluster.getHostCanaryMessage().getText() + " is a required property",
				"HostCanary field message not matching");
		sAssertion.assertAll();

		/*------------------ Click on create cluster By only entering values for cluster name field--------------- */
		cluster.getCancelbutton().click();
		cluster.getAcsCreateCCDButton().click();

		cluster.getAcsCCDNameField().sendKeys("Cluster_test1");

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedDataCenterId,
				cluster.getDataCenterMessage().getText() + " is a required property",
				"DataCenter id field message not matching");
		sAssertion.assertEquals(expectedHostlive, cluster.getHostLiverMessage().getText() + " is a required property",
				"HostLive field message not matching");
		sAssertion.assertEquals(expectedHostCanary,
				cluster.getHostCanaryMessage().getText() + " is a required property",
				"HostCanary field message not matching");
		sAssertion.assertEquals(expectedGroupname, cluster.getGroupNameMessage().getText() + " is a required property",
				"Groupd name field message not matching");
		sAssertion.assertAll();

		/*------------------ Click on create cluster By only entering values of Host Live field--------------- */
		cluster.getCancelbutton().click();
		cluster.getAcsCreateCCDButton().click();

		cluster.getAcsCCDHostLiveField().sendKeys("192.168.109.36:443");

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedClusterName, cluster.getClusterMessage().getText() + " is a required property",
				"Cluster name field message not matching");
		sAssertion.assertEquals(expectedDataCenterId,
				cluster.getDataCenterMessage().getText() + " is a required property",
				"DataCenter id field message not matching");
		sAssertion.assertEquals(expectedHostCanary,
				cluster.getHostCanaryMessage().getText() + " is a required property",
				"HostCanary field message not matching");
		sAssertion.assertEquals(expectedGroupname, cluster.getGroupNameMessage().getText() + " is a required property",
				"Groupd name field message not matching");
		sAssertion.assertAll();

		/*------------------ Click on create cluster By only entering values of Host canary field--------------- */
		cluster.getCancelbutton().click();
		cluster.getAcsCreateCCDButton().click();

		cluster.getAcsCCDHostCanaryField().sendKeys("192.168.109.36:443");

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedClusterName, cluster.getClusterMessage().getText() + " is a required property",
				"Cluster name field message not matching");
		sAssertion.assertEquals(expectedDataCenterId,
				cluster.getDataCenterMessage().getText() + " is a required property",
				"DataCenter id field message not matching");
		sAssertion.assertEquals(expectedHostlive, cluster.getHostLiverMessage().getText() + " is a required property",
				"HostLive field message not matching");
		sAssertion.assertEquals(expectedGroupname, cluster.getGroupNameMessage().getText() + " is a required property",
				"Groupd name field message not matching");
		sAssertion.assertAll();

		/*------------------ Click on create cluster By only entering values of DataCenter  field--------------- */
		cluster.getCancelbutton().click();
		cluster.getAcsCreateCCDButton().click();

		cluster.getAcsCCDDataCenterSelectField().click();
		cluster.getAcsCCDDataCenterSearchField().sendKeys("indblr-blrrel");
		cluster.getAcsCCDDataCenterRadioButton().click();

		cluster.getAcsCreateCCDButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(expectedClusterName, cluster.getClusterMessage().getText() + " is a required property",
				"Cluster name field message not matching");
		sAssertion.assertEquals(expectedHostlive, cluster.getHostLiverMessage().getText() + " is a required property",
				"HostLive field message not matching");
		sAssertion.assertEquals(expectedHostCanary,
				cluster.getHostCanaryMessage().getText() + " is a required property",
				"HostCanary field message not matching");
		sAssertion.assertEquals(expectedGroupname, cluster.getGroupNameMessage().getText() + " is a required property",
				"Groupd name field message not matching");
		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		System.out.println("Sucessfully Logout");
	}
}

package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AlertReportPage;
import com.uam.pages.LoginPage;

public class AlertApiResponse extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] AlertApiResponseVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertsReport");
	}

	@Test(dataProvider = "AlertApiResponseVerification", enabled = true, priority = 1)
	public void AlertApiResponseVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String API_Response, String Channel,
			String Schema, String Regression,String desc) {

		System.out.println("=======Alert Report Verifivation=======");

		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		NewSimulatorCheckOutPage checkoutpage2 = new NewSimulatorCheckOutPage(driver);
		NewSimulatorOTPPage otp2 = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		String currentURL2 = null;
		LoginPage lp = new LoginPage(driver);
		// LogOutPage logout = new LogOutPage(driver);

		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);

			MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
			MPIOTPPage otp = new MPIOTPPage(driver);

			String currentURL = null;
			invocationCount++;

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage.getCardNumberField().clear();
			checkoutpage.getCardNumberField().sendKeys(Cardnumber);

			generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

			checkoutpage.getCardExpiryField().clear();
			checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			checkoutpage.getCardCVVField().clear();
			checkoutpage.getCardCVVField().sendKeys("111");

			checkoutpage.getQuantityField().clear();
			checkoutpage.getQuantityField().sendKeys("1");

			checkoutpage.getPurchaseAmountField().clear();
			checkoutpage.getPurchaseAmountField().sendKeys(amount);

			generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
			// putting try catch block to handle pop-up
			try {

				checkoutpage.getSubmitButton().click();
				generic.explicitWait(5);
				System.out.println("Clicked on Checkout button");

				// For Karnataka Bank
				if (IssuerBankId.equalsIgnoreCase("8131")) {
					driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
					generic.explicitWait(8);
				}
				
				if (String.valueOf(otp.getEnglishLangNBEbank().isDisplayed()).equalsIgnoreCase("true")) {
					// Change UI in English
					otp.getEnglishLangNBEbank().click();
				}

				/*
				 * Getting ACSTcnId from Pareq Date-28-07-2020
				 */

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);

				switch (Flow) {

				case "Challenge":
					log.info(Flow + "Started");
					generic.explicitWait(2);
					System.out.println("ACS Txn Id is : " + acsTxnId);
					if(API_Response.equalsIgnoreCase("INVALID_REQUEST")) {
						otp.getCardNotRegisteredContinueButton().click();
					}
					else {
						
					
					generic.explicitWait(2);
					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
					otp.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);
					if (TemplateType.equalsIgnoreCase("Rocker")) {
						otp.getRkrotpSubmitButton().click();
					} else {
						otp.getTmlotpSubmitButton().click();
						generic.explicitWait(2);
					}
					}
					break;
				}
			} catch (Exception e) {
				System.out.println("Handling unexpected popup");
				/*
				 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
				 * + alert.getText()); alert.accept();
				 */
				ErrorCollector.addVerificationFailure(e);
			}

			// driver.close();

			// Verify Hard block in Admin portal

		} else if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
			driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
			System.out.println("Merchant Name : " + merchantname);
			Select merchantoptions = new Select(checkoutpage2.getMerchantIdDropDown());
			merchantoptions.selectByVisibleText(merchantname);

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage2.getCardNumberField().clear();
			checkoutpage2.getCardNumberField().sendKeys(Cardnumber);

			checkoutpage2.getCardExpiryField().clear();
			checkoutpage2.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			System.out.println("Amout : " + amount);
			checkoutpage2.getPurchaseAmountField().clear();
			checkoutpage2.getPurchaseAmountField().sendKeys(amount);

			System.out.println("Currency : " + currencytype);
			checkoutpage2.getCurrencyDropDown().click();
			Select currencyoptions = new Select(checkoutpage2.getCurrencyDropDown());
			currencyoptions.selectByVisibleText(currencytype);

			System.out.println("Acquirer Bank Id : " + AccquirerBankId);
			checkoutpage2.getAcquirerIDField().clear();
			checkoutpage2.getAcquirerIDField().sendKeys(AccquirerBankId);
			System.out.println("Protocal Version : " + ProtocalVersion);

			// putting try catch block to handle popup
			try {
				String versionCheckUrl = checkoutpage2.getVersionCheckURLFeild().getAttribute("value");
				System.out.println("Version check url from simulator : " + versionCheckUrl);
				String arr[] = versionCheckUrl.split("pVrq/");
				System.out.println("Splitter version Check url is : " + arr[0]);
				String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
				System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
				checkoutpage2.getVersionCheckURLFeild().clear();
				checkoutpage2.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
				checkoutpage2.getSubmitButton().click();

				System.out.println("Clicked on Checkout button");

				switch (Flow) {

				case "Challenge":
					log.info(Flow + "Started");
					// generic.explicitWait(3);
					if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
						// generic.explicitWait(3);
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						// generic.explicitWait(2);
					} else {
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
						// document.getElementByName('acctId').value").toString();
						// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
						System.out.println("Clicked on Checkout button");

						/*
						 * Getting ACSTcnId from Pareq Date-28-07-2020
						 */

						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						System.out.println("Pareq:-" + paReq);
						String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
						// System.out.println("tesdDecode:-" + tesdDecode);
						String arr1[] = tesdDecode.split("&");
						String testEncodedPaReq = arr1[0];
						String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
						System.out.println("testDecodedPareq:-" + testDecodedPareq);
						acsTxnId = generic.getValueFromXml(testDecodedPareq);
						System.out.println("acsTxnId:-" + acsTxnId);
						generic.explicitWait(2);
					}

					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);

					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

					otp2.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);

					otp2.getOtpSubmitButton().click();

					break;

				}
			} catch (UnhandledAlertException u) {
				System.out.println("Handling unexpected popup");

				Alert alert = driver.switchTo().alert();
				System.out.println("Type of alert: " + alert.getText());
				alert.accept();

				ErrorCollector.addVerificationFailure(u);
			} catch (Exception e) {
				System.out.println("Handling unexpected popup" + e);

			}
		}
		driver.get(Config.BASE_UAM_URL);
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// selecting date and fetching report
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);
		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null")) {
			System.out.println("Acs txn id is null ");
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);
		}

		acsTxnPage.getFetchReportButton().click();
		System.out.println("Clicked on Fetch Report button");
		generic.explicitWait(5);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		generic.explicitWait(2);

		String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
		String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);

		if (Channel.equalsIgnoreCase("Both")) {
			// validating card number
			List<WebElement> cardNumWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[2]"));
			for (WebElement cardNumber : cardNumWebElement) {
				sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
						cardNumber.getText());
			}
			// validating channel
			List<WebElement> channelWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[7]"));
			for (int i = 0; i < 2; i++) {
				if (i == 0) {
					String channelType = channelWebElement.get(i).getText();
					switch (channelType) {
					case "SMS":
						sAssertion.assertEquals(channelWebElement.get(i).getText(), "SMS");
						break;

					case "Email":
						sAssertion.assertEquals(channelWebElement.get(i).getText(), "Email");
						break;
					}
				}

			}

			// validating Mobile Number
			List<WebElement> mobileWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[8]"));
			for (WebElement mobileNumber : mobileWebElement) {
				sAssertion.assertEquals(Mobile, mobileNumber.getText());
			}
			// Validating Email-id
			List<WebElement> emailWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[10]"));
			for (WebElement emailId : emailWebElement) {
				sAssertion.assertEquals(Email, emailId.getText());
			}
		} else if (Channel.equalsIgnoreCase("SMS")) {
			//sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
					//aReport.getAlertChannelTypeText().getText());
			//sAssertion.assertEquals(Channel, aReport.getAlertChannelTypeText().getText());
			//sAssertion.assertEquals(Mobile, aReport.getAlertMobileNumberText().getText());
			//sAssertion.assertEquals(Email, aReport.getAlertEmailText().getText());
			//sAssertion.assertEquals("Y", aReport.getAlertTransactionStatusText().getText());
			System.out.println("Api Response: "+aReport.getAlertApiResponseText().getText());
			sAssertion.assertEquals(API_Response, aReport.getAlertApiResponseText().getText());

		}

		else if (Channel.equalsIgnoreCase("Email")) {
			//sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
					//aReport.getAlertChannelTypeText().getText());
			//sAssertion.assertEquals(Channel, aReport.getAlertChannelTypeText().getText());
			//sAssertion.assertEquals(Mobile, aReport.getAlertMobileNumberText().getText());
			//sAssertion.assertEquals(Email, aReport.getAlertEmailText().getText());
			//sAssertion.assertEquals("Y", aReport.getAlertTransactionStatusText().getText());
			System.out.println("Api Response: "+aReport.getAlertApiResponseText().getText());
			sAssertion.assertEquals(API_Response, aReport.getAlertApiResponseText().getText());

		}

		sAssertion.assertAll();

	}
}

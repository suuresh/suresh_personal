package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

public class AdminLoginValidation extends ACSInitialSetUp {
	/* Modified By Suuresh */
	@DataProvider
	public Object[][] verifyLoginInvalidUnAndPwd() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Login");
	}

	@Test(dataProvider = "verifyLoginInvalidUnAndPwd", priority = 1, enabled = true)
	public void verifyLoginInvalidUnAndPwd(String UserName, String Password, String Flow, String desc) {
		System.out.println("=======Verify Invalid User and Password=======");

		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		LoginPage lp = new LoginPage(driver);
		LogOutPage logout = new LogOutPage(driver);
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);

		lp.getLoginIDTextField().sendKeys(UserName);
		lp.getPasswordTextField().sendKeys(Password);

		if (Flow.equalsIgnoreCase("Positive")) {
			lp.getLoginButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(),
					"WELCOME TO ACCOSA IVSTM");
			System.out.println("Login Successfully");
			generic.explicitWait(2);
			logout.logout();
			System.out.println("Sucessfully Logout");
		} else if (Flow.equalsIgnoreCase("Negative")) {
			lp.getLoginButton().click();
			//
			//div[contains(text(),'Please enter valid credentials')]
			// Negative scenario			
			
			if(desc == "invalid UserName and valid password")
			{
				WebElement alertPopup = driver.findElement(
						By.xpath("//div[contains(text(),'User Validation Failed :: UserId and Password comb')]"));
				String alertPopupMessage = alertPopup.getText();
				System.out.println("alertPopup Message : " + alertPopupMessage);
				sAssertion.assertEquals(alertPopupMessage,
						"User Validation Failed :: UserId and Password combination is not correct");
			}
			else if(desc == "Valid UserName and Invalid password")
			{
				WebElement alertPopup = driver.findElement(
						By.xpath("//div[contains(text(),'Wrong input entered')]"));
				String alertPopupMessage = alertPopup.getText();
				System.out.println("alertPopup Message : " + alertPopupMessage);
				sAssertion.assertEquals(alertPopupMessage,
						"Wrong input entered, Please try again");
			}
		} else if (Flow.equalsIgnoreCase("BlankUser") || Flow.equalsIgnoreCase("BlankPassword")) {
			lp.getLoginButton().click();
			// Negative scenario
			//WebElement alertPopup = driver.findElement(By.xpath("//div[contains(text(),'BAD REQUEST')]"));
			WebElement alertPopup = driver.findElement(By.xpath("//div[contains(text(),'Please enter valid credentials')]"));
			String alertPopupMessage = alertPopup.getText();
			System.out.println("alertPopup Message : " + alertPopupMessage);
			//sAssertion.assertEquals(alertPopupMessage, "BAD REQUEST");
			sAssertion.assertEquals(alertPopupMessage, "Please enter valid credentials");
		}
		sAssertion.assertAll();
	}

}

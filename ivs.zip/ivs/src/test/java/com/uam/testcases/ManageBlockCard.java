package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LogOutPage;
import com.uam.pages.ManageBlockedCardPage;

public class ManageBlockCard extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);

	public void waitUntilElementIsPresent(String s) {
		// To wait for element visible
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(s)));
		System.out.print("Waiting till Element is now visible");
	}

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(5);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	/*
	 * Scenario:- 1.Blocking card as softblock, hardblock and hotlist and verify the
	 * same. 2.Active the softblock, hardblock, and hotlist and verify the same.
	 */

	@DataProvider
	public Object[][] BlockingCard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ManageBlockCardData");
	}

	@Test(dataProvider = "BlockingCard", enabled = true)
	public void BlockingCard(String BankName, String BlockingCardDetail, String Status, String Comment,
		String ActiveCardDetails, String UnblockingComment, String Desc) {
		System.out.println("=======Navigating to ManageBlockCard=======");
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTestManager.getTest().setDescription(Desc);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		js.executeScript("arguments[0].click();", adminhomepage.getManageBlockedCardsLink());
		// adminhomepage.getManageBlockedCardsLink().click();
		generic.explicitWait(5);

		// Blocking the card
		manageBlockCardPage.getBlockCardPlusButton().click();
		generic.explicitWait(8);
		manageBlockCardPage.getCardNumberTextField().sendKeys(BlockingCardDetail);
		manageBlockCardPage.getStatusDropdown().click();
		if (Status.equalsIgnoreCase("SOFTBLOCK")) {
			System.out.println("Softblock..");
			manageBlockCardPage.getSoftBlockDropdownlist().click();
		} else if (Status.equalsIgnoreCase("HOTLIST")) {
			System.out.println("Hotlist..");
			manageBlockCardPage.getHotListDropdownList().click();
		} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
			System.out.println("Hardblock..");
			manageBlockCardPage.getHardBlockDropdownList().click();
		}

		// Comment and Save
		manageBlockCardPage.getCommentTextField().sendKeys(Comment);
		generic.explicitWait(3);

		js.executeScript("window.scrollBy(0,-250)", "");
		manageBlockCardPage.getBlockingCard_SaveButton().click();

		generic.explicitWait(10);
		System.out.println("Card is blocked");
		// Verify Blocked card

		wait.until(ExpectedConditions.elementToBeClickable(manageBlockCardPage.getFilteredByDropdown()));
		manageBlockCardPage.getFilteredByDropdown().click();

		// js.executeScript("arguments[0].click();",
		// adminhomepage.getManageBlockedCardsLink());
		// manageBlockCardPage.getFilteredByDropdown().click();

		if (Status.equalsIgnoreCase("SOFTBLOCK")) {
			System.out.println("Softblock..");
			manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
		} else if (Status.equalsIgnoreCase("HOTLIST")) {
			System.out.println("Hotlist..");
			manageBlockCardPage.getFilteredByDropdownHotList().click();
		} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
			System.out.println("Hardblock..");
			manageBlockCardPage.getFilteredByDropdownHardBlock().click();
		}

		if(ActiveCardDetails.length()>0) {
			
			String last4Digit = ActiveCardDetails.substring(ActiveCardDetails.length() - 4);
			System.out.println("Last4Digit:- " + last4Digit);
			// manageBlockCardPage.getSearchBox().sendKeys(last4Digit);
			// Adding new CR for Advance search
			if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
				manageBlockCardPage.getAdvanceSearchPlusSign().click();
			}

			generic.explicitWait(2);
			manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
			manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(ActiveCardDetails);
			manageBlockCardPage.getSearchButton().click();

			if (driver
					.findElements(By.xpath(
							"//div[text()='Card number']/../following::div/div/div[contains(text(),'" + last4Digit + "')]"))
					.size() >= 0) {
				System.out.println("Card is blocked sucessfully");
				driver.findElement(By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
						+ last4Digit + "')]/following::div/div/div[@class='options__edit']")).click();
			} else {
				System.out.println("Card is not blocked");
			}

			// Active the card
			manageBlockCardPage.getUnBlock_StatusDropdown().click();
			if (Status.equalsIgnoreCase("SOFTBLOCK")) {
				System.out.println("Activated Softblock..");
				manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
			} else if (Status.equalsIgnoreCase("HOTLIST")) {
				System.out.println("Activated Hotlist..");
				manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
			} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
				System.out.println("Activated Hardblock..");
				manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
			}

			manageBlockCardPage.getUnBlock_CommentTextField().sendKeys(UnblockingComment);

			JavascriptExecutor js1 = (JavascriptExecutor) driver;
			js1.executeScript("arguments[0].click();", manageBlockCardPage.getUnBlock_SaveChangesButton());
			// manageBlockCardPage.getUnBlock_SaveChangesButton().click();
			generic.explicitWait(6);
			// Verify successful message
			System.out.println("Verify success message");

		}
		
		
	}

	// Validating unblocked card
	@DataProvider
	public Object[][] ValidateUnblockedCard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ManageBlockCardData");
	}

	@Test(dataProvider = "ValidateUnblockedCard", enabled = true)
	public void ValidateUnblockedCard(String BankName, String BlockingCardDetail, String Status, String Comment,
			String ActiveCardDetails, String UnblockingComment, String Desc) {
		System.out.println("=======Navigating to ManageBlockCard=======");
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(Desc);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		generic.explicitWait(2);
		js.executeScript("arguments[0].click();", adminhomepage.getOperationsLink());
		//adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		js.executeScript("arguments[0].click();", adminhomepage.getManageBlockedCardsLink());
		//adminhomepage.getManageBlockedCardsLink().click();
		generic.explicitWait(7);
		manageBlockCardPage.getFilteredByDropdown().click();
		if (Status.equalsIgnoreCase("SOFTBLOCK")) {
			System.out.println("Softblock..");
			manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
		} else if (Status.equalsIgnoreCase("HOTLIST")) {
			System.out.println("Hotlist..");
			manageBlockCardPage.getFilteredByDropdownHotList().click();
		} else if (Status.equalsIgnoreCase("HARDBLOCK")) {
			System.out.println("Hardblock..");
			manageBlockCardPage.getFilteredByDropdownHardBlock().click();
		}

		generic.explicitWait(7);

		String last4Digit = ActiveCardDetails.substring(ActiveCardDetails.length() - 4);
		System.out.println("Last4Digit:- " + last4Digit);
		// manageBlockCardPage.getSearchBox().sendKeys(last4Digit);
		// Adding new CR for Advance search
		if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
			manageBlockCardPage.getAdvanceSearchPlusSign().click();
		}

		generic.explicitWait(2);
		manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
		manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(ActiveCardDetails);
		manageBlockCardPage.getSearchButton().click();

		if (driver
				.findElements(By.xpath(
						"//div[text()='Card number']/../following::div/div/div[contains(text(),'" + last4Digit + "')]"))
				.size() > 0) {

			System.out.println("Card is still blocked ");
			sAssertion.assertEquals("Blocked", "Unblocked");
			sAssertion.assertAll();

		} else {
			System.out.println("Card is successfully Unblocked");
		}

	}

	/*
	 * Scenario: 1.Validate the card whether it block and if so unblock the card
	 */
	@DataProvider
	public Object[][] ValidatingCard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CardUnBlocking");
	}

	@Test(dataProvider = "ValidatingCard", enabled = true)
	public void ValidatingCard(String IssuerBankId, String BankName, String AccquirerBankId, String Cardnumber,
			String ProtocalVersion, String Flow, String merchantname, String amount, String currencytype,
			String CardUnionType, String UnblockingComment, String decs) {
		System.out.println("=======Navigating to ManageBlockCard=======");

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		ExtentTestManager.getTest().setDescription(decs);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);

		if (IssuerBankId.equalsIgnoreCase("8271")) {

			driver.findElement(By.xpath("//span[contains(text(),'" + BankName + "')]")).click();
		} else {
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase(BankName)) {
					bankName.click();
					break;
				}
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", adminhomepage.getManageBlockedCardsLink());
		// adminhomepage.getManageBlockedCardsLink().click();
		generic.explicitWait(8);

		String last4DigitV = Cardnumber.substring(Cardnumber.length() - 4);
		System.out.println("Last4Digit:- " + last4DigitV);

		// Verify card is blocked if so then unblock

		String[] block = { "SOFTBLOCK", "HARDBLOCK", "HOTLIST" };
		for (String cardType : block) {
			System.out.println("Checking in CardType: " + cardType);
			js.executeScript("arguments[0].click();", manageBlockCardPage.getFilteredByDropdown());
			// manageBlockCardPage.getFilteredByDropdown().click();
			// manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
			driver.findElement(By.xpath("//label[@for='" + cardType + "']")).click();
			generic.explicitWait(8);

			// generic.waitForProgressBar();
			// manageBlockCardPage.getSearchBox().clear();
			// manageBlockCardPage.getSearchBox().sendKeys(last4DigitV);

			// Adding new CR for Advance search
			if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
				manageBlockCardPage.getAdvanceSearchPlusSign().click();
			}

			generic.explicitWait(6);
			manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
			manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(Cardnumber);
			manageBlockCardPage.getSearchButton().click();
			generic.explicitWait(2);
			if (driver.findElements(By.xpath(
					"//div[text()='Card number']/../following::div/div/div[contains(text(),'" + last4DigitV + "')]"))
					.size() > 0) {
				System.out.println("Card is blocked...");
				driver.findElement(By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
						+ last4DigitV + "')]/following::div/div/div[@class='options__edit']")).click();
				manageBlockCardPage.getUnBlock_StatusDropdown().click();
				manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
				manageBlockCardPage.getUnBlock_CommentTextField().sendKeys(UnblockingComment);

				JavascriptExecutor js1 = (JavascriptExecutor) driver;
				js1.executeScript("arguments[0].click();", manageBlockCardPage.getUnBlock_SaveChangesButton());
				// manageBlockCardPage.getUnBlock_SaveChangesButton().click();
				generic.explicitWait(6);
				// Verify successful message
				System.out.println("Card is active now");
				break;
			} else {
				System.out.println("Card is in active state");
			}

			System.out.println("All Done");
		}

	}

	/*
	 * 1.Checking the error message by blocking unregister card
	 */
	@Test(enabled = true)
	public void validateUnregisterCard() {
		System.out.println("=======Navigating to ManageBlockCard=======");

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		ExtentTestManager.getTest().setDescription("Validating error message by blocking unregistered card");
		SoftAssert sAssertion = new SoftAssert();
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		adminhomepage.getManageBlockedCardsLink().click();
		generic.explicitWait(5);

		// Blocking card with unregister card
		manageBlockCardPage.getBlockCardPlusButton().click();
		generic.explicitWait(8);
		manageBlockCardPage.getCardNumberTextField().sendKeys("5648398473257437");
		manageBlockCardPage.getStatusDropdown().click();
		manageBlockCardPage.getSoftBlockDropdownlist().click();
		manageBlockCardPage.getCommentTextField().sendKeys("Blocking by Automation");
		manageBlockCardPage.getBlockingCard_SaveButton().click();
		generic.explicitWait(3);
		String actualErrorMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		String expectedErrorMessage = "BIN-RANGE NOT FOUND OR BIN-RANGE ID INVALID";
		System.out.println("actualErrorMessage:-" + actualErrorMessage);
		sAssertion.assertEquals(actualErrorMessage, expectedErrorMessage);
		sAssertion.assertAll();

	}

	@AfterMethod
	public void logout() {
		LogOutPage logout = new LogOutPage(driver);
		logout.logout();
		System.out.println("Sucessfully Logout");
	}
}

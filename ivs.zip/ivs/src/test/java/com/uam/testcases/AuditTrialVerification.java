package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AuditTrialPage;

public class AuditTrialVerification extends ACSInitialSetUp {
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {
		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AuditTrial");
	}

	@Test(dataProvider = "DataSet")
	public void fetchAcsTransactionReport(String IssuerBankId, String IssuerBankName, String Operation,
			String MobileNumber, String panNumber, String decs) {
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AuditTrialPage auditTrialPage = new AuditTrialPage(driver);
		/*auditTrialPage.getSelectBank().click();
		auditTrialPage.getDropDownBankNameNational().click();*/
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		switch (Operation) {	
		case "ACS Transaction Report":
			log.info(Operation + "Started");
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsTransactionReport().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(5);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsTransactionReportScreen().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			acsLeftHoursOptions.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(1);
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestActionType().getText(), "ACS-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensType().getText(), "ACS Transaction");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "MDD Report":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsMddReport().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions1 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions1.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(8);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsMddScreen().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			acsLeftHoursOptions1.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(2);
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestMddActionType().getText(), "ACS-MDD-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeMdd().getText(), "MDD Report");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Alerts Report":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsAlertReport().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions2 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions2.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(3);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsAlertScreen().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			acsLeftHoursOptions2.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(4);
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAlertsActionType().getText(), "ACS-ALERT-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeAlert().getText(), "Alert History Report");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;

		case "Customer File Upload List":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsOperations().click();
			auditTrialPage.getAcsCustomDataUpload().click();
			generic.explicitWait(1);
			auditTrialPage.getSaveFileData().click();
			generic.explicitWait(8);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsCustomerFileUploadList().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions5 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions5.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsCustomerFileUploadType().getText(),
					"ACS Customer File Upload List");
			//sAssertion.assertEquals(auditTrialPage.getScreensTypeFileUpload().getText(), "Config-Upload");
			// sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(),
			// IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;

		case "Manage Blocked Cards":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsOperations().click();
			auditTrialPage.getAcsOperationsManageBlockedCards().click();
			generic.explicitWait(6);
			auditTrialPage.getSelectBlockedCard().click();
			auditTrialPage.getSelectHotListCard().click();
			generic.explicitWait(3);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsManageBlockedCards().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions7 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions7.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			//sAssertion.assertEquals(auditTrialPage.getRequestAcsManageBlockedCard().getText(), "VIEW-CUSTOMER-DETAILS");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeManageBlockedCard().getText(),
					"ACS Manage-cards-block");
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Manage RBA Config":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsConfigurations().click();
			auditTrialPage.getAcsManageRbaConfig().click();
			generic.explicitWait(1);
			auditTrialPage.getEditRuleSetDetails().click();
			generic.explicitWait(1);
			auditTrialPage.getSaveChanges().click();
			generic.explicitWait(8);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsManageRbaConfigScreen().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions8 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions8.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(1);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			// sAssertion.assertEquals(auditTrialPage.getRequestAcsRbaRulesType().getText(),
			// "FETCH-LIST-OF-RBA-RULES");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeRbaManage().getText(), "RBA Manage");
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Issuer Configurations":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsConfigurations().click();
			auditTrialPage.getAcsIssuerConfigurations().click();
			generic.explicitWait(2);
			auditTrialPage.getEditActionConfigurationsFirstOne().click();
			auditTrialPage.getSaveConfigurations().click();
			generic.explicitWait(7);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsIssuerConfigurationsSelectScreen().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions9 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions9.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(1);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			//sAssertion.assertEquals(auditTrialPage.getRequestAcsIssuerConfigurations().getText(),"UPDATE-ACS-ISSUER-CONFIG-VALUE");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeIssuerConfiguration().getText(),"Issuer Configuration");
			//sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Issuer Bin Range":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsConfigurations().click();
			auditTrialPage.getAcsIssuerBinRangeConfigurations().click();
			generic.explicitWait(1);
			auditTrialPage.getEditBinRange().click();
			generic.explicitWait(3);
			auditTrialPage.getUpdateBinRange().click();
			generic.explicitWait(6);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsIssuerBinRangeScreen().click();
			generic.explicitWait(2);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions11 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions11.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsIsserBinRangeType().getText(),
					"FETCH-LIST-OF-ISSUER-BIN-RANGES");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeIsserBibRange().getText(), "Issuer-bin-ranges");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "RBA MIS":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsRbaMis().click();
			generic.explicitWait(1);
			auditTrialPage.getCalenderDatePicker().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions12 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions12.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsRbaMisScreen().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			acsLeftHoursOptions12.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(1);
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestTypeRbaMis().getText(), "ACS-RBA-MIS-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeRbiMis().getText(), "RBA MIS");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Monitoring Dashboard":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsMonitoringDashboard().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions3 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions3.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsMonitoringDashboardScreen().click();
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			acsLeftHoursOptions3.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			auditTrialPage.getBtnFetchReport().click();
			generic.explicitWait(10);
			auditTrialPage.getTableRecordEntityAction().click();
			//sAssertion.assertEquals(auditTrialPage.getRequestMonitoringDashboardType().getText(),"ACS-MONITORING-DASHBOARD-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeMonitoringDashboard().getText(),"Monitoring Dashboard");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "ACS Dashboard":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsReportDashboards().click();
			auditTrialPage.getAcsDashboard().click();
			generic.explicitWait(9);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsDashboardScreen().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions4 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions4.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsDashboardType().getText(),"ACS-DASHBOARD-REPORT-FETCH");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeDashboard().getText(), "ACS Report Dashboard");
			sAssertion.assertEquals(auditTrialPage.getIssuerId().getText(), IssuerBankId);
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Manage Cardholder Details":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsOperations().click();
			auditTrialPage.getAcsOperationsManageCardholderDetails().click();
			generic.explicitWait(1);
			auditTrialPage.getInputMobileNumberManage().sendKeys(MobileNumber);
			auditTrialPage.getLinkSearch().click();
			auditTrialPage.getEditRecords().click();
			generic.explicitWait(1);
			auditTrialPage.getLinkSaveChanges().click();
			generic.explicitWait(10);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsManageCardholderDetails().click();
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions6 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions6.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsManageCardHolderDetails().getText(),"UPDATE_CARD_DATA");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeViewCustomerDetails().getText(),"View Customer Details");
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Search deatil with last four digit pan Number":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsOperations().click();
			auditTrialPage.getAcsOperationsManageCardholderDetails().click();
			generic.explicitWait(1);
			auditTrialPage.getTextCardNumber().sendKeys(panNumber);
			auditTrialPage.getLinkSearch().click();
			auditTrialPage.getEditRecords().click();	
			String lastFourDigitCard=panNumber.substring(12, 16);
			auditTrialPage.getInputMobileNumber().clear();
			auditTrialPage.getInputMobileNumber().sendKeys("1234567890");
			//generic.explicitWait(1);
			auditTrialPage.getLinkSaveChanges().click();
			generic.explicitWait(10);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsManageCardholderDetails().click();
			auditTrialPage.getTextLastFourDigitPan().sendKeys(lastFourDigitCard);
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions10 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions10.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsManageCardHolderDetails().getText(),"UPDATE_CARD_DATA");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeViewCustomerDetails().getText(),"View Customer Details");
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Search with Full PAN in the Audit Trail":
			auditTrialPage.getLinkACS().click();
			auditTrialPage.getAcsOperations().click();
			auditTrialPage.getAcsOperationsManageCardholderDetails().click();
			generic.explicitWait(1);
			auditTrialPage.getTextCardNumber().sendKeys(panNumber);
			auditTrialPage.getLinkSearch().click();
			auditTrialPage.getEditRecords().click();	
			auditTrialPage.getInputMobileNumber().clear();
			auditTrialPage.getInputMobileNumber().sendKeys("1234567890");
			//generic.explicitWait(1);
			auditTrialPage.getLinkSaveChanges().click();
			generic.explicitWait(10);
			auditTrialPage.getLinkUam().click();
			auditTrialPage.getLinkAuditTrail().click();
			auditTrialPage.getPlusLinkAdvancedSearch().click();
			auditTrialPage.getSelectScreens().click();
			auditTrialPage.getAcsManageCardholderDetails().click();
			auditTrialPage.getInputCardNumber().sendKeys(panNumber);
			generic.explicitWait(1);
			acsTxnPage.getAcsCalenderIcon().click();
			acsTxnPage.getAcsLeftHoursSelect().click();
			Select acsLeftHoursOptions13 = new Select(acsTxnPage.getAcsLeftHoursSelect());
			acsLeftHoursOptions13.selectByValue("0");
			acsTxnPage.getApplyButton().click();
			generic.explicitWait(2);
			auditTrialPage.getBtnFetchReport().click();
			auditTrialPage.getTableRecordEntityAction().click();
			sAssertion.assertEquals(auditTrialPage.getRequestAcsManageCardHolderDetails().getText(),
					"UPDATE_CARD_DATA");
			sAssertion.assertEquals(auditTrialPage.getScreensTypeViewCustomerDetails().getText(),
					"View Customer Details");
			sAssertion.assertEquals(auditTrialPage.getUserName().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		}
		sAssertion.assertAll();
	}
	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());
	}
}

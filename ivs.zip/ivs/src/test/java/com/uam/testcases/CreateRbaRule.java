package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LogOutPage;
import com.uam.pages.ManageRbaConfigPage;

public class CreateRbaRule extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] AddNewRuleSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "RbaConfigRule");
	}

	@Test(dataProvider = "AddNewRuleSet", priority = 1, enabled = false)
	public void AddNewRuleSet(String BankName, String RuleSetName, String RuleSetStatus,
			String DefaultModeOfAuthentication, String RuleSetDescription, String RuleType, String Parameter1,
			String Parameter2, String Condition1, String Condition2, String Value1, String Value2,
			String ModeOfAuthentication, String IssuerBinRange, String decs) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageRbaConfigPage manageRbaConfigPage = new ManageRbaConfigPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		//driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageRbaConfig
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getManageRbaConfigLink().click();

		// Add new rule set
		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RulesetNameWithNum = RuleSetName + "" + randomPIN;

		manageRbaConfigPage.getAddNewRuleSetButton().click();
		manageRbaConfigPage.getRuleSetNameTextField().sendKeys(RulesetNameWithNum);
		manageRbaConfigPage.getRuleSetStatusDropdown().click();
		manageRbaConfigPage.getActiveRuleSetStatusDropdown().click();

		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();

		manageRbaConfigPage.getRuleSetDescTextField().sendKeys(RuleSetDescription);
		manageRbaConfigPage.getCreateNewRuleIcon().click();
		// setting parameter

		manageRbaConfigPage.getFirstParameterDropdown().click();
		switch (RuleType) {
		case "Risk Engine Score":
			System.out.println("Parameter : Risk Engine Score");
			manageRbaConfigPage.getRiskEngineScoreDropdownList().click();
			manageRbaConfigPage.getRiskEngineScore_conditionDropdown().click();
			// driver.findElement(By.xpath("(//a[contains(text(),'" + Condition +
			// "')])[1]")).click();
			// manageRbaConfigPage.getRiskEngineScor_valueTextField().sendKeys(Value);
			break;

		case "Risk Engine Suggestion":
			System.out.println("Parameter : Risk Engine Suggestion");
			manageRbaConfigPage.getRiskEngineSuggestionDropdownlist().click();
			manageRbaConfigPage.getRES_valueDropdown().click();
			// driver.findElement(By.xpath("(//a[contains(text(),'" + Value +
			// "')])[1]")).click();
			break;

		case "Merchant Name":
			System.out.println("Parameter : Merchant Name");
			manageRbaConfigPage.getMerchantNameDropdownList().click();
			manageRbaConfigPage.getMerchantName_ConditionsDropdown().click();
			// driver.findElement(By.xpath("(//a[contains(text(),'" + Condition +
			// "')])[1]")).click();
			// manageRbaConfigPage.getMerchantId_valueTextField().sendKeys(Value);
			break;

		case "Amount":
			System.out.println("Parameter : Amount");
			manageRbaConfigPage.getAmountDropdownList().click();
			manageRbaConfigPage.getAmount_conditionDropdown().click();
			// driver.findElement(By.xpath("(//a[contains(text(),'" + Condition +
			// "')])[1]")).click();
			// manageRbaConfigPage.getAmount_valueTextField().sendKeys(Value);
			break;

		case "Transaction Type":
			System.out.println("Parameter : Transaction Type");
			manageRbaConfigPage.getTransactionTypeDropdownList().click();
			manageRbaConfigPage.getTransactionType_valueDropdown().click();
			// driver.findElement(By.xpath("(//a[contains(text(),'" + Value +
			// "')])[1]")).click();
			break;

		case "Merchant Category Code":
			System.out.println("Parameter : Merchant Category Code");
			manageRbaConfigPage.getMerchantCategoryCodeDropdownList().click();
			// manageRbaConfigPage.getMerchantCategoryCode_valueTextField().sendKeys(Value);
			break;

		case "Merchant Id":
			System.out.println("Parameter : Merchant Id");
			manageRbaConfigPage.getMerchantIdDropdownList().click();
			// manageRbaConfigPage.getMerchantId_valueTextField().sendKeys(Value);
			break;
		}

		// Select Mode of Authentication
		manageRbaConfigPage.getModeOfAuthDropdown().click();
		if (ModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getModeOfAuth_Otp().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getModeOfAuth_Frictionless().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getModeOfAuth_DenyDecline().click();
		}
		// Saving the rule

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)", "");
		generic.explicitWait(2);
		manageRbaConfigPage.getSaveChangesButton().click();

		generic.explicitWait(3);
		String actualMessage = "Rule Set Created Successfully.";
		String expectedMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedMessage:-" + expectedMessage);

		sAssertion.assertEquals(actualMessage, expectedMessage);

		String ruleSetId = driver.findElement(By.xpath("//div[text()='" + RulesetNameWithNum + "']/parent::div/div[2]"))
				.getText();
		System.out.println("Rule Set Id:-" + ruleSetId);

		// Navigating to Issuer Bin Range
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getIssuerBinRangeConfigLink().click();

		// Selecting Bin Range
		generic.explicitWait(2);
		System.out.println("Assigning rule to issuer Bin Range");
		driver.findElement(
				By.xpath("(//div[text()='" + IssuerBinRange + "']/following::div/div/div[@data-tip='Edit'])[1]"))
				.click();
		generic.explicitWait(5);

		js.executeScript("window.scrollBy(0,600)", "");
		generic.explicitWait(2);
		driver.findElement(By.xpath("(//div[@data-tip='Rba Config']/following::div/div/a)[1]")).click();
		driver.findElement(By.xpath("//label[@for='" + ruleSetId + "']")).click();
		js.executeScript("window.scrollBy(0,-600)", "");
		generic.explicitWait(2);
		driver.findElement(By.xpath("//a[text()='Update']")).click();
		generic.explicitWait(3);
		System.out.println("Rule set is updated with Issuer Bin Range");
		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] AddDifferentRuleSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "RbaConfigRule");
	}

	@Test(dataProvider = "AddDifferentRuleSet", priority = 1, enabled = true)
	public void AddDifferentRuleSet(String BankName, String RuleSetName, String RuleSetStatus,
			String DefaultModeOfAuthentication, String RuleSetDescription, String RuleType, String Parameter1,
			String Parameter2, String Condition1, String Condition2, String Value1, String Value2,
			String ModeOfAuthentication, String IssuerBinRange, String decs) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		Actions action = new Actions(driver);
		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageRbaConfigPage manageRbaConfigPage = new ManageRbaConfigPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		//driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageRbaConfig
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getManageRbaConfigLink().click();

		// Add new rule set
		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RulesetNameWithNum = RuleSetName + "" + randomPIN;

		manageRbaConfigPage.getAddNewRuleSetButton().click();

		manageRbaConfigPage.getRuleSetNameTextField().sendKeys(RulesetNameWithNum);
		manageRbaConfigPage.getRuleSetStatusDropdown().click();
		manageRbaConfigPage.getActiveRuleSetStatusDropdown().click();

		/*
		 * manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		 * manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();
		 */

		// Select Default Mode of Authentication
		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		if (DefaultModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();
		} else if (DefaultModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getFrictionlessModeOfAuthenticationDropdownlist().click();
		} else if (DefaultModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getDenyModeOfAuthenticationDropdownlist().click();
		}

		manageRbaConfigPage.getRuleSetDescTextField().sendKeys(RuleSetDescription);
		manageRbaConfigPage.getCreateNewRuleIcon().click();

		switch (RuleType) {
		case "Rule#1":
			System.out.println("Rule Desc:- " + RuleSetDescription);
			manageRbaConfigPage.getFirstParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter1 + "'])[1]")).click();
			manageRbaConfigPage.getFirstConditionDropdown().click();
			System.out.println("Chechpoint-1 " + Parameter1);
			driver.findElement(By.xpath("(//a[contains(text(),'" + Condition1 + "')])[1]")).click();
			System.out.println("Chechpoint-1 " + Condition1);
			manageRbaConfigPage.getFirstValueTextField().sendKeys(Value1);
			System.out.println("Value1 :- " + Value1);
			break;

		case "Rule#2":
			System.out.println("Rule Desc:- " + RuleSetDescription);
			manageRbaConfigPage.getFirstParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter1 + "'])[1]")).click();
			System.out.println("Chechpoint-1 " + Parameter1);
			manageRbaConfigPage.getFirstValueDropdown().click();
			driver.findElement(By.xpath("(//a[contains(text(),'" + Value1 + "')])[1]")).click();
			break;
		case "Rule#3":
			System.out.println("Rule Desc:- " + RuleSetDescription);
			manageRbaConfigPage.getFirstParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter1 + "'])[1]")).click();

			System.out.println("Chechpoint-1 " + Parameter1);
			manageRbaConfigPage.getFirstValueTextField().sendKeys(Value1);
			break;
		case "Rule#4":
			System.out.println("Rule Desc:- " + RuleSetDescription);
			manageRbaConfigPage.getFirstParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter1 + "'])[1]")).click();
			manageRbaConfigPage.getFirstConditionDropdown().click();
			System.out.println("Chechpoint-1 " + Parameter1);
			driver.findElement(By.xpath("(//a[contains(text(),'" + Condition1 + "')])[1]")).click();
			System.out.println("Chechpoint-1 " + Condition1);
			manageRbaConfigPage.getFirstValueTextField().sendKeys(Value1);
			System.out.println("Value1 :- " + Value1);

			generic.explicitWait(3);
			// Adding Second Condition
			manageRbaConfigPage.getPlusConditionButton().click();
			generic.explicitWait(3);
			manageRbaConfigPage.getSecondParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter2 + "'])[1]")).click();

			manageRbaConfigPage.getSecondConditionDropdown().click();
			System.out.println("Chechpoint-2 " + Parameter2);
			driver.findElement(By.xpath("(//a[contains(text(),'" + Condition2 + "')])[1]")).click();
			System.out.println("Chechpoint-2 " + Condition2);
			manageRbaConfigPage.getSecondValueTextField().sendKeys(Value2);
			System.out.println("Value2 :- " + Value2);
			break;

		case "Rule#5":
			System.out.println("Rule Desc:- " + RuleSetDescription);
			manageRbaConfigPage.getFirstParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter1 + "'])[1]")).click();
			manageRbaConfigPage.getFirstConditionDropdown().click();
			System.out.println("Chechpoint-1 " + Parameter1);
			driver.findElement(By.xpath("(//a[contains(text(),'" + Condition1 + "')])[1]")).click();
			System.out.println("Chechpoint-1 " + Condition1);
			manageRbaConfigPage.getFirstValueTextField().sendKeys(Value1);
			System.out.println("Value1 :- " + Value1);

			// Adding Second 'OR'Condition
			manageRbaConfigPage.getOR_RadiButton().click();
			manageRbaConfigPage.getPlusConditionButton().click();
			generic.explicitWait(3);
			manageRbaConfigPage.getSecondParameterDropdown().click();
			driver.findElement(By.xpath("(//a[text()='" + Parameter2 + "'])[1]")).click();
			System.out.println("Chechpoint-2 " + Parameter2);
			manageRbaConfigPage.getSecondValueTextField().sendKeys(Value2);
			System.out.println("Value2:-" + Value2);
			break;

		}

		// Select Mode of Authentication
		manageRbaConfigPage.getModeOfAuthDropdown().click();
		if (ModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getModeOfAuth_Otp().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getModeOfAuth_Frictionless().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getModeOfAuth_DenyDecline().click();
		}
		// Saving the rule

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)", "");
		generic.explicitWait(2);
		manageRbaConfigPage.getSaveChangesButton().click();

		generic.explicitWait(3);
		String actualMessage = "Rule Set Created Successfully.";
		String expectedMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedMessage:-" + expectedMessage);

		sAssertion.assertEquals(actualMessage, expectedMessage);
		sAssertion.assertAll();

		String ruleSetId = driver.findElement(By.xpath("//div[text()='" + RulesetNameWithNum + "']/parent::div/div[2]"))
				.getText();
		System.out.println("Rule Set Id:-" + ruleSetId);

		// Navigating to Issuer Bin Range
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getIssuerBinRangeConfigLink().click();
		generic.explicitWait(3);

		// Adding Pagination---
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver
					.findElements(By.xpath(
							"(//div[text()='" + IssuerBinRange + "']/following::div/div/div[@data-tip='Edit'])[1]"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i );
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		generic.explicitWait(2);
		System.out.println("Assigning rule to issuer Bin Range");
		/*
		 * action.moveToElement(driver.findElement( By.xpath("(//div[text()='" +
		 * IssuerBinRange + "']/following::div/div/div[@data-tip='Edit'])[1]")));
		 */
		js.executeScript("window.scrollBy(0,-200)", "");

		generic.explicitWait(3);
		driver.findElement(
				By.xpath("(//div[text()='" + IssuerBinRange + "']/following::div/div/div[@data-tip='Edit'])[1]"))
				.click();
		generic.explicitWait(5);

		// js.executeScript("window.scrollBy(0,900)", "");

		action.moveToElement(driver.findElement(By.xpath("//div[text()='Rba Config']"))).perform();

		generic.explicitWait(2);
		driver.findElement(By.xpath(
				"(//div[text()='Rba Config']/following::div[@class='dropdown dropdown--type3 is-active']/div/a)[1]"))
				.click();
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(ruleSetId);
		driver.findElement(By.xpath(
				"//div[text()='Rba Config']/following::div[@class='dropdown dropdown--type3 is-active']/div/following::div[@class='dropdown-menu']/div/div/following::div/label[1]"))
				.click();
		generic.explicitWait(2);
		js.executeScript("window.scrollBy(0,-1000)", "");
		System.out.println("CheckPoint1");
		generic.explicitWait(2);
		driver.findElement(By.xpath("//a[text()='Update']")).click();
		System.out.println("CheckPoint2");
		// Validating success message
		generic.explicitWait(1);
		String actualUpdate = "Successfully Updated Bin And Association";
		String expectedUpdate = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedMessage:-" + expectedUpdate);

		sAssertion.assertEquals(actualUpdate, expectedUpdate);
		sAssertion.assertAll();

		generic.explicitWait(3);
		System.out.println("Rule set is updated with Issuer Bin Range");

	}

	@AfterMethod
	public void logout() {
		LogOutPage logout = new LogOutPage(driver);
		logout.logout();
		System.out.println("Sucessfully Logout");
	}

}

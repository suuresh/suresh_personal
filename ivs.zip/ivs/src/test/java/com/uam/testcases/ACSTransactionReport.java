package com.uam.testcases;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;


public class ACSTransactionReport extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);

	static String cDay = null;
	static String cMonth = null;
	static String nMonth = null;
	static String cYear = null;
	static String cHour = null;
	static String cMinutes = null;
	static String cSeconds = null;

	static String to_cDay = null;
	static String to_cMonth = null;
	static String to_nMonth = null;
	static String to_cYear = null;
	static String to_cHour = null;
	static String to_cMinutes = null;
	static String to_cSeconds = null;

	static String pDay = null;
	static String pMonth = null;
	static String pnMonth = null;
	static String pYear = null;
	static String pHour = null;
	static String pMinutes = null;
	static String pSeconds = null;
	static String pDay_2 = null;
	static String LastDay = null;
	static String prevNmonth = null;

	static String utcDay = null;
	static String utcMonth = null;
	static String utcYear = null;
	static String utcHour = null;
	static String utcMinutes = null;
	static String ucSeconds = null;

	static String to_utcDay = null;
	static String to_utcMonth = null;
	static String to_utcYear = null;
	static String to_utcHour = null;
	static String to_utcMinutes = null;
	static String to_ucSeconds = null;

	boolean flag = true;

	public static String totalAcsTxnReport = null;
	// TODO
	public static String getTransactionType(String transactionType) {
		String txnType = "";
		if(transactionType.contentEquals("ECOM"))
			txnType = "1";
		else if(transactionType.contentEquals("REDIRECTION")) {
			txnType = "10";
		}
		else if(transactionType.contentEquals("BEPG")) {
			txnType = "7";
		}	
		return txnType;
	}

	public static String getTotalNoTxnReport(String schema, String issuerId, String protocalVersion, String transactionType) {

		String NoofTxnReport = "SELECT count(*) FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where issuer_id='" + issuerId + "' and date_time between '" + utcYear + "-" + nMonth
				+ "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "'";
		String strQuery = "";
		if(protocalVersion != "" && !(protocalVersion.equals("1.0.0.0"))  && !(protocalVersion.equals("2.0.0.0")) ) {
			strQuery = "and acs_version='"+protocalVersion+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		if(transactionType != "") {
			strQuery = "";
			strQuery = "and transaction_type='"+getTransactionType(transactionType)+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		System.out.println(NoofTxnReport);
		return NoofTxnReport;
	}

	public static String getTotalNoTxnReportOnSameDate(String schema, String issuerId, String protocalVersion, String transactionType) {

		String NoofTxnReport = "SELECT count(*) FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where issuer_id='" + issuerId + "' and date_time between '" + utcYear + "-" + nMonth + "-" + utcDay
				+ " 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "'";
		
		String strQuery = "";
		if(protocalVersion != "" && !(protocalVersion.equals("1.0.0.0"))  && !(protocalVersion.equals("2.0.0.0"))) {
			strQuery = "and acs_version='"+protocalVersion+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		if(transactionType != "") {
			strQuery = "";
			strQuery = "and transaction_type='"+getTransactionType(transactionType)+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		
		return NoofTxnReport;
	}

	public static String getTotalNoTxnCurrentMonth(String schema, String issuerId, String protocalVersion, String transactionType ) {

		String NoofTxnReportCurrentMonth = "SELECT count(*) FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where issuer_id='" + issuerId + "' and date_time between '" + utcYear + "-" + nMonth
				+ "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "'";
		String strQuery = "";
		if(protocalVersion != "" && !(protocalVersion.equals("1.0.0.0"))  && !(protocalVersion.equals("2.0.0.0")) ) {
			strQuery = "and acs_version='"+protocalVersion+"'";
			NoofTxnReportCurrentMonth = NoofTxnReportCurrentMonth + strQuery;
		}
		if(transactionType != "") {
			strQuery = "";
			strQuery = "and transaction_type='"+getTransactionType(transactionType)+"'";
			NoofTxnReportCurrentMonth = NoofTxnReportCurrentMonth + strQuery;
		}
		return NoofTxnReportCurrentMonth;
	}

	public static String getTotalNoTxnPrevMonth(String schema, String issuerId, String protocalVersion, String transactionType) {

		String NoofTxnReportPrevMonth = "SELECT count(*) FROM " + schema + ".acs_txn_" + utcYear + "" + prevNmonth
				+ " where issuer_id='" + issuerId + "' and date_time between '" + utcYear + "-" + prevNmonth + "-"
				+ pDay_2 + " 00:00' and '" + cYear + "-" + prevNmonth + "-" + LastDay + " 23:59'";
		String strQuery = "";
		if(protocalVersion != "" && !(protocalVersion.equals("1.0.0.0"))  && !(protocalVersion.equals("2.0.0.0")) ) {
			strQuery = "and acs_version='"+protocalVersion+"'";
			NoofTxnReportPrevMonth = NoofTxnReportPrevMonth + strQuery;
		}
		if(transactionType != "") {
			strQuery = "";
			strQuery = "and transaction_type='"+getTransactionType(transactionType)+"'";
			NoofTxnReportPrevMonth = NoofTxnReportPrevMonth + strQuery;
		}
		return NoofTxnReportPrevMonth;
	}

	public static String getTotalNoTxnReportOnDefault(String schema, String issuerId, String protocalVersion, String transactionType) {

		String NoofTxnReport = "SELECT count(*) FROM " + schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where issuer_id='" + issuerId + "' and date_time between '" + utcYear + "-" + nMonth + "-" + utcDay
				+ " " + utcHour + ":" + utcMinutes + "' and '" + to_utcYear + "-" + to_nMonth + "-" + to_utcDay + " "
				+ to_utcHour + ":" + to_utcMinutes + "'";
		String strQuery = "";
		if(protocalVersion != "" && !(protocalVersion.equals("1.0.0.0"))  && !(protocalVersion.equals("2.0.0.0")) ) {
			strQuery = "and acs_version='"+protocalVersion+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		if(transactionType != "") {
			strQuery = "";
			strQuery = "and transaction_type='"+getTransactionType(transactionType)+"'";
			NoofTxnReport = NoofTxnReport + strQuery;
		}
		System.out.println("NoofTxnReport " + NoofTxnReport);
		return NoofTxnReport;
	}
	
	
	

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

	}

	/**
	 * Acs Transaction Download Report
	 * 
	 */
	
	/*
	@DataProvider
	public Object[][] ACSTxnDownloadReport() throws IOException {

		System.out.println("Reading data from excell file AcsTxnDownloadReport");
		return generic.getData(XlFileName, "AcsTxnDownloadReport");
	}

	@Test(dataProvider = "ACSTxnDownloadReport", priority = 1, enabled = true)
	public void ACSTxnDownloadReport(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String CardUnion, String TransactionType, String ReportType, String Schema, String Desc) throws IOException {


		System.out.println("***********Start Test*************");

		System.out.println("cleanFolder");
		File directory = new File(downloadLocation);
		FileUtils.cleanDirectory(directory);

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(Desc);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();
		generic.explicitWait(2);

		// Handling toggle which is permission based

		String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241", "9111", "8171", "8117", "8263",
				"8111", "8235" };
		for (int i = 0; i < bankHasTooggle.length; i++) {
			if (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
				acsTxnPage.getDatePicker().click();
				flag = false;
				break;
			}
		}
		if (flag == true) {
			acsTxnPage.getDatePickerWithoutToggle().click();
		}
		flag = true;
		System.out.println("Flag value:" + flag);
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), "1");
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), "30");
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + cDay);
				}
			}
		}

		generic.explicitWait(5);

		acsTxnPage.getApplyButton().click();
		
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		
		
		// Ptotocol Selection
		acsTxnPage.getProtocolVersionField().click();
		if(ProtocalVersion.contentEquals("1.0.2")) {
			acsTxnPage.getProtocolVersionOneDotO().click();
			acsTxnPage.getProtocolVersionOneDotOSelected().click();
		} else if(ProtocalVersion.contentEquals("2.1.0")) {
			acsTxnPage.getProtocolVersionTwoDotO().click();
			acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		} 
		generic.explicitWait(5);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		
		//For Rupay
		if(CardUnion.contentEquals("Rupay")) {
			// Select Card Union
			acsTxnPage.getCardUnionField().click();			
		}
		
		// Transaction Type Selection
		if(TransactionType.contentEquals("REDIRECTION")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
		} else if(TransactionType.contentEquals("BEPG")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
		} else if(TransactionType.contentEquals("ECOM")) {
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeECOM().click();
		}
		
		acsTxnPage.getFetchReportButton().click();

		generic.explicitWait(10);
		// Fetching values from DB
		totalAcsTxnReport = DBConnection.getValueFromDB(ACSTransactionReport.getTotalNoTxnReport(Schema, IssuerBankId, ProtocalVersion, TransactionType));

		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {

			System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();
			sAssertion.assertEquals(totalAcsTxnReport, "0", "Validating empty DB");
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");

		} else {

			// Select the format to download
			acsTxnPage.getDropDownFormatIcon().click();
			generic.explicitWait(2);
			// driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			List<WebElement> formats = driver.findElements(By.xpath("//label[@class='checkbox__lable']"));
			for (WebElement format : formats) {
				if (format.getText().equalsIgnoreCase(ReportType)) {
					format.click();
					break;
				}
			}

			// Download the report

			acsTxnPage.getDownloadReportButton().click();

			generic.explicitWait(10);

			// verify the file is downloaded or not

			// sAssertion.assertTrue(isFileDownloaded("AcsReport","zip", 10000));
			sAssertion.assertTrue(isFileDownloaded("AcsReport.zip"));
			sAssertion.assertAll();
		}

	}
	*/
	
	public boolean isFileDownloaded(String expectedFileName) {
		boolean fileDownloaded = false;

		File folder = new File(downloadLocation);
		File[] listofFiles = folder.listFiles();
		for (File listofFile : listofFiles) {
			if (listofFile.isFile()) {
				String fileName = listofFile.getName();
				System.out.println("Filename: " + fileName);
				if (fileName.matches(expectedFileName)) {
					fileDownloaded = true;
					break;
				}
			}
		}

		return fileDownloaded;
	}

	/*
	 * Scenario:Validting fetch report,select "1" and current date w.r.t both "From"
	 * and "to" with time 05:30 to current system time Author: Vikash Gupta Date:
	 * 03-05-2-21
	 * 
	 */

	@DataProvider
	public Object[][] ACSTxnReport() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AcsTxnReport");
	}

	@Test(dataProvider = "ACSTxnReport", priority = 1, enabled = true)
	public void ACSTxnReport(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String CardUnion, String TransactionType, String FromDate,
			String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate, String ToMonth,
			String ToYear, String ToHour, String ToMinutes, String Schema, String decs) throws IOException {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		//System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		
		//adminhomepage.getAcsTransactionReportLink().click();
		
		
		
		generic.explicitWait(2);

		// Handling toggle which is permission based
		String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241", "9111", "8171", "8117", "8263",
				"8111", "8235" };
		for (int i = 0; i < bankHasTooggle.length; i++) {
			if (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
				acsTxnPage.getDatePicker().click();
				flag = false;
				break;
			}
		}
		if (flag == true) {
			acsTxnPage.getDatePickerWithoutToggle().click();
		}
		flag = true;
		//System.out.println("Flag value:" + flag);
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							//System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					//System.out.println("Clicked...Day" + cDay);
				}
			}
		}

		
		
		// Fetching values from DB
		totalAcsTxnReport = DBConnection.getValueFromDB(ACSTransactionReport.getTotalNoTxnReport(Schema, IssuerBankId, ProtocalVersion, TransactionType));
		generic.explicitWait(2);
		acsTxnPage.getApplyButton().click();
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		// Protocol Selection
		
		if(ProtocalVersion.contentEquals("1.0.2")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionOneDotO().click();
			acsTxnPage.getProtocolVersionOneDotOSelected().click();
		} else if(ProtocalVersion.contentEquals("2.1.0")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionTwoDotO().click();
			acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		}
		
		generic.explicitWait(5);
		
		//For Rupay
		if(CardUnion.contentEquals("Rupay")) {
			// Select Card Union
			acsTxnPage.getCardUnionField().click();	
			acsTxnPage.getCardUnionRuPay().click();
		}
				
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		
		
		
		// Transaction Type Selection
		if(TransactionType.contentEquals("REDIRECTION")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeRedirection().click();
			
		} else if(TransactionType.contentEquals("BEPG")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeBepg().click();
			
		} else if(TransactionType.contentEquals("ECOM")) {
			js.executeScript("arguments[0].click();", acsTxnPage.getTransactionTypeField());
			//acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeECOM().click();
			
		}
		
		
		
		acsTxnPage.getFetchReportButton().click();

		generic.explicitWait(2);
		
		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {

			//System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();
			sAssertion.assertEquals(totalAcsTxnReport, "0", "Validating empty DB");
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");

		} else {

			String TotalItemCountValue = acsTxnPage.getTotalItemCount().getText().replaceAll("[^0-9]", "");
			System.out.println("TotalItemCountValue:" + TotalItemCountValue);
			sAssertion.assertEquals(totalAcsTxnReport, TotalItemCountValue);
			
			
			// Verify Download
			verifyDownloadReport(".CSV", acsTxnPage, sAssertion);
			verifyDownloadReport(".XLS", acsTxnPage, sAssertion);
			verifyDownloadReport(".TXT", acsTxnPage, sAssertion);
			
			sAssertion.assertAll();
		}

	}
	
	
	private void verifyDownloadReport(String type, AdminACSFetchTxnPage acsTxnPage, SoftAssert  sAssertion) throws IOException {
		
		acsTxnPage.getDropDownFormatIcon().click();
		generic.explicitWait(2);

		List<WebElement> formats = driver.findElements(By.xpath("//label[@class='checkbox__lable']"));
		for (WebElement format : formats) {
			//System.out.println(format.getText());
			if (format.getText().contentEquals(type)) {
				//System.out.println("cleanFolder");
				File directory = new File(downloadLocation);
				FileUtils.cleanDirectory(directory);
				
				format.click();
				generic.explicitWait(2);
				// Download the report
				acsTxnPage.getDownloadReportButton().click();
				generic.explicitWait(5);
				// verify the file is downloaded or not
				sAssertion.assertTrue(isFileDownloaded("AcsReport.zip"));
				generic.explicitWait(5);
				break;
			}
		}
	}

	/*
	 * Scenario:Validting fetch report,select current date on both "From" and "to"
	 * with time 05:30 to current system time Author: Vikash Gupta Date: 03-05-2-21
	 * 
	 */

	@DataProvider
	public Object[][] ACSTxnReportOnSameDate() throws IOException {

		//System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AcsTxnReport");
	}

	@Test(dataProvider = "ACSTxnReportOnSameDate", priority = 1, enabled = true)
	public void ACSTxnReportOnSameDate(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String CardUnion, String TransactionType,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) throws IOException {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		//System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		//System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		//System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		//adminhomepage.getAcsTransactionReportLink().click();
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		generic.explicitWait(2);

		// Handling toggle which is permission based
		String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241", "9111", "8171", "8117", "8263",
				"8111", "8235" };
		for (int i = 0; i < bankHasTooggle.length; i++) {
			if (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
				acsTxnPage.getDatePicker().click();
				flag = false;
				break;
			}
		}
		if (flag == true) {
			acsTxnPage.getDatePickerWithoutToggle().click();
		}
		flag = true;
		//System.out.println("Flag value:" + flag);
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		/*
		 * int trSize = driver .findElements( By.
		 * xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"
		 * )) .size();
		 * 
		 * for (int i = 0; i < trSize; i++) { for (int j = 0; j < 7; j++) { WebElement
		 * dayXpath = driver.findElement(By.xpath(
		 * "//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
		 * + i + "c" + j + "']")); String currentDay = dayXpath.getText(); String attr =
		 * dayXpath.getAttribute("class"); if (currentDay.equalsIgnoreCase(cDay)) { if
		 * (!attr.contains("off ")) { dayXpath.click(); if (cDay.equalsIgnoreCase(cDay))
		 * { driver.findElement(By.xpath(
		 * "//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
		 * + i + "c" + j + "']")) .click(); System.out.println("clicking 01 again"); } }
		 * } else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
		 * if (!attr.contains("off ")) { dayXpath.click(); }
		 * System.out.println("Clicked...Day" + cDay); } } }
		 * 
		 */ 
		generic.explicitWait(2);
		// Fetching values from DB
		totalAcsTxnReport = DBConnection
					.getValueFromDB(ACSTransactionReport.getTotalNoTxnReportOnSameDate(Schema, IssuerBankId, ProtocalVersion, TransactionType));
		
		acsTxnPage.getApplyButton().click();
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		// Protocol Selection
		
		if(ProtocalVersion.contentEquals("1.0.2")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionOneDotO().click();
			acsTxnPage.getProtocolVersionOneDotOSelected().click();
		} else if(ProtocalVersion.contentEquals("2.1.0")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionTwoDotO().click();
			acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		} 
		generic.explicitWait(5);
		
		
		//For Rupay
		if(CardUnion.contentEquals("Rupay")) {
			// Select Card Union
			acsTxnPage.getCardUnionField().click();
			acsTxnPage.getCardUnionRuPay().click();
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		
		// Transaction Type Selection
		if(TransactionType.contentEquals("REDIRECTION")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeRedirection().click();
			
		} else if(TransactionType.contentEquals("BEPG")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeBepg().click();
			
		} else if(TransactionType.contentEquals("ECOM")) {
			
			js.executeScript("arguments[0].click();", acsTxnPage.getTransactionTypeField());
			//acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeECOM().click();
			
		}
		
		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		

		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {
			//System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();
			sAssertion.assertEquals(totalAcsTxnReport, "0", "Validating empty DB");
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");

		} else {

			generic.explicitWait(5);
			String TotalItemCountValue = acsTxnPage.getTotalItemCount().getText().replaceAll("[^0-9]", "");
			System.out.println("TotalItemCountValue: - " + TotalItemCountValue);
			sAssertion.assertEquals(totalAcsTxnReport, TotalItemCountValue);
			
			// Verify Download
			verifyDownloadReport(".CSV", acsTxnPage, sAssertion);
			verifyDownloadReport(".XLS", acsTxnPage, sAssertion);
			verifyDownloadReport(".TXT", acsTxnPage, sAssertion);
			
			sAssertion.assertAll();
		}
	}
	/*
	 * Scenario:Validting fetch report by selecting "From " previous month "to"
	 * current month Author: Vikash Gupta Date: 03-05-2-21
	 * 
	 */

	@DataProvider
	public Object[][] ACSTxnReportOnTwoMonth() throws IOException {

		//System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AcsTxnReport");
	}

	@Test(dataProvider = "ACSTxnReportOnTwoMonth", priority = 1, enabled = true)
	public void ACSTxnReportOnTwoMonth(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String CardUnion, String TransactionType,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) throws IOException {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		String pDateAndTime = FORMATTER.format(cal.getTime());
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);
		int max = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		//System.out.println("max :" + max);
		// current Date and time

		System.out.println("Current dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];
		
		

		// previous Date and time

		System.out.println("pDateAndTime:-" + pDateAndTime);
		String[] pDateTime = pDateAndTime.split("/");
		pYear = pDateTime[0];
		pMonth = pDateTime[1];
		pDay = pDateTime[2];
		pHour = String.format("%01d", Integer.parseInt(pDateTime[3]));
		pMinutes = pDateTime[4];
		pSeconds = pDateTime[5];
		LastDay = Integer.toString(max);

		// UTC time Zone
		//System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		/*
		 * LocalDateTime now = LocalDateTime.now(); nMonth = String.format("%02d",
		 * now.getMonthValue()); System.out.println("nMonth:-" + nMonth);
		 */

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		//System.out.println("nMonth:-" + nMonth);
		LocalDateTime minusOne = now.minusMonths(1);
		prevNmonth = String.format("%02d", minusOne.getMonthValue());
		//System.out.println("prevNmonth :" + prevNmonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		//adminhomepage.getAcsTransactionReportLink().click();
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		generic.explicitWait(2);

		// Handling toggle which is permission based
		String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241", "9111", "8171", "8117", "8263",
				"8111", "8235" };
		for (int i = 0; i < bankHasTooggle.length; i++) {
			if (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
				acsTxnPage.getDatePicker().click();
				flag = false;
				break;
			}
		}
		if (flag == true) {
			acsTxnPage.getDatePickerWithoutToggle().click();
		}
		flag = true;
		//System.out.println("Flag value:" + flag);
		generic.explicitWait(2);
		//System.out.println("pMonth: " + pMonth);
		//System.out.println("pYear: " + pYear);

		// Picking "From" Date and Time
		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), pMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), pYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' left calendar day
		int trSizeLeft = driver
				.findElements(By.xpath("//div[@class='drp-calendar left']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSizeLeft; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar left']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));

				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				//System.out.println("Checkpoint : pDay :" + pDay);

				if (Integer.parseInt(pDay) <= 30 && Integer.parseInt(pDay) >= 12) {
					//System.out.println("Checkpoint2 greather than 12");
					pDay_2 = Integer.toString((Integer.parseInt(cDay) + 1));
					if (currentDay.equalsIgnoreCase(pDay_2)) {
						if (!attr.contains("off ")) {
							dayXpath.click();
							System.out.println("Clicked1");
							break;
						}
					}
				} else {
					System.out.println("Date less than 12"+ Integer.parseInt(cDay));
					pDay_2 = Integer.toString((Integer.parseInt(cDay) + 2));
					//System.out.println("pDay_2:- " + pDay_2);
					//System.out.println("currentDay:- " + currentDay);
					//System.out.println("pDay_2Format :- " + pDay_2.replaceFirst("^0+(?!$)", ""));
					//System.out.println("*********Loop finished*******");
					if (currentDay.equalsIgnoreCase(pDay_2.replaceFirst("^0+(?!$)", "")))
						if (!attr.contains("off ")) {
							dayXpath.click();
							System.out.println("Clicked2");
							break;
						}
				}

			}
		}

		// Code for picking 'to' Right calendar day

		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();
		System.out.println("+++++++++++++++++++++++++++++Right++++++++++++++++++++++++++++++++++");
		
		if (Integer.parseInt(cDay) == 31) {
			for (int i = 0; i < trSize; i++) {
				for (int j = 0; j < 7; j++) {
					WebElement dayXpath = driver.findElement(By.xpath(
							"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
									+ i + "c" + j + "']"));
					String currentDay = dayXpath.getText();
					String attr = dayXpath.getAttribute("class");
					//System.out.println(currentDay+","+cDay+","+attr);
					if (currentDay.equalsIgnoreCase("1")) {
						if (!attr.contains("off")) {
							dayXpath.click();
							System.out.println("Clicked1or2");
							break;
						}
					}					
				}
			}
		}
		
		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				//System.out.println(currentDay+","+cDay+","+attr);
				
				if (attr.contains("today")) {
					dayXpath.click();
					System.out.println("Clicked3");
					break;
				}
				
				
				
				/*
				 * if (Integer.parseInt(cDay) <= 30 && Integer.parseInt(cDay) >= 12)
				 * //System.out.println("Right Calender : greater than 12"); if
				 * (currentDay.equalsIgnoreCase(cDay)) { if (!attr.contains("off ")) {
				 * dayXpath.click(); System.out.println("Clicked3"); break; } } else if
				 * (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
				 * System.out.println("Right calendar ******"); if (!attr.contains("off ")) {
				 * dayXpath.click(); System.out.println("Clicked4"); }
				 * 
				 * }
				 */
			}
		}

		generic.explicitWait(2);

		acsTxnPage.getApplyButton().click();
		
		// Fetching values from DB

		String currentMonth = DBConnection
				.getValueFromDB(ACSTransactionReport.getTotalNoTxnCurrentMonth(Schema, IssuerBankId, ProtocalVersion, TransactionType));

		String prevMonth = "0";
		if(Integer.parseInt(pDay_2) >= 31) {
			System.out.println("Donothing");
		} else {

			prevMonth = DBConnection
					.getValueFromDB(ACSTransactionReport.getTotalNoTxnPrevMonth(Schema, IssuerBankId, ProtocalVersion, TransactionType));
		}
		
		//System.out.println("prevMonth :" + prevMonth);
		int total = Integer.parseInt(currentMonth) + Integer.parseInt(prevMonth);
		totalAcsTxnReport = Integer.toString(total);
		System.out.println("totalAcsTxnReport:" + totalAcsTxnReport);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("arguments[0].click();", acsTxnPage.getAcsAdevanceSearchButton());
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		// Protocol Selection
		
		if(ProtocalVersion.contentEquals("1.0.2")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionOneDotO().click();
			acsTxnPage.getProtocolVersionOneDotOSelected().click();
		} else if(ProtocalVersion.contentEquals("2.1.0")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionTwoDotO().click();
			acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		} 
		generic.explicitWait(5);
		
		
		//For Rupay
		if(CardUnion.contentEquals("Rupay")) {
			// Select Card Union
			acsTxnPage.getCardUnionField().click();
			acsTxnPage.getCardUnionRuPay().click();
		}
		
	
		js.executeScript("window.scrollBy(0,400)", "");
		
		// Transaction Type Selection
		if(TransactionType.contentEquals("REDIRECTION")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeRedirection().click();
			
		} else if(TransactionType.contentEquals("BEPG")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeBepg().click();
			
		} else if(TransactionType.contentEquals("ECOM")) {
			js.executeScript("arguments[0].click();", acsTxnPage.getTransactionTypeField());
			//acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeECOM().click();
			
		}
		
		acsTxnPage.getFetchReportButton().click();

		generic.explicitWait(2);

		
		String TotalItemCountValue = acsTxnPage.getTotalItemCount().getText().replaceAll("[^0-9]", "");
		System.out.println("TotalItemCountValue: - " + TotalItemCountValue);
		sAssertion.assertEquals(totalAcsTxnReport, TotalItemCountValue);
		
		// Verify Download
		verifyDownloadReport(".CSV", acsTxnPage, sAssertion);
		verifyDownloadReport(".XLS", acsTxnPage, sAssertion);
		verifyDownloadReport(".TXT", acsTxnPage, sAssertion);
		
		sAssertion.assertAll();

	}

	/*
	 * Scenario:Validting fetch report by selecting default time Author: Vikash
	 * Gupta Date: 03-05-2-21
	 * 
	 */

	@DataProvider
	public Object[][] ACSTxnReportOnDefaultTime() throws IOException {

		//System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AcsTxnReport");
	}

	@Test(dataProvider = "ACSTxnReportOnDefaultTime", priority = 1, enabled = true)
	public void ACSTxnReportOnDefaultTime(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String CardUnion, String TransactionType,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) 
			throws ParseException, IOException {

		//System.out.println("*******Fetching DB value from the Default time******");

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS TXN Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		//adminhomepage.getAcsTransactionReportLink().click();
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		generic.explicitWait(2);

		// Handling toggle which is permission based
		/*
		 * String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241",
		 * "9111", "8171", "8117", "8263", "8111", "8235" }; for (int i = 0; i <
		 * bankHasTooggle.length; i++) { if
		 * (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
		 * acsTxnPage.getDatePicker().click(); flag = false; break; } } if (flag ==
		 * true) { acsTxnPage.getDatePickerWithoutToggle().click(); } flag = true;
		 * System.out.println("Flag value:" + flag); generic.explicitWait(2);
		 */

		String FromDateInfo = acsTxnPage.getFrom_DateInfoText().getText();
		String ToDateInfo = acsTxnPage.getTo_DateInfoText().getText();
		//System.out.println("FromDateInfo: " + FromDateInfo);
		//System.out.println("ToDateInfo:   " + ToDateInfo);

		// String FromDateInfo="06 May 2021|12:58";
		String from_Month = FromDateInfo.replaceAll("[^a-zA-Z]+", "");
		String from_DateAndYear = FromDateInfo.replaceAll("[a-zA-Z]+", "").replace(" ", "");
		String from_Date = from_DateAndYear.substring(0, 2);
		String from_Year = from_DateAndYear.substring(2, 6);
		String from_Hour = from_DateAndYear.substring(7, 9);
		String from_Min = from_DateAndYear.substring(10, 12);

		String dateMonthTime = from_Year + "/" + from_Month + "/" + from_Date + "/" + from_Hour + "/" + from_Min + "/"
				+ "00";

		// to_date info
		String to_Month = ToDateInfo.replaceAll("[^a-zA-Z]+", "");
		String to_DateAndYear = ToDateInfo.replaceAll("[a-zA-Z]+", "").replace(" ", "");
		String to_Date = to_DateAndYear.substring(0, 2);
		String to_Year = to_DateAndYear.substring(2, 6);
		String to_Hour = to_DateAndYear.substring(7, 9);
		String to_Min = to_DateAndYear.substring(10, 12);

		String to_dateMonthTime = to_Year + "/" + to_Month + "/" + to_Date + "/" + to_Hour + "/" + to_Min + "/" + "00";

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMMM/dd/HH/mm/ss");
		// Date currentDate = new Date();
		Date currentDate = FORMATTER.parse(dateMonthTime);
		String dateAndTime = FORMATTER.format(currentDate);

		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// Utc date from to
		SimpleDateFormat to_FORMATTER = new SimpleDateFormat("yyyy/MMMM/dd/HH/mm/ss");
		// Date currentDate = new Date();
		Date to_currentDate = to_FORMATTER.parse(to_dateMonthTime);
		String to_dateAndTime = to_FORMATTER.format(to_currentDate);

		TimeZone to_utcTimeZone = TimeZone.getTimeZone("UTC");
		to_FORMATTER.setTimeZone(to_utcTimeZone);
		String to_utcTime = to_FORMATTER.format(to_currentDate);

		// current Date and time 'From'

		//System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		//System.out.println("utcTime:    " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		/*
		 * LocalDateTime now = LocalDateTime.now(); nMonth = String.format("%02d",
		 * now.getMonthValue()); System.out.println("nMonth:-" + nMonth);
		 */
		Month utcMon = Month.valueOf(utcMonth.toUpperCase());
		nMonth = String.format("%02d", utcMon.getValue());
		//System.out.println("nMonth:" + nMonth);
		// current Date and time 'to'

		//System.out.println("to_dateAndTime:-" + to_dateAndTime);
		String[] to_dateTime = to_dateAndTime.split("/");
		to_cYear = to_dateTime[0];
		to_cMonth = to_dateTime[1];
		to_cDay = to_dateTime[2];
		to_cHour = String.format("%01d", Integer.parseInt(to_dateTime[3]));
		to_cMinutes = to_dateTime[4];
		to_cSeconds = to_dateTime[5];

		// UTC time Zone
		//System.out.println("to_utcTime:     " + to_utcTime);
		String[] to_utcDateTime = to_utcTime.split("/");
		to_utcYear = to_utcDateTime[0];
		to_utcMonth = to_utcDateTime[1];
		to_utcDay = to_utcDateTime[2];
		to_utcHour = to_utcDateTime[3];
		to_utcMinutes = to_utcDateTime[4];
		to_ucSeconds = to_utcDateTime[5];

		Month to_utcMon = Month.valueOf(to_utcMonth.toUpperCase());
		to_nMonth = String.format("%02d", to_utcMon.getValue());
		//System.out.println("to_nMonth :" + to_nMonth);
		
		// Fetching values from DB
		totalAcsTxnReport = DBConnection
				.getValueFromDB(ACSTransactionReport.getTotalNoTxnReportOnDefault(Schema, IssuerBankId, ProtocalVersion, TransactionType));
		
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		// Protocol Selection
		
		if(ProtocalVersion.contentEquals("1.0.2")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionOneDotO().click();
			acsTxnPage.getProtocolVersionOneDotOSelected().click();
		} else if(ProtocalVersion.contentEquals("2.1.0")) {
			acsTxnPage.getProtocolVersionField().click();
			acsTxnPage.getProtocolVersionTwoDotO().click();
			acsTxnPage.getProtocolVersionTwoDotOSelected().click();
		} 
		generic.explicitWait(5);
		
		
		//For Rupay
		if(CardUnion.contentEquals("Rupay")) {
			// Select Card Union
			acsTxnPage.getCardUnionField().click();
			acsTxnPage.getCardUnionRuPay().click();
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");
		
		// Transaction Type Selection
		if(TransactionType.contentEquals("REDIRECTION")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeRedirection().click();
			
		} else if(TransactionType.contentEquals("BEPG")) {
			// Select Transaction Type
			acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeBepg().click();
			
		} else if(TransactionType.contentEquals("ECOM")) {
			js.executeScript("arguments[0].click();", acsTxnPage.getTransactionTypeField());
			//acsTxnPage.getTransactionTypeField().click();
			acsTxnPage.getTransactionTypeECOM().click();
			
		}

		acsTxnPage.getFetchReportButton().click();
		generic.explicitWait(2);
		
		// handling pop-up
		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {
			//System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();
			sAssertion.assertEquals(totalAcsTxnReport, "0", "Validating empty DB");
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");
		} else {

			//System.out.println("Total Count Box");
			generic.explicitWait(4);
			String TotalItemCountValue = acsTxnPage.getTotalItemCount().getText().replaceAll("[^0-9]", "");
			System.out.println("TotalItemCountValue:" + TotalItemCountValue);
			sAssertion.assertEquals(totalAcsTxnReport, TotalItemCountValue);
			
			// Verify Download
			verifyDownloadReport(".CSV", acsTxnPage, sAssertion);
			verifyDownloadReport(".XLS", acsTxnPage, sAssertion);
			verifyDownloadReport(".TXT", acsTxnPage, sAssertion);
			sAssertion.assertAll();
		}
		
	}

	@DataProvider
	public Object[][] AdvancedACSTxnReport() throws IOException {
		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AdvancedACSTxnReport");
	}
	
	@Test(dataProvider="AdvancedACSTxnReport",priority=1,enabled=true)

	public void AdvancedACSTxnReport(String IssuerBankId, String IssuerBankName, String KeyAlias, String CardNumber,
			String MerchantId, String ACSTransactionId, String DSTransactionId, String AuthenticationFlowType,
			String DeviceChannel, String CardUnion, String CardType, String TransactionStatus, String BINNumber,
			String DataCenter, String RiskScoreRange, String TransactionType, String AmountWithCurrencyExponent,
			String Currency, String ProtocalVersion, String MerchantName, String ErrorCode, String ErrorDescription,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs)
			throws IOException {
		
		System.out.println("****** "+decs);

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		//System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		//adminhomepage.getAcsTransactionReportLink().click();
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		generic.explicitWait(2);

		// Handling toggle which is permission based
		String[] bankHasTooggle = { "8131", "8191", "8116", "8125", "8129", "8241", "9111", "8171", "8117", "8263",
				"8111", "8235" };
		for (int i = 0; i < bankHasTooggle.length; i++) {
			if (bankHasTooggle[i].equalsIgnoreCase(IssuerBankId)) {
				acsTxnPage.getDatePicker().click();
				flag = false;
				break;
			}
		}
		if (flag == true) {
			acsTxnPage.getDatePickerWithoutToggle().click();
		}
		flag = true;
		//System.out.println("Flag value:" + flag);
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							//System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					//System.out.println("Clicked...Day" + cDay);
				}
			}
		}

		
		
		// Prepare the Query
		
		String query = "SELECT count(*) FROM " + Schema + ".acs_txn_" + utcYear + "" + nMonth
				+ " where issuer_id='" + IssuerBankId + "' and date_time between '" + utcYear + "-" + nMonth
				+ "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + cHour + ":" + cMinutes + "'";
		
		
		
		if(CardNumber != "") {
			String cardNumber = generic.getEncryptedCard(CardNumber, KeyAlias);
			query = query + " and acct_number='"+cardNumber+"'";
		}
		
		if(MerchantId != "") {
			query = query + " and merchant_id='"+MerchantId+"'";
		}
		if(ACSTransactionId != "") {
			query = query + " and acs_txn_id='"+ACSTransactionId+"'";
		}
		if(DSTransactionId != "") {
			query = query + " and ds_txn_id='"+DSTransactionId+"'";
		}
		if(AuthenticationFlowType != "") {
			String[] aft = AuthenticationFlowType.split(",");
			query = query + " and auth_flow_type='"+aft[0]+"'";
			for(int i=1;i<aft.length;i++) {
				query = query + " or auth_flow_type='"+aft[i]+"'";
			}
		}
		if(DeviceChannel != "") {
			String [] dc = DeviceChannel.split(",");
			query = query + " and device_channel='"+dc[0].split("-")[1]+"'";
			for(int i=1;i<dc.length;i++) {
				query = query + " or device_channel='"+dc[i].split("-")[1]+"'";
			}
		}
		if(CardUnion != "") {
			String [] cu = CardUnion.split(",");
			query = query + " and card_union='"+cu[0].split("-")[1]+"'";
			for(int i=1;i<cu.length;i++) {
				query = query + " or card_union='"+cu[i].split("-")[1]+"'";
			}
		}
		if(CardType != "") {
			String [] ct = CardType.split(",");
			query = query + " and card_type='"+ct[0].split("-")[1]+"'";
			for(int i=1;i<ct.length;i++) {
				query = query + " or card_type='"+ct[i].split("-")[1]+"'";
			}
		}
		if(TransactionStatus != "") {
			String [] ts = TransactionStatus.split(",");
			query = query + " and txn_status='"+ts[0].split("-")[1]+"'";
			for(int i=1;i<ts.length;i++) {
				query = query + " or txn_status='"+ts[i].split("-")[1]+"'";
			}
		}
		
		//bin_id
		if(BINNumber != "") {
			String [] bid = BINNumber.split(",");
			query = query + " and bin_id='"+bid[0].split("-")[1]+"'";
			for(int i=1;i<bid.length;i++) {
				query = query + " or bin_id='"+bid[i].split("-")[1]+"'";
			}
		}		
		if(DataCenter != "") {
			query = query + " and wibmo_avail_zone='"+DataCenter+"'";
		}		
		//risk_score
		if(RiskScoreRange != "") {
			String[] q = RiskScoreRange.split(",");
			query = query + " and risk_score  between '"+q[0]+"' and '"+q[1]+"'";
		}		
		if(TransactionType != "") {
			String [] tt = TransactionType.split(",");
			query = query + " and transaction_type='"+tt[0].split("-")[1]+"'";
			for(int i=1;i<tt.length;i++) {
				query = query + " or transaction_type='"+tt[i].split("-")[1]+"'";
			}
		}
		
		// txn_amount = Amount (With Currency Exponent)
		if(AmountWithCurrencyExponent != "") {
			String [] ac = AmountWithCurrencyExponent.split(",");
			query = query + " and txn_amount between '"+ac[0]+"' and '"+ac[1]+"'";
		}
		
		//purchase_currency = currency
		if(Currency != "") {
			query = query + " and purchase_currency='"+Currency.split("-")[1]+"'";
		}
		if(ProtocalVersion != "" ) {	
			String [] pv = ProtocalVersion.split(",");
			query = query + " and acs_version='"+pv[0]+"'" ;
			for(int i=1;i<pv.length;i++) {
				query = query + " or acs_version='"+pv[i]+"'" ;
			}
		}
		if(MerchantName != "") {
			query = query + " and merchant_name='"+MerchantName+"'";
		}
		
		if(ErrorCode != "") {
			query = query + " and error_code='"+ErrorCode+"'";
		}
		if(ErrorDescription != "") {
			String [] ed = ErrorDescription.split(",");
			query = query + " and error_code='"+ed[0].split("-")[1]+"'";
			for(int i=1;i<ed.length;i++) {
				query = query + " or error_code='"+ed[i].split("-")[1]+"'";
			}
		}
					
		
		
		System.out.println(query);
		
		
		// Fetching values from DB		
		totalAcsTxnReport = DBConnection.getValueFromDB(query);
		
		
		
		generic.explicitWait(2);
		acsTxnPage.getApplyButton().click();
		
		
		
		
		acsTxnPage.getAcsAdevanceSearchButton().click();
		// Protocol Selection
		
		
		if(CardNumber != "") {
			acsTxnPage.getCardNumberTextField().sendKeys(CardNumber);
		}
		
		if(MerchantId != "") {
			acsTxnPage.getMerchantId().clear();
			acsTxnPage.getMerchantId().sendKeys(MerchantId);
		}
		
		if(ACSTransactionId != "") {
			acsTxnPage.getAcsTxnIDTextField().clear();
			acsTxnPage.getAcsTxnIDTextField().sendKeys(ACSTransactionId);
		}
		
		if(DSTransactionId != "") {
			acsTxnPage.getDSTransactionId().clear();
			acsTxnPage.getDSTransactionId().sendKeys(DSTransactionId);
		}
		
		if(AuthenticationFlowType != "") {
			//name=authFlowType
			acsTxnPage.getAuthFlowType().click();
			List<WebElement> authFlowTypes = driver.findElements(By.xpath("//input[@name='authFlowType']"));
			String[] aft = AuthenticationFlowType.split(",");
			for(int i=0;i<aft.length;i++) {
				for (WebElement authFlowType : authFlowTypes) {
					if (authFlowType.getAttribute("id").equalsIgnoreCase(aft[i])) {
						authFlowType.click();
						break;
					}
				}
			}
		}
		
		if(DeviceChannel != "") {
			acsTxnPage.getDeviceChannelField().click();
			List<WebElement> deviceChanneles = driver.findElements(By.xpath("//input[@name='deviceChannel']"));
			String [] dc = DeviceChannel.split(",");
			for(int i=0;i<dc.length;i++) {
				for (WebElement deviceChannel : deviceChanneles) {
					if (deviceChannel.getAttribute("id").equalsIgnoreCase(dc[i].split("-")[0])) {
						deviceChannel.click();
						break;
					}
				}	
			}
		}
		if(CardUnion != "") {
			acsTxnPage.getCardUnionField().click();
			List<WebElement> cardUnions = driver.findElements(By.xpath("//input[@name='card_union']"));
			String [] cu = CardUnion.split(",");
			for(int i=0;i<cu.length;i++) {
				for (WebElement cardUnion : cardUnions) {
					if (cardUnion.getAttribute("id").equalsIgnoreCase(cu[i].split("-")[0])) {
						cardUnion.click();
						break;
					}
				}	
			}
		}
		
		if(CardType != "") {
			acsTxnPage.getCardTypeField().click();
			List<WebElement> cardTypes = driver.findElements(By.xpath("//input[@name='card_type']"));
			String [] ct = CardType.split(",");
			for(int i=0;i<ct.length;i++) {
				for (WebElement cardType : cardTypes) {
					if (cardType.getAttribute("id").equalsIgnoreCase(ct[i].split("-")[0])) {
						cardType.click();
						break;
					}
				}	
			}
		}
		
		if(TransactionStatus != "") {
			acsTxnPage.getTransactionStatusField().click();
			List<WebElement> transactionStatuses = driver.findElements(By.xpath("//input[@name='transaction_status']"));
			String [] ts = TransactionStatus.split(",");
			for(int i=0;i<ts.length;i++) {
				for (WebElement transactionStatus : transactionStatuses) {
					if (transactionStatus.getAttribute("id").equalsIgnoreCase(ts[i].split("-")[0])) {
						transactionStatus.click();
						break;
					}
				}	
			}
		}
		
		if(BINNumber != "") {
			acsTxnPage.getBinNumberField().click();
			List<WebElement> binNumbers = driver.findElements(By.xpath("//input[@name='bin_number']"));
			String [] bn = BINNumber.split(",");
			for(int i=0;i<bn.length;i++) {
				for (WebElement binNumber : binNumbers) {
					if (binNumber.getAttribute("id").equalsIgnoreCase(bn[i].split("-")[1])) {
						binNumber.click();
						break;
					}
				}	
			}
		}
		
		if(DataCenter != "") {
			acsTxnPage.getDataCenterField().click();
			List<WebElement> dataCenters = driver.findElements(By.xpath("//input[@name='transaction_status']"));
			String [] dc = DataCenter.split(",");
			for(int i=0;i<dc.length;i++) {
				for (WebElement dataCenter : dataCenters) {
					if (dataCenter.getAttribute("id").equalsIgnoreCase(dc[i])) {
						dataCenter.click();
						break;
					}
				}	
			}
		}
		
		if(RiskScoreRange != "") {
			String [] rsr = RiskScoreRange.split(",");
			acsTxnPage.getRiskScoreRangeFrom().sendKeys(rsr[0]);
			acsTxnPage.getRiskScoreRangeTo().sendKeys(rsr[1]);
		}
		if(TransactionType != "") {
			acsTxnPage.getTransactionTypeField().click();
			List<WebElement> txnTypes = driver.findElements(By.xpath("//input[@name='IVStransaction_type']"));
			String [] tt = TransactionType.split(",");
			for(int i=0;i<tt.length;i++) {
				for (WebElement txntype : txnTypes) {
					if (txntype.getAttribute("id").equalsIgnoreCase(tt[i].split("-")[0])) {
						txntype.click();
						break;
					}
				}	
			}
		}
		
		if(AmountWithCurrencyExponent != "") {
			String [] ace = AmountWithCurrencyExponent.split(",");
			acsTxnPage.getAmountRangeFrom().sendKeys(ace[0]);
			acsTxnPage.getAmountRangeTo().sendKeys(ace[1]);
		}
		if(Currency != "") {
			acsTxnPage.getCurrencyField().click();
			List<WebElement> curriencies = driver.findElements(By.xpath("//input[@name='currency']"));
			for (WebElement currency : curriencies) {
				if (currency.getAttribute("id").equalsIgnoreCase(Currency.split("-")[0])) {
					currency.click();
					break;
				}
			}
		}
		
		if(ProtocalVersion != "") {
			acsTxnPage.getProtocolVersionField().click();
			List<WebElement> protocolves = driver.findElements(By.xpath("//input[@name='acsVersion']"));
			String [] pv = ProtocalVersion.split(",");
			for(int i=0;i<pv.length;i++) {
				for (WebElement protocolVersion : protocolves) {
					if (protocolVersion.getAttribute("id").equalsIgnoreCase(pv[i])) {
						protocolVersion.click();
						break;
					}
				}
			}
		}
		
		
		
		if(MerchantName != "") {
			acsTxnPage.getMerchantNameField().sendKeys(MerchantName);	
		}
		if(ErrorCode != "") {
			acsTxnPage.getErrorCodeField().sendKeys(ErrorCode);
		}
		if(ErrorDescription != "") {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)", "");
			acsTxnPage.getErrorDescriptionField().click();
			List<WebElement> errorDescs = driver.findElements(By.xpath("//input[@name='errorDescription']"));
			String [] ed = ErrorDescription.split(",");
			for(int i=0;i<ed.length;i++) {
				for (WebElement errordesc : errorDescs) {
					if (errordesc.getAttribute("id").equalsIgnoreCase(ed[i].split("-")[0])) {
						errordesc.click();
						break;
					}
				}	
			}
			acsTxnPage.getErrorDescriptionField().click();
		}	
						
		generic.explicitWait(5);		
				
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,400)", "");		
		
		acsTxnPage.getFetchReportButton().click();

		generic.explicitWait(2);
		
		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {

			//System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();
			sAssertion.assertEquals(totalAcsTxnReport, "0", "Validating empty DB");
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");

		} else {

			String TotalItemCountValue = acsTxnPage.getTotalItemCount().getText().replaceAll("[^0-9]", "");
			System.out.println("TotalItemCountValue:" + TotalItemCountValue);
			sAssertion.assertEquals(totalAcsTxnReport, TotalItemCountValue);
			
			//System.out.println("Download Report");
			
			// Verify Download
			/*
			 * verifyDownloadReport(".CSV", acsTxnPage, sAssertion);
			 * verifyDownloadReport(".XLS", acsTxnPage, sAssertion);
			 * verifyDownloadReport(".TXT", acsTxnPage, sAssertion);
			 */
			
			sAssertion.assertAll();
		}

	}
}
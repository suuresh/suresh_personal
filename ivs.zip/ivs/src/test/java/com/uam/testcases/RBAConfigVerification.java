package com.uam.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONObject;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.CardEncryptHomePage;
import com.acs.pages.CheckOutPage;
import com.acs.pages.OTPPage;
import com.acs.pages.PgResponsePage;
import com.acs.testcases.ACSInitialSetUp;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminACSRBAPage;
import com.uam.pages.AdminHomePage;

public class RBAConfigVerification extends ACSInitialSetUp{
	
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;
	
	@BeforeMethod
	public void beforeAuthenticationMethod() {
		driver.get(Config.BASE_UAM_URL);
		
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

		
	}
	
	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName,"RBAScript");
	}

	@Test(dataProvider = "DataSet")
	public void rbaConfiguration(String rbascript, String Cardnumber, String Flow, String merchantname, String amount, String currencytype, String acsTxnid) throws Exception {
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminACSRBAPage acsRBAPage = new AdminACSRBAPage(driver);
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		PgResponsePage responsepage = new PgResponsePage(driver);
		OTPPage otp = new OTPPage(driver);
		
		CardEncryptHomePage enNDcryptPage = new CardEncryptHomePage(driver);
		
	//	xpath=//td[@class='available in-range'][contains(text(),'13')]
		
		adminhomepage.getDropDownHeader().click();
	//	adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getRbaLink().click();
		adminhomepage.getRbaconfigurationLink().click();
		acsRBAPage.getRbaScriptTextArea().click();
		acsRBAPage.getRbaScriptClearConfigurationButton().click();
		generic.explicitWait(1);
		acsRBAPage.getRbaScriptTextArea().sendKeys(rbascript);
		acsRBAPage.getRbaScriptSaveConfigurationButton().click();
		generic.explicitWait(3);
//		sAssertion.assertEquals(adminhomepage.getRbaScriptSuccessfullyUpdatedPopUp().getText(), "Successfully Updated");
		
		//opening new tab and initiating transaction
		generic.openNewWindow();
		Set<String> windowids = driver.getWindowHandles();
		Iterator<String> it = windowids.iterator();
		String FirstWindow = it.next();
		String SecondWindow = it.next();
		String ThirdWindow = null;
		driver.switchTo().window(SecondWindow);
		driver.get(Config.DC2_TRANSACTION_URL);
		
		Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
		merchantoptions.selectByVisibleText(merchantname);

		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		checkoutpage.getCurrencyDropDown().click();
		Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
		currencyoptions.selectByVisibleText(currencytype);
		checkoutpage.getCheckOutButton().click();

		generic.explicitWait(1);
	
		
		switch (Flow) {

		case "FrictionLess":
			System.out.println(Flow + "Started");
			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Frictionless");
			System.out.println("First window name:"+FirstWindow);
			System.out.println("2nd window name:"+SecondWindow);
			

			break;


		case "Challenge":
			System.out.println(Flow + "Started");
			generic.explicitWait(3);
			driver.switchTo().frame("foo");
	//		String enCryptedOTP = generic.getencyrptedOTPFromDB();
			String dcryptedjson = null;
			String dcryptedOTPValue = null;
		//	System.out.println("Encrypted OTP Value is :" + enCryptedOTP);
			// driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"n");
			generic.openNewWindow();
			generic.explicitWait(1);

			windowids = driver.getWindowHandles();
		     it = windowids.iterator();
			 FirstWindow = it.next();
			 SecondWindow = it.next();
			 ThirdWindow = it.next();
			driver.switchTo().window(ThirdWindow);
			driver.get("file:///" + Config.DC2_CARD_ENCRYPT_PATH);
			enNDcryptPage.getEnNDcryptTextField().clear();
		//	enNDcryptPage.getEnNDcryptTextField().sendKeys(enCryptedOTP);
			enNDcryptPage.getSelectDrpDwon().click();
			

			Select options = new Select(enNDcryptPage.getSelectDrpDwon());
			// options.selectByValue("decrypt");
			options.selectByIndex(1);
			enNDcryptPage.getSubmitButton().click();
			dcryptedjson = enNDcryptPage.getEnOrDcryptResult().getText();
			driver.close();
			System.out.println("dcrypted OTP Value: " + dcryptedjson);

			JSONObject obj = new JSONObject(dcryptedjson);
			dcryptedOTPValue = (String) obj.get("Result");

			System.out.println("dcryptedOTPValue:" + dcryptedOTPValue);

			// Switch back to original browser (first window)
			driver.switchTo().window(SecondWindow);
			driver.switchTo().frame("foo");
			otp.getOtpField().sendKeys(dcryptedOTPValue);
			generic.explicitWait(1);

			otp.getOtpSubmitButton().click();
			
			sAssertion.assertEquals(responsepage.getTransactionStatusValue().getText(), "Y");
			sAssertion.assertEquals(responsepage.getEciValue().getText(), "05");
			sAssertion.assertEquals(responsepage.getErrorCodeValue().getText(), "000");
			sAssertion.assertEquals(responsepage.getRreqStatusValue().getText(), "Y");
			sAssertion.assertEquals(responsepage.getAresStatusValue().getText(), "Challenge");
			System.out.println("First window name:"+FirstWindow);
			System.out.println("2nd window name:"+SecondWindow);
			System.out.println("3rd window name:"+ThirdWindow);
	//		driver.close();
	//		driver.switchTo().window(FirstWindow);

			break;
		}
		
		
		generic.explicitWait(1);
		driver.close();
		driver.switchTo().window(FirstWindow);
		generic.explicitWait(3);
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsTransactionReportLink().click();
		adminhomepage.getAcsFetchTransactionReportLink().click();
		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
	//	acsTxnPage.getAcsTxnIDTextField().sendKeys(generic.getACSTxnIDFromDB());
		acsTxnPage.getFetchReportButton().click();
		
		sAssertion.assertEquals(acsTxnPage.getTxnRecordMerchantName().getText(), merchantname);
		sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnAmount().getText(), amount+" "+currencytype );
		sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText(), Flow);
		sAssertion.assertAll();
		
	//	FirstWindow = null;
	//	SecondWindow = null;
		
		
		
		/*//	adminhomepage.getDatePickerButton().click();
		
		generic.explicitWait(2);
		Actions act = new Actions(driver);

		act.moveToElement(adminhomepage.getTodayActiveStartDateCurrentMonth()).click().build().perform();
		generic.dynamicXpathForCurentDate();
		adminhomepage.getTodayActiveStartDateCurrentMonth().click();
		adminhomepage.getTodayActiveStartDateCurrentMonth().click();
		System.out.println("Date picker starting");
		generic.explicitWait(3);
		Actions actions = new Actions(driver);
		actions.moveToElement(adminhomepage.getFromDate());
	//	actions.click();
		actions.sendKeys("00:00");
		actions.sendKeys(Keys.ENTER);
		
	//	adminhomepage.getTodayActiveStartDateCurrentMonth().click();
	//	adminhomepage.getTodayActiveStartDateCurrentMonth().sendKeys("00:00");
		actions.build().perform();
	//	adminhomepage.getTodayActiveStartDateCurrentMonth().click();
		generic.dynamicXpathForCurentDate();
		generic.dynamicXpathForCurentDate();
		System.out.println("Date picker clicked");
	//	adminhomepage.getHoursSelect().click();
		
		Select houroptions = new Select(adminhomepage.getHoursSelect());
		houroptions.selectByValue("0");
		
		Select minutesoptions = new Select(adminhomepage.getMinutesSelect());
		minutesoptions.selectByValue("59");
		
		
	//	adminhomepage.getApplyButton();
	//	System.out.println("applay button clicked");
		adminhomepage.getFetchReportButton().click();
		*/
	}
	
	
	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
	//	driver.quit();

	}


}
	
	

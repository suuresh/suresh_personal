package com.uam.testcases;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AlertReportPage;
import com.uam.pages.LoginPage;

public class AlertReport extends ACSInitialSetUp {

	static String cDay = null;
	static String cMonth = null;
	static String nMonth = null;
	static String cYear = null;
	static String cHour = null;
	static String cMinutes = null;
	static String cSeconds = null;

	static String utcDay = null;
	static String utcMonth = null;
	static String utcYear = null;
	static String utcHour = null;
	static String utcMinutes = null;
	static String ucSeconds = null;

	public static String alertTotalSms = null;
	public static String alertTotalEmail = null;

	/*
	 * public static String totalNoOfSms(String schema) {
	 * 
	 * String alertTotalSms = "SELECT count(*) FROM " + schema +
	 * ".sent_alert_details_" + utcYear + "" + nMonth + " where date_time between '"
	 * + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-" +
	 * cDay + " " + utcHour + ":" + utcMinutes + "'  and alert_type_id=1"; return
	 * alertTotalSms; }
	 */
	public static String totalNoOfSms(String schema, String BankId) {

		String alertTotalSms = "SELECT count(*) FROM " + schema + ".sent_alert_details_" + utcYear + "" + nMonth
				+ " AS s, acs_txn_" + utcYear + "" + nMonth + " AS a WHERE s.bank_id = " + BankId
				+ " AND s.date_time BETWEEN '" + utcYear + "-" + nMonth + "-01 00:00' AND '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "'  AND s.request_id = a.acs_txn_id AND alert_type_id=1";
		return alertTotalSms;
	}

	/*
	 * SELECT count(*) FROM sent_alert_details_202102 AS s, acs_txn_202102 AS a
	 * WHERE s.bank_id = 8503 AND s.date_time BETWEEN '2021-02-01 00:01' AND
	 * '2021-02-17 15:09' AND s.request_id = a.acs_txn_id AND alert_type_id=2;
	 */

	/*
	 * public static String totalNoOfEmail(String schema) {
	 * 
	 * String alertTotalEmail = "SELECT count(*) FROM " + schema +
	 * ".sent_alert_details_" + utcYear + "" + nMonth + " where date_time between '"
	 * + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-" +
	 * cDay + " " + utcHour + ":" + utcMinutes + "'  and alert_type_id=2 "; return
	 * alertTotalEmail; }
	 */
	
	public static String totalNoOfEmail(String schema, String BankId) {
		String alertTotalEmail = "SELECT count(*) FROM sent_alert_details_" + utcYear + "" + nMonth + " AS s, acs_txn_"
				+ utcYear + "" + nMonth + " AS a WHERE s.bank_id = " + BankId + " AND s.date_time BETWEEN '" + utcYear
				+ "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":"
				+ utcMinutes + "'  AND s.request_id = a.acs_txn_id AND alert_type_id=2";
		return alertTotalEmail;
	}

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] AlertReportVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}
	
/*	
   Scenario: 
	*/
	@Test(dataProvider = "AlertReportVerification", enabled = true, priority = 1)
	public void AlertReportVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String Channel, String Schema, String desc) {

		System.out.println("=======Alert Report Verifivation=======");

		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		NewSimulatorCheckOutPage checkoutpage2 = new NewSimulatorCheckOutPage(driver);
		NewSimulatorOTPPage otp2 = new NewSimulatorOTPPage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		String currentURL2 = null;
		LoginPage lp = new LoginPage(driver);
		// LogOutPage logout = new LogOutPage(driver);

		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);

			MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
			MPIOTPPage otp = new MPIOTPPage(driver);

			String currentURL = null;
			invocationCount++;

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage.getCardNumberField().clear();
			checkoutpage.getCardNumberField().sendKeys(Cardnumber);

			generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

			checkoutpage.getCardExpiryField().clear();
			checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			checkoutpage.getCardCVVField().clear();
			checkoutpage.getCardCVVField().sendKeys("111");

			checkoutpage.getQuantityField().clear();
			checkoutpage.getQuantityField().sendKeys("1");

			checkoutpage.getPurchaseAmountField().clear();
			checkoutpage.getPurchaseAmountField().sendKeys(amount);

			generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
			// putting try catch block to handle pop-up
			try {

				checkoutpage.getSubmitButton().click();
				generic.explicitWait(5);
				System.out.println("Clicked on Checkout button");

				// For Karnataka Bank
				if (IssuerBankId.equalsIgnoreCase("8131")) {
					driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
					generic.explicitWait(8);
				}

				/*
				 * Getting ACSTcnId from Pareq Date-28-07-2020
				 */

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);

				switch (Flow) {

				case "Challenge":
					log.info(Flow + "Started");
					generic.explicitWait(2);
					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);
					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);
					otp.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);
					if (TemplateType.equalsIgnoreCase("Rocker")) {
						otp.getRkrotpSubmitButton().click();
					} else {
						otp.getTmlotpSubmitButton().click();
						generic.explicitWait(2);
					}

					break;
				}
			} catch (Exception e) {
				System.out.println("Handling unexpected popup");
				/*
				 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
				 * + alert.getText()); alert.accept();
				 */
				ErrorCollector.addVerificationFailure(e);
			}

			// driver.close();

			// Verify Hard block in Admin portal

		} else if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
			driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
			System.out.println("Merchant Name : " + merchantname);
			Select merchantoptions = new Select(checkoutpage2.getMerchantIdDropDown());
			merchantoptions.selectByVisibleText(merchantname);

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage2.getCardNumberField().clear();
			checkoutpage2.getCardNumberField().sendKeys(Cardnumber);

			checkoutpage2.getCardExpiryField().clear();
			checkoutpage2.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			System.out.println("Amout : " + amount);
			checkoutpage2.getPurchaseAmountField().clear();
			checkoutpage2.getPurchaseAmountField().sendKeys(amount);

			System.out.println("Currency : " + currencytype);
			checkoutpage2.getCurrencyDropDown().click();
			Select currencyoptions = new Select(checkoutpage2.getCurrencyDropDown());
			currencyoptions.selectByVisibleText(currencytype);

			System.out.println("Acquirer Bank Id : " + AccquirerBankId);
			checkoutpage2.getAcquirerIDField().clear();
			checkoutpage2.getAcquirerIDField().sendKeys(AccquirerBankId);
			System.out.println("Protocal Version : " + ProtocalVersion);

			// putting try catch block to handle popup
			try {
				String versionCheckUrl = checkoutpage2.getVersionCheckURLFeild().getAttribute("value");
				System.out.println("Version check url from simulator : " + versionCheckUrl);
				String arr[] = versionCheckUrl.split("pVrq/");
				System.out.println("Splitter version Check url is : " + arr[0]);
				String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
				System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
				checkoutpage2.getVersionCheckURLFeild().clear();
				checkoutpage2.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
				checkoutpage2.getSubmitButton().click();

				System.out.println("Clicked on Checkout button");

				switch (Flow) {

				case "Challenge":
					log.info(Flow + "Started");
					// generic.explicitWait(3);
					if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
						// generic.explicitWait(3);
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						// generic.explicitWait(2);
					} else {
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
						// document.getElementByName('acctId').value").toString();
						// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
						System.out.println("Clicked on Checkout button");

						/*
						 * Getting ACSTcnId from Pareq Date-28-07-2020
						 */

						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						System.out.println("Pareq:-" + paReq);
						String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
						// System.out.println("tesdDecode:-" + tesdDecode);
						String arr1[] = tesdDecode.split("&");
						String testEncodedPaReq = arr1[0];
						String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
						System.out.println("testDecodedPareq:-" + testDecodedPareq);
						acsTxnId = generic.getValueFromXml(testDecodedPareq);
						System.out.println("acsTxnId:-" + acsTxnId);
						generic.explicitWait(2);
					}

					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);

					otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

					otp2.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);

					otp2.getOtpSubmitButton().click();

					break;

				}
			} catch (UnhandledAlertException u) {
				System.out.println("Handling unexpected popup");

				Alert alert = driver.switchTo().alert();
				System.out.println("Type of alert: " + alert.getText());
				alert.accept();

				ErrorCollector.addVerificationFailure(u);
			} catch (Exception e) {
				System.out.println("Handling unexpected popup" + e);

			}
		}
		driver.get(Config.BASE_UAM_URL);
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// selecting date and fetching report
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);
		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null")) {
			System.out.println("Acs txn id is null ");
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);
		}

		acsTxnPage.getFetchReportButton().click();
		System.out.println("Clicked on Fetch Report button");
		generic.explicitWait(5);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		generic.explicitWait(2);

		String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
		String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);

		if (Channel.equalsIgnoreCase("Both")) {
			// validating card number
			List<WebElement> cardNumWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[2]"));
			for (WebElement cardNumber : cardNumWebElement) {
				sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
						cardNumber.getText());
			}
			// validating channel
			List<WebElement> channelWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[7]"));
			for (int i = 0; i < 2; i++) {
				if (i == 0) {
					String channelType = channelWebElement.get(i).getText();
					switch (channelType) {
					case "SMS":
						sAssertion.assertEquals(channelWebElement.get(i).getText(), "SMS");
						break;

					case "Email":
						sAssertion.assertEquals(channelWebElement.get(i).getText(), "Email");
						break;
					}
				}

			}

			// validating Mobile Number
			List<WebElement> mobileWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[8]"));
			for (WebElement mobileNumber : mobileWebElement) {
				sAssertion.assertEquals(Mobile, mobileNumber.getText());
			}
			// Validating Email-id
			List<WebElement> emailWebElement = driver
					.findElements(By.xpath("//div[@class='flex-table__body']/div/div[10]"));
			for (WebElement emailId : emailWebElement) {
				sAssertion.assertEquals(Email, emailId.getText());
			}
		} else if (Channel.equalsIgnoreCase("SMS")) {
			sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
					aReport.getAlertChannelTypeText().getText());
			sAssertion.assertEquals(Channel, aReport.getAlertChannelTypeText().getText());
			sAssertion.assertEquals(Mobile, aReport.getAlertMobileNumberText().getText());
			sAssertion.assertEquals(Email, aReport.getAlertEmailText().getText());
			sAssertion.assertEquals("Y", aReport.getAlertTransactionStatusText().getText());

		}

		else if (Channel.equalsIgnoreCase("Email")) {
			sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
					aReport.getAlertChannelTypeText().getText());
			sAssertion.assertEquals(Channel, aReport.getAlertChannelTypeText().getText());
			sAssertion.assertEquals(Mobile, aReport.getAlertMobileNumberText().getText());
			sAssertion.assertEquals(Email, aReport.getAlertEmailText().getText());
			sAssertion.assertEquals("Y", aReport.getAlertTransactionStatusText().getText());

		}

		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] channelTypeSmsVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "channelTypeSmsVerification", enabled = true, priority = 2)
	public void channelTypeSmsVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String Channel, String Schema, String desc) throws IOException {
		System.out.println("=======Channel Type filter Verifivation=======");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription("Channel Type filter Verifivation");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// Select date and time
		/*
		 * acsTxnPage.getAcsCalenderIcon().click();
		 * acsTxnPage.getAcsLeftHoursSelect().click(); Select acsLeftHoursOptions = new
		 * Select(acsTxnPage.getAcsLeftHoursSelect());
		 * acsLeftHoursOptions.selectByValue("0"); acsTxnPage.getApplyButton().click();
		 */
		acsTxnPage.getAcsCalenderIcon().click();
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), "5");
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), "31");
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + cDay);
				}
			}
		}
		aReport.getAlertApplyButton().click();
		generic.explicitWait(10);

		// Advance search
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertSelectChannelDropdown().click();
		aReport.getAlertSelectChannelSmsDropdownlist().click();

		aReport.getAlertFetchReportButton().click();

		// validating channel type as sms
		List<WebElement> channelWebElement = driver
				.findElements(By.xpath("//div[@class='flex-table__body']/div/div[7]"));
		for (WebElement channelFilter : channelWebElement) {
			sAssertion.assertEquals(channelFilter.getText(), "SMS");
		}

		// Fetching values from DB
		String schemaquery = "use "+Schema+"; " ;
		//DBConnection.getValueFromDB(schemaquery);
		//alertTotalSms = DBConnection.getValueFromDB(AlertReport.totalNoOfSms(Schema, IssuerBankId));
		alertTotalSms = DBConnection.getValueFromDataBase(schemaquery, AlertReport.totalNoOfSms(Schema, IssuerBankId));
		
		// Download Report
		
		File directory = new File(downloadLocation);
		FileUtils.cleanDirectory(directory);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", aReport.getAlertDownloadReportButton());
		
		//aReport.getAlertDownloadReportButton().click();
		generic.explicitWait(5);
		// verify the file is downloaded or not
		sAssertion.assertTrue(isFileDownloaded("AlertsReport.zip"));
		generic.explicitWait(5);
		
		String alertTotalNoOfSmsUIValue = aReport.getAlertTotalCountText().getText();
		int value = Integer.parseInt(alertTotalNoOfSmsUIValue.replaceAll("[^0-9]", ""));
		sAssertion.assertEquals(alertTotalSms, String.valueOf(value));
		
		
		
		
		
		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] channelTypeEmailVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "channelTypeEmailVerification", enabled = true, priority = 3)
	public void channelTypeEmailVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String Channel, String Schema, String desc) throws IOException {
		System.out.println("=======Channel Type filter Verifivation=======");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription("Channel Type filter Verifivation");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// Select date and time
		/*
		 * acsTxnPage.getAcsCalenderIcon().click();
		 * acsTxnPage.getAcsLeftHoursSelect().click(); Select acsLeftHoursOptions = new
		 * Select(acsTxnPage.getAcsLeftHoursSelect());
		 * acsLeftHoursOptions.selectByValue("0"); acsTxnPage.getApplyButton().click();
		 */
		acsTxnPage.getAcsCalenderIcon().click();
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), "5");
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), "31");
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + cDay);
				}
			}
		}
		aReport.getAlertApplyButton().click();
		generic.explicitWait(10);

		// Advance search
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertSelectChannelDropdown().click();
		aReport.getAlertSelectChannelEmailDropdownList().click();

		aReport.getAlertFetchReportButton().click();

		// validating channel type as Email
		List<WebElement> channelWebElement = driver
				.findElements(By.xpath("//div[@class='flex-table__body']/div/div[7]"));
		for (WebElement channelEmailFilter : channelWebElement) {
			sAssertion.assertEquals(channelEmailFilter.getText(), "Email");
		}
		// Fetching values from DB
		String schemaquery = "use "+Schema+"; " ;
		//alertTotalEmail = DBConnection.getValueFromDB(AlertReport.totalNoOfEmail(Schema, IssuerBankId));
		alertTotalEmail = DBConnection.getValueFromDataBase(schemaquery, AlertReport.totalNoOfEmail(Schema, IssuerBankId));
		
		// Download Report
		
		File directory = new File(downloadLocation);
		FileUtils.cleanDirectory(directory);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", aReport.getAlertDownloadReportButton());
		
		//aReport.getAlertDownloadReportButton().click();
		generic.explicitWait(5);
		// verify the file is downloaded or not
		sAssertion.assertTrue(isFileDownloaded("AlertsReport.zip"));
		generic.explicitWait(5);
		
		String alertTotalNoOfEmailUIValue = aReport.getAlertTotalCountText().getText();
		System.out.println("alertTotalNoOfEmailUIValue: - " + alertTotalNoOfEmailUIValue);
		System.out.println();
		sAssertion.assertEquals(alertTotalEmail, alertTotalNoOfEmailUIValue.replaceAll("[^0-9]", ""));
		
		
		
		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] mobileFilterVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "mobileFilterVerification", enabled = true, priority = 4)
	public void mobileFilterVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String Channel, String Schema, String desc) {
		System.out.println("=======Mobile Filter Verifivation=======");
		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// Select date and time
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		// Advance search for Mobile number
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertMobileNumberTextField().sendKeys(Mobile);
		aReport.getAlertFetchReportButton().click();

		// validating mobile column
		List<WebElement> mobileWebElement = driver
				.findElements(By.xpath("//div[@class='flex-table__body']/div/div[8]"));
		for (WebElement mobile : mobileWebElement) {
			sAssertion.assertEquals(mobile.getText(), Mobile);
		}
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] cardNumberVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	//@Test(dataProvider = "cardNumberVerification", enabled = true, priority = 5)
	public void cardNumberVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String currencytype, String AccquirerBankId, String Mobile,
			String InvalidMobile, String InvalidEventId, String Email, String Channel, String Schema, String desc) {
		System.out.println("=======Mobile Filter Verifivation=======");
		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
		String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		// Advance search for Mobile number
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertMobileNumberTextField().sendKeys(Mobile);
		aReport.getAlertFetchReportButton().click();

		// validating mobile column
		List<WebElement> cardNumberWebElement = driver
				.findElements(By.xpath("//div[@class='flex-table__body']/div/div[2]"));
		for (WebElement cardNumber : cardNumberWebElement) {
			sAssertion.assertEquals(firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber,
					cardNumber.getText());
		}
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] fieldVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "fieldVerification", enabled = true, priority = 6)
	public void fieldVerification(String IssuerBankId, String IssuerBankName, String TemplateType, String Cardnumber,
			String ProtocalVersion, String Flow, String merchantId, String merchantname, String amount,
			String CardUnionType, String currencytype, String AccquirerBankId, String Mobile, String InvalidMobile,
			String InvalidEventId, String Email, String Channel, String Schema, String desc) {
		System.out.println("=======Field  Verifivation=======");
		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		// AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();
		boolean downloadReport = aReport.getAlertDownloadReportButton().isDisplayed();
		boolean downloadReset = aReport.getAlertResetButton().isDisplayed();

		sAssertion.assertEquals(Boolean.toString(downloadReport), "true");
		sAssertion.assertEquals(Boolean.toString(downloadReset), "true");
		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] invalidMobileNumber() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "invalidMobileNumber", enabled = true, priority = 7)
	public void invalidMobileNumber(String IssuerBankId, String IssuerBankName, String TemplateType, String Cardnumber,
			String ProtocalVersion, String Flow, String merchantId, String merchantname, String amount,
			String CardUnionType, String currencytype, String AccquirerBankId, String Mobile, String InvalidMobile,
			String InvalidEventId, String Email, String Channel, String Schema, String desc) {
		System.out.println("=======Invalid Mobile Number Verifivation=======");
		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// Select date and time
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		// Advance search for Mobile number
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertMobileNumberTextField().sendKeys(InvalidMobile);
		aReport.getAlertFetchReportButton().click();
		generic.explicitWait(3);

		// validating mobile column
		String errorMsg = "Sorry. No data is available for the date and time range specified.";
		sAssertion.assertEquals(aReport.getAlertPopupErrorMsg().getText(), errorMsg);
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] invalidEventId() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AlertReport");
	}

	@Test(dataProvider = "invalidEventId", enabled = true, priority = 8)
	public void invalidEventId(String IssuerBankId, String IssuerBankName, String TemplateType, String Cardnumber,
			String ProtocalVersion, String Flow, String merchantId, String merchantname, String amount,
			String CardUnionType, String currencytype, String AccquirerBankId, String Mobile, String InvalidMobile,
			String InvalidEventId, String Email, String Channel, String Schema, String desc) {
		System.out.println("=======invalidEventId Verifivation=======");
		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AlertReportPage aReport = new AlertReportPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		// Navigating to Alert Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		aReport.getAlertReportSideLink().click();

		// Select date and time
		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		// Advance search for Mobile number
		aReport.getAlertAdvanceSerchPlusButton().click();
		aReport.getAlertEventIdTextField().sendKeys(InvalidEventId);
		aReport.getAlertFetchReportButton().click();
		generic.explicitWait(3);

		// validating mobile column
		String errorMsg = "Sorry. No data is available for the date and time range specified.";
		sAssertion.assertEquals(aReport.getAlertPopupErrorMsg().getText(), errorMsg);
		sAssertion.assertAll();

		sAssertion.assertAll();

	}
	
	public boolean isFileDownloaded(String expectedFileName) {
		boolean fileDownloaded = false;

		File folder = new File(downloadLocation);
		File[] listofFiles = folder.listFiles();
		for (File listofFile : listofFiles) {
			if (listofFile.isFile()) {
				String fileName = listofFile.getName();
				System.out.println("Filename: " + fileName);
				if (fileName.matches(expectedFileName)) {
					fileDownloaded = true;
					break;
				}
			}
		}

		return fileDownloaded;
	}

}

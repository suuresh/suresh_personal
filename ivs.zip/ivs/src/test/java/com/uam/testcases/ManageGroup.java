package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.ManageBlockedCardPage;
import com.uam.pages.ManageGroupsPage;
import com.uam.pages.ManageUsersPage;


public class ManageGroup extends ACSInitialSetUp {

	int invocationCount = 1;
	public static String Randomgroupname;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateGroup");
	}

	@Test(dataProvider = "DataSet", priority = 1)
	public void createGroup(String BankId, String BankName, String Groupname, String product, String acsTrnxReport, String acsMDDReport, String acsRba,
			String acsCardblock, String acsDashboard, String acsCardHolder, String acsAlertReport,
			String threedsTrnxReport, String threedsDashboard, String threedsRbaconfig, String threedsAcquirer,
			String threedsmaker, String threedsAcquirerBin, String uamMnguser, String uamMngBank, String uamMngGrp,
			String uamAudit) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription("Creating Group and validating the same");
		invocationCount++;

		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		// adminhomepage.getManageBankLink().click();
		adminhomepage.getManageGroupsLink().click();

		// Click on Create Group plus button
		mnggrouppage.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		// generating random group name to avoid duplicates

		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RandomNum = "" + randomPIN;
		Randomgroupname = "AutoGroup" + RandomNum;
		System.out.println("Group name is " + Randomgroupname);
		mnggrouppage.getGroupNameTextField().sendKeys(Randomgroupname);
		generic.writingToExcel(XlFileName, "CreateGroup", "GroupName", invocationCount, Randomgroupname);

		// mnggrouppage.getGroupNameTextField().sendKeys(Groupname);
		mnggrouppage.getGroupProductsSelectDropDown().click();

		/************ Adding permissions to ACS product group *****************/

		if (product.equalsIgnoreCase("ACS")) {

			mnggrouppage.getGroupProductACSRadioButton().click();
			generic.explicitWait(2);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,200)");

			if (acsTrnxReport.equalsIgnoreCase("View")) {
				mnggrouppage.getACSTrnxReportViewCheckBox().click();
				System.out.println(" Cliked View");
				generic.explicitWait(2);
			} else if (acsTrnxReport.equalsIgnoreCase("View_Clear")) {
				mnggrouppage.getACSTransactionReportViewClearCheckBox().click();
				System.out.println("view clear clicked");
				generic.explicitWait(2);
			}

			generic.explicitWait(2);

			// ACS MDD report permission
			if (acsMDDReport.equalsIgnoreCase("View")) {
				mnggrouppage.getACSMddReportViewCheckBox().click();
				System.out.println("MDD view clicked");
				generic.explicitWait(2);
			}

			// ACS RBA config permission
			if (acsRba.equalsIgnoreCase("View")) {
				mnggrouppage.getACSRbaViewCheckBox().click();
				System.out.println("RBA view clicked");
				generic.explicitWait(2);
			} else if (acsRba.equalsIgnoreCase("Manage_default")) {
				mnggrouppage.getACSRBAConfigManageDefaultCheckBox().click();
				System.out.println("RBA manage default clicked");
				generic.explicitWait(2);
			}

			// Manage block card permission
			if (acsCardblock.equalsIgnoreCase("View")) {
				mnggrouppage.getACSMangeBlockCardViewCheckBox().click();
				System.out.println("Manage block view clicked");
				generic.explicitWait(2);
			} else if (acsCardblock.equalsIgnoreCase("Manage")) {
				mnggrouppage.getACSManageBlockCardManageCheckBox().click();
				System.out.println("Manage block Manage clicked");
				generic.explicitWait(2);
			}

			// ACS Dashboard view permission
			if (acsDashboard.equalsIgnoreCase("View")) {
				mnggrouppage.getACSDashboardViewCheckBox().click();
				System.out.println("ACSdashboard view clicked");
				generic.explicitWait(2);
			}

			// ACS Card holder detail permission
			if (acsCardHolder.equalsIgnoreCase("View")) {
				mnggrouppage.getACSCardholderViewCheckBox().click();
				System.out.println("Cardholder view clicked");
				generic.explicitWait(2);
			} else if (acsCardHolder.equalsIgnoreCase("Manage")) {
				mnggrouppage.getACSManageHolderManage().click();
				System.out.println("Cardholder manage clicked");
				generic.explicitWait(2);
			}

			if (acsAlertReport.equalsIgnoreCase("View")) {
				mnggrouppage.getACSAlertViewCheckBox().click();
				System.out.println("Alert view clicked");
				generic.explicitWait(2);
			}

			// Clicking on create group button
			js.executeScript("window.scrollBy(0,-1000)");
			mnggrouppage.getGroupCreateButton().click();
			generic.explicitWait(2);
			mnggrouppage.getListPerPageDropDown().click();
			mnggrouppage.getList30PerPageRadioButton().click();
			mnggrouppage.getSeacrhByGroupName().sendKeys(Randomgroupname);

			// Pagination
			int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver
						.findElements(
								By.xpath("//div[text()='" + Randomgroupname + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			generic.explicitWait(2);
			// Assertion to verify group is created for ACS product
			sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Randomgroupname,
					"GroupName created is not matching");
			sAssertion.assertEquals(mnggrouppage.getListedProductName().getText(), product,
					"Product created is not matching");
			sAssertion.assertEquals(mnggrouppage.getStatus().getText(), "Active", "Status is NOT Active");
			sAssertion.assertAll();

		} /* End of ACS permissions */

		/************ Adding permissions to 3DS product group *****************/
		else if (product.equalsIgnoreCase("3DS")) {
			System.out.println("Welcome to 3ds permissions");

			mnggrouppage.getGroupProduct3DSRadioButton().click();
			generic.explicitWait(2);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,200)");

			// 3dss transaction view
			if (threedsTrnxReport.equalsIgnoreCase("View")) {
				mnggrouppage.getThreedsTrnxfView().click();
				generic.explicitWait(2);
			}

			// 3dss dashboard view
			if (threedsDashboard.equalsIgnoreCase("View")) {
				mnggrouppage.getThreedsDashboardfView().click();
				generic.explicitWait(2);
			}

			// 3DSS rba config view and manage
			if (threedsRbaconfig.equalsIgnoreCase("View")) {
				mnggrouppage.getThreedsRbaView().click();
				generic.explicitWait(2);

			} else if (threedsRbaconfig.equalsIgnoreCase("manage")) {
				mnggrouppage.getThreedsRbaManage().click();
				generic.explicitWait(2);
			}

			// 3dss Acquirer config
			if (threedsAcquirer.equalsIgnoreCase("view")) {
				mnggrouppage.getThreedsacquirerView().click();
			}

			// 3dss maker checker view
			if (threedsmaker.equalsIgnoreCase("view")) {
				mnggrouppage.getThreedsMakerCheckerView().click();
				generic.explicitWait(2);
			}

			// 3dss acquirer BIN
			if (threedsAcquirerBin.equalsIgnoreCase("view")) {
				mnggrouppage.getThreedsAcquirerBinView().click();
				generic.explicitWait(2);
			} else if (threedsAcquirerBin.equalsIgnoreCase("Manage_default")) {
				mnggrouppage.getThreedsAcquirerBINManage().click();
				generic.explicitWait(2);
			}

			// Clicking on create group button
			js.executeScript("window.scrollBy(0,-1000)");
			mnggrouppage.getGroupCreateButton().click();
			generic.explicitWait(2);
			mnggrouppage.getListPerPageDropDown().click();
			mnggrouppage.getList30PerPageRadioButton().click();
			mnggrouppage.getSeacrhByGroupName().sendKeys(Randomgroupname);

			// Pagination
			int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver
						.findElements(
								By.xpath("//div[text()='" + Randomgroupname + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			generic.explicitWait(2);
			// Assertion to verify group is created for 3DS product

			sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Randomgroupname,
					"GroupName created is not matching");
			sAssertion.assertEquals(mnggrouppage.getListedProductName().getText(), product,
					"Product created is not matching");
			sAssertion.assertEquals(mnggrouppage.getStatus().getText(), "Active", "Status is NOT Active");
			sAssertion.assertAll();

		} /* End of 3DS permissions */

		/************ Adding permissions to UAM product group *****************/
		else if (product.equalsIgnoreCase("UAM")) {
			System.out.println("Welcome to UAM permission");

			mnggrouppage.getGroupProductUAMRadioButton().click();
			generic.explicitWait(2);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,200)");

			// UAM --- Manage user permission
			if (uamMnguser.equalsIgnoreCase("View")) {
				mnggrouppage.getUAMMngUserView().click();
				generic.explicitWait(2);
			} else if (uamMnguser.equalsIgnoreCase("Manage")) {
				mnggrouppage.getUAMMngUserManage().click();
				generic.explicitWait(2);
			} else if (uamMnguser.equalsIgnoreCase("Manage_default")) {
				mnggrouppage.getUAMMngUserManageDefault().click();
				generic.explicitWait(2);
			} else if (uamMnguser.equalsIgnoreCase("Manage_maker")) {
				mnggrouppage.getUAMMngUserManageMaker().click();
				generic.explicitWait(2);
			} else if (uamMnguser.equalsIgnoreCase("Manage_checker")) {
				mnggrouppage.getUAMMngUserManageChecker().click();
				generic.explicitWait(2);
			}

			// UAM --- Manage Bank permission
			if (uamMngBank.equalsIgnoreCase("View")) {
				mnggrouppage.getUAMMngBankView().click();
				generic.explicitWait(2);
			} else if (uamMngBank.equalsIgnoreCase("Manage")) {
				mnggrouppage.getUAMMngBanksManage().click();
				generic.explicitWait(2);
			} else if (uamMngBank.equalsIgnoreCase("Manage_default")) {
				mnggrouppage.getUAMMngBanksManageDefault().click();
				generic.explicitWait(2);
			} else if (uamMngBank.equalsIgnoreCase("Manage_maker")) {
				mnggrouppage.getUAMMngBanksManageMaker().click();
				generic.explicitWait(2);
			} else if (uamMngBank.equalsIgnoreCase("Manage_checker")) {
				mnggrouppage.getUAMMngBanksManageChecker().click();
				generic.explicitWait(2);
			}

			// UAM --- Manage Groups permission
			if (uamMngGrp.equalsIgnoreCase("View")) {
				mnggrouppage.getUAMMngGrpsView().click();
				generic.explicitWait(2);
			} else if (uamMngGrp.equalsIgnoreCase("Manage")) {
				mnggrouppage.getUAMMnggroupsManage().click();
				generic.explicitWait(2);
			} else if (uamMngGrp.equalsIgnoreCase("Manage_default")) {
				mnggrouppage.getUAMMnggroupsManageDefault().click();
				generic.explicitWait(2);
			} else if (uamMngGrp.equalsIgnoreCase("Manage_maker")) {
				mnggrouppage.getUAMMnggroupsManageMaker().click();
				generic.explicitWait(2);
			} else if (uamMngGrp.equalsIgnoreCase("Manage_checker")) {
				mnggrouppage.getUAMMnggroupsManageChecker().click();
				generic.explicitWait(2);
			}

			// UAM --- Audit permission
			if (uamAudit.equalsIgnoreCase("View")) {
				mnggrouppage.getUAMAuditView().click();
				generic.explicitWait(2);
			}

			// Clicking on create group button
			js.executeScript("window.scrollBy(0,-1000)");
			mnggrouppage.getGroupCreateButton().click();
			generic.explicitWait(2);
			mnggrouppage.getListPerPageDropDown().click();
			mnggrouppage.getList30PerPageRadioButton().click();
			mnggrouppage.getSeacrhByGroupName().sendKeys(Randomgroupname);

			// Pagination
			int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver
						.findElements(
								By.xpath("//div[text()='" + Randomgroupname + "']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			generic.explicitWait(2);
			// Assertion to verify group is created for 3DS product

			sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Randomgroupname,
					"GroupName created is not matching");
			sAssertion.assertEquals(mnggrouppage.getListedProductName().getText(), product,
					"Product created is not matching");
			sAssertion.assertEquals(mnggrouppage.getStatus().getText(), "Active", "Status is NOT Active");
			sAssertion.assertAll();

		} /* End of UAM permissions */

	}
	
	@DataProvider
	public Object[][] assigneUsersDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateGroup");
	}

	@Test(dataProvider = "assigneUsersDataSet", priority = 2)
	public void assigneUsers(String BankId, String BankName, String Groupname, String product, String acsTrnxReport, String acsMDDReport, String acsRba,
			String acsCardblock, String acsDashboard, String acsCardHolder, String acsAlertReport,
			String threedsTrnxReport, String threedsDashboard, String threedsRbaconfig, String threedsAcquirer,
			String threedsmaker, String threedsAcquirerBin, String uamMnguser, String uamMngBank, String uamMngGrp,
			String uamAudit) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageGroupsLink().click();

		generic.explicitWait(2);

		mnggrouppage.getListPerPageDropDown().click();
		mnggrouppage.getList30PerPageRadioButton().click();
		mnggrouppage.getSeacrhByGroupName().sendKeys(Groupname);

		// Pagination
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver
					.findElements(
							By.xpath("//div[text()='" + Groupname + "']/following::div[@data-tip='Assign Users']"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}
		mnggrouppage.getAssignUsersToGroup().click();
		mnggrouppage.getAssignUsersToGroupSearchField().sendKeys(Config.DCS_UAM_ADMIN_MAKER_USER_NAME);
		mnggrouppage.getAssignUsersCheckBox().click();
		mnggrouppage.getAssignUsersButton().click();

		generic.explicitWait(3);
	} /* End of assigne users testcase */

	@DataProvider
	public Object[][] makerAndCheckerDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateGroup");
	}

	@Test(dataProvider = "makerAndCheckerDataSet", priority = 3)
	public void makerCheckerVerification(String BankId, String BankName, String Groupname, String product,
			String acsTrnxReport, String acsMDDReport, String acsRba, String acsCardblock, String acsDashboard,
			String acsCardHolder, String acsAlertReport, String threedsTrnxReport, String threedsDashboard,
			String threedsRbaconfig, String threedsAcquirer, String threedsmaker, String threedsAcquirerBin,
			String uamMnguser, String uamMngBank, String uamMngGrp, String uamAudit) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		ManageUsersPage manageuser = new ManageUsersPage(driver);
		SoftAssert sAssertion = new SoftAssert();
		Boolean YesElementpresent ;
		logout.logout();
		loginPage.login(Config.DCS_UAM_ADMIN_MAKER_USER_NAME, Config.DCS_UAM_ADMIN_MAKER_PASSWD);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + BankName);
		switch (product) {

		case "ACS":
			adminhomepage.getSideBarLinkACS().click();
			generic.explicitWait(2);
			if (acsTrnxReport.equalsIgnoreCase("View_clear")) {
				
				adminhomepage.getAcsReportsAndDashboard().click();
				generic.explicitWait(2);
				adminhomepage.getAcsTransactionReportLink().click();
				System.out.println("Clicked on Transactions Report Link");
				generic.explicitWait(2);
				acsTxnPage.getAcsCalenderIcon().click();
				acsTxnPage.getAcsLeftHoursSelect().click();
				Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
				acsLeftHoursOptions.selectByValue("0");
				acsTxnPage.getApplyButton().click();

				acsTxnPage.getFetchReportButton().click();
				generic.explicitWait(2);
				System.out.println("Clicked on Fetch Report button");
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,300)", "");
				sAssertion.assertFalse(acsTxnPage.getTxnRecordCardNumber().getText().contains("XXXXX"), "Card number is not in clear formate");
			
			}
			
			if(acsCardblock.equalsIgnoreCase("Manage")) {
				adminhomepage.getSideBarLinkACS().click();
				adminhomepage.getOperationsLink().click();
				generic.explicitWait(2);
				adminhomepage.getManageBlockedCardsLink().click();
				
				YesElementpresent = driver.findElements(By.xpath("//a[text()='Block Card']")).size() > 0;
				sAssertion.assertTrue(YesElementpresent, "Block Card Button is not Present");
			}
			break;
			
		case "3DSS":
			adminhomepage.getSideBarLink3DSS().click();
			System.out.println("3DSS is out of scope, will take up later");
			
			break;
			
		case "UAM":
			
			generic.explicitWait(2);
			if(uamMnguser.equalsIgnoreCase("View")) {
				adminhomepage.getSideBarLinkUAM().click();
				adminhomepage.getManageUsersLink().click();
				generic.explicitWait(2);
				YesElementpresent = driver.findElements(By.xpath("//a[contains(text(),'Create User')]")).size() > 0;
				sAssertion.assertFalse(YesElementpresent, "Add user Button is not Present");
			}
			
			if (uamMngGrp.equalsIgnoreCase("manage_default")) {
				adminhomepage.getSideBarLinkUAM().click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,-1000)");
				adminhomepage.getManageGroupsLink().click();
				//mnggrouppage.getGroupCreateButton().click();
				YesElementpresent = driver.findElements(By.xpath("//a[contains(text(),'Create Group')]")).size() > 0;
				sAssertion.assertTrue(YesElementpresent, "Create Group Button is not Present");
				
			}
			
			break;
		}
		sAssertion.assertAll();
		generic.explicitWait(3);
	} /* End of assigne users testcase */


	@DataProvider
	public Object[][] EditDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateGroup");
	}

	@Test(dataProvider = "EditDataSet", priority =4 )
	public void editgroup(String BankId, String BankName, String Groupname, String product, String acsTrnxReport, String acsMDDReport, String acsRba,
			String acsCardblock, String acsDashboard, String acsCardHolder, String acsAlertReport,
			String threedsTrnxReport, String threedsDashboard, String threedsRbaconfig, String threedsAcquirer,
			String threedsmaker, String threedsAcquirerBin, String uamMnguser, String uamMngBank, String uamMngGrp,
			String uamAudit) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageGroupsLink().click();

		generic.explicitWait(2);

		mnggrouppage.getListPerPageDropDown().click();
		mnggrouppage.getList30PerPageRadioButton().click();
		mnggrouppage.getSeacrhByGroupName().sendKeys(Groupname);

		// Pagination
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("//div[text()='" + Groupname + "']/following::div[@data-tip='Edit']"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		/****************** Editing the groups created *******************/
		if (mnggrouppage.getListedGroupName().getText().equals(Groupname)) {
			System.out.println("Edit the group");
			mnggrouppage.getEditGroups().click();
			generic.explicitWait(2);
			mnggrouppage.getGroupNameTextEditField().clear();
			mnggrouppage.getGroupNameTextEditField().sendKeys(Groupname + "edit");
			System.out.println("edited the group is " + Groupname + "edit");

			mnggrouppage.getGroupEditSavesButton().click();
			generic.explicitWait(2);

			mnggrouppage.getListPerPageDropDown().click();
			mnggrouppage.getList30PerPageRadioButton().click();
			mnggrouppage.getSeacrhByGroupName().sendKeys(Groupname + "edit");

			// Pagination
			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver
						.findElements(By
								.xpath("//div[text()='" + Groupname + "\"+edit+\"']/following::div[@data-tip='Edit']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}

			sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Groupname + "edit",
					"GroupName created is not matching");
			sAssertion.assertAll();

		}

		else {
			System.out.println("Group no avilable for edit");
		}

	} /* End of editgroups testcase */


	@DataProvider
	public Object[][] DeleteDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateGroup");
	}

	@Test(dataProvider = "DeleteDataSet", priority = 5)
	public void deleteGroup(String BankId, String BankName, String Groupname, String product, String acsTrnxReport, String acsMDDReport, String acsRba,
			String acsCardblock, String acsDashboard, String acsCardHolder, String acsAlertReport,
			String threedsTrnxReport, String threedsDashboard, String threedsRbaconfig, String threedsAcquirer,
			String threedsmaker, String threedsAcquirerBin, String uamMnguser, String uamMngBank, String uamMngGrp,
			String uamAudit) {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageGroupsLink().click();

		generic.explicitWait(2);

		mnggrouppage.getListPerPageDropDown().click();
		mnggrouppage.getList30PerPageRadioButton().click();
		mnggrouppage.getSeacrhByGroupName().sendKeys(Groupname + "edit");

		// Pagination
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver
					.findElements(
							By.xpath("//div[text()='" + Groupname + "\"+edit+\"']/following::div[@data-tip='Edit']"))
					.size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		/****************** Deleting the groups created *******************/
		if (mnggrouppage.getListedGroupName().getText().equals(Groupname + "edit")) {
			System.out.println("Edit the group");
			mnggrouppage.getDeleteGroups().click();
			generic.explicitWait(2);

			generic.checkAlertDisplayed();
			generic.dismissAlertPopup();

			System.out.println("Clicked cancel from alert popup");
			sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Groupname + "edit",
					"User deleted by clicking cancel, which is not correct");
			sAssertion.assertAll();

			generic.explicitWait(2);

			mnggrouppage.getDeleteGroups().click();
			generic.explicitWait(2);
			generic.checkAlertDisplayed();
			generic.acceptAlertPopup();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-500)");

			System.out.println("Click confirmed from alert popup");

			if (driver
					.findElements(By.xpath("(//div[text()='" + Groupname
							+ "\"+edit+\"']/following::div[@data-id='tooltip']/following::div/div/div[1])[1]"))
					.size() > 0) {
				System.out.println("Webelement Exist");

				sAssertion.assertEquals(mnggrouppage.getListedGroupName().getText(), Groupname + "edit");
				sAssertion.assertAll();

			} else {
				sAssertion.assertTrue(true);
				sAssertion.assertAll();
				System.out.println("User gets deleted...");

			}
		}

		else {
			System.out.println("Group not present to delete");
		}

	}

	@Test(priority = 0)
	public void validationMsg() {

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageGroupsPage mnggrouppage = new ManageGroupsPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageGroupsLink().click();

		generic.explicitWait(2);
		mnggrouppage.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		/* Clicking create groups without mandatory values */

		String expectedGropname = "Group Name is a required property";
		String expectedProdname = "Products is a required property";
		String expectedGropnamelesschar = "GroupName should NOT be shorter than 8 characters";

		mnggrouppage.getGroupCreateButton().click();
		generic.explicitWait(2);

		System.out.println("expected groupname is " + mnggrouppage.getGroupname().getText());
		System.out.println("expected product is" + mnggrouppage.getProductname().getText());

		sAssertion.assertEquals(mnggrouppage.getGroupname().getText() + " is a required property", expectedGropname,
				"Group name Error message is not present/proper");
		sAssertion.assertAll();
		sAssertion.assertEquals(mnggrouppage.getProductname().getText() + " is a required property", expectedProdname,
				"Product name Error message is not present/proper");
		sAssertion.assertAll();

		System.out.println("Validation complete with nothing entered");

		/* Clicking create groups without Product name values */
		mnggrouppage.getGroupCancelButton().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		mnggrouppage.getGroupNameTextField().sendKeys("AutoGroup7989");

		mnggrouppage.getGroupCreateButton().click();
		generic.explicitWait(3);

		sAssertion.assertEquals(mnggrouppage.getProductname().getText() + " is a required property", expectedProdname,
				"Product name Error message is not present/proper");
		sAssertion.assertAll();
		System.out.println("Validation complete with Product NOT entered");

		/* Clicking create groups without group name values */

		mnggrouppage.getGroupCancelButton().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		mnggrouppage.getGroupProductsSelectDropDown().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupProductACSRadioButton().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupCreateButton().click();
		generic.explicitWait(3);

		sAssertion.assertEquals(mnggrouppage.getGroupname().getText() + " is a required property", expectedGropname,
				"Group name Error message is not present/proper");
		sAssertion.assertAll();

		System.out.println("Validation complete with groupname NOT entered");

		/* Clicking create groups with group name having less than 8 character values */

		mnggrouppage.getGroupCancelButton().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupCreatePlusButton().click();
		generic.explicitWait(2);

		mnggrouppage.getGroupNameTextField().sendKeys("Auto1");

		mnggrouppage.getGroupProductsSelectDropDown().click();
		generic.explicitWait(2);
		mnggrouppage.getGroupProductACSRadioButton().click();
		generic.explicitWait(2);

		mnggrouppage.getGroupCreateButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(mnggrouppage.getGroupnamelesschar().getText(), expectedGropnamelesschar,
				" Group name with less than 8 character Error message is not present/proper");
		sAssertion.assertAll();
		System.out.println("Validation complete with groupname less than 8 character entered");

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();

	}

}

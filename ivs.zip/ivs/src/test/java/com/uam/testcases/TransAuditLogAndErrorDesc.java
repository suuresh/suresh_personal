package com.uam.testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class TransAuditLogAndErrorDesc extends ACSInitialSetUp {

	// Error desc
	public static final String OtpPageTimeOut = "OTP page Timed out";
	public static final String OtpPageCancelled = "User cancelled transaction in OTP page";
	public static final String OtpPageBlockCard = "Invalid credentials. Card blocked temporarily";
	public static final String OtpPageBlockCardPermanently = "Invalid credentials. Card blocked permanently";
	public static final String OtpPageBlockedCard = "Card blocked at ACS";
	public static final String OtpPageUnregisterdCard = "Cardholder data not available with ACS";
	public static final String OtpPageCard = "Customer closed the browser";
	public static final String OtpExpiry = "Customer closed the browser";
	public static final String switchedUnregCard = "Cardholder data not available with bank switch";
	public static final String binInactive = "BIN Range inactive";
	public static final String invalidCard = "Cardholder data in invalid format";
	public static final String otpPageCloseBrowser = "Customer closed the browser";
	public static final String blockPageCloseBrowser = "Customer closed browser in CustomerCare page";
	public static final String custCareCloseBrowser = "Customer closed browser in Block page";
	public static final String clickContactYourBranch = "User clicked customer care link in OTP Page";

	// Transaction AuditLogs 1.0 for customer Journey
	public static final String alertOtpReponse1dot0 = "OTP generated label=Y";
	public static final String transactionStatus1dot0 = "I~TX_STATUS=Y";
	public static final String resendStatus1dot0 = "Resend OTP label=SUCCESS";
	public static final String transactionCancelStatus1dot0 = "I~TX_STATUS=N";
	public static final String transactionBlockStatus1dot0 = "I~TX_STATUS=N";
	public static final String transactionCustBlockedStatus1dot0 = "I~CUSTINFO:STATUS=blocked:DBHIT";
	public static final String transactionBlockedStatus1dot0 = "I~TX_STATUS=N";
	public static final String failedCustStatus1dot0 = "I~CUSTINFO:STATUS=active:DBHIT:DATA_NOTFOUND";
	public static final String transactionFailedStatus1dot0 = "I~TX_STATUS=N";
	public static final String transactionPageExpiryStatus1dot0 = "I~TX_STATUS=N";
	
	
	// Transaction AuditLogs 1.0 for Technical information Journey
		public static final String auditTechInfoOtpPage1dot0 = "T~OTP_PAGE=";
		public static final String auditTechInfoBlockPage1dot0 = "T~BLOCKED_PAGE=";
		public static final String auditTechInfoCustPage1dot0 = "T~CUST_CARE=";
		
	// Transaction AuditLogs 2.0
	public static final String customerApiResponse2dot0 = "Customer API service response=SUCCESS";
	public static final String otpAlertApiResponse2dot0 = "Otp alert api response=SUCCESS";

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, ACSTxn1_0SheetName);
	}

	@Test(dataProvider = "DataSet")
	public void adminErrorVerification(String IssuerBankId, String IssuerBankName, String Cardnumber,
			String ProtocalVersion, String Flow, String merchantId, String merchantname, String amount,
			String CardUnionType, String acsTxnId, String CavvOrAvv, String RiskengineClientID, String RiskScore,
			String RiskSuggestion, String decs) throws Exception {

		ArrayList<String> auditLogList = new ArrayList<String>();
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);
		// driver.findElement(By.xpath("//span[text()='" + IssuerBankName + " Bank" +
		// "']")).click();
		driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);

		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();
		System.out.println("Clicked on Transactions Report Link");
		System.out.println("Flow is : " + Flow);

		acsTxnPage.getAcsCalenderIcon().click();
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);

		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null")) {
			System.out.println("Acs txn id is null ");
		} else {
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);
		}

		acsTxnPage.getFetchReportButton().click();
		System.out.println("Clicked on Fetch Report button");
		generic.explicitWait(4);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'flex-table__body')]//div[1]//div[3]")));

		acsTxnPage.getTxnFirstRecordInTheList().click();
		System.out.println("Clicked on displayed record to go to details report");

		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[span[text()='Card Number']]/div/span")));

		// Validating error code

		generic.explicitWait(2);

		switch (Flow) {

		case "FrictionLess":

			generic.explicitWait(2);
			// String challengeText = acsTxnPage.getErrorDescText().getText();
			if (driver.findElements(By.xpath("//span[@class='err_desc']")).size() >= 1) {
				System.out.println("There should not be any error for frictionless");
				sAssertion.assertEquals("Error", "No Error");
			}

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			acsTxnPage.getAuditLogsTechInfoPlusButton().click();
			List<WebElement> custJourney = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP alert response 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionStatus1dot0), "Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				// sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp
				// Alert response 2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "Frictionless: auditTechInfoOtpPage1dot0");
			}

			break;

		case "Challenge":

			generic.explicitWait(2);
			// String challengeText = acsTxnPage.getErrorDescText().getText();
			if (driver.findElements(By.xpath("//span[@class='err_desc']")).size() >= 1) {
				System.out.println("There should not be any error");
				sAssertion.assertEquals("Error", "No Error");
			}

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney1 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney1) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP alert response 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionStatus1dot0), "Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "Challenge: auditTechInfoOtpPage1dot0");
			}

			break;

		case "Canceled":

			generic.explicitWait(3);
			String canceledText = acsTxnPage.getErrorDescText().getText();
			System.out.println("canceledText:- " + canceledText);
			sAssertion.assertEquals(OtpPageCancelled, canceledText);

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney2 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney2) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(resendStatus1dot0), "Resend status 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionCancelStatus1dot0),
						"Transaction cancel Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "Canceled: auditTechInfoOtpPage1dot0");
			}

			break;

		case "BlockCard":

			generic.explicitWait(3);
			String blockCardText = acsTxnPage.getErrorDescText().getText();
			System.out.println("blockCardText:-" + blockCardText);
			//
			if (blockCardText.contains("temporarily")) {
				System.out.println("card temporarily blocked");
				sAssertion.assertEquals(OtpPageBlockCard, blockCardText);
			} else {
				System.out.println("card Permanently blocked");
				sAssertion.assertEquals(OtpPageBlockCardPermanently, blockCardText);
			}

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney3 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney3) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP Generated 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionBlockStatus1dot0),
						"Transaction Block Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "BlockPage: auditTechInfoOtpPage1dot0");
			}

			break;

		case "Blocked":

			generic.explicitWait(3);
			String blockedCardText = acsTxnPage.getErrorDescText().getText();
			System.out.println("blockedCardText:-" + blockedCardText);
			sAssertion.assertEquals(OtpPageBlockedCard, blockedCardText);
			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney4 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney4) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(transactionCustBlockedStatus1dot0),
						"Cust Blocked status 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionBlockedStatus1dot0),
						"Transaction Blocked Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoBlockPage1dot0), "Blocked: auditTechInfoOtpPage1dot0");
			}

			break;

		case "Failed":

			generic.explicitWait(3);
			String unregisteredCardText = acsTxnPage.getErrorDescText().getText();
			sAssertion.assertEquals(OtpPageUnregisterdCard, unregisteredCardText);

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney5 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney5) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(failedCustStatus1dot0), "Failed customer info  1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionFailedStatus1dot0),
						"Failed Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoCustPage1dot0), "Failed: auditTechInfoOtpPage1dot0");
			}

			break;
		case "OtpPage":

			generic.explicitWait(3);
			String otpPageText = acsTxnPage.getErrorDescText().getText();
			sAssertion.assertEquals(OtpPageCard, otpPageText);

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney6 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney6) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP alert response 1.0");
				// sAssertion.assertTrue(auditLogList.contains(transactionStatus1dot0),
				// "Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "OTP Page: auditTechInfoOtpPage1dot0");
			}

			break;

		case "InActiveBin":

			generic.explicitWait(3);
			String InActiveBinText = acsTxnPage.getErrorDescText().getText();
			System.out.println("InActiveBinText:- " + InActiveBinText);
			sAssertion.assertEquals(binInactive, InActiveBinText);

			break;

		case "otpCloseBrowser":

			generic.explicitWait(3);
			String CloseBrowserText = acsTxnPage.getErrorDescText().getText();
			System.out.println("CloseBrowserText:- " + CloseBrowserText);
			sAssertion.assertEquals(otpPageCloseBrowser, CloseBrowserText);

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney8 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney8) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0),
						"OTP alert response otpCloseBrowser 1.0");
				// sAssertion.assertTrue(auditLogList.contains(transactionStatus1dot0),
				// "Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "Close Browser: auditTechInfoOtpPage1dot0");
			}

			break;

		case "OTPExpiry":

			generic.explicitWait(3);
			String OtpExpiryText = acsTxnPage.getErrorDescText().getText();
			System.out.println("OtpExpiryText:- " + OtpExpiryText);
			sAssertion.assertEquals(OtpExpiry, OtpExpiryText);

			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney9 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney9) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP alert response otpExpiry 1.0");
				// sAssertion.assertTrue(auditLogList.contains(transactionStatus1dot0),
				// "Transaction Status 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "OTP Expiry: auditTechInfoOtpPage1dot0");
			}

			break;
		case "PageExpiry":

			generic.explicitWait(3);
			String OtpPageExpiryText = acsTxnPage.getErrorDescText().getText();
			System.out.println("OtpPageExpiryText:- " + OtpPageExpiryText);
			sAssertion.assertEquals(OtpPageTimeOut, OtpPageExpiryText);
			// Verifying Transaction Audit logs
			generic.explicitWait(3);
			acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			generic.explicitWait(1);
			acsTxnPage.getTransactionAuditLogs().click();
			List<WebElement> custJourney10 = driver
					.findElements(By.xpath("//th[contains(text(),'CUSTOMER JOURNEY')]/../../following::tbody/tr/td"));
			for (WebElement auditLogs : custJourney10) {

				auditLogList.add(auditLogs.getText());
			}
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				sAssertion.assertTrue(auditLogList.contains(alertOtpReponse1dot0), "OTP alert response PageExpiry 1.0");
				sAssertion.assertTrue(auditLogList.contains(transactionPageExpiryStatus1dot0),
						"Transaction Status PageExpiry 1.0");

			} else {
				System.out.println("Assert for 2.0 protocol");
				sAssertion.assertTrue(auditLogList.contains(customerApiResponse2dot0), "Customer Api response 2.0");
				sAssertion.assertTrue(auditLogList.contains(otpAlertApiResponse2dot0), "Otp Alert response  2.0");
				sAssertion.assertTrue(auditLogList.contains(auditTechInfoOtpPage1dot0), "Page Exipry: auditTechInfoOtpPage1dot0");
			}

			break;

		case "custCareCloseBrowser":

			generic.explicitWait(3);
			String custCareCloseBrowserText = acsTxnPage.getErrorDescText().getText();
			System.out.println("custCareCloseBrowserText:- " + custCareCloseBrowserText);
			sAssertion.assertEquals(custCareCloseBrowser, custCareCloseBrowserText);

			break;

		case "InvalidCard":

			generic.explicitWait(3);
			String InvalidText = acsTxnPage.getErrorDescText().getText();
			System.out.println("InvalidText:- " + InvalidText);
			sAssertion.assertEquals(invalidCard, InvalidText);

			break;

		case "ContactYourBranch":

			generic.explicitWait(3);
			String ContactYourBranchText = acsTxnPage.getErrorDescText().getText();
			System.out.println("ContactYourBranchText:- " + ContactYourBranchText);
			sAssertion.assertEquals(clickContactYourBranch, ContactYourBranchText);

			break;

		}

		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}

}

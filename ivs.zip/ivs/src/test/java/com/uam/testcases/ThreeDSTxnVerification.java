package com.uam.testcases;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.Admin3DSSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class ThreeDSTxnVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	public static String currentdate = LocalDate.now().toString();
	public static String yearMonth = currentdate.substring(0, 4) + currentdate.substring(5, 7);

	public static String ThreeDSMerchantId(String IssuerBankId, String ThreedsTxnId) {

		String MerchanId = "SELECT merchant_txn_id FROM acs2qadcs_3dss_txn_" + IssuerBankId + ".3ds_server_txn_"
				+ yearMonth + " where 3ds_server_txn_id ='" + ThreedsTxnId + "';";

		return MerchanId;
	}

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, ThreeDSSTxn2_0SheetName);
	}

	@Test(dataProvider = "DataSet")
	public void admin3DSTxnVerification(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String acsTxnId, String CavvOrAvv,
			String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion, String decs)
			throws Exception {
		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);

		AdminHomePage adminhomepage = new AdminHomePage(driver);
		Admin3DSSFetchTxnPage threeDSTxnPage = new Admin3DSSFetchTxnPage(driver);

		invocationCount++;
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(AcquirerBankName);
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(AcquirerBankName)) {
				bankName.click();
				break;
			}
		}

		// driver.findElement(By.xpath("//span[text()='"+AcquirerBankName+"
		// Bank"+"']")).click();
		// driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + AcquirerBankName);

		// adminhomepage.getThreeDSAcquirerBankNameLinkInDropDown().click();
		generic.explicitWait(2);
		// adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLink3DSS().click();
		generic.explicitWait(2);
		adminhomepage.getThreedssReportsAndDashboard().click();
		generic.explicitWait(2);
		adminhomepage.getThreedssFetchTransactionReportLink().click();
		generic.explicitWait(2);
		System.out.println("Clicked on Transactions Report Link");
		System.out.println("Flow is : " + Flow);

		threeDSTxnPage.getThreedssCalenderIcon().click();
		threeDSTxnPage.getThreedsLeftHourSelect().click();
		Select acsLeftHoursOptions = new Select(threeDSTxnPage.getThreedsLeftHourSelect());
		acsLeftHoursOptions.selectByValue("0");
		threeDSTxnPage.getApplyButton().click();

		// adminhomepage.getAcsFetchTransactionReportLink().click();
		threeDSTxnPage.getThreedssAdevanceSearchButton().click();
		threeDSTxnPage.getThreedsssCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);
		threeDSTxnPage.getThreedssTxnIdTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null")) {
			System.out.println("Acs txn id is null ");
		} else {

			threeDSTxnPage.getThreedssTxnIdTextField().sendKeys(ThreeDSTxnId);
			generic.explicitWait(1);
		}
		/*
		 * if(Flow.equalsIgnoreCase("BlockCard")){
		 * threeDSTxnPage.getThreedssTransactionStatusField().click();
		 * threeDSTxnPage.getThreedssTransactionStatusFailure().click();
		 * System.out.println("Selected Failure filster in Advanced Search");
		 * threeDSTxnPage.getThreedsssCardNumberTextField().click(); }else
		 * if(Flow.equalsIgnoreCase("Blocked") &&
		 * ProtocalVersion.equalsIgnoreCase("2.1.0")) {
		 * threeDSTxnPage.getThreedssTransactionStatusField().click();
		 * threeDSTxnPage.getThreedssTransactionStatusRejected().click();
		 * System.out.println("Selected Rejected filster in Advanced Search");
		 * threeDSTxnPage.getThreedsssCardNumberTextField().click(); }else if
		 * (Flow.equalsIgnoreCase("Blocked")&&
		 * ProtocalVersion.equalsIgnoreCase("1.0.2")) {
		 * threeDSTxnPage.getThreedssTransactionStatusField().click();
		 * threeDSTxnPage.getThreedssTransactionStatusRejected().click();
		 * System.out.println("Selected Failure filster in Advanced Search");
		 * threeDSTxnPage.getThreedsssCardNumberTextField().click(); }
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("window.scrollBy(0,1000)");
		 */
		String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
		String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);
		threeDSTxnPage.getFetchReportButton().click();
		System.out.println("Clicked on Fetch Report button");
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'flex-table__body')]//div[1]//div[3]")));
		sAssertion.assertEquals(threeDSTxnPage.getTxnRecordMerchantName().getText().toLowerCase(),
				merchantname.toLowerCase());
		sAssertion.assertEquals(threeDSTxnPage.getTxnRecordTxnAmount().getText(),
				String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);
		sAssertion.assertEquals(threeDSTxnPage.getTxnRecordProtocalVersioin().getText(), ProtocalVersion);
		generic.explicitWait(1);

		threeDSTxnPage.getTxnFirstRecordInTheList().click();
		System.out.println("Clicked on displayed record to go to details report");
		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[span[text()='Card Number']]/div/span")));
		sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageCardNumberValue().getText(),
				firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber);

		sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageMerchantNameValue().getText(), merchantname);
		sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageTransactionAmountValue().getText(),
				String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);

		sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageDeviceChannelValue().getText(), "Browser");

		if (CardUnionType.equalsIgnoreCase("Master")) {

			// sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageAAVValue().getText(),
			// CavvOrAvv);

		} else {
			// sAssertion.assertEquals(threeDSTxnPage.getThreedsstxnDetailPageCAVVValue().getText(),
			// CavvOrAvv);
		}
		System.out.println("Invocation count is : " + invocationCount);
		
		//Validating 3dss Merchant id from DB
		String MerchanIdFromDB=DBConnection.getValueFromDB(ThreeDSMerchantId(IssuerBankId, ThreeDSTxnId));
		System.out.println("MerchanIdFromDB: "+MerchanIdFromDB);

		boolean merchant_id = MerchanIdFromDB.contentEquals("NULL") ||MerchanIdFromDB.contentEquals("");
        sAssertion.assertFalse(merchant_id,"Validating merchant_id from DB");
		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod() {
		logout.logout();
		System.out.println("Successfully logged out: Page Title is : " + driver.getTitle());

	}
}

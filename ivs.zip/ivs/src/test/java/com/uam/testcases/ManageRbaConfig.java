package com.uam.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LogOutPage;
import com.uam.pages.ManageRbaConfigPage;

public class ManageRbaConfig extends ACSInitialSetUp {

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] ValidateParameter() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "RbaConfig");
	}

	@Test(dataProvider = "ValidateParameter", priority = 1, invocationCount = 1, enabled = true)
	public void ValidateParameter(String BankName, String RuleSetName, String RuleSetStatus,
			String DefaultModeOfAuthentication, String RuleSetDescription, String Parameter1, String Condition1,
			String Value1, String ModeOfAuthentication, String EditDefaultModeOfAuthentication, String decs) {
		System.out.println("=======Navigating to Manage RBA Config Page=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageRbaConfigPage manageRbaConfigPage = new ManageRbaConfigPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Filling Rule Set Details
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getManageRbaConfigLink().click();

		manageRbaConfigPage.getAddNewRuleSetButton().click();
		manageRbaConfigPage.getRuleSetNameTextField().sendKeys(RuleSetName);
		manageRbaConfigPage.getRuleSetStatusDropdown().click();
		manageRbaConfigPage.getActiveRuleSetStatusDropdown().click();

		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();

		manageRbaConfigPage.getRuleSetDescTextField().sendKeys(RuleSetDescription);
		manageRbaConfigPage.getCreateNewRuleIcon().click();

		// Validating First Parameter
		manageRbaConfigPage.getFirstParameterDropdown().click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		String[] firstParameter = { "Risk Engine Score", "Risk Engine Suggestion", "Merchant Name", "Amount",
				"Transaction Type", "Merchant Category Code", "Merchant Id" };

		for (int i = 0; i < firstParameter.length; i++) {
			String aParameter = driver.findElement(By.xpath("//a[text()='" + firstParameter[i] + "']")).getText();
			sAssertion.assertEquals(aParameter, firstParameter[i]);
			sAssertion.assertAll();
		}
		// Validating sub part of Risk Engine Score i.e. condition dropdownlist
		generic.explicitWait(3);
		manageRbaConfigPage.getRiskEngineScoreDropdownList().click();
		manageRbaConfigPage.getRiskEngineScore_conditionDropdown().click();
		String[] riskEngineScoreConditionList = { "Equals", "< Less than", "> Greater than", "<= Less than Equal to",
				">= Greater than Equal to", "Between" };
		for (int j = 0; j < riskEngineScoreConditionList.length; j++) {
			String aRiskEngineScoreConditionList = driver
					.findElement(By.xpath("//a[text()='" + riskEngineScoreConditionList[j] + "']")).getText();
			sAssertion.assertEquals(aRiskEngineScoreConditionList, riskEngineScoreConditionList[j]);
			sAssertion.assertAll();
		}
		// Validating sub part of Risk Engine Suggestion i.e Value list
		
		// manageRbaConfigPage.getFirstParameterDropdown().click();
		WebElement firstPara_Webelemet = driver
				.findElement(By.xpath("(//a[@class='button dropdown-btn is-fullwidth  '])[1]"));
		firstPara_Webelemet.click();
		System.out.println("Checkpoint1:-7");
		manageRbaConfigPage.getRiskEngineSuggestionDropdownlist().click();
		manageRbaConfigPage.getRES_valueDropdown().click();
		String[] RiskEngineSuggestionValueList = { "DENY", "CRITICAL", "HIGH", "MEDIUM", "LOW", "ACCEPT" };
		for (int k = 0; k < RiskEngineSuggestionValueList.length; k++) {
			String aRiskEngineSuggestionValueList = driver
					.findElement(By.xpath("//a[text()='" + RiskEngineSuggestionValueList[k] + "']")).getText();
			sAssertion.assertEquals(aRiskEngineSuggestionValueList, RiskEngineSuggestionValueList[k]);
			sAssertion.assertAll();
			System.out.println("aRiskEngineSuggestionValueList:-" + aRiskEngineSuggestionValueList + "-->>"
					+ RiskEngineSuggestionValueList[k]);
		}

		// Validating sub part of Merchant Name i.e Condition list
		System.out.println("-------------------------");
		firstPara_Webelemet.click();
		manageRbaConfigPage.getMerchantNameDropdownList().click();
		driver.findElement(By.xpath("(//a[@class='button dropdown-btn is-fullwidth  '])[2]")).click();
		String[] merchanNameConditionList = { "Equals", "Contains", "Does not contain" };

		for (int l = 0; l < merchanNameConditionList.length; l++) {
			String aMerchanNameConditionList = driver
					.findElement(By.xpath("//a[text()='" + merchanNameConditionList[l] + "']")).getText();
			sAssertion.assertEquals(aMerchanNameConditionList, merchanNameConditionList[l]);
			sAssertion.assertAll();
			System.out.println(
					"aMerchanNameConditionList:-" + aMerchanNameConditionList + "-->>" + merchanNameConditionList[l]);
		}

		// Validating sub part of Amount i.e Condition list
		firstPara_Webelemet.click();
		manageRbaConfigPage.getAmountDropdownList().click();
		driver.findElement(By.xpath("(//a[@class='button dropdown-btn is-fullwidth  '])[2]")).click();
		String[] amountConditionList = { "Equals", "< Less than", "> Greater than", "<= Less than Equal to",
				">= Greater than Equal to", "Between" };
		for (int m = 0; m < amountConditionList.length; m++) {
			String aAmountConditionList = driver.findElement(By.xpath("//a[text()='" + amountConditionList[m] + "']"))
					.getText();
			System.out.println("aAmountConditionList: " + aAmountConditionList + "-->>" + amountConditionList[m]);
			sAssertion.assertEquals(aAmountConditionList, amountConditionList[m]);
			sAssertion.assertAll();
		}

		// Validating sub part of Transaction Type i.e Value list

		firstPara_Webelemet.click();
		manageRbaConfigPage.getTransactionTypeDropdownList().click();
		manageRbaConfigPage.getTransactionType_valueDropdown().click();
		String[] transactionType = { "E-commerce", "Non-payment", "IVR" };
		for (int n = 0; n < transactionType.length; n++) {
			String aTransactionType = driver.findElement(By.xpath("//a[text()='" + transactionType[n] + "']"))
					.getText();
			System.out.println("aTransactionType:- " + aTransactionType + "-->>" + transactionType[n]);
			sAssertion.assertEquals(aTransactionType, transactionType[n]);
			sAssertion.assertAll();
		}

		// Validating Mode of Authentication
		manageRbaConfigPage.getModeOfAuthDropdown().click();
		String[] modeOfAuth_list = { "OTP", "Frictionless", "Deny/Decline" };
		for (int p = 0; p < modeOfAuth_list.length; p++) {
			String aModeOfAuthList = driver.findElement(By.xpath("//a[text()='" + modeOfAuth_list[p] + "']")).getText();
			System.out.println("aModeOfAuthList:- " + aModeOfAuthList + "-->> " + modeOfAuth_list[p]);
			sAssertion.assertEquals(aModeOfAuthList, modeOfAuth_list[p]);
			sAssertion.assertAll();
		}

	}

	@DataProvider
	public Object[][] EditRbaRule() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "RbaConfig");
	}

	@Test(dataProvider = "EditRbaRule", priority = 1, invocationCount = 1, enabled = true)
	public void EditRbaRule(String BankName, String RuleSetName, String RuleSetStatus,
			String DefaultModeOfAuthentication, String RuleSetDescription, String Parameter1, String Condition1,
			String Value1, String ModeOfAuthentication, String EditDefaultModeOfAuthentication, String decs) {
		System.out.println("=======Navigating to RBA config Page=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageRbaConfigPage manageRbaConfigPage = new ManageRbaConfigPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageRbaConfig
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getManageRbaConfigLink().click();

		// Add new rule set
		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RulesetNameWithNum = RuleSetName + "" + randomPIN;

		manageRbaConfigPage.getAddNewRuleSetButton().click();
		manageRbaConfigPage.getRuleSetNameTextField().sendKeys(RulesetNameWithNum);
		manageRbaConfigPage.getRuleSetStatusDropdown().click();
		manageRbaConfigPage.getActiveRuleSetStatusDropdown().click();

		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();

		manageRbaConfigPage.getRuleSetDescTextField().sendKeys(RuleSetDescription);
		manageRbaConfigPage.getCreateNewRuleIcon().click();

		// Filling Create Rule Condition
		manageRbaConfigPage.getFirstParameterDropdown().click();
		System.out.println("Parameter : Amount");
		manageRbaConfigPage.getAmountDropdownList().click();
		manageRbaConfigPage.getAmount_conditionDropdown().click();
		manageRbaConfigPage.getAmount_greaterThanEqualToDropdownList().click();
		manageRbaConfigPage.getAmount_valueTextField().sendKeys(Value1);

		// Select Mode of Authentication
		manageRbaConfigPage.getModeOfAuthDropdown().click();
		if (ModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getModeOfAuth_Otp().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getModeOfAuth_Frictionless().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getModeOfAuth_DenyDecline().click();
		}
		// Saving the rule

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)", "");
		generic.explicitWait(2);
		manageRbaConfigPage.getSaveChangesButton().click();

		generic.explicitWait(3);
		String actualMessage = "Rule Set Created Successfully.";
		String expectedMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedMessage:-" + expectedMessage);

		sAssertion.assertEquals(actualMessage, expectedMessage);

		String ruleSetId = driver.findElement(By.xpath("//div[text()='" + RulesetNameWithNum + "']/parent::div/div[2]"))
				.getText();
		System.out.println("Rule Set Id:-" + ruleSetId);

		// clicking on edit
		driver.findElement(By.xpath("(//div[text()='" + RulesetNameWithNum
				+ "']/following::div[@class='flex-table__cell column']/div/div[@class='options__edit'])[1]")).click();

		generic.explicitWait(3);
		String eRuleSet = manageRbaConfigPage.getRuleSetNameTextField().getAttribute("value");
		System.out.println("eRuleSet:-" + eRuleSet);
		sAssertion.assertEquals(RulesetNameWithNum, eRuleSet);
		sAssertion.assertAll();

		// Default Mode of Authentication
		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		if (EditDefaultModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();
		} else if (EditDefaultModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getFrictionlessModeOfAuthenticationDropdownlist().click();
		} else if (EditDefaultModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getDenyModeOfAuthenticationDropdownlist().click();
		}
		// Saving the edit part

		js.executeScript("window.scrollBy(0,-500)", "");
		generic.explicitWait(2);
		manageRbaConfigPage.getSaveChangesButton().click();

		generic.explicitWait(3);
		String actualEditUpdateMessage = "Rule Set Updated Successfully.";
		String expectedEditUpdateMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedEditUpdateMessage:-" + expectedEditUpdateMessage);

		sAssertion.assertEquals(actualEditUpdateMessage, expectedEditUpdateMessage);
		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] CloneRbaRule() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "RbaConfig");
	}

	@Test(dataProvider = "CloneRbaRule", priority = 1, invocationCount = 1, enabled = true)
	public void CloneRbaRule(String BankName, String RuleSetName, String RuleSetStatus,
			String DefaultModeOfAuthentication, String RuleSetDescription, String Parameter1, String Condition1,
			String Value1, String ModeOfAuthentication, String EditDefaultModeOfAuthentication, String decs) {
		System.out.println("=======Navigating to RBA config Page=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageRbaConfigPage manageRbaConfigPage = new ManageRbaConfigPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageRbaConfig
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		manageRbaConfigPage.getManageRbaConfigLink().click();

		// Add new rule set
		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String RulesetNameWithNum = RuleSetName + "" + randomPIN;

		manageRbaConfigPage.getAddNewRuleSetButton().click();
		manageRbaConfigPage.getRuleSetNameTextField().sendKeys(RulesetNameWithNum);
		manageRbaConfigPage.getRuleSetStatusDropdown().click();
		manageRbaConfigPage.getActiveRuleSetStatusDropdown().click();

		manageRbaConfigPage.getDefaultModeOfAuthenticationDropdown().click();
		manageRbaConfigPage.getOtpModeOfAuthenticationDropdownlist().click();

		manageRbaConfigPage.getRuleSetDescTextField().sendKeys(RuleSetDescription);
		manageRbaConfigPage.getCreateNewRuleIcon().click();

		// Filling Create Rule Condition
		manageRbaConfigPage.getFirstParameterDropdown().click();
		System.out.println("Parameter : Amount");
		manageRbaConfigPage.getAmountDropdownList().click();
		manageRbaConfigPage.getAmount_conditionDropdown().click();
		manageRbaConfigPage.getAmount_greaterThanEqualToDropdownList().click();
		manageRbaConfigPage.getAmount_valueTextField().sendKeys(Value1);

		// Select Mode of Authentication
		manageRbaConfigPage.getModeOfAuthDropdown().click();
		if (ModeOfAuthentication.equalsIgnoreCase("OTP")) {
			manageRbaConfigPage.getModeOfAuth_Otp().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Frictionless")) {
			manageRbaConfigPage.getModeOfAuth_Frictionless().click();
		} else if (ModeOfAuthentication.equalsIgnoreCase("Deny/Decline")) {
			manageRbaConfigPage.getModeOfAuth_DenyDecline().click();
		}
		// Saving the rule

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)", "");
		generic.explicitWait(2);
		manageRbaConfigPage.getSaveChangesButton().click();

		generic.explicitWait(3);
		String actualMessage = "Rule Set Created Successfully.";
		String expectedMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedMessage:-" + expectedMessage);

		sAssertion.assertEquals(actualMessage, expectedMessage);

		String ruleSetId = driver.findElement(By.xpath("//div[text()='" + RulesetNameWithNum + "']/parent::div/div[2]"))
				.getText();
		System.out.println("Rule Set Id:-" + ruleSetId);
		// clicking on edit
		driver.findElement(By.xpath("(//div[text()='" + RulesetNameWithNum
				+ "']/following::div[@class='flex-table__cell column']/div/div[@class='options__edit'])[1]")).click();

		generic.explicitWait(3);
		String eRuleSet = manageRbaConfigPage.getRuleSetNameTextField().getAttribute("value");
		System.out.println("eRuleSetClone:-" + eRuleSet);
		sAssertion.assertEquals(RulesetNameWithNum, eRuleSet);
		sAssertion.assertAll();

		// Cloning
		System.out.println("Cloning.....");
		manageRbaConfigPage.getCloneRuleSetButton().click();
		manageRbaConfigPage.getSaveChangesButton().click();
		generic.explicitWait(2);
		String actualCloneUpdateMessage = "Rule Set Created Successfully.";
		String expectedCloneUpdateMessage = driver.findElement(By.xpath("//div[@role='alert']")).getText();
		System.out.println("expectedCloneUpdateMessage:-" + expectedCloneUpdateMessage);

		sAssertion.assertEquals(actualCloneUpdateMessage, expectedCloneUpdateMessage);
		sAssertion.assertAll();

	}

	@AfterMethod
	public void logout() {
		LogOutPage logout = new LogOutPage(driver);
		logout.logout();
		System.out.println("Sucessfully Logout");
	}

}

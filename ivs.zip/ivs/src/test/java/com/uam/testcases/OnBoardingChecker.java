package com.uam.testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.acs.bankonboarding.pages.CheckerOnboardBank;
import com.acs.bankonboarding.pages.CreateSchema;
import com.acs.bankonboarding.pages.ManageBins;
import com.acs.bankonboarding.pages.NewOnBoardingHome;
import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;

public class OnBoardingChecker extends ACSInitialSetUp {

	String expectedApprovedStatus = "Approved. Configuration in progress";
	// public static String checkerBankCode = NewOnboarding.bankCode;
	// NewOnboarding nob=new NewOnboarding();
	// String checkerBankCode=nob.bankCode ;
	// String checkerBankCode = "4445";

	@BeforeTest
	public void loginAdminPortal() {

		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_CHECKER_USER_NAME, Config.BASE_UAM_ADMIN_CHECKER_PASSWD);
		System.out.println("Exiting from Before test");

	}

	@Test(priority = 1)
	public void NavigateToOnboardPage() {
		System.out.println("=============Navigating to Onboard Page==============");
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		adminhomepage.getDropDownHeaderIcon().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(Config.BASE_UAM_WIBMO_BANK_NAME);
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Navigating to onboarding Bank
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getConfigurationsLink().click();
		adminhomepage.getOnboardingBanksLink().click();

		// clicking on New Onboarding
		// adminhomepage.getNewOnboardingButton().click();

		System.out.println("On the onBoarding Page");
	}

	@DataProvider
	public Object[][] ApproveConfiguration() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "ApproveConfiguration");
	}

	@Test(dataProvider = "ApproveConfiguration", priority = 2)
	public void ApproveConfiguration(String ApproveBankComment, String decs) {
		System.out.println("=============ApproveConfiguration==============");
		// AdminHomePage adminhomepage = new AdminHomePage(driver);
		ExtentTestManager.getTest().setDescription(decs);

		CheckerOnboardBank checkerOnboardBank = new CheckerOnboardBank(driver);
		System.out.println("checkerBankCode:-" + NewOnboarding.bankCode);
		driver.findElement(
				By.xpath("//div[text()='" + NewOnboarding.bankCode + "']/following::a[text()='Approve Configuration']"))
				.click();

		checkerOnboardBank.getApproveButton().click();
		checkerOnboardBank.getCommentTextArea().sendKeys(ApproveBankComment);
		checkerOnboardBank.getConfirmButton().click();

		// checking bank onboard status
		String actualApprovedStatus = driver
				.findElement(By.xpath("//div[@class='flex-table__row columns odd'][div[text()='"
						+ NewOnboarding.bankCode + "']]/div[text()='Approved. Configuration in progress']"))
				.getText();

		assertEquals(actualApprovedStatus, expectedApprovedStatus);
		System.out.println("Successfully  Approved. Configuration in progress");
		generic.explicitWait(6);
	}

	@DataProvider
	public Object[][] ApproveBin() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(OnBoradingXlFileName, "ApproveBin");
	}

	@Test(dataProvider = "ApproveBin", priority = 3)
	public void ApproveBin(String ApproveBankComment, String decs) {
		System.out.println("=============ApproveBin==============");

		ExtentTestManager.getTest().setDescription(decs);

		ManageBins manageBin = new ManageBins(driver);
		System.out.println("checkerBankCode:-" + NewOnboarding.bankCode);
		driver.findElement(By.xpath("//div[@class='flex-table__row columns odd'][div[text()='" + NewOnboarding.bankCode
				+ "']]/div[@class='flex-table__cell column']//div//div//a[text()='Manage Bins']")).click();

		// Review Bin
		manageBin.getReviewBinButton().click();
		manageBin.getReviewBinSubmitButton().click();

		// Approve Bin
		manageBin.getApproveBinsButton().click();
		manageBin.getApproveButton().click();
		manageBin.getApproveComment().sendKeys(ApproveBankComment);
		manageBin.getApproveConfirmButton().click();

	}

	@AfterTest
	public void LogoutAdminPortal() {

		NewOnBoardingHome newonboardingHomePage = new NewOnBoardingHome(driver);
		newonboardingHomePage.getLogoutAdminPortalDropdown().click();
		newonboardingHomePage.getLogoutAdminPortalDropdown().click();
		System.out.println("Logout Successfully");
	}
}

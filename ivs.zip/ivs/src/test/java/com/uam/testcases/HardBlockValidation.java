package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;
import com.uam.pages.ManageBlockedCardPage;

public class HardBlockValidation extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;	
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	boolean flag = false;

	@DataProvider
	public Object[][] HardBlockVerification() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "HardBlock");
	}

	@Test(dataProvider = "HardBlockVerification", invocationCount = 1)
	public void HardBlockVerification(String IssuerBankId, String IssuerBankName, String TemplateType,
			String Cardnumber, String ProtocalVersion, String Flow, String merchantId, String merchantname,
			String amount, String CardUnionType, String UnblockingComment, String desc) {
		System.out.println("=======Hard BlockValidation=======");

		ExtentTestManager.getTest().setDescription(desc);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageBlockedCardPage manageBlockCardPage = new ManageBlockedCardPage(driver);
		LoginPage lp = new LoginPage(driver);
		LogOutPage logout = new LogOutPage(driver);
		driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);

		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

		String currentURL = null;
		invocationCount++;

		System.out.println("Card Number : " + Cardnumber);
		checkoutpage.getCardNumberField().clear();
		checkoutpage.getCardNumberField().sendKeys(Cardnumber);

		generic.selectByVisibleText(checkoutpage.getMerchantTextField(), merchantId);

		checkoutpage.getCardExpiryField().clear();
		checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

		checkoutpage.getCardCVVField().clear();
		checkoutpage.getCardCVVField().sendKeys("111");

		checkoutpage.getQuantityField().clear();
		checkoutpage.getQuantityField().sendKeys("1");

		checkoutpage.getPurchaseAmountField().clear();
		checkoutpage.getPurchaseAmountField().sendKeys(amount);

		generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
		// putting try catch block to handle pop-up
		try {

			checkoutpage.getSubmitButton().click();
			generic.explicitWait(5);
			System.out.println("Clicked on Checkout button");

			// For Karnataka Bank
			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(8);
			}

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */

			NetWorklogs = driver.manage().logs().get("performance");
			System.out.println("NETWORK LOGS: " + NetWorklogs);
			currentURL = driver.getCurrentUrl();
			System.out.println("Current URL : " + currentURL);
			paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
			System.out.println("Pareq:-" + paReq);
			String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
			// System.out.println("tesdDecode:-" + tesdDecode);
			String arr[] = tesdDecode.split("&");
			String testEncodedPaReq = arr[0];
			String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
			System.out.println("testDecodedPareq:-" + testDecodedPareq);
			acsTxnId = generic.getValueFromXml(testDecodedPareq);
			System.out.println("acsTxnId:-" + acsTxnId);

			switch (Flow) {

			case "BlockCard":
				log.info(Flow + "Started");

				System.out.println("acsTxnId:- " + acsTxnId);
				generic.explicitWait(2);
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
						"(//*[@class='hei mid-content' or@class='mid-content'or @id='error_text'or@class='headerDiv mid-content'])[1]")));

				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				otp.getOtpTextField().sendKeys("123456");
				if (TemplateType.equalsIgnoreCase("Rocker")) {
					otp.getRkrotpSubmitButton().click();
				} else {
					otp.getTmlotpSubmitButton().click();
					generic.explicitWait(2);
				}
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[text()='Continue' or text()='CONTINUE']")));
				System.out.println("Customer care page and submit button is displayed");
				otp.getCardBlockedContinueButton().click();
				generic.explicitWait(3);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//blockquote/center[1]")));
				
				break;
			}
		} catch (Exception e) {
			System.out.println("Handling unexpected popup");
			/*
			 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
			 * + alert.getText()); alert.accept();
			 */
			ErrorCollector.addVerificationFailure(e);
		}

		//driver.close();

		// Verify Hard block in Admin portal

		driver.get(Config.BASE_UAM_URL);
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		adminhomepage.getManageBlockedCardsLink().click();
		generic.explicitWait(5);

		String last4DigitV = Cardnumber.substring(Cardnumber.length() - 4);
		System.out.println("Last4Digit:- " + last4DigitV);

		// Verify card is blocked if so then unblock

		String[] block = { "SOFTBLOCK", "HARDBLOCK", "HOTLIST" };
		for (String cardType : block) {
			System.out.println("Checking in CardType: " + cardType);
			generic.explicitWait(7);
			manageBlockCardPage.getFilteredByDropdown().click();
			// manageBlockCardPage.getFilteredByDropdownSoftBlock().click();
			driver.findElement(By.xpath("//label[@for='" + cardType + "']")).click();
			generic.explicitWait(7);
			/*manageBlockCardPage.getSearchBox().clear();
			manageBlockCardPage.getSearchBox().sendKeys(last4DigitV);*/
			// Adding new CR for Advance search
						if (driver.findElements(By.xpath("//input[@name='card number']")).size() == 0) {
							manageBlockCardPage.getAdvanceSearchPlusSign().click();
						}

						generic.explicitWait(6);
						manageBlockCardPage.getAdvSearchCardNumberTextField().clear();
						manageBlockCardPage.getAdvSearchCardNumberTextField().sendKeys(Cardnumber);
						manageBlockCardPage.getSearchButton().click();
						generic.explicitWait(2);
			if (driver.findElements(By.xpath(
					"//div[text()='Card number']/../following::div/div/div[contains(text(),'" + last4DigitV + "')]"))
					.size() > 0) {
				System.out.println("Card is blocked...");
				// Validation Point
				String NoOfBlock = driver.findElement(By.xpath(
						"//div[contains(text(),'# of Blocks this Month')]/../following::div[@class='flex-table__body']/div/div[6]"))
						.getText();
				System.out.println("NoOfBlock :-" + NoOfBlock);
				if (Integer.parseInt(NoOfBlock) % 4 == 0) {
					sAssertion.assertEquals(cardType, "HARDBLOCK");
					sAssertion.assertAll();
					System.out.println("Hard block validation has been comepleted");
				}
				driver.findElement(By.xpath("//div[text()='Card number']/../following::div/div/div[contains(text(),'"
						+ last4DigitV + "')]/following::div/div/div[@class='options__edit']")).click();
				manageBlockCardPage.getUnBlock_StatusDropdown().click();
				manageBlockCardPage.getUnBlock_ActiveStatusDropdownList().click();
				manageBlockCardPage.getUnBlock_CommentTextField().sendKeys(UnblockingComment);

				JavascriptExecutor js1 = (JavascriptExecutor) driver;
				js1.executeScript("arguments[0].click();", manageBlockCardPage.getUnBlock_SaveChangesButton());
				// manageBlockCardPage.getUnBlock_SaveChangesButton().click();
				generic.explicitWait(6);
				// Verify successful message
				System.out.println("Card is active now");
				logout.logout();
				break;
			}
				
		}
	}
}

package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.CustomerDataUploadPage;

public class CustomerDataUpload extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeFileUploadMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Fileupload");
	}

	@Test(dataProvider = "DataSet")
	public void adminFileUploadVerification(String IssuerBankId, String IssuerBankName, String FileName,
			String withHeaders, String decs) throws Exception {

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		CustomerDataUploadPage fileuploadpage = new CustomerDataUploadPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
				"Currently selected bank is " + IssuerBankName);
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		fileuploadpage.getCustomerDatUploadHeaderLinkText().click();
		Boolean NoElementpresent = driver.findElements(By.xpath(
				"//div[text()='Header Row Required']/div[@class='switch btn off btn-outline-danger btn-sm [object Object]']"))
				.size() > 0;
		Boolean YesElementpresent = driver.findElements(By.xpath(
				"//div[text()='Header Row Required']/div[@class='switch btn on btn-outline-success btn-sm [object Object]']"))
				.size() > 0;

		if (withHeaders.equalsIgnoreCase("No") && NoElementpresent) {
			System.out.println("No : without Headers already selected");

		} else if (withHeaders.equalsIgnoreCase("Yes") && YesElementpresent) {
			System.out.println("Yes with Headers already selected");

		} else if (withHeaders.equalsIgnoreCase("No") && YesElementpresent) {
			fileuploadpage.getHeaderRowRequiredYesButton().click();

		} else {
			fileuploadpage.getHeaderRowRequiredNoButton().click();

		}

		generic.explicitWait(2);
		fileuploadpage.getFileUploadConfigSaveButton().click();
		fileuploadpage.getUploadFilePlusButton().click();

		if (FileName.equalsIgnoreCase("TestDataFileForExecution.xlsx")) {
			fileuploadpage.getUploadFileTextBox().sendKeys(System.getProperty("user.dir") + "/TestData/" + FileName);
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getUploadFileFormateValidationMessage().getText(),
					"Please upload a vaild encrypted PGP or CSV file.", "File Upload formate verification faield");
		} else {

			fileuploadpage.getUploadFileTextBox().sendKeys(Config.UPLOADINGFILES_PATH + FileName);
			generic.explicitWait(2);
			fileuploadpage.getUploadFileUploadButton().click();
			generic.explicitWait(5);
		}

		if (FileName.equalsIgnoreCase("One_Successul_Record__NoHeader.csv")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(1);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "1",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("One_Successul_Record__WithHeader.csv")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(1);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "1",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Filed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Success_20_Records_NoHeader.csv")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "PROGRESSING");
			generic.explicitWait(2);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "20",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Success_20_Records_WithHeader.csv")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "PROGRESSING");
			generic.explicitWait(2);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "20",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Account_Number_NoHeader.csv")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(2);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "2",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "2",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "PARTIALLY_SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("One_Successul_Record__NoHeader.pgp")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(1);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "1",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Success_20_Records_NoHeader.pgp")) {
			fileuploadpage.getActionExecuteOrDownload().click();
			generic.explicitWait(2);
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "20",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "0",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "SUCCESSFUL",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "SUCCESSFULL",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Mobile.csv")) {
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "0",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "1",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "file uploaded",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "FAILED",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Null.csv")) {
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "0",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "1",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "file uploaded",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "FAILED",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Space.csv")) {
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "0",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "3",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "file uploaded",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "FAILED",
					"File validation status failed");

		} else if (FileName.equalsIgnoreCase("Special_Char.csv")) {
			fileuploadpage.getRefreshButton().click();
			generic.explicitWait(2);
			sAssertion.assertEquals(fileuploadpage.getFileNameText().getText(), FileName);
			sAssertion.assertEquals(fileuploadpage.getUserText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			sAssertion.assertEquals(fileuploadpage.getSuccessRecordsText().getText().trim(), "0",
					"No of Success Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFailedRecordsText().getText().trim(), "1",
					"No of Failed Records Count mismatched");
			sAssertion.assertEquals(fileuploadpage.getFileUploadStatusText().getText(), "file uploaded",
					"File Upload Status faield");
			sAssertion.assertEquals(fileuploadpage.getFileValidationStatusText().getText(), "FAILED",
					"File validation status failed");

		}

		sAssertion.assertAll();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

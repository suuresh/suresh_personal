package com.uam.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;
import com.uam.pages.AuditTrialPage;
import com.uam.pages.ErrorCodeList;

public class ErrorCodeListScreenAdmin extends ACSInitialSetUp {
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	public static String errorCode;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {
		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ErrorCodeListScreenAdmin ");
	}

	@Test(dataProvider = "DataSet")
	public void fetchErrorCodeFromAdmin(String IssuerBankId, String IssuerBankName, String Operation,
			String Schema, String panNumber, String decs) {
		ExtentTestManager.getTest().setDescription(decs);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		ErrorCodeList errorCodeList = new ErrorCodeList(driver);
		/*errorCodeList.getSelectBank().click();
		errorCodeList.getDropDownBankNameNational().click();*/
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		switch (Operation) {	
		case "Lebal Name existing error codes":
			log.info(Operation + "Started");
			errorCodeList.getLinkACS().click();
			errorCodeList.getAcsOperations().click();
			js.executeScript("arguments[0].scrollIntoView();", errorCodeList.getManageErrorCode());
			errorCodeList.getManageErrorCode().click();
			generic.explicitWait(1);
			sAssertion.assertEquals(errorCodeList.getLblErrorCode().getText(), "Error Code");
			sAssertion.assertEquals(errorCodeList.getLblCodeType().getText(), "Code Type");
			sAssertion.assertEquals(errorCodeList.getLblDesc().getText(), "Description");
			sAssertion.assertEquals(errorCodeList.getLblUserName().getText(), "Inserted By");
			break;
		case "Edit Desc existing error codes":
			log.info(Operation + "Started");
			errorCodeList.getLinkACS().click();
			errorCodeList.getAcsOperations().click();
			js.executeScript("arguments[0].scrollIntoView();", errorCodeList.getManageErrorCode());
			errorCodeList.getManageErrorCode().click();
			generic.explicitWait(1);
			errorCodeList.getEditLink().click();
			generic.explicitWait(1);
			errorCodeList.getErrorDesc().clear();
			errorCodeList.getErrorDesc().sendKeys("Automation testing error code");
			generic.explicitWait(1);
			errorCodeList.getUpdateLink().click();
			generic.explicitWait(5);
			sAssertion.assertEquals(errorCodeList.getUpdateErrorCode().getText(), "Automation testing error code");
			sAssertion.assertEquals(errorCodeList.getUserNameText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		case "Add error codes":
			log.info(Operation + "Started");
			errorCodeList.getLinkACS().click();
			errorCodeList.getAcsOperations().click();
			js.executeScript("arguments[0].scrollIntoView();", errorCodeList.getManageErrorCode());
			errorCodeList.getManageErrorCode().click();
			generic.explicitWait(1);
			errorCodeList.getAddErrorCode().click();
			generic.explicitWait(1);
			errorCodeList.getRootCode().clear();
			int randomPIN = (int) (Math.random() * 90000) + 10000;
			String RandomNum = "" + randomPIN;
			errorCode = Config.BASE_UAM_ADMIN_USER_NAME+ RandomNum;
			System.out.println("Error Code is= " + errorCode);
			errorCodeList.getRootCode().sendKeys(errorCode);
			errorCodeList.getRootCodeDesc().clear();
			errorCodeList.getRootCodeDesc().sendKeys("Automation Error Code Testing");
			errorCodeList.getRootCodeType().clear();
			errorCodeList.getRootCodeType().sendKeys("reg123");
			errorCodeList.getRootProduct().clear();
			errorCodeList.getRootProduct().sendKeys("ErrorCodeTesting");
			errorCodeList.getCreateLink().click();
			generic.explicitWait(2);
			boolean codeIsexist=false;
			int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {
				if (driver.findElements(By.xpath("//div[text()='" + errorCode + "']"))
						.size() > 0) {
					System.out.println("Webelement Exist");
					codeIsexist = true;
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}
			}
			
			sAssertion.assertTrue(codeIsexist);
			
			//sAssertion.assertEquals(errorCodeList.getUpdateErrorCode().getText(), "Automation Error Code Testing");
			//sAssertion.assertEquals(errorCodeList.getUserNameText().getText(), Config.BASE_UAM_ADMIN_USER_NAME);
			break;
		}
		sAssertion.assertAll();
	}
	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());
	}
}

package com.uam.testcases;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.DBQuery;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.ACSMDDPage;
import com.uam.pages.AcsSmsMisPage;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminHomePage;

public class ACSMDDReport extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
// 2.0 Column values
	public static String mddTotalAreqCountValue = null;
	public static String mddAresYCountValue = null;
	public static String mddAresNCountValue = null;
	public static String mddAresRCountValue = null;
	public static String mddAresCCountValue = null;
	public static String mddAresUCountValue = null;
	public static String mddTotalCreqCountValue = null;
	public static String mddTotalCresCountValue = null;
	public static String mddTotalRreqCountValue = null;
	public static String mddTotalRresCountValue = null;
	public static String mddRreqWithStatusYCountValue = null;
	public static String mddRreqWithStatusNCountValue = null;
	public static String mddRreqWithStatusUCountValue = null;

	public static String mddFrictionLessSuccessWithYPercentageValue = null;
	public static String mddChallengeTxnPercentageValue = null;
	public static String mddFrictionlessRejectWithRPercentageValue = null;
	public static String mddFrictionlessDeclineWithNPercentageValue = null;
	public static String mddFrictionlessRejectWithUPercentageValue = null;
	public static String mddChallengeSuccessPercentageValue = null;
	public static String mddChallengeFailureNPercentageValue = null;
	public static String mddChallengeDeclineUPercentageValue = null;
	public static String mddOverallSuccessYPercentageValue = null;
	public static String mddOverallFailurePercentageValue = null;
	public static String mddOverallSuccessWithYNRPercentageValue = null;

	// 2.0 Calculated values
	public static double mddFrictionLessSuccessWithYPercentage;
	public static double mddChallengeTxnPercentage;
	public static double mddFrictionlessRejectWithRPercentage;
	public static double mddFrictionlessDeclineWithNPercentage;
	public static double mddFrictionlessRejectWithUPercentage;
	public static double mddChallengeSuccessPercentage;
	public static double mddChallengeFailureNPercentage;
	public static double mddChallengeDeclineUPercentage;
	public static double mddOverallSuccessYPercentage;
	public static double mddOverallFailurePercentage;
	public static double mddOverallSuccessWithYNRPercentage;

//1.0 column values
	public static String mddTotalVEReqValue = null;
	public static String mddVEResYValue = null;
	public static String mddVEResNValue = null;
	public static String mddVEResUValue = null;
	public static String mddTotalPAReqValue = null;
	public static String mddPAResYValue = null;
	public static String mddPAResNValue = null;
	public static String mddPAResUValue = null;
	public static String mddPAReqDidNotComeValue = null;
	public static String mddAbondonedValue = null;
	public static String mddDroppedPareqDidNotComePlusAbandonedValue = null;

	public static String mddDroppedPAResOrVReqPErcentageValue = null;
	public static String mddAbandonedPAResOrPAReqPercentageValue = null;
	public static String mddPAReqOrVReqPercentageValue = null;
	public static String mddPAResYOrVReqPercentageSuccessValue = null;

	public static String mddPAResYPlusNOrVReqPercentageValue = null;
	public static String mddPAResYPlusNOrVReqPercentageFailureValue = null;
	public static String mddPAResYOrPAReqPercentageValue = null;
	public static String mddPAResYPlusNOrPAReqPercentageValue = null;

//date and time varibles
	public static String cDay = null;
	public static String cMonth = null;
	public static String nMonth = null;
	public static String cYear = null;
	public static String cHour = null;
	public static String cMinutes = null;
	public static String cSeconds = null;

	public static String utcDay = null;
	public static String utcMonth = null;
	public static String utcYear = null;
	public static String utcHour = null;
	public static String utcMinutes = null;
	public static String ucSeconds = null;

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] validateMDDReport() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "MDD");
	}

	@Test(dataProvider = "validateMDDReport", priority = 1, enabled = true)
	public void validateMDDReport(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String FromDate,
			String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate, String ToMonth,
			String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = dateTime[3];
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ACSMDDPage acsmddpage = new ACSMDDPage(driver);
		AcsSmsMisPage acsMisSmsPage = new AcsSmsMisPage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		if(IssuerBankId.equalsIgnoreCase("8271")) {
			 /*driver.findElement(By.xpath("//span[text()='" + IssuerBankName + " Bank" +
			 "']")).click();*/
			driver.findElement(By.xpath("//span[contains(text(),'"+IssuerBankName+"')]")).click();
		}
		else {
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		}
	//	driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		if(IssuerBankId.equalsIgnoreCase("8271")) {
			System.out.println("Bank Name is not validating for saib bank");
		}
		else {
			sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + IssuerBankName);
		}

		// Navigating to MDD Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsmddpage.getMddReportLink().click();
		generic.explicitWait(2);

		acsmddpage.getDatePicker().click();
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
	int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsmddpage.getApplyButton().click();
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			acsmddpage.getThreeDS1Button().click();
		}
		acsmddpage.getMddfetchReportButton().click();
		generic.explicitWait(10);

		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			// Preparing the query string
			
			String schemaquery = "use "+Schema+"; " ;
			// query updated on jan 21
			String oneDotOquery2 = 
					
					"select bank_id, txn_schema_name,  bankInfo.bank_name , protocol_version, " + 
					"sum(txn_count_vreq_veres) as total_txn_count_vreq_veres_V1, " + 
					"sum(txn_count_vereq_veres_success_y) as total_txn_count_vereq_veres_success_y_V2, " + 
					"sum(txn_count_vereq_veres_failure_n) as total_txn_count_vereq_veres_failure_n_V3, " + 
					"sum(txn_count_vereq_veres_failure_u) as total_txn_count_vereq_veres_failure_u, " + 
					"sum(txn_count_pareq) as total_txn_count_pareq_P1, " + 
					"sum(txn_count_pares_y) as total_txn_count_pares_y_P2, " + 
					"sum(txn_count_pares_n) as total_txn_count_pares_n_P3, " + 
					"sum(txn_count_pares_u) as total_txn_count_pares_u_P4, " + 
					"sum(txn_count_abandoned) as total_txn_count_abandoned_P5, " + 
					"sum(txn_count_pareq_didNot_come) as total_txn_count_pareq_didNot_come, " + 
					"sum(txn_count_pareq_didNot_come + txn_count_abandoned) as dropped_paresDNC_abandoned, " + 
					"format(ifnull(((sum(txn_count_vreq_veres - txn_count_pareq + txn_count_abandoned)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as pares_to_vereq_Q1, format(ifnull(((sum(txn_count_pareq)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as pares_pareq_Z3, format(ifnull(((sum(txn_count_pares_y)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as pares_to_vereq_Z4, format(ifnull(((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as pares_y_n_to_vereq_Z5, case format(100-ifnull((((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres))) * 100),0),2) "
					+ "when 100 then 0 else format(100-ifnull((((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres))) * 100),0),2) end "
					+ "as pares_y_n_to_vereq_failure_Z6, format(ifnull(((sum(txn_count_pares_y)/sum(txn_count_pareq)) * 100),0),2) "
					+ "as pares_pareq_Z7, format(ifnull(((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_pareq)) * 100),0),2) "
					+ "as pares_y_n_to_pareq_Z8, format(ifnull(((sum(txn_count_pareq_didNot_come + txn_count_abandoned)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as abandoned_pareqDNC_vereq_percentage_Z1, format(ifnull(((sum(txn_count_abandoned)/sum(txn_count_pareq)) * 100),0),2) "
					+ "as abandoned_pareq_percentage_Z2 from " + 
					"(SELECT bank_id, txn_schema_name, protocol_version, sum(txn_count_areq_ares) as txn_count_vreq_veres, " + 
					"sum(txn_count_vereq_veres_success_y) as txn_count_vereq_veres_success_y, " + 
					"sum(txn_count_vereq_veres_failure_n) as txn_count_vereq_veres_failure_n , " + 
					"sum(txn_count_vereq_veres_failure_u) as txn_count_vereq_veres_failure_u, " + 
					"sum(txn_count_pareq) as txn_count_pareq, " + 
					"sum(txn_count_pares_y) as txn_count_pares_y, " + 
					"sum(txn_count_pares_n) as txn_count_pares_n, " + 
					"sum(txn_count_pares_u) as txn_count_pares_u, " + 
					"sum(txn_count_pareq_didNot_come) as txn_count_pareq_didNot_come, " + 
					"sum(txn_count_abandoned) as txn_count_abandoned from "+ Schema+".mdd_summary where date_from between '"
					+ utcYear + "-" + nMonth + "-01 00:00"
					+"' and '"+ cYear + "-" + nMonth + "-" + cDay + " " +utcHour + ":" + utcMinutes+ "' and protocol_version = '1.0.2' and interval_minutes = '5' and "
					+ "bank_id = '"+IssuerBankId+"' "
					+ "group by bank_id, txn_schema_name, protocol_version) as outerQuery left join (select bank_id as bankId, bank_name from bank_info  ) "
					+ "bankInfo  ON  outerQuery.bank_id = bankInfo.bankId group by bank_id, txn_schema_name;";
	// Query updated on Mar 21
			String oneDotOquery1 = "SELECT outerQuery.bank_id, txn_schema_name, bankInfo.bank_name, protocol_version," + 
					"sum(txn_count_vreq_veres) as total_txn_count_vreq_veres_V1," + 
					"sum(txn_count_vereq_veres_success_y) as total_txn_count_vereq_veres_success_y_V2, " + 
					"sum(txn_count_vereq_veres_failure_n) as total_txn_count_vereq_veres_failure_n_V3, " + 
					"sum(txn_count_vereq_veres_failure_u) as total_txn_count_vereq_veres_failure_u, " + 
					"sum(txn_count_pareq) as total_txn_count_pareq_P1, " + 
					"sum(txn_count_pares_y) as total_txn_count_pares_y_P2, " + 
					"sum(txn_count_pares_n) as total_txn_count_pares_n_P3, " + 
					"sum(txn_count_pares_u) as total_txn_count_pares_u_P4, " + 
					"sum(txn_count_abandoned) as total_txn_count_abandoned_P5, " + 
					"sum(txn_count_pareq_didNot_come) as total_txn_count_pareq_didNot_come, " + 
					"sum(txn_count_pareq_didNot_come + txn_count_abandoned) as dropped_paresDNC_abandoned, " + 
					"format(ifnull(((sum(txn_count_vreq_veres - txn_count_pareq + txn_count_abandoned)/sum(txn_count_vreq_veres)) * 100),0),2) "
					+ "as pares_to_vereq_Q1, format(ifnull(((sum(txn_count_pareq)/sum(txn_count_vreq_veres)) * 100),0),2) as pares_pareq_Z3, "
					+ "format(ifnull(((sum(txn_count_pares_y)/sum(txn_count_vreq_veres)) * 100),0),2) as pares_to_vereq_Z4, " + 
					"format(ifnull(((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres)) * 100),0),2) as pares_y_n_to_vereq_Z5, "
					+ "case format(100-ifnull((((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres))) * 100),0),2) when 100 then 0 else "
					+ "format(100-ifnull((((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_vreq_veres))) * 100),0),2) end as pares_y_n_to_vereq_failure_Z6, "
					+ "format(ifnull(((sum(txn_count_pares_y)/sum(txn_count_pareq)) * 100),0),2) as pares_pareq_Z7, " + 
					"format(ifnull(((sum(txn_count_pares_y + txn_count_pares_n)/sum(txn_count_pareq)) * 100),0),2) as pares_y_n_to_pareq_Z8, "
					+ "format(ifnull(((sum(txn_count_pareq_didNot_come + txn_count_abandoned)/sum(txn_count_vreq_veres)) * 100),0),2) as abandoned_pareqDNC_vereq_percentage_Z1, "
					+ "format(ifnull(((sum(txn_count_abandoned)/sum(txn_count_pareq)) * 100),0),2) as abandoned_pareq_percentage_Z2 "
					+ "from ( SELECT issuer_id as bank_id, '"+Schema+"' as txn_schema_name, acs_version as protocol_version, " + 
					"count(acs_txn_id) as txn_count_vreq_veres, SUM(CASE WHEN auth_status = 'Y' THEN 1 ELSE 0 END) " + 
					"AS txn_count_vereq_veres_success_y, SUM(CASE WHEN auth_status = 'N' THEN 1 ELSE 0 END) " + 
					"AS txn_count_vereq_veres_failure_n, SUM(CASE WHEN auth_status = 'U' THEN 1 ELSE 0 END) " + 
					"AS txn_count_vereq_veres_failure_u, 0 AS txn_count_pareq, 0 AS txn_count_pares_y, 0 " + 
					"AS txn_count_pares_n, 0 AS txn_count_pares_u, 0 as txn_count_pareq_didNot_come, 0 " + 
					"AS txn_count_abandoned from "+Schema+".vereq_veres_" +utcYear+nMonth+ " where request_date_time between '"+ utcYear + "-" + nMonth + "-01 00:00"
					+"' and '"+ cYear + "-" + nMonth + "-" + cDay + " " +utcHour + ":" + utcMinutes+ "' and "
					+ "acs_version = '1.0.2' and "
					+ "issuer_id = "+IssuerBankId+" group by bank_id,txn_schema_name, acs_version UNION ALL SELECT issuer_id as bank_id, "
					+ "'"+Schema+"' as txn_schema_name, acs_version as protocol_version, 0 as txn_count_vreq_veres, 0 AS txn_count_vereq_veres_success_y, 0 " + 
					"AS txn_count_vereq_veres_failure_n, 0 AS txn_count_vereq_veres_failure_u, SUM(CASE WHEN error_code!='AC0408' THEN 1 ELSE 0 END) " + 
					"AS txn_count_pareq, SUM(CASE WHEN txn_status = 'Y' THEN 1 ELSE 0 END)" + 
					"AS txn_count_pares_y, SUM(CASE WHEN txn_status = 'N' AND error_code != 'AC0408' AND error_code != 'AC0407' THEN 1 ELSE 0 END) " + 
					"AS txn_count_pares_n, SUM(CASE WHEN txn_status = 'U' THEN 1 ELSE 0 END) " + 
					"AS txn_count_pares_u, SUM(CASE WHEN error_code='AC0408' THEN 1 ELSE 0 END) " + 
					"as txn_count_pareq_didNot_come, SUM(CASE WHEN error_code= 'AC0407' THEN 1 ELSE 0 END) " + 
					"AS txn_count_abandoned from "+Schema+".acs_txn_"+utcYear+nMonth+" " + 
					"where date_time between '"+ utcYear + "-" + nMonth + "-01 00:00"
					+"' and '"+ cYear + "-" + nMonth + "-" + cDay + " " +utcHour + ":" + utcMinutes+ "' and"
					+ " acs_version = '1.0.2' and issuer_id = '"+IssuerBankId+"' group by bank_id, txn_schema_name, acs_version ) "
					+ "as outerQuery left join acs2qadcs_reporting_admin.bank_info as bankInfo ON outerQuery.bank_id = bankInfo.bank_id group by outerQuery.bank_id, txn_schema_name, protocol_version ;";			
			
			
			System.out.println("Query : " + oneDotOquery1);
		
			getOneDotOmddReportValuesFromDB(oneDotOquery1, schemaquery);

			sAssertion.assertEquals(acsmddpage.getMddTotalVEReqValue().getText(), mddTotalVEReqValue,
					"mddTotalVEReqValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddVEResYValue().getText(), mddVEResYValue,
					"mddVEResYValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddVEResNValue().getText(), mddVEResNValue,
					"mddVEResNValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddVEResUValue().getText(), mddVEResUValue,
					"mddVEResUValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddTotalPAReqValue().getText(), mddTotalPAReqValue,
					"mddTotalPAReqValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYValue().getText(), mddPAResYValue,
					"mddPAResYValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResNValue().getText(), mddPAResNValue,
					"mddPAResNValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResUValue().getText(), mddPAResUValue,
					"mddPAResUValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAReqDidNotComeValue().getText(), mddPAReqDidNotComeValue,
					"mddPAReqDidNotComeValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddAbondonedValue().getText(), mddAbondonedValue,
					"mddAbondonedValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddDroppedPareqDidNotComePlusAbandonedValue().getText(),
					mddDroppedPareqDidNotComePlusAbandonedValue,
					"mddDroppedPareqDidNotComePlusAbandonedValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddDroppedPAResOrVReqPErcentageValue().getText(),
					mddDroppedPAResOrVReqPErcentageValue, "mddDroppedPAResOrVReqPErcentageValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddAbandonedPAResOrPAReqPercentageValue().getText(),
					mddAbandonedPAResOrPAReqPercentageValue,
					"mddAbandonedPAResOrPAReqPercentageValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAReqOrVReqPercentageValue().getText(),
					mddPAReqOrVReqPercentageValue, "mddPAReqOrVReqPercentageValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYOrVReqPercentageSuccessValue().getText(),
					mddPAResYOrVReqPercentageSuccessValue, "mddPAResYOrVReqPercentageSuccessValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYPlusNOrVReqPercentageValue().getText(),
					mddPAResYPlusNOrVReqPercentageValue, "mddPAResYPlusNOrVReqPercentageValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYPlusNOrVReqPercentageFailureValue().getText(),
					mddPAResYPlusNOrVReqPercentageFailureValue,
					"mddPAResYPlusNOrVReqPercentageFailureValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYOrPAReqPercentageValue().getText(),
					mddPAResYOrPAReqPercentageValue, "mddPAResYOrPAReqPercentageValue not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddPAResYPlusNOrPAReqPercentageValue().getText(),
					mddPAResYPlusNOrPAReqPercentageValue, "mddPAResYPlusNOrPAReqPercentageValue not matched with DB");
		} else {

			// 2.0 getting values from the DB
			String twoDotOSchema = "use "+Schema+"; ";
			String twoDotOQueryString = 
					"SELECT bank_id, txn_schema_name, bankInfo.bank_name , protocol_version,  " + 
					"sum(txn_count_areq_ares) as total_txn_count_areq_ares_A1, " + 
					"sum(txn_count_areq_ares_y) as total_txn_count_areq_ares_y_A2, " + 
					"sum(txn_count_areq_ares_n) as total_txn_count_areq_ares_n_A3, " + 
					"sum(txn_count_areq_ares_R) as total_txn_count_areq_ares_R_A4, " + 
					"sum(txn_count_areq_ares_C) as total_txn_count_areq_ares_C_A5, " + 
					"sum(txn_count_areq_ares_u) as total_txn_count_areq_ares_u_A6, " + 
					"sum(txn_count_challenge) as total_txn_count_challenge_C1, " + 
					"sum(txn_count_rreq_rres) as total_txn_count_challenge_recieved_C2, " + 
					"sum(txn_count_rreq_rres) as total_txn_count_rreq_rres_R1, " + 
					"sum(txn_count_rreq_rres) as total_txn_count_rreq_rres_R2, " + 
					"sum(txn_count_rreq_rres_success_y) as total_txn_count_rreq_rres_success_y_R3, " + 
					"sum(txn_count_rreq_rres_failure_n) as total_txn_count_rreq_rres_failure_n_R4 , " + 
					"sum(txn_count_rreq_rres_failure_u) as total_txn_count_rreq_rres_failure_u_R5 , " + 
					"format(ifnull(((sum(txn_count_areq_ares_y)/sum(txn_count_areq_ares - txn_count_areq_ares_C)) * 100),0),2) as ares_success_y_S1, format(ifnull(((sum(txn_count_rreq_rres_success_y)/sum(txn_count_challenge)) * 100),0),2) as ares_challenge_S2, format(ifnull(((sum(txn_count_areq_ares_R)/sum(txn_count_areq_ares)) * 100),0),2) as aresR_to_ares_S3, format(ifnull(((sum(txn_count_areq_ares_n)/sum(txn_count_areq_ares)) * 100),0),2) as aresN_to_areq_S4, format(ifnull(((sum(txn_count_areq_ares_u)/sum(txn_count_areq_ares)) * 100),0),2) as aresU_to_ares_S5, format(ifnull(((sum(txn_count_rreq_rres_success_y)/sum(txn_count_areq_ares_C)) * 100),0),2) as challenge_successful_Rreq_y_C1, format(ifnull(((sum(txn_count_rreq_rres_failure_n)/sum(txn_count_areq_ares_C)) * 100),0),2) as challenge_failure_RreqN_to_AresC_C2, format(ifnull(((sum(txn_count_rreq_rres_failure_u)/sum(txn_count_areq_ares_C)) * 100),0),2) as challenge_decline_RreqU_to_AresC_C3, format(ifnull(((sum(txn_count_rreq_rres_failure_n)/sum(txn_count_areq_ares_C)) * 100),0),2) as challenge_decline_RreqR_to_AresC_C4, format(ifnull(((sum(txn_count_areq_ares_y + txn_count_rreq_rres_success_y)/sum(txn_count_areq_ares)) * 100),0),2) as AresY_RReqY_to_AReq_O1, format(ifnull(((sum(txn_count_areq_ares_R + txn_count_areq_ares_C + txn_count_areq_ares_u + txn_count_rreq_rres_failure_n + txn_count_rreq_rres_failure_u)/sum(txn_count_areq_ares)) * 100),0),2) as Ares_N_R_U_RReq_N_R_U_to_Areq_O2, " + 
					"format(ifnull(((sum(txn_count_areq_ares_y + txn_count_areq_ares_n + txn_count_areq_ares_R + txn_count_rreq_rres_success_y + txn_count_rreq_rres_failure_n)/sum(txn_count_areq_ares)) * 100),0),2) as O_3 " + 
					"from (SELECT bank_id, txn_schema_name, protocol_version, " + 
					"sum(txn_count_areq_ares) as txn_count_areq_ares, " + 
					"sum(txn_count_areq_ares_y) as txn_count_areq_ares_y, " + 
					"sum(txn_count_areq_ares_n) as txn_count_areq_ares_n , " + 
					"sum(txn_count_areq_ares_R) as txn_count_areq_ares_R, " + 
					"sum(txn_count_areq_ares_u) as txn_count_areq_ares_u, " + 
					"sum(txn_count_areq_ares_C) as txn_count_areq_ares_C, " + 
					"sum(txn_count_challenge) as txn_count_challenge, " + 
					"sum(txn_count_challenge_recieved) as txn_count_challenge_recieved, " + 
					"sum(txn_count_rreq_rres) as txn_count_rreq_rres, " + 
					"sum(txn_count_rreq_rres_success_y) as txn_count_rreq_rres_success_y, " + 
					"sum(txn_count_rreq_rres_failure_n) as txn_count_rreq_rres_failure_n, " + 
					"sum(txn_count_rreq_rres_failure_u) as txn_count_rreq_rres_failure_u " + 
					"from mdd_summary where date_from between '"+ utcYear + "-" + nMonth + "-01 00:00" + 
					"' and '"+ cYear + "-" + nMonth + "-" + cDay + " " +utcHour + ":" + utcMinutes+"' and " 
							+ "protocol_version = '2.1.0' and interval_minutes = '5' and bank_id = '"+IssuerBankId+"' " + 
					"group by bank_id, txn_schema_name, protocol_version) as outerQuery left join (select bank_id as bankId, bank_name from bank_info  ) bankInfo  ON  outerQuery.bank_id = bankInfo.bankId group by bank_id, txn_schema_name ;";
			
			System.out.println("Query : " + twoDotOQueryString);
			
			getTwoDotOmddReportValuesFromDB(twoDotOQueryString, twoDotOSchema);
			
			/*
			 * mddTotalAreqCountValue =
			 * DBConnection.getValueFromDB(DBQuery.TotalAreqCount(Schema));
			 * mddAresYCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddAresYCount(Schema));
			 * mddAresNCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddAresNCount(Schema));
			 * mddAresRCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddAresRCount(Schema));
			 * mddAresCCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddAresCCount(Schema));
			 * mddAresUCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddAresUCount(Schema));
			 * mddTotalCreqCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddTotalCreqCount(Schema));
			 * mddTotalCresCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddTotalCresCount(Schema));
			 * mddTotalRreqCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddTotalRreqCount(Schema));
			 * mddTotalRresCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddTotalRresCount(Schema));
			 * mddChallengeSuccessPercentageValue =
			 * DBConnection.getValueFromDB(DBQuery.mddRreqWithStatusYCount(Schema));
			 * mddRreqWithStatusNCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddRreqWithStatusNCount(Schema));
			 * mddRreqWithStatusUCountValue =
			 * DBConnection.getValueFromDB(DBQuery.mddRreqWithStatusUCount(Schema));
			 * twoDotOcolumnCalculations();
			 * 
			 * mddFrictionlessRejectWithRPercentageValue = String
			 * .valueOf(Math.round(mddFrictionlessRejectWithRPercentage * 10) / 10.0);
			 * mddFrictionlessDeclineWithNPercentageValue = String
			 * .valueOf(Math.round(mddFrictionlessDeclineWithNPercentage * 10) / 10.0);
			 * mddFrictionlessRejectWithUPercentageValue = String
			 * .valueOf(Math.round(mddFrictionlessRejectWithUPercentage * 10) / 10.0);
			 * mddChallengeSuccessPercentageValue =
			 * String.valueOf(Math.round(mddChallengeSuccessPercentage * 10) / 10.0);
			 * mddChallengeFailureNPercentageValue = String
			 * .valueOf(Math.round(mddChallengeFailureNPercentage * 10) / 10.0);
			 * mddChallengeDeclineUPercentageValue = String
			 * .valueOf(Math.round(mddChallengeDeclineUPercentage * 10) / 10.0);
			 * mddOverallSuccessYPercentageValue =
			 * String.valueOf(Math.round(mddOverallSuccessYPercentage * 10) / 10.0);
			 * mddOverallFailurePercentageValue =
			 * String.valueOf(Math.round(mddOverallFailurePercentage * 10) / 10.0);
			 * mddOverallSuccessWithYNRPercentageValue = String
			 * .valueOf(Math.round(mddOverallSuccessWithYNRPercentage * 10) / 10.0);
			 */
			sAssertion.assertEquals(acsmddpage.getMddTotalAreqCountValue().getText(), mddTotalAreqCountValue,
					"mddTotalAreqCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddAresYCountValue().getText(), mddAresYCountValue,
					"mddAresYCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddAresNCountValue().getText(), mddAresNCountValue,
					"mddAresNCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddAresRCountValue().getText(), mddAresRCountValue,
					"mddAresRCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddAresCCountValue().getText(), mddAresCCountValue,
					"mddAresCCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddAresUCountValue().getText(), mddAresUCountValue,
					"mddAresUCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddTotalCreqCountValue().getText(), mddTotalCreqCountValue,
					"mddTotalCreqCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddTotalCresCountValue().getText(), mddTotalCresCountValue,
					"mddTotalCresCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddTotalRreqCountValue().getText(), mddTotalRreqCountValue,
					"mddTotalRreqCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddTotalRresCountValue().getText(), mddTotalRresCountValue,
					"mddTotalRresCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddRreqWithStatusYCountValue().getText(),
					mddRreqWithStatusYCountValue, "mddRreqWithStatusYCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddRreqWithStatusNCountValue().getText(),
					mddRreqWithStatusNCountValue, "mddRreqWithStatusNCountValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddRreqWithStatusUCountValue().getText(),
					mddRreqWithStatusUCountValue, "mddRreqWithStatusUCountValue  not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddFrictionLessSuccessWithYPercentageValue().getText(),
					mddFrictionLessSuccessWithYPercentageValue,
					"mddFrictionLessSuccessWithYPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddChallengeTxnPercentageValue().getText(),
					mddChallengeTxnPercentageValue, "mddChallengeTxnPercentageValue  not matched with DB");

			sAssertion.assertEquals(acsmddpage.getMddFrictionlessRejectWithRPercentageValue().getText(),
					mddFrictionlessRejectWithRPercentageValue,
					"mddFrictionlessRejectWithRPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddFrictionlessDeclineWithNPercentageValue().getText(),
					mddFrictionlessDeclineWithNPercentageValue,
					"mddFrictionlessDeclineWithNPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddFrictionlessRejectWithUPercentageValue().getText(),
					mddFrictionlessRejectWithUPercentageValue,
					"mddFrictionlessRejectWithUPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddChallengeSuccessPercentageValue().getText(),
					mddChallengeSuccessPercentageValue, "mddChallengeSuccessPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddChallengeFailureNPercentageValue().getText(),
					mddChallengeFailureNPercentageValue, "mddChallengeFailureNPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddChallengeDeclineUPercentageValue().getText(),
					mddChallengeDeclineUPercentageValue, "mddChallengeDeclineUPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddOverallSuccessYPercentageValue().getText(),
					mddOverallSuccessYPercentageValue, "mddOverallSuccessYPercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddOverallFailurePercentageValue().getText(),
					mddOverallFailurePercentageValue, "mddOverallFailurePercentageValue  not matched with DB");
			sAssertion.assertEquals(acsmddpage.getMddOverallSuccessWithYNRPercentageValue().getText(),
					mddOverallSuccessWithYNRPercentageValue,
					"mddOverallSuccessWithYNRPercentageValue  not matched with DB");

		}

		sAssertion.assertAll();

	}

	public void twoDotOcolumnCalculations() {
		try {
			System.out.println("Calculation started");
			mddFrictionLessSuccessWithYPercentage = Float.parseFloat(mddAresYCountValue)
					/ (Float.parseFloat(mddTotalAreqCountValue) - Float.parseFloat(mddAresCCountValue));
			mddChallengeTxnPercentage = Float.parseFloat(mddRreqWithStatusYCountValue)
					/ Float.parseFloat(mddTotalCreqCountValue);
			mddFrictionlessRejectWithRPercentage = Float.parseFloat(mddAresRCountValue)
					/ Float.parseFloat(mddTotalAreqCountValue);
			mddFrictionlessDeclineWithNPercentage = Float.parseFloat(mddAresNCountValue)
					/ Float.parseFloat(mddTotalAreqCountValue);
			mddFrictionlessRejectWithUPercentage = Float.parseFloat(mddAresUCountValue)
					/ Float.parseFloat(mddTotalAreqCountValue);

			mddChallengeSuccessPercentage = Float.parseFloat(mddChallengeSuccessPercentageValue)
					/ Float.parseFloat(mddAresCCountValue);

			mddChallengeFailureNPercentage = Float.parseFloat(mddRreqWithStatusNCountValue)
					/ Float.parseFloat(mddAresCCountValue);

			mddChallengeDeclineUPercentage = Float.parseFloat(mddRreqWithStatusUCountValue)
					/ Float.parseFloat(mddAresCCountValue);

			mddOverallSuccessYPercentage = Float.parseFloat(mddAresYCountValue)
					+ Float.parseFloat(mddRreqWithStatusNCountValue) / Float.parseFloat(mddTotalAreqCountValue);

			mddOverallFailurePercentage = (Float.parseFloat(mddAresRCountValue) + Float.parseFloat(mddAresCCountValue)
					+ Float.parseFloat(mddAresUCountValue) + Float.parseFloat(mddRreqWithStatusNCountValue)
					+ Float.parseFloat(mddRreqWithStatusUCountValue)) / Float.parseFloat(mddTotalAreqCountValue);

			mddOverallSuccessWithYNRPercentage = (Float.parseFloat(mddAresYCountValue)
					+ Float.parseFloat(mddAresNCountValue) + Float.parseFloat(mddAresRCountValue)
					+ Float.parseFloat(mddRreqWithStatusNCountValue) + Float.parseFloat(mddRreqWithStatusYCountValue))
					/ Float.parseFloat(mddTotalAreqCountValue);
			
			System.out.println("Calculations over");
			
		} catch (Exception e) {
			System.out.println("Print the exception:" + e);
		}
	}
	
	public static void getOneDotOmddReportValuesFromDB(String queryString, String schemaquery) {

		String dbValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs1 = stmt.executeQuery(schemaquery);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				// dbValue = rs.getString(1);
				mddTotalVEReqValue = rs.getString("total_txn_count_vreq_veres_V1");
				mddVEResYValue = rs.getString("total_txn_count_vereq_veres_success_y_V2");
				mddVEResNValue = rs.getString("total_txn_count_vereq_veres_failure_n_V3");
				mddVEResUValue = rs.getString("total_txn_count_vereq_veres_failure_u");
				mddTotalPAReqValue = rs.getString("total_txn_count_pareq_P1");
				mddPAResYValue = rs.getString("total_txn_count_pares_y_P2");
				mddPAResNValue = rs.getString("total_txn_count_pares_n_P3");
				mddPAResUValue = rs.getString("total_txn_count_pares_u_P4");
				mddPAReqDidNotComeValue = rs.getString("total_txn_count_pareq_didNot_come");
				mddAbondonedValue = rs.getString("total_txn_count_abandoned_P5");
				
				mddDroppedPareqDidNotComePlusAbandonedValue = rs.getString("dropped_paresDNC_abandoned");
				mddDroppedPAResOrVReqPErcentageValue = rs.getString("abandoned_pareqDNC_vereq_percentage_Z1");
				mddAbandonedPAResOrPAReqPercentageValue = rs.getString("abandoned_pareq_percentage_Z2");
				mddPAReqOrVReqPercentageValue = rs.getString("pares_pareq_Z3");
				mddPAResYOrVReqPercentageSuccessValue = rs.getString("pares_to_vereq_Z4");
				mddPAResYPlusNOrVReqPercentageValue = rs.getString("pares_y_n_to_vereq_Z5");

				mddPAResYPlusNOrVReqPercentageFailureValue = rs.getString("pares_y_n_to_vereq_failure_Z6");
				mddPAResYOrPAReqPercentageValue = rs.getString("pares_pareq_Z7");
				mddPAResYPlusNOrPAReqPercentageValue = rs.getString("pares_y_n_to_pareq_Z8");

				// System.out.println("dbValue:" + dbValue);

				System.out.println("mddTotalVEReqValue :"+mddTotalVEReqValue);
				System.out.println("mddVEResYValue :"+mddVEResYValue);
				System.out.println("mddVEResNValue :"+mddVEResNValue);
				System.out.println("mddVEResUValue :"+mddVEResUValue);
				System.out.println("mddTotalPAReqValue :"+mddTotalPAReqValue);
				System.out.println("mddPAResYValue :"+mddPAResYValue);
				System.out.println("mddPAResNValue :"+mddPAResNValue);
				System.out.println("mddPAResUValue :"+mddPAResUValue);
				System.out.println("mddPAReqDidNotComeValue :"+mddPAReqDidNotComeValue);
				System.out.println("mddPAReqDidNotComeValue :"+mddAbondonedValue);
				System.out.println("mddDroppedPareqDidNotComePlusAbandonedValue :"+mddDroppedPareqDidNotComePlusAbandonedValue);
				System.out.println("mddDroppedPAResOrVReqPErcentageValue :"+mddDroppedPAResOrVReqPErcentageValue);
				System.out.println("mddAbandonedPAResOrPAReqPercentageValue :"+mddAbandonedPAResOrPAReqPercentageValue);
				System.out.println("mddPAReqOrVReqPercentageValue :"+mddPAReqOrVReqPercentageValue);
				System.out.println("mddPAResYOrVReqPercentageSuccessValue :"+mddPAResYOrVReqPercentageSuccessValue);

				System.out.println("mddPAResYPlusNOrVReqPercentageValue :"+mddPAResYPlusNOrVReqPercentageValue);
				System.out.println("mddPAResYPlusNOrVReqPercentageFailureValue :"+mddPAResYPlusNOrVReqPercentageFailureValue);
				System.out.println("mddPAResYOrPAReqPercentageValue :"+mddPAResYOrPAReqPercentageValue);
				System.out.println("mddPAResYPlusNOrPAReqPercentageValue :"+mddPAResYPlusNOrPAReqPercentageValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	return dbValue;

	}
	
	public static void getTwoDotOmddReportValuesFromDB(String queryString, String schemaquery) {

		String dbValue = null;

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created for 2.0 -  :" + queryString);
			ResultSet rs1 = stmt.executeQuery(schemaquery);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				// dbValue = rs.getString(1);
				mddTotalAreqCountValue = rs.getString("total_txn_count_areq_ares_A1");
				mddAresYCountValue = rs.getString("total_txn_count_areq_ares_y_A2");
				mddAresNCountValue = rs.getString("total_txn_count_areq_ares_n_A3");
				mddAresRCountValue = rs.getString("total_txn_count_areq_ares_R_A4");
				mddAresCCountValue = rs.getString("total_txn_count_areq_ares_C_A5");
				mddAresUCountValue = rs.getString("total_txn_count_areq_ares_u_A6");
				mddTotalCreqCountValue = rs.getString("total_txn_count_challenge_C1");
				mddTotalCresCountValue = rs.getString("total_txn_count_challenge_recieved_C2");
				mddTotalRreqCountValue = rs.getString("total_txn_count_rreq_rres_R1");
				mddTotalRresCountValue = rs.getString("total_txn_count_rreq_rres_R2");
				mddChallengeSuccessPercentageValue = rs.getString("challenge_decline_RreqR_to_AresC_C4");
				mddRreqWithStatusYCountValue = rs.getString("total_txn_count_rreq_rres_success_y_R3");
				mddRreqWithStatusNCountValue = rs.getString("total_txn_count_rreq_rres_failure_n_R4");
				mddRreqWithStatusUCountValue = rs.getString("total_txn_count_rreq_rres_failure_u_R5");
				mddFrictionLessSuccessWithYPercentageValue = rs.getString("ares_success_y_S1");
				mddChallengeTxnPercentageValue = rs.getString("ares_challenge_S2");
				mddFrictionlessRejectWithRPercentageValue = rs.getString("aresR_to_ares_S3");
				mddFrictionlessDeclineWithNPercentageValue = rs.getString("aresN_to_areq_S4");
				mddFrictionlessRejectWithUPercentageValue = rs.getString("aresU_to_ares_S5");
				mddChallengeSuccessPercentageValue = rs.getString("challenge_successful_Rreq_y_C1");
				mddChallengeFailureNPercentageValue = rs.getString("challenge_failure_RreqN_to_AresC_C2");
				mddChallengeDeclineUPercentageValue = rs.getString("challenge_decline_RreqU_to_AresC_C3");
				mddOverallSuccessYPercentageValue = rs.getString("AresY_RReqY_to_AReq_O1");
				mddOverallFailurePercentageValue = rs.getString("Ares_N_R_U_RReq_N_R_U_to_Areq_O2");
				mddOverallSuccessWithYNRPercentageValue = rs.getString("O_3");

				
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	return dbValue;

	}


}

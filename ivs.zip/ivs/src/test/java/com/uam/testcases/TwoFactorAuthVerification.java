package com.uam.testcases;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.mailReader;
import com.uam.pages.AdminHomePage;
import com.uam.pages.TwoFactorAuthenticationPage;

public class TwoFactorAuthVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, ACSTxn2_0SheetName);
	}

	//@Test(priority=1)
	public void enable_2fa() throws Exception {

		ExtentTestManager.getTest().setDescription("Enabling Two Factor Authentication");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		Actions actions = new Actions(driver);
		TwoFactorAuthenticationPage twofa = new TwoFactorAuthenticationPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("Wibmo");
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("Wibmo")) {
				bankName.click();
				break;
			}
		}
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + "Wibmo");
	
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		twofa.getManageResourceLink().click();
		twofa.getAdminParamsButton().click();
	//	twofa.getSearchByKeyNameInPutField().sendKeys("ENABLE_TWO_FACTOR_AUTHENTICATION");
	//	sAssertion.assertEquals(twofa.getRootKeyNameText().getText(),"ENABLE_TWO_FACTOR_AUTHENTICATION");
		generic.explicitWait(1);
		actions.moveToElement(twofa.getTwoFactorEditOption()).perform();
		generic.explicitWait(2);
		twofa.getTwoFactorEditOption().click();
		twofa.getRootKeyValueTextArea().clear();
		twofa.getRootKeyValueTextArea().sendKeys("true");	
		twofa.getRootKeyCommentTextArea().clear();
		twofa.getRootKeyCommentTextArea().sendKeys("Enabling 2fa");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-200)");
		js.executeScript("window.scrollTo(0,document.body.scrollTop)");
		twofa.getSaveChangesButton().click();
		generic.explicitWait(5);
		sAssertion.assertAll();

	}
	
	@Test(priority=2)
	public void verify_2fa() throws Exception {

		ExtentTestManager.getTest().setDescription("Verifying Two Factor Authentication");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		TwoFactorAuthenticationPage twofa = new TwoFactorAuthenticationPage(driver);
		Actions actions = new Actions(driver);
		invocationCount++;
		//generic.explicitWait(50);
		String adminOtp=mailReader.OutlookMailReader("Inbox", "OTP Alert", "is your OTP to login to ACCOSA 2.0", 6);
		System.out.println("Admin OTP is  : "+adminOtp);
		twofa.getEnterOTPTextArea().sendKeys(adminOtp);
		twofa.getOTPSubmitButton().click();
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("Wibmo");
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("Wibmo")) {
				bankName.click();
				break;
			}
		}
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + "Wibmo");
	
		//Disabling Two factor Authentication
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		twofa.getManageResourceLink().click();
		twofa.getAdminParamsButton().click();
//		twofa.getSearchByKeyNameInPutField().sendKeys("ENABLE_TWO_FACTOR_AUTHENTICATION");
//		sAssertion.assertEquals(twofa.getRootKeyNameText().getText(),"ENABLE_TWO_FACTOR_AUTHENTICATION");
		
		generic.explicitWait(1);
		actions.moveToElement(twofa.getTwoFactorEditOption()).perform();
		generic.explicitWait(2);
		twofa.getTwoFactorEditOption().click();
		twofa.getRootKeyValueTextArea().clear();
		twofa.getRootKeyValueTextArea().sendKeys("false");	
		twofa.getRootKeyCommentTextArea().clear();
		twofa.getRootKeyCommentTextArea().sendKeys("Disabling 2fa");
		twofa.getSaveChangesButton().click();
		generic.explicitWait(2);
		sAssertion.assertAll();

	}
	
	@Test(priority=3)
	public void verifying_2fa_disabled() throws Exception {

		ExtentTestManager.getTest().setDescription("Verifying Two Factor Authentication");
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys("Wibmo");
		generic.explicitWait(1);
		
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("Wibmo")) {
				bankName.click();
				break;
			}
		}
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + "Wibmo");
	
		sAssertion.assertAll();

	}
	
	

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

package com.uam.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.libraries.Xls_Reader;
import com.uam.pages.LogOutPage;
import com.uam.pages.LoginPage;

public class UAMInitialSetUp {

	public WebDriver driver;
	public Xls_Reader excel;
	public LoginPage loginPage;
	public LogOutPage logout;
	public SoftAssert sAssertion;
	int invocationCount = 2;

	public GenericMethods generic;
	public Logger app_logs = Logger.getLogger("devpinoyLogeer");

	@Parameters({ "browser-name", "operating-system" })
	@BeforeClass
	public void preCondtion(String browser, String OS) {

		if (OS.equalsIgnoreCase("windows")) {

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.GECKODRIVER_PATH);
				driver = new FirefoxDriver();

				// this is how applogs will be generated.
				app_logs.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				System.setProperty("webdriver.chrome.driver", Config.CHROMEDRIVER_PATH);
				driver = new ChromeDriver();
			}
		} else if (OS.equalsIgnoreCase("linux")) {

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", Config.LINUX_GECKODRIVER_PATH);
				driver = new FirefoxDriver();

				// this is how applogs will be generated.
				app_logs.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				System.setProperty("webdriver.chrome.driver", Config.LINUX_CHROMEDRIVER_PATH);
				driver = new ChromeDriver();
			}
		}else if (OS.equalsIgnoreCase("mac")) {

			if (browser.equalsIgnoreCase("firefox")) {

				System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
				driver = new FirefoxDriver();

				// this is how applogs will be generated.
				app_logs.debug("opening the firefox browser");

			} else if (browser.equalsIgnoreCase("Chrome")) {

				System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver3");
				driver = new ChromeDriver();
			}
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		generic = new GenericMethods(driver);
		sAssertion = new SoftAssert();
		loginPage = new LoginPage(driver);
		logout = new LogOutPage(driver);
		
	}

	@AfterClass
	public void postCondtion() {
		driver.quit();
	}

	@BeforeMethod
	public void beforeMehtodLogin() {
		generic.explicitWait(1);
		driver.get(Config.BASE_UAM_URL);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		
		if (result.getStatus() == ITestResult.SUCCESS) {

	//		generic.writingACSTxnIDToExcell(XlFileName,"RBAScript", "AcsTxnId", invocationCount, generic.getACSTxnIDFromDB());

		} else if(result.getStatus() == ITestResult.FAILURE) {
			String methodName = result.getName().toString().trim();
			try {
				generic.CaptureScreenshot(driver, methodName);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		invocationCount++;
		logout.logout();
	//	driver.quit();

	}
}

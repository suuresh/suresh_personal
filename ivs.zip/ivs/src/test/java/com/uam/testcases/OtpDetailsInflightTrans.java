package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.LoginPage;
import com.uam.pages.OtpDetailDuringInfligtTran;

public class OtpDetailsInflightTrans extends ACSInitialSetUp {
	// WebDriver driver;
	// public String XlFileName = null;

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	String acsTxnId = null;
	String acsTxnIdFromOTPPage;
	String acsTxnIdFromHeaders;
	LogEntries NetWorklogs;
	String otpValue = null;
	String paReq = null;

	@BeforeMethod
	public void beforeAuthenticationMethod() throws Exception {
		driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
		System.out.println("Title of the page : " + driver.getTitle());

	}

	/*
	 * @BeforeMethod public void beforeTxnVerificationMethod() { driver = new
	 * ChromeDriver(); driver.get(Config.BASE_UAM_URL);
	 * driver.manage().window().maximize(); LoginPage loginPage = new
	 * LoginPage(driver); generic.explicitWait(1);
	 * loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME,
	 * Config.BASE_UAM_ADMIN_PASSWD);
	 * System.out.println("Successfully logged In: Page Title is :" +
	 * driver.getTitle());
	 * 
	 * }
	 */

	@DataProvider
	public Object[][] OtpDetailsDuringInfiligtTxn() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "OtpDetails");
	}

	@Test(dataProvider = "OtpDetailsDuringInfiligtTxn", priority = 1, enabled = true)
	public void OtpDetailsDuringInfiligtTxn(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String MerchantId,
			String MerchantName, String TransactionAmount, String CurrencyType, String CardUnion, String EmailId,
			String MobileNumber, String MaximumOtpAttempt, String ResendOTPCount, String InvalidOTPAttempts,
			String LastOTPStatusResend, String LastOTPStatusInvalid, String Desc) {

		/*
		 * driver = new ChromeDriver(); driver.get(Config.BASE_UAM_URL);
		 * driver.manage().window().maximize();
		 */
		/*
		 * LoginPage loginPage = new LoginPage(driver); generic.explicitWait(1);
		 * loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME,
		 * Config.BASE_UAM_ADMIN_PASSWD);
		 * System.out.println("Successfully logged In: Page Title is :" +
		 * driver.getTitle());
		 */
		// driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);

		ExtentTestManager.getTest().setDescription(Desc);
		SoftAssert sAssertion = new SoftAssert();
		// Initializing the page objects
		NewSimulatorCheckOutPage checkoutpage = new NewSimulatorCheckOutPage(driver);
		OtpDetailDuringInfligtTran otpDetail = new OtpDetailDuringInfligtTran(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);

		if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {

			String currentURL = null;
			invocationCount++;
			System.out.println("Merchant Name : " + MerchantName);
			Select merchantoptions = new Select(checkoutpage.getMerchantIdDropDown());
			merchantoptions.selectByVisibleText(MerchantName);

			System.out.println("Card Number : " + Cardnumber);
			checkoutpage.getCardNumberField().clear();
			checkoutpage.getCardNumberField().sendKeys(Cardnumber);

			checkoutpage.getCardExpiryField().clear();
			checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			System.out.println("Amout : " + TransactionAmount);
			checkoutpage.getPurchaseAmountField().clear();
			checkoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

			System.out.println("Currency : " + CurrencyType);
			checkoutpage.getCurrencyDropDown().click();
			Select currencyoptions = new Select(checkoutpage.getCurrencyDropDown());
			currencyoptions.selectByVisibleText(CurrencyType);

			System.out.println("Acquirer Bank Id : " + AccquirerBankId);
			checkoutpage.getAcquirerIDField().clear();
			checkoutpage.getAcquirerIDField().sendKeys(AccquirerBankId);
			System.out.println("Protocal Version : " + ProtocalVersion);

			checkoutpage.getSubmitPaReqButton().click();

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */
			try {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr1[] = tesdDecode.split("&");
				String testEncodedPaReq = arr1[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
				generic.explicitWait(2);
			} catch (Exception e) {
				System.out.println("Exception for 2.0: " + e);
			}
			System.out.println("ACS Txn Id is : " + acsTxnId);
			generic.explicitWait(2);

			otpValue = OTPFromEngine.getOTPFromEngine(Cardnumber, IssuerBankId, acsTxnId);

			/*
			 * otp.getOtpTextField().sendKeys(otpValue); generic.explicitWait(1);
			 * otp.getOtpSubmitButton().click()
			 */;
			// Resend OTP

			int n = Integer.parseInt(ResendOTPCount);
			for (int i = 1; i <= n; i++) {
				otpDetail.getOtpResendButton().click();
				generic.explicitWait(2);
			}

			// InValidOtp
			int v = Integer.parseInt(InvalidOTPAttempts);
			for (int j = 1; j <= v; j++) {
				otpDetail.getOtpTextField().clear();
				otpDetail.getOtpTextField().sendKeys("982312");
				otpDetail.getOtpSubmitButton().click();
			}

		} else {

			driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);
			generic.explicitWait(5);
			// initializing the page objects
			MPICheckOutPage mpiCheckoutpage = new MPICheckOutPage(driver);

			String currentURL = null;
			invocationCount++;

			System.out.println("Card Number : " + Cardnumber);
			mpiCheckoutpage.getCardNumberField().clear();
			mpiCheckoutpage.getCardNumberField().sendKeys(Cardnumber);

			generic.selectByVisibleText(mpiCheckoutpage.getMerchantTextField(), MerchantId);

			mpiCheckoutpage.getCardExpiryField().clear();
			mpiCheckoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			mpiCheckoutpage.getCardCVVField().clear();
			mpiCheckoutpage.getCardCVVField().sendKeys("111");

			mpiCheckoutpage.getQuantityField().clear();
			mpiCheckoutpage.getQuantityField().sendKeys("1");

			mpiCheckoutpage.getPurchaseAmountField().clear();
			mpiCheckoutpage.getPurchaseAmountField().sendKeys(TransactionAmount);

			generic.selectByVisibleText(mpiCheckoutpage.getCurrencyField(), "INR");
			generic.explicitWait(3);
			mpiCheckoutpage.getSubmitButton().click();
			generic.explicitWait(8);
			System.out.println("Clicked on Checkout button");

			// For Karnataka Bank

			if (IssuerBankId.equalsIgnoreCase("8131")) {
				driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
				generic.explicitWait(5);
			}
			MPIOTPPage otp = new MPIOTPPage(driver);
			if (String.valueOf(otp.getEnglishLangNBEbank().isDisplayed()).equalsIgnoreCase("true")) {
				// Change UI in English
				otp.getEnglishLangNBEbank().click();
			}

			/*
			 * Getting ACSTcnId from Pareq Date-28-07-2020
			 */
			try {

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);
			} catch (Exception x) {
				System.out.println("Exception for 2.0 " + x);
			}
			// Re-send OTP

			/*
			 * int n = Integer.parseInt(ResendOTPCount); for (int i = 1; i <= n; i++) {
			 * otpDetail.getOtpResendButton().click(); generic.explicitWait(2); }
			 * 
			 * // InValidOtp int v = Integer.parseInt(InvalidOTPAttempts); for (int j = 1; j
			 * <= v; j++) { otpDetail.getOtpTextField().clear();
			 * otpDetail.getOtpTextField().sendKeys("982312");
			 * otpDetail.getOtpSubmitButton().click(); }
			 */

			// Another approach
			otpDetail.getOtpResendButton().click();
			generic.explicitWait(2);
			otpDetail.getOtpResendButton().click();
			generic.explicitWait(2);
		}

		// Verify Otp Detail in Admin portal
		// driver = new ChromeDriver();

		/*
		 * driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		 * ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		 * driver.switchTo().window(tabs.get(0));
		 */

		/*
		 * driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");
		 * 
		 * Set<String> windowHandles = driver.getWindowHandles();
		 * 
		 * System.out.println(windowHandles.size());
		 * 
		 * for (String winHandle : driver.getWindowHandles()) {
		 * 
		 * driver.switchTo().window(winHandle); }
		 */

		/*
		 * String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN);
		 * driver.findElement(By.linkText("www.facebook.com")).sendKeys(
		 * selectLinkOpeninNewTab); generic.explicitWait(3);
		 */

		String currentWin = driver.getWindowHandle();
		System.out.println("currentWin: " + currentWin);

		((JavascriptExecutor) driver).executeScript("window.open()");

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));

		/*
		 * Set<String> tab = driver.getWindowHandles(); for (String win : tab) { if
		 * (!win.equals(tab)) { driver.switchTo().window(win);
		 */

		LoginPage lp = new LoginPage(driver);
		driver.get(Config.BASE_UAM_URL);
		// driver.manage().window().maximize();
		lp.getLoginIDTextField().sendKeys(Config.DCS_UAM_ADMIN_USER_NAME);
		lp.getPasswordTextField().sendKeys(Config.DCS_UAM_ADMIN_PASSWD);
		lp.getLoginButton().click();

		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}

		generic.explicitWait(3);

		// Navigating to Otp Usages
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();

		/*
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * js.executeScript("window.scrollBy(0,300)", "");
		 */

		/*
		 * Actions action = new Actions(driver);
		 * action.moveToElement(otpDetail.getOtpUsageReportSideLink()).build().perform()
		 * ; generic.explicitWait(2);
		 */

		// driver.findElement(By.xpath("(//ul[@class='submenu'])[1]")).sendKeys(Keys.PAGE_DOWN);

		otpDetail.getOtpUsageReportSideLink().click();
		generic.explicitWait(2);
		otpDetail.getOtpUsageCardNumber().clear();
		otpDetail.getOtpUsageCardNumber().sendKeys(Cardnumber);
		otpDetail.getOtpUsageSearchButton().click();
		generic.explicitWait(5);

		// Validate fields
		sAssertion.assertEquals(otpDetail.getOtpUsageAcsTxnIdText().getText(), acsTxnId, "Verifing Acs Txn Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageEmailIdText().getText(), EmailId, "Verifing Email Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageMobileNumberText().getText(), MobileNumber,
				"Verifing MobileNumber");
		sAssertion.assertEquals(otpDetail.getOtpUsageMaximumOtpAllowedText().getText(), MaximumOtpAttempt,
				"Verifing MaximumOtpAttempt");
		sAssertion.assertEquals(otpDetail.getOtpUsageResendOtpCountText().getText(), ResendOTPCount,
				"Verifing ResendOTPCount");
		/*
		 * sAssertion.assertEquals(otpDetail.getOtpUsageInvalidOtpAttemptsText().getText
		 * (), InvalidOTPAttempts, "Verifing InvalidOTPAttempts");
		 */
		sAssertion.assertEquals(otpDetail.getOtpUsageLastOTPStatusText().getText(), LastOTPStatusResend,
				"Verifing LastOTPStatus");
		// sAssertion.assertAll();
		generic.explicitWait(3);
		// logout.logout();
		// driver.close();
		generic.explicitWait(3);
		driver.switchTo().window(tabs.get(0));
		generic.explicitWait(4);

		// Invalid otp
		otpDetail.getOtpTextField().clear();
		otpDetail.getOtpTextField().sendKeys("982312");
		otpDetail.getOtpSubmitButton().click();
		generic.explicitWait(2);
		otpDetail.getOtpTextField().clear();
		otpDetail.getOtpTextField().sendKeys("982312");
		otpDetail.getOtpSubmitButton().click();

		generic.explicitWait(2);
		driver.switchTo().window(tabs.get(1));
		generic.explicitWait(2);

		otpDetail.getOtpUsageCardNumber().clear();
		otpDetail.getOtpUsageCardNumber().sendKeys(Cardnumber);
		otpDetail.getOtpUsageSearchButton().click();
		generic.explicitWait(5);

		// Validate fields
		sAssertion.assertEquals(otpDetail.getOtpUsageAcsTxnIdText().getText(), acsTxnId, "Verifing Acs Txn Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageEmailIdText().getText(), EmailId, "Verifing Email Id");
		sAssertion.assertEquals(otpDetail.getOtpUsageMobileNumberText().getText(), MobileNumber,
				"Verifing MobileNumber");
		sAssertion.assertEquals(otpDetail.getOtpUsageMaximumOtpAllowedText().getText(), MaximumOtpAttempt,
				"Verifing MaximumOtpAttempt");
		/*
		 * sAssertion.assertEquals(otpDetail.getOtpUsageResendOtpCountText().getText(),
		 * ResendOTPCount, "Verifing ResendOTPCount");
		 */
		sAssertion.assertEquals(otpDetail.getOtpUsageInvalidOtpAttemptsText().getText(), InvalidOTPAttempts,
				"Verifing InvalidOTPAttempts");
		sAssertion.assertEquals(otpDetail.getOtpUsageLastOTPStatusText().getText(), LastOTPStatusInvalid,
				"Verifing LastOTPStatus");

		generic.explicitWait(2);
		driver.switchTo().window(tabs.get(0));
		otpDetail.getOtpCancelButton().click();

		if (IssuerBankId.equalsIgnoreCase("8551")) {
			Alert cancelAlert = driver.switchTo().alert();
			cancelAlert.accept();
		}
		/*
		 * System.out.println("otpValue: "+otpValue);
		 * otpDetail.getOtpTextField().clear();
		 * otpDetail.getOtpTextField().sendKeys(otpValue);
		 * otpDetail.getOtpSubmitButton().click(); generic.explicitWait(2);
		 */

		sAssertion.assertAll();
	}

	/*
	 * driver.switchTo().window(currentWin); generic.explicitWait(3);
	 */
}
/*
 * @AfterClass public void afterMethod(ITestResult result) { //logout.logout();
 * //driver.quit(); //driver.close();
 * //System.out.println("Successfully logged out : Page Title is : " +
 * driver.getTitle());
 * 
 * 
 * 
 * }
 */

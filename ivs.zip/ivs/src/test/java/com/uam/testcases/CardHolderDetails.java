package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.CardHolderDetailsPage;
import com.uam.pages.LogOutPage;

public class CardHolderDetails extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	LogEntries NetWorklogs;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	String acsTxnId = null;

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] FetchCustomerDetailUsingMobile() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ManageCustomerDetails");
	}

	@Test(dataProvider = "FetchCustomerDetailUsingMobile", priority = 1, enabled = true)
	public void FetchCustomerDetailUsingMobile(String SN, String BankName, String MobileCode, String MobileNumber,
			String PartialMobileNum, String CardNumber, String Email_Id, String EditCardNumber, String UpdateMobile,
			String UpdateEmail, String UpdateMobileCode, String decs1, String desc2, String desc3) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs1);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		cardHolderDetailsPage.getManageCardHolderDetailsLink().click();

		// Fetch Customer details by Mobile number

		cardHolderDetailsPage.getMobileNumberTextfield().click();
		generic.explicitWait(1);
		System.out.println("MobileNumber" + MobileNumber);
		if (SN.equals("1")) {
			cardHolderDetailsPage.getMobileNumberTextfield().sendKeys(MobileNumber);
			generic.explicitWait(3);
		} else {
			cardHolderDetailsPage.getMobileNumberTextfield().sendKeys(PartialMobileNum);
			generic.explicitWait(3);
		}

		cardHolderDetailsPage.getSearchButton().click();
		generic.explicitWait(5);

		String expectedCard = CardNumber.substring(CardNumber.length() - 4);
		System.out.println("expectedCard:-" + expectedCard);

		String actualCard = driver
				.findElement(By.xpath(
						"//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard + "')]"))
				.getText();
		System.out.println("Card:" + actualCard);
		String actualEmail = driver
				.findElement(By.xpath("//div[text()='Email ID']/../following::div/div/div[contains(text(),'"
						+ expectedCard + "')]/following::div[6]"))
				.getText();

		System.out.println("Email:" + actualEmail);

		sAssertion.assertEquals(actualCard.substring(actualCard.length() - 4), expectedCard);
		sAssertion.assertEquals(actualEmail, Email_Id);
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] FetchCustomerDetailUsingCard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ManageCustomerDetails");
	}

	@Test(dataProvider = "FetchCustomerDetailUsingCard", priority = 2, enabled = true)
	public void FetchCustomerDetailUsingCard(String SN, String BankName, String MobileCode, String MobileNumber,
			String PartialMobileNum, String CardNumber, String Email_Id, String EditCardNumber, String UpdateMobile,
			String UpdateEmail, String UpdateMobileCode, String desc1, String desc2, String desc3) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(desc2);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		cardHolderDetailsPage.getManageCardHolderDetailsLink().click();

		// Fetch Customer details by Card
		cardHolderDetailsPage.getCardNumberTextfield().sendKeys(CardNumber);
		cardHolderDetailsPage.getSearchButton().click();
		generic.explicitWait(3);

		String expectedCard = CardNumber.substring(CardNumber.length() - 4);
		System.out.println("expectedCard:-" + expectedCard);

		String actualMobile = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[5]"))
				.getText();
		String actualEmail = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[6]"))
				.getText();

		String actualMobileWithoutSpChar = actualMobile.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println("MobileCode:-" + MobileCode);
		String expectedMobileWithoutSpChar = MobileCode + MobileNumber;
		System.out.println("actualMobileWithoutSpChar:-" + actualMobileWithoutSpChar);
		System.out.println("expectedMobileWithoutSpChar:-" + expectedMobileWithoutSpChar);
		sAssertion.assertEquals(actualMobileWithoutSpChar, expectedMobileWithoutSpChar);
		sAssertion.assertEquals(actualEmail, Email_Id);
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] EditCustomerDetail() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ManageCustomerDetails");
	}

	@Test(dataProvider = "EditCustomerDetail", priority = 3, enabled = true)
	public void EditCustomerDetail(String SN, String BankName, String MobileCode, String MobileNumber,
			String PartialMobileNum, String CardNumber, String Email_Id, String EditCardNumber, String UpdateMobile,
			String UpdateEmail, String UpdateMobileCode, String desc1, String desc2, String desc3) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(desc3);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(BankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(BankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		generic.explicitWait(2);
		cardHolderDetailsPage.getManageCardHolderDetailsLink().click();

		// Fetch Customer details by Card
		cardHolderDetailsPage.getCardNumberTextfield().sendKeys(EditCardNumber);
		cardHolderDetailsPage.getSearchButton().click();
		generic.explicitWait(3);

		String expectedCard = EditCardNumber.substring(EditCardNumber.length() - 4);
		System.out.println("expectedCard :" + expectedCard);

		// GdprDeteleButton verification
		boolean GdprDeteleButton = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div/div/div[@class='options__delete']"))
				.isEnabled();
		System.out.println("GdprDeteleButton: " + GdprDeteleButton);
		sAssertion.assertTrue(GdprDeteleButton, "GdprDeteleButton verification");

		// Click on edit
		driver.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
				+ "')]/following::div/div/div[@class='options__edit']")).click();

		// validating Mobile code drop-down list
		String validateMobCode = "+ 2";
		if (SN.equalsIgnoreCase("1")) {
			ArrayList<String> list = new ArrayList<String>();
			cardHolderDetailsPage.getMobileCodeDropdown().click();
			List<WebElement> mobileCodeList = driver.findElements(By.xpath("//label[@class='radio-label']"));
			for (WebElement mobileCode : mobileCodeList) {
				list.add(mobileCode.getText());

			}
			boolean codeValidate = list.contains(validateMobCode);
			sAssertion.assertTrue(codeValidate, "+2 code validation ");
			System.out.println("codeValidate :-" + codeValidate);
			System.out.println("MobileCodeList:" + list);
			cardHolderDetailsPage.getMobileCodeDropdown().click();
		}

		// Update MobileCode and Mobile Number
		cardHolderDetailsPage.getMobileCodeDropdown().click();
		cardHolderDetailsPage.getMobileCodeSearchField().sendKeys(UpdateMobileCode);
		cardHolderDetailsPage.getFirstMobileCodelist().click();

		cardHolderDetailsPage.getEditMobileTextfield().clear();
		cardHolderDetailsPage.getEditMobileTextfield().sendKeys(UpdateMobile);

		// Update Email
		cardHolderDetailsPage.getEditEmailTextfield().clear();
		cardHolderDetailsPage.getEditEmailTextfield().sendKeys(UpdateEmail);

		// Click on Save
		cardHolderDetailsPage.getSaveChangesButton().click();

		// Capturing time at action performed
		/*
		 * DateTimeFormatter dtf = DateTimeFormatter.ofPattern("DD-MM-YYYY | HH:mm:ss");
		 * LocalDateTime now = LocalDateTime.now(); String DT = dtf.format(now); String
		 * ActualtimeAtActionPerformed = DT.substring(0, DT.length() - 3);
		 * System.out.println("timeAtActionPerformed " + ActualtimeAtActionPerformed);
		 */

		Date date = new Date();
		SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
		String DateandTimeWhileEdit = DateFor.format(date);

		DateFor = new SimpleDateFormat("ddMMMMyyyy|HH:mm");
		DateandTimeWhileEdit = DateFor.format(date);
		System.out.println("DateandTimeWhileEdit  : " + DateandTimeWhileEdit);

		generic.explicitWait(8);
		cardHolderDetailsPage.getCardNumberTextfield().sendKeys(EditCardNumber);
		cardHolderDetailsPage.getSearchButton().click();

		generic.explicitWait(5);

		String expectedMobileWithoutSpChar = UpdateMobileCode + UpdateMobile;
		String expectedEmail = UpdateEmail;

		System.out.println("expectedMobileWithoutSpChar:-" + expectedMobileWithoutSpChar);
		System.out.println("expectedEmail:-" + expectedEmail);

		// Validating Last update date and time
		String lastUpdateDateAndTime = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[2]"))
				.getText();
		// String expectedLastUpdatedDateandTime = lastUpdateDateAndTime.substring(0,
		// DT.length() - 3);
		// System.out.println("Date and Time:-" + expectedLastUpdatedDateandTime);

		String actualMobile = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[5]"))
				.getText();
		String actualEmail = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[6]"))
				.getText();

		String actualMobileWithoutSpChar = actualMobile.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println("actualMobileWithoutSpChar:-" + actualMobileWithoutSpChar);
		System.out.println("actualEmail:-" + actualEmail);

		// sAssertion.assertEquals(ActualtimeAtActionPerformed,
		// expectedLastUpdatedDateandTime);
		sAssertion.assertEquals(actualMobileWithoutSpChar, expectedMobileWithoutSpChar);
		sAssertion.assertEquals(actualEmail, expectedEmail);
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] CreateCardInAdmin() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateCardAdmin");
	}

	@Test(dataProvider = "CreateCardInAdmin", priority = 4, enabled = true)
	public void CreateCardInAdmin(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String TemplateType, String MobileCode, String MobileNumber,
			String ProtocolVersion, String IssuerBin, String CardNumber, String Email_Id, String Desc) {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(Desc);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);
		invocationCount++;
		GenericMethods.writingToExcel(XlFileName, "CreateCardAdmin", "CardNumber", invocationCount, "");

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		adminhomepage.getAddACardLink().click();
		generic.explicitWait(2);
		// cardHolderDetailsPage.getManageCardHolderDetailsLink().click();
		// long randomNumber = GenericMethods.generateRandomDigits(10);
		long randomNumber = (long) (Math.random() * 100000 + 4533300000L);
		System.out.println("Random number : " + randomNumber);
		String createdCardNumber = IssuerBin + randomNumber;
		System.out.println("Card numbers is : " + createdCardNumber);

		generic.explicitWait(1);
		cardHolderDetailsPage.getCreateCardTextField().sendKeys(createdCardNumber);
		cardHolderDetailsPage.getCreateCardDetailsMobileCodeDropDown().click();
		cardHolderDetailsPage.getCreateCardDetailsMobileCountryCodeTextField().sendKeys(MobileCode);

		WebElement radio = driver.findElement(By.xpath("//label[text()='+" + MobileCode + "']"));
		radio.click();

		// cardHolderDetailsPage.getCreateCardDetailsMobileCountryCodeRadioButton().click();
		cardHolderDetailsPage.getCreateCardDetailsMobileNumberTextField().sendKeys(MobileNumber);
		cardHolderDetailsPage.getCreateCardDetailsEmailTextField().sendKeys(Email_Id);
		// cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		generic.explicitWait(5);

		// Fetch Customer details by Card
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		cardHolderDetailsPage.getManageCardHolderDetailsLink().click();
		cardHolderDetailsPage.getCardNumberTextfield().sendKeys(createdCardNumber);
		cardHolderDetailsPage.getSearchButton().click();
		generic.explicitWait(3);

		String expectedCard = createdCardNumber.substring(createdCardNumber.length() - 4);
		System.out.println("expectedCard:-" + expectedCard);

		String actualMobile = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[5]"))
				.getText();
		String actualEmail = driver
				.findElement(By.xpath("//div[text()='PAN']/../following::div/div/div[contains(text(),'" + expectedCard
						+ "')]/following::div[6]"))
				.getText();

		String actualMobileWithoutSpChar = actualMobile.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println("MobileCode:-" + MobileCode);
		String expectedMobileWithoutSpChar = MobileCode + MobileNumber;
		System.out.println("actualMobileWithoutSpChar:-" + actualMobileWithoutSpChar);
		System.out.println("expectedMobileWithoutSpChar:-" + expectedMobileWithoutSpChar);
		sAssertion.assertEquals(actualMobileWithoutSpChar, expectedMobileWithoutSpChar);
		sAssertion.assertEquals(actualEmail, Email_Id);

		GenericMethods.writingToExcel(XlFileName, "CreateCardAdmin", "CardNumber", invocationCount, createdCardNumber);
		sAssertion.assertAll();

	}

	@Test(priority = 5, enabled = true)
	public void CreateCardInAdminFieldValidation() {
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription("Filed Vaidation for Create Card in Admin");
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		CardHolderDetailsPage cardHolderDetailsPage = new CardHolderDetailsPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys("National Bank");
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase("National Bank")) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ManageBlockCard
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getOperationsLink().click();
		adminhomepage.getAddACardLink().click();
		generic.explicitWait(2);
		// cardHolderDetailsPage.getManageCardHolderDetailsLink().click();
		long randomNumber = GenericMethods.generateRandomDigits(10);
		System.out.println("Random number : " + randomNumber);
		// String createdCardNumber = IssuerBin + randomNumber;
		// System.out.println("Card numbers is : "+createdCardNumber);
		cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		generic.explicitWait(1);

		// implement alert

		String validateMessage = driver
				.findElement(
						By.xpath("//div[@class='Toastify__toast-container Toastify__toast-container--top-center']"))
				.getText();
		System.out.println("validateMessage:-" + validateMessage);
		String message = "Please enter valid Account Number";

		sAssertion.assertTrue(validateMessage.contains(message));
		generic.explicitWait(10);

		cardHolderDetailsPage.getCreateCardTextField().sendKeys(randomNumber + "");
		cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		generic.explicitWait(2);

		validateMessage = driver
				.findElement(
						By.xpath("//div[@class='Toastify__toast-container Toastify__toast-container--top-center']"))
				.getText();
		System.out.println("validateMessage:-" + validateMessage);
		message = "Please enter valid Mobile Number";

		sAssertion.assertTrue(validateMessage.contains(message));
		generic.explicitWait(10);

		cardHolderDetailsPage.getCreateCardDetailsMobileNumberTextField().sendKeys(randomNumber + "");
		cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		generic.explicitWait(2);

		validateMessage = driver
				.findElement(
						By.xpath("//div[@class='Toastify__toast-container Toastify__toast-container--top-center']"))
				.getText();
		System.out.println("validateMessage:-" + validateMessage);
		message = "Not able to create as cardnumber is not matching the bins under the binlist";

		sAssertion.assertTrue(validateMessage.contains(message));

		/*
		 * // cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileCodeRequiredErrorTxtMsg().getText(),
		 * "1. Mobile Code is a required property");
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileRequiredErrorTxtMsg().getText(),
		 * "2. Mobile is a required property");
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsAccountNumberRequiredErrorTxtMsg().getText(),
		 * "3. AccountNumber is a required property");
		 * cardHolderDetailsPage.getCreateCardTextField().sendKeys("12345678910"); //
		 * cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		 * cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		 * 
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileCodeRequiredErrorTxtMsg().getText(),
		 * "1. Mobile Code is a required property");
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileRequiredErrorTxtMsg().getText(),
		 * "2. Mobile is a required property");
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsAccountNumberRequiredErrorTxtMsg().getText(),
		 * "3. AccountNumber should NOT be shorter than 12 characters");
		 * cardHolderDetailsPage.getCreateCardTextField().sendKeys("123456789101");
		 * cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		 * 
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileCodeRequiredErrorTxtMsg().getText(),
		 * "1. Mobile Code is a required property",
		 * "After Entering the Account number 12 digits.");
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileRequiredErrorTxtMsg().getText(),
		 * "2. Mobile is a required property",
		 * "After Entering the Account number 12 digits.");
		 * 
		 * cardHolderDetailsPage.getCreateCardDetailsMobileCodeDropDown().click();
		 * cardHolderDetailsPage.getCreateCardDetailsMobileCountryCodeTextField().
		 * sendKeys("91");
		 * cardHolderDetailsPage.getCreateCardDetailsMobileCountryCodeRadioButton().
		 * click(); // cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		 * cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		 * 
		 * sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileOnlyRequiredErrorTxtMsg().getText(),
		 * "1. Mobile is a required property"); generic.explicitWait(2);
		 * cardHolderDetailsPage.getCreateCardDetailsMobileNumberTextField().sendKeys(
		 * "12345"); System.out.println("Entered 5 digits to mobile number field");
		 * cardHolderDetailsPage.getCreateCardDetailsPlusButton().click(); //
		 * cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		 * generic.explicitWait(2); sAssertion.assertEquals(cardHolderDetailsPage.
		 * getCreateCardDetailsMobileNumberLengthErrorTxtMsg().getText(),
		 * "1. Mobile should NOT be shorter than 6 characters");
		 * cardHolderDetailsPage.getCreateCardDetailsMobileNumberTextField().clear();
		 * cardHolderDetailsPage.getCreateCardDetailsMobileNumberTextField().sendKeys(
		 * "123456"); // cardHolderDetailsPage.getCreateCardDetailsSaveButton().click();
		 * cardHolderDetailsPage.getCreateCardDetailsPlusButton().click();
		 */
		sAssertion.assertAll();

	}

	@AfterMethod
	public void logout() {
		LogOutPage logout = new LogOutPage(driver);
		logout.logout();
		System.out.println("Sucessfully Logout");
	}

}

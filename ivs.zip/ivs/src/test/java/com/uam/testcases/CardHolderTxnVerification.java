package com.uam.testcases;

import java.io.IOException;
import java.net.URLDecoder;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.pages.MPICheckOutPage;
import com.acs.pages.MPIOTPPage;
import com.acs.pages.MPIResponsePage;
import com.acs.pages.NewSimulatorCheckOutPage;
import com.acs.pages.NewSimulatorOTPPage;
import com.acs.pages.NewSimulatorResponsePage;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.acs.utils.GetHeaderPartTwo;
import com.acs.utils.GetHeaders;
import com.acs.utils.OTPFromEngine;
import com.acs.utils.RFC;
import com.uam.pages.AdminHomePage;
import com.uam.pages.CardHolderDetailsPage;

public class CardHolderTxnVerification extends ACSInitialSetUp{
	
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;
	LogEntries NetWorklogs;
	String otpValue = null;
	String transactionStatus = null;
	String paReq = null;
	String acsTxnId = null;
	
	@DataProvider
	public Object[][] CreateCardDetails() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateCardAdmin");
	}
	
	
	@Test(dataProvider = "CreateCardDetails", priority = 6, enabled = true)
	public void TransactionVerification(String IssuerBankId, String IssuerBankName,String AccquirerBankId,String AcquirerBankName,
			String TemplateType, String MobileCode, String MobileNumber, String ProtocolVersion, String IssuerBin, 
			String CardNumber, String Email_Id, String Desc){
		System.out.println("=======Navigating to ManageCardHolderDetails=======");

		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(ProtocolVersion+" Registered card transactions Verification ");
		
		NewSimulatorCheckOutPage checkoutpage2 = new NewSimulatorCheckOutPage(driver);
		NewSimulatorOTPPage otp2 = new NewSimulatorOTPPage(driver);
		NewSimulatorResponsePage responsepage2 = new NewSimulatorResponsePage(driver);
		GetHeaders getHeaders = new GetHeaders(driver);
		GetHeaderPartTwo getHeaderPartTwo = new GetHeaderPartTwo(driver);
		MPICheckOutPage checkoutpage = new MPICheckOutPage(driver);
		MPIResponsePage responsepage = new MPIResponsePage(driver);
		MPIOTPPage otp = new MPIOTPPage(driver);
		String currentURL2 = null;
		// Selecting a bank
		generic.explicitWait(3);
		if (ProtocolVersion.equalsIgnoreCase("1.0.2")) {
			driver.get(Config.BASE_MPI_SIMULATOR_TRANSACTION_URL);

			String currentURL = null;
			invocationCount++;

			System.out.println("Card Number : " + CardNumber);
			checkoutpage.getCardNumberField().clear();
			checkoutpage.getCardNumberField().sendKeys(CardNumber);

			generic.selectByVisibleText(checkoutpage.getMerchantTextField(), "Federal_acs2stg");

			checkoutpage.getCardExpiryField().clear();
			checkoutpage.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			checkoutpage.getCardCVVField().clear();
			checkoutpage.getCardCVVField().sendKeys("111");

			checkoutpage.getQuantityField().clear();
			checkoutpage.getQuantityField().sendKeys("1");

			checkoutpage.getPurchaseAmountField().clear();
			checkoutpage.getPurchaseAmountField().sendKeys("15000");

			generic.selectByVisibleText(checkoutpage.getCurrencyField(), "INR");
			// putting try catch block to handle pop-up
			try {

				checkoutpage.getSubmitButton().click();
				generic.explicitWait(5);
				System.out.println("Clicked on Checkout button");

				// For Karnataka Bank
				if (IssuerBankId.equalsIgnoreCase("8131")) {
					driver.findElement(By.xpath("//input[@id='submitBtn']")).click();
					generic.explicitWait(8);
				}

				/*
				 * Getting ACSTcnId from Pareq Date-28-07-2020
				 */

				NetWorklogs = driver.manage().logs().get("performance");
				System.out.println("NETWORK LOGS: " + NetWorklogs);
				currentURL = driver.getCurrentUrl();
				System.out.println("Current URL : " + currentURL);
				paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL, IssuerBankId, NetWorklogs);
				System.out.println("Pareq:-" + paReq);
				String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
				// System.out.println("tesdDecode:-" + tesdDecode);
				String arr[] = tesdDecode.split("&");
				String testEncodedPaReq = arr[0];
				String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
				System.out.println("testDecodedPareq:-" + testDecodedPareq);
				acsTxnId = generic.getValueFromXml(testDecodedPareq);
				System.out.println("acsTxnId:-" + acsTxnId);

					generic.explicitWait(2);
					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);
					otpValue = OTPFromEngine.getOTPFromEngine(CardNumber, IssuerBankId, acsTxnId);
					otp.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);
					if (TemplateType.equalsIgnoreCase("Rocker")) {
						otp.getRkrotpSubmitButton().click();
					} else {
						otp.getTmlotpSubmitButton().click();
						generic.explicitWait(2);
					}
					
					sAssertion.assertTrue(responsepage.getSuccessTransactionStatus().getText().contains("Status : Y"),
							"Transaction staty Y verification");

			} catch (Exception e) {
				System.out.println("Handling unexpected popup");
				/*
				 * Alert alert = driver.switchTo().alert(); System.out.println("Type of alert: "
				 * + alert.getText()); alert.accept();
				 */
				ErrorCollector.addVerificationFailure(e);
			}

			// driver.close();

			// Verify Hard block in Admin portal

		} else if (ProtocolVersion.equalsIgnoreCase("2.1.0")) {
			driver.get(Config.BASE_NEW_SIMULATOR_TRANSACTION_URL);
			System.out.println("Merchant Name : " + "OLX");
			Select merchantoptions = new Select(checkoutpage2.getMerchantIdDropDown());
			merchantoptions.selectByVisibleText("AmazonIndia");

			System.out.println("Card Number : " + CardNumber);
			checkoutpage2.getCardNumberField().clear();
			checkoutpage2.getCardNumberField().sendKeys(CardNumber);

			checkoutpage2.getCardExpiryField().clear();
			checkoutpage2.getCardExpiryField().sendKeys(Config.CARD_EXPIRY_DATE);

			checkoutpage2.getPurchaseAmountField().clear();
			checkoutpage2.getPurchaseAmountField().sendKeys("12345");

			checkoutpage2.getCurrencyDropDown().click();
			Select currencyoptions = new Select(checkoutpage2.getCurrencyDropDown());
			currencyoptions.selectByVisibleText("INR");

			System.out.println("Acquirer Bank Id : " + AccquirerBankId);
			checkoutpage2.getAcquirerIDField().clear();
			checkoutpage2.getAcquirerIDField().sendKeys(AccquirerBankId);
			System.out.println("Protocal Version : " + ProtocolVersion);

			// putting try catch block to handle popup
			try {
				String versionCheckUrl = checkoutpage2.getVersionCheckURLFeild().getAttribute("value");
				System.out.println("Version check url from simulator : " + versionCheckUrl);
				String arr[] = versionCheckUrl.split("pVrq/");
				System.out.println("Splitter version Check url is : " + arr[0]);
				String desiredVersionCheckUrl = arr[0] + "pVrq/" + AccquirerBankId;
				System.out.println("Desired version check url is : " + desiredVersionCheckUrl);
				checkoutpage2.getVersionCheckURLFeild().clear();
				checkoutpage2.getVersionCheckURLFeild().sendKeys(desiredVersionCheckUrl);
				checkoutpage2.getSubmitButton().click();

				System.out.println("Clicked on Checkout button");

					if (ProtocolVersion.equalsIgnoreCase("2.1.0")) {
						// generic.explicitWait(3);
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						acsTxnId = getHeaders.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						// generic.explicitWait(2);
					} else {
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[contains(text(),'CONFIRM')]")));
						// acsTxnId = ((JavascriptExecutor) driver).executeScript("return
						// document.getElementByName('acctId').value").toString();
						// acsTxnId = otp.getAcsTxnIdXpath().getAttribute("value");
						System.out.println("Clicked on Checkout button");

						/*
						 * Getting ACSTcnId from Pareq Date-28-07-2020
						 */

						NetWorklogs = driver.manage().logs().get("performance");
						System.out.println("NETWORK LOGS: " + NetWorklogs);
						currentURL2 = driver.getCurrentUrl();
						System.out.println("Current URL : " + currentURL2);
						paReq = getHeaderPartTwo.getACSTxnIDFromHeaders(currentURL2, IssuerBankId, NetWorklogs);
						System.out.println("Pareq:-" + paReq);
						String tesdDecode = URLDecoder.decode(paReq, "UTF-8");
						// System.out.println("tesdDecode:-" + tesdDecode);
						String arr1[] = tesdDecode.split("&");
						String testEncodedPaReq = arr1[0];
						String testDecodedPareq = RFC.decodeAndDecompress(testEncodedPaReq);
						System.out.println("testDecodedPareq:-" + testDecodedPareq);
						acsTxnId = generic.getValueFromXml(testDecodedPareq);
						System.out.println("acsTxnId:-" + acsTxnId);
						generic.explicitWait(2);
					}

					System.out.println("ACS Txn Id is : " + acsTxnId);
					generic.explicitWait(2);

					otpValue = OTPFromEngine.getOTPFromEngine(CardNumber, IssuerBankId, acsTxnId);

					otp2.getOtpTextField().sendKeys(otpValue);
					generic.explicitWait(1);

					otp2.getOtpSubmitButton().click();
					sAssertion.assertEquals(responsepage2.getTransactionStatusValue().getText(), "Y");
				
			} catch (UnhandledAlertException u) {
				System.out.println("Handling unexpected popup");

				Alert alert = driver.switchTo().alert();
				System.out.println("Type of alert: " + alert.getText());
				alert.accept();

				ErrorCollector.addVerificationFailure(u);
			} catch (Exception e) {
				System.out.println("Handling unexpected popup" + e);

			}
		}
		
		sAssertion.assertAll();
		
	}



}

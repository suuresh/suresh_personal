package com.uam.testcases;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AcsSmsMisPage;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminHomePage;

public class AcsSmsMis extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);

	static String cDay = null;
	static String cMonth = null;
	static String nMonth = null;
	static String cYear = null;
	static String cHour = null;
	static String cMinutes = null;
	static String cSeconds = null;

	static String utcDay = null;
	static String utcMonth = null;
	static String utcYear = null;
	static String utcHour = null;
	static String utcMinutes = null;
	static String ucSeconds = null;

	public static String ReportResultIVSOTP = null;
	public static String ReportResultIVR = null;
	public static String ReportResultExpressPay = null;
	public static String ReportResultOTPOneTimePasswordAlert = null;
	public static String ReportResultTotalSMSCount = null;

	/*
	 * public static String totalNoIVSOTP(String schema) {
	 * 
	 * String NoIVSOTP = "SELECT count(*) FROM " + schema + ".sent_alert_details_" +
	 * utcYear + "" + nMonth + " where date_time between '" + utcYear + "-" + nMonth
	 * + "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour +
	 * ":" + utcMinutes + "'  and alert_type_id=1 and event_id=100001"; return
	 * NoIVSOTP; }
	 */
	public static String totalNoIVSOTP(String IssuerBankId, String Schema) {

		String NoIVSOTP = "SELECT sum(ceiling(template_length/160)) FROM " + Schema + ".sent_alert_details_" + utcYear
				+ "" + nMonth + " where bank_id = " + IssuerBankId + " and date_time between '" + utcYear + "-" + nMonth
				+ "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "'  and alert_type_id=1 and event_id=100001 and  mobile_number IS NOT NULL";
		System.out.println(NoIVSOTP);
		return NoIVSOTP;
	}

	public static String totalNoIVR(String IssuerBankId, String Schema) {

		String NoIVR = "SELECT sum(ceiling(template_length/160)) FROM " + Schema + ".sent_alert_details_" + utcYear + ""
				+ nMonth + " where bank_id = " + IssuerBankId + " and date_time between '" + utcYear + "-" + nMonth
				+ "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes
				+ "'  and alert_type_id=1 and event_id=100002 and  mobile_number IS NOT NULL";

		return NoIVR;
	}

	public static String totalNoExpressPay(String IssuerBankId, String Schema) {

		String NoExpressPay = "SELECT sum(ceiling(template_length/160)) FROM " + Schema + ".sent_alert_details_"
				+ utcYear + "" + nMonth + " where bank_id = " + IssuerBankId + " and date_time between '" + utcYear
				+ "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth + "-" + cDay + " " + utcHour + ":"
				+ utcMinutes + "'  and alert_type_id=1 and event_id=100003 and  mobile_number IS NOT NULL";

		return NoExpressPay;
	}

	public static String templateLength(String schema) {

		String templateLen = "SELECT template_length FROM " + schema + ".sent_alert_details_" + utcYear + "" + nMonth
				+ " where date_time between '" + utcYear + "-" + nMonth + "-01 00:00' and '" + cYear + "-" + nMonth
				+ "-" + cDay + " " + utcHour + ":" + utcMinutes + "'  and alert_type_id=1 and event_id=100001";
		return templateLen;
	}

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] validateSmsMisReport() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "AcsSmsMIS");
	}

	@Test(dataProvider = "validateSmsMisReport", priority = 1, enabled = true)
	public void validateSmsMisReport(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AcsSmsMisPage acsMisSmsPage = new AcsSmsMisPage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsMisSmsPage.getAcsSmsMisSedeLink().click();
		generic.explicitWait(2);

		acsMisSmsPage.getDatePicker().click();
		generic.explicitWait(2);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(2);

		// int tempLen =
		// Integer.parseInt(DBConnection.getValueFromDB(AcsSmsMis.templateLength(Schema)));
		// System.out.println("tempLen: "+tempLen);

		if (driver.findElements(By.xpath("//*[@role='alert']")).size() > 0) {

			System.out.println("Pop-up Box");
			String popupText = driver.findElement(By.xpath("//*[@role='alert']")).getText();			
			sAssertion.assertEquals(popupText, "Sorry. No data is available for the date and time range specified.",
					"Validating pop-up message");

		} else {
			generic.explicitWait(8);
			// Fetching values from DB
			System.out.println("----IVS Otp result----");
			ReportResultIVSOTP = DBConnection.getValueFromDB(AcsSmsMis.totalNoIVSOTP(IssuerBankId, Schema));
			System.out.println("ivsOtpDBValue" + ReportResultIVSOTP);
			String IvsOtpUIValue = acsMisSmsPage.getIvsOtpValue().getText();
			System.out.println("IvsOtpUIValue: - " + IvsOtpUIValue);
			sAssertion.assertEquals(ReportResultIVSOTP, IvsOtpUIValue, "ReportResultIVSOTP");

			// Other approach
			/*
			 * if (tempLen <= 160) { ReportResultIVSOTP =
			 * DBConnection.getValueFromDB(AcsSmsMis.totalNoIVSOTP(Schema)); String
			 * IvsOtpUIValue = acsMisSmsPage.getIvsOtpValue().getText();
			 * System.out.println("IvsOtpUIValue: - " + IvsOtpUIValue);
			 * sAssertion.assertEquals(ReportResultIVSOTP, IvsOtpUIValue,
			 * "ReportResultIVSOTP"); } else if (tempLen > 160) { int IvsOtp =
			 * Integer.parseInt(DBConnection.getValueFromDB(AcsSmsMis.totalNoIVSOTP(Schema))
			 * ); ReportResultIVSOTP = Integer.toString(IvsOtp * 2); String IvsOtpUIValue =
			 * acsMisSmsPage.getIvsOtpValue().getText();
			 * System.out.println("IvsOtpUIValue: - " + IvsOtpUIValue);
			 * sAssertion.assertEquals(ReportResultIVSOTP, IvsOtpUIValue,
			 * "ReportResultIVSOTP"); }
			 */

			if (driver.findElements(By.xpath("//td[text()='IVR']/following::td[1]")).size() >= 1) {
				System.out.println("----IVR result----");
				ReportResultIVR = DBConnection.getValueFromDB(AcsSmsMis.totalNoIVR(IssuerBankId, Schema));
				System.out.println("ivrOtpDBValue" + ReportResultIVR);
				String IvrOtpUIValue = acsMisSmsPage.getIvrOtpValue().getText();
				System.out.println("ivrOtpUIValue:-" + IvrOtpUIValue);
				sAssertion.assertEquals(ReportResultIVR, IvrOtpUIValue, "ReportResultIVR");
			}

			if (driver.findElements(By.xpath("//td[text()='ExpressPay']/following::td[1]")).size() >= 1) {
				System.out.println("----ExpressPay result----");
				ReportResultExpressPay = DBConnection.getValueFromDB(AcsSmsMis.totalNoExpressPay(IssuerBankId, Schema));
				System.out.println("ExpressPayOtpDBValue" + ReportResultExpressPay);
				String ExpressPayUIValue = acsMisSmsPage.getExpressPayValue().getText();
				System.out.println("ExpressPayUIValue:-" + ExpressPayUIValue);
				sAssertion.assertEquals(ReportResultExpressPay, ExpressPayUIValue, "ReportResultExpressPay");
			}			
		}
		sAssertion.assertAll();

	}
}

package com.uam.testcases;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;

import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class ACSTxnVerification extends ACSInitialSetUp {
	/* Modified By Suuresh */
	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 1;

	@BeforeMethod
	public void beforeTxnVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
		System.out.println("Successfully logged In: Page Title is :" + driver.getTitle());

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, ACSTxn2_0SheetName);
	}

	@Test(dataProvider = "DataSet")
	public void adminTxnVerification(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String ErrorDescription, String EmailID,
			String MobileNumber, String MaximumAllowedOTPAttempts, String ResendOTPCount, String InvalidOTPAttempts,
			String LastOTPStatus, String AATransStatus, String CCTransStatus, String RRTransStatus, String AuditLog, String acsTxnId,
			String CavvOrAvv, String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion,
			String decs) throws Exception {
		System.out.println("*********************Test Started**************************");

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		invocationCount++;
		System.out.println("Invocation count: " + invocationCount);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//span[contains(@class,'dropdown-header-item')]")));
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);
		if (IssuerBankId.equalsIgnoreCase("8271")) {
			/*
			 * driver.findElement(By.xpath("//span[text()='" + IssuerBankName + " Bank" +
			 * "']")).click();
			 */
			driver.findElement(By.xpath("//span[contains(text(),'" + IssuerBankName + "')]")).click();
		} else {
			List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
			for (WebElement bankName : bankList) {
				if (bankName.getText().equalsIgnoreCase(IssuerBankName)
						|| bankName.getText().toLowerCase().contains(IssuerBankName.toLowerCase())) {
					bankName.click();
					break;
				}
			}
		}
		// driver.findElement(By.xpath("//div[contains(@class,'is-active')]//div[@id='dropdown-menu']//a[1]")).click();
		sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessageTitle().getText(), "WELCOME TO ACCOSA IVSTM");
		if (IssuerBankId.equalsIgnoreCase("8271") || IssuerBankId.equalsIgnoreCase("8234")) {
			System.out.println("Bank Name is not validating for saib bank");
		} else {
			sAssertion.assertEquals(adminhomepage.getHomepageWelcomeMessage().getText(),
					"Currently selected bank is " + IssuerBankName);
		}

		// adminhomepage.getAcsIssuerBankNameLinkInDropDown().click();
		// adminhomepage.getFederalACSBankLink().click();
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		//adminhomepage.getAcsTransactionReportLink().click();
		List<WebElement> btns = driver.findElements(By.xpath("//li[contains(text(), 'Transaction Report')]"));
		for (WebElement btn : btns) {
			if (btn.getText().equalsIgnoreCase("Transaction Report")) {
				System.out.println(btn.getText());
				//btn.click();
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", btn);
				break;
			}
		}
		generic.explicitWait(1);
		System.out.println("Clicked on Transactions Report Link");
		System.out.println("Flow is : " + Flow);
		acsTxnPage.getAcsResetButton().click();
		generic.explicitWait(1);
		acsTxnPage.getAcsCalenderIcon().click();
		generic.explicitWait(1);
		acsTxnPage.getAcsLeftHoursSelect().click();
		Select acsLeftHoursOptions = new Select(acsTxnPage.getAcsLeftHoursSelect());
		acsLeftHoursOptions.selectByValue("0");
		acsTxnPage.getApplyButton().click();

		acsTxnPage.getAcsAdevanceSearchButton().click();
		acsTxnPage.getCardNumberTextField().sendKeys(Cardnumber);
		System.out.println("Card Number : " + Cardnumber);
		acsTxnPage.getAcsTxnIDTextField().clear();
		if (acsTxnId.equalsIgnoreCase("null") || acsTxnId == "") {
			System.out.println("Acs txn id is null ");
		} else {
			System.out.println("acsTxnId::"+acsTxnId);
			acsTxnPage.getAcsTxnIDTextField().sendKeys(acsTxnId);			
			acsTxnPage.getFetchReportButton().click();
			generic.explicitWait(4);
			System.out.println("Clicked on Fetch Report button");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)", "");

			generic.explicitWait(2);
			// int doubleAmount = Integer.parseInt(amount);
			String firstSixDigitsOfTheCardNumber = Cardnumber.substring(0, 6);
			String lastFourDigitsOfTheCardNumber = Cardnumber.substring(12, 16);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//div[contains(@class,'flex-table__body')]/div[1]/div[3]")));

			System.out.println(firstSixDigitsOfTheCardNumber);
			System.out.println(lastFourDigitsOfTheCardNumber);
			System.out.println(acsTxnPage.getTxnRecordCardNumber().getText());
			System.out.println("************************");
			System.out.println(ProtocalVersion);
			System.out.println(acsTxnPage.getTxnRecordProtocalVersion().getText());
			System.out.println("************************");
			System.out.println(merchantname.toLowerCase());
			System.out.println(acsTxnPage.getTxnRecordMerchantName().getText().toLowerCase());
			System.out.println("************************");
			System.out.println(String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);
			System.out.println(acsTxnPage.getTxnRecordTxnAmount().getText());
			System.out.println("************************");

			if (acsTxnPage.getTxnRecordCardNumber().getText().contains("xxxx")) {
				sAssertion.assertEquals(acsTxnPage.getTxnRecordCardNumber().getText(),
						firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber);
			} else {
				sAssertion.assertEquals(acsTxnPage.getTxnRecordCardNumber().getText(), Cardnumber);
			}

			sAssertion.assertEquals(acsTxnPage.getTxnRecordProtocalVersion().getText(), ProtocalVersion);
			sAssertion.assertEquals(acsTxnPage.getTxnRecordMerchantName().getText().toLowerCase(),
					merchantname.toLowerCase());

			if (IssuerBankId.contentEquals("8527") || IssuerBankId.contentEquals("8618")) {
				System.out.println(new BigDecimal(new BigInteger(amount), 2) + " " + currencytype);

				sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnAmount().getText(),
						new BigDecimal(new BigInteger(amount), 2) + " " + currencytype);
			} else {
				sAssertion.assertEquals(acsTxnPage.getTxnRecordTxnAmount().getText(),
						String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);
			}

			// sAssertion.assertEquals(acsTxnPage.getTxnRecordAuthType().getText().toLowerCase(),
			// Flow.toLowerCase());
			// sAssertion.assertEquals(acsTxnPage.getTxnRecordStatus().getAttribute("data-tip"),
			// "SUCCESS");

			/* Transaction Details */
			/*
			 * 1. Cardnumber 2. merchantname 3. currencytype 4. Page Device Channel
			 */

			acsTxnPage.getTxnFirstRecordInTheList().click();
			generic.explicitWait(2);
			System.out.println("Clicked on displayed record to go to details report");

			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//div[span[text()='Card Number']]/div/span")));

			System.out.println(Cardnumber);
			System.out.println(acsTxnPage.getAcstxnDetailPageCardNumberValue().getText());
			System.out.println("************************");

			if (acsTxnPage.getAcstxnDetailPageCardNumberValue().getText().contains("xxxxx")) {
				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageCardNumberValue().getText(),
						firstSixDigitsOfTheCardNumber + "xxxxxx" + lastFourDigitsOfTheCardNumber);
			} else {
				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageCardNumberValue().getText(), Cardnumber);
			}

			System.out.println(merchantname);
			System.out.println(acsTxnPage.getAcstxnDetailPageMerchantNameValue().getText());
			System.out.println("************************");
			sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageMerchantNameValue().getText().toLowerCase(),
					merchantname.toLowerCase());

			System.out.println(String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);
			System.out.println(acsTxnPage.getAcstxnDetailPageTransactionAmountValue().getText());
			System.out.println("************************");

			if (IssuerBankId.contentEquals("8527") || IssuerBankId.contentEquals("8618")) {
				System.out.println(new BigDecimal(new BigInteger(amount), 2) + " " + currencytype);

				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageTransactionAmountValue().getText(),
						new BigDecimal(new BigInteger(amount), 2) + " " + currencytype);
			} else {
				sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageTransactionAmountValue().getText(),
						String.format("%,d", Integer.parseInt(amount)) + ".00" + " " + currencytype);
			}

			// sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageAuthenticationFlowTypeValue().getText().toLowerCase(),
			// Flow.toLowerCase());

			System.out.println("Browser");
			System.out.println(acsTxnPage.getAcstxnDetailPageDeviceChannelValue().getText());
			System.out.println("************************");
			sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageDeviceChannelValue().getText(), "Browser");

			if (CardUnionType.equalsIgnoreCase("Master")) {

				// sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageAAVValue().getText(),
				// CavvOrAvv);

			} else {
				// sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageCAVVValue().getText(),
				// CavvOrAvv);
			}
			generic.explicitWait(2);

			System.out.println(acsTxnPage.getAcstxnDetailPageErrorDescription().getText());
			System.out.println(ErrorDescription);
			//sAssertion.assertEquals(acsTxnPage.getAcstxnDetailPageErrorDescription().getText(), ErrorDescription);
			sAssertion.assertTrue(ErrorDescription.contains(acsTxnPage.getAcstxnDetailPageErrorDescription().getText()));
			/* OTP DETAILS */

			System.out.println(acsTxnPage.getAcstxnDetailPageAuthenticationFlowTypeValue().getText().toLowerCase());

			if (Flow.contentEquals("FrictionLess")) {
				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(AATransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), AATransStatus);
			} else if (Flow.contentEquals("Challenge") || Flow.contentEquals("Cancelled")
					|| Flow.contentEquals("Resend") || Flow.contentEquals("BlockCard")) {
				acsTxnPage.getOtpDetailPlusSign().click();
				generic.explicitWait(2);
				System.out.println(acsTxnPage.getOtpDetailEmailIdText().getText());
				System.out.println(EmailID);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailEmailIdText().getText(), EmailID);

				System.out.println(acsTxnPage.getOtpDetailMobileNoText().getText());
				System.out.println(MobileNumber);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailMobileNoText().getText(), MobileNumber);

				System.out.println(acsTxnPage.getOtpDetailMaximumAllowedOTPAttempsText().getText());
				System.out.println(MaximumAllowedOTPAttempts);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailMaximumAllowedOTPAttempsText().getText(),
						MaximumAllowedOTPAttempts);

				System.out.println(acsTxnPage.getOtpDetailResendOtpCountText().getText());
				System.out.println(ResendOTPCount);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailResendOtpCountText().getText(), ResendOTPCount);

				System.out.println(acsTxnPage.getOtpDetailInvalidOtpAttemptsText().getText());
				System.out.println(InvalidOTPAttempts);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailInvalidOtpAttemptsText().getText(), InvalidOTPAttempts);

				System.out.println(acsTxnPage.getOtpDetailLastOtpStatusText().getText());
				System.out.println(LastOTPStatus);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailLastOtpStatusText().getText(), LastOTPStatus);

				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(AATransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), AATransStatus);

				acsTxnPage.getCreqCres().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(CCTransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), CCTransStatus);

				acsTxnPage.getRreqRres().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(RRTransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), RRTransStatus);
			} else if (Flow.contentEquals("OTPCloseBrowser") || Flow.contentEquals("OTPExpiry")
					|| Flow.contentEquals("OtpPage")) {
				acsTxnPage.getOtpDetailPlusSign().click();
				generic.explicitWait(2);
				System.out.println(acsTxnPage.getOtpDetailEmailIdText().getText());
				System.out.println(EmailID);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailEmailIdText().getText(), EmailID);

				System.out.println(acsTxnPage.getOtpDetailMobileNoText().getText());
				System.out.println(MobileNumber);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailMobileNoText().getText(), MobileNumber);

				System.out.println(acsTxnPage.getOtpDetailMaximumAllowedOTPAttempsText().getText());
				System.out.println(MaximumAllowedOTPAttempts);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailMaximumAllowedOTPAttempsText().getText(),
						MaximumAllowedOTPAttempts);

				System.out.println(acsTxnPage.getOtpDetailResendOtpCountText().getText());
				System.out.println(ResendOTPCount);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailResendOtpCountText().getText(), ResendOTPCount);

				System.out.println(acsTxnPage.getOtpDetailInvalidOtpAttemptsText().getText());
				System.out.println(InvalidOTPAttempts);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailInvalidOtpAttemptsText().getText(), InvalidOTPAttempts);

				System.out.println(acsTxnPage.getOtpDetailLastOtpStatusText().getText());
				System.out.println(LastOTPStatus);
				sAssertion.assertEquals(acsTxnPage.getOtpDetailLastOtpStatusText().getText(), LastOTPStatus);

				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(AATransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), AATransStatus);

				acsTxnPage.getRreqRres().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(RRTransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), RRTransStatus);
			} else if (Flow.contentEquals("Failed")) {
				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(AATransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), AATransStatus);
			} else if (Flow.contentEquals("Blocked")) {
				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(AATransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), AATransStatus);

				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", acsTxnPage.getCreqCres());
				// acsTxnPage.getCreqCres().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(CCTransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), CCTransStatus);

				executor.executeScript("arguments[0].click();", acsTxnPage.getRreqRres());
				// acsTxnPage.getRreqRres().click();
				System.out.println(acsTxnPage.getAatransStatus().getText());
				System.out.println(RRTransStatus);
				sAssertion.assertEquals(acsTxnPage.getAatransStatus().getText(), RRTransStatus);
			} else {
				acsTxnPage.getDetailedTransactionOutputExpandLink().click();
			}
			
			// Audit Log
			if(AuditLog.contentEquals("") || AuditLog != null) {
				js.executeScript("arguments[0].click();", acsTxnPage.getAuditLog());
								
				WebElement element =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'"+AuditLog+"')]")));
				
				if(element != null) {
					sAssertion.assertTrue(true);
				} else {
					sAssertion.assertTrue(false);
				}				
			}

			System.out.println(
					"RiskengineClientID:- " + acsTxnPage.getAcstxnDetailPageRiskengineClientIDValue().getText());
			System.out.println(
					"acstxnDetailPageRiskScoreValue:- " + acsTxnPage.getAcstxnDetailPageRiskScoreValue().getText());
			System.out.println("acstxnDetailPageRiskSuggestionValue:- "
					+ acsTxnPage.getAcstxnDetailPageRiskSuggestionValue().getText());

			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskengineClientID", invocationCount,
					acsTxnPage.getAcstxnDetailPageRiskengineClientIDValue().getText());
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskScore", invocationCount,
					acsTxnPage.getAcstxnDetailPageRiskScoreValue().getText());
			GenericMethods.writingToExcel(XlFileName, ACSTxn2_0SheetName, "RiskSuggestion", invocationCount,
					acsTxnPage.getAcstxnDetailPageRiskSuggestionValue().getText());

			// Writing to Trident
			/*
			 * GenericMethods.writingToExcel(XlFileName, TridentTxn2_0SheetName,
			 * "RiskengineClientID", invocationCount,
			 * acsTxnPage.getAcstxnDetailPageRiskengineClientIDValue().getText());
			 * GenericMethods.writingToExcel(XlFileName, TridentTxn2_0SheetName,
			 * "RiskScore", invocationCount,
			 * acsTxnPage.getAcstxnDetailPageRiskScoreValue().getText());
			 * GenericMethods.writingToExcel(XlFileName, TridentTxn2_0SheetName,
			 * "RiskSuggestion", invocationCount,
			 * acsTxnPage.getAcstxnDetailPageRiskSuggestionValue().getText());
			 */

			sAssertion.assertAll();
		}

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		// driver.quit();
		System.out.println("Successfully logged out : Page Title is : " + driver.getTitle());

	}
}

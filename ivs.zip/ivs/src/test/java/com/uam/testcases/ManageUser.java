package com.uam.testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AdminHomePage;
import com.uam.pages.ManageUsersPage;

public class ManageUser extends ACSInitialSetUp {
	/* Modified By Suuresh */
	int invocationCount = 1;
	public static String RandomLoginID;

	@BeforeMethod
	public void beforeVerificationMethod() {
		driver.get(Config.BASE_UAM_URL);

		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateUser");
	}

	@Test(dataProvider = "DataSet", priority = 1, enabled = true)
	public void createUser(String IssuerBankId, String IssuerBankName, String firstName, String lastName,
			String loginId, String countryCode, String mobileNum, String email, String status, String bankName,
			String AutomationType, String StatusAfterMakerChecker, String Decs) throws InterruptedException {

		System.out.println(firstName + lastName + loginId);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageUsersPage manageuser = new ManageUsersPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		invocationCount++;
		ExtentTestManager.getTest().setDescription(Decs);
		System.out.println("row num" + invocationCount);

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageUsersLink().click();

		generic.explicitWait(2);
		manageuser.getUserCreatePlusButton().click();

		/*----------------------Create User------------------------*/
		manageuser.getUserFirstNameTextField().clear();
		manageuser.getUserFirstNameTextField().sendKeys(firstName);
		manageuser.getUserLastNameTextField().sendKeys(lastName);

		manageuser.getUserLoginIdTextField().clear();

		if (AutomationType.equals("Regression")) {
			/* random number generation for Login ID */
			int randomPIN = (int) (Math.random() * 9000) + 1000;
			String RandomNum = "" + randomPIN;
			RandomLoginID = "LoginID" + RandomNum;
			System.out.println("Login ID is " + RandomLoginID);
			manageuser.getUserLoginIdTextField().sendKeys(RandomLoginID);
			generic.writingToExcel(XlFileName, "CreateUser", "LoginID", invocationCount, RandomLoginID);
		} else {
			System.out.println("Executing Functional");
			manageuser.getUserLoginIdTextField().sendKeys(loginId);
		}

		// selecting the country code
		manageuser.getUserCodeDropDownField().click();
		manageuser.getUserCodeSearch().sendKeys(countryCode);
		manageuser.getUserCodeCheckBox().click();
		generic.explicitWait(2);

		// Selecting the Mobile number and Email ID
		manageuser.getUserMobileNumberTextField().sendKeys(mobileNum);
		manageuser.getUserEmailIdTextField().sendKeys(email);

		// Selecting Status='Active'
		// manageuser.getUserStatusDropDownField().click();
		// manageuser.getUserStatusField().click();

		// js.executeScript("arguments[0].scrollIntoView();",
		// manageuser.getUserBankListSearchField());

		// Searching the Bank from List and selecting
		manageuser.getUserBankListSearchField().sendKeys(bankName);
		generic.explicitWait(2);

		// Need to see below line, from Page class
		manageuser.getUserBankListCheckBox().click();
		generic.explicitWait(2);

		// javascript Executor to scroll to particular web element
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)");

		/*
		 * generic.scrollThePageTillXpositionOfTheElement(manageuser.getCreateUserButton
		 * ());
		 */

		/* Clicking create user button once after fill mandatory data */
		manageuser.getCreateUserButton().click();
		System.out.println("clicked create user");
		generic.explicitWait(2);

		// Searching created users with paginations
		manageuser.getListPerPageDropDown().click();
		manageuser.getList30PerPageRadioButton().click();

		if (AutomationType.equals("Regression")) {
			System.out.println("searching randome Login user");
			manageuser.getSearchByLoginIDTextField().sendKeys(RandomLoginID);
		} else {
			System.out.println("searching Functional login user");
			manageuser.getSearchByLoginIDTextField().sendKeys(loginId);
		}

		// pagination
		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {

			if (driver.findElements(By.xpath("//div[text()='" + RandomLoginID + "']")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}

			/*
			 * if (driver.findElements(By.xpath("(//div[text()='" + RandomLoginID +
			 * "']/following::div[@data-id='tooltip']/following::div/div/div[1])[1]")).size(
			 * ) > 0) { System.out.println("Webelement Exist"); break; } else {
			 * System.out.println("Navigating to next page..." + i);
			 * driver.findElement(By.xpath(
			 * "//ul[@class='pagination-list']/li/a[text()='NEXT']")).click(); }
			 */
		}
		// generic.explicitWait(2);
		// System.out.println("start clicking next page");
		// manageuser.getClickNextPage().click();

		// Assertion cases

		System.out.println("Name" + manageuser.getListedName().getText());
		System.out.println("Status" + manageuser.getListedStatus().getText());

		sAssertion.assertEquals(manageuser.getListedName().getText(), firstName + " " + lastName,
				"FirstName or Lastname is NOT in match");
		sAssertion.assertEquals(manageuser.getListedLoginId().getText(), RandomLoginID, "Login ID NOT match");
		sAssertion.assertEquals(manageuser.getListedEmail().getText(), email, "Email ID is not Matching");
		sAssertion.assertEquals(manageuser.getListedMobile().getText(), "+ " + countryCode + " " + mobileNum,
				"Mobile Number is not matching");
		sAssertion.assertEquals(manageuser.getListedStatus().getText(), status, "Status is not matching");

		sAssertion.assertAll();
	}

	@DataProvider
	public Object[][] EditDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateUser");
	}

	@Test(dataProvider = "EditDataSet", priority = 2, enabled = true)
	public void editUser(String IssuerBankId, String IssuerBankName, String firstName, String lastName, String loginId,
			String countryCode, String mobileNum, String email, String status, String bankName, String AutomationType,
			String StatusAfterMakerChecker, String Decs) {
		ExtentTestManager.getTest().setDescription(Decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageUsersPage manageuser = new ManageUsersPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageUsersLink().click();

		generic.explicitWait(2);

		// Searching created users with paginations
		manageuser.getListPerPageDropDown().click();
		manageuser.getList30PerPageRadioButton().click();
		manageuser.getSearchByLoginIDTextField().sendKeys(loginId);
		generic.explicitWait(2);
		// System.out.println("start clicking next page");
		// manageuser.getClickNextPage().click();
		// generic.explicitWait(2);

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {

			if (driver.findElements(By.xpath("//div[text()='" + loginId + "']")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}

			/*
			 * if (driver.findElements(By.xpath("(//div[text()='" + loginId +
			 * "']/following::div[@data-id='tooltip']/following::div/div/div[1])[1]")).size(
			 * ) > 0) { System.out.println("Webelement Exist"); break; } else {
			 * System.out.println("Navigating to next page..." + i);
			 * driver.findElement(By.xpath(
			 * "//ul[@class='pagination-list']/li/a[text()='NEXT']")).click(); }
			 */
		}

		/*-----------------Editing the user created--------------*/
		if (manageuser.getListedLoginId().getText().equals(loginId)) {
			System.out.println("click Edit for the user created");
			manageuser.getEdituser().click();
			generic.explicitWait(2);
			manageuser.getUserFirstNameTextField().clear();
			manageuser.getUserFirstNameTextField().sendKeys(firstName + "edit");
			manageuser.getUserLastNameTextField().clear();
			manageuser.getUserLastNameTextField().sendKeys(lastName + "edit");

			manageuser.getEditUserCodeDropDownField().click();
			manageuser.getUserCodeSearch().sendKeys(countryCode);
			manageuser.getUserCodeCheckBox().click();
			generic.explicitWait(2);

			manageuser.getUserMobileNumberTextField().clear();
			manageuser.getUserMobileNumberTextField().sendKeys(mobileNum + "21");

			manageuser.getUserEmailIdTextField().clear();
			manageuser.getUserEmailIdTextField().sendKeys(email);

			/*
			 * manageuser.getUserStatusDropDownField().click();
			 * manageuser.getUserStatusField().click();
			 */

			// Searching the Bank from List
			manageuser.getUserBankListSearchField().sendKeys(bankName);
			generic.explicitWait(2);

			// Select the checkbox for the bank searched
			manageuser.getUserBankListCheckBox().click();
			generic.explicitWait(2);

			/* Save the Edit changes */
			manageuser.getSaveChanges().click();
			generic.explicitWait(2);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-500)");

			manageuser.getListPerPageDropDown().click();
			manageuser.getList30PerPageRadioButton().click();
			manageuser.getSearchByLoginIDTextField().sendKeys(loginId);
			generic.explicitWait(2);
			// manageuser.getClickNextPage().click();
			// generic.explicitWait(2);
			paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
			for (int i = 0; i < paginationSize - 4; i++) {

				if (driver.findElements(By.xpath("//div[text()='" + loginId + "']")).size() > 0) {
					System.out.println("Webelement Exist");
					break;
				} else {
					System.out.println("Navigating to next page..." + i);
					driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
				}

				/*
				 * if (driver.findElements(By.xpath("(//div[text()='" + loginId +
				 * "']/following::div[@data-id='tooltip']/following::div/div/div[1])[1]")).size(
				 * ) > 0) { System.out.println("Webelement Exist"); break; } else {
				 * System.out.println("Navigating to next page..." + i);
				 * driver.findElement(By.xpath(
				 * "//ul[@class='pagination-list']/li/a[text()='NEXT']")).click(); }
				 */
			}
			System.out.println(manageuser.getListedMobile().getText());

			sAssertion.assertEquals(manageuser.getListedName().getText(), firstName + "edit" + " " + lastName + "edit",
					"Name is not in match");
			sAssertion.assertEquals(manageuser.getListedEmail().getText(), email, "Email ID is not Matching");
			sAssertion.assertNotEquals(manageuser.getListedMobile().getText(), "+" + countryCode + " " + mobileNum,
					"Mobile Number is not matching");
			sAssertion.assertEquals(manageuser.getListedStatus().getText(), status, "Status is not matching");
			sAssertion.assertAll();

		} else
			System.out.println("User not available for Edit");
	}

	@DataProvider
	public Object[][] DeleteDataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "CreateUser");
	}

	@Test(dataProvider = "DeleteDataSet", priority = 3, enabled = true)
	public void deleteUser(String IssuerBankId, String IssuerBankName, String firstName, String lastName,
			String loginId, String countryCode, String mobileNum, String email, String status, String bankName,
			String AutomationType, String StatusAfterMakerChecker, String Decs) {
		ExtentTestManager.getTest().setDescription(Decs);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageUsersPage manageuser = new ManageUsersPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageUsersLink().click();

		generic.explicitWait(2);

		// Searching created users with paginations
		manageuser.getListPerPageDropDown().click();
		manageuser.getList30PerPageRadioButton().click();
		manageuser.getSearchByLoginIDTextField().sendKeys(loginId);
		generic.explicitWait(2);
		/*
		 * System.out.println("start clicking next page");
		 * manageuser.getClickNextPage().click(); generic.explicitWait(2);
		 * System.out.println("clicked next page"); generic.explicitWait(2);
		 */

		int paginationSize = driver.findElements(By.xpath("//ul[@class='pagination-list']//li//a")).size();
		for (int i = 0; i < paginationSize - 4; i++) {
			if (driver.findElements(By.xpath("//div[text()='" + loginId + "']")).size() > 0) {
				System.out.println("Webelement Exist");
				break;
			} else {
				System.out.println("Navigating to next page..." + i);
				driver.findElement(By.xpath("//ul[@class='pagination-list']/li/a[text()='NEXT']")).click();
			}
		}

		/* Delete the user which is present and matching */
		if (manageuser.getListedLoginId().getText().equals(loginId)) {
			System.out.println("Element exits");

			manageuser.getDeleteuser().click();
			generic.explicitWait(2);

			generic.checkAlertDisplayed();
			generic.dismissAlertPopup();

			sAssertion.assertEquals(manageuser.getListedLoginId().getText(), loginId,
					"User deleted by clicking cancel, which is not correct");
			sAssertion.assertAll();
			System.out.println("Clicked cancel from alert popup");

			manageuser.getDeleteuser().click();
			generic.explicitWait(2);
			generic.checkAlertDisplayed();
			generic.acceptAlertPopup();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-500)");

			// manageuser.getListPerPageDropDown().click();
			// manageuser.getList30PerPageRadioButton().click();

			// manageuser.getSearchByLoginIDTextField().clear();
			// manageuser.getSearchByLoginIDTextField().sendKeys(loginId);
			generic.explicitWait(2);
			System.out.println("Click confirmed from alert popup");

			if (driver.findElements(By.xpath("//div[text()='" + loginId + "']")).size() > 0) {
				System.out.println("Webelement Exist");

				sAssertion.assertEquals(manageuser.getListedLoginId().getText(), loginId);
				sAssertion.assertAll();

			} else {
				sAssertion.assertTrue(true);
				sAssertion.assertAll();
				System.out.println("User gets deleted...");

			}

		}

		else {

			System.out.println("User Not present to delete");
		}

	}

	/*
	 * @DataProvider public Object[][] ValidateDataSet() throws IOException {
	 * 
	 * System.out.println("Reading data from excell file"); return
	 * generic.getData(XlFileName,"CreateUser"); }
	 */

	@Test(priority = 0, enabled = true)
	public void validationMessageCreateUser() {
		ExtentTestManager.getTest().setDescription("Field Validation for Create user");
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ManageUsersPage manageuser = new ManageUsersPage(driver);
		SoftAssert sAssertion = new SoftAssert();

		// select the bank(wibmo) dropdown from home page
		adminhomepage.getDropDownHeader().click();
		adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();

		// Select the UAM from left side bar and then select Manage User
		adminhomepage.getSideBarLinkUAM().click();
		adminhomepage.getManageUsersLink().click();

		generic.explicitWait(2);
		manageuser.getUserCreatePlusButton().click();
		generic.explicitWait(2);

		/*----------------------Clicking on Create User without filling form------------------------*/
		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		/* Field level Error message in Manager users */
		String expectedFirstName = "First Nameis a required property";
		String expectedLoginId = "Login ID is a required property";
		String expectedCode = "Code is a required property";
		String expectedMobileNumber = "Mobile Number is a required property";
		String expectedEmailID = "Email ID is a required property";
		// String expectedStatus = "Status is a required property";

		sAssertion.assertEquals(manageuser.getFirstNameMessage().getText() + "is a required property",
				expectedFirstName, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getLoginIdMessage().getText() + " is a required property", expectedLoginId,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getCodeMessage().getText() + " is a required property", expectedCode,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getMobileNumMessage().getText() + " is a required property",
				expectedMobileNumber, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();

		System.out.println("Validation done when noting entered");
		/*----------------------Validation message where only FIRSTNAME is entered------------------------ 	    */
		manageuser.getUserFirstNameTextField().clear();
		manageuser.getUserFirstNameTextField().sendKeys("TestAuto");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(manageuser.getLoginIdMessage().getText() + " is a required property", expectedLoginId,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getCodeMessage().getText() + " is a required property", expectedCode,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getMobileNumMessage().getText() + " is a required property",
				expectedMobileNumber, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();
		System.out.println("Validation done when only FIRSTNAME is entered");
		/*----------------------Validation message where only LASTNAME is entered------------------------*/
		manageuser.getUserFirstNameTextField().clear();
		manageuser.getUserLastNameTextField().sendKeys("User");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		// Verify Error message for First Name field with No input
		/*
		 * sAssertion.assertEquals(manageuser.getFirstNameMessage().getText()
		 * +"is a required property", expectedFirstName,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertEquals(manageuser.getLoginIdMessage().getText() + " is a required property", expectedLoginId,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getCodeMessage().getText() + " is a required property", expectedCode,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getMobileNumMessage().getText() + " is a required property",
				expectedMobileNumber, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();
		System.out.println("Validation done when only LASTNAME is entered");

		/*----------------------Validating FIRSTNAME field with less than 3 character------------------------*/
		manageuser.getUserLastNameTextField().clear();
		manageuser.getUserFirstNameTextField().sendKeys("AA");
		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		String firstnamecharcterErrMsg = "FirstName should NOT be shorter than 3 characters";
		String lesscharacterErrMsg = driver
				.findElement(By.xpath("//span[contains(text(),' FirstName should NOT be shorter than 3 characters')]"))
				.getText();

		sAssertion.assertEquals(lesscharacterErrMsg, firstnamecharcterErrMsg,
				"Error message for less chacter is not present/proper");
		sAssertion.assertAll();
		System.out.println("FIRSTNAME field with less than 3 characterd");

		/*----------------------Validation message where only Login ID entered ------------------------*/

		manageuser.getUserLoginIdTextField().clear();
		manageuser.getUserLoginIdTextField().sendKeys("TestAuto898");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(manageuser.getCodeMessage().getText() + " is a required property", expectedCode,
				"Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getMobileNumMessage().getText() + " is a required property",
				expectedMobileNumber, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();
		System.out.println("Validation done  where only Login ID entered");
		/*----------------------Validation message where Login ID less than 3 character entered ------------------------*/
		manageuser.getUserLoginIdTextField().clear();
		manageuser.getUserLoginIdTextField().sendKeys("AA");
		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		String actualLogin = driver
				.findElement(By.xpath("//span[contains(text(),' LoginID should NOT be shorter than 3 characters')]"))
				.getText();
		String expectedLogin = "LoginID should NOT be shorter than 3 characters";

		sAssertion.assertEquals(actualLogin, expectedLogin, "Error message for less chacter is not present/proper");
		sAssertion.assertAll();
		System.out.println("Validation done  where Login ID less than 3 character entered");

		/*----------------------Validation message where only country code is entered ------------------------*/
		manageuser.getUserLoginIdTextField().clear();
		manageuser.getUserCodeDropDownField().click();
		manageuser.getUserCodeSearch().sendKeys("+91");
		manageuser.getUserCodeCheckBox().click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(actualLogin, expectedLogin, "Error message for less chacter is not present/proper");
		sAssertion.assertEquals(lesscharacterErrMsg, firstnamecharcterErrMsg,
				"Error message for less chacter is not present/proper");
		sAssertion.assertEquals(manageuser.getMobileNumMessage().getText() + " is a required property",
				expectedMobileNumber, "Error message is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();

		System.out.println("Validation done when only country code is entered");

		/*----------------------Validation message where only Mobile number is is entered ------------------------*/
		manageuser.getUserMobileNumberTextField().sendKeys("1234567890");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(actualLogin, expectedLogin, "Error message for less chacter is not present/proper");
		sAssertion.assertEquals(lesscharacterErrMsg, firstnamecharcterErrMsg,
				"Error message for less chacter is not present/proper");
		sAssertion.assertEquals(manageuser.getEmailIDMessage().getText() + " is a required property", expectedEmailID,
				"Error message is not present/proper");
		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();

		System.out.println("Validation done where only Mobile number is is entered");

		/*----------------------Validation message where only Mobile number is is entered less than 6 digits------------------------*/
		manageuser.getUserMobileNumberTextField().clear();
		manageuser.getUserMobileNumberTextField().sendKeys("12345");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		String actualMobilenum = "MobileNumber should NOT be shorter than 6 characters";
		String expectedmobilenum = driver
				.findElement(
						By.xpath("//span[contains(text(),' MobileNumber should NOT be shorter than 6 characters')]"))
				.getText();

		sAssertion.assertEquals(actualMobilenum, expectedmobilenum, "mobile number is not lessthan 6 digits");
		sAssertion.assertAll();

		System.out.println("Validation done Mobile number is is entered less than 6 digits");

		/*----------------------Validation message where only Email ID is entered ------------------------*/
		manageuser.getUserMobileNumberTextField().clear();
		manageuser.getUserEmailIdTextField().sendKeys("testauto1@gmail.com");

		manageuser.getCreateUserButton().click();
		generic.explicitWait(2);

		sAssertion.assertEquals(lesscharacterErrMsg, firstnamecharcterErrMsg,
				"Error message for less chacter is not present/proper");

		sAssertion.assertEquals(actualLogin, expectedLogin, "Error message for less chacter is not present/proper");

		sAssertion.assertEquals(actualMobilenum, expectedmobilenum, "mobile number is not lessthan 6 digits");

		/*
		 * sAssertion.assertEquals(manageuser.getStatusMessage().getText() +
		 * " is a required property", expectedStatus,
		 * "Error message is not present/proper");
		 */
		sAssertion.assertAll();
		System.out.println("Validation done only Email ID is entered");

		/*----------------------Validation message where only Status entered ------------------------*/
		manageuser.getUserEmailIdTextField().clear();

		/*
		 * manageuser.getUserStatusDropDownField().click();
		 * manageuser.getUserStatusField().click(); // Scroll up
		 * 
		 * js.executeScript("window.scrollBy(0,-500)");
		 * manageuser.getCreateUserButton().click();
		 * 
		 * generic.explicitWait(2);
		 * 
		 * sAssertion.assertEquals(lesscharacterErrMsg, firstnamecharcterErrMsg,
		 * "Error message for less chacter is not present/proper");
		 * 
		 * sAssertion.assertEquals(actualLogin, expectedLogin,
		 * "Error message for less chacter is not present/proper");
		 * 
		 * sAssertion.assertEquals(actualMobilenum, expectedmobilenum,
		 * "mobile number is not lessthan 6 digits");
		 */

		sAssertion.assertAll();
		System.out.println("Validation done only Status entered");

	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		logout.logout();
		System.out.println("Sucessfully Logout");
	}

}

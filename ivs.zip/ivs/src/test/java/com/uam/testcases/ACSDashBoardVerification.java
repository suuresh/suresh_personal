package com.uam.testcases;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.DBQuery;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.ACSDashBoardPage;
import com.uam.pages.ACSMDDPage;
import com.uam.pages.AcsSmsMisPage;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminHomePage;

public class ACSDashBoardVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);

//date and time varibles
	public static String cDay = null;
	public static String yesterDay = null;
	public static String cMonth = null;
	public static String nMonth = null;
	public static String cYear = null;
	public static String cHour = null;
	public static String cMinutes = null;
	public static String cSeconds = null;

	public static String utcDay = null;
	public static String utcMonth = null;
	public static String utcYear = null;
	public static String utcHour = null;
	public static String utcMinutes = null;
	public static String ucSeconds = null;

	// DB Values
	public static String totalTxnCount = null;
	public static String totalTxnSuccessCount = null;
	public static String totalTxnFailureCount = null;
	public static String totalTxnDeclinedCount = null;
	public static String totalTxnFrictionlessSuccessCount = null;
	public static String totalTxnChallengeSuccessCount = null;
	public static String totalTxnSpend = null;
	public static String totalTxnSuccessSpend = null;
	public static String totalTxnFailureSpend = null;
	public static String totalTxnDeclinedSpend = null;
	public static String totalTxnFlessCount = null;
	public static String totalTxnFrictionlessSpend = null;
	public static String totalTxnChallengeCount = null;
	public static String totalTxnChallengeSpend = null;

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] validateACSDashBoard() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "ACSDashBoard");
	}

	@Test(dataProvider = "validateACSDashBoard", priority = 1, enabled = true)
	public void acsDashBoardVerification(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String BankCurrency, String CurrencyCode, String Schema, String decs) {

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();

		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		cYear = dateTime[0];
		cMonth = dateTime[1];
		cDay = dateTime[2];
		cHour = dateTime[3];
		cMinutes = dateTime[4];
		cSeconds = dateTime[5];
		int yesterday = Integer.parseInt(cDay) - 1;

		String yesterday1 = Integer.toString(yesterday);
		yesterDay = String.format("%02d", Integer.parseInt(yesterday1));

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		utcYear = utcDateTime[0];
		utcMonth = utcDateTime[1];
		utcDay = utcDateTime[2];
		utcHour = utcDateTime[3];
		utcMinutes = utcDateTime[4];
		ucSeconds = utcDateTime[5];

		// DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String dateAndTime1 = FORMATTER.format(currentDate);

		LocalDateTime now = LocalDateTime.now();
		nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + nMonth);
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ACSDashBoardPage dashboardpage = new ACSDashBoardPage(driver);
		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		generic.explicitWait(3);

		// Navigating to MDD Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsDashboard().click();

		generic.explicitWait(2);
		String schemaquery = "use "+Schema+"; " ;
		String query1 = "select count(acs_txn_id) as totalTxnCount,"
				+ "count(case txn_status when 'Y' then 1 end) as totalTxnSuccessCount,"
				+ "count(case txn_status when 'N' then 1 end) as totalTxnFailureCount,"
				+ "count(case txn_status when 'R' then 1 end) as totalTxnDeclinedCount,"
				+ "count(case when (txn_status = 'Y' AND auth_flow_type = 'FrictionLess')  then 1 end) as totalTxnFrictionlessSuccessCount,"
				+ "count(case when (txn_status = 'Y' AND auth_flow_type = 'Challenge')  then 1 end) as totalTxnChallengeSuccessCount,"
				+ "ifnull(sum(txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)),0) as totalTxnSpend,"
				+ "ifnull(sum( case txn_status when 'Y' then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0) as totalTxnSuccessSpend,"
				+ "ifnull(sum( case txn_status when 'N' then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0) as totalTxnFailureSpend,"
				+ "ifnull(sum( case txn_status when 'R' then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0) as totalTxnDeclinedSpend,"
				+ "count(case lower(auth_flow_type) when lower('FrictionLess') then 1 end) as totalTxnFlessCount,"
				+ "ifnull(sum(case lower(auth_flow_type) when lower('FrictionLess') then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)  as totalTxnFrictionlessSpend,"
				+ "count(case lower(auth_flow_type) when lower('Challenge') then 1 end) as totalTxnChallengeCount,"
				+ "ifnull(sum(case lower(auth_flow_type) when lower('Challenge') then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)  as totalTxnChallengeSpend"
				+ "from " + Schema + ".acs_txn_" + utcYear + "" + nMonth + " where issuer_id = " + IssuerBankId
				+ " and date_time between '" + utcYear + "-" + nMonth + "-" + yesterDay + " 18:30:00' and '" + cYear
				+ "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "';";

		String query = "select count(acs_txn_id) as totalTxnCount," + 
				"sum(case when purchase_currency != '"+CurrencyCode+"' then 1 else 0 end) as totalTxnCountIntlCurrency," + 
				"count(case txn_status when 'Y' then 1 end) as totalTxnSuccessCount," + 
				"count(case txn_status when 'N' then 1 end) as totalTxnFailureCount," + 
				"count(case txn_status when 'R' then 1 end) as totalTxnDeclinedCount," + 
				"count(case when (txn_status = 'Y' AND auth_flow_type = 'FrictionLess')  then 1 end) as totalTxnFrictionlessSuccessCount," + 
				"count(case when (txn_status = 'Y' AND auth_flow_type = 'Challenge')  then 1 end) as totalTxnChallengeSuccessCount," + 
				"count(case when (txn_status = 'N' and (error_code = 'AC0407' or error_code = 'AC0408')) then 1 end ) as totalTxnParesNotReceivedCount," + 
				"ifnull(sum((case when purchase_currency = '"+CurrencyCode+"' then txn_amount else 0 end)/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)),0) as totalTxnSpend, ifnull(sum((case when purchase_currency != '"+CurrencyCode+"' then txn_amount else 0 end)/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)),0)" + 
				"as totalTxnSpendIntlCurrency, ifnull(sum( case when (txn_status = 'Y' and purchase_currency = '"+CurrencyCode+"') then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)" + 
				"as totalTxnSuccessSpend, ifnull(sum( case when (txn_status ='N' and purchase_currency = '"+CurrencyCode+"') then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)" + 
				"as totalTxnFailureSpend, ifnull(sum( case when (txn_status = 'R' and purchase_currency = '"+CurrencyCode+"' ) then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)" + 
				"as totalTxnDeclinedSpend, count(case lower(auth_flow_type) when lower('FrictionLess') then 1 end)" + 
				"as totalTxnFlessCount, ifnull(sum(case when ( lower(auth_flow_type) = lower('FrictionLess') and purchase_currency = '"+CurrencyCode+"' ) then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)" + 
				"as totalTxnFrictionlessSpend, count(case lower(auth_flow_type) when lower('Challenge') then 1 end)" + 
				"as totalTxnChallengeCount, ifnull(sum(case when (lower(auth_flow_type) = lower('Challenge') and purchase_currency = '"+CurrencyCode+"') then (txn_amount/(case (ifnull(currency_exponent,0)) when 0 then 1 when 1 then 10 when 2 then 100 when 3 then 1000 end)) end),0)" + 
				"as totalTxnChallengeSpend from acs_txn_"+ cYear + nMonth +" where issuer_id = '"+IssuerBankId+"' and date_time between '" + utcYear + "-" + nMonth + "-" + yesterDay + " 18:30:00' and '" + cYear
				+ "-" + nMonth + "-" + cDay + " " + utcHour + ":" + utcMinutes + "';";
		generic.explicitWait(5);

		getACSDashBoardValuesFromDB(schemaquery, query);
		sAssertion.assertEquals(dashboardpage.getAcsDashboardTotalTransactionsAllCurrenciesValue().getText(), totalTxnCount,
				"Total transactions count mismatched with DB");
		
		sAssertion.assertEquals(dashboardpage.getAcsDashboardTotalAmoutCurrenyText().getText(), "("+BankCurrency+")",
				"Total Amount Bank Currency Text mismatched.");
		sAssertion.assertEquals(dashboardpage.getAcsDashboardAvgAmoutSpentCurrenyText().getText(), "("+BankCurrency+")",
				"Avg Amount Spend Bank Currency Text mismatched.");
		
		sAssertion.assertEquals(dashboardpage.getAcsDashboardTotalAmoutNonCurrenyText().getText(), "Non("+BankCurrency+")",
				"Total Amount Non Bank Currency Text mismatched.");
		
		sAssertion.assertEquals(dashboardpage.getAcsDashboardTotalNumberOfTransactionNonCurrenyText().getText(), "("+BankCurrency+")",
				"Total Number of Transactions Non Bank Currency Text mismatched.");
	

	//	sAssertion.assertEquals(dashboardpage.getAcsDashboardAuthenticationRateValue().getText(),
	//			Percentage(totalTxnSuccessCount, totalTxnCount), "Total Authentication Rate mismatched with DB");

		sAssertion.assertEquals(dashboardpage.getAcsDashboardFrictionLessTransactionsTotalCountValue().getText(),
				totalTxnFlessCount, "Total Frictionless transactions count mismatched with DB");

	//	sAssertion.assertEquals(dashboardpage.getAcsDashboardFrictionLessTransactionsAuthenticationRateValue().getText(),
	//			Percentage(totalTxnFrictionlessSuccessCount, totalTxnFlessCount),"Total Frictionless transactions Autheticate Rate mismatched with DB");

		sAssertion.assertEquals(dashboardpage.getAcsDashboardChallengedTransactionsTotalCountValue().getText(),
				totalTxnChallengeCount, "Total Challenge transactions count mismatched with DB");

	//	sAssertion.assertEquals(dashboardpage.getAcsDashboardChallengedTransactionsAuthenticationRateValue().getText(),
	//			Percentage(totalTxnChallengeSuccessCount, totalTxnChallengeCount),"Total Challenge transactions Autheticate Rate mismatched with DB");

		sAssertion.assertEquals(dashboardpage.getAcsDashboardDeclinedTransactionsTotalCountValue().getText(),
				totalTxnDeclinedCount, "Total Declined transactions count mismatched with DB");
		
		sAssertion.assertEquals(dashboardpage.getAcsDashboardFailureTransactionsTotalCountValue().getText(),
				totalTxnFailureCount, "Total Failure transactions count mismatched with DB");
		

		sAssertion.assertAll();

	}

	public static void getACSDashBoardValuesFromDB(String schemaQuery, String queryString) {

		try {
			Class.forName(Config.mysqldriver);

			// System.out.println("Connected to DB");
			Connection connection = DriverManager.getConnection(Config.mysqlurl, Config.mysqluserName,
					Config.mysqlpassword);
			Statement stmt = connection.createStatement();
			System.out.println("Statement Created is :" + queryString);
			ResultSet rs1 = stmt.executeQuery(schemaQuery);
			ResultSet rs = stmt.executeQuery(queryString);
			System.out.println("Query executed");
			// While Loop to iterate through all data and print results
			while (rs.next()) {
				// dbValue = rs.getString(1);

				totalTxnCount = rs.getString("totalTxnCount");
				totalTxnSuccessCount = rs.getString("totalTxnSuccessCount");
				totalTxnFailureCount = rs.getString("totalTxnFailureCount");
				totalTxnDeclinedCount = rs.getString("totalTxnDeclinedCount");
				totalTxnFrictionlessSuccessCount = rs.getString("totalTxnFrictionlessSuccessCount");
				totalTxnChallengeSuccessCount = rs.getString("totalTxnChallengeSuccessCount");
				totalTxnSpend = rs.getString("totalTxnSpend");
				totalTxnSuccessSpend = rs.getString("totalTxnSuccessSpend");
				totalTxnFailureSpend = rs.getString("totalTxnFailureSpend");
				totalTxnDeclinedSpend = rs.getString("totalTxnDeclinedSpend");
				totalTxnFlessCount = rs.getString("totalTxnFlessCount");
				totalTxnFrictionlessSpend = rs.getString("totalTxnFrictionlessSpend");
				totalTxnChallengeCount = rs.getString("totalTxnChallengeCount");
				totalTxnChallengeSpend = rs.getString("totalTxnChallengeSpend");

				// System.out.println("dbValue:" + dbValue);
			}
			connection.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	return dbValue;

	}

	public static String Percentage(String successCount, String totalCount) {
		String Percentage = null;

		// DecimalFormat df2 = new DecimalFormat("#.##");
		float percentage1 = Float.parseFloat(successCount) / Float.parseFloat(totalCount);
		float finalpercentage = percentage1 * 100;
		// pareqParesPercentage = df2.format(pareqPares)+" %";
		// finalpercentage = String.format("%.2f", percentage) + " %";
		int convertedFloat = (int) finalpercentage;
		Percentage = String.valueOf(convertedFloat) + " %";
		System.out.println("pareqParesPercentage--" + Percentage);
		return Percentage;
	}

}

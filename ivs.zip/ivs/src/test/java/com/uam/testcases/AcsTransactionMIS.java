package com.uam.testcases;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TimeZone;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.DBConnection;
import com.acs.utils.DBQuery;
import com.acs.utils.ExtentTestManager;
import com.uam.pages.AcsTransactionMisPage;
import com.uam.pages.AdminACSFetchTxnPage;
import com.uam.pages.AdminHomePage;

public class AcsTransactionMIS extends ACSInitialSetUp {
	GenericMethods generic = new GenericMethods(driver);

	public static String SystemType = null;
	public static String Bin_Id = null;
	public static String Bins = null;
	public static String CardUnion = null;
	public static String CardType = null;

	public static String VeresPareq = null;

	public static String ReportResultTranMisMessageversion = null;
	public static String ReportResultTotalNoOfVreq = null;
	public static String ReportResultTotalNoOfVeres = null;
	public static String ReportResultTotalNoOfVres_Y = null;
	public static String ReportResultTotalNoOfVres_N = null;
	public static String ReportResultTotalNoofUnabletoAuthenticateVRes_U = null;
	public static String ReportResultTotalNoofPAReq = null;
	public static String ReportResultTotalNoofSuccessPARes = null;
	public static String ReportResultPAReswithvalidAuthentication_Y = null;
	public static String ReportResultPAReswithInvalidAuthentication_N = null;
	public static String ReportResultTotalNoofAttemptedPARes_A = null;
	public static String ReportResultTotalNoofAbortedPAResProgAbort = null;
	public static String ReportResultTotalNoofUnauthenticatedPARes_Failed_U = null;
	public static String ReportResultVeres_PareqPercentage = null;
	public static String ReportResultPareq_ParesPercentage = null;
	public static String ReportResultVeres_ParesPercentage = null;
	public static String TotalPares = null;
	public static String TotalNoOfVeres = null;

	// Protocol version 2.0
	public static String ReportResultTranMis2_0_Messageversion = null;
	public static String ReportResultTotalNoOfAreq = null;
	public static String ReportResultTotalNoOfARes_Y = null;
	public static String ReportResultTotalNoOfARes_N = null;
	public static String ReportResultTotalNoOfARes_U = null;
	public static String ReportResultTotalNoofAres_R = null;
	public static String ReportResultTotalNoofAres_C = null;
	public static String ReportResultTotalNoofCreq = null;
	public static String ReportResultTotalNoOfCres_Y = null;
	public static String ReportResultTotalNoOfCres_N = null;
	public static String ReportResultTotalNoofRReq = null;
	public static String ReportResultTotalNoofRRes_Y = null;
	public static String ReportResultTotalNoofRRes_N = null;

	public static String binDetail = null;

	LinkedHashMap<String, String> binModuleUI = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> binModuleDB = new LinkedHashMap<String, String>();
	ArrayList<String> binWiseList = new ArrayList<String>();

	public void moveToElement(WebElement e) {
		System.out.println("Moved to element");
		Actions action = new Actions(driver);
		action.moveToElement(e).perform();
	}

	public static String veresPareqPercentage() {
		// DecimalFormat df2 = new DecimalFormat("#.##");
		String veresPareqPerc = null;

		TotalNoOfVeres = Integer
				.toString(Integer.parseInt(ReportResultTotalNoOfVres_N) + Integer.parseInt(ReportResultTotalNoOfVres_Y)
						+ Integer.parseInt(ReportResultTotalNoofUnabletoAuthenticateVRes_U));
		float paReqByVeRes = Float.parseFloat(ReportResultTotalNoofPAReq) / Float.parseFloat(TotalNoOfVeres);
		float veresPareq = (100 - (paReqByVeRes * 100));
		// veresPareqPerc = df2.format(veresPareq)+" %";
		veresPareqPerc = String.format("%.2f", veresPareq) + " %";
		System.out.println("veresPareqPerc--" + veresPareqPerc);
		return veresPareqPerc;

	}

	public static String pareqParesPercentage() {
		String pareqParesPercentage = null;

		// DecimalFormat df2 = new DecimalFormat("#.##");
		TotalPares = Integer.toString(Integer.parseInt(ReportResultPAReswithInvalidAuthentication_N)
				+ Integer.parseInt(ReportResultPAReswithvalidAuthentication_Y)
				+ Integer.parseInt(ReportResultTotalNoofUnauthenticatedPARes_Failed_U)
				+ Integer.parseInt(ReportResultTotalNoofAttemptedPARes_A));
		float pareqByPares = Float.parseFloat(TotalPares) / Float.parseFloat(ReportResultTotalNoofPAReq);
		float pareqPares = (100 - (pareqByPares * 100));

		// pareqParesPercentage = df2.format(pareqPares)+" %";
		pareqParesPercentage = String.format("%.2f", pareqPares) + " %";
		System.out.println("pareqParesPercentage--" + pareqParesPercentage);
		return pareqParesPercentage;
	}

	public static String veresParesPercentage() {
		String veresParesPercentage = null;
		// DecimalFormat df2 = new DecimalFormat("#.##");

		TotalPares = Integer.toString(Integer.parseInt(ReportResultPAReswithInvalidAuthentication_N)
				+ Integer.parseInt(ReportResultPAReswithvalidAuthentication_Y)
				+ Integer.parseInt(ReportResultTotalNoofUnauthenticatedPARes_Failed_U)
				+ Integer.parseInt(ReportResultTotalNoofAttemptedPARes_A));

		TotalNoOfVeres = Integer
				.toString(Integer.parseInt(ReportResultTotalNoOfVres_N) + Integer.parseInt(ReportResultTotalNoOfVres_Y)
						+ Integer.parseInt(ReportResultTotalNoofUnabletoAuthenticateVRes_U));
		float veresByPares = Float.parseFloat(TotalPares) / Float.parseFloat(TotalNoOfVeres);
		float veresPares = (100 - (veresByPares * 100));

		// veresParesPercentage = df2.format(veresPares)+" %";
		veresParesPercentage = String.format("%.2f", veresPares) + " %";
		System.out.println("veresParesPercentage:-" + veresParesPercentage);

		return veresParesPercentage;
	}

	@BeforeMethod
	public void loginAdminPortal() {
		driver.get(Config.BASE_UAM_URL);
		generic.explicitWait(1);
		loginPage.login(Config.BASE_UAM_ADMIN_USER_NAME, Config.BASE_UAM_ADMIN_PASSWD);
	}

	@DataProvider
	public Object[][] init() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "init", enabled = false)
	public void init(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String FromDate,
			String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate, String ToMonth,
			String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		// SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		// Fetching data from Report Result
		acsTxnMis.getThreeDS1Button().click();

		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// Jul 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				if (currentDay.equalsIgnoreCase("1")) {
					if (dayXpath.isEnabled()) {
						dayXpath.click();
					}
				} else if (DBQuery.cDay.equalsIgnoreCase(currentDay)) {
					if (dayXpath.isEnabled()) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);
	}

	@DataProvider
	public Object[][] validateReportResult() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validateReportResult", priority = 1, enabled = true)
	public void validateReportResult(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		// selecting protocol version
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			System.out.println("Clicked 1.0 protocol version");
			acsTxnMis.getThreeDS1Button().click();
		} else {
			System.out.println("2.0 protocol version");
		}

		// Selecting date
		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// Jul 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				// System.out.println("currentDay from UI:-" + currentDay);
				String attr = dayXpath.getAttribute("class");
				// System.out.println("Date Picker attribute:- "+attr);
				// System.out.println("Date from system:-"+DBQuery.cDay);
				if (currentDay.equalsIgnoreCase("1")) {

					if (!attr.contains("off ")) {
						dayXpath.click();
						if (DBQuery.cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(DBQuery.cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();

					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);

		// Validation of 1.0 protocol version
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			// Fetching values from DB

			ReportResultTotalNoOfVreq = DBConnection.getValueFromDB(DBQuery.NoOfVreq(Schema));
			System.out.println("ReportResultTotalNoOfVreq: " + ReportResultTotalNoOfVreq);
			sAssertion.assertEquals(ReportResultTotalNoOfVreq, acsTxnMis.getTotalNoOfVreqValue().getText(),
					"ReportResultTotalNoOfVreq");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoOfVreqValue().getText());

			ReportResultTotalNoOfVres_Y = DBConnection.getValueFromDB(DBQuery.NoOfVres_Y(Schema));
			System.out.println("ReportResultTotalNoOfVres_Y: "+ ReportResultTotalNoOfVres_Y);
			sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, acsTxnMis.getTotalNoOfVres_Y_Value().getText(),
					"ReportResultTotalNoOfVres_Y");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoOfVres_Y_Value().getText());

			ReportResultTotalNoOfVres_N = DBConnection.getValueFromDB(DBQuery.NoOfVres_N(Schema));
			System.out.println("ReportResultTotalNoOfVres_N: "+ReportResultTotalNoOfVres_N);
			sAssertion.assertEquals(ReportResultTotalNoOfVres_N, acsTxnMis.getTotalNoOfVres_N_Value().getText(),
					"ReportResultTotalNoOfVres_N");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoOfVres_N_Value().getText());

			ReportResultTotalNoofUnabletoAuthenticateVRes_U = DBConnection.getValueFromDB(DBQuery.NoOfVres_U(Schema));
			System.out.println("ReportResultTotalNoofUnabletoAuthenticateVRes_U");
			sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U,
					acsTxnMis.getTotalNoofUnabletoAuthenticateVRes_U_value().getText(),
					"ReportResultTotalNoofUnabletoAuthenticateVRes_U");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoofUnabletoAuthenticateVRes_U_value().getText());

			ReportResultTotalNoofPAReq = DBConnection.getValueFromDB(DBQuery.NoOfPAReq(Schema));
			System.out.println("ReportResultTotalNoofPAReq:"+ReportResultTotalNoofPAReq);
			sAssertion.assertEquals(ReportResultTotalNoofPAReq, acsTxnMis.getTotalNoofPAReqValue().getText(),
					"ReportResultTotalNoofPAReq");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoofPAReqValue().getText());

			ReportResultTotalNoofSuccessPARes = DBConnection.getValueFromDB(DBQuery.NoofSuccessPARes(Schema));
			System.out.println("ReportResultTotalNoofSuccessPARes: "+ReportResultTotalNoofSuccessPARes);
			sAssertion.assertEquals(ReportResultTotalNoofSuccessPARes,
					acsTxnMis.getTotalNoofSuccessPAResValue().getText(), "ReportResultTotalNoofSuccessPARes");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoofSuccessPAResValue().getText());

			ReportResultPAReswithvalidAuthentication_Y = DBConnection
					.getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y(Schema));
			System.out.println("ReportResultPAReswithvalidAuthentication_Y: "+ ReportResultTotalNoofSuccessPARes);
			sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y,
					acsTxnMis.getPAReswithvalidAuthentication_Y_Value().getText(),
					"ReportResultPAReswithvalidAuthentication_Y");
			System.out.println("UI Value:" + acsTxnMis.getPAReswithvalidAuthentication_Y_Value().getText());

			ReportResultPAReswithInvalidAuthentication_N = DBConnection
					.getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N(Schema));
			System.out.println("ReportResultPAReswithInvalidAuthentication_N: "+ ReportResultPAReswithInvalidAuthentication_N);
			sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N,
					acsTxnMis.getPAReswithInvalidAuthentication_N_Value().getText(),
					"ReportResultPAReswithInvalidAuthentication_N");
			System.out.println("UI Value: " + acsTxnMis.getPAReswithInvalidAuthentication_N_Value().getText());

			ReportResultTotalNoofAttemptedPARes_A = DBConnection
					.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A(Schema));
			System.out.println("ReportResultTotalNoofAttemptedPARes_A");
			sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A,
					acsTxnMis.getTotalNoofAttemptedPARes_A_Value().getText(), "ReportResultTotalNoofAttemptedPARes_A");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoofAttemptedPARes_A_Value().getText());

			ReportResultTotalNoofAbortedPAResProgAbort = "InProgress";

			ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
					.getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U(Schema));
			System.out.println("ReportResultTotalNoofUnauthenticatedPARes_Failed_U");
			sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U,
					acsTxnMis.getTotalNoofUnauthenticatedPARes_Failed_U_Value().getText(),
					"ReportResultTotalNoofUnauthenticatedPARes_Failed_U");
			System.out.println("UI Value:" + acsTxnMis.getTotalNoofUnauthenticatedPARes_Failed_U_Value().getText());

			ReportResultVeres_PareqPercentage = AcsTransactionMIS.veresPareqPercentage();
			sAssertion.assertEquals(ReportResultVeres_PareqPercentage,
					acsTxnMis.getVeres_PareqPercentageValue().getText(), "ReportResultVeres_PareqPercentage");
			System.out.println("UI Value:" + acsTxnMis.getVeres_PareqPercentageValue().getText());

			ReportResultPareq_ParesPercentage = AcsTransactionMIS.pareqParesPercentage();
			sAssertion.assertEquals(ReportResultPareq_ParesPercentage,
					acsTxnMis.getPareq_ParesPercentageValue().getText(), "ReportResultPareq_ParesPercentage");
			System.out.println("UI Value:" + acsTxnMis.getPareq_ParesPercentageValue().getText());

			ReportResultVeres_ParesPercentage = AcsTransactionMIS.veresParesPercentage();
			sAssertion.assertEquals(ReportResultVeres_ParesPercentage,
					acsTxnMis.getVeres_ParesPercentageValue().getText(), "ReportResultVeres_ParesPercentage");
			System.out.println("UI Value:" + acsTxnMis.getVeres_ParesPercentageValue().getText());
		}

		// Validation data for 2.0 protocol version
		else {

			ReportResultTotalNoOfAreq = DBConnection.getValueFromDB(DBQuery.NoofAreq(Schema));
			System.out.println("ReportResultTotalNoOfAreq_DB: " + ReportResultTotalNoOfAreq);
			sAssertion.assertEquals(ReportResultTotalNoOfAreq, acsTxnMis.getACSTransactionMis_Areq_2_0().getText(),
					"validating ReportResultTotalNoOfAreq");
			System.out.println("TotalNoOfAreq UI Value:" + acsTxnMis.getACSTransactionMis_Areq_2_0().getText());

			ReportResultTotalNoOfARes_Y = DBConnection.getValueFromDB(DBQuery.NoofARes_Y(Schema));
			System.out.println("ReportResultTotalNoOfARes_Y_DB: " + ReportResultTotalNoOfARes_Y);
			sAssertion.assertEquals(ReportResultTotalNoOfARes_Y, acsTxnMis.getACSTransactionMis_ARes_Y_2_0().getText(),
					"validating ReportResultTotalNoOfARes_Y");
			System.out.println(
					"ReportResultTotalNoOfARes_Y UI Value:" + acsTxnMis.getACSTransactionMis_ARes_Y_2_0().getText());

			ReportResultTotalNoOfARes_N = DBConnection.getValueFromDB(DBQuery.NoofARes_N(Schema));
			System.out.println("ReportResultTotalNoOfARes_N_DB: " + ReportResultTotalNoOfARes_N);
			sAssertion.assertEquals(ReportResultTotalNoOfARes_N, acsTxnMis.getACSTransactionMis_ARes_Y_2_0().getText(),
					"validating ReportResultTotalNoOfARes_N");
			System.out.println(
					"ReportResultTotalNoOfARes_N UI Value:" + acsTxnMis.getACSTransactionMis_ARes_Y_2_0().getText());

			ReportResultTotalNoOfARes_U = DBConnection.getValueFromDB(DBQuery.NoofARes_U(Schema));
			System.out.println("ReportResultTotalNoOfARes_U_DB: " + ReportResultTotalNoOfARes_U);
			sAssertion.assertEquals(ReportResultTotalNoOfARes_U, acsTxnMis.getACSTransactionMis_ARes_U_2_0().getText(),
					"validating ReportResultTotalNoOfARes_U");
			System.out.println(
					"ReportResultTotalNoOfARes_U UI Value:" + acsTxnMis.getACSTransactionMis_ARes_U_2_0().getText());

			ReportResultTotalNoofAres_R = DBConnection.getValueFromDB(DBQuery.NoofARes_R(Schema));
			System.out.println("ReportResultTotalNoofAres_R_DB: " + ReportResultTotalNoofAres_R);
			sAssertion.assertEquals(ReportResultTotalNoofAres_R, acsTxnMis.getACSTransactionMis_Ares_R_2_0().getText(),
					"validating ReportResultTotalNoofAres_R");
			System.out.println(
					"ReportResultTotalNoofAres_R UI Value:" + acsTxnMis.getACSTransactionMis_Ares_R_2_0().getText());

			ReportResultTotalNoofAres_C = DBConnection.getValueFromDB(DBQuery.NoofARes_C(Schema));
			System.out.println("ReportResultTotalNoofAres_C_DB: " + ReportResultTotalNoofAres_C);
			sAssertion.assertEquals(ReportResultTotalNoofAres_C, acsTxnMis.getACSTransactionMis_Ares_C_2_0().getText(),
					"validating ReportResultTotalNoofAres_C");
			System.out.println(
					"ReportResultTotalNoofAres_C UI Value:" + acsTxnMis.getACSTransactionMis_Ares_C_2_0().getText());

			ReportResultTotalNoofCreq = DBConnection.getValueFromDB(DBQuery.NoofCreq(Schema));
			System.out.println("ReportResultTotalNoofCreq_DB: " + ReportResultTotalNoofCreq);
			sAssertion.assertEquals(ReportResultTotalNoofCreq, acsTxnMis.getACSTransactionMis_Creq_2_0().getText(),
					"validating ReportResultTotalNoofCreq");
			System.out.println(
					"ReportResultTotalNoofCreq UI Value:" + acsTxnMis.getACSTransactionMis_Creq_2_0().getText());

			ReportResultTotalNoOfCres_Y = DBConnection.getValueFromDB(DBQuery.NoofCRes_Y(Schema));
			System.out.println("ReportResultTotalNoOfCres_Y_DB: " + ReportResultTotalNoOfCres_Y);
			sAssertion.assertEquals(ReportResultTotalNoOfCres_Y, acsTxnMis.getACSTransactionMis_Cres_Y_2_0().getText(),
					"validating ReportResultTotalNoOfCres_Y");
			System.out.println(
					"ReportResultTotalNoOfCres_Y UI Value:" + acsTxnMis.getACSTransactionMis_Cres_Y_2_0().getText());

			ReportResultTotalNoOfCres_N = DBConnection.getValueFromDB(DBQuery.NoofCRes_N(Schema));
			System.out.println("ReportResultTotalNoOfCres_N_DB: " + ReportResultTotalNoOfCres_N);
			sAssertion.assertEquals(ReportResultTotalNoOfCres_N, acsTxnMis.getACSTransactionMis_Cres_N_2_0().getText(),
					"validating ReportResultTotalNoOfCres_N");
			System.out.println(
					"ReportResultTotalNoOfCres_N UI Value:" + acsTxnMis.getACSTransactionMis_Cres_N_2_0().getText());

			ReportResultTotalNoofRReq = DBConnection.getValueFromDB(DBQuery.NoofRreq(Schema));
			System.out.println("ReportResultTotalNoofRReq_DB: " + ReportResultTotalNoofRReq);
			sAssertion.assertEquals(ReportResultTotalNoofCreq, acsTxnMis.getACSTransactionMis_RReq_2_0().getText(),
					"validating ReportResultTotalNoofRReq");
			System.out.println(
					"ReportResultTotalNoofRReq UI Value:" + acsTxnMis.getACSTransactionMis_RReq_2_0().getText());

			ReportResultTotalNoofRRes_Y = DBConnection.getValueFromDB(DBQuery.NoofRres_Y(Schema));
			System.out.println("ReportResultTotalNoofRRes_Y_DB: " + ReportResultTotalNoofRRes_Y);
			sAssertion.assertEquals(ReportResultTotalNoofRRes_Y, acsTxnMis.getACSTransactionMis_RRes_Y_2_0().getText(),
					"validating ReportResultTotalNoofRRes_Y");
			System.out.println(
					"ReportResultTotalNoofRRes_Y UI Value:" + acsTxnMis.getACSTransactionMis_RRes_Y_2_0().getText());

			ReportResultTotalNoofRRes_N = DBConnection.getValueFromDB(DBQuery.NoofRres_N(Schema));
			System.out.println("ReportResultTotalNoofRRes_N_DB: " + ReportResultTotalNoofRRes_N);
			sAssertion.assertEquals(ReportResultTotalNoofRRes_N, acsTxnMis.getACSTransactionMis_RRes_N_2_0().getText(),
					"validating ReportResultTotalNoofRRes_N");
			System.out.println(
					"ReportResultTotalNoofRRes_N UI Value:" + acsTxnMis.getACSTransactionMis_RRes_N_2_0().getText());

		}
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] validateAmountSummary() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validateAmountSummary", priority = 2, enabled = true)
	public void validateAmountSummary(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		System.out.println("----validateAmountSummary----");

		LinkedHashMap<String, String> amountModuleUI = new LinkedHashMap<String, String>();
		// LinkedHashMap<String, String> amountModuleDB = new LinkedHashMap<String,
		// String>();
		ArrayList<String> amountList = new ArrayList<String>();

		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);
		ExtentTestManager.getTest().setDescription(decs);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		// selecting protocol version
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			System.out.println("Clicked 1.0 protocol version");
			acsTxnMis.getThreeDS1Button().click();
		} else {
			System.out.println("2.0 protocol version");
		}
		// acsTxnMis.getThreeDS1Button().click();

		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// Jul 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off ")) {
						dayXpath.click();
						if (DBQuery.cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(DBQuery.cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off ")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);

		moveToElement(acsTxnMis.getMisSummaryHeader());
		String System_Type = null;
		String CurrencyCode = null;
		String CurrencyName = null;
		String Amount_UI = null;
		String ParesY_UI = null;
		String ParesA_UI = null;
		String ParesN_UI = null;
		String ParesU_UI = null;
		String ParesAborted_UI = null;

		// 2.0 variables
		String Ares_Y = null;
		String Ares_N = null;
		String Ares_U = null;
		String Ares_R = null;
		String Ares_C = null;

		int AmtSum_trSize = driver.findElements(By.xpath(
				"(//div[text()='Amount Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr"))
				.size();
		int AmtSum_tdSize = driver.findElements(By.xpath(
				"(//div[text()='Amount Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td"))
				.size();

		System.out.println("AmtSum_trSize: " + AmtSum_trSize);
		System.out.println("AmtSum_tdSize: " + AmtSum_tdSize);

		for (int i = 1; i <= AmtSum_trSize; i++) {

			for (int j = 1; j <= AmtSum_tdSize; j++) {
				String headerDetail = driver.findElement(By.xpath(
						"(//div[text()='Amount Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/tr[1])[1]/th["
								+ j + "]"))
						.getText();
				String amtSummaryDetails = driver.findElement(By.xpath(
						"(//div[text()='Amount Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td["
								+ j + "]"))
						.getText();
				amountList.add(amtSummaryDetails);
				amountModuleUI.put(headerDetail, amtSummaryDetails);

			}
			

			// Validate 1.0 protocol
			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				System_Type = amountList.get(0);
				sAssertion.assertEquals(System_Type, "Accosa IVS", "Validate SytemType :" + CurrencyCode + " ");
				System.out.println("System_Type: " + System_Type);
				//ss
				CurrencyCode = amountList.get(1);
				sAssertion.assertEquals(CurrencyCode, CurrencyCode, "Validate CurrencyCode: " + CurrencyCode + " ");
				System.out.println("CurrencyCode :" + CurrencyCode);

				CurrencyName = amountList.get(2);
				sAssertion.assertEquals(CurrencyName, CurrencyName, "Validate Currency Name: " + CurrencyCode + "");
				System.out.println("CurrencyName: " + CurrencyName);

				Amount_UI = amountList.get(3);
				String amountDB = DBConnection.getValueFromDB(DBQuery.TotalAmount(Schema, CurrencyCode));
				sAssertion.assertEquals(Amount_UI, amountDB, "Validate Amount :" + CurrencyCode + "");
				System.out.println("Amount_UI :" + Amount_UI);

				ParesY_UI = amountList.get(4);
				String ParesY_DB = DBConnection.getValueFromDB(DBQuery.PARes_Y(Schema, CurrencyCode));
				sAssertion.assertEquals(ParesY_UI, ParesY_DB, "Validate ParesY :" + CurrencyCode + "");
				System.out.println("ParesY_UI: " + ParesY_UI);

				ParesA_UI = amountList.get(5);
				String ParesA_DB = DBConnection.getValueFromDB(DBQuery.Pares_A(Schema, CurrencyCode));
				sAssertion.assertEquals(ParesA_UI, ParesA_DB, "Validate ParesA :" + CurrencyCode + "");
				System.out.println("ParesA_UI: " + ParesA_UI);

				ParesN_UI = amountList.get(6);
				String ParesN_DB = DBConnection.getValueFromDB(DBQuery.Pares_N(Schema, CurrencyCode));
				sAssertion.assertEquals(ParesN_UI, ParesN_DB, "Validate ParesN :" + CurrencyCode + "");
				System.out.println("ParesN_UI :" + ParesN_UI);

				ParesU_UI = amountList.get(7);
				String ParesU_DB = DBConnection.getValueFromDB(DBQuery.Pares_U(Schema, CurrencyCode));
				sAssertion.assertEquals(ParesU_UI, ParesU_DB, "Validate ParesU :" + CurrencyCode + "");
				System.out.println("ParesU_UI: " + ParesU_UI);

				ParesAborted_UI = amountList.get(8);
				String ParesAborted_DB = DBConnection.getValueFromDB(DBQuery.TotalAmount(Schema, CurrencyCode));
				sAssertion.assertEquals(ParesAborted_UI, ParesAborted_UI,
						"Validate ParesAborted :" + CurrencyCode + "");
				System.out.println("ParesAborted_UI :" + ParesAborted_UI);

				System.out.println(amountModuleUI);
				System.out.println("****************************************************************************");
				binWiseList.clear();
			}
			// Validating 2.0 protocol values
			else {

				CurrencyCode = amountList.get(0);
				sAssertion.assertEquals(CurrencyCode, CurrencyCode, "Validate CurrencyCode: " + CurrencyCode + " ");
				System.out.println("CurrencyCode :" + CurrencyCode);

				CurrencyName = amountList.get(1);
				sAssertion.assertEquals(CurrencyName, CurrencyName, "Validate Currency Name: " + CurrencyCode + "");
				System.out.println("CurrencyName: " + CurrencyName);

				Amount_UI = amountList.get(2);
				String amountDB = DBConnection.getValueFromDB(DBQuery.TotalAmount_2_0(Schema, CurrencyCode));
				sAssertion.assertEquals(Amount_UI, amountDB, "Validate Amount 2.0:" + CurrencyCode + "");
				System.out.println("Amount_UI 2.0 :" + Amount_UI);

				Ares_Y = amountList.get(3);
				String Ares_Y_DB = DBConnection.getValueFromDB(DBQuery.Ares_Y(Schema, CurrencyCode));
				sAssertion.assertEquals(Ares_Y, Ares_Y_DB, "Validate Ares_Y :" + CurrencyCode + "");
				System.out.println("Ares_Y_UI :" + Ares_Y);

				Ares_N = amountList.get(4);
				String Ares_N_DB = DBConnection.getValueFromDB(DBQuery.Ares_N(Schema, CurrencyCode));
				sAssertion.assertEquals(Ares_N, Ares_N_DB, "Validate Ares_N :" + CurrencyCode + "");
				System.out.println("Ares_N_UI :" + Ares_N);

				Ares_U = amountList.get(5);
				String Ares_U_DB = DBConnection.getValueFromDB(DBQuery.Ares_U(Schema, CurrencyCode));
				sAssertion.assertEquals(Ares_U, Ares_U_DB, "Validate Ares_U :" + CurrencyCode + "");
				System.out.println("Ares_U_UI :" + Ares_U);

				Ares_R = amountList.get(2);
				String Ares_R_DB = DBConnection.getValueFromDB(DBQuery.Ares_R(Schema, CurrencyCode));
				sAssertion.assertEquals(Ares_R, Ares_R_DB, "Validate Ares_R :" + CurrencyCode + "");
				System.out.println("Ares_R_UI :" + Ares_R);

				Ares_C = amountList.get(2);
				String Ares_C_DB = DBConnection.getValueFromDB(DBQuery.Ares_C(Schema, CurrencyCode));
				sAssertion.assertEquals(Ares_C, Ares_C_DB, "Validate Ares_C :" + CurrencyCode + "");
				System.out.println("Ares_C_UI :" + Ares_C);

				System.out.println(amountModuleUI);
				System.out.println("****************************************************************************");
				binWiseList.clear();
			}
			sAssertion.assertAll();
		}

		/*
		 * AmountINR = DBConnection.getValueFromDB(DBQuery.TotalAmountINR(Schema));
		 * String UIAmountINR = acsTxnMis.getAmountINRValue().getText();
		 * System.out.println("Total UI INR Amount:-" + UIAmountINR);
		 * sAssertion.assertEquals(AmountINR, UIAmountINR, "UIAmountINR");
		 * 
		 * if (driver.findElements(By.xpath(
		 * "(//th[contains(text(),'Amount')]/following::tr[3]/td[4])[1]")).size() > 0) {
		 * AmountUSD = DBConnection.getValueFromDB(DBQuery.TotalAmountUSD(Schema));
		 * String UIAmountUSD = acsTxnMis.getAmountUSDValue().getText();
		 * System.out.println("Total UI USD Amount:-" + UIAmountUSD);
		 * sAssertion.assertEquals(AmountUSD, UIAmountUSD, "UIAmountUSD"); } else {
		 * System.out.println("No USD amount transaction"); }
		 * 
		 * if (driver.findElements(By.
		 * xpath("(//th[contains(text(),'Currency Code')]/following::tr[4]/td[2])[1]"))
		 * .size() > 0) { AmountEUR =
		 * DBConnection.getValueFromDB(DBQuery.TotalAmountEUR(Schema)); String
		 * UIAmountEUR = acsTxnMis.getAmountEURValue().getText();
		 * System.out.println("Total UI EUR Amount:-" + UIAmountEUR);
		 * sAssertion.assertEquals(AmountEUR, UIAmountEUR); } else {
		 * System.out.println("No EUR amount transaction"); }
		 */
		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] validateMisSummary() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validateMisSummary", priority = 3, enabled = true)
	public void validateMisSummary(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String FromDate,
			String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate, String ToMonth,
			String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		System.out.println("----validatevalidateMisSummary----");
		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		LinkedHashMap<String, String> misSummaryUI = new LinkedHashMap<String, String>();
		ArrayList<String> misSummaryList = new ArrayList<String>();

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		// selecting protocol version
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			System.out.println("Clicked 1.0 protocol version");
			acsTxnMis.getThreeDS1Button().click();
		} else {
			System.out.println("2.0 protocol version");
		}
		// acsTxnMis.getThreeDS1Button().click();

		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// Jul 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off")) {
						dayXpath.click();
						if (DBQuery.cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(DBQuery.cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);

		int MisSummary_trSize = driver.findElements(By.xpath(
				"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr"))
				.size();
		int MisSummary_tdSize = driver.findElements(By.xpath(
				"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td"))
				.size();

		System.out.println("MisSummary_trSize: " + MisSummary_trSize);
		System.out.println("MisSummary_tdSize: " + MisSummary_tdSize);

		for (int i = 1; i <= MisSummary_trSize; i++) {

			for (int j = 1; j <= MisSummary_tdSize; j++) {
				String headerDetail = driver.findElement(By.xpath(
						"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/tr[1])[1]/th["
								+ j + "]"))
						.getText();
				String misSummaryDetails = driver.findElement(By.xpath(
						"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td["
								+ j + "]"))
						.getText();
				misSummaryList.add(misSummaryDetails);
				misSummaryUI.put(headerDetail, misSummaryDetails);

			}

			// Validate the values

			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				
				String System_Type = misSummaryList.get(0);
				sAssertion.assertEquals(System_Type, "Accosa IVS", "Validate SytemType ");
				System.out.println("System_Type: " + System_Type);
				System.out.println("------------");
				//ss
				CardUnion = misSummaryList.get(1);
				sAssertion.assertEquals(CardUnion, CardUnion, "Validating CardUnion ");
				System.out.println("CardUnion: " + CardUnion);
				System.out.println("------------");

				CardType = misSummaryList.get(2);
				sAssertion.assertEquals(CardType, CardType, "Validating CardType: ");
				System.out.println("CardType: " + CardType);
				System.out.println("------------");

				String misSummaryADSReg_UIValue = misSummaryList.get(6);
				System.out.println("misSummaryADSReg_UIValue:- " + misSummaryADSReg_UIValue);
				sAssertion.assertEquals(misSummaryADSReg_UIValue, misSummaryADSReg_UIValue,
						"Validating misSummaryADSReg_UIValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryVereq_UIValue = misSummaryList.get(7);
				System.out.println("misSummaryVereq_UIValue: " + misSummaryVereq_UIValue);
				ReportResultTotalNoOfVreq = DBConnection
						.getValueFromDB(DBQuery.NoOfVreq_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVreq, misSummaryVereq_UIValue,
						"misSummaryVereq_UIValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryVeres_UIValue = misSummaryList.get(8);
				System.out.println("misSummaryVeres_UIValue: " + misSummaryVeres_UIValue);
				ReportResultTotalNoOfVeres = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVeres, misSummaryVeres_UIValue,
						"misSummaryVeres_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryVeres_Y_Value = misSummaryList.get(9);
				System.out.println("misSummaryVeres_Y_Value:-" + misSummaryVeres_Y_Value);
				ReportResultTotalNoOfVres_Y = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_Y_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, misSummaryVeres_Y_Value,
						"misSummaryVeres_Y_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryVeres_N_Value = misSummaryList.get(10);
				System.out.println("misSummaryVeres_N_Value:-" + misSummaryVeres_N_Value);
				ReportResultTotalNoOfVres_N = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_N_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVres_N, misSummaryVeres_N_Value,
						"misSummaryVeres_N_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryVeres_U_Value = misSummaryList.get(11);
				System.out.println("misSummaryVeres_U_Value:-" + misSummaryVeres_U_Value);
				ReportResultTotalNoofUnabletoAuthenticateVRes_U = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_U_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U, misSummaryVeres_U_Value,
						"misSummaryVeres_U_Value:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryPareqValue = misSummaryList.get(12);
				System.out.println("misSummaryPareqValue:-" + misSummaryPareqValue);
				ReportResultTotalNoofPAReq = DBConnection
						.getValueFromDB(DBQuery.NoOfPAReq_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofPAReq, misSummaryPareqValue,
						"misSummaryPareqValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryPares_A_Value = misSummaryList.get(13);
				System.out.println("misSummaryPares_A_Value:-" + misSummaryPares_A_Value);
				ReportResultTotalNoofAttemptedPARes_A = DBConnection
						.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A, misSummaryPares_A_Value,
						"misSummaryPares_A_Value :" + CardUnion + "" + CardType + "");
				System.out.println("------------");

				String misSummaryPares_Y_Value = misSummaryList.get(14);
				System.out.println("misSummaryPares_Y_Value:-" + misSummaryPares_Y_Value);
				ReportResultPAReswithvalidAuthentication_Y = DBConnection
						.getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y, misSummaryPares_Y_Value,
						"misSummaryPares_Y_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryPares_N_Value = misSummaryList.get(15);
				System.out.println("misSummaryPares_N_Value:-" + misSummaryPares_N_Value);
				ReportResultPAReswithInvalidAuthentication_N = DBConnection
						.getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N, misSummaryPares_N_Value,
						"misSummaryPares_N_Value :" + CardUnion + "_" + CardType + "");

				String misSummaryPares_U_Value = misSummaryList.get(16);
				System.out.println("misSummaryPares_U_Value:-" + misSummaryPares_U_Value);
				ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
						.getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U, misSummaryPares_U_Value,
						"misSummaryPares_U_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String misSummaryParesProgInit = misSummaryList.get(17);
				System.out.println("misSummaryParesProgInit: " + misSummaryParesProgInit);
				System.out.println("------------");

				String misSummaryParesProgAbortValue = misSummaryList.get(18);
				System.out.println("misSummaryParesProgAbortValue:-" + misSummaryParesProgAbortValue);
				System.out.println("------------");

				String misSummaryParesProgRespValue = misSummaryList.get(19);
				System.out.println("misSummaryParesProgRespValue:-" + misSummaryParesProgRespValue);
				System.out.println("------------");

				String misSummaryParesProgCompValue = misSummaryList.get(20);
				System.out.println("misSummaryParesProgCompValue:-" + misSummaryParesProgCompValue);
				System.out.println("------------");

				String misSummaryCacheMissValue = misSummaryList.get(21);
				System.out.println("misSummaryCacheMissValue:-" + misSummaryCacheMissValue);

				// Validating percentage

				String misSummaryVeresPareq_UIValue = misSummaryList.get(3);
				System.out.println("misSummaryVeresPareq_UIValue:-" + misSummaryVeresPareq_UIValue);
				ReportResultVeres_PareqPercentage = AcsTransactionMIS.veresPareqPercentage();
				sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ", ""),
						misSummaryVeresPareq_UIValue, "misSummaryVeresPareq_UIValue");
				System.out.println("------------");

				String misSummaryPareqPares_UIValue = misSummaryList.get(4);
				System.out.println("misSummaryPareqPares_UIValue: " + misSummaryPareqPares_UIValue);
				ReportResultPareq_ParesPercentage = AcsTransactionMIS.pareqParesPercentage();
				sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ", ""),
						misSummaryPareqPares_UIValue, "misSummaryPareqPares_UIValue: ");
				System.out.println("------------");

				String misSummaryVeresPares_UIValue = misSummaryList.get(5);
				System.out.println("misSummaryVeresPares_UIValue:- " + misSummaryVeresPares_UIValue);
				ReportResultVeres_ParesPercentage = AcsTransactionMIS.veresParesPercentage();
				sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ", ""),
						misSummaryVeresPares_UIValue, "binWiseSummaryVeresPares_UIValue: ");
				System.out.println("------------");

				// String val = DBConnection.getValueFromDB(DBQuery.NoOfVreq_Bin(Schema,
				// binDetail));
				// .out.println("val: " + val);
				// System.out.println(binModuleUI);
				System.out.println("*****************************************************************************");
				binWiseList.clear();

			}

			// validating 2.0 protocol values
			else {

				

				CardUnion = misSummaryList.get(0);
				sAssertion.assertEquals(CardUnion, CardUnion, "Validating CardUnion ");
				System.out.println("CardUnion: " + CardUnion);
				System.out.println("------------");

				CardType = misSummaryList.get(1);
				sAssertion.assertEquals(CardType, CardType, "Validating CardType: ");
				System.out.println("CardType: " + CardType);
				System.out.println("------------");
				
				String misSummaryAreq_UIValue = misSummaryList.get(6);
				System.out.println("misSummaryAreq_UIValue: " + misSummaryAreq_UIValue);
				ReportResultTotalNoOfAreq = DBConnection
						.getValueFromDB(DBQuery.Areq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfAreq, misSummaryAreq_UIValue,
						"misSummaryAreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_Y_UIValue = misSummaryList.get(7);
				System.out.println("misSummaryAres_Y_UIValue: " + misSummaryAres_Y_UIValue);
				ReportResultTotalNoOfARes_Y = DBConnection
						.getValueFromDB(DBQuery.Ares_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_Y, misSummaryAres_Y_UIValue,
						"misSummaryAres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_N_UIValue = misSummaryList.get(8);
				System.out.println("misSummaryAres_N_UIValue: " + misSummaryAres_N_UIValue);
				ReportResultTotalNoOfARes_N = DBConnection
						.getValueFromDB(DBQuery.Ares_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_N, misSummaryAres_N_UIValue,
						"misSummaryAres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_U_UIValue = misSummaryList.get(9);
				System.out.println("misSummaryAres_U_UIValue: " + misSummaryAres_U_UIValue);
				ReportResultTotalNoOfARes_U = DBConnection
						.getValueFromDB(DBQuery.Ares_U_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_U, misSummaryAres_U_UIValue,
						"misSummaryAres_U_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_R_UIValue = misSummaryList.get(10);
				System.out.println("misSummaryAres_R_UIValue: " + misSummaryAres_R_UIValue);
				ReportResultTotalNoofAres_R= DBConnection
						.getValueFromDB(DBQuery.Ares_R_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAres_R, misSummaryAres_R_UIValue,
						"misSummaryAres_R_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_C_UIValue = misSummaryList.get(11);
				System.out.println("misSummaryAres_C_UIValue: " + misSummaryAres_C_UIValue);
				ReportResultTotalNoofAres_C = DBConnection
						.getValueFromDB(DBQuery.Ares_C_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAres_C, misSummaryAres_C_UIValue,
						"misSummaryAres_C_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				//hello
				String misSummaryCreq_UIValue = misSummaryList.get(12);
				System.out.println("misSummaryCreq_UIValue: " + misSummaryCreq_UIValue);
				ReportResultTotalNoofCreq = DBConnection
						.getValueFromDB(DBQuery.Creq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofCreq, misSummaryCreq_UIValue,
						"misSummaryCreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryCres_Y_UIValue = misSummaryList.get(13);
				System.out.println("misSummaryCres_Y_UIValue: " + misSummaryCres_Y_UIValue);
				ReportResultTotalNoOfCres_Y = DBConnection
						.getValueFromDB(DBQuery.Cres_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfCres_Y, misSummaryCres_Y_UIValue,
						"misSummaryCres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryCres_N_UIValue = misSummaryList.get(14);
				System.out.println("misSummaryCres_N_UIValue: " + misSummaryCres_N_UIValue);
				ReportResultTotalNoOfCres_N = DBConnection
						.getValueFromDB(DBQuery.Cres_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfCres_N, misSummaryCres_N_UIValue,
						"misSummaryCres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRreq_UIValue = misSummaryList.get(6);
				System.out.println("misSummaryRreq_UIValue: " + misSummaryRreq_UIValue);
				ReportResultTotalNoofRReq = DBConnection
						.getValueFromDB(DBQuery.Rreq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRReq, misSummaryRreq_UIValue,
						"misSummaryRreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRres_Y_UIValue = misSummaryList.get(7);
				System.out.println("misSummaryRres_Y_UIValue: " + misSummaryRres_Y_UIValue);
				ReportResultTotalNoofRRes_Y= DBConnection
						.getValueFromDB(DBQuery.Rres_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRRes_Y, misSummaryRres_Y_UIValue,
						"misSummaryRres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRres_N_UIValue = misSummaryList.get(8);
				System.out.println("misSummaryRres_N_UIValue: " + misSummaryRres_N_UIValue);
				ReportResultTotalNoofRRes_N = DBConnection
						.getValueFromDB(DBQuery.Rres_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRRes_N, misSummaryRres_N_UIValue,
						"misSummaryRres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
			}
		}
		moveToElement(acsTxnMis.getPdcSummaryHeader());
		generic.explicitWait(3);

		// fetching the value for formula:-
		/*
		 * ReportResultTotalNoOfVres_N = acsTxnMis.getTotalNoOfVres_N_Value().getText();
		 * ReportResultTotalNoOfVres_Y =
		 * acsTxnMis.getMisSummaryVeres_Y_Value().getText();
		 * ReportResultTotalNoofUnabletoAuthenticateVRes_U =
		 * acsTxnMis.getMisSummaryVeres_U_Value().getText(); ReportResultTotalNoofPAReq
		 * = acsTxnMis.getMisSummaryPareqValue().getText();
		 * 
		 * ReportResultTotalNoofSuccessPARes =
		 * acsTxnMis.getTotalNoofSuccessPAResValue().getText();
		 * 
		 * String misSummaryVeresPareq_UIValue =
		 * acsTxnMis.getMisSummaryVeresPareqValue().getText();
		 * System.out.println("misSummaryVeresPareqUIValue:-" +
		 * misSummaryVeresPareq_UIValue); ReportResultVeres_PareqPercentage =
		 * AcsTransactionMIS.veresPareqPercentage();
		 * sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ",
		 * ""), misSummaryVeresPareq_UIValue, "misSummaryVeresPareq_UIValue");
		 * 
		 * String misSummaryPareqPares_UIValue =
		 * acsTxnMis.getMisSummaryPareqParesValue().getText();
		 * System.out.println("misSummaryPareqPares_UIValue: " +
		 * misSummaryPareqPares_UIValue); ReportResultPareq_ParesPercentage =
		 * AcsTransactionMIS.pareqParesPercentage();
		 * sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ",
		 * ""), misSummaryPareqPares_UIValue, "misSummaryPareqPares_UIValue");
		 * 
		 * String misSummaryVeresPares_UIValu =
		 * acsTxnMis.getMisSummaryVeresParesValue().getText();
		 * System.out.println("misSummaryVeresPares_UIValu:- " +
		 * misSummaryVeresPares_UIValu); ReportResultVeres_ParesPercentage =
		 * AcsTransactionMIS.veresParesPercentage();
		 * sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ",
		 * ""), misSummaryVeresPares_UIValu, "misSummaryVeresPares_UIValu");
		 * 
		 * String MisSummaryADSReg_UIValue =
		 * acsTxnMis.getMisSummaryADSRegValue().getText();
		 * System.out.println("MisSummaryADSReg_UIValue:- " + MisSummaryADSReg_UIValue);
		 * 
		 * String MisSummaryVereq_UIValue =
		 * acsTxnMis.getMisSummaryVereqValue().getText();
		 * System.out.println("MisSummaryVereq_UIValue: " + MisSummaryVereq_UIValue);
		 * ReportResultTotalNoOfVreq =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVreq(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVreq, MisSummaryVereq_UIValue,
		 * "MisSummaryVereq_UIValue");
		 * 
		 * String MisSummaryVeresValue = acsTxnMis.getMisSummaryVeresValue().getText();
		 * System.out.println("MisSummaryVeresValue: " + MisSummaryVeresValue);
		 * 
		 * String MisSummaryVeres_Y_Value =
		 * acsTxnMis.getMisSummaryVeres_Y_Value().getText();
		 * System.out.println("MisSummaryVeres_Y_Value:-" + MisSummaryVeres_Y_Value);
		 * ReportResultTotalNoOfVres_Y =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVres_Y(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, MisSummaryVeres_Y_Value,
		 * "MisSummaryVeres_Y_Value");
		 * 
		 * String MisSummaryVeres_N_Value =
		 * acsTxnMis.getMisSummaryVeres_N_Value().getText();
		 * System.out.println("MisSummaryVeres_N_Value:-" + MisSummaryVeres_N_Value);
		 * ReportResultTotalNoOfVres_N =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVres_N(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVres_N, MisSummaryVeres_N_Value,
		 * "MisSummaryVeres_N_Value");
		 * 
		 * String MisSummaryVeres_U_Value =
		 * acsTxnMis.getMisSummaryVeres_U_Value().getText();
		 * System.out.println("MisSummaryVeres_U_Value:-" + MisSummaryVeres_U_Value);
		 * ReportResultTotalNoofUnabletoAuthenticateVRes_U =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVres_U(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U,
		 * MisSummaryVeres_U_Value, "MisSummaryVeres_U_Value");
		 * 
		 * String MisSummaryPareqValue = acsTxnMis.getMisSummaryPareqValue().getText();
		 * System.out.println("MisSummaryPareqValue:-" + MisSummaryPareqValue);
		 * ReportResultTotalNoofPAReq =
		 * DBConnection.getValueFromDB(DBQuery.NoOfPAReq(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofPAReq, MisSummaryPareqValue,
		 * "MisSummaryPareqValue");
		 * 
		 * String MisSummaryPares_A_Value =
		 * acsTxnMis.getMisSummaryPares_A_Value().getText();
		 * System.out.println("MisSummaryPares_A_Value:-" + MisSummaryPares_A_Value);
		 * ReportResultTotalNoofAttemptedPARes_A =
		 * DBConnection.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A,
		 * MisSummaryPares_A_Value, "MisSummaryPares_A_Value");
		 * 
		 * String MisSummaryPares_Y_Value =
		 * acsTxnMis.getMisSummaryPares_Y_Value().getText();
		 * System.out.println("MisSummaryPares_Y_Value:-" + MisSummaryPares_Y_Value);
		 * ReportResultPAReswithvalidAuthentication_Y = DBConnection
		 * .getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y(Schema));
		 * sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y,
		 * MisSummaryPares_Y_Value, "MisSummaryPares_Y_Value");
		 * 
		 * String MisSummaryPares_N_Value =
		 * acsTxnMis.getMisSummaryPares_N_Value().getText();
		 * System.out.println("MisSummaryPares_N_Value:-" + MisSummaryPares_N_Value);
		 * ReportResultPAReswithInvalidAuthentication_N = DBConnection
		 * .getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N(Schema));
		 * sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N,
		 * MisSummaryPares_N_Value, "MisSummaryPares_N_Value");
		 * 
		 * String MisSummaryPares_U_Value =
		 * acsTxnMis.getMisSummaryPares_U_Value().getText();
		 * System.out.println("MisSummaryPares_U_Value:-" + MisSummaryPares_U_Value);
		 * ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
		 * .getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U,
		 * MisSummaryPares_U_Value, "MisSummaryPares_U_Value");
		 * 
		 * String MisSummaryParesProgInit =
		 * acsTxnMis.getMisSummaryParesProgInit().getText();
		 * System.out.println("MisSummaryParesProgInit: " + MisSummaryParesProgInit);
		 * 
		 * String MisSummaryParesProgAbortValue =
		 * acsTxnMis.getMisSummaryParesProgAbortValue().getText();
		 * System.out.println("MisSummaryParesProgAbortValue:-" +
		 * MisSummaryParesProgAbortValue);
		 * 
		 * String MisSummaryParesProgRespValue =
		 * acsTxnMis.getMisSummaryParesProgRespValue().getText();
		 * System.out.println("MisSummaryParesProgRespValue:-" +
		 * MisSummaryParesProgRespValue);
		 * 
		 * String MisSummaryParesProgCompValue =
		 * acsTxnMis.getMisSummaryParesProgCompValue().getText();
		 * System.out.println("MisSummaryParesProgCompValue:-" +
		 * MisSummaryParesProgCompValue);
		 * 
		 * String MisSummaryCacheMissValue =
		 * acsTxnMis.getMisSummaryCacheMissValue().getText();
		 * System.out.println("MisSummaryCacheMissValue:-" + MisSummaryCacheMissValue);
		 * 
		 */ sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] validatePdcSummary() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validatePdcSummary", priority = 4, enabled = false)
	public void validatePdcSummary(String IssuerBankId, String IssuerBankName, String ProtocalVersion, String FromDate,
			String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate, String ToMonth,
			String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		System.out.println("----validatevalidateMisSummary----");
		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		LinkedHashMap<String, String> pdcSummaryUI = new LinkedHashMap<String, String>();
		ArrayList<String> pdcSummaryList = new ArrayList<String>();
		
		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		
		//Selecting 1.0 protocol version
		if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
			System.out.println("Clicked 1.0 protocol version");
			acsTxnMis.getThreeDS1Button().click();
		} else {
			System.out.println("2.0 protocol version");
		}
		//acsTxnMis.getThreeDS1Button().click();

		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// July 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off")) {
						dayXpath.click();
						if (DBQuery.cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(DBQuery.cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);
		
		
		int MisSummary_trSize = driver.findElements(By.xpath(
				"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr"))
				.size();
		int MisSummary_tdSize = driver.findElements(By.xpath(
				"(//div[text()='MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td"))
				.size();

		System.out.println("MisSummary_trSize: " + MisSummary_trSize);
		System.out.println("MisSummary_tdSize: " + MisSummary_tdSize);

		for (int i = 1; i <= MisSummary_trSize; i++) {

			for (int j = 1; j <= MisSummary_tdSize; j++) {
				String headerDetail = driver.findElement(By.xpath(
						"(//div[text()='PDC Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/tr[1])[1]/th["
								+ j + "]"))
						.getText();
				String misSummaryDetails = driver.findElement(By.xpath(
						"(//div[text()='PDC Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2])[1]/tr[1]/td["
								+ j + "]"))
						.getText();
				pdcSummaryList.add(misSummaryDetails);
				pdcSummaryUI.put(headerDetail, misSummaryDetails);

			}

			// Validate the values

			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				
				String System_Type = pdcSummaryList.get(0);
				sAssertion.assertEquals(System_Type, "Accosa IVS", "Validate SytemType ");
				System.out.println("System_Type: " + System_Type);
				System.out.println("------------");

				CardUnion = pdcSummaryList.get(1);
				sAssertion.assertEquals(CardUnion, CardUnion, "Validating CardUnion ");
				System.out.println("CardUnion: " + CardUnion);
				System.out.println("------------");

				CardType = pdcSummaryList.get(2);
				sAssertion.assertEquals(CardType, CardType, "Validating CardType: ");
				System.out.println("CardType: " + CardType);
				System.out.println("------------");

				String pdcSummaryADSReg_UIValue = pdcSummaryList.get(6);
				System.out.println("pdcSummaryADSReg_UIValue:- " + pdcSummaryADSReg_UIValue);
				sAssertion.assertEquals(pdcSummaryADSReg_UIValue, pdcSummaryADSReg_UIValue,
						"Validating pdcSummaryADSReg_UIValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryVereq_UIValue = pdcSummaryList.get(7);
				System.out.println("pdcSummaryVereq_UIValue: " + pdcSummaryVereq_UIValue);
				ReportResultTotalNoOfVreq = DBConnection
						.getValueFromDB(DBQuery.NoOfVreq_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVreq, pdcSummaryVereq_UIValue,
						"pdcSummaryVereq_UIValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryVeres_UIValue= pdcSummaryList.get(8);
				System.out.println("pdcSummaryVeres_UIValue: " + pdcSummaryVeres_UIValue);
				ReportResultTotalNoOfVeres = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVeres, pdcSummaryVeres_UIValue,
						"pdcSummaryVeres_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryVeres_Y_Value = pdcSummaryList.get(9);
				System.out.println("pdcSummaryVeres_Y_Value:-" + pdcSummaryVeres_Y_Value);
				ReportResultTotalNoOfVres_Y = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_Y_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, pdcSummaryVeres_Y_Value,
						"pdcSummaryVeres_Y_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryVeres_N_Value = pdcSummaryList.get(10);
				System.out.println("pdcSummaryVeres_N_Value:-" + pdcSummaryVeres_N_Value);
				ReportResultTotalNoOfVres_N = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_N_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfVres_N, pdcSummaryVeres_N_Value,
						"pdcSummaryVeres_N_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryVeres_U_Value = pdcSummaryList.get(11);
				System.out.println("pdcSummaryVeres_U_Value:-" + pdcSummaryVeres_U_Value);
				ReportResultTotalNoofUnabletoAuthenticateVRes_U = DBConnection
						.getValueFromDB(DBQuery.NoOfVres_U_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U, pdcSummaryVeres_U_Value,
						"pdcSummaryVeres_U_Value:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryPareqValue = pdcSummaryList.get(12);
				System.out.println("pdcSummaryPareqValue:-" + pdcSummaryPareqValue);
				ReportResultTotalNoofPAReq = DBConnection
						.getValueFromDB(DBQuery.NoOfPAReq_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofPAReq, pdcSummaryPareqValue,
						"pdcSummaryPareqValue:" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryPares_A_Value = pdcSummaryList.get(13);
				System.out.println("pdcSummaryPares_A_Value:-" + pdcSummaryPares_A_Value);
				ReportResultTotalNoofAttemptedPARes_A = DBConnection
						.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A, pdcSummaryPares_A_Value,
						"pdcSummaryPares_A_Value :" + CardUnion + "" + CardType + "");
				System.out.println("------------");

				String pdcSummaryPares_Y_Value = pdcSummaryList.get(14);
				System.out.println("pdcSummaryPares_Y_Value:-" + pdcSummaryPares_Y_Value);
				ReportResultPAReswithvalidAuthentication_Y = DBConnection
						.getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y, pdcSummaryPares_Y_Value,
						"pdcSummaryPares_Y_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryPares_N_Value = pdcSummaryList.get(15);
				System.out.println("pdcSummaryPares_N_Value:-" + pdcSummaryPares_N_Value);
				ReportResultPAReswithInvalidAuthentication_N = DBConnection
						.getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N, pdcSummaryPares_N_Value,
						"pdcSummaryPares_N_Value :" + CardUnion + "_" + CardType + "");

				String pdcSummaryPares_U_Value = pdcSummaryList.get(16);
				System.out.println("pdcSummaryPares_U_Value:-" + pdcSummaryPares_U_Value);
				ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
						.getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U_Mis(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U, pdcSummaryPares_U_Value,
						"pdcSummaryPares_U_Value :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");

				String pdcSummaryParesProgInit = pdcSummaryList.get(17);
				System.out.println("pdcSummaryParesProgInit: " + pdcSummaryParesProgInit);
				System.out.println("------------");

				String pdcSummaryParesProgAbortValue = pdcSummaryList.get(18);
				System.out.println("pdcSummaryParesProgAbortValue:-" + pdcSummaryParesProgAbortValue);
				System.out.println("------------");

				String pdcSummaryParesProgRespValue = pdcSummaryList.get(19);
				System.out.println("pdcSummaryParesProgRespValue:-" + pdcSummaryParesProgRespValue);
				System.out.println("------------");

				String pdcSummaryParesProgCompValue = pdcSummaryList.get(20);
				System.out.println("pdcSummaryParesProgCompValue:-" + pdcSummaryParesProgCompValue);
				System.out.println("------------");

				String pdcSummaryCacheMissValue = pdcSummaryList.get(21);
				System.out.println("pdcSummaryCacheMissValue:-" + pdcSummaryCacheMissValue);

				// Validating percentage

				String pdcSummaryVeresPareq_UIValue = pdcSummaryList.get(3);
				System.out.println("pdcSummaryVeresPareq_UIValue:-" + pdcSummaryVeresPareq_UIValue);
				ReportResultVeres_PareqPercentage = AcsTransactionMIS.veresPareqPercentage();
				sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ", ""),
						pdcSummaryVeresPareq_UIValue, "pdcSummaryVeresPareq_UIValue");
				System.out.println("------------");

				String pdcSummaryPareqPares_UIValue = pdcSummaryList.get(4);
				System.out.println("pdcSummaryPareqPares_UIValue: " + pdcSummaryPareqPares_UIValue);
				ReportResultPareq_ParesPercentage = AcsTransactionMIS.pareqParesPercentage();
				sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ", ""),
						pdcSummaryPareqPares_UIValue, "pdcSummaryPareqPares_UIValue: ");
				System.out.println("------------");

				String pdcSummaryVeresPares_UIValue = pdcSummaryList.get(5);
				System.out.println("misSummaryVeresPares_UIValue:- " + pdcSummaryVeresPares_UIValue);
				ReportResultVeres_ParesPercentage = AcsTransactionMIS.veresParesPercentage();
				sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ", ""),
						pdcSummaryVeresPares_UIValue, "pdcSummaryVeresPares_UIValue: ");
				System.out.println("------------");

				// String val = DBConnection.getValueFromDB(DBQuery.NoOfVreq_Bin(Schema,
				// binDetail));
				// .out.println("val: " + val);
				// System.out.println(binModuleUI);
				System.out.println("*****************************************************************************");
				binWiseList.clear();
			}

			// validating 2.0 protocol values
			else {
				CardUnion = pdcSummaryList.get(0);
				sAssertion.assertEquals(CardUnion, CardUnion, "Validating CardUnion ");
				System.out.println("CardUnion: " + CardUnion);
				System.out.println("------------");

				CardType = pdcSummaryList.get(1);
				sAssertion.assertEquals(CardType, CardType, "Validating CardType: ");
				System.out.println("CardType: " + CardType);
				System.out.println("------------");
				
				String misSummaryAreq_UIValue = pdcSummaryList.get(6);
				System.out.println("misSummaryAreq_UIValue: " + misSummaryAreq_UIValue);
				ReportResultTotalNoOfAreq = DBConnection
						.getValueFromDB(DBQuery.Areq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfAreq, misSummaryAreq_UIValue,
						"misSummaryAreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_Y_UIValue = pdcSummaryList.get(7);
				System.out.println("misSummaryAres_Y_UIValue: " + misSummaryAres_Y_UIValue);
				ReportResultTotalNoOfARes_Y = DBConnection
						.getValueFromDB(DBQuery.Ares_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_Y, misSummaryAres_Y_UIValue,
						"misSummaryAres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_N_UIValue = pdcSummaryList.get(8);
				System.out.println("misSummaryAres_N_UIValue: " + misSummaryAres_N_UIValue);
				ReportResultTotalNoOfARes_N = DBConnection
						.getValueFromDB(DBQuery.Ares_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_N, misSummaryAres_N_UIValue,
						"misSummaryAres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_U_UIValue = pdcSummaryList.get(9);
				System.out.println("misSummaryAres_U_UIValue: " + misSummaryAres_U_UIValue);
				ReportResultTotalNoOfARes_U = DBConnection
						.getValueFromDB(DBQuery.Ares_U_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfARes_U, misSummaryAres_U_UIValue,
						"misSummaryAres_U_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_R_UIValue = pdcSummaryList.get(10);
				System.out.println("misSummaryAres_R_UIValue: " + misSummaryAres_R_UIValue);
				ReportResultTotalNoofAres_R= DBConnection
						.getValueFromDB(DBQuery.Ares_R_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAres_R, misSummaryAres_R_UIValue,
						"misSummaryAres_R_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryAres_C_UIValue = pdcSummaryList.get(11);
				System.out.println("misSummaryAres_C_UIValue: " + misSummaryAres_C_UIValue);
				ReportResultTotalNoofAres_C = DBConnection
						.getValueFromDB(DBQuery.Ares_C_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofAres_C, misSummaryAres_C_UIValue,
						"misSummaryAres_C_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				//hello
				String misSummaryCreq_UIValue = pdcSummaryList.get(12);
				System.out.println("misSummaryCreq_UIValue: " + misSummaryCreq_UIValue);
				ReportResultTotalNoofCreq = DBConnection
						.getValueFromDB(DBQuery.Creq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofCreq, misSummaryCreq_UIValue,
						"misSummaryCreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryCres_Y_UIValue = pdcSummaryList.get(13);
				System.out.println("misSummaryCres_Y_UIValue: " + misSummaryCres_Y_UIValue);
				ReportResultTotalNoOfCres_Y = DBConnection
						.getValueFromDB(DBQuery.Cres_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfCres_Y, misSummaryCres_Y_UIValue,
						"misSummaryCres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryCres_N_UIValue = pdcSummaryList.get(14);
				System.out.println("misSummaryCres_N_UIValue: " + misSummaryCres_N_UIValue);
				ReportResultTotalNoOfCres_N = DBConnection
						.getValueFromDB(DBQuery.Cres_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoOfCres_N, misSummaryCres_N_UIValue,
						"misSummaryCres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRreq_UIValue = pdcSummaryList.get(6);
				System.out.println("misSummaryRreq_UIValue: " + misSummaryRreq_UIValue);
				ReportResultTotalNoofRReq = DBConnection
						.getValueFromDB(DBQuery.Rreq_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRReq, misSummaryRreq_UIValue,
						"misSummaryRreq_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRres_Y_UIValue = pdcSummaryList.get(7);
				System.out.println("misSummaryRres_Y_UIValue: " + misSummaryRres_Y_UIValue);
				ReportResultTotalNoofRRes_Y= DBConnection
						.getValueFromDB(DBQuery.Rres_Y_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRRes_Y, misSummaryRres_Y_UIValue,
						"misSummaryRres_Y_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				
				String misSummaryRres_N_UIValue = pdcSummaryList.get(8);
				System.out.println("misSummaryRres_N_UIValue: " + misSummaryRres_N_UIValue);
				ReportResultTotalNoofRRes_N = DBConnection
						.getValueFromDB(DBQuery.Rres_N_Mis_2_0(Schema, CardUnion, CardType));
				sAssertion.assertEquals(ReportResultTotalNoofRRes_N, misSummaryRres_N_UIValue,
						"misSummaryRres_N_UIValue validation :" + CardUnion + "_" + CardType + "");
				System.out.println("------------");
				binWiseList.clear();
			}
		}
		
		/*String SystemType = null;
		String CardUnion = null;
		String VeresPareq = null;

		moveToElement(acsTxnMis.getPdcSummaryHeader());
		generic.explicitWait(3);

		// fetching the value for formula:-
		ReportResultTotalNoOfVres_N = acsTxnMis.getTotalNoOfVres_N_Value().getText();
		ReportResultTotalNoOfVres_Y = acsTxnMis.getPdcSummaryVeres_Y().getText();
		ReportResultTotalNoofUnabletoAuthenticateVRes_U = acsTxnMis.getPdcSummaryVeres_U().getText();
		ReportResultTotalNoofPAReq = acsTxnMis.getPdcSummaryPareq().getText();

		ReportResultTotalNoofSuccessPARes = acsTxnMis.getTotalNoofSuccessPAResValue().getText();

		// Comparing value from UI and DB:
		String pdcSummaryVeresPareq_UIValue = acsTxnMis.getPdcSummaryVeresPareqPerc().getText();
		System.out.println("pdcSummaryVeresPareq_UIValue:-" + pdcSummaryVeresPareq_UIValue);
		ReportResultVeres_PareqPercentage = AcsTransactionMIS.veresPareqPercentage();
		sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ", ""), pdcSummaryVeresPareq_UIValue,
				"pdcSummaryVeresPareq_UIValue");

		String pdcSummaryPareqPares_UIValue = acsTxnMis.getPdcSummaryPareqParesPerc().getText();
		System.out.println("pdcSummaryPareqPares_UIValue: " + pdcSummaryPareqPares_UIValue);
		ReportResultPareq_ParesPercentage = AcsTransactionMIS.pareqParesPercentage();
		sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ", ""), pdcSummaryPareqPares_UIValue,
				"pdcSummaryPareqPares_UIValue");

		String pdcSummaryVeresPares_UIValue = acsTxnMis.getPdcSummaryVeresParesPerc().getText();
		System.out.println("pdcSummaryVeresPares_UIValue:- " + pdcSummaryVeresPares_UIValue);
		ReportResultVeres_ParesPercentage = AcsTransactionMIS.veresParesPercentage();
		sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ", ""), pdcSummaryVeresPares_UIValue,
				"pdcSummaryVeresPares_UIValue");

		String pdcSummaryADSReg_UIValue = acsTxnMis.getPdcSummaryADSReg().getText();
		System.out.println("pdcSummaryADSReg_UIValue:- " + pdcSummaryADSReg_UIValue);

		String pdcSummaryVereq_UIValue = acsTxnMis.getPdcSummaryVereq().getText();
		System.out.println("pdcSummaryVereq_UIValue: " + pdcSummaryVereq_UIValue);
		ReportResultTotalNoOfVreq = DBConnection.getValueFromDB(DBQuery.NoOfVreq(Schema));
		sAssertion.assertEquals(ReportResultTotalNoOfVreq, pdcSummaryVereq_UIValue, "pdcSummaryVereq_UIValue");

		String pdcSummaryVeresValue = acsTxnMis.getPdcSummaryVeres().getText();
		System.out.println("pdcSummaryVeresValue: " + pdcSummaryVeresValue);

		String pdcSummaryVeres_Y_Value = acsTxnMis.getPdcSummaryVeres_Y().getText();
		System.out.println("pdcSummaryVeres_Y_Value:-" + pdcSummaryVeres_Y_Value);
		ReportResultTotalNoOfVres_Y = DBConnection.getValueFromDB(DBQuery.NoOfVres_Y(Schema));
		sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, pdcSummaryVeres_Y_Value, "pdcSummaryVeres_Y_Value");

		String pdcSummaryVeres_N_Value = acsTxnMis.getPdcSummaryVeres_N().getText();
		System.out.println("pdcSummaryVeres_N_Value:-" + pdcSummaryVeres_N_Value);
		ReportResultTotalNoOfVres_N = DBConnection.getValueFromDB(DBQuery.NoOfVres_N(Schema));
		sAssertion.assertEquals(ReportResultTotalNoOfVres_N, pdcSummaryVeres_N_Value, "pdcSummaryVeres_N_Value");

		String pdcSummaryVeres_U_Value = acsTxnMis.getPdcSummaryVeres_U().getText();
		System.out.println("pdcSummaryVeres_U_Value:-" + pdcSummaryVeres_U_Value);
		ReportResultTotalNoofUnabletoAuthenticateVRes_U = DBConnection.getValueFromDB(DBQuery.NoOfVres_U(Schema));
		sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U, pdcSummaryVeres_U_Value,
				"pdcSummaryVeres_U_Value");

		String pdcSummaryPareqValue = acsTxnMis.getPdcSummaryPareq().getText();
		System.out.println("pdcSummaryPareqValue:-" + pdcSummaryPareqValue);
		ReportResultTotalNoofPAReq = DBConnection.getValueFromDB(DBQuery.NoOfPAReq(Schema));
		sAssertion.assertEquals(ReportResultTotalNoofPAReq, pdcSummaryPareqValue, "pdcSummaryPareqValue");

		String pdcSummaryPares_A_Value = acsTxnMis.getPdcSummaryPares_A().getText();
		System.out.println("pdcSummaryPares_A_Value:-" + pdcSummaryPares_A_Value);
		ReportResultTotalNoofAttemptedPARes_A = DBConnection.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A(Schema));
		sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A, pdcSummaryPares_A_Value,
				"pdcSummaryPares_A_Value");

		String pdcSummaryPares_Y_Value = acsTxnMis.getPdcSummaryPares_Y().getText();
		System.out.println("pdcSummaryPares_Y_Value:-" + pdcSummaryPares_Y_Value);
		ReportResultPAReswithvalidAuthentication_Y = DBConnection
				.getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y(Schema));
		sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y, pdcSummaryPares_Y_Value,
				"pdcSummaryPares_Y_Value");

		String pdcSummaryPares_N_Value = acsTxnMis.getPdcSummaryPares_N().getText();
		System.out.println("pdcSummaryPares_N_Value:-" + pdcSummaryPares_N_Value);
		ReportResultPAReswithInvalidAuthentication_N = DBConnection
				.getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N(Schema));
		sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N, pdcSummaryPares_N_Value,
				"pdcSummaryPares_N_Value");

		String pdcSummaryPares_U_Value = acsTxnMis.getPdcSummaryPares_U().getText();
		System.out.println("pdcSummaryPares_U_Value:-" + pdcSummaryPares_U_Value);
		ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
				.getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U(Schema));
		sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U, pdcSummaryPares_U_Value,
				"pdcSummaryPares_U_Value");

		String pdcSummaryParesProgInit = acsTxnMis.getPdcSummaryProgInit().getText();
		System.out.println("pdcSummaryParesProgInit: " + pdcSummaryParesProgInit);

		String pdcSummaryParesProgAbortValue = acsTxnMis.getPdcSummaryProgAbort().getText();
		System.out.println("pdcSummaryParesProgAbortValue:-" + pdcSummaryParesProgAbortValue);

		String pdcSummaryParesProgRespValue = acsTxnMis.getPdcSummaryProgResp().getText();
		System.out.println("pdcSummaryParesProgRespValue:-" + pdcSummaryParesProgRespValue);

		String pdcSummaryParesProgCompValue = acsTxnMis.getPdcSummaryProgComp().getText();
		System.out.println("pdcSummaryParesProgCompValue:-" + pdcSummaryParesProgCompValue);

		String pdcSummaryCacheMissValue = acsTxnMis.getPdcSummaryCacheMiss().getText();
		System.out.println("pdcSummaryCacheMissValue:-" + pdcSummaryCacheMissValue);*/

		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] validateBinWiseMisSummary() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validateBinWiseMisSummary", priority = 5, enabled = true)
	public void validateBinWiseMisSummary(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		System.out.println("----validateBinWiseMisSummary----");
		// DateTimeFormatter.ofPattern("yyyy/MMM/dd/HH/mm/ss");

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/ss");
		Date currentDate = new Date();
		String dateAndTime = FORMATTER.format(currentDate);
		TimeZone utcTimeZone = TimeZone.getTimeZone("UTC");
		FORMATTER.setTimeZone(utcTimeZone);
		String utcTime = FORMATTER.format(currentDate);

		// current Date and time

		System.out.println("dateAndTime:-" + dateAndTime);
		String[] dateTime = dateAndTime.split("/");
		DBQuery.cYear = dateTime[0];
		DBQuery.cMonth = dateTime[1];
		DBQuery.cDay = dateTime[2];
		DBQuery.cHour = String.format("%01d", Integer.parseInt(dateTime[3]));
		DBQuery.cMinutes = dateTime[4];
		DBQuery.cSeconds = dateTime[5];

		// UTC time Zone
		System.out.println("utcTime: " + utcTime);
		String[] utcDateTime = utcTime.split("/");
		DBQuery.utcYear = utcDateTime[0];
		DBQuery.utcMonth = utcDateTime[1];
		DBQuery.utcDay = utcDateTime[2];
		DBQuery.utcHour = utcDateTime[3];
		DBQuery.utcMinutes = utcDateTime[4];
		DBQuery.ucSeconds = utcDateTime[5];

		LocalDateTime now = LocalDateTime.now();
		DBQuery.nMonth = String.format("%02d", now.getMonthValue());
		System.out.println("nMonth:-" + DBQuery.nMonth);

		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		generic.explicitWait(1);

		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS Transaction MIS
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		acsTxnMis.getACSTransactionMisSideBar().click();
		generic.explicitWait(2);

		
		// selecting protocol version
				if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
					System.out.println("Clicked 1.0 protocol version");
					acsTxnMis.getThreeDS1Button().click();
				} else {
					System.out.println("2.0 protocol version");
				}
		//acsTxnMis.getThreeDS1Button().click();

		acsTxnMis.getDatePicker().click();
		generic.explicitWait(2);

		// driver.findElement(By.xpath("(//div[@class='transaction-date__info'])[1]//span[1]")).sendKeys("10
		// Jul 2020");

		// Selecting From Date and time
		// System.out.println("cYear: " + cYear);
		// System.out.println("cMonth: " + cMonth);

		generic.selectByVisibleText(acsTxnMis.getFromMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getFromYearSelectDropdown(), DBQuery.cYear);
		// driver.findElement(By.xpath("(//td[@data-title='r0c6'])[2]")).click();

		generic.selectByVisibleText(acsTxnMis.getFromHourSelectDropdown(), FromHour);
		generic.selectByVisibleText(acsTxnMis.getFromMinuteselectDropdown(), FromMinutes);
		generic.selectByVisibleText(acsTxnMis.getFromSecondselectDropdown(), "00");

		// Picking "to" Date and Time
		generic.selectByVisibleText(acsTxnMis.getToMonthSelectDropdown(), DBQuery.cMonth);
		generic.selectByVisibleText(acsTxnMis.getToYearSelectDropdown(), DBQuery.cYear);

		generic.selectByVisibleText(acsTxnMis.getToHourSelectDropdown(), DBQuery.cHour);
		generic.selectByVisibleText(acsTxnMis.getToMinuteselectDropdown(), DBQuery.cMinutes);
		generic.selectByVisibleText(acsTxnMis.getToSecondselectDropdown(), DBQuery.cSeconds);

		// Code for picking 'to' day
		int trSize = driver
				.findElements(
						By.xpath("//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr"))
				.size();

		for (int i = 0; i < trSize; i++) {
			for (int j = 0; j < 7; j++) {
				WebElement dayXpath = driver.findElement(By.xpath(
						"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
								+ i + "c" + j + "']"));
				String currentDay = dayXpath.getText();
				String attr = dayXpath.getAttribute("class");
				if (currentDay.equalsIgnoreCase("1")) {
					if (!attr.contains("off")) {
						dayXpath.click();
						if (DBQuery.cDay.equalsIgnoreCase("01")) {
							driver.findElement(By.xpath(
									"//div[@class='drp-calendar right']/div[@class='calendar-table']/table/tbody/tr/td[@data-title='r"
											+ i + "c" + j + "']"))
									.click();
							System.out.println("clicking 01 again");
						}
					}
				} else if (currentDay.equalsIgnoreCase(DBQuery.cDay.replaceFirst("^0+(?!$)", ""))) {
					if (!attr.contains("off")) {
						dayXpath.click();
					}
					System.out.println("Clicked...Day" + DBQuery.cDay);
				}
			}
		}

		generic.explicitWait(10);

		acsTxnMis.getApplyButton().click();
		acsTxnMis.getFetchReportButton().click();
		generic.explicitWait(10);

		moveToElement(acsTxnMis.getPdcSummaryHeader());
		generic.explicitWait(3);

		// fetching report Bin wise
		int trBinSize = driver.findElements(By.xpath(
				"//div[text()='BIN Wise MIS Summary']/../../following::div/div/div/div/table[@class='table table-bordered']/thead/following::tbody[2]/tr"))
				.size();
		int tdSize = driver.findElements(By.xpath(
				"//div[text()='BIN Wise MIS Summary']/../../following::div/div/div/div/table[@class='table table-bordered']/thead/tr/th"))
				.size();
		System.out.println("trSize: " + trBinSize);
		System.out.println("tdSize: " + tdSize);
		for (int i = 1; i <= trBinSize; i++) {
			binDetail = driver.findElement(By.xpath(
					"//div[text()='BIN Wise MIS Summary']/../../following::div/div/div/div/table[@class='table table-bordered']/thead/following::tbody[2]/tr["
							+ i + "]/td[3]"))
					.getText();

			for (int j = 1; j <= tdSize; j++) {
				String binKey = driver.findElement(By.xpath(
						"//div[text()='BIN Wise MIS Summary']/../../following::div/div/div/div/table[@class='table table-bordered']/thead/tr/th["
								+ j + "]"))
						.getText();
				String binValue = driver.findElement(By.xpath(
						"//div[text()='BIN Wise MIS Summary']/../../following::div/div/div/div/table[@class='table table-bordered']/thead/following::tbody[2]/tr["
								+ i + "]/td[" + j + "]"))
						.getText();

				binWiseList.add(binValue);
				binModuleUI.put(binKey, binValue);
			}
			// validate values

			if (ProtocalVersion.equalsIgnoreCase("1.0.2")) {
				
			System.out.println("Validating for Bin : " + binDetail);

			SystemType = binWiseList.get(0);
			sAssertion.assertEquals(SystemType, SystemType, "Validating SystemType : " + binDetail + "");
			System.out.println("------------");

			Bin_Id = binWiseList.get(1);

			String BinIdDB = DBConnection.getValueFromDB(DBQuery.BinId_Bin(Schema, binDetail));
			System.out.println("Bin_Id UI: " + Bin_Id);
			System.out.println("Bin_Id DB: " + BinIdDB);
			sAssertion.assertEquals(Bin_Id, BinIdDB, "Validating Bin_Id : " + binDetail + "");
			System.out.println("------------");

			Bins = binWiseList.get(2);
			sAssertion.assertEquals(Bins, binDetail, "Validating binDetail: " + binDetail + "");
			System.out.println("------------");

			CardUnion = binWiseList.get(3);
			String CardUnionDB = DBConnection.getValueFromDB(DBQuery.card_Union(Schema, binDetail));
			System.out.println("CardUnion_UI" + CardUnion);
			System.out.println("CardUnionDB" + CardUnionDB);
			sAssertion.assertEquals(CardUnion, CardUnionDB, "Validating CardUnion : " + binDetail + "");
			System.out.println("------------");

			CardType = binWiseList.get(4);
			String cardTypeDB = DBConnection.getValueFromDB(DBQuery.CardType(Schema, binDetail));
			System.out.println("CardType_UI" + CardType);
			System.out.println("CardTypeDB" + cardTypeDB);
			sAssertion.assertEquals(CardType, cardTypeDB, "Validating CardType: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryADSReg_UIValue = binWiseList.get(8);
			System.out.println("binWiseSummaryADSReg_UIValue:- " + binWiseSummaryADSReg_UIValue);
			sAssertion.assertEquals(binWiseSummaryADSReg_UIValue, binWiseSummaryADSReg_UIValue,
					"Validating binWiseSummaryADSReg_UIValue :" + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryVereq_UIValue = binWiseList.get(9);
			System.out.println("binWiseSummaryVereq_UIValue: " + binWiseSummaryVereq_UIValue);
			ReportResultTotalNoOfVreq = DBConnection.getValueFromDB(DBQuery.NoOfVreq_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoOfVreq, binWiseSummaryVereq_UIValue,
					"binWiseSummaryVereq_UIValue: " + binDetail + "");
			System.out.println("------------");

			String biWiseSummaryVeresValue = binWiseList.get(10);
			System.out.println("biWiseSummaryVeresValue: " + biWiseSummaryVeresValue);
			System.out.println("------------");

			String binWiseSummaryVeres_Y_Value = binWiseList.get(11);
			System.out.println("binWiseSummaryVeres_Y_Value:-" + binWiseSummaryVeres_Y_Value);
			ReportResultTotalNoOfVres_Y = DBConnection.getValueFromDB(DBQuery.NoOfVres_Y_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoOfVres_Y, binWiseSummaryVeres_Y_Value,
					"binWiseSummaryVeres_Y_Value: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryVeres_N_Value = binWiseList.get(12);
			System.out.println("binWiseSummaryVeres_N_Value:-" + binWiseSummaryVeres_N_Value);
			ReportResultTotalNoOfVres_N = DBConnection.getValueFromDB(DBQuery.NoOfVres_N_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoOfVres_N, binWiseSummaryVeres_N_Value,
					"binWiseSummaryVeres_Y_Value: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryVeres_U_Value = binWiseList.get(13);
			System.out.println("binWiseSummaryVeres_U_Value:-" + binWiseSummaryVeres_U_Value);
			ReportResultTotalNoofUnabletoAuthenticateVRes_U = DBConnection
					.getValueFromDB(DBQuery.NoOfVres_U_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U, binWiseSummaryVeres_U_Value,
					"binWiseSummaryVeres_U_Value: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryPareqValue = binWiseList.get(14);
			System.out.println("binWiseSummaryPareqValue:-" + binWiseSummaryPareqValue);
			ReportResultTotalNoofPAReq = DBConnection.getValueFromDB(DBQuery.NoOfPAReq_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoofPAReq, binWiseSummaryPareqValue,
					"binWiseSummaryPareqValue: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryPares_A_Value = binWiseList.get(15);
			System.out.println("binWiseSummaryPares_A_Value:-" + binWiseSummaryPares_A_Value);
			ReportResultTotalNoofAttemptedPARes_A = DBConnection
					.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A, binWiseSummaryPares_A_Value,
					"binWiseSummaryPares_A_Value: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryPares_Y_Value = binWiseList.get(16);
			System.out.println("binWiseSummaryPares_Y_Value:-" + binWiseSummaryPares_Y_Value);
			ReportResultPAReswithvalidAuthentication_Y = DBConnection
					.getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y, binWiseSummaryPares_Y_Value,
					"binWiseSummaryPares_Y_Value : " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryPares_N_Value = binWiseList.get(17);
			System.out.println("binWiseSummaryPares_N_Value:-" + binWiseSummaryPares_N_Value);
			ReportResultPAReswithInvalidAuthentication_N = DBConnection
					.getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N, binWiseSummaryPares_N_Value,
					"binWiseSummaryPares_N_Value:" + binDetail + "");

			String binWiseSummaryPares_U_Value = binWiseList.get(18);
			System.out.println("binWiseSummaryPares_U_Value:-" + binWiseSummaryPares_U_Value);
			ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
					.getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U_Bin(Schema, binDetail));
			sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U, binWiseSummaryPares_U_Value,
					"binWiseSummaryPares_U_Value: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryParesProgInit = binWiseList.get(19);
			System.out.println("binWiseSummaryParesProgInit: " + binWiseSummaryParesProgInit);
			System.out.println("------------");

			String binWiseSummaryParesProgAbortValue = binWiseList.get(20);
			System.out.println("binWiseSummaryParesProgAbortValue:-" + binWiseSummaryParesProgAbortValue);
			System.out.println("------------");

			String binWiseSummaryParesProgRespValue = binWiseList.get(21);
			System.out.println("binWiseSummaryParesProgRespValue:-" + binWiseSummaryParesProgRespValue);
			System.out.println("------------");

			String binWiseSummaryParesProgCompValue = binWiseList.get(22);
			System.out.println("binWiseSummaryParesProgCompValue:-" + binWiseSummaryParesProgCompValue);
			System.out.println("------------");

			String binWiseSummaryCacheMissValue = binWiseList.get(23);
			System.out.println("binWiseSummaryCacheMissValue:-" + binWiseSummaryCacheMissValue);

			// Validating percentage

			String binWiseSummaryVeresPareq_UIValue = binWiseList.get(5);
			System.out.println("binWiseSummaryVeresPareq_UIValue:-" + binWiseSummaryVeresPareq_UIValue);
			ReportResultVeres_PareqPercentage = AcsTransactionMIS.veresPareqPercentage();
			sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ", ""),
					binWiseSummaryVeresPareq_UIValue, "binWiseSummaryVeresPareq_UIValue:" + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryPareqPares_UIValue = binWiseList.get(6);
			System.out.println("binWiseSummaryPareqPares_UIValue: " + binWiseSummaryPareqPares_UIValue);
			ReportResultPareq_ParesPercentage = AcsTransactionMIS.pareqParesPercentage();
			sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ", ""),
					binWiseSummaryPareqPares_UIValue, "binWiseSummaryPareqPares_UIValue: " + binDetail + "");
			System.out.println("------------");

			String binWiseSummaryVeresPares_UIValue = binWiseList.get(7);
			System.out.println("binWiseSummaryVeresPares_UIValue:- " + binWiseSummaryVeresPares_UIValue);
			ReportResultVeres_ParesPercentage = AcsTransactionMIS.veresParesPercentage();
			sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ", ""),
					binWiseSummaryVeresPares_UIValue, "binWiseSummaryVeresPares_UIValue: " + binDetail + "");
			System.out.println("------------");

			String val = DBConnection.getValueFromDB(DBQuery.NoOfVreq_Bin(Schema, binDetail));
			System.out.println("val: " + val);
			System.out.println(binModuleUI);
			System.out.println(
					"**********************************************************************************************");
			binWiseList.clear();
			}
			//Validating 2.0 protocol values
			else {
				
				System.out.println("Validating for Bin : " + binDetail);

				SystemType = binWiseList.get(0);
				sAssertion.assertEquals(SystemType, SystemType, "Validating SystemType : " + binDetail + "");
				System.out.println("------------");

				Bin_Id = binWiseList.get(1);

				String BinIdDB = DBConnection.getValueFromDB(DBQuery.BinId_Bin(Schema, binDetail));
				System.out.println("Bin_Id UI: " + Bin_Id);
				System.out.println("Bin_Id DB: " + BinIdDB);
				sAssertion.assertEquals(Bin_Id, BinIdDB, "Validating Bin_Id : " + binDetail + "");
				System.out.println("------------");

				Bins = binWiseList.get(2);
				sAssertion.assertEquals(Bins, binDetail, "Validating binDetail: " + binDetail + "");
				System.out.println("------------");

				CardUnion = binWiseList.get(3);
				String CardUnionDB = DBConnection.getValueFromDB(DBQuery.card_Union(Schema, binDetail));
				System.out.println("CardUnion_UI" + CardUnion);
				System.out.println("CardUnionDB" + CardUnionDB);
				sAssertion.assertEquals(CardUnion, CardUnionDB, "Validating CardUnion : " + binDetail + "");
				System.out.println("------------");

				CardType = binWiseList.get(4);
				String cardTypeDB = DBConnection.getValueFromDB(DBQuery.CardType(Schema, binDetail));
				System.out.println("CardType_UI" + CardType);
				System.out.println("CardTypeDB" + cardTypeDB);
				sAssertion.assertEquals(CardType, cardTypeDB, "Validating CardType: " + binDetail + "");
				System.out.println("------------");
				
			}

		}

		// System.out.println(binWiseList);
		// System.out.println("***************************");
		// System.out.println(binModule);

		/*
		 * // fetching the value for formula:- ReportResultTotalNoOfVres_N =
		 * acsTxnMis.getTotalNoOfVres_N_Value().getText(); ReportResultTotalNoOfVres_Y =
		 * acsTxnMis.getPdcSummaryVeres_Y().getText();
		 * ReportResultTotalNoofUnabletoAuthenticateVRes_U =
		 * acsTxnMis.getPdcSummaryVeres_U().getText(); ReportResultTotalNoofPAReq =
		 * acsTxnMis.getPdcSummaryPareq().getText();
		 * 
		 * ReportResultTotalNoofSuccessPARes =
		 * acsTxnMis.getTotalNoofSuccessPAResValue().getText();
		 * 
		 * // Comparing value from UI and DB: String binWiseSummaryVeresPareq_UIValue =
		 * acsTxnMis.getBinWiseVeresPareq().getText();
		 * System.out.println("binWiseSummaryVeresPareq_UIValue:-" +
		 * binWiseSummaryVeresPareq_UIValue); ReportResultVeres_PareqPercentage =
		 * AcsTransactionMIS.veresPareqPercentage();
		 * sAssertion.assertEquals(ReportResultVeres_PareqPercentage.replaceAll(" ",
		 * ""), binWiseSummaryVeresPareq_UIValue, "binWiseSummaryVeresPareq_UIValue");
		 * 
		 * String binWiseSummaryPareqPares_UIValue =
		 * acsTxnMis.getBinWisePareqPares().getText();
		 * System.out.println("binWiseSummaryPareqPares_UIValue: " +
		 * binWiseSummaryPareqPares_UIValue); ReportResultPareq_ParesPercentage =
		 * AcsTransactionMIS.pareqParesPercentage();
		 * sAssertion.assertEquals(ReportResultPareq_ParesPercentage.replaceAll(" ",
		 * ""), binWiseSummaryPareqPares_UIValue, "binWiseSummaryPareqPares_UIValue");
		 * 
		 * String binWiseSummaryVeresPares_UIValue =
		 * acsTxnMis.getBinWiseVeresPares().getText();
		 * System.out.println("binWiseSummaryVeresPares_UIValue:- " +
		 * binWiseSummaryVeresPares_UIValue); ReportResultVeres_ParesPercentage =
		 * AcsTransactionMIS.veresParesPercentage();
		 * sAssertion.assertEquals(ReportResultVeres_ParesPercentage.replaceAll(" ",
		 * ""), binWiseSummaryVeresPares_UIValue, "binWiseSummaryVeresPares_UIValue");
		 * 
		 * String binWiseSummaryADSReg_UIValue = acsTxnMis.getBinWiseADSReg().getText();
		 * System.out.println("binWiseSummaryADSReg_UIValue:- " +
		 * binWiseSummaryADSReg_UIValue);
		 * 
		 * String binWiseSummaryVereq_UIValue = acsTxnMis.getBinWiseVereq().getText();
		 * System.out.println("binWiseSummaryVereq_UIValue: " +
		 * binWiseSummaryVereq_UIValue); ReportResultTotalNoOfVreq =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVreq(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVreq,
		 * binWiseSummaryVereq_UIValue, "binWiseSummaryVereq_UIValue");
		 * 
		 * String biWiseSummaryVeresValue = acsTxnMis.getBinWiseVeres().getText();
		 * System.out.println("biWiseSummaryVeresValue: " + biWiseSummaryVeresValue);
		 * 
		 * String binWiseSummaryVeres_Y_Value = acsTxnMis.getBinWiseVeres_Y().getText();
		 * System.out.println("binWiseSummaryVeres_Y_Value:-" +
		 * binWiseSummaryVeres_Y_Value); ReportResultTotalNoOfVres_Y =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVres_Y(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVres_Y,
		 * binWiseSummaryVeres_Y_Value, "binWiseSummaryVeres_Y_Value");
		 * 
		 * String binWiseSummaryVeres_N_Value = acsTxnMis.getBinWiseVeres_N().getText();
		 * System.out.println("binWiseSummaryVeres_N_Value:-" +
		 * binWiseSummaryVeres_N_Value); ReportResultTotalNoOfVres_N =
		 * DBConnection.getValueFromDB(DBQuery.NoOfVres_N(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoOfVres_N,
		 * binWiseSummaryVeres_N_Value, "binWiseSummaryVeres_Y_Value");
		 * 
		 * String binWiseSummaryVeres_U_Value = acsTxnMis.getBinWiseVeres_U().getText();
		 * System.out.println("binWiseSummaryVeres_U_Value:-" +
		 * binWiseSummaryVeres_U_Value); ReportResultTotalNoofUnabletoAuthenticateVRes_U
		 * = DBConnection.getValueFromDB(DBQuery.NoOfVres_U(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofUnabletoAuthenticateVRes_U,
		 * binWiseSummaryVeres_U_Value, "binWiseSummaryVeres_U_Value");
		 * 
		 * String binWiseSummaryPareqValue = acsTxnMis.getBinWisePareq().getText();
		 * System.out.println("binWiseSummaryPareqValue:-" + binWiseSummaryPareqValue);
		 * ReportResultTotalNoofPAReq =
		 * DBConnection.getValueFromDB(DBQuery.NoOfPAReq(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofPAReq, binWiseSummaryPareqValue,
		 * "binWiseSummaryPareqValue");
		 * 
		 * String binWiseSummaryPares_A_Value = acsTxnMis.getBinWisePares_A().getText();
		 * System.out.println("binWiseSummaryPares_A_Value:-" +
		 * binWiseSummaryPares_A_Value); ReportResultTotalNoofAttemptedPARes_A =
		 * DBConnection.getValueFromDB(DBQuery.TotalNoofAttemptedPARes_A(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofAttemptedPARes_A,
		 * binWiseSummaryPares_A_Value, "binWiseSummaryPares_A_Value");
		 * 
		 * String binWiseSummaryPares_Y_Value = acsTxnMis.getBinWisePares_Y().getText();
		 * System.out.println("binWiseSummaryPares_Y_Value:-" +
		 * binWiseSummaryPares_Y_Value); ReportResultPAReswithvalidAuthentication_Y =
		 * DBConnection .getValueFromDB(DBQuery.PAReswithvalidAuthentication_Y(Schema));
		 * sAssertion.assertEquals(ReportResultPAReswithvalidAuthentication_Y,
		 * binWiseSummaryPares_Y_Value, "binWiseSummaryPares_Y_Value");
		 * 
		 * String binWiseSummaryPares_N_Value = acsTxnMis.getBinWisePares_N().getText();
		 * System.out.println("binWiseSummaryPares_N_Value:-" +
		 * binWiseSummaryPares_N_Value); ReportResultPAReswithInvalidAuthentication_N =
		 * DBConnection
		 * .getValueFromDB(DBQuery.PAReswithInvalidAuthentication_N(Schema));
		 * sAssertion.assertEquals(ReportResultPAReswithInvalidAuthentication_N,
		 * binWiseSummaryPares_N_Value, "binWiseSummaryPares_N_Value");
		 * 
		 * String binWiseSummaryPares_U_Value = acsTxnMis.getBinWisePares_U().getText();
		 * System.out.println("binWiseSummaryPares_U_Value:-" +
		 * binWiseSummaryPares_U_Value);
		 * ReportResultTotalNoofUnauthenticatedPARes_Failed_U = DBConnection
		 * .getValueFromDB(DBQuery.NoofUnauthenticatedPARes_Failed_U(Schema));
		 * sAssertion.assertEquals(ReportResultTotalNoofUnauthenticatedPARes_Failed_U,
		 * binWiseSummaryPares_U_Value, "binWiseSummaryPares_U_Value");
		 * 
		 * String binWiseSummaryParesProgInit =
		 * acsTxnMis.getBinWiseParesProgInit().getText();
		 * System.out.println("binWiseSummaryParesProgInit: " +
		 * binWiseSummaryParesProgInit);
		 * 
		 * String binWiseSummaryParesProgAbortValue =
		 * acsTxnMis.getBinWiseParesProgAbort().getText();
		 * System.out.println("binWiseSummaryParesProgAbortValue:-" +
		 * binWiseSummaryParesProgAbortValue);
		 * 
		 * String binWiseSummaryParesProgRespValue =
		 * acsTxnMis.getBinWiseParesProgResp().getText();
		 * System.out.println("binWiseSummaryParesProgRespValue:-" +
		 * binWiseSummaryParesProgRespValue);
		 * 
		 * String binWiseSummaryParesProgCompValue =
		 * acsTxnMis.getBinWiseParesProgComp().getText();
		 * System.out.println("binWiseSummaryParesProgCompValue:-" +
		 * binWiseSummaryParesProgCompValue);
		 * 
		 * String binWiseSummaryCacheMissValue =
		 * acsTxnMis.getBinWiseCacheMiss().getText();
		 * System.out.println("binWiseSummaryCacheMissValue:-" +
		 * binWiseSummaryCacheMissValue);
		 */

		sAssertion.assertAll();

	}

	@DataProvider
	public Object[][] validateDefaultFunctionality() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, "Report");
	}

	@Test(dataProvider = "validateDefaultFunctionality", priority = 6, invocationCount = 1, enabled = true)
	public void validateDefaultFunctionality(String IssuerBankId, String IssuerBankName, String ProtocalVersion,
			String FromDate, String FromMonth, String FromYear, String FromHour, String FromMinutes, String ToDate,
			String ToMonth, String ToYear, String ToHour, String ToMinutes, String Schema, String decs) {

		System.out.println("----validateDefaultFunctioanilty----");
		ExtentTestManager.getTest().setDescription(decs);
		SoftAssert sAssertion = new SoftAssert();
		// AcsTransactionMisPage acsTxnMis = new AcsTransactionMisPage(driver);
		AdminACSFetchTxnPage acsTxnPage = new AdminACSFetchTxnPage(driver);
		AdminHomePage adminhomepage = new AdminHomePage(driver);

		// Selecting a bank
		generic.explicitWait(3);
		adminhomepage.getDropDownHeaderIcon().click();
		generic.explicitWait(3);
		adminhomepage.getSearchByBankNameTextField().sendKeys(IssuerBankName);
		// driver.findElement(By.xpath("(//div[@id='dropdown-menu']/div/div/following::a[1])[1]")).click();
		List<WebElement> bankList = driver.findElements(By.xpath("//a[@class='dropdown-item']"));
		for (WebElement bankName : bankList) {
			if (bankName.getText().equalsIgnoreCase(IssuerBankName)) {
				bankName.click();
				break;
			}
		}
		// adminhomepage.getAcsWibmoBankNameLinkInDropDown().click();
		generic.explicitWait(3);

		// Navigating to ACS TXN Report
		adminhomepage.getSideBarLinkACS().click();
		adminhomepage.getAcsReportsAndDashboard().click();
		adminhomepage.getAcsTransactionReportLink().click();
		generic.explicitWait(2);
		acsTxnPage.getAcsResetButton().click();
		generic.explicitWait(2);

		String FromDateInfo = acsTxnPage.getFrom_DateInfoText().getText();
		String ToDateInfo = acsTxnPage.getTo_DateInfoText().getText();
		System.out.println("FromDateInfoUI: " + FromDateInfo);
		System.out.println("ToDateInfoUI:   " + ToDateInfo);

		// String FromDateInfo="06 May 2021|12:58";
		String from_Month = FromDateInfo.replaceAll("[^a-zA-Z]+", "");
		String from_DateAndYear = FromDateInfo.replaceAll("[a-zA-Z]+", "").replace(" ", "");
		String from_Date = from_DateAndYear.substring(0, 2);
		String from_Year = from_DateAndYear.substring(2, 6);
		String from_Hour = from_DateAndYear.substring(7, 9);
		String from_Min = from_DateAndYear.substring(10, 12);

		String dateMonthTime = from_Year + "/" + from_Month + "/" + from_Date + "/" + from_Hour + "/" + from_Min + "/"
				+ "00";

		// to_date info
		String to_Month = ToDateInfo.replaceAll("[^a-zA-Z]+", "");
		String to_DateAndYear = ToDateInfo.replaceAll("[a-zA-Z]+", "").replace(" ", "");
		String to_Date = to_DateAndYear.substring(0, 2);
		String to_Year = to_DateAndYear.substring(2, 6);
		String to_Hour = to_DateAndYear.substring(7, 9);
		String to_Min = to_DateAndYear.substring(10, 12);

		String to_dateMonthTime = to_Year + "/" + to_Month + "/" + to_Date + "/" + to_Hour + "/" + to_Min + "/" + "00";

		SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy/MMM/dd/HH/mm/00");
		Date currentDate = new Date();

		String dateAndTime = FORMATTER.format(currentDate);

		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);
		c.add(Calendar.MINUTE, -30);
		Date currentDatePlusOne = c.getTime();

		System.out.println("After formating FromUI :" + dateMonthTime);
		System.out.println("After formating ToUI :" + to_dateMonthTime);
		// current Date and time 'From'

		System.out.println("Updated DateandTime " + FORMATTER.format(currentDatePlusOne));
		System.out.println("CurrentdateAndTimeSystem:-" + dateAndTime);

		sAssertion.assertEquals(dateMonthTime, FORMATTER.format(currentDatePlusOne), "Validating Default 'From' time");
		sAssertion.assertEquals(to_dateMonthTime, dateAndTime, "Validating Default 'To' time");
		sAssertion.assertAll();
	}
}

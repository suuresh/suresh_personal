package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminACSRBAPage {

	public WebDriver driver;

	public AdminACSRBAPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//textarea")
	private WebElement rbaScriptTextArea;

	@FindBy(xpath = "//span[contains(text(),'Save Configuration')]")
	private WebElement rbaScriptSaveConfigurationButton;

	@FindBy(xpath = "//span[contains(text(),'Clear Configuration')]")
	private WebElement rbaScriptClearConfigurationButton;

	@FindBy(xpath = "//div[contains(@class,'notification is-success')]")
	private WebElement rbaScriptSuccessfullyUpdatedPopUp;

	public WebElement getRbaScriptTextArea() {
		return rbaScriptTextArea;
	}

	public WebElement getRbaScriptSaveConfigurationButton() {
		return rbaScriptSaveConfigurationButton;
	}

	public WebElement getRbaScriptClearConfigurationButton() {
		return rbaScriptClearConfigurationButton;
	}

	public WebElement getRbaScriptSuccessfullyUpdatedPopUp() {
		return rbaScriptSuccessfullyUpdatedPopUp;
	}

}

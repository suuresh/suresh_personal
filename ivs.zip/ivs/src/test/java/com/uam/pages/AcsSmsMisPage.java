package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AcsSmsMisPage {

	public WebDriver driver;

	public AcsSmsMisPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getAcsSmsMisSedeLink() {
		return acsSmsMisSedeLink;
	}

	public void setAcsSmsMisSedeLink(WebElement acsSmsMisSedeLink) {
		this.acsSmsMisSedeLink = acsSmsMisSedeLink;
	}

	public WebElement getIvsOtpValue() {
		return ivsOtpValue;
	}

	public void setIvsOtpValue(WebElement ivsOtpValue) {
		this.ivsOtpValue = ivsOtpValue;
	}

	public WebElement getIvrOtpValue() {
		return ivrOtpValue;
	}

	public void setIvrOtpValue(WebElement ivrOtpValue) {
		this.ivrOtpValue = ivrOtpValue;
	}

	public WebElement getExpressPayValue() {
		return expressPayValue;
	}

	public void setExpressPayValue(WebElement expressPayValue) {
		this.expressPayValue = expressPayValue;
	}

	public WebElement getOneTimePasswordAlertValue() {
		return oneTimePasswordAlertValue;
	}

	public void setOneTimePasswordAlertValue(WebElement oneTimePasswordAlertValue) {
		this.oneTimePasswordAlertValue = oneTimePasswordAlertValue;
	}

	public WebElement getTotalSmsCountValue() {
		return totalSmsCountValue;
	}

	public void setTotalSmsCountValue(WebElement totalSmsCountValue) {
		this.totalSmsCountValue = totalSmsCountValue;
	}

	@FindBy(xpath = "//li[text()='ACS SMS MIS']")
	private WebElement acsSmsMisSedeLink;

	@FindBy(xpath = "//*[@class='date-picker']")
	private WebElement datePicker;

	public WebElement getDatePicker() {
		return datePicker;
	}

	@FindBy(xpath = "//td[text()='IVS OTP']/following::td[1]")
	private WebElement ivsOtpValue;

	@FindBy(xpath = "//td[text()='IVR']/following::td[1]")
	private WebElement ivrOtpValue;

	@FindBy(xpath = "//td[text()='ExpressPay']/following::td[1]")
	private WebElement expressPayValue;

	@FindBy(xpath = "//td[text()='OTP - One Time Password Alert']/following::td[1]")
	private WebElement oneTimePasswordAlertValue;

	@FindBy(xpath = "//td[text()=' Total SMS Count']/following::td[1]")
	private WebElement totalSmsCountValue;
}

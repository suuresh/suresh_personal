package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.acs.libraries.Config;

public class ACSDashBoardPage {

	public WebDriver driver;

	public ACSDashBoardPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//h4[contains(text(),'ACS Highlights')]")
	private WebElement acsDashboardHeading;
	
	@FindBy(xpath="//div[contains(text(),'Total Number of Transactions')]")
	private WebElement acsDashboardTotalTransactionsHeading;
	
	@FindBy(xpath="(//*[text()='Total Number of Transactions']/following::div[@class='column number'])[1]")
	private WebElement acsDashboardTotalTransactionsValue;
	
	@FindBy(xpath="(//*[text()='Total Number of Transactions']/span[text()='(All Currencies)']/following::div[@class='column number'])[1]")
	private WebElement acsDashboardTotalTransactionsAllCurrenciesValue;
	
	@FindBy(xpath="//div[contains(text(),'Authentication Rate')]")
	private WebElement acsDashboardAuthRateHeading;
	
	@FindBy(xpath="//div[contains(@class,'dashboard__block pad12 bg-white')]//div[contains(@class,'title')][contains(text(),'Total Amount')]")
	private WebElement acsDashboardTotalAmountHeading;
	
	@FindBy(xpath="(//*[text()='Total Amount']/following::div[@class='column number'])[1]")
	private WebElement acsDashboardTotalAmountValue;
	
	@FindBy(xpath="//div[contains(text(),'Avg Amount Spend')]")
	private WebElement acsDashboardAvgAmountSpendHeading;
	
	@FindBy(xpath="(//*[text()='Avg Amount Spend']/following::div[@class='column number'])[1]")
	private WebElement acsDashboardAvgAmountSpendValue;
	
	@FindBy(xpath="//div[contains(text(),'Authentication Rate')]")
	private WebElement acsDashboardAuthenticationRateHeading;
	
	@FindBy(xpath="(//*[text()='Authentication Rate']/following::div[contains(@class,'column number auth')])[1]")
	private WebElement acsDashboardAuthenticationRateValue;
	
	@FindBy(xpath="//div[contains(text(),'Cards Usage Breakdown')]")
	private WebElement acsDashboardCardsUsageBreakdownHeading;
	
	@FindBy(xpath="//div[contains(text(),'Frictionless Transactions')]")
	private WebElement acsDashboardFrictionLessTransactionsHeading;
	
	@FindBy(xpath="(//*[text()='Frictionless Transactions']/following::div[@class='column number nopad-right'])[1]")
	private WebElement acsDashboardFrictionLessTransactionsTotalCountValue;
	
	@FindBy(xpath="(//*[text()='Frictionless Transactions']/following::div[contains(@class, 'column number nopad-right auth')])[1]")
	private WebElement acsDashboardFrictionLessTransactionsAuthenticationRateValue;
	
	@FindBy(xpath="//div[contains(text(),'Challenged Transactions')]")
	private WebElement acsDashboardChallengedTransactionsHeading;
	
	@FindBy(xpath="(//*[text()='Challenged Transactions']/following::div[@class='column number nopad-right'])[1]")
	private WebElement acsDashboardChallengedTransactionsTotalCountValue;
	
	@FindBy(xpath="(//*[text()='Challenged Transactions']/following::div[contains(@class,'column number nopad-right  auth')])[1]")
	private WebElement acsDashboardChallengedTransactionsAuthenticationRateValue;
	
	@FindBy(xpath="//div[contains(text(),'Declined Transactions')]")
	private WebElement acsDashboardDeclinedTransactionsHeading;
	
	@FindBy(xpath="(//*[text()='Declined Transactions']/following::div[@class='column number nopad-right'])[1]")
	private WebElement acsDashboardDeclinedTransactionsTotalCountValue;
	
	@FindBy(xpath="(//*[text()='Failure Transactions']/following::div[@class='column number nopad-right'])[1]")
	private WebElement acsDashboardFailureTransactionsTotalCountValue;
	
		
	//Insight
		
	@FindBy(xpath="//div[@class='tabs tabs2 is-boxed is-marginless']//li[@class='is-active']//span[1]")
	private WebElement acsDashboardInsightTopMerchantsTab;
	
	@FindBy(xpath="//span[contains(text(),'TICKET SIZE')]")
	private WebElement acsDashboardInsightTicketSizeTab;
	
	@FindBy(xpath="//span[contains(text(),'Device Channel & Modes of Authentication')]")
	private WebElement acsDashboardInsightDeviceChannelTab;
	
	@FindBy(xpath="//span[contains(text(),'Card type and union & Failure Reasons')]")
	private WebElement acsDashboardInsightCardUnionTab;
	
	//Transaction Trends
	
	@FindBy(xpath="//span[contains(text(),'Volume and Success Rate')]")
	private WebElement acsDashboardTrendsValumeSuccesRateTab;
	
	@FindBy(xpath="//span[contains(text(),'Failed Transaction')]")
	private WebElement acsDashboardTrendsFailedTransactionsTab;
	
	@FindBy(xpath="//span[contains(text(),'Declined Transaction')]")
	private WebElement acsDashboardTrendsDeclinedTransactionsTab;
	
	//Fileters
	
	@FindBy(xpath="//span[contains(text(),'Card Type')]")
	private WebElement acsDashboardFilterCardTypeTab;
	
	@FindBy(xpath="//label[contains(text(),'Debit')]")
	private WebElement acsDashboardFilterCardTypeDebitCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'Credit')]")
	private WebElement acsDashboardFilterCardTypeCreditCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'Prepaid')]")
	private WebElement acsDashboardFilterCardTypePrepaidCheckBox;
	
	@FindBy(xpath="//div[contains(text(),'Debit')]/a")
	private WebElement acsDashboardFilterCardTypeDebitRemove;
	
	@FindBy(xpath="//div[contains(text(),'Credit')]/a")
	private WebElement acsDashboardFilterCardTypeCreditRemove;
	
	@FindBy(xpath="//div[contains(text(),'Prepaid')]/a")
	private WebElement acsDashboardFilterCardTypePrepaidRemove;
	
	@FindBy(xpath="//span[contains(text(),'Card Union')]")
	private WebElement acsDashboardFilterCardUnionTab;
	
	@FindBy(xpath="//label[contains(text(),'Mastercard')]")
	private WebElement acsDashboardFilterCardUnionMastercardCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'Visa')]")
	private WebElement acsDashboardFilterCardUnionVisaCheckBox;
	
	@FindBy(xpath="//div[contains(text(),'Mastercard')]/a")
	private WebElement acsDashboardFilterCardUnionMastercardRemove;
	
	@FindBy(xpath="//div[contains(text(),'Visa')]/a")
	private WebElement acsDashboardFilterCardUnionVisaRemove;
	
	@FindBy(xpath="//span[contains(text(),'Location')]")
	private WebElement acsDashboardFilterLocationTab;
	
	@FindBy(xpath="//label[contains(text(),'MUMRDC')]")
	private WebElement acsDashboardFilterLocationMumRdcCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'BLRTDC')]")
	private WebElement acsDashboardFilterLocationBlrTdcCheckBox;
	
	@FindBy(xpath="//div[contains(text(),'MUMRDC')]/a")
	private WebElement acsDashboardFilterLocationMumRdcRemove;
	
	@FindBy(xpath="//div[contains(text(),'BLRTDC')]/a")
	private WebElement acsDashboardFilterLocationBlrTdcRemove;
	
	@FindBy(xpath="//span[contains(text(),'Device Channel')]")
	private WebElement acsDashboardFilterDeviceChannelTab;
	
	@FindBy(xpath="//label[contains(text(),'Browser')]")
	private WebElement acsDashboardFilterDeviceChannelBrowserCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'App')]")
	private WebElement acsDashboardFilterDeviceChannelAppCheckBox;
	
	@FindBy(xpath="//div[contains(text(),'Browser')]/a")
	private WebElement acsDashboardFilterDeviceChannelBrowserRemove;
	
	@FindBy(xpath="//div[contains(text(),'App')]/a")
	private WebElement acsDashboardFilterDeviceChannelAppRemove;
	
	@FindBy(xpath="//span[contains(text(),'Environment')]")
	private WebElement acsDashboardFilterEnvironmentTab;
	
	@FindBy(xpath="//label[contains(text(),'Canary')]")
	private WebElement acsDashboardFilterEnvironmentCanaryCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'Production')]")
	private WebElement acsDashboardFilterEnvironmentProductionCheckbox;
	
	@FindBy(xpath="//div[contains(text(),'Canary')]/a")
	private WebElement acsDashboardFilterEnvironmentCanaryRemove;
	
	@FindBy(xpath="//div[contains(text(),'Production')]/a")
	private WebElement acsDashboardFilterEnvironmentProductionRemove;
	
	@FindBy(xpath="//span[contains(text(),'Merchant')]")
	private WebElement acsDashboardFilterMerchantTab;
	
	@FindBy(xpath="//span[contains(text(),'Acquirer Bin')]")
	private WebElement acsDashboardFilterAcquirerBinTab;
	
	@FindBy(xpath="//span[contains(text(),'Version')]")
	private WebElement acsDashboardFilterVersionTab;

	
	// Bank Currency Type xpaths.
	
	@FindBy(xpath="(//*[text()='Total Amount'])[1]/span[1]")
	private WebElement acsDashboardTotalAmoutCurrenyText;
	
	@FindBy(xpath="(//*[text()='Avg Amount Spend'])[1]/span[1]")
	private WebElement acsDashboardAvgAmoutSpentCurrenyText;
	
	@FindBy(xpath="(//*[text()='Total Number of Transactions'])/span[1]")
	private WebElement acsDashboardTotalNumberOfTransactionNonCurrenyText;
	
	@FindBy(xpath="(//*[text()='Total Amount'])[2]/span[1]")
	private WebElement acsDashboardTotalAmoutNonCurrenyText;
	
		
	public WebElement getAcsDashboardTotalAmoutCurrenyText() {
		return acsDashboardTotalAmoutCurrenyText;
	}

	public WebElement getAcsDashboardAvgAmoutSpentCurrenyText() {
		return acsDashboardAvgAmoutSpentCurrenyText;
	}

	public WebElement getAcsDashboardTotalNumberOfTransactionNonCurrenyText() {
		return acsDashboardTotalNumberOfTransactionNonCurrenyText;
	}

	public WebElement getAcsDashboardTotalAmoutNonCurrenyText() {
		return acsDashboardTotalAmoutNonCurrenyText;
	}

	public WebElement getAcsDashboardHeading() {
		return acsDashboardHeading;
	}

	public WebElement getAcsDashboardTotalTransactionsHeading() {
		return acsDashboardTotalTransactionsHeading;
	}

	public WebElement getAcsDashboardTotalTransactionsValue() {
		return acsDashboardTotalTransactionsValue;
	}
	
	public WebElement getAcsDashboardTotalTransactionsAllCurrenciesValue() {
		return acsDashboardTotalTransactionsAllCurrenciesValue;
	}

	public WebElement getAcsDashboardAuthRateHeading() {
		return acsDashboardAuthRateHeading;
	}

	public WebElement getAcsDashboardTotalAmountHeading() {
		return acsDashboardTotalAmountHeading;
	}

	public WebElement getAcsDashboardTotalAmountValue() {
		return acsDashboardTotalAmountValue;
	}

	public WebElement getAcsDashboardAvgAmountSpendHeading() {
		return acsDashboardAvgAmountSpendHeading;
	}

	public WebElement getAcsDashboardAvgAmountSpendValue() {
		return acsDashboardAvgAmountSpendValue;
	}

	public WebElement getAcsDashboardAuthenticationRateHeading() {
		return acsDashboardAuthenticationRateHeading;
	}

	public WebElement getAcsDashboardAuthenticationRateValue() {
		return acsDashboardAuthenticationRateValue;
	}

	public WebElement getAcsDashboardCardsUsageBreakdownHeading() {
		return acsDashboardCardsUsageBreakdownHeading;
	}

	public WebElement getAcsDashboardFrictionLessTransactionsHeading() {
		return acsDashboardFrictionLessTransactionsHeading;
	}

	public WebElement getAcsDashboardFrictionLessTransactionsTotalCountValue() {
		return acsDashboardFrictionLessTransactionsTotalCountValue;
	}

	public WebElement getAcsDashboardFrictionLessTransactionsAuthenticationRateValue() {
		return acsDashboardFrictionLessTransactionsAuthenticationRateValue;
	}

	public WebElement getAcsDashboardChallengedTransactionsHeading() {
		return acsDashboardChallengedTransactionsHeading;
	}

	public WebElement getAcsDashboardChallengedTransactionsTotalCountValue() {
		return acsDashboardChallengedTransactionsTotalCountValue;
	}

	public WebElement getAcsDashboardChallengedTransactionsAuthenticationRateValue() {
		return acsDashboardChallengedTransactionsAuthenticationRateValue;
	}

	public WebElement getAcsDashboardDeclinedTransactionsHeading() {
		return acsDashboardDeclinedTransactionsHeading;
	}

	public WebElement getAcsDashboardDeclinedTransactionsTotalCountValue() {
		return acsDashboardDeclinedTransactionsTotalCountValue;
	}
	
	public WebElement getAcsDashboardFailureTransactionsTotalCountValue() {
		return acsDashboardFailureTransactionsTotalCountValue;
	}

	public WebElement getAcsDashboardInsightTopMerchantsTab() {
		return acsDashboardInsightTopMerchantsTab;
	}

	public WebElement getAcsDashboardInsightTicketSizeTab() {
		return acsDashboardInsightTicketSizeTab;
	}

	public WebElement getAcsDashboardInsightDeviceChannelTab() {
		return acsDashboardInsightDeviceChannelTab;
	}

	public WebElement getAcsDashboardInsightCardUnionTab() {
		return acsDashboardInsightCardUnionTab;
	}

	public WebElement getAcsDashboardTrendsValumeSuccesRateTab() {
		return acsDashboardTrendsValumeSuccesRateTab;
	}

	public WebElement getAcsDashboardTrendsFailedTransactionsTab() {
		return acsDashboardTrendsFailedTransactionsTab;
	}

	public WebElement getAcsDashboardTrendsDeclinedTransactionsTab() {
		return acsDashboardTrendsDeclinedTransactionsTab;
	}

	public WebElement getAcsDashboardFilterCardTypeTab() {
		return acsDashboardFilterCardTypeTab;
	}

	public WebElement getAcsDashboardFilterCardTypeDebitCheckBox() {
		return acsDashboardFilterCardTypeDebitCheckBox;
	}

	public WebElement getAcsDashboardFilterCardTypeCreditCheckBox() {
		return acsDashboardFilterCardTypeCreditCheckBox;
	}

	public WebElement getAcsDashboardFilterCardTypePrepaidCheckBox() {
		return acsDashboardFilterCardTypePrepaidCheckBox;
	}

	public WebElement getAcsDashboardFilterCardTypeDebitRemove() {
		return acsDashboardFilterCardTypeDebitRemove;
	}

	public WebElement getAcsDashboardFilterCardTypeCreditRemove() {
		return acsDashboardFilterCardTypeCreditRemove;
	}

	public WebElement getAcsDashboardFilterCardTypePrepaidRemove() {
		return acsDashboardFilterCardTypePrepaidRemove;
	}

	public WebElement getAcsDashboardFilterCardUnionTab() {
		return acsDashboardFilterCardUnionTab;
	}

	public WebElement getAcsDashboardFilterCardUnionMastercardCheckBox() {
		return acsDashboardFilterCardUnionMastercardCheckBox;
	}

	public WebElement getAcsDashboardFilterCardUnionVisaCheckBox() {
		return acsDashboardFilterCardUnionVisaCheckBox;
	}

	public WebElement getAcsDashboardFilterCardUnionMastercardRemove() {
		return acsDashboardFilterCardUnionMastercardRemove;
	}

	public WebElement getAcsDashboardFilterCardUnionVisaRemove() {
		return acsDashboardFilterCardUnionVisaRemove;
	}

	public WebElement getAcsDashboardFilterLocationTab() {
		return acsDashboardFilterLocationTab;
	}

	public WebElement getAcsDashboardFilterLocationMumRdcCheckBox() {
		return acsDashboardFilterLocationMumRdcCheckBox;
	}

	public WebElement getAcsDashboardFilterLocationBlrTdcCheckBox() {
		return acsDashboardFilterLocationBlrTdcCheckBox;
	}

	public WebElement getAcsDashboardFilterLocationMumRdcRemove() {
		return acsDashboardFilterLocationMumRdcRemove;
	}

	public WebElement getAcsDashboardFilterLocationBlrTdcRemove() {
		return acsDashboardFilterLocationBlrTdcRemove;
	}

	public WebElement getAcsDashboardFilterDeviceChannelTab() {
		return acsDashboardFilterDeviceChannelTab;
	}

	public WebElement getAcsDashboardFilterDeviceChannelBrowserCheckBox() {
		return acsDashboardFilterDeviceChannelBrowserCheckBox;
	}

	public WebElement getAcsDashboardFilterDeviceChannelAppCheckBox() {
		return acsDashboardFilterDeviceChannelAppCheckBox;
	}

	public WebElement getAcsDashboardFilterDeviceChannelBrowserRemove() {
		return acsDashboardFilterDeviceChannelBrowserRemove;
	}

	public WebElement getAcsDashboardFilterDeviceChannelAppRemove() {
		return acsDashboardFilterDeviceChannelAppRemove;
	}

	public WebElement getAcsDashboardFilterEnvironmentTab() {
		return acsDashboardFilterEnvironmentTab;
	}

	public WebElement getAcsDashboardFilterEnvironmentCanaryCheckBox() {
		return acsDashboardFilterEnvironmentCanaryCheckBox;
	}

	public WebElement getAcsDashboardFilterEnvironmentProductionCheckbox() {
		return acsDashboardFilterEnvironmentProductionCheckbox;
	}

	public WebElement getAcsDashboardFilterEnvironmentCanaryRemove() {
		return acsDashboardFilterEnvironmentCanaryRemove;
	}

	public WebElement getAcsDashboardFilterEnvironmentProductionRemove() {
		return acsDashboardFilterEnvironmentProductionRemove;
	}

	public WebElement getAcsDashboardFilterMerchantTab() {
		return acsDashboardFilterMerchantTab;
	}

	public WebElement getAcsDashboardFilterAcquirerBinTab() {
		return acsDashboardFilterAcquirerBinTab;
	}

	public WebElement getAcsDashboardFilterVersionTab() {
		return acsDashboardFilterVersionTab;
	}
}

package com.uam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageUsersPage {
	
public WebDriver driver;
	
	public ManageUsersPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(xpath="//input[contains(@placeholder,'Search by Name and Login ID')]")
	private WebElement userSearchField;
	
	// Made change in below xpath
	@FindBy(xpath="//a[contains(text(),'Create User')]")
	private WebElement userCreatePlusButton;
	
	@FindBy(xpath="//input[@id='root_FirstName']")
	private WebElement userFirstNameTextField;
	
	@FindBy(xpath="//input[@id='root_LastName']")
	private WebElement userLastNameTextField;
	
	@FindBy(xpath="//input[@id='root_LoginID']")
	private WebElement userLoginIdTextField;
	
	@FindBy(xpath="//input[contains(@placeholder,'Mobile number')]")
	private WebElement userMobileNumberTextField;
	
	@FindBy(xpath="//input[@id='root_EmailID']")
	private WebElement userEmailIdTextField;
	
	@FindBy(xpath="//div[contains(@class,'form-group field field-string')]//span[contains(@class,'dropdown-trigger-item')]")
	private WebElement userStatusDropDownField;
	
	@FindBy(xpath="//div[@class='dropdown-menu']//label[contains(text(),'Active')]")
	private WebElement userStatusField;
	
	//div[contains(@class,'customwidth_13 scrollDisplay')]//div[contains(@class,'dropdown dropdown--type3 is-active')]	
	//@FindBy(xpath="//div[contains(@class,'customwidth_13')]//span[contains(@class,'dropdown-trigger-item')]")
	@FindBy(xpath="//div[contains(@class,'customwidth_13 scrollDisplay')]//div[contains(@class,'dropdown-trigger')]")
	private WebElement userCodeDropDownField;
	
	@FindBy(xpath="//div[contains(@class,'scrollDisplay customwidth_13')]//div[contains(@class,'dropdown-trigger')]")
	private WebElement editUserCodeDropDownField;		
	
	//Search Code and selection code
	@FindBy(xpath="//input[@placeholder='Search' and @id='1111']")
	private WebElement userCodeSearch;
	
	@FindBy(xpath="//label[@class='radio-label']")
	private WebElement userCodeCheckBox;

	@FindBy(xpath="//input[contains(@placeholder,'Search')]")
	private WebElement userBankListSearchField;
	
	@FindBy(xpath="//label[contains(text(),'adisa Bank')]")
	private WebElement userBankListCheckBox1;
	
	// added below code instead of above one (as there is no bank with name)
	@FindBy(xpath="//label[@class='checkbox__lable']")
	private WebElement userBankListCheckBox;
	
	@FindBy(xpath="//a[contains(text(),'Create User')]")
	private WebElement createUserButton;
	
	@FindBy(xpath="//a[@class='button button dropdown-btn']")
	private WebElement listPerPageDropDown;
	
	@FindBy(xpath="//label[contains(text(),'20 per page')]")
	private WebElement list20PerPageRadioButton;
	
	@FindBy(xpath="//input[@placeholder='Search by Login ID']")
	private WebElement searchByLoginIDTextField;
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column truncate'][1]")
	private WebElement listedName;	
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column user-concat'][1]")
	private WebElement listedLoginId; 
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column lg truncate'][1]")
	private WebElement listedEmail;
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column lg'][1]")
	private WebElement listedMobile;		

	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column'][1]")
	private WebElement listedStatus;
	
	@FindBy(xpath="//div[@class='options manage_opt_user'][1]//div[@class='options__edit'][1]")
	private WebElement Edituser;
	
	@FindBy(xpath="//div[@class='options manage_opt_user'][1]//div[@class='options__delete'][1]")
	private WebElement Deleteuser;
	
	public WebElement getDeleteuser() {
		return Deleteuser;
	}
	
	public WebElement getFirstNameMessage() {
		return firstNameMessage;
	}

	public WebElement getLoginIdMessage() {
		return loginIdMessage;
	}

	public WebElement getCodeMessage() {
		return codeMessage;
	}

	public WebElement getMobileNumMessage() {
		return mobileNumMessage;
	}

	public WebElement getEmailIDMessage() {
		return emailIDMessage;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}


	@FindBy(xpath="//span[text()='First Name']")
	private WebElement firstNameMessage;
	
	@FindBy(xpath="//span[text()='Login ID']")
	private WebElement loginIdMessage;
	
	@FindBy(xpath="//span[text()='Code']")
	private WebElement codeMessage;
	
	@FindBy(xpath="//span[text()='Mobile Number']")
	private WebElement mobileNumMessage;
	
	@FindBy(xpath="//span[text()='Email ID']")
	private WebElement emailIDMessage;
	
	@FindBy(xpath="//span[text()='Status']")
	private WebElement statusMessage;
	
	@FindBy(xpath="//a[contains(text(),'Save Changes')]")
	private WebElement saveChanges;
	
	public WebElement getSaveChanges() {
		return saveChanges;
	}

	public WebElement getEdituser() {
		return Edituser;
	}

	public WebElement getListedLoginId() {
		return listedLoginId;
	}

	public WebElement getListedEmail() {
		return listedEmail;
	}

	public WebElement getListedMobile() {
		return listedMobile;
	}

	public WebElement getListedStatus() {
		return listedStatus;
	}


	@FindBy(xpath="//ul[@class='pagination-list']//a[contains(text(),'NEXT')]")
	private WebElement clickNextPage;
	
	public WebElement getClickNextPage() {
		return clickNextPage;
	}

	public WebElement getListedName() {
		return listedName;
	}

	public WebElement getSearchByLoginIDTextField() {
		return searchByLoginIDTextField;
	}

	public WebElement getList20PerPageRadioButton() {
		return list20PerPageRadioButton;
	}

	public WebElement getList30PerPageRadioButton() {
		return list30PerPageRadioButton;
	}


	@FindBy(xpath="//label[contains(text(),'30 per page')]")
	private WebElement list30PerPageRadioButton;
	
	
	public WebElement getListPerPageDropDown() {
		return listPerPageDropDown;
	}

	public WebElement getCreateUserButton() {
		return createUserButton;
	}

	public WebElement getUserSearchField() {
		return userSearchField;
	}

	public WebElement getUserCreatePlusButton() {
		return userCreatePlusButton;
	}

	public WebElement getUserFirstNameTextField() {
		return userFirstNameTextField;
	}

	public WebElement getUserLastNameTextField() {
		return userLastNameTextField;
	}

	public WebElement getUserLoginIdTextField() {
		return userLoginIdTextField;
	}

	public WebElement getUserMobileNumberTextField() {
		return userMobileNumberTextField;
	}

	public WebElement getUserEmailIdTextField() {
		return userEmailIdTextField;
	}

	public WebElement getUserStatusDropDownField() {
		return userStatusDropDownField;
	}

	public WebElement getUserCodeDropDownField() {
		return userCodeDropDownField;
	}
	
	public WebElement getEditUserCodeDropDownField() {
		return editUserCodeDropDownField;
	}

	public WebElement getUserBankListSearchField() {
		return userBankListSearchField;
	}

	public WebElement getUserBankListCheckBox1() {
		return userBankListCheckBox1;
	}
	
	// Need to see below code 
	public WebElement getUserBankListCheckBox() {
		return userBankListCheckBox;
	}
	// Need to see below code 
	public WebElement getUserCodeSearch() {
		return userCodeSearch;
	}

	// Need to see below code
	public WebElement getUserCodeCheckBox() {
		return userCodeCheckBox;
	}
	
	public WebElement getUserStatusField() {
		return userStatusField;
	}

	
}

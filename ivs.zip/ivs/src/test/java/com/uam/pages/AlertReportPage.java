package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlertReportPage {

	public WebDriver driver;

	public AlertReportPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[contains(text(), 'Alerts Report')]")
	private WebElement alertReportSideLink;

	@FindBy(name = "card_number")
	private WebElement alertCardNumberTextField;

	@FindBy(name = "acs_txn_id")
	private WebElement alertAcsTxnIdTextField;

	@FindBy(xpath = "//*[text()='Select Mobile Code']")
	private WebElement alertMobileCodeDropdown;

	@FindBy(xpath = "//label[@for='+91']")
	private WebElement alertMobileCodePlus91DropdownList;

	@FindBy(xpath = "//label[@for='+1']")
	private WebElement alertMobileCodePlus1Dropdown;
	@FindBy(name = "mobile_number")
	private WebElement alertMobileNumberTextField;

	@FindBy(name = "event_id")
	private WebElement alertEventIdTextField;

	@FindBy(xpath = "//*[text()='Select Alert Type']")
	private WebElement alertSelectAlertTypeDropdown;

	@FindBy(xpath = "//label[text()='OTP']")
	private WebElement alertSelectAlertTypeOtpDropdownList;
	
	@FindBy(xpath = "//*[@class='btn-icon']")
	private WebElement alertAdvanceSerchPlusButton;
	
	@FindBy(xpath = "//a[text()='Fetch Report']")
	private WebElement alertFetchReportButton;
	
	@FindBy(xpath = "//a[text()=' Download Report']")
	private WebElement alertDownloadReportButton;
	
	@FindBy(xpath = "//a[text()='Reset']")
	private WebElement alertResetButton;
	
	

	public WebElement getAlertResetButton() {
		return alertResetButton;
	}

	public WebElement getAlertDownloadReportButton() {
		return alertDownloadReportButton;
	}

	public WebElement getAlertFetchReportButton() {
		return alertFetchReportButton;
	}

	public WebElement getAlertAdvanceSerchPlusButton() {
		return alertAdvanceSerchPlusButton;
	}

	public WebElement getAlertCardNumberText() {
		return alertCardNumberText;
	}

	public WebElement getAlertAcsTxnIdText() {
		return alertAcsTxnIdText;
	}

	public WebElement getAlertEventIdText() {
		return alertEventIdText;
	}

	public WebElement getAlertAlertTypeText() {
		return alertAlertTypeText;
	}

	public WebElement getAlertChannelTypeText() {
		return alertChannelTypeText;
	}

	public WebElement getAlertMobileNumberText() {
		return alertMobileNumberText;
	}

	public WebElement getAlertEmailText() {
		return alertEmailText;
	}

	public WebElement getAlertTotalCountText() {
		return alertTotalCountText;
	}

	@FindBy(xpath = "//*[text()='Select Channel']")
	private WebElement alertSelectChannelDropdown;

	@FindBy(xpath = "//label[text()='SMS']")
	private WebElement alertSelectChannelSmsDropdownlist;

	@FindBy(xpath = "//label[text()='Email']")
	private WebElement alertSelectChannelEmailDropdownList;

	// After fetching report xpath
	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[2])[1]")
	private WebElement alertCardNumberText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[4])[1]")
	private WebElement alertAcsTxnIdText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[5])[1]")
	private WebElement alertEventIdText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[6])[1]")
	private WebElement alertAlertTypeText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[7])[1]")
	private WebElement alertChannelTypeText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[8])[1]")
	private WebElement alertMobileNumberText;

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[10])[1]")
	private WebElement alertEmailText;
	
	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[11])[1]")
	private WebElement alertApiResponseText;
	
	public WebElement getAlertApiResponseText() {
		return alertApiResponseText;
	}

	@FindBy(xpath = "(//div[@class='flex-table__body']/div/div[12])[1]")
	private WebElement alertTransactionStatusText;

	public WebElement getAlertTransactionStatusText() {
		return alertTransactionStatusText;
	}

	@FindBy(xpath = "//span[@class='total-count']")
	private WebElement alertTotalCountText;
	
	@FindBy(xpath = "//button[text()='Apply']")
	private WebElement alertApplyButton;
	
	@FindBy(xpath = "//div[@role='alert']")
	private WebElement alertPopupErrorMsg;
	

	public WebElement getAlertPopupErrorMsg() {
		return alertPopupErrorMsg;
	}

	public WebElement getAlertApplyButton() {
		return alertApplyButton;
	}

	public WebElement getAlertCardNumberTextField() {
		return alertCardNumberTextField;
	}

	public WebElement getAlertAcsTxnIdTextField() {
		return alertAcsTxnIdTextField;
	}

	public WebElement getAlertMobileCodeDropdown() {
		return alertMobileCodeDropdown;
	}

	public WebElement getAlertMobileCodePlus91DropdownList() {
		return alertMobileCodePlus91DropdownList;
	}

	public WebElement getAlertMobileCodePlus1Dropdown() {
		return alertMobileCodePlus1Dropdown;
	}

	public WebElement getAlertMobileNumberTextField() {
		return alertMobileNumberTextField;
	}

	public WebElement getAlertEventIdTextField() {
		return alertEventIdTextField;
	}

	public WebElement getAlertSelectAlertTypeDropdown() {
		return alertSelectAlertTypeDropdown;
	}

	public WebElement getAlertSelectAlertTypeOtpDropdownList() {
		return alertSelectAlertTypeOtpDropdownList;
	}

	public WebElement getAlertSelectChannelDropdown() {
		return alertSelectChannelDropdown;
	}

	public WebElement getAlertSelectChannelSmsDropdownlist() {
		return alertSelectChannelSmsDropdownlist;
	}

	public WebElement getAlertSelectChannelEmailDropdownList() {
		return alertSelectChannelEmailDropdownList;
	}
	public WebElement getAlertReportSideLink() {
		return alertReportSideLink;

	}

}

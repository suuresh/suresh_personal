package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.acs.testcases.ACSInitialSetUp;

public class LogOutPage extends ACSInitialSetUp{
	
	public WebDriver driver;
	
	public LogOutPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//div[contains(@class,'dropdown-header-item')]")
	private WebElement profileDropDown;
	
	@FindBy(xpath="//span[contains(text(),'Sign Out')]")
	private WebElement signOutLink;
	
	public void logout(){
		profileDropDown.click();
		signOutLink.click();
	}

}

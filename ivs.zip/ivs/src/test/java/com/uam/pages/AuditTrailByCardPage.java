package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AuditTrailByCardPage {

	public WebDriver driver;

	public AuditTrailByCardPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//*[text()='Audit Trail By Card'])[1]")
	private WebElement AuditTrailByCardSideLink;

	@FindBy(xpath = "(//*[@class='btn-icon'])[1]")
	private WebElement AuditTrialByCard_AdvanceSearchButton;

	@FindBy(xpath = "(//div[@class='level']//div[3]//*[local-name()='svg'])[1]")
	private WebElement AuditTrialByCard_CalenderIcon;

	@FindBy(xpath = "//div[@class='drp-calendar left']//select[@class='hourselect']")
	private WebElement AuditTrialByCard_LeftHoursSelect;

	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	private WebElement applyButton;

	@FindBy(xpath = "//input[@name='pan']")
	private WebElement AuditTrialByCard_CardNumberTextField;

	@FindBy(xpath = "//a[text()='Reset']")
	private WebElement AuditTrialByCard_ResetButton;

	@FindBy(xpath = "//a[text()=' Download Report']")
	private WebElement AuditTrialByCard_DownloadReport;

	public WebElement getAuditTrialByCard_AdvanceSearchButton() {
		return AuditTrialByCard_AdvanceSearchButton;
	}

	public WebElement getAuditTrialByCard_CalenderIcon() {
		return AuditTrialByCard_CalenderIcon;
	}

	public WebElement getAuditTrialByCard_LeftHoursSelect() {
		return AuditTrialByCard_LeftHoursSelect;
	}

	public WebElement getApplyButton() {
		return applyButton;
	}

	public WebElement getAuditTrialByCard_CardNumberTextField() {
		return AuditTrialByCard_CardNumberTextField;
	}

	public WebElement getAuditTrialByCard_ResetButton() {
		return AuditTrialByCard_ResetButton;
	}

	public WebElement getAuditTrialByCard_DownloadReport() {
		return AuditTrialByCard_DownloadReport;
	}

	public WebElement getAuditTrialByCard_FetchReportButton() {
		return AuditTrialByCard_FetchReportButton;
	}

	@FindBy(xpath = "//a[text()='Fetch Report']")
	private WebElement AuditTrialByCard_FetchReportButton;

	public WebElement getAuditTrailByCardSideLink() {
		return AuditTrailByCardSideLink;
	}

	public WebElement getAuditTrailByCardActionText() {
		return AuditTrailByCardActionText;
	}

	public WebElement getAuditTrailByCardActionStatusText() {
		return AuditTrailByCardActionStatusText;
	}

	public WebElement getAuditTrailByCardSourceText() {
		return AuditTrailByCardSourceText;
	}

	public WebElement getAuditTrailByCardAccNumText() {
		return AuditTrailByCardAccNumText;
	}

	public WebElement getAuditTrailByCardUserIdText() {
		return AuditTrailByCardUserIdText;
	}

	public WebElement getAuditTrailByCardShowallDetailsButton() {
		return AuditTrailByCardShowallDetailsButton;
	}

	public WebElement getAuditTrailByCardShowModifiedDetailsButton() {
		return AuditTrailByCardShowModifiedDetailsButton;
	}

	public WebElement getAuditTrailByCardBeforeChange_BankIdText() {
		return AuditTrailByCardBeforeChange_BankIdText;
	}

	public WebElement getAuditTrailByCardBeforeChange_UserText() {
		return AuditTrailByCardBeforeChange_UserText;
	}

	public WebElement getAuditTrailByCardBeforeChange_maskedPanText() {
		return AuditTrailByCardBeforeChange_maskedPanText;
	}

	public WebElement getAuditTrailByCardBeforeChange_acsTxnIdText() {
		return AuditTrailByCardBeforeChange_acsTxnIdText;
	}

	public WebElement getAuditTrailByCardBeforeChange_actionText() {
		return AuditTrailByCardBeforeChange_actionText;
	}

	public WebElement getAuditTrailByCardBeforeChange_typeText() {
		return AuditTrailByCardBeforeChange_typeText;
	}

	public WebElement getAuditTrailByCardBeforeChange_accountNumberText() {
		return AuditTrailByCardBeforeChange_accountNumberText;
	}

	public WebElement getAuditTrailByCardBeforeChange_accountIdentifier() {
		return AuditTrailByCardBeforeChange_accountIdentifier;
	}

	public WebElement getAuditTrailByCardBeforeeChange_commentText() {
		return AuditTrailByCardBeforeeChange_commentText;
	}

	public WebElement getAuditTrailByCardAfterChange_BankIdText() {
		return AuditTrailByCardAfterChange_BankIdText;
	}

	public WebElement getAuditTrailByCardAfterChange_UserText() {
		return AuditTrailByCardAfterChange_UserText;
	}

	public WebElement getAuditTrailByCardAfterChange_maskedPanText() {
		return AuditTrailByCardAfterChange_maskedPanText;
	}

	public WebElement getAuditTrailByCardAfterChange_acsTxnIdText() {
		return AuditTrailByCardAfterChange_acsTxnIdText;
	}

	public WebElement getAuditTrailByCardAfterChange_actionText() {
		return AuditTrailByCardAfterChange_actionText;
	}

	public WebElement getAuditTrailByCardAfterChange_typeText() {
		return AuditTrailByCardAfterChange_typeText;
	}

	public WebElement getAuditTrailByCardAfterChange_accountNumberText() {
		return AuditTrailByCardAfterChange_accountNumberText;
	}

	public WebElement getAuditTrailByCardAfterChange_accountIdentifier() {
		return AuditTrailByCardAfterChange_accountIdentifier;
	}

	public WebElement getAuditTrailByCardAfterChange_commentText() {
		return AuditTrailByCardAfterChange_commentText;
	}

	@FindBy(xpath = "(//span[text()='Action']/following::div/span[1])[1]")
	private WebElement AuditTrailByCardActionText;

	@FindBy(xpath = "(//span[text()='Action Status']/following::div/span[1])[1]")
	private WebElement AuditTrailByCardActionStatusText;

	@FindBy(xpath = "(//span[text()='Source']/following::div/span[1])[1]")
	private WebElement AuditTrailByCardSourceText;

	@FindBy(xpath = "(//span[text()='Account Number']/following::div/span[1])[1]")
	private WebElement AuditTrailByCardAccNumText;

	@FindBy(xpath = "(//span[text()='User Id']/following::div/span[1])[1]")
	private WebElement AuditTrailByCardUserIdText;

	// Modification Details:
	@FindBy(xpath = "//*[text()='SHOW All DETAILS']")
	private WebElement AuditTrailByCardShowallDetailsButton;

	@FindBy(xpath = "//*[text()='SHOW MODIFIED ONLY']")
	private WebElement AuditTrailByCardShowModifiedDetailsButton;

	// Before Change
	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='bankId'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_BankIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='user'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_UserText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='maskedPan'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_maskedPanText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='acsTxnId'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_acsTxnIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='action'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_actionText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='type'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_typeText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='accountNumber'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_accountNumberText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='accountIdentifier'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_accountIdentifier;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='comment'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeeChange_commentText;

	// After Change
	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='bankId'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_BankIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='user'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_UserText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='maskedPan'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_maskedPanText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='acsTxnId'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_acsTxnIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='action'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_actionText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='type'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_typeText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='accountNumber'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_accountNumberText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='accountIdentifier'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_accountIdentifier;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='comment'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_commentText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='email_id'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_emailIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='email_id'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_emailIdText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='mobile_number'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_MobileText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='mobile_number'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_MobileText;

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='country_code'])[1]/following::div[1]")
	private WebElement AuditTrailByCardBeforeChange_CountryCodeText;

	public WebElement getAuditTrailByCardBeforeChange_CountryCodeText() {
		return AuditTrailByCardBeforeChange_CountryCodeText;
	}

	public WebElement getAuditTrailByCardAfterChange_CountryCodeText() {
		return AuditTrailByCardAfterChange_CountryCodeText;
	}

	@FindBy(xpath = "(//div[text()='Before Change: ']/../div/following::div/div/div/span[text()='country_code'])[2]/following::div[1]")
	private WebElement AuditTrailByCardAfterChange_CountryCodeText;

	public WebElement getAuditTrailByCardBeforeChange_emailIdText() {
		return AuditTrailByCardBeforeChange_emailIdText;
	}

	public WebElement getAuditTrailByCardAfterChange_emailIdText() {
		return AuditTrailByCardAfterChange_emailIdText;
	}

	public WebElement getAuditTrailByCardBeforeChange_MobileText() {
		return AuditTrailByCardBeforeChange_MobileText;
	}

	public WebElement getAuditTrailByCardAfterChange_MobileText() {
		return AuditTrailByCardAfterChange_MobileText;
	}

}

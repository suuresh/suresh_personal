package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageBanksPage {
	
public WebDriver driver;
	
	public ManageBanksPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//input[@placeholder='Search by Bank ID']")
	private WebElement bankSearchField;
	
	@FindBy(xpath="//a[contains(text(),'Create Bank')]")
	private WebElement createBankPlusButton;
	
	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement createBankCancelButton;
	
	
	@FindBy(xpath="//input[@placeholder='Search by Bank ID']")
	private WebElement searchByBankIdTextField;
	
	@FindBy(xpath="//a[@class='button button dropdown-btn']")
	private WebElement listPerPageDropDown;
	
	@FindBy(xpath="//label[contains(text(),'10 per page')]")
	private WebElement list10PerPageRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'20 per page')]")
	private WebElement list20PerPageRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'30 per page')]")
	private WebElement list30PerPageRadioButton;
	
	@FindBy(xpath="//div[@class='flex-table__row columns is-marginless odd'][1]//div[@class='flex-table__cell column lg truncate'][1]")
	private WebElement listedBankName;
	
	@FindBy(xpath="//div[@class='flex-table__row columns is-marginless odd'][1]//div[@class='flex-table__cell column lg'][1]")
	private WebElement listedBankId;
	
	@FindBy(xpath="//div[@class='flex-table__row columns is-marginless odd'][1]//div[@class='flex-table__cell column lg'][2]")
	private WebElement listedBucketName;
	
	@FindBy(xpath="//div[@class='flex-table__row columns is-marginless odd'][1]//div[@class='flex-table__cell column md'][1]")
	private WebElement listedCurrencyOfBank;
	
	@FindBy(xpath="//div[@class='flex-table__row columns is-marginless odd'][1]//div[@class='flex-table__cell column xl truncatexl'][1]")
	private WebElement listedProductsOfBank;
		
	@FindBy(xpath="//span[contains(text(),'Cancel')]")
	private WebElement CancleButton;
	
	@FindBy(xpath="//a[text()='Create Bank']")
	private WebElement createBankButton;
	
	@FindBy(xpath="//input[@id='root_BankName']")
	private WebElement bankNameTextField;
	
	@FindBy(xpath="//input[@id='root_BankCode']")
	private WebElement bankCodeTextField;
	
	@FindBy(xpath="//input[@id='root_BankID']")
	private WebElement bankIdTextField;
	
	@FindBy(xpath="//input[@id='root_Buckets']")
	private WebElement bucketsTextField;
	
	@FindBy(xpath="//label[contains(text(),'EUR')]")
	private WebElement eurCurrencyRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'INR')]")
	private WebElement inrCurrencyRadioButton;
	
	public WebElement getCurrencySearchfield() {
		return currencySearchfield;
	}

	@FindBy(xpath="//label[contains(text(),'USD')]")
	private WebElement usdCurrencyRadioButton;
	
	@FindBy(xpath="(//a[contains(@class,'button dropdown-btn is-fullwidth')]//span[@class='dropdown-trigger-item'])[2]")
	private WebElement currencySelectDropDownField;
	
	@FindBy(xpath="(//div[@class='dropdown-trigger']//a[contains(@class,'button dropdown-btn is-fullwidth  ')])[1]")
	private WebElement timezonedropdown;
	
	@FindBy(xpath="(//input[@class='input secondary-input is-marginless'])[1]")
	private WebElement timezoneSearchfield;
	
	@FindBy(xpath="(//label[@class='radio-label'])[1]")
	private WebElement timezoneselect;
	
	public WebElement getTimezonedropdown() {
		return timezonedropdown;
	}
	public WebElement getTimezoneSearchfield() {
		return timezoneSearchfield;
	}
	public WebElement getTimezoneselect() {
		return timezoneselect;
	}

	@FindBy(xpath="(//input[@class='input secondary-input is-marginless'])[1]")
	private WebElement currencySearchfield;
	
	@FindBy(xpath="(//label[@class='radio-label'])[1]")
	private WebElement selectCurrency;
	
	public WebElement getSelectCurrency() {
		return selectCurrency;
	}

	@FindBy(xpath="//input[@id='root_BankLogoURL']")
	private WebElement bankLogoURLTextField;
	
	@FindBy(xpath="//label[contains(text(),'ACS')]")
	private WebElement productACSCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'3DS')]")
	private WebElement product3DSCheckBox;
	
	@FindBy(xpath="//label[contains(text(),'UAM')]")
	private WebElement productUAMCheckBox;
	
	@FindBy(xpath="//input[contains(@placeholder,'Search')]")
	private WebElement productsSearchTextField;

	
	@FindBy(xpath="//div[@class='options'][1]//div[@class='options__attach']")	
	private WebElement assignScreenButton;	
		
	@FindBy(xpath="//a[@class='button secondary-btn is-fullwidth  '][contains(text(),'Cancel')]")	
	private WebElement cancelbuttonnAssingscreen;	
		
	@FindBy(xpath="//a[@class='button primary-btn is-fullwidth  '][contains(text(),'Assign')]")	
	private WebElement assignButton;	
		
	@FindBy(xpath="//a[@class='button dropdown-btn is-fullwidth  ']")	
	private WebElement productDropdown;	
		
	@FindBy(xpath="//label[@class='radio-label']")	
	private WebElement productRadioButton;	
		
	@FindBy(xpath="//label[text()='Select a Product']")	
	private WebElement selectScreenDropdown;	
		

	@FindBy(xpath="//input[contains(@placeholder,'Search')]")	
	private WebElement screenSearch;	
		
	@FindBy(xpath="(//label[@class='checkbox__lable'])[1]")	
	private WebElement screenSelect;	
		
	@FindBy(xpath="(//input[@type='checkbox'])[1]")
	private WebElement checkbox;
	
	@FindBy(xpath="(//div[contains(@class,'dropdown-trigger ')]//a[contains(@class,'button dropdown-btn is-fullwidth  ')]//span[contains(@class,'dropdown-trigger-item')])[1]")
	private WebElement clusterdropdown;
	
	@FindBy(xpath="//label[@class='radio-label']")
	private WebElement selectcluster;
	
	@FindBy(xpath="(//div[contains(@class,'dropdown-trigger ')]//span[contains(@class,'dropdown-trigger-item')])[2]")
	private WebElement makerchecker;
	
	@FindBy(xpath="//label[@class='radio-label' and contains(text(),'Yes')]")
	private WebElement selectMakerYes;
	
	@FindBy(xpath="//label[@class='radio-label' and contains(text(),'No')]")
	private WebElement selectMakerNo;
	
	public WebElement getSelectMakerYes() {
		return selectMakerYes;
	}
	public WebElement getSelectMakerNo() {
		return selectMakerNo;
	}

	@FindBy(xpath="//label[@class='radio-label' and text()='3ds2dcs']")
	private WebElement select3ds2dcs;
	
	@FindBy(xpath="//label[@class='radio-label' and text()='dcs']")
	private WebElement selectdcs;
	
	@FindBy(xpath="//label[@class='radio-label' and text()='rbadcs']")
	private WebElement selectrbadcs;
	
	public WebElement getSelect3ds2dcs() {
		return select3ds2dcs;
	}
	public WebElement getSelectdcs() {
		return selectdcs;
	}
	public WebElement getSelectrbadcs() {
		return selectrbadcs;
	}
	public WebElement getCheckbox() {
		return checkbox;
	}
	public WebElement getAssignScreenButton() {	
		return assignScreenButton;	
	}	
	public WebElement getCancelbuttonnAssingscreen() {	
		return cancelbuttonnAssingscreen;	
	}	
	public WebElement getAssignButton() {	
		return assignButton;	
	}	
	public WebElement getProductDropdown() {	
		return productDropdown;	
	}	
	public WebElement getProductRadioButton() {	
		return productRadioButton;	
	}	
	public WebElement getSelectScreenDropdown() {	
		return selectScreenDropdown;	
	}	
	public WebElement getScreenSearch() {	
		return screenSearch;	
	}	
	public WebElement getScreenSelect() {	
		return screenSelect;	
	}
	
	public WebElement getListedBankName() {
		return listedBankName;
	}

	public WebElement getListedBankId() {
		return listedBankId;
	}

	public WebElement getListedBucketName() {
		return listedBucketName;
	}

	public WebElement getListedCurrencyOfBank() {
		return listedCurrencyOfBank;
	}

	public WebElement getListedProductsOfBank() {
		return listedProductsOfBank;
	}

	public WebElement getSearchByBankIdTextField() {
		return searchByBankIdTextField;
	}

	public WebElement getListPerPageDropDown() {
		return listPerPageDropDown;
	}

	public WebElement getList10PerPageRadioButton() {
		return list10PerPageRadioButton;
	}

	public WebElement getList20PerPageRadioButton() {
		return list20PerPageRadioButton;
	}

	public WebElement getList30PerPageRadioButton() {
		return list30PerPageRadioButton;
	}

	public WebElement getBankSearchField() {
		return bankSearchField;
	}

	public WebElement getCreateBankPlusButton() {
		return createBankPlusButton;
	}
	
	public WebElement getCreateBankCancelButton() {
		return createBankCancelButton;
	}
	

	public WebElement getCancleButton() {
		return CancleButton;
	}

	public WebElement getCreateBankButton() {
		return createBankButton;
	}

	public WebElement getBankNameTextField() {
		return bankNameTextField;
	}

	public WebElement getBankCodeTextField() {
		return bankCodeTextField;
	}

	public WebElement getBankIdTextField() {
		return bankIdTextField;
	}

	public WebElement getBucketsTextField() {
		return bucketsTextField;
	}

	public WebElement getEurCurrencyRadioButton() {
		return eurCurrencyRadioButton;
	}

	public WebElement getInrCurrencyRadioButton() {
		return inrCurrencyRadioButton;
	}

	public WebElement getUsdCurrencyRadioButton() {
		return usdCurrencyRadioButton;
	}

	public WebElement getCurrencySelectDropDownField() {
		return currencySelectDropDownField;
	}

	public WebElement getBankLogoURLTextField() {
		return bankLogoURLTextField;
	}

	public WebElement getProductACSCheckBox() {
		return productACSCheckBox;
	}

	public WebElement getProduct3DSCheckBox() {
		return product3DSCheckBox;
	}

	public WebElement getProductUAMCheckBox() {
		return productUAMCheckBox;
	}

	public WebElement getProductsSearchTextField() {
		return productsSearchTextField;
	}
	
	public WebElement getClusterdropdown() {
		return clusterdropdown;
	}
	public WebElement getSelectcluster() {
		return selectcluster;
	}
	public WebElement getMakerchecker() {
		return makerchecker;
	}
	
}

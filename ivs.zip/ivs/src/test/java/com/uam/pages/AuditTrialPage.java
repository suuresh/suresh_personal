package com.uam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AuditTrialPage {
	public WebDriver driver;
	public AuditTrialPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="(//div[@class='transaction-date__item'])[3]")
	private WebElement calenderDatePicker;

	@FindBy(xpath="//div[contains(text(),'ACS')]")
	private WebElement linkACS;

	@FindBy(xpath="//li[@class='sidebar__item active']//span[contains(text(),'Reports and Dashboards')]")
	private WebElement acsReportDashboards;

	@FindBy(xpath="//span[normalize-space()='Operations']")
	private WebElement acsOperations;

	@FindBy(xpath="(//span[normalize-space()='Configurations'])[1]")
	private WebElement acsConfigurations;

	@FindBy(xpath="(//li[normalize-space()='Transaction Report'])[1]")
	private WebElement acsTransactionReport;

	@FindBy(xpath="//li[normalize-space()='RBA MIS']")
	private WebElement acsRbaMis;

	@FindBy(xpath="(//li[normalize-space()='MDD Report'])[1]")
	private WebElement acsMddReport;

	@FindBy(xpath="//li[normalize-space()='Alerts Report']")
	private WebElement acsAlertReport;

	@FindBy(xpath="//li[normalize-space()='Monitoring Dashboard']")
	private WebElement acsMonitoringDashboard;

	@FindBy(xpath="//li[normalize-space()='ACS Dashboard']")
	private WebElement acsDashboard;

	@FindBy(xpath="//li[normalize-space()='Customer Data Upload Header']")
	private WebElement acsCustomDataUpload;
	
	@FindBy(xpath="//li[normalize-space()='ACS Transaction MIS']")
	private WebElement acsTransactionMis;
	
	@FindBy(xpath="//li[normalize-space()='ACS SMS MIS']")
	private WebElement acsSmsMis;
	
	@FindBy(xpath="//li[normalize-space()='ACS Third Party Details']")
	private WebElement acsThirdPartyDetail;
	
	@FindBy(xpath="//li[normalize-space()='EMI Transaction Report']")
	private WebElement emiTransactionReport;
	
	@FindBy(xpath="//li[normalize-space()='Otp Usage Report']")
	private WebElement otpUsageReport;
	
	@FindBy(xpath="//li[normalize-space()='Customer Data Upload']")
	private WebElement customerDataUpload;
	
	@FindBy(xpath="//li[normalize-space()='Customer Data Upload Header']")
	private WebElement customerDataUploadHeader;
	
	@FindBy(xpath="//li[normalize-space()='Add a Card']")
	private WebElement addACard;
	
	@FindBy(xpath="//li[normalize-space()='Audit Trail By Card']")
	private WebElement auditTrailByCard;
	
	@FindBy(xpath="//li[normalize-space()='Merchant Whitelist']")
	private WebElement merchantWhitelist;
	
	@FindBy(xpath="//li[normalize-space()='Manage Error Codes']")
	private WebElement manageErrorCode;
	
	@FindBy(xpath="//th[normalize-space()='Total Count(Accosa IVS)']")
	private WebElement validateTextAcsTranMis;
	
	@FindBy(xpath="//h4[normalize-space()='Third-Party API Report']")
	private WebElement validateTextThirdPartyDetails;
	
	@FindBy(xpath="//h4[normalize-space()='EMI Report']")
	private WebElement validateTextEmiTransactionReport;
	
	@FindBy(xpath="//h4[normalize-space()='OTP Details During Inflight Transactions']")
	private WebElement validateTextOtpUsageReport;

	@FindBy(xpath="//th[normalize-space()='Total Count']")
	private WebElement validateTextAcsSmsMis;
	
	@FindBy(xpath="//h4[normalize-space()='Manage Blocked Cards']")
	private WebElement validateTextManageBlockedCard;
	
	@FindBy(xpath="//h4[normalize-space()='View/Edit Card Details']")
	private WebElement validateTextManageCardholderDetail;
	
	@FindBy(xpath="//h4[normalize-space()='Customer File Upload List']")
	private WebElement validateTextCustomerFileUpload;
	
	@FindBy(xpath="//h4[normalize-space()='Configure Header Information']")
	private WebElement validateTextCustomerFileUploadHeader;
	
	@FindBy(xpath="//h4[normalize-space()='Audit Trail By Card']")
	private WebElement validateTextAuditTrailByCard;
	
	@FindBy(xpath="//h4[normalize-space()='Error Code Details']")
	private WebElement validateTextManageErrorCode;
	
	@FindBy(xpath="//h4[normalize-space()='Merchant Whitelist']")
	private WebElement validateTextMerchantWhitelist;
	
	@FindBy(xpath="//h4[normalize-space()='Create Card Details']")
	private WebElement validateTextAddCard;

	
	@FindBy(xpath="//a[normalize-space()='Save']")
	private WebElement saveFileData;

	@FindBy(xpath="//li[normalize-space()='Manage Cardholder Details']")
	private WebElement acsOperationsManageCardholderDetails;

	@FindBy(xpath="//li[normalize-space()='Manage Blocked Cards']")
	private WebElement acsOperationsManageBlockedCards;

	@FindBy(xpath="//input[@id='root_Mobile']")
	private WebElement inputMobileNumber;
	
	@FindBy(xpath="//input[@id='root_MobileNumber']")
	private WebElement inputMobileNumberManage;

	@FindBy(xpath="(//span[@class='dropdown-trigger-item'])[1]")
	private WebElement selectBlockedCard;

	@FindBy(xpath="//label[contains(text(),'HOTLIST')]")
	private WebElement selectHotListCard;

	@FindBy(xpath="//a[normalize-space()='Search']")
	private WebElement linkSearch;

	@FindBy(xpath="//div[@class='options__edit']")
	private WebElement editRecords;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement linkSaveChanges;

	@FindBy(xpath="//li[normalize-space()='Issuer Configurations']")
	private WebElement acsIssuerConfigurations;

	@FindBy(xpath="(//div[@data-tip='Edit'])[1]")
	private WebElement editActionConfigurationsFirstOne;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement saveConfigurations;

	@FindBy(xpath="//li[normalize-space()='Manage RBA Config']")
	private WebElement acsManageRbaConfig;

	@FindBy(xpath="//li[normalize-space()='Issuer Bin Range Configurations']")
	private WebElement acsIssuerBinRangeConfigurations;

	@FindBy(xpath="(//div[@data-tip='Rule Set Details'])[1]")
	private WebElement editRuleSetDetails;

	@FindBy(xpath="(//div[@data-tip='Edit'])[1]")
	private WebElement editBinRange;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement saveChanges;

	@FindBy(xpath="//a[normalize-space()='Update']")
	private WebElement updateBinRange;

	@FindBy(xpath="//span[contains(text(),'Select a bank')]")
	private WebElement selectBank;

	@FindBy(xpath="//span[normalize-space()='Wibmo']")
	private WebElement dropDownBankNameWibmo;

	@FindBy(xpath="//span[normalize-space()='National Bank']")
	private WebElement dropDownBankNameNational;

	@FindBy(xpath="//div[@class='sidebar__link'][normalize-space()='UAM']")
	private WebElement linkUam;

	@FindBy(xpath="//span[contains(text(),'Audit Trail')]")
	private WebElement linkAuditTrail;

	@FindBy(xpath="//h4[contains(text(),'Audit Trail Report')]")
	private WebElement headerTitleAuditTrail;

	@FindBy(xpath="//a[normalize-space()='Reset']")
	private WebElement btnReset;

	@FindBy(xpath="//a[normalize-space()='Download Report']")
	private WebElement btnDownloadReport;

	@FindBy(xpath="//a[normalize-space()='Fetch Report']")
	private WebElement btnFetchReport;

	@FindBy(xpath="//div[contains(text(),'Advanced Search')]")
	private WebElement advancedSearch;

	@FindBy(xpath="//a[@class='icon-link']")
	private WebElement plusLinkAdvancedSearch;

	@FindBy(xpath="//div[contains(text(),'Users')]")
	private WebElement lblUsers;

	@FindBy(xpath="//div[contains(text(),'Screen')]")
	private WebElement lblScreen;

	@FindBy(xpath="//div[contains(text(),'Entity Status')]")
	private WebElement lblEntityStatus;

	@FindBy(xpath="//div[3][@class='transaction-date__item']")
	private WebElement IconCalender;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select User']")
	private WebElement selectUser;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select Screens']")
	private WebElement selectScreens;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select Entity Status']")
	private WebElement selectEntityStatus;

	@FindBy(xpath="//h4[contains(text(),'Report Results')]")
	private WebElement reportResultHeader;

	@FindBy(xpath="//div[contains(text(),'Audit Time')]")
	private WebElement lblAuditTime;

	@FindBy(xpath="//div[contains(text(),'Entity Action')]")
	private WebElement lblEntityAction;

	@FindBy(xpath="(//div[contains(text(),'Screen')])[2]")
	private WebElement lblScreen2;

	@FindBy(xpath="//div[contains(text(),'Login Id')]")
	private WebElement lblLoginId;

	@FindBy(xpath="(//div[contains(text(),'Product')])[1]")
	private WebElement lblProduct;

	@FindBy(xpath="(//div[contains(text(),'Entity Status')])[2]")
	private WebElement lblEntityStatus2;

	@FindBy(xpath="(//div[@class='flex-table__cell column xl truncate'])[2]")
	private WebElement tableRecordEntityAction;

	@FindBy(xpath="//label[normalize-space()='ACS Transaction Report']")
	private WebElement acsTransactionReportScreen;

	@FindBy(xpath="//label[normalize-space()='RBA MIS']")
	private WebElement acsRbaMisScreen;

	@FindBy(xpath="//label[normalize-space()='MDD Report']")
	private WebElement acsMddScreen;

	@FindBy(xpath="//label[normalize-space()='Alerts Report']")
	private WebElement acsAlertScreen;

	@FindBy(xpath="//label[normalize-space()='Monitoring Dashboard']")
	private WebElement acsMonitoringDashboardScreen;

	@FindBy(xpath="//label[normalize-space()='Customer File Upload List']")
	private WebElement acsCustomerFileUploadList;

	@FindBy(xpath="//label[normalize-space()='Manage Cardholder Details']")
	private WebElement acsManageCardholderDetails;

	@FindBy(xpath="//li[normalize-space()='Manage Blocked Cards']")
	private WebElement acsManageBlockedCards;

	@FindBy(xpath="//label[normalize-space()='Issuer Configurations']")
	private WebElement acsIssuerConfigurationsSelectScreen;

	@FindBy(xpath="//label[normalize-space()='Manage RBA Config']")
	private WebElement acsManageRbaConfigScreen;

	@FindBy(xpath="//label[normalize-space()='Issuer Bin Range']")
	private WebElement acsIssuerBinRangeScreen;

	@FindBy(xpath="//label[normalize-space()='ACS Dashboard']")
	private WebElement acsDashboardScreen;

	@FindBy(xpath="//span[normalize-space()='ACS-REPORT-FETCH']")
	private WebElement requestActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-RBA-MIS-REPORT-FETCH']")
	private WebElement requestTypeRbaMis;

	@FindBy(xpath="//span[normalize-space()='ACS-MDD-REPORT-FETCH']")
	private WebElement requestMddActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-ALERT-REPORT-FETCH']")
	private WebElement requestAlertsActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-MONITORING-DASHBOARD-REPORT-FETCH']")
	private WebElement requestMonitoringDashboardType;

	@FindBy(xpath="//span[normalize-space()='ACS-DASHBOARD-REPORT-FETCH']")
	private WebElement requestAcsDashboardType;

	@FindBy(xpath="//span[normalize-space()='ACS Customer File Upload List']")
	private WebElement requestAcsCustomerFileUploadType;

	@FindBy(xpath="//span[normalize-space()='UPDATE_CARD_DATA']")
	private WebElement requestAcsManageCardHolderDetails;

	@FindBy(xpath="//span[normalize-space()='VIEW-CUSTOMER-DETAILS']")
	private WebElement requestAcsManageBlockedCard;

	@FindBy(xpath="//span[normalize-space()='UPDATE-ACS-ISSUER-CONFIG-VALUE']")
	private WebElement requestAcsIssuerConfigurations;

	@FindBy(xpath="//span[normalize-space()='FETCH-LIST-OF-RBA-RULES']")
	private WebElement requestAcsRbaRulesType;

	@FindBy(xpath="//span[normalize-space()='FETCH-LIST-OF-ISSUER-BIN-RANGES']")
	private WebElement requestAcsIsserBinRangeType;

	@FindBy(xpath="//span[normalize-space()='ACS Transaction']")
	private WebElement screensType;

	@FindBy(xpath="//span[normalize-space()='RBA MIS']")
	private WebElement screensTypeRbiMis;

	@FindBy(xpath="//span[normalize-space()='MDD Report']")
	private WebElement screensTypeMdd;

	@FindBy(xpath="//span[normalize-space()='Alert History Report']")
	private WebElement screensTypeAlert;

	@FindBy(xpath="//span[normalize-space()='Monitoring Dashboard']")
	private WebElement screensTypeMonitoringDashboard;

	@FindBy(xpath="//span[normalize-space()='ACS Report Dashboard']")
	private WebElement screensTypeDashboard;

	@FindBy(xpath="//span[normalize-space()='Config-Upload']")
	private WebElement screensTypeFileUpload;

	@FindBy(xpath="//span[normalize-space()='View Customer Details']")
	private WebElement screensTypeViewCustomerDetails;

	@FindBy(xpath="//span[normalize-space()='ACS Manage-cards-block']")
	private WebElement screensTypeManageBlockedCard;

	@FindBy(xpath="//span[normalize-space()='Issuer Configuration']")
	private WebElement screensTypeIssuerConfiguration;

	@FindBy(xpath="//span[normalize-space()='RBA Manage']")
	private WebElement screensTypeRbaManage;

	@FindBy(xpath="//span[normalize-space()='Issuer-bin-ranges']")
	private WebElement screensTypeIsserBibRange;

	@FindBy(xpath="//div[normalize-space()='bankId' or normalize-space()='issuer_id']//following::div[1]")
	private WebElement issuerId;

	@FindBy(xpath="//span[normalize-space()='Login Id']//following::div[1]")
	private WebElement userName;

	@FindBy(xpath="//div[@role='alert']")
	private WebElement toastMessage;
	
	@FindBy(xpath="//input[@id='root_PAN']")
	private WebElement textPan;
	
	@FindBy(xpath="//input[@id='root_CardNumber']")
	private WebElement textCardNumber;
	
	@FindBy(xpath="//input[@id='root_Mobile']")
	private WebElement textMobile;
	
	@FindBy(xpath="//input[@name='lastFourPan']")
	private WebElement textLastFourDigitPan;
	
	@FindBy(xpath="//div/input[@name='pan']")
	private WebElement inputCardNumber;
	
	@FindBy(xpath = "//*[name()='path' and contains(@d,'M17,7H7C4.')]")
	private WebElement viewBox1;
	
	@FindBy(xpath = "//h4[normalize-space()='MDD Report']")
	private WebElement mddReportHeader;
	
	@FindBy(xpath = "//h4[normalize-space()='Report Results']")
	private WebElement mddReportResult;


	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getTableRecordEntityAction() {
		return tableRecordEntityAction;
	}

	public WebElement getCalenderDatePicker() {
		return calenderDatePicker;
	}

	public WebElement getLinkACS() {
		return linkACS;
	}

	public WebElement getAcsReportDashboards() {
		return acsReportDashboards;
	}

	public WebElement getAcsOperations() {
		return acsOperations;
	}

	public WebElement getAcsConfigurations() {
		return acsConfigurations;
	}

	public WebElement getAcsTransactionReport() {
		return acsTransactionReport;
	}

	public WebElement getAcsRbaMis() {
		return acsRbaMis;
	}

	public WebElement getAcsMddReport() {
		return acsMddReport;
	}

	public WebElement getAcsAlertReport() {
		return acsAlertReport;
	}

	public WebElement getAcsMonitoringDashboard() {
		return acsMonitoringDashboard;
	}

	public WebElement getAcsDashboard() {
		return acsDashboard;
	}

	public WebElement getAcsCustomDataUpload() {
		return acsCustomDataUpload;
	}

	public WebElement getSaveFileData() {
		return saveFileData;
	}

	public WebElement getAcsOperationsManageCardholderDetails() {
		return acsOperationsManageCardholderDetails;
	}

	public WebElement getAcsOperationsManageBlockedCards() {
		return acsOperationsManageBlockedCards;
	}

	public WebElement getInputMobileNumber() {
		return inputMobileNumber;
	}

	public WebElement getSelectBlockedCard() {
		return selectBlockedCard;
	}

	public WebElement getSelectHotListCard() {
		return selectHotListCard;
	}

	public WebElement getLinkSearch() {
		return linkSearch;
	}

	public WebElement getEditRecords() {
		return editRecords;
	}

	public WebElement getLinkSaveChanges() {
		return linkSaveChanges;
	}

	public WebElement getAcsIssuerConfigurations() {
		return acsIssuerConfigurations;
	}

	public WebElement getEditActionConfigurationsFirstOne() {
		return editActionConfigurationsFirstOne;
	}

	public WebElement getSaveConfigurations() {
		return saveConfigurations;
	}

	public WebElement getAcsManageRbaConfig() {
		return acsManageRbaConfig;
	}

	public WebElement getAcsIssuerBinRangeConfigurations() {
		return acsIssuerBinRangeConfigurations;
	}

	public WebElement getEditRuleSetDetails() {
		return editRuleSetDetails;
	}

	public WebElement getEditBinRange() {
		return editBinRange;
	}

	public WebElement getSaveChanges() {
		return saveChanges;
	}

	public WebElement getUpdateBinRange() {
		return updateBinRange;
	}

	public WebElement getSelectBank() {
		return selectBank;
	}

	public WebElement getDropDownBankNameWibmo() {
		return dropDownBankNameWibmo;
	}

	public WebElement getDropDownBankNameNational() {
		return dropDownBankNameNational;
	}

	public WebElement getLinkUam() {
		return linkUam;
	}

	public WebElement getLinkAuditTrail() {
		return linkAuditTrail;
	}

	public WebElement getHeaderTitleAuditTrail() {
		return headerTitleAuditTrail;
	}

	public WebElement getBtnReset() {
		return btnReset;
	}

	public WebElement getBtnDownloadReport() {
		return btnDownloadReport;
	}

	public WebElement getBtnFetchReport() {
		return btnFetchReport;
	}

	public WebElement getAdvancedSearch() {
		return advancedSearch;
	}

	public WebElement getPlusLinkAdvancedSearch() {
		return plusLinkAdvancedSearch;
	}

	public WebElement getLblUsers() {
		return lblUsers;
	}

	public WebElement getLblScreen() {
		return lblScreen;
	}

	public WebElement getLblEntityStatus() {
		return lblEntityStatus;
	}

	public WebElement getIconCalender() {
		return IconCalender;
	}

	public WebElement getSelectUser() {
		return selectUser;
	}

	public WebElement getSelectScreens() {
		return selectScreens;
	}

	public WebElement getSelectEntityStatus() {
		return selectEntityStatus;
	}

	public WebElement getReportResultHeader() {
		return reportResultHeader;
	}

	public WebElement getLblAuditTime() {
		return lblAuditTime;
	}

	public WebElement getLblEntityAction() {
		return lblEntityAction;
	}

	public WebElement getLblScreen2() {
		return lblScreen2;
	}

	public WebElement getLblLoginId() {
		return lblLoginId;
	}

	public WebElement getLblProduct() {
		return lblProduct;
	}

	public WebElement getLblEntityStatus2() {
		return lblEntityStatus2;
	}

	public WebElement getAcsTransactionReportScreen() {
		return acsTransactionReportScreen;
	}

	public WebElement getAcsRbaMisScreen() {
		return acsRbaMisScreen;
	}

	public WebElement getAcsMddScreen() {
		return acsMddScreen;
	}

	public WebElement getAcsAlertScreen() {
		return acsAlertScreen;
	}

	public WebElement getAcsMonitoringDashboardScreen() {
		return acsMonitoringDashboardScreen;
	}

	public WebElement getAcsCustomerFileUploadList() {
		return acsCustomerFileUploadList;
	}

	public WebElement getAcsManageCardholderDetails() {
		return acsManageCardholderDetails;
	}

	public WebElement getAcsManageBlockedCards() {
		return acsManageBlockedCards;
	}

	public WebElement getAcsIssuerConfigurationsSelectScreen() {
		return acsIssuerConfigurationsSelectScreen;
	}

	public WebElement getAcsManageRbaConfigScreen() {
		return acsManageRbaConfigScreen;
	}

	public WebElement getAcsIssuerBinRangeScreen() {
		return acsIssuerBinRangeScreen;
	}

	public WebElement getAcsDashboardScreen() {
		return acsDashboardScreen;
	}

	public WebElement getRequestActionType() {
		return requestActionType;
	}

	public WebElement getRequestTypeRbaMis() {
		return requestTypeRbaMis;
	}

	public WebElement getRequestMddActionType() {
		return requestMddActionType;
	}

	public WebElement getRequestAlertsActionType() {
		return requestAlertsActionType;
	}

	public WebElement getRequestMonitoringDashboardType() {
		return requestMonitoringDashboardType;
	}

	public WebElement getRequestAcsDashboardType() {
		return requestAcsDashboardType;
	}

	public WebElement getRequestAcsCustomerFileUploadType() {
		return requestAcsCustomerFileUploadType;
	}

	public WebElement getRequestAcsManageCardHolderDetails() {
		return requestAcsManageCardHolderDetails;
	}

	public WebElement getRequestAcsManageBlockedCard() {
		return requestAcsManageBlockedCard;
	}

	public WebElement getRequestAcsIssuerConfigurations() {
		return requestAcsIssuerConfigurations;
	}

	public WebElement getRequestAcsRbaRulesType() {
		return requestAcsRbaRulesType;
	}

	public WebElement getRequestAcsIsserBinRangeType() {
		return requestAcsIsserBinRangeType;
	}

	public WebElement getScreensType() {
		return screensType;
	}

	public WebElement getScreensTypeRbiMis() {
		return screensTypeRbiMis;
	}

	public WebElement getScreensTypeMdd() {
		return screensTypeMdd;
	}

	public WebElement getScreensTypeAlert() {
		return screensTypeAlert;
	}

	public WebElement getScreensTypeMonitoringDashboard() {
		return screensTypeMonitoringDashboard;
	}

	public WebElement getScreensTypeDashboard() {
		return screensTypeDashboard;
	}

	public WebElement getScreensTypeFileUpload() {
		return screensTypeFileUpload;
	}

	public WebElement getScreensTypeViewCustomerDetails() {
		return screensTypeViewCustomerDetails;
	}

	public WebElement getScreensTypeManageBlockedCard() {
		return screensTypeManageBlockedCard;
	}

	public WebElement getScreensTypeIssuerConfiguration() {
		return screensTypeIssuerConfiguration;
	}

	public WebElement getScreensTypeRbaManage() {
		return screensTypeRbaManage;
	}

	public WebElement getScreensTypeIsserBibRange() {
		return screensTypeIsserBibRange;
	}

	public WebElement getIssuerId() {
		return issuerId;
	}

	public WebElement getUserName() {
		return userName;
	}

	public WebElement getToastMessage() {
		return toastMessage;
	}

	public WebElement getTextPan() {
		return textPan;
	}

	public WebElement getTextMobile() {
		return textMobile;
	}

	public WebElement getTextLastFourDigitPan() {
		return textLastFourDigitPan;
	}

	public WebElement getTextCardNumber() {
		return textCardNumber;
	}

	public WebElement getInputCardNumber() {
		return inputCardNumber;
	}

	public WebElement getInputMobileNumberManage() {
		return inputMobileNumberManage;
	}

	public WebElement getViewBox1() {
		return viewBox1;
	}

	public WebElement getMddReportHeader() {
		return mddReportHeader;
	}

	public WebElement getMddReportResult() {
		return mddReportResult;
	}

	public WebElement getAcsTransactionMis() {
		return acsTransactionMis;
	}

	public WebElement getAcsSmsMis() {
		return acsSmsMis;
	}

	public WebElement getAcsThirdPartyDetail() {
		return acsThirdPartyDetail;
	}

	public WebElement getEmiTransactionReport() {
		return emiTransactionReport;
	}

	public WebElement getOtpUsageReport() {
		return otpUsageReport;
	}

	public WebElement getValidateTextAcsTranMis() {
		return validateTextAcsTranMis;
	}

	public WebElement getValidateTextAcsSmsMis() {
		return validateTextAcsSmsMis;
	}
	public WebElement getValidateTextThirdPartyDetails() {
		return validateTextThirdPartyDetails;
	}

	public WebElement getValidateTextEmiTransactionReport() {
		return validateTextEmiTransactionReport;
	}

	public WebElement getValidateTextOtpUsageReport() {
		return validateTextOtpUsageReport;
	}

	public WebElement getValidateTextManageCardholderDetail() {
		return validateTextManageCardholderDetail;
	}

	public void setValidateTextManageCardholderDetail(
			WebElement validateTextManageCardholderDetail) {
		this.validateTextManageCardholderDetail = validateTextManageCardholderDetail;
	}

	public WebElement getValidateTextManageBlockedCard() {
		return validateTextManageBlockedCard;
	}

	public WebElement getCustomerDataUpload() {
		return customerDataUpload;
	}

	public WebElement getCustomerDataUploadHeader() {
		return customerDataUploadHeader;
	}

	public WebElement getAuditTrailByCard() {
		return auditTrailByCard;
	}

	public WebElement getMerchantWhitelist() {
		return merchantWhitelist;
	}

	public WebElement getManageErrorCode() {
		return manageErrorCode;
	}

	public WebElement getValidateTextCustomerFileUpload() {
		return validateTextCustomerFileUpload;
	}

	public WebElement getValidateTextCustomerFileUploadHeader() {
		return validateTextCustomerFileUploadHeader;
	}

	public WebElement getValidateTextAditTrailByCard() {
		return validateTextAuditTrailByCard;
	}

	public WebElement getValidateTextManageErrorCode() {
		return validateTextManageErrorCode;
	}

	public WebElement getValidateTextMerchantWhitelist() {
		return validateTextMerchantWhitelist;
	}

	public WebElement getAddACard() {
		return addACard;
	}

	public WebElement getValidateTextAuditTrailByCard() {
		return validateTextAuditTrailByCard;
	}

	public WebElement getValidateTextAddCard() {
		return validateTextAddCard;
	}
}

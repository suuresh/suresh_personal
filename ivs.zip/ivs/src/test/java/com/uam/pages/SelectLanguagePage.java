package com.uam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SelectLanguagePage {
	public WebDriver driver;
	public SelectLanguagePage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="(//div[@class='transaction-date__item'])[3]")
	private WebElement calenderDatePicker;

	@FindBy(xpath="//div[normalize-space()='ACS']")
	private WebElement linkACS;

	@FindBy(xpath="(//span[normalize-space()='Reports and Dashboards'])[1]")
	private WebElement acsReportDashboards;

	@FindBy(xpath="//span[normalize-space()='Operations']")
	private WebElement acsOperations;

	@FindBy(xpath="(//span[normalize-space()='Configurations'])[1]")
	private WebElement acsConfigurations;

	@FindBy(xpath="(//li[normalize-space()='Transaction Report'])[1]")
	private WebElement acsTransactionReport;

	@FindBy(xpath="//li[normalize-space()='RBA MIS']")
	private WebElement acsRbaMis;

	@FindBy(xpath="(//li[normalize-space()='MDD Report'])[1]")
	private WebElement acsMddReport;

	@FindBy(xpath="//li[normalize-space()='Alerts Report']")
	private WebElement acsAlertReport;

	@FindBy(xpath="//li[normalize-space()='Monitoring Dashboard']")
	private WebElement acsMonitoringDashboard;

	@FindBy(xpath="//li[normalize-space()='ACS Dashboard']")
	private WebElement acsDashboard;

	@FindBy(xpath="//li[normalize-space()='Customer Data Upload Header']")
	private WebElement acsCustomDataUpload;

	@FindBy(xpath="//a[normalize-space()='Save']")
	private WebElement saveFileData;

	@FindBy(xpath="//li[normalize-space()='Manage Cardholder Details']")
	private WebElement acsOperationsManageCardholderDetails;

	@FindBy(xpath="//li[normalize-space()='Manage Blocked Cards']")
	private WebElement acsOperationsManageBlockedCards;

	@FindBy(xpath="//input[@id='root_Mobile']")
	private WebElement inputMobileNumber;
	
	@FindBy(xpath="//input[@id='root_MobileNumber']")
	private WebElement inputMobileNumberManage;

	@FindBy(xpath="(//span[@class='dropdown-trigger-item'])[1]")
	private WebElement selectBlockedCard;

	@FindBy(xpath="//label[contains(text(),'HOTLIST')]")
	private WebElement selectHotListCard;

	@FindBy(xpath="//a[normalize-space()='Search']")
	private WebElement linkSearch;

	@FindBy(xpath="//div[@class='options__edit']")
	private WebElement editRecords;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement linkSaveChanges;

	@FindBy(xpath="//li[normalize-space()='Issuer Configurations']")
	private WebElement acsIssuerConfigurations;

	@FindBy(xpath="(//div[@data-tip='Edit'])[1]")
	private WebElement editActionConfigurationsFirstOne;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement saveConfigurations;

	@FindBy(xpath="//li[normalize-space()='Manage RBA Config']")
	private WebElement acsManageRbaConfig;

	@FindBy(xpath="//li[normalize-space()='Issuer Bin Range Configurations']")
	private WebElement acsIssuerBinRangeConfigurations;

	@FindBy(xpath="(//div[@data-tip='Rule Set Details'])[1]")
	private WebElement editRuleSetDetails;

	@FindBy(xpath="(//div[@data-tip='Edit'])[1]")
	private WebElement editBinRange;

	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	private WebElement saveChanges;

	@FindBy(xpath="//a[normalize-space()='Update']")
	private WebElement updateBinRange;

	@FindBy(xpath="//span[contains(text(),'Select a bank')]")
	private WebElement selectBank;

	@FindBy(xpath="//span[normalize-space()='Wibmo']")
	private WebElement dropDownBankNameWibmo;

	@FindBy(xpath="//span[normalize-space()='National Bank']")
	private WebElement dropDownBankNameNational;
	
	  // language selection
	
	@FindBy(xpath="//select[@class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']")
	private WebElement selectLanguageDropdown;
	
	@FindBy(xpath="//select[@Class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']/option[@value='Deutsche']")
	private WebElement selectLanguageDeutche;
	
	@FindBy(xpath="//select[@Class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']/option[@value='Española']")
	private WebElement selectLanguageOther;
	
	@FindBy(xpath="//select[@Class='languageDropdown langdesign Select-sc-1sm01tk-0 wIjFa']/option[@value='English']")
	private WebElement selectLanguageEnglish;
	
	// acs transaction page primary and secondary button
	@FindBy(xpath="//h4[@class='page__title']")
	private WebElement acsTranHeaderLabel;
	
	@FindBy(xpath="//div[@class='adv__search']")
	private WebElement lblAdvancedSearch;
	
	@FindBy(xpath="//a[@class='button primary-btn   ']")
	private WebElement lblFetchReport;
	
	@FindBy(xpath="//a[@class='button secondary-btn   ']")
	private WebElement lblReset;
	
	//ACS transaction advanced search field name
	@FindBy(xpath="(//div[@class='transaction-report is-active']/div/div/div/label[1])[1]")
	private WebElement lblCardNumber;
	@FindBy(xpath="(//div[@class='transaction-report is-active']/div/div/div/label[1])[2]")
	private WebElement lblMerchantId;
	@FindBy(xpath="(//div[@class='transaction-report is-active']/div/div/div/label[1])[3]")
	private WebElement lblAcsTranId;
	@FindBy(xpath="(//div[@class='dropdown__title'])[1]")
	private WebElement lblAuthType;
	
	@FindBy(xpath="(//div[@class='dropdown__title'])[2]")
	private WebElement lblDeviceChannel;
	@FindBy(xpath="(//div[@class='dropdown__title'])[3]")
	private WebElement lblCardUnion;
	@FindBy(xpath="(//div[@class='dropdown__title'])[4]")
	private WebElement lblCardType;
	@FindBy(xpath="(//div[@class='dropdown__title'])[5]")
	private WebElement lblTranStatus;
	
	@FindBy(xpath="(//div[@class='dropdown__title'])[6]")
	private WebElement lblBinNumber;
	@FindBy(xpath="(//div[@class='dropdown__title'])[7]")
	private WebElement lblDataCenter;
	@FindBy(xpath="(//div[@class='dropdown__title'])[8]")
	private WebElement lblEnvironment;
	@FindBy(xpath="//div[4]//div[3]//div[1]//label[1]")
	private WebElement lblRiskScoreRange;
	
	@FindBy(xpath="(//div[@class='dropdown__title'])[9]")
	private WebElement lblRuleSetId;
	
	@FindBy(xpath="//div[5]//div[2]//div[1]//label[1]")
	private WebElement lblRiskEngineClientId;
	
	@FindBy(xpath="//div[5]//div[3]//div[1]//label[1]")
	private WebElement lblProductionNode;
	
	@FindBy(xpath="(//div[@class='dropdown__title'])[10]")
	private WebElement lblTransactionType;
	@FindBy(xpath="(//div[@class='dropdown__title'])[11]")
	private WebElement lblClientId;
	
	@FindBy(xpath="(//div[@class='dropdown__title'])[12]")
	private WebElement lblProtocalVersion;
	
	//ACS Transaction report column name
	
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[1]")
	private WebElement lbltimeStamp;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[2]")
	private WebElement lblCardNumberReportResult;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[3]")
	private WebElement lblProtocalVer;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[4]")
	private WebElement lblMerchName;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[5]")
	private WebElement lblTranAmount;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[6]")
	private WebElement lblTranType;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[7]")
	private WebElement lblCardTypeReportResult;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[8]")
	private WebElement lblCardUnionReportResult;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[9]")
	private WebElement lblDataCentre;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[10]")
	private WebElement lblDeviceChannelReportResult;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[11]")
	private WebElement lblAuthenticationType;
	@FindBy(xpath="(//div[@class='flex-table__header columns']/div)[12]")
	private WebElement lblStatus;
	
	//mdd report title name
	@FindBy(xpath="(//h4[@class='page__title'])[1]")
	private WebElement lblMddReportHeader1;
	@FindBy(xpath="(//h4[@class='page__title'])[2]")
	private WebElement lblMddReportHeader2;

	// acs dashboard report title name and lable name
	@FindBy(xpath="(//div[@class='title'])[1]")
	private WebElement lblTotalNumberTranINR;
	@FindBy(xpath="(//div[@class='title'])[2]")
	private WebElement lblTotalAmountINR;
	@FindBy(xpath="(//div[@class='title'])[3]")
	private WebElement lblAvgAmountSpendINR;
	@FindBy(xpath="(//div[@class='title'])[4]")
	private WebElement lblAuthRate;
	@FindBy(xpath="(//div[@class='title'])[5]")
	private WebElement lblTotalNumberTranAllCur;
	@FindBy(xpath="(//div[@class='title'])[6]")
	private WebElement lblTotalNumberTranNonINR;
	@FindBy(xpath="(//div[@class='title'])[7]")
	private WebElement lblTotalAmountNonINR;
	@FindBy(xpath="(//div[@class='title'])[8]")
	private WebElement lblCardUsageBreakDown;
	
	@FindBy(xpath="(//div[@class='title'])[10]")
	private WebElement lblFrictionlessTran;
	@FindBy(xpath="(//div[@class='title'])[11]")
	private WebElement lblChallengedTran;
	@FindBy(xpath="(//div[@class='title'])[12]")
	private WebElement lblDeclinedTran;
	@FindBy(xpath="(//div[@class='title'])[13]")
	private WebElement lblFailureTran;
	@FindBy(xpath="(//h4[@class='page__title'])[1]")
	private WebElement lblAcsHighlight;
	@FindBy(xpath="(//h4[@class='page__title'])[2]")
	private WebElement lblInsight;
	@FindBy(xpath="(//h4[@class='page__title'])[3]")
	private WebElement lblTransactionTrends;
	
	// Other 

	@FindBy(xpath="//div[@class='sidebar__link'][normalize-space()='UAM']")
	private WebElement linkUam;

	@FindBy(xpath="//span[contains(text(),'Audit Trail')]")
	private WebElement linkAuditTrail;

	@FindBy(xpath="//h4[contains(text(),'Audit Trail Report')]")
	private WebElement headerTitleAuditTrail;

	@FindBy(xpath="//a[normalize-space()='Reset']")
	private WebElement btnReset;

	@FindBy(xpath="//a[normalize-space()='Download Report']")
	private WebElement btnDownloadReport;

	@FindBy(xpath="//a[normalize-space()='Fetch Report']")
	private WebElement btnFetchReport;

	@FindBy(xpath="//div[contains(text(),'Advanced Search')]")
	private WebElement advancedSearch;

	@FindBy(xpath="//a[@class='icon-link']")
	private WebElement plusLinkAdvancedSearch;

	@FindBy(xpath="//div[contains(text(),'Users')]")
	private WebElement lblUsers;

	@FindBy(xpath="//div[contains(text(),'Screen')]")
	private WebElement lblScreen;

	@FindBy(xpath="//div[contains(text(),'Entity Status')]")
	private WebElement lblEntityStatus;

	@FindBy(xpath="//div[3][@class='transaction-date__item']")
	private WebElement IconCalender;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select User']")
	private WebElement selectUser;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select Screens']")
	private WebElement selectScreens;

	@FindBy(xpath="//span[@class='dropdown-trigger-item'][normalize-space()='Select Entity Status']")
	private WebElement selectEntityStatus;

	@FindBy(xpath="//h4[contains(text(),'Report Results')]")
	private WebElement reportResultHeader;

	@FindBy(xpath="//div[contains(text(),'Audit Time')]")
	private WebElement lblAuditTime;

	@FindBy(xpath="//div[contains(text(),'Entity Action')]")
	private WebElement lblEntityAction;

	@FindBy(xpath="(//div[contains(text(),'Screen')])[2]")
	private WebElement lblScreen2;

	@FindBy(xpath="//div[contains(text(),'Login Id')]")
	private WebElement lblLoginId;

	@FindBy(xpath="(//div[contains(text(),'Product')])[1]")
	private WebElement lblProduct;

	@FindBy(xpath="(//div[contains(text(),'Entity Status')])[2]")
	private WebElement lblEntityStatus2;

	@FindBy(xpath="(//div[@class='flex-table__cell column xl truncate'])[2]")
	private WebElement tableRecordEntityAction;

	@FindBy(xpath="//label[normalize-space()='ACS Transaction Report']")
	private WebElement acsTransactionReportScreen;

	@FindBy(xpath="//label[normalize-space()='RBA MIS']")
	private WebElement acsRbaMisScreen;

	@FindBy(xpath="//label[normalize-space()='MDD Report']")
	private WebElement acsMddScreen;

	@FindBy(xpath="//label[normalize-space()='Alerts Report']")
	private WebElement acsAlertScreen;

	@FindBy(xpath="//label[normalize-space()='Monitoring Dashboard']")
	private WebElement acsMonitoringDashboardScreen;

	@FindBy(xpath="//label[normalize-space()='Customer File Upload List']")
	private WebElement acsCustomerFileUploadList;

	@FindBy(xpath="//label[normalize-space()='Manage Cardholder Details']")
	private WebElement acsManageCardholderDetails;

	@FindBy(xpath="//label[normalize-space()='Manage Blocked Cards']")
	private WebElement acsManageBlockedCards;

	@FindBy(xpath="//label[normalize-space()='Issuer Configurations']")
	private WebElement acsIssuerConfigurationsSelectScreen;

	@FindBy(xpath="//label[normalize-space()='Manage RBA Config']")
	private WebElement acsManageRbaConfigScreen;

	@FindBy(xpath="//label[normalize-space()='Issuer Bin Range']")
	private WebElement acsIssuerBinRangeScreen;

	@FindBy(xpath="//label[normalize-space()='ACS Dashboard']")
	private WebElement acsDashboardScreen;

	@FindBy(xpath="//span[normalize-space()='ACS-REPORT-FETCH']")
	private WebElement requestActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-RBA-MIS-REPORT-FETCH']")
	private WebElement requestTypeRbaMis;

	@FindBy(xpath="//span[normalize-space()='ACS-MDD-REPORT-FETCH']")
	private WebElement requestMddActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-ALERT-REPORT-FETCH']")
	private WebElement requestAlertsActionType;

	@FindBy(xpath="//span[normalize-space()='ACS-MONITORING-DASHBOARD-REPORT-FETCH']")
	private WebElement requestMonitoringDashboardType;

	@FindBy(xpath="//span[normalize-space()='ACS-DASHBOARD-REPORT-FETCH']")
	private WebElement requestAcsDashboardType;

	@FindBy(xpath="//span[normalize-space()='ACS Customer File Upload List']")
	private WebElement requestAcsCustomerFileUploadType;

	@FindBy(xpath="//span[normalize-space()='UPDATE_CARD_DATA']")
	private WebElement requestAcsManageCardHolderDetails;

	@FindBy(xpath="//span[normalize-space()='VIEW-CUSTOMER-DETAILS']")
	private WebElement requestAcsManageBlockedCard;

	@FindBy(xpath="//span[normalize-space()='UPDATE-ACS-ISSUER-CONFIG-VALUE']")
	private WebElement requestAcsIssuerConfigurations;

	@FindBy(xpath="//span[normalize-space()='FETCH-LIST-OF-RBA-RULES']")
	private WebElement requestAcsRbaRulesType;

	@FindBy(xpath="//span[normalize-space()='FETCH-LIST-OF-ISSUER-BIN-RANGES']")
	private WebElement requestAcsIsserBinRangeType;

	@FindBy(xpath="//span[normalize-space()='ACS Transaction']")
	private WebElement screensType;

	@FindBy(xpath="//span[normalize-space()='RBA MIS']")
	private WebElement screensTypeRbiMis;

	@FindBy(xpath="//span[normalize-space()='MDD Report']")
	private WebElement screensTypeMdd;

	@FindBy(xpath="//span[normalize-space()='Alert History Report']")
	private WebElement screensTypeAlert;

	@FindBy(xpath="//span[normalize-space()='Monitoring Dashboard']")
	private WebElement screensTypeMonitoringDashboard;

	@FindBy(xpath="//span[normalize-space()='ACS Report Dashboard']")
	private WebElement screensTypeDashboard;

	@FindBy(xpath="//span[normalize-space()='Config-Upload']")
	private WebElement screensTypeFileUpload;

	@FindBy(xpath="//span[normalize-space()='View Customer Details']")
	private WebElement screensTypeViewCustomerDetails;

	@FindBy(xpath="//span[normalize-space()='ACS Manage-cards-block']")
	private WebElement screensTypeManageBlockedCard;

	@FindBy(xpath="//span[normalize-space()='Issuer Configuration']")
	private WebElement screensTypeIssuerConfiguration;

	@FindBy(xpath="//span[normalize-space()='RBA Manage']")
	private WebElement screensTypeRbaManage;

	@FindBy(xpath="//span[normalize-space()='Issuer-bin-ranges']")
	private WebElement screensTypeIsserBibRange;

	@FindBy(xpath="//div[normalize-space()='bankId' or normalize-space()='issuer_id']//following::div[1]")
	private WebElement issuerId;

	@FindBy(xpath="//span[normalize-space()='Login Id']//following::div[1]")
	private WebElement userName;

	@FindBy(xpath="//div[@role='alert']")
	private WebElement toastMessage;
	
	@FindBy(xpath="//input[@id='root_PAN']")
	private WebElement textPan;
	
	@FindBy(xpath="//input[@id='root_CardNumber']")
	private WebElement textCardNumber;
	
	@FindBy(xpath="//input[@id='root_Mobile']")
	private WebElement textMobile;
	
	@FindBy(xpath="//input[@name='lastFourPan']")
	private WebElement textLastFourDigitPan;
	
	@FindBy(xpath="//div/input[@name='pan']")
	private WebElement inputCardNumber;
	
	@FindBy(xpath="//h5[@class='page__title']")
	private WebElement textWelcomeAccosa;
	
	@FindBy(xpath="//h4[@class='page__title']")
	private WebElement textBankSelection;
	

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getTableRecordEntityAction() {
		return tableRecordEntityAction;
	}

	public WebElement getCalenderDatePicker() {
		return calenderDatePicker;
	}

	public WebElement getLinkACS() {
		return linkACS;
	}

	public WebElement getAcsReportDashboards() {
		return acsReportDashboards;
	}

	public WebElement getAcsOperations() {
		return acsOperations;
	}

	public WebElement getAcsConfigurations() {
		return acsConfigurations;
	}

	public WebElement getAcsTransactionReport() {
		return acsTransactionReport;
	}

	public WebElement getAcsRbaMis() {
		return acsRbaMis;
	}

	public WebElement getAcsMddReport() {
		return acsMddReport;
	}

	public WebElement getAcsAlertReport() {
		return acsAlertReport;
	}

	public WebElement getAcsMonitoringDashboard() {
		return acsMonitoringDashboard;
	}

	public WebElement getAcsDashboard() {
		return acsDashboard;
	}

	public WebElement getAcsCustomDataUpload() {
		return acsCustomDataUpload;
	}

	public WebElement getSaveFileData() {
		return saveFileData;
	}

	public WebElement getAcsOperationsManageCardholderDetails() {
		return acsOperationsManageCardholderDetails;
	}

	public WebElement getAcsOperationsManageBlockedCards() {
		return acsOperationsManageBlockedCards;
	}

	public WebElement getInputMobileNumber() {
		return inputMobileNumber;
	}

	public WebElement getSelectBlockedCard() {
		return selectBlockedCard;
	}

	public WebElement getSelectHotListCard() {
		return selectHotListCard;
	}

	public WebElement getLinkSearch() {
		return linkSearch;
	}

	public WebElement getEditRecords() {
		return editRecords;
	}

	public WebElement getLinkSaveChanges() {
		return linkSaveChanges;
	}

	public WebElement getAcsIssuerConfigurations() {
		return acsIssuerConfigurations;
	}

	public WebElement getEditActionConfigurationsFirstOne() {
		return editActionConfigurationsFirstOne;
	}

	public WebElement getSaveConfigurations() {
		return saveConfigurations;
	}

	public WebElement getAcsManageRbaConfig() {
		return acsManageRbaConfig;
	}

	public WebElement getAcsIssuerBinRangeConfigurations() {
		return acsIssuerBinRangeConfigurations;
	}

	public WebElement getEditRuleSetDetails() {
		return editRuleSetDetails;
	}

	public WebElement getEditBinRange() {
		return editBinRange;
	}

	public WebElement getSaveChanges() {
		return saveChanges;
	}

	public WebElement getUpdateBinRange() {
		return updateBinRange;
	}

	public WebElement getSelectBank() {
		return selectBank;
	}

	public WebElement getDropDownBankNameWibmo() {
		return dropDownBankNameWibmo;
	}

	public WebElement getDropDownBankNameNational() {
		return dropDownBankNameNational;
	}

	public WebElement getLinkUam() {
		return linkUam;
	}

	public WebElement getLinkAuditTrail() {
		return linkAuditTrail;
	}

	public WebElement getHeaderTitleAuditTrail() {
		return headerTitleAuditTrail;
	}

	public WebElement getBtnReset() {
		return btnReset;
	}

	public WebElement getBtnDownloadReport() {
		return btnDownloadReport;
	}

	public WebElement getBtnFetchReport() {
		return btnFetchReport;
	}

	public WebElement getAdvancedSearch() {
		return advancedSearch;
	}

	public WebElement getPlusLinkAdvancedSearch() {
		return plusLinkAdvancedSearch;
	}

	public WebElement getLblUsers() {
		return lblUsers;
	}

	public WebElement getLblScreen() {
		return lblScreen;
	}

	public WebElement getLblEntityStatus() {
		return lblEntityStatus;
	}

	public WebElement getIconCalender() {
		return IconCalender;
	}

	public WebElement getSelectUser() {
		return selectUser;
	}

	public WebElement getSelectScreens() {
		return selectScreens;
	}

	public WebElement getSelectEntityStatus() {
		return selectEntityStatus;
	}

	public WebElement getReportResultHeader() {
		return reportResultHeader;
	}

	public WebElement getLblAuditTime() {
		return lblAuditTime;
	}

	public WebElement getLblEntityAction() {
		return lblEntityAction;
	}

	public WebElement getLblScreen2() {
		return lblScreen2;
	}

	public WebElement getLblLoginId() {
		return lblLoginId;
	}

	public WebElement getLblProduct() {
		return lblProduct;
	}

	public WebElement getLblEntityStatus2() {
		return lblEntityStatus2;
	}

	public WebElement getAcsTransactionReportScreen() {
		return acsTransactionReportScreen;
	}

	public WebElement getAcsRbaMisScreen() {
		return acsRbaMisScreen;
	}

	public WebElement getAcsMddScreen() {
		return acsMddScreen;
	}

	public WebElement getAcsAlertScreen() {
		return acsAlertScreen;
	}

	public WebElement getAcsMonitoringDashboardScreen() {
		return acsMonitoringDashboardScreen;
	}

	public WebElement getAcsCustomerFileUploadList() {
		return acsCustomerFileUploadList;
	}

	public WebElement getAcsManageCardholderDetails() {
		return acsManageCardholderDetails;
	}

	public WebElement getAcsManageBlockedCards() {
		return acsManageBlockedCards;
	}

	public WebElement getAcsIssuerConfigurationsSelectScreen() {
		return acsIssuerConfigurationsSelectScreen;
	}

	public WebElement getAcsManageRbaConfigScreen() {
		return acsManageRbaConfigScreen;
	}

	public WebElement getAcsIssuerBinRangeScreen() {
		return acsIssuerBinRangeScreen;
	}

	public WebElement getAcsDashboardScreen() {
		return acsDashboardScreen;
	}

	public WebElement getRequestActionType() {
		return requestActionType;
	}

	public WebElement getRequestTypeRbaMis() {
		return requestTypeRbaMis;
	}

	public WebElement getRequestMddActionType() {
		return requestMddActionType;
	}

	public WebElement getRequestAlertsActionType() {
		return requestAlertsActionType;
	}

	public WebElement getRequestMonitoringDashboardType() {
		return requestMonitoringDashboardType;
	}

	public WebElement getRequestAcsDashboardType() {
		return requestAcsDashboardType;
	}

	public WebElement getRequestAcsCustomerFileUploadType() {
		return requestAcsCustomerFileUploadType;
	}

	public WebElement getRequestAcsManageCardHolderDetails() {
		return requestAcsManageCardHolderDetails;
	}

	public WebElement getRequestAcsManageBlockedCard() {
		return requestAcsManageBlockedCard;
	}

	public WebElement getRequestAcsIssuerConfigurations() {
		return requestAcsIssuerConfigurations;
	}

	public WebElement getRequestAcsRbaRulesType() {
		return requestAcsRbaRulesType;
	}

	public WebElement getRequestAcsIsserBinRangeType() {
		return requestAcsIsserBinRangeType;
	}

	public WebElement getScreensType() {
		return screensType;
	}

	public WebElement getScreensTypeRbiMis() {
		return screensTypeRbiMis;
	}

	public WebElement getScreensTypeMdd() {
		return screensTypeMdd;
	}

	public WebElement getScreensTypeAlert() {
		return screensTypeAlert;
	}

	public WebElement getScreensTypeMonitoringDashboard() {
		return screensTypeMonitoringDashboard;
	}

	public WebElement getScreensTypeDashboard() {
		return screensTypeDashboard;
	}

	public WebElement getScreensTypeFileUpload() {
		return screensTypeFileUpload;
	}

	public WebElement getScreensTypeViewCustomerDetails() {
		return screensTypeViewCustomerDetails;
	}

	public WebElement getScreensTypeManageBlockedCard() {
		return screensTypeManageBlockedCard;
	}

	public WebElement getScreensTypeIssuerConfiguration() {
		return screensTypeIssuerConfiguration;
	}

	public WebElement getScreensTypeRbaManage() {
		return screensTypeRbaManage;
	}

	public WebElement getScreensTypeIsserBibRange() {
		return screensTypeIsserBibRange;
	}

	public WebElement getIssuerId() {
		return issuerId;
	}

	public WebElement getUserName() {
		return userName;
	}

	public WebElement getToastMessage() {
		return toastMessage;
	}

	public WebElement getTextPan() {
		return textPan;
	}

	public WebElement getTextMobile() {
		return textMobile;
	}

	public WebElement getTextLastFourDigitPan() {
		return textLastFourDigitPan;
	}

	public WebElement getTextCardNumber() {
		return textCardNumber;
	}

	public WebElement getInputCardNumber() {
		return inputCardNumber;
	}

	public WebElement getInputMobileNumberManage() {
		return inputMobileNumberManage;
	}

	public WebElement getTextWelcomeAccosa() {
		return textWelcomeAccosa;
	}

	public WebElement getTextBankSelection() {
		return textBankSelection;
	}

	public WebElement getSelectLanguageDeutche() {
		return selectLanguageDeutche;
	}

	public WebElement getSelectLanguageOther() {
		return selectLanguageOther;
	}

	public WebElement getAcsTranHeaderLabel() {
		return acsTranHeaderLabel;
	}

	public WebElement getLblAdvancedSearch() {
		return lblAdvancedSearch;
	}

	public WebElement getLblFetchReport() {
		return lblFetchReport;
	}

	public WebElement getLblReset() {
		return lblReset;
	}

	public WebElement getLblCardNumber() {
		return lblCardNumber;
	}

	public WebElement getLblMerchantId() {
		return lblMerchantId;
	}

	

	public WebElement getSelectLanguageEnglish() {
		return selectLanguageEnglish;
	}

	public WebElement getLblAcsTranId() {
		return lblAcsTranId;
	}

	public WebElement getLblAuthType() {
		return lblAuthType;
	}

	public WebElement getLblDeviceChannel() {
		return lblDeviceChannel;
	}

	public WebElement getLblCardUnion() {
		return lblCardUnion;
	}

	public WebElement getLblCardType() {
		return lblCardType;
	}

	public WebElement getLblTranStatus() {
		return lblTranStatus;
	}

	public WebElement getLblBinNumber() {
		return lblBinNumber;
	}

	public WebElement getLblDataCenter() {
		return lblDataCenter;
	}

	public WebElement getLblEnvironment() {
		return lblEnvironment;
	}

	public WebElement getLblRiskScoreRange() {
		return lblRiskScoreRange;
	}

	public WebElement getLblRuleSetId() {
		return lblRuleSetId;
	}

	public WebElement getLblRiskEngineClientId() {
		return lblRiskEngineClientId;
	}

	public WebElement getLblProductionNode() {
		return lblProductionNode;
	}

	public WebElement getLblTransactionType() {
		return lblTransactionType;
	}

	public WebElement getLblClientId() {
		return lblClientId;
	}

	public WebElement getLblProtocalVersion() {
		return lblProtocalVersion;
	}

	public WebElement getLbltimeStamp() {
		return lbltimeStamp;
	}

	public WebElement getLblCardNumberReportResult() {
		return lblCardNumberReportResult;
	}

	public WebElement getLblProtocalVer() {
		return lblProtocalVer;
	}

	public WebElement getLblMerchName() {
		return lblMerchName;
	}

	public WebElement getLblTranAmount() {
		return lblTranAmount;
	}

	public WebElement getLblTranType() {
		return lblTranType;
	}

	public WebElement getLblCardTypeReportResult() {
		return lblCardTypeReportResult;
	}

	public WebElement getLblCardUnionReportResult() {
		return lblCardUnionReportResult;
	}

	public WebElement getLblDataCentre() {
		return lblDataCentre;
	}

	public WebElement getLblDeviceChannelReportResult() {
		return lblDeviceChannelReportResult;
	}

	public WebElement getLblAuthenticationType() {
		return lblAuthenticationType;
	}

	public WebElement getLblStatus() {
		return lblStatus;
	}

	public WebElement getLblMddReportHeader1() {
		return lblMddReportHeader1;
	}

	public WebElement getLblMddReportHeader2() {
		return lblMddReportHeader2;
	}

	public WebElement getLblTotalNumberTranINR() {
		return lblTotalNumberTranINR;
	}

	public WebElement getLblTotalAmountINR() {
		return lblTotalAmountINR;
	}

	public WebElement getLblAvgAmountSpendINR() {
		return lblAvgAmountSpendINR;
	}

	public WebElement getLblAuthRate() {
		return lblAuthRate;
	}

	public WebElement getLblTotalNumberTranAllCur() {
		return lblTotalNumberTranAllCur;
	}

	public WebElement getLblTotalNumberTranNonINR() {
		return lblTotalNumberTranNonINR;
	}

	public WebElement getLblTotalAmountNonINR() {
		return lblTotalAmountNonINR;
	}

	public WebElement getLblCardUsageBreakDown() {
		return lblCardUsageBreakDown;
	}

	public WebElement getLblFrictionlessTran() {
		return lblFrictionlessTran;
	}

	public WebElement getLblChallengedTran() {
		return lblChallengedTran;
	}

	public WebElement getLblDeclinedTran() {
		return lblDeclinedTran;
	}

	public WebElement getLblFailureTran() {
		return lblFailureTran;
	}

	public WebElement getLblAcsHighlight() {
		return lblAcsHighlight;
	}

	public WebElement getLblInsight() {
		return lblInsight;
	}

	public WebElement getLblTransactionTrends() {
		return lblTransactionTrends;
	}

	public WebElement getSelectLanguageDropdown() {
		return selectLanguageDropdown;
	}

	public void setSelectLanguageDropdown(WebElement selectLanguageDropdown) {
		this.selectLanguageDropdown = selectLanguageDropdown;
	}
}

package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OtpDetailDuringInfligtTran {

	public WebDriver driver;

	public OtpDetailDuringInfligtTran(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[text()='Otp Usage Report']")
	private WebElement otpUsageReportSideLink;

	@FindBy(xpath = "//input[@id='root_CardNumber']")
	private WebElement otpUsageCardNumber;

	@FindBy(xpath = "//a[@data-tip='Search/Refresh']")
	private WebElement otpUsageSearchButton;

	@FindBy(xpath = "//th[text()='ACS Trans. ID']/../../following::tbody/tr/td[1]")
	private WebElement otpUsageAcsTxnIdText;

	@FindBy(xpath = "//th[contains(text(),'Email ID ')]/../../following::tbody/tr/td[2]")
	private WebElement otpUsageEmailIdText;

	@FindBy(xpath = "//th[contains(text(),'Mobile Number')]/../../following::tbody/tr/td[3]")
	private WebElement otpUsageMobileNumberText;

	@FindBy(xpath = "//th[contains(text(),'Maximum allowed')]/../../following::tbody/tr/td[4]")
	private WebElement otpUsageMaximumOtpAllowedText;

	@FindBy(xpath = "//th[contains(text(),'Resend OTP Count')]/../../following::tbody/tr/td[5]")
	private WebElement otpUsageResendOtpCountText;

	@FindBy(xpath = "//th[contains(text(),'Invalid OTP Attempts')]/../../following::tbody/tr/td[6]")
	private WebElement otpUsageInvalidOtpAttemptsText;

	@FindBy(xpath = "//th[contains(text(),'Last OTP Status')]/../../following::tbody/tr/td[7]")
	private WebElement otpUsageLastOTPStatusText;

	@FindBy(xpath = "//td[contains(text(),'Search did not find any inflight transactions with')]")
	private WebElement otpUsageBlankInflightTxnMessage;

	@FindBy(xpath = "//*[contains(@class,'otpValue_Automate') or @id='otpValue']")
	private WebElement otpTextField;

	@FindBy(xpath = "//*[contains(@class,'reSendOtp_Automate') or contains(@href,'resend_otp')or @ id='otpResend' or @id='reSend']")
	private WebElement otpResendButton;

	@FindBy(xpath = "//*[contains(@class,'submit_Automate') or @id='submitBtn']")
	private WebElement otpSubmitButton;

	@FindBy(xpath = "//*[contains(text(),'CANCEL')or @id='cancelBtn' or @id='otpReset']")
	private WebElement otpCancelButton;

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getOtpTextField() {
		return otpTextField;
	}

	public WebElement getOtpResendButton() {
		return otpResendButton;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpUsageReportSideLink() {
		return otpUsageReportSideLink;
	}

	public WebElement getOtpUsageCardNumber() {
		return otpUsageCardNumber;
	}

	public WebElement getOtpUsageSearchButton() {
		return otpUsageSearchButton;
	}

	public WebElement getOtpUsageAcsTxnIdText() {
		return otpUsageAcsTxnIdText;
	}

	public WebElement getOtpUsageEmailIdText() {
		return otpUsageEmailIdText;
	}

	public WebElement getOtpUsageMobileNumberText() {
		return otpUsageMobileNumberText;
	}

	public WebElement getOtpUsageMaximumOtpAllowedText() {
		return otpUsageMaximumOtpAllowedText;
	}

	public WebElement getOtpUsageResendOtpCountText() {
		return otpUsageResendOtpCountText;
	}

	public WebElement getOtpUsageInvalidOtpAttemptsText() {
		return otpUsageInvalidOtpAttemptsText;
	}

	public WebElement getOtpUsageLastOTPStatusText() {
		return otpUsageLastOTPStatusText;
	}

	public WebElement getOtpUsageBlankInflightTxnMessage() {
		return otpUsageBlankInflightTxnMessage;
	}

}

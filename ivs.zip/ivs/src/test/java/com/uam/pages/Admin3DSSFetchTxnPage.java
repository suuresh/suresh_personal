package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Admin3DSSFetchTxnPage {

	public WebDriver driver;

	public Admin3DSSFetchTxnPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath = "//div[@class='level']//div[3]//*[local-name()='svg']")
	private WebElement threedssCalenderIcon;
		
	@FindBy(xpath = "//div[@class='drp-calendar left']//select[@class='hourselect']")
	private WebElement threedsLeftHourSelect;

	@FindBy(xpath = "//a[contains(@class,'icon-link')]//*[contains(@class,'btn-icon')]")
	private WebElement threedssAdevanceSearchButton;

	@FindBy(xpath = "//button[contains(@class,'applyBtn btn btn-sm button primary-btn padding-btn')]")
	private WebElement threedssDatePickerApplyButton;

	@FindBy(xpath = "//*[@class='btn-icon']")
	private WebElement threedssAdvacedSearchButton;

	@FindBy(name = "card_number")
	private WebElement threedsssCardNumberTextField;
	
	@FindBy(name = "threeds_server_txn_id")
	private WebElement threedssTxnIdTextField;

	@FindBy(xpath = "//span[contains(text(),'Select Transaction Status')]")
	private WebElement threedssTransactionStatusField;

	@FindBy(xpath = "//label[contains(text(),'Failure')]")
	private WebElement threedssTransactionStatusFailure;

	@FindBy(xpath = "//label[contains(text(),'Rejected')]")
	private WebElement threedssTransactionStatusRejected;

	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	private WebElement applyButton;

	@FindBy(xpath = "//a[contains(text(),'Fetch Report')]")
	private WebElement fetchReportButton;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]//div[1]//div[3]")
	private WebElement txnRecordMerchantName;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]//div[1]//div[4]")
	private WebElement txnRecordTxnAmount;
					    
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]//div[1]//div[6]")
	private WebElement txnRecordProtocalVersioin;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]//div[1]//div[8]")
	private WebElement txnRecordAuthType;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]")
	private WebElement txnFirstRecordInTheList;

	// Detail page web Elements.

	@FindBy(xpath = "//div[span[text()='Card Number']]/div/span")
	private WebElement threedsstxnDetailPageCardNumberValue;

	@FindBy(xpath = "//div[span[text()='Merchant Name']]/div/span")
	private WebElement threedsstxnDetailPageMerchantNameValue;

	@FindBy(xpath = "//div[span[text()='Card Type']]/div/span")
	private WebElement threedsstxnDetailPageCardTypeValue;

	@FindBy(xpath = "//div[span[text()='Acquirer Bin']]/div/span")
	private WebElement threedsstxnDetailPageAcquirerBinValue;

	@FindBy(xpath = "//div[span[text()='Transaction Amount']]/div/span")
	private WebElement threedsstxnDetailPageTransactionAmountValue;

	@FindBy(xpath = "//div[span[text()='Device Channel']]/div/span")
	private WebElement threedsstxnDetailPageDeviceChannelValue;

	@FindBy(xpath = "//div[span[text()='CAVV']]/div/span")
	private WebElement threedsstxnDetailPageCAVVValue;

	@FindBy(xpath = "//div[span[text()='AAV']]/div/span")
	private WebElement threedsstxnDetailPageAAVValue;

	public WebElement getThreedssCalenderIcon() {
		return threedssCalenderIcon;
	}

	public WebElement getThreedsLeftHourSelect() {
		return threedsLeftHourSelect;
	}

	public WebElement getTxnFirstRecordInTheList() {
		return txnFirstRecordInTheList;
	}

	public WebElement getThreedsstxnDetailPageCardNumberValue() {
		return threedsstxnDetailPageCardNumberValue;
	}

	public WebElement getThreedsstxnDetailPageMerchantNameValue() {
		return threedsstxnDetailPageMerchantNameValue;
	}

	public WebElement getThreedsstxnDetailPageCardTypeValue() {
		return threedsstxnDetailPageCardTypeValue;
	}

	public WebElement getThreedsstxnDetailPageAcquirerBinValue() {
		return threedsstxnDetailPageAcquirerBinValue;
	}

	public WebElement getThreedsstxnDetailPageTransactionAmountValue() {
		return threedsstxnDetailPageTransactionAmountValue;
	}

	public WebElement getThreedsstxnDetailPageDeviceChannelValue() {
		return threedsstxnDetailPageDeviceChannelValue;
	}

	public WebElement getThreedsstxnDetailPageCAVVValue() {
		return threedsstxnDetailPageCAVVValue;
	}

	public WebElement getThreedsstxnDetailPageAAVValue() {
		return threedsstxnDetailPageAAVValue;
	}

	public WebElement getThreedssAdevanceSearchButton() {
		return threedssAdevanceSearchButton;
	}

	public WebElement getThreedssDatePickerApplyButton() {
		return threedssDatePickerApplyButton;
	}

	public WebElement getThreedssAdvacedSearchButton() {
		return threedssAdvacedSearchButton;
	}

	public WebElement getThreedsssCardNumberTextField() {
		return threedsssCardNumberTextField;
	}
	
	public WebElement getThreedssTxnIdTextField() {
		return threedssTxnIdTextField;
	}

	public WebElement getThreedssTransactionStatusField() {
		return threedssTransactionStatusField;
	}

	public WebElement getThreedssTransactionStatusFailure() {
		return threedssTransactionStatusFailure;
	}

	public WebElement getThreedssTransactionStatusRejected() {
		return threedssTransactionStatusRejected;
	}

	public WebElement getApplyButton() {
		return applyButton;
	}

	public WebElement getFetchReportButton() {
		return fetchReportButton;
	}

	public WebElement getTxnRecordMerchantName() {
		return txnRecordMerchantName;
	}

	public WebElement getTxnRecordTxnAmount() {
		return txnRecordTxnAmount;
	}

	public WebElement getTxnRecordProtocalVersioin() {
		return txnRecordProtocalVersioin;
	}

	public WebElement getTxnRecordAuthType() {
		return txnRecordAuthType;
	}

}

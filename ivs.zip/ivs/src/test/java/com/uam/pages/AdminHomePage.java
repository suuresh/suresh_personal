package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.acs.libraries.Config;

public class AdminHomePage {

	public WebDriver driver;

	public AdminHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//img[@class='brand__logo']")
	private WebElement projectLogo;

	@FindBy(xpath = "//div[@class='brand__name']")
	private WebElement headerAccosaProjectName;

	@FindBy(xpath = "//span[@class='dropdown-header-item']")
	private WebElement headerBankDropDown;

	@FindBy(xpath = "//select[@class='languageDropdown Select-sc-1sm01tk-0 wIjFa']")
	private WebElement headerLanguageDropDown;

	@FindBy(xpath = "//div[@class='dropdown']//*[@class='dropdown__icon display-block']")
	private WebElement headerUserProfileDropDown;

	@FindBy(xpath = "//h4[@class='page__title']")
	private WebElement HomepageWelcomeMessageTitle;

	@FindBy(xpath = "//h5[@class='page__title']	")
	private WebElement HomepageWelcomeMessage;

	@FindBy(xpath = "//span[contains(@class,'dropdown-header-item')]")
	private WebElement dropDownHeader;

	@FindBy(xpath = "//div[contains(@class,'is-active')]//*[contains(@class,'dropdown__icon display-block')]")
	private WebElement dropDownHeaderIcon;

//	@FindBy(xpath = "//a[2]/span[text()='National Bank']")
//	private WebElement acsIssuerBankNameLinkInDropDown;

	@FindBy(xpath = "//input[contains(@placeholder,'Search by Name and Login ID')]")
	private WebElement searchByBankNameTextField;

//	@FindBy(xpath = "//span[contains(text(),'"+Config.BASE_UAM_ACQUIRER_BANK_NAME+"')]")
//	private WebElement threeDSAcquirerBankNameLinkInDropDown;

	@FindBy(xpath = "//span[contains(text(),'" + Config.BASE_UAM_WIBMO_BANK_NAME + "')]")
	private WebElement acsWibmoBankNameLinkInDropDown;

	// ACS

	@FindBy(xpath = "//div[contains(text(),'ACS')]")
	private WebElement sideBarLinkACS;

	@FindBy(xpath = "//span[contains(text(), 'Reports and Dashboards')]")
	private WebElement acsReportsAndDashboard;

	// ACS report and dashboard
	@FindBy(xpath = "//li[contains(text(),'ACS Dashboard')]")
	private WebElement acsDashboard;

	@FindBy(xpath = "//li[contains(text(), 'Transaction Report')]")
	private WebElement acsTransactionReportLink;
	
	@FindBy(xpath = "//li[contains(text(), 'Alerts Report')]")
	private WebElement acsAlertsReportLink;

	@FindBy(xpath = "//li[contains(text(),'FETCH TRANSACTION REPORT')]")
	private WebElement acsFetchTransactionReportLink;

	// rba link
	@FindBy(xpath = "//span[contains(text(),'Rba')]")
	private WebElement rbaLink;

	@FindBy(xpath = "//li[contains(text(),'RBA CONFIGURATION')]")
	private WebElement rbaconfigurationLink;

	@FindBy(xpath = "(//span[text()='Configurations'])[1]")
	private WebElement configurationsLink;

	@FindBy(xpath = "//li[text()='Onboarding Banks']")
	private WebElement onboardingBanksLink;

	// Operation link
	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	private WebElement operationsLink;
	
	@FindBy(xpath = "//li[contains(text(),'Add a Card')]")
	private WebElement addACardLink;

	@FindBy(xpath = "//li[text()='Manage Blocked Cards']")
	private WebElement manageBlockedCardsLink;
	
	@FindBy(xpath = "//li[text()='Manage Blocked VC Users']")
	private WebElement manageBlockedVCCardsLink;
	
	@FindBy(xpath = "//li[text()='MANAGE CARDHOLDER DETAILS']")
	private WebElement manageCardholderDetailsLink;
	
	@FindBy(xpath = "//li[text()='Customer Data Upload']")
	private WebElement customerDataUploadLink;
	
	@FindBy(xpath = "//li[text()='Manage Resources']")
	private WebElement manageResourcesLink;
	
	@FindBy(xpath = "//li[text()='Manage Cluster Configurations']")
	private WebElement manageClusterConfigurationsLink;

	// 3DSS

	@FindBy(xpath = "//div[contains(text(),'3DSS')]")
	private WebElement sideBarLink3DSS;

	@FindBy(xpath = "//li[@class='sidebar__item active']//span[contains(text(),'Reports and Dashboards')]")
	private WebElement threedssReportsAndDashboard;

	@FindBy(xpath = "//li[contains(@class,'submenu__item active')]//li[contains(@class,'')][contains(text(),'Transaction Report')]")
	private WebElement threedssFetchTransactionReportLink;

	// UAM

	@FindBy(xpath = "//div[contains(text(),'UAM')]")
	private WebElement sideBarLinkUAM;

	@FindBy(xpath = "//span[contains(text(),'User Management')]")
	private WebElement userManagementLink;

	@FindBy(xpath = "//span[contains(text(),'Manage Banks')]")
	private WebElement manageBankLink;

	@FindBy(xpath = "//span[contains(text(),'Manage Groups')]")
	private WebElement manageGroupsLink;

	@FindBy(xpath = "//span[contains(text(),'Manage Users')]")
	private WebElement manageUsersLink;

	@FindBy(xpath = "//div[@class='footer__copyright']")
	private WebElement footerCopyRightText;

	@FindBy(xpath = "//a[text()='NEW ONBOARDING']")
	private WebElement newOnboardingButton;

	// New script added on 28th Dec

	public WebElement getSearchByBankNameTextField() {
		return searchByBankNameTextField;
	}

	public WebElement getAcsWibmoBankNameLinkInDropDown() {
		return acsWibmoBankNameLinkInDropDown;
	}

	public WebElement getProjectLogo() {
		return projectLogo;
	}

	public WebElement getHeaderAccosaProjectName() {
		return headerAccosaProjectName;
	}

	public WebElement getHeaderBankDropDown() {
		return headerBankDropDown;
	}

	public WebElement getHeaderLanguageDropDown() {
		return headerLanguageDropDown;
	}

	public WebElement getHeaderUserProfileDropDown() {
		return headerUserProfileDropDown;
	}

	public WebElement getHomepageWelcomeMessageTitle() {
		return HomepageWelcomeMessageTitle;
	}

	public WebElement getHomepageWelcomeMessage() {
		return HomepageWelcomeMessage;
	}

	public WebElement getSideBarLink3DSS() {
		return sideBarLink3DSS;
	}

	public WebElement getThreedssReportsAndDashboard() {
		return threedssReportsAndDashboard;
	}

	public WebElement getThreedssFetchTransactionReportLink() {
		return threedssFetchTransactionReportLink;
	}

	public WebElement getSideBarLinkUAM() {
		return sideBarLinkUAM;
	}

	public WebElement getAcsReportsAndDashboard() {
		return acsReportsAndDashboard;
	}

	public WebElement getUserManagementLink() {
		return userManagementLink;
	}

	public WebElement getManageBankLink() {
		return manageBankLink;
	}

	public WebElement getManageGroupsLink() {
		return manageGroupsLink;
	}

	public WebElement getManageUsersLink() {
		return manageUsersLink;
	}

	public WebElement getDropDownHeader() {
		return dropDownHeader;
	}

	public WebElement getDropDownHeaderIcon() {
		return dropDownHeaderIcon;
	}

	public WebElement getRbaLink() {
		return rbaLink;
	}

	public WebElement getRbaconfigurationLink() {
		return rbaconfigurationLink;
	}

	public WebElement getSideBarLinkACS() {
		return sideBarLinkACS;
	}

	public WebElement getAcsDashboard() {
		return acsDashboard;
	}

	public WebElement getAcsTransactionReportLink() {
		return acsTransactionReportLink;
	}
	
	public WebElement getAcsAlertsReportLink() {
		return acsAlertsReportLink;
	}

	public WebElement getAcsFetchTransactionReportLink() {
		return acsFetchTransactionReportLink;
	}

	public WebElement getFooterCopyRightText() {
		return footerCopyRightText;
	}

	public WebElement getOnboardingBanksLink() {
		return onboardingBanksLink;
	}

	public WebElement getConfigurationsLink() {
		return configurationsLink;
	}

	public WebElement getNewOnboardingButton() {
		return newOnboardingButton;
	}

	public WebElement getOperationsLink() {
		return operationsLink;
	}
	
	public WebElement getAddACardLink() {
		return addACardLink;
	}

	public WebElement getManageBlockedCardsLink() {
		return manageBlockedCardsLink;
	}
	public WebElement getManageBlockedVCCardsLink() {
		return manageBlockedVCCardsLink;
	}

	public WebElement getManageCardholderDetailsLink() {
		return manageCardholderDetailsLink;
	}

	public WebElement getManageClusterConfigurationsLink() {
		return manageClusterConfigurationsLink;
	}

	public WebElement getCustomerDataUploadLink() {
		return customerDataUploadLink;
	}

	public WebElement getManageResourcesLink() {
		return manageResourcesLink;
	}

}

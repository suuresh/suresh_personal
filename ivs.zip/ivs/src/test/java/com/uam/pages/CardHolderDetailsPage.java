package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CardHolderDetailsPage {

	public WebDriver driver;

	public CardHolderDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[text()='Manage Cardholder Details']")
	private WebElement manageCardHolderDetailsLink;

	// View card details page
	@FindBy(xpath = "//input[@id='root_MobileNumber']")	
	private WebElement mobileNumberTextfield;

	@FindBy(id = "root_CardNumber")
	private WebElement cardNumberTextfield;

	@FindBy(xpath = "//a[text()='Search']")
	private WebElement searchButton;

	// Edit card details page

	@FindBy(id = "root_PAN")
	private WebElement panTextfield;

	@FindBy(id = "root_Expiry")
	private WebElement expiryTextfield;

	@FindBy(xpath = "//div[text()='Mobile Code']/following::div/div/a[@class='button dropdown-btn is-fullwidth  ']")
	private WebElement mobileCodeDropdown;

	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement mobileCodeSearchField;

	@FindBy(xpath = "//div[text()='Mobile Code']//following::label[@class='radio-label']")
	private WebElement firstMobileCodelist;

	@FindBy(id = "root_Mobile")
	private WebElement editMobileTextfield;

	@FindBy(id = "root_Email")
	private WebElement editEmailTextfield;

	@FindBy(xpath = "//a[text()='Save Changes']")
	private WebElement saveChangesButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement cancelButton;

	// Create Card Details page elements

	//@FindBy(xpath = "//a[@class='button primary-btn is-fullwidth  ']")
	@FindBy(xpath = "//a[normalize-space()='Create']")
	private WebElement createCardDetailsPlusButton;

	@FindBy(xpath = "//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement createCardDetailsCancelButton;

	@FindBy(xpath = "//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement createCardDetailsSaveButton;

	//@FindBy(xpath = "//input[@id='root_AccountNumber']")
	@FindBy(xpath = "//input[@name='card_number']")
	private WebElement createCardTextField;

	@FindBy(xpath = "//a[@class='button button dropdown-btn']")
	private WebElement createCardDetailsMobileCodeDropDown;

	//@FindBy(xpath = "//input[@class='input secondary-input is-marginless']")
	@FindBy(xpath = "//input[@id='myInput']")
	private WebElement createCardDetailsMobileCountryCodeTextField;

	@FindBy(xpath = "//label[contains(text(),'+91')]")
	private WebElement createCardDetailsMobileCountryCodeRadioButton;

	//@FindBy(xpath = "//input[@id='root_Mobile']")
	@FindBy(xpath = "//input[@name='mobile_number']")
	private WebElement createCardDetailsMobileNumberTextField;

	//@FindBy(xpath = "//input[@id='root_Email']")
	@FindBy(xpath ="//input[@name='email_id']")
	private WebElement createCardDetailsEmailTextField;
	
	@FindBy(xpath = "//*[@id='app']/div/div[2]/div[2]/div[2]/div[1]/div[2]/div/div/form/div[1]/li[1]/div")
	private WebElement createCardDetailsMobileCodeRequiredErrorTxtMsg;
					
	
	@FindBy(xpath = "//*[@id='app']/div/div[2]/div[2]/div[2]/div[1]/div[2]/div/div/form/div[1]/li[2]/div")
	private WebElement createCardDetailsMobileRequiredErrorTxtMsg;
	
	@FindBy(xpath = "//*[@id='app']/div/div[2]/div[2]/div[2]/div[1]/div[2]/div/div/form/div[1]/li/div")
	private WebElement createCardDetailsMobileOnlyRequiredErrorTxtMsg;
					  
	@FindBy(xpath = "//*[@id='app']/div/div[2]/div[2]/div[2]/div[1]/div[2]/div/div/form/div[1]/li[3]/div")
	private WebElement createCardDetailsAccountNumberRequiredErrorTxtMsg;
	
	@FindBy(xpath = "//*[@id='app']/div/div[2]/div[2]/div[2]/div[1]/div[2]/div/div/form/div[1]/li/div")
	private WebElement createCardDetailsMobileNumberLengthErrorTxtMsg;
	
	
	
	public WebElement getCreateCardDetailsMobileOnlyRequiredErrorTxtMsg() {
		return createCardDetailsMobileOnlyRequiredErrorTxtMsg;
	}

	public WebElement getCreateCardDetailsMobileCodeRequiredErrorTxtMsg() {
		return createCardDetailsMobileCodeRequiredErrorTxtMsg;
	}

	public WebElement getCreateCardDetailsMobileRequiredErrorTxtMsg() {
		return createCardDetailsMobileRequiredErrorTxtMsg;
	}

	public WebElement getCreateCardDetailsAccountNumberRequiredErrorTxtMsg() {
		return createCardDetailsAccountNumberRequiredErrorTxtMsg;
	}

	public WebElement getCreateCardDetailsMobileNumberLengthErrorTxtMsg() {
		return createCardDetailsMobileNumberLengthErrorTxtMsg;
	}
		
	public WebElement getCreateCardDetailsPlusButton() {
		return createCardDetailsPlusButton;
	}

	public WebElement getCreateCardDetailsCancelButton() {
		return createCardDetailsCancelButton;
	}

	public WebElement getCreateCardDetailsSaveButton() {
		return createCardDetailsSaveButton;
	}

	public WebElement getCreateCardTextField() {
		return createCardTextField;
	}

	public WebElement getCreateCardDetailsMobileCodeDropDown() {
		return createCardDetailsMobileCodeDropDown;
	}

	public WebElement getCreateCardDetailsMobileCountryCodeTextField() {
		return createCardDetailsMobileCountryCodeTextField;
	}

	public WebElement getCreateCardDetailsMobileCountryCodeRadioButton() {
		return createCardDetailsMobileCountryCodeRadioButton;
	}

	public WebElement getCreateCardDetailsMobileNumberTextField() {
		return createCardDetailsMobileNumberTextField;
	}

	public WebElement getCreateCardDetailsEmailTextField() {
		return createCardDetailsEmailTextField;
	}

	public WebElement getMobileNumberTextfield() {
		return mobileNumberTextfield;
	}

	public WebElement getCardNumberTextfield() {
		return cardNumberTextfield;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getPanTextfield() {
		return panTextfield;
	}

	public WebElement getExpiryTextfield() {
		return expiryTextfield;
	}

	public WebElement getMobileCodeDropdown() {
		return mobileCodeDropdown;
	}

	public WebElement getMobileCodeSearchField() {
		return mobileCodeSearchField;
	}

	public WebElement getFirstMobileCodelist() {
		return firstMobileCodelist;
	}

	public WebElement getEditMobileTextfield() {
		return editMobileTextfield;
	}

	public WebElement getEditEmailTextfield() {
		return editEmailTextfield;
	}

	public WebElement getSaveChangesButton() {
		return saveChangesButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getManageCardHolderDetailsLink() {
		return manageCardHolderDetailsLink;
	}

}

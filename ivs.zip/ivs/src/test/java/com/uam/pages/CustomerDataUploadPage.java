package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.acs.testcases.ACSInitialSetUp;


public class CustomerDataUploadPage extends ACSInitialSetUp{

	public WebDriver driver;
    
	public CustomerDataUploadPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//li[contains(text(),'Customer Data Upload Header')]")
	private WebElement customerDatUploadHeaderLinkText;
		
	@FindBy(xpath="//li[text()='Customer Data Upload']")
	private WebElement customerDatUploadLinnkText;
	
	//Elements in the upload file page
	@FindBy(xpath="//a[text()='Upload File']")
	private WebElement uploadFilePlusButton;
	
	@FindBy(xpath="//input[@id='fileInfo']")
	private WebElement uploadFileTextBox;
	
	@FindBy(xpath="//div[contains(text(),'Please upload a vaild encrypted PGP or CSV file.')]")
	private WebElement uploadFileFormateValidationMessage;
	
	@FindBy(xpath="//a[text()='Cancel']")
	private WebElement uploadFileCancelButton;
	
	@FindBy(xpath="//a[text()='Upload']")
	private WebElement uploadFileUploadButton;
	
	@FindBy(xpath="//div[@class='level-right']/div[@class='options__edit']")
	private WebElement refreshButton;
	
	//Uploaded file 1st record xpaths
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[1])[1]")
	private WebElement jobIdText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[2])[1]")
	private WebElement fileNameText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[3])[1]")
	private WebElement uploadedDateText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[4])[1]")
	private WebElement userText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[5])[1]")
	private WebElement successRecordsText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[6])[1]")
	private WebElement failedRecordsText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[7])[1]")
	private WebElement fileUploadStatusText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[8])[1]")
	private WebElement fileValidationStatusText;
	
	@FindBy(xpath="(//div[text()='File Name']/../following::div[@class='flex-table__body']/div/div[9]//div[@class='options__edit'])[1]")
	private WebElement actionExecuteOrDownload;
	
		
	//Customer Data Upload headers xpath
	@FindBy(xpath="//div[text()='Header Row Required']/div[@class='switch btn on btn-outline-success btn-sm [object Object]']")
	private WebElement headerRowRequiredYesButton;
	
	@FindBy(xpath="//div[text()='Header Row Required']/div[@class='switch btn off btn-outline-danger btn-sm [object Object]']")
	private WebElement headerRowRequiredNoButton;
	
	/*@FindBy(xpath="//label[contains(text(),'Yes')]")
	private WebElement headerRowRequiredYesButton;
	
	@FindBy(xpath="//label[contains(text(),'No')]")
	private WebElement headerRowRequiredNoButton;
	*/
	@FindBy(xpath="//a[text()='Cancel']")
	private WebElement fileUploadConfigCancelButton;
	
	public WebElement getUploadFileFormateValidationMessage() {
		return uploadFileFormateValidationMessage;
	}

	@FindBy(xpath="//a[text()='Save']")
	private WebElement fileUploadConfigSaveButton;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_PH_COUNTRY_CODE']]/div/label[@class='checkbox__lable']")
	private WebElement primaryPhCountryCodeCheckBox;
	
	@FindBy(xpath="//div[div[text()='ACCOUNT_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement accountNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_PH_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement primaryPhNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_EMAIL']]/div/label[@class='checkbox__lable']")
	private WebElement primaryEmailCheckBox;
	
	@FindBy(xpath="//div[div[text()='STATUS']]/div/label[@class='checkbox__lable']")
	private WebElement statusCheckBox;
	
	@FindBy(xpath="//div[div[text()='ATTEMPTS']]/div/label[@class='checkbox__lable']")
	private WebElement attemptsCheckBox;
	
	@FindBy(xpath="//div[div[text()='UPDATED_ON']]/div/label[@class='checkbox__lable']")
	private WebElement updatedOnCheckBox;
	
	@FindBy(xpath="//div[div[text()='CREATED_ON']]/div/label[@class='checkbox__lable']")
	private WebElement createdOnCheckBox;
	
	@FindBy(xpath="//div[div[text()='EXPIRY']]/div/label[@class='checkbox__lable']")
	private WebElement expiryCheckBox;
	
	@FindBy(xpath="//div[div[text()='BATCH_ID']]/div/label[@class='checkbox__lable']")
	private WebElement batchCheckBox;
	
	@FindBy(xpath="//div[div[text()='SOURCE']]/div/label[@class='checkbox__lable']")
	private WebElement sourceCheckBox;
	
	@FindBy(xpath="//div[div[text()='ACCOUNT_IDENTIFIER']]/div/label[@class='checkbox__lable']")
	private WebElement accountIdentifierCheckBox;
	
	@FindBy(xpath="//div[div[text()='LOGIN_ID']]/div/label[@class='checkbox__lable']")
	private WebElement loginIdCheckBox;
	
	@FindBy(xpath="//div[div[text()='VALID_FROM']]/div/label[@class='checkbox__lable']")
	private WebElement validFromCheckBox;
	
	@FindBy(xpath="//div[div[text()='DOB']]/div/label[@class='checkbox__lable']")
	private WebElement dobCheckBox;
	
	@FindBy(xpath="//div[div[text()='CARD_TYPE']]/div/label[@class='checkbox__lable']")
	private WebElement cardTypeCheckBox;
	
	@FindBy(xpath="//div[div[text()='NAME_ON_CARD']]/div/label[@class='checkbox__lable']")
	private WebElement nameOnCardCheckBox;
	
	@FindBy(xpath="//div[div[text()='EXPIRY_MODE']]/div/label[@class='checkbox__lable']")
	private WebElement expiryModeCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_PH_NUMBER_ID']]/div/label[@class='checkbox__lable']")
	private WebElement primaryPhNumberIdCheckBox;
	
	@FindBy(xpath="//div[div[text()='USER_ID']]/div/label[@class='checkbox__lable']")
	private WebElement userIdCheckBox;
	
	@FindBy(xpath="//div[div[text()='SECONDARY_PH_COUNTRY_CODE']]/div/label[@class='checkbox__lable']")
	private WebElement secondaryPhCountryCodeCheckBox;
	
	@FindBy(xpath="//div[div[text()='SECONDARY_PH_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement secodaryPhNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='TEMP_PH_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement tempPhNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='SECONDARY_EMAIL']]/div/label[@class='checkbox__lable']")
	private WebElement secondaryEmailCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_ACCOUNT_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement primaryAccountNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_ACC_PH_COUNTRY_CODE']]/div/label[@class='checkbox__lable']")
	private WebElement primaryAccCountryCodeCheckBox;
	
	@FindBy(xpath="//div[div[text()='PRIMARY_ACC_PH_NUMBER']]/div/label[@class='checkbox__lable']")
	private WebElement primaryAccPhNumberCheckBox;
	
	@FindBy(xpath="//div[div[text()='LANG_PREFERENCE']]/div/label[@class='checkbox__lable']")
	private WebElement langPreferenceCheckBox;
	
	@FindBy(xpath="//div[div[text()='CREATED_BY']]/div/label[@class='checkbox__lable']")
	private WebElement createdByCheckBox;
	
	@FindBy(xpath="//div[div[text()='UPDATED_BY']]/div/label[@class='checkbox__lable']")
	private WebElement updatedByCheckBox;
	
	@FindBy(xpath="//div[div[text()='BANKID']]/div/label[@class='checkbox__lable']")
	private WebElement bankIDCheckBox;
	
	
	
	public WebElement getRefreshButton() {
		return refreshButton;
	}

	public WebElement getHeaderRowRequiredYesButton() {
		return headerRowRequiredYesButton;
	}

	public WebElement getHeaderRowRequiredNoButton() {
		return headerRowRequiredNoButton;
	}

	public WebElement getCustomerDatUploadHeaderLinkText() {
		return customerDatUploadHeaderLinkText;
	}

	public WebElement getCustomerDatUploadLinnkText() {
		return customerDatUploadLinnkText;
	}

	public WebElement getUploadFilePlusButton() {
		return uploadFilePlusButton;
	}

	public WebElement getUploadFileTextBox() {
		return uploadFileTextBox;
	}

	public WebElement getUploadFileCancelButton() {
		return uploadFileCancelButton;
	}

	public WebElement getUploadFileUploadButton() {
		return uploadFileUploadButton;
	}

	public WebElement getJobIdText() {
		return jobIdText;
	}

	public WebElement getFileNameText() {
		return fileNameText;
	}

	public WebElement getUploadedDateText() {
		return uploadedDateText;
	}

	public WebElement getUserText() {
		return userText;
	}

	public WebElement getSuccessRecordsText() {
		return successRecordsText;
	}

	public WebElement getFailedRecordsText() {
		return failedRecordsText;
	}

	public WebElement getFileUploadStatusText() {
		return fileUploadStatusText;
	}

	public WebElement getFileValidationStatusText() {
		return fileValidationStatusText;
	}

	public WebElement getActionExecuteOrDownload() {
		return actionExecuteOrDownload;
	}

	public WebElement getFileUploadConfigCancelButton() {
		return fileUploadConfigCancelButton;
	}

	public WebElement getFileUploadConfigSaveButton() {
		return fileUploadConfigSaveButton;
	}

	public WebElement getPrimaryPhCountryCodeCheckBox() {
		return primaryPhCountryCodeCheckBox;
	}

	public WebElement getAccountNumberCheckBox() {
		return accountNumberCheckBox;
	}

	public WebElement getPrimaryPhNumberCheckBox() {
		return primaryPhNumberCheckBox;
	}

	public WebElement getPrimaryEmailCheckBox() {
		return primaryEmailCheckBox;
	}

	public WebElement getStatusCheckBox() {
		return statusCheckBox;
	}

	public WebElement getAttemptsCheckBox() {
		return attemptsCheckBox;
	}

	public WebElement getUpdatedOnCheckBox() {
		return updatedOnCheckBox;
	}

	public WebElement getCreatedOnCheckBox() {
		return createdOnCheckBox;
	}

	public WebElement getExpiryCheckBox() {
		return expiryCheckBox;
	}

	public WebElement getBatchCheckBox() {
		return batchCheckBox;
	}

	public WebElement getSourceCheckBox() {
		return sourceCheckBox;
	}

	public WebElement getAccountIdentifierCheckBox() {
		return accountIdentifierCheckBox;
	}

	public WebElement getLoginIdCheckBox() {
		return loginIdCheckBox;
	}

	public WebElement getValidFromCheckBox() {
		return validFromCheckBox;
	}

	public WebElement getDobCheckBox() {
		return dobCheckBox;
	}

	public WebElement getCardTypeCheckBox() {
		return cardTypeCheckBox;
	}

	public WebElement getNameOnCardCheckBox() {
		return nameOnCardCheckBox;
	}

	public WebElement getExpiryModeCheckBox() {
		return expiryModeCheckBox;
	}

	public WebElement getPrimaryPhNumberIdCheckBox() {
		return primaryPhNumberIdCheckBox;
	}

	public WebElement getUserIdCheckBox() {
		return userIdCheckBox;
	}

	public WebElement getSecondaryPhCountryCodeCheckBox() {
		return secondaryPhCountryCodeCheckBox;
	}

	public WebElement getSecodaryPhNumberCheckBox() {
		return secodaryPhNumberCheckBox;
	}

	public WebElement getTempPhNumberCheckBox() {
		return tempPhNumberCheckBox;
	}

	public WebElement getSecondaryEmailCheckBox() {
		return secondaryEmailCheckBox;
	}

	public WebElement getPrimaryAccountNumberCheckBox() {
		return primaryAccountNumberCheckBox;
	}

	public WebElement getPrimaryAccCountryCodeCheckBox() {
		return primaryAccCountryCodeCheckBox;
	}

	public WebElement getPrimaryAccPhNumberCheckBox() {
		return primaryAccPhNumberCheckBox;
	}

	public WebElement getLangPreferenceCheckBox() {
		return langPreferenceCheckBox;
	}

	public WebElement getCreatedByCheckBox() {
		return createdByCheckBox;
	}

	public WebElement getUpdatedByCheckBox() {
		return updatedByCheckBox;
	}

	public WebElement getBankIDCheckBox() {
		return bankIDCheckBox;
	}

	
}

package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageBlockedCardPage {

	public WebDriver driver;

	public ManageBlockedCardPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[contains(text(),'Filtered By:')]")
	private WebElement filteredByDropdown;

	@FindBy(xpath = "//label[@for='SOFTBLOCK']")
	private WebElement filteredByDropdownSoftBlock;
	@FindBy(xpath = "//label[@for='HARDBLOCK']")
	private WebElement filteredByDropdownHardBlock;
	@FindBy(xpath = "//label[@for='HOTLIST']")
	private WebElement filteredByDropdownHotList;

	@FindBy(xpath = "//input[@placeholder='Search by Card Number']")
	private WebElement searchBox;

// Blocking the card
	@FindBy(xpath = "//a[text()='Block Card']")
	private WebElement blockCardPlusButton;

	@FindBy(xpath = "//input[@placeholder='Card Number']")
	private WebElement cardNumberTextField;

	@FindBy(xpath = "//div[text()='Status']/following::div/div/a")
	private WebElement statusDropdown;

	@FindBy(xpath = "//div[text()='Status']/following::div/div/following::div/div/div/label[text()='SOFTBLOCK']")
	private WebElement softBlockDropdownlist;

	@FindBy(xpath = "//div[text()='Status']/following::div/div/following::div/div/div/label[text()='HOTLIST']")
	private WebElement hotListDropdownList;

	@FindBy(xpath = "//div[text()='Status']/following::div/div/following::div/div/div/label[text()='HARDBLOCK']")
	private WebElement hardBlockDropdownList;

	@FindBy(xpath = "//label[text()='Comments']/following::div/input[@placeholder='Comment']")
	private WebElement commentTextField;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement blockingCard_CancelButton;

	@FindBy(xpath = "//a[text()='Save Changes']")
	private WebElement blockingCard_SaveButton;

	// Unblocking a card

	@FindBy(xpath = "//input[@id='root_CardNumber']")
	private WebElement unBlockingCardNumberTextField;

	@FindBy(xpath = "//input[@id='root_IncurrectAttempts']")
	private WebElement incurrectAttemptsTextField;

	@FindBy(xpath = "//input[@id='root_DateOfBlock']")
	private WebElement dateOfBlockTextField;

	@FindBy(xpath = "//input[@id='root_TimeOfBlock']")
	private WebElement timeOfBlockTextField;

	@FindBy(xpath = "//div[@data-tip='Status']/following::div[a]")
	private WebElement unBlock_StatusDropdown;

	@FindBy(xpath = "//label[text()='ACTIVE']")
	private WebElement unBlock_ActiveStatusDropdownList;

	@FindBy(xpath = "//label[text()='SOFTBLOCK']")
	private WebElement unBlockS_oftBlockStatusDropdownList;

	@FindBy(xpath = "//label[text()='HOTLIST']")
	private WebElement unBlock_HotListStatusDropdownList;

	@FindBy(xpath = "//label[text()='HARDBLOCK']")
	private WebElement unBlock_HardBlockStatusDropdownList;

	@FindBy(xpath = "//input[@id='root_Comments']")
	private WebElement unBlock_CommentTextField;

	@FindBy(xpath = "//a[text()='Save Changes']")
	private WebElement unBlock_SaveChangesButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement unBlock_CancelButton;
	
	//For Advance search
	
	@FindBy(xpath = "//div[text()='Advanced Search']/following::div/a")
	private WebElement advanceSearchPlusSign;
	
	@FindBy(xpath = "//input[@name='card number']")
	private WebElement advSearchCardNumberTextField;
	
	public WebElement getAdvanceSearchPlusSign() {
		return advanceSearchPlusSign;
	}

	public WebElement getAdvSearchCardNumberTextField() {
		return advSearchCardNumberTextField;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	@FindBy(xpath = "//a[text()='Search']")
	private WebElement searchButton;

	public WebElement getFilteredByDropdown() {
		return filteredByDropdown;
	}

	public WebElement getFilteredByDropdownSoftBlock() {
		return filteredByDropdownSoftBlock;
	}

	public WebElement getFilteredByDropdownHardBlock() {
		return filteredByDropdownHardBlock;
	}

	public WebElement getFilteredByDropdownHotList() {
		return filteredByDropdownHotList;
	}

	public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getBlockCardPlusButton() {
		return blockCardPlusButton;
	}

	public WebElement getCardNumberTextField() {
		return cardNumberTextField;
	}

	public WebElement getStatusDropdown() {
		return statusDropdown;
	}

	public WebElement getSoftBlockDropdownlist() {
		return softBlockDropdownlist;
	}

	public WebElement getHotListDropdownList() {
		return hotListDropdownList;
	}

	public WebElement getHardBlockDropdownList() {
		return hardBlockDropdownList;
	}

	public WebElement getCommentTextField() {
		return commentTextField;
	}

	public WebElement getBlockingCard_CancelButton() {
		return blockingCard_CancelButton;
	}

	public WebElement getBlockingCard_SaveButton() {
		return blockingCard_SaveButton;
	}

	public WebElement getUnBlockingCardNumberTextField() {
		return unBlockingCardNumberTextField;
	}

	public WebElement getIncurrectAttemptsTextField() {
		return incurrectAttemptsTextField;
	}

	public WebElement getDateOfBlockTextField() {
		return dateOfBlockTextField;
	}

	public WebElement getTimeOfBlockTextField() {
		return timeOfBlockTextField;
	}

	public WebElement getUnBlock_StatusDropdown() {
		return unBlock_StatusDropdown;
	}

	public WebElement getUnBlock_ActiveStatusDropdownList() {
		return unBlock_ActiveStatusDropdownList;
	}

	public WebElement getUnBlockS_oftBlockStatusDropdownList() {
		return unBlockS_oftBlockStatusDropdownList;
	}

	public WebElement getUnBlock_HotListStatusDropdownList() {
		return unBlock_HotListStatusDropdownList;
	}

	public WebElement getUnBlock_HardBlockStatusDropdownList() {
		return unBlock_HardBlockStatusDropdownList;
	}

	public WebElement getUnBlock_CommentTextField() {
		return unBlock_CommentTextField;
	}

	public WebElement getUnBlock_SaveChangesButton() {
		return unBlock_SaveChangesButton;
	}

	public WebElement getUnBlock_CancelButton() {
		return unBlock_CancelButton;
	}

}

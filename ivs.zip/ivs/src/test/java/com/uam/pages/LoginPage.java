package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.acs.testcases.ACSInitialSetUp;


public class LoginPage extends ACSInitialSetUp{

	public WebDriver driver;
    
	public LoginPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//div[@class='login__header']//img")
	private WebElement projectLogo;
	
	@FindBy(xpath="//div[@class='login__tag']")
	private WebElement accosaProjectName;
	
	@FindBy(xpath="//h3[@class='login__title']")
	private WebElement loginPageHeadingText;
	
	@FindBy(xpath="//p[@class='login__warning']")
	private WebElement loginWarningMessageText;
	
	@FindBy(xpath="//label[contains(text(),'Login ID')]")
	private WebElement loginIdTextBoxLableText;
	
	@FindBy(name="loginId")
	private WebElement loginIDTextField;
	
	@FindBy(xpath="//label[contains(text(),'Password')]")
	private WebElement passwordTextBoxLableText;
	
	@FindBy(name="password")
	private WebElement passwordTextField;
	
	@FindBy(xpath="//a[normalize-space()='Set password']")
	private WebElement linkSetPassword;
	
	@FindBy(xpath="//a[contains(text(),'Forgot Password?')]")
	private WebElement forgotPasswordLinkText;
	
	@FindBy(xpath="//a[contains(text(),'login')]")
	private WebElement loginButton;
	
	@FindBy(xpath="//a[contains(text(),'Set password')]")
	private WebElement setPasswordLinkText;
	
	@FindBy(xpath="//input[@placeholder='Enter 6 Digit OTP']")
	private WebElement otpTextField;
	
	@FindBy(xpath="//input[@placeholder='Enter Captcha']")
	private WebElement enterCaptcha;
	
	@FindBy(xpath="//span[contains(text(),'Submit')]")
	private WebElement otpSubmitButton;
	
	@FindBy(xpath="//a[contains(text(),'Submit')]")
	private WebElement btnOtpSubmit;
	
	@FindBy(xpath="//span[contains(text(),'Cancel')]")
	private WebElement otpCancelButton;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement textSetPassword;
	
	@FindBy(xpath="//input[@name='confirmpassword']")
	private WebElement textConfirmPassword;
	
	@FindBy(xpath="//a[normalize-space()='SUBMIT']")
	private WebElement btnSubmit;
	
	@FindBy(xpath="//a[normalize-space()='Send OTP']")
	private WebElement btnSendOtp;
	
	public void login(String un, String pwd){
		loginIDTextField.sendKeys(un);
		passwordTextField.sendKeys(pwd);
		loginButton.click();
	//	otpTextField.sendKeys(generic.getencyrptedOTPFromUserMasterTable());
	//	otpSubmitButton.click();
	}
	
	public WebElement getProjectLogo() {
		return projectLogo;
	}
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getAccosaProjectName() {
		return accosaProjectName;
	}

	public WebElement getLoginPageHeadingText() {
		return loginPageHeadingText;
	}

	public WebElement getLoginWarningMessageText() {
		return loginWarningMessageText;
	}

	public WebElement getLoginIdTextBoxLableText() {
		return loginIdTextBoxLableText;
	}

	public WebElement getLoginIDTextField() {
		return loginIDTextField;
	}

	public WebElement getPasswordTextBoxLableText() {
		return passwordTextBoxLableText;
	}

	public WebElement getPasswordTextField() {
		return passwordTextField;
	}

	public WebElement getForgotPasswordLinkText() {
		return forgotPasswordLinkText;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public WebElement getSetPasswordLinkText() {
		return setPasswordLinkText;
	}

	public WebElement getOtpTextField() {
		return otpTextField;
	}

	public WebElement getOtpSubmitButton() {
		return otpSubmitButton;
	}

	public WebElement getOtpCancelButton() {
		return otpCancelButton;
	}

	public WebElement getEnterCaptcha() {
		return enterCaptcha;
	}

	public WebElement getBtnSendOtp() {
		return btnSendOtp;
	}

	public WebElement getLinkSetPassword() {
		return linkSetPassword;
	}

	public WebElement getBtnOtpSubmit() {
		return btnOtpSubmit;
	}

	public WebElement getTextSetPassword() {
		return textSetPassword;
	}

	public WebElement getTextConfirmPassword() {
		return textConfirmPassword;
	}

	public WebElement getBtnSubmit() {
		return btnSubmit;
	}
	
}

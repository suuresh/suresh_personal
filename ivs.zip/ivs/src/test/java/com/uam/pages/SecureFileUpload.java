package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecureFileUpload {

	public WebDriver driver;

	public SecureFileUpload(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[contains(text(),'Secure File Upload')]")
	private WebElement SecureFileUploadLink;
	
	@FindBy(xpath = "//h4[contains(text(),'Secure File Generate')]")
	private WebElement SecureFileUploadPageHeading;
	
	@FindBy(xpath = "//h5[contains(text(), 'public key')]")
	private WebElement publickeyHeading;
	
	@FindBy(xpath = "//input[@id='publicKey']")
	private WebElement publicKeyInputField;
	
	@FindBy(xpath = "//h5[contains(text(), 'CSV file')]")
	private WebElement csvFileHeading;
	
	@FindBy(xpath = "//input[@id='file']")
	private WebElement csvFileInputField;
	
	@FindBy(xpath = "//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement CancelButton;
	
	@FindBy(xpath = "//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement GeneratePGPFileButton;
	
	@FindBy(xpath = "//div[contains(text(),'Please upload a vaild public key and CSV file.')]")
	private WebElement ErrorMessageIfNofilesuploaded;
	
	@FindBy(xpath = "//div[contains(text(),'Please upload a vaild text file (.txt extension)')]")
	private WebElement ErrorMessageForPublicFileExtension;
	
	@FindBy(xpath = "//div[contains(text(),'Please verify the public key.')]")
	private WebElement ErrorMessageForInvalidPublicKeyFile;
	
	@FindBy(xpath = "//div[contains(text(),'Please upload a vaild csv file.')]")
	private WebElement ErrorMessageForCsvFileExtention;
			
	@FindBy(xpath = "//div[contains(text(),'Successfully downloaded encrypted .pgp file.')]")
	private WebElement SuccessMessageForGeneratePGPFile;

	public WebElement getSecureFileUploadLink() {
		return SecureFileUploadLink;
	}

	public WebElement getSecureFileUploadPageHeading() {
		return SecureFileUploadPageHeading;
	}

	public WebElement getPublickeyHeading() {
		return publickeyHeading;
	}

	public WebElement getPublicKeyInputField() {
		return publicKeyInputField;
	}

	public WebElement getCsvFileHeading() {
		return csvFileHeading;
	}

	public WebElement getCsvFileInputField() {
		return csvFileInputField;
	}

	public WebElement getCancelButton() {
		return CancelButton;
	}

	public WebElement getGeneratePGPFileButton() {
		return GeneratePGPFileButton;
	}

	public WebElement getErrorMessageIfNofilesuploaded() {
		return ErrorMessageIfNofilesuploaded;
	}

	public WebElement getErrorMessageForPublicFileExtension() {
		return ErrorMessageForPublicFileExtension;
	}

	public WebElement getErrorMessageForInvalidPublicKeyFile() {
		return ErrorMessageForInvalidPublicKeyFile;
	}
	
	public WebElement getErrorMessageForCsvFileExtention() {
		return ErrorMessageForCsvFileExtention;
	}

	public WebElement getSuccessMessageForGeneratePGPFile() {
		return SuccessMessageForGeneratePGPFile;
	}
		
}

package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.acs.testcases.ACSInitialSetUp;


public class ForgotPasswordPage extends ACSInitialSetUp{

	public WebDriver driver;
    
	public ForgotPasswordPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//a[contains(text(),'Forgot Password?')]")
	private WebElement ForgotPasswordTextLink;
	
	@FindBy(name="loginId")
	private WebElement loginIDTextField;
	
	@FindBy(xpath="//div[@class='login__msg mar-20']")
	private WebElement PasswordRequirmentMsg;
	
	@FindBy(name="password")
	private WebElement PasswordTextField;
	
	@FindBy(name="confirmpassword")
	private WebElement ConfirmPasswordTextField;
	
	@FindBy(xpath="//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement ResetPassowordSubmitButton;
	
	@FindBy(xpath="//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement ResetPassowordCancelButton;
	
	public WebElement getForgotPasswordTextLink() {
		return ForgotPasswordTextLink;
	}

	public WebElement getLoginIDTextField() {
		return loginIDTextField;
	}

	public WebElement getPasswordRequirmentMsg() {
		return PasswordRequirmentMsg;
	}

	public WebElement getPasswordTextField() {
		return PasswordTextField;
	}

	public WebElement getConfirmPasswordTextField() {
		return ConfirmPasswordTextField;
	}

	public WebElement getResetPassowordSubmitButton() {
		return ResetPassowordSubmitButton;
	}

	public WebElement getResetPassowordCancelButton() {
		return ResetPassowordCancelButton;
	}
	
}

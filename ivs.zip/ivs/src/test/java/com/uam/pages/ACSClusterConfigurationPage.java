package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.acs.libraries.Config;

public class ACSClusterConfigurationPage {

	public WebDriver driver;

	public ACSClusterConfigurationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[text()='Manage Cluster Configurations']")
	private WebElement acsManageCCDTextLink;

	public WebElement getAcsManageCCDTextLink() {
		return acsManageCCDTextLink;
	}

	public WebElement getAcsCreateCCDButton() {
		return acsCreateCCDButton;
	}

	public WebElement getAcsCancelCCDButton() {
		return acsCancelCCDButton;
	}

	public WebElement getAcsCCDGroupSelectField() {
		return acsCCDGroupSelectField;
	}

	public WebElement getAcseCCDGroupSelectSearchField() {
		return acseCCDGroupSelectSearchField;
	}

	public WebElement getAcsCCDNameField() {
		return acsCCDNameField;
	}

	public WebElement getAcsCCDHostLiveField() {
		return acsCCDHostLiveField;
	}

	public WebElement getAcsCCDHostCanaryField() {
		return acsCCDHostCanaryField;
	}

	public WebElement getAcsCCDDataCenterSelectField() {
		return acsCCDDataCenterSelectField;
	}

	public WebElement getAcsCCDDataCenterSearchField() {
		return acsCCDDataCenterSearchField;
	}

	public WebElement getAcsCCDResourceTypeSelectField() {
		return acsCCDResourceTypeSelectField;
	}

	public WebElement getAcsCCDResourceTypeSearchField() {
		return acsCCDResourceTypeSearchField;
	}

	public WebElement getAcsCertificateTextField() {
		return acsCertificateTextField;
	}

	public WebElement getAcsConfigJSONTextField() {
		return acsConfigJSONTextField;
	}

	public WebElement getAcsCCDStatusSelectField() {
		return acsCCDStatusSelectField;
	}

	public WebElement getAcsCCDGroupRadioButton() {
		return acsCCDGroupRadioButton;
	}

	public WebElement getAcsCCDResourceRadioButton() {
		return acsCCDResourceRadioButton;
	}

	public WebElement getAcsCCDDataCenterRadioButton() {
		return acsCCDDataCenterRadioButton;
	}

	public WebElement getAcsCCDStatusRadioButton() {
		return acsCCDStatusRadioButton;
	}

	@FindBy(xpath = "//a[text()='Create Cluster Config Details']")
	private WebElement acsCreateCCDButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement acsCancelCCDButton;

	@FindBy(xpath = "//div[contains(@class,'form-group field field-object')]//div[1]//div[1]//div[2]//div[1]//a[1]")
	private WebElement acsCCDGroupSelectField;

	@FindBy(xpath = "//input[@id='1111']")
	private WebElement acseCCDGroupSelectSearchField;

	@FindBy(xpath = "//input[@id='root_ClusterName']")
	private WebElement acsCCDNameField;

	@FindBy(xpath = "//input[@id='root_HostLive']")
	private WebElement acsCCDHostLiveField;

	@FindBy(xpath = "//input[@id='root_HostCanary']")
	private WebElement acsCCDHostCanaryField;

	@FindBy(xpath = "//div[@class='dropdown__title' and text()='Data CenterId']//following::div[1]//a")
	private WebElement acsCCDDataCenterSelectField;

	@FindBy(xpath = "//input[@id='1111']")
	private WebElement acsCCDDataCenterSearchField;

	@FindBy(xpath = "//div[@class='dropdown__title' and text()=' Resource Type']//following::div[1]//a")
	private WebElement acsCCDResourceTypeSelectField;

	@FindBy(xpath = "//input[@id='1111']")
	private WebElement acsCCDResourceTypeSearchField;

	@FindBy(xpath = "//textarea[@id='root_certificateData']")
	private WebElement acsCertificateTextField;

	@FindBy(xpath = "//textarea[@id='root_configJson']")
	private WebElement acsConfigJSONTextField;

	@FindBy(xpath = "//div[@class='dropdown__title' and text()='Status']//following::div[1]//a")
	private WebElement acsCCDStatusSelectField;

	@FindBy(xpath = "//label[@class='radio-label']")
	private WebElement acsCCDGroupRadioButton;

	@FindBy(xpath = "//label[@class='radio-label']")
	private WebElement acsCCDResourceRadioButton;

	@FindBy(xpath = "//label[@class='radio-label']")
	private WebElement acsCCDDataCenterRadioButton;

	@FindBy(xpath = "//label[@class='radio-label']")
	private WebElement acsCCDStatusRadioButton;

	@FindBy(xpath = "//label[@class='radio-label' and contains(text(),'Yes')]")
	private WebElement acsCCDStatusYes;

	@FindBy(xpath = "//label[@class='radio-label' and contains(text(),'No')]")
	private WebElement acsCCDStatusNo;

	@FindBy(xpath = "//div[@class='dropdown dropdown--type4 is-active']//a[@class='button button dropdown-btn']")
	private WebElement listperPageDropdown;

	@FindBy(xpath = "//label[contains(text(),'30 per page')]")
	private WebElement list30PerPageRadioButton;

	@FindBy(xpath = "//input[@placeholder='Search by Cluster Name (case sensitive)']")
	private WebElement searchByClusterName;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column xs truncate'][1]")
	private WebElement listedGroupname;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column md truncate'][1]")
	private WebElement listedclustername;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column md truncate'][2]")
	private WebElement listedResourcetype;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column md truncate'][3]")
	private WebElement listedDatacenter;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column lg truncate'][1]")
	private WebElement listedHostlive;

	@FindBy(xpath = "//div[@class='flex-table__body']//div[@class='flex-table__cell column lg truncate'][2]")
	private WebElement listedHostcanary;

	@FindBy(xpath = "//div[@class='options__edit'][1]")
	private WebElement editClusterButton;

	@FindBy(xpath = "//a[text()='Save Changes']")
	private WebElement saveChanges;

	@FindBy(xpath = "//div[@class='level-right']//a[contains(text(),'Cancel')]")
	private WebElement cancelbutton;

	public WebElement getCancelbutton() {
		return cancelbutton;
	}

	public WebElement getClusterMessage() {
		return clusterMessage;
	}

	public WebElement getDataCenterMessage() {
		return dataCenterMessage;
	}

	public WebElement getHostLiverMessage() {
		return HostLiverMessage;
	}

	public WebElement getHostCanaryMessage() {
		return HostCanaryMessage;
	}

	public WebElement getGroupNameMessage() {
		return groupNameMessage;
	}

	@FindBy(xpath = "//span[text()='Cluster Name']")
	private WebElement clusterMessage;

	@FindBy(xpath = "//span[text()='Data CenterId']")
	private WebElement dataCenterMessage;

	@FindBy(xpath = "//span[contains(text(),'Host Live')]")
	private WebElement HostLiverMessage;

	@FindBy(xpath = "//span[contains(text(),'Host Canary')]")
	private WebElement HostCanaryMessage;

	@FindBy(xpath = "//span[contains(text(),'Group Name')]")
	private WebElement groupNameMessage;

	public WebElement getSaveChanges() {
		return saveChanges;
	}

	public WebElement getListedGroupname() {
		return listedGroupname;
	}

	public WebElement getListedclustername() {
		return listedclustername;
	}

	public WebElement getListedResourcetype() {
		return listedResourcetype;
	}

	public WebElement getListedDatacenter() {
		return listedDatacenter;
	}

	public WebElement getListedHostlive() {
		return listedHostlive;
	}

	public WebElement getListedHostcanary() {
		return listedHostcanary;
	}

	public WebElement getEditClusterButton() {
		return editClusterButton;
	}

	public WebElement getListedStatus() {
		return listedStatus;
	}

	@FindBy(xpath = "//div[@class='oval'][1]")
	private WebElement listedStatus;

	public WebElement getListperPageDropdown() {
		return listperPageDropdown;
	}

	public WebElement getList30PerPageRadioButton() {
		return list30PerPageRadioButton;
	}

	public WebElement getSearchByClusterName() {
		return searchByClusterName;
	}

	public WebElement getAcsCCDStatusYes() {
		return acsCCDStatusYes;
	}

	public WebElement getAcsCCDStatusNo() {
		return acsCCDStatusNo;
	}

}

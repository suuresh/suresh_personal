package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AcsTransactionMisPage {

	public WebDriver driver;

	public AcsTransactionMisPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[text()='ACS Transaction MIS']")
	private WebElement ACSTransactionMisSideBar;

	@FindBy(xpath = "//button[text()=' 3DS1.0']")
	private WebElement ThreeDS1Button;

	@FindBy(xpath = "//button[text()=' 3DS2.0']")
	private WebElement ThreeDS2Button;

	@FindBy(xpath = "(//*[@class='date-picker'])[2]")
	private WebElement datePicker;

	// Select Date
	@FindBy(xpath = "(//select[@class='monthselect'])[1]")
	private WebElement fromMonthSelectDropdown;

	@FindBy(xpath = "(//select[@class='yearselect'])[1]")
	private WebElement fromYearSelectDropdown;

	@FindBy(xpath = "(//select[@class='monthselect'])[2]")
	private WebElement toMonthSelectDropdown;

	@FindBy(xpath = "(//select[@class='yearselect'])[2]")
	private WebElement toYearSelectDropdown;

	@FindBy(xpath = "//a[text()='Fetch Report']")
	private WebElement fetchReportButton;

	public WebElement getFromMonthSelectDropdown() {
		return fromMonthSelectDropdown;
	}

	public WebElement getFetchReportButton() {
		return fetchReportButton;
	}

	public WebElement getFromYearSelectDropdown() {
		return fromYearSelectDropdown;
	}

	public WebElement getToMonthSelectDropdown() {
		return toMonthSelectDropdown;
	}

	public WebElement getToYearSelectDropdown() {
		return toYearSelectDropdown;
	}

	// Select Time
	@FindBy(xpath = "(//select[@class='hourselect'])[1]")
	private WebElement fromHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[1]")
	private WebElement fromMinuteselectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[1]")
	private WebElement fromSecondselectDropdown;

	@FindBy(xpath = "(//select[@class='hourselect'])[2]")
	private WebElement toHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[2]")
	private WebElement toMinuteselectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[1]")
	private WebElement toSecondselectDropdown;

	@FindBy(xpath = "//button[text()='Apply']")
	private WebElement ApplyButton;

	@FindBy(xpath = "//button[text()='Cancel']")
	private WebElement CancelButton;

	// Report Results

	@FindBy(xpath = "//td[text()='Message version']/following::td[2]")
	private WebElement MessageversionValue;

	@FindBy(xpath = "//td[text()='Total No.of VReq(VReq)']/following::td[2]")
	private WebElement TotalNoOfVreqValue;

	@FindBy(xpath = "//td[text()='Total No.of Success VRes(VRes Y)']/following::td[2]")
	private WebElement TotalNoOfVres_Y_Value;

	@FindBy(xpath = "//td[text()='Total No.of Failed VRes(VRes N)']/following::td[2]")
	private WebElement TotalNoOfVres_N_Value;

	@FindBy(xpath = "//td[text()='Total No.of Unable to Authenticate VRes(VRes U)']/following::td[2]")
	private WebElement TotalNoofUnabletoAuthenticateVRes_U_value;

	@FindBy(xpath = "//td[text()='Total No.of PAReq(PAReq)']/following::td[2]")
	private WebElement TotalNoofPAReqValue;

	@FindBy(xpath = "//td[text()='Total No.of Success PARes']/following::td[2]")
	private WebElement TotalNoofSuccessPAResValue;

	@FindBy(xpath = "//td[text()='PARes with valid Authentication(PARes Y)']/following::td[2]")
	private WebElement PAReswithvalidAuthentication_Y_Value;

	@FindBy(xpath = "//td[text()='PARes with Invalid Authentication(PARes N)']/following::td[2]")
	private WebElement PAReswithInvalidAuthentication_N_Value;

	@FindBy(xpath = "//td[text()='Total No.of Attempted PARes (PARes A)']/following::td[2]")
	private WebElement TotalNoofAttemptedPARes_A_Value;

	@FindBy(xpath = "//td[text()='Total No.of Aborted PARes (PARes Prog Abort) ']/following::td[2]")
	private WebElement TotalNoofAbortedPAResProgAbortValue;

	@FindBy(xpath = "//td[text()='Total No. of Unauthenticated PARes/Failed PARes(PARes U )']/following::td[2]")
	private WebElement TotalNoofUnauthenticatedPARes_Failed_U_Value;

	@FindBy(xpath = "//td[text()='Veres/Pareq %']/following::td[2]")
	private WebElement Veres_PareqPercentageValue;

	@FindBy(xpath = "//td[text()='Pareq/Pares %']/following::td[2]")
	private WebElement Pareq_ParesPercentageValue;

	@FindBy(xpath = "//td[text()=' Veres/Pares %']/following::td[2]")
	private WebElement Veres_ParesPercentageValue;

	// Amount Summary
	@FindBy(xpath = "//div[text()='Amount Summary']")
	private WebElement amountSummaryHeader;

	public WebElement getAmountSummaryHeader() {
		return amountSummaryHeader;
	}

	@FindBy(xpath = "(//th[contains(text(),'Currency Code')]/following::tr[2]/td[2])[1]")
	private WebElement currencyCodeINRValue;
	@FindBy(xpath = "(//th[contains(text(),'Currency Code')]/following::tr[3]/td[2])[1]")
	private WebElement currencyCodeUSDValue;
	@FindBy(xpath = "(//th[contains(text(),'Currency Code')]/following::tr[4]/td[2])[1]")
	private WebElement currencyCodeEURValue;

	@FindBy(xpath = "(//th[contains(text(),'Currency Name')]/following::tr[2]/td[3])[1]")
	private WebElement currencyNameINRValue;
	@FindBy(xpath = "(//th[contains(text(),'Currency Name')]/following::tr[3]/td[3])[1]")
	private WebElement currencyNameUSDValue;
	@FindBy(xpath = "(//th[contains(text(),'Currency Name')]/following::tr[4]/td[3])[1]")
	private WebElement currencyNameEURValue;

	@FindBy(xpath = "(//th[contains(text(),'Amount')]/following::tr[2]/td[4])[1]")
	private WebElement amountINRValue;
	@FindBy(xpath = "(//th[contains(text(),'Amount')]/following::tr[3]/td[4])[1]")
	private WebElement amountUSDValue;
	@FindBy(xpath = "(//th[contains(text(),'Amount')]/following::tr[4]/td[4])[1]")
	private WebElement amountEURValue;

	@FindBy(xpath = "(//th[contains(text(),'Pares Y')]/following::tr[2]/td[5])[1]")
	private WebElement ParesY_INRValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares Y')]/following::tr[3]/td[5])[1]")
	private WebElement ParesY_USDValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares Y')]/following::tr[4]/td[5])[1]")
	private WebElement ParesY_EURValue;

	@FindBy(xpath = "(//th[contains(text(),'Pares A')]/following::tr[2]/td[6])[1]")
	private WebElement ParesA_INRValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares A')]/following::tr[3]/td[6])[1]")
	private WebElement ParesA_USDValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares A')]/following::tr[4]/td[6])[1]")
	private WebElement ParesA_EURValue;

	@FindBy(xpath = "(//th[contains(text(),'Pares N')]/following::tr[2]/td[7])[1]")
	private WebElement ParesN_INRValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares N')]/following::tr[3]/td[7])[1]")
	private WebElement ParesN_USDValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares N')]/following::tr[4]/td[7])[1]")
	private WebElement ParesN_EURValue;

	@FindBy(xpath = "(//th[contains(text(),'Pares U')]/following::tr[2]/td[8])[1]")
	private WebElement ParesU_INRValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares U')]/following::tr[3]/td[8])[1]")
	private WebElement ParesU_USDValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares U')]/following::tr[4]/td[8])[1]")
	private WebElement ParesU_EURValue;

	@FindBy(xpath = "(//th[contains(text(),'Pares Aborted')]/following::tr[2]/td[9])[1]")
	private WebElement ParesAborted_INRValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares Aborted')]/following::tr[3]/td[9])[1]")
	private WebElement ParesAborted_USDValue;
	@FindBy(xpath = "(//th[contains(text(),'Pares Aborted')]/following::tr[4]/td[9])[1]")
	private WebElement ParesAborted_EURValue;

	// MIS Summary
	
	@FindBy(xpath = "//div[text()='MIS Summary']")
	private WebElement misSummaryHeader;

	public WebElement getMisSummaryHeader() {
		return misSummaryHeader;
	}

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='System Type']/following::td[1])[1]")
	private WebElement misSummarySystemTypeText;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Card Union']/following::td[2])[1]")
	private WebElement misSummaryCardUnionText;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Card Type']/following::td[3])[1]")
	private WebElement misSummaryCardTypeText;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres/Pareq']/following::td[4])[1]")
	private WebElement misSummaryVeresPareqValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pareq/Pares']/following::td[5])[1]")
	private WebElement misSummaryPareqParesValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres/Pares']/following::td[6])[1]")
	private WebElement misSummaryVeresParesValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='ADS Reg']/following::td[7])[1]")
	private WebElement misSummaryADSRegValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Vereq']/following::td[8])[1]")
	private WebElement misSummaryVereqValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres']/following::td[9])[1]")
	private WebElement misSummaryVeresValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres Y']/following::td[10])[1]")
	private WebElement misSummaryVeres_Y_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres N']/following::td[11])[1]")
	private WebElement misSummaryVeres_N_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Veres U']/following::td[12])[1]")
	private WebElement misSummaryVeres_U_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pareq']/following::td[13])[1]")
	private WebElement misSummaryPareqValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares A']/following::td[14])[1]")
	private WebElement misSummaryPares_A_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares Y']/following::td[15])[1]")
	private WebElement misSummaryPares_Y_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares N']/following::td[16])[1]")
	private WebElement misSummaryPares_N_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares U']/following::td[17])[1]")
	private WebElement misSummaryPares_U_Value;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares Prog Init']/following::td[18])[1]")
	private WebElement misSummaryParesProgInit;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares Prog Abort']/following::td[19])[1]")
	private WebElement misSummaryParesProgAbortValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares Prog Resp']/following::td[20])[1]")
	private WebElement misSummaryParesProgRespValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Pares Prog Comp']/following::td[21])[1]")
	private WebElement misSummaryParesProgCompValue;

	@FindBy(xpath = "(//div[text()='MIS Summary']/following::th[text()='Cache Miss']/following::td[22])[1]")
	private WebElement misSummaryCacheMissValue;

	//PDC Summary
	@FindBy(xpath = "//div[text()='PDC Summary']")
	private WebElement pdcSummaryHeader;
	
	public WebElement getPdcSummaryHeader() {
		return pdcSummaryHeader;
	}

	public WebElement getMisSummarySystemTypeText() {
		return misSummarySystemTypeText;
	}

	public WebElement getMisSummaryCardUnionText() {
		return misSummaryCardUnionText;
	}

	public WebElement getMisSummaryCardTypeText() {
		return misSummaryCardTypeText;
	}

	public WebElement getMisSummaryVeresPareqValue() {
		return misSummaryVeresPareqValue;
	}

	public WebElement getMisSummaryPareqParesValue() {
		return misSummaryPareqParesValue;
	}

	public WebElement getMisSummaryVeresParesValue() {
		return misSummaryVeresParesValue;
	}

	public WebElement getMisSummaryADSRegValue() {
		return misSummaryADSRegValue;
	}

	public WebElement getMisSummaryVereqValue() {
		return misSummaryVereqValue;
	}

	public WebElement getMisSummaryVeresValue() {
		return misSummaryVeresValue;
	}

	public WebElement getMisSummaryVeres_Y_Value() {
		return misSummaryVeres_Y_Value;
	}

	public WebElement getMisSummaryVeres_N_Value() {
		return misSummaryVeres_N_Value;
	}

	public WebElement getMisSummaryVeres_U_Value() {
		return misSummaryVeres_U_Value;
	}

	public WebElement getMisSummaryPareqValue() {
		return misSummaryPareqValue;
	}

	public WebElement getMisSummaryPares_A_Value() {
		return misSummaryPares_A_Value;
	}

	public WebElement getMisSummaryPares_Y_Value() {
		return misSummaryPares_Y_Value;
	}

	public WebElement getMisSummaryPares_N_Value() {
		return misSummaryPares_N_Value;
	}

	public WebElement getMisSummaryPares_U_Value() {
		return misSummaryPares_U_Value;
	}

	public WebElement getMisSummaryParesProgInit() {
		return misSummaryParesProgInit;
	}

	public WebElement getMisSummaryParesProgAbortValue() {
		return misSummaryParesProgAbortValue;
	}

	public WebElement getMisSummaryParesProgRespValue() {
		return misSummaryParesProgRespValue;
	}

	public WebElement getMisSummaryParesProgCompValue() {
		return misSummaryParesProgCompValue;
	}

	public WebElement getMisSummaryCacheMissValue() {
		return misSummaryCacheMissValue;
	}

	public WebElement getCurrencyCodeINRValue() {
		return currencyCodeINRValue;
	}

	public WebElement getCurrencyCodeUSDValue() {
		return currencyCodeUSDValue;
	}

	public WebElement getCurrencyCodeEURValue() {
		return currencyCodeEURValue;
	}

	public WebElement getCurrencyNameINRValue() {
		return currencyNameINRValue;
	}

	public WebElement getCurrencyNameUSDValue() {
		return currencyNameUSDValue;
	}

	public WebElement getCurrencyNameEURValue() {
		return currencyNameEURValue;
	}

	public WebElement getAmountINRValue() {
		return amountINRValue;
	}

	public WebElement getAmountUSDValue() {
		return amountUSDValue;
	}

	public WebElement getAmountEURValue() {
		return amountEURValue;
	}

	public WebElement getParesY_INRValue() {
		return ParesY_INRValue;
	}

	public WebElement getParesY_USDValue() {
		return ParesY_USDValue;
	}

	public WebElement getParesY_EURValue() {
		return ParesY_EURValue;
	}

	public WebElement getParesA_INRValue() {
		return ParesA_INRValue;
	}

	public WebElement getParesA_USDValue() {
		return ParesA_USDValue;
	}

	public WebElement getParesA_EURValue() {
		return ParesA_EURValue;
	}

	public WebElement getParesN_INRValue() {
		return ParesN_INRValue;
	}

	public WebElement getParesN_USDValue() {
		return ParesN_USDValue;
	}

	public WebElement getParesN_EURValue() {
		return ParesN_EURValue;
	}

	public WebElement getParesU_INRValue() {
		return ParesU_INRValue;
	}

	public WebElement getParesU_USDValue() {
		return ParesU_USDValue;
	}

	public WebElement getParesU_EURValue() {
		return ParesU_EURValue;
	}

	public WebElement getParesAborted_INRValue() {
		return ParesAborted_INRValue;
	}

	public WebElement getParesAborted_USDValue() {
		return ParesAborted_USDValue;
	}

	public WebElement getParesAborted_EURValue() {
		return ParesAborted_EURValue;
	}

	public WebElement getACSTransactionMisSideBar() {
		return ACSTransactionMisSideBar;
	}

	public WebElement getThreeDS1Button() {
		return ThreeDS1Button;
	}

	public WebElement getThreeDS2Button() {
		return ThreeDS2Button;
	}

	public WebElement getDatePicker() {
		return datePicker;
	}

	public WebElement getFromHourSelectDropdown() {
		return fromHourSelectDropdown;
	}

	public WebElement getFromMinuteselectDropdown() {
		return fromMinuteselectDropdown;
	}

	public WebElement getFromSecondselectDropdown() {
		return fromSecondselectDropdown;
	}

	public WebElement getToHourSelectDropdown() {
		return toHourSelectDropdown;
	}

	public WebElement getToMinuteselectDropdown() {
		return toMinuteselectDropdown;
	}

	public WebElement getToSecondselectDropdown() {
		return toSecondselectDropdown;
	}

	public WebElement getApplyButton() {
		return ApplyButton;
	}

	public WebElement getCancelButton() {
		return CancelButton;
	}

	public WebElement getMessageversionValue() {
		return MessageversionValue;
	}

	public WebElement getTotalNoOfVreqValue() {
		return TotalNoOfVreqValue;
	}

	public WebElement getTotalNoOfVres_Y_Value() {
		return TotalNoOfVres_Y_Value;
	}

	public WebElement getTotalNoOfVres_N_Value() {
		return TotalNoOfVres_N_Value;
	}

	public WebElement getTotalNoofUnabletoAuthenticateVRes_U_value() {
		return TotalNoofUnabletoAuthenticateVRes_U_value;
	}

	public WebElement getTotalNoofPAReqValue() {
		return TotalNoofPAReqValue;
	}

	public WebElement getTotalNoofSuccessPAResValue() {
		return TotalNoofSuccessPAResValue;
	}

	public WebElement getPAReswithvalidAuthentication_Y_Value() {
		return PAReswithvalidAuthentication_Y_Value;
	}

	public WebElement getPAReswithInvalidAuthentication_N_Value() {
		return PAReswithInvalidAuthentication_N_Value;
	}

	public WebElement getTotalNoofAttemptedPARes_A_Value() {
		return TotalNoofAttemptedPARes_A_Value;
	}

	public WebElement getTotalNoofAbortedPAResProgAbortValue() {
		return TotalNoofAbortedPAResProgAbortValue;
	}

	public WebElement getTotalNoofUnauthenticatedPARes_Failed_U_Value() {
		return TotalNoofUnauthenticatedPARes_Failed_U_Value;
	}

	public WebElement getVeres_PareqPercentageValue() {
		return Veres_PareqPercentageValue;
	}

	public WebElement getPareq_ParesPercentageValue() {
		return Pareq_ParesPercentageValue;
	}

	public WebElement getVeres_ParesPercentageValue() {
		return Veres_ParesPercentageValue;
	}
	
	// PDC
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[1]")
		private WebElement pdcSummarySystemType;
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[2]")
		private WebElement pdcSummaryCardUnion;
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[3]")
		private WebElement pdcSummaryCardType;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[4]")
		private WebElement pdcSummaryVeresPareqPerc;

		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[5]")
		private WebElement pdcSummaryPareqParesPerc;

		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[6]")
		private WebElement pdcSummaryVeresParesPerc;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[7]")
		private WebElement pdcSummaryADSReg;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[8]")
		private WebElement pdcSummaryVereq;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[9]")
		private WebElement pdcSummaryVeres;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[10]")
		private WebElement pdcSummaryVeres_Y;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[11]")
		private WebElement pdcSummaryVeres_N;
		
		public WebElement getPdcSummarySystemType() {
			return pdcSummarySystemType;
		}

		public WebElement getPdcSummaryCardUnion() {
			return pdcSummaryCardUnion;
		}

		public WebElement getPdcSummaryCardType() {
			return pdcSummaryCardType;
		}

		public WebElement getPdcSummaryVeresPareqPerc() {
			return pdcSummaryVeresPareqPerc;
		}

		public WebElement getPdcSummaryPareqParesPerc() {
			return pdcSummaryPareqParesPerc;
		}

		public WebElement getPdcSummaryVeresParesPerc() {
			return pdcSummaryVeresParesPerc;
		}

		public WebElement getPdcSummaryADSReg() {
			return pdcSummaryADSReg;
		}

		public WebElement getPdcSummaryVereq() {
			return pdcSummaryVereq;
		}

		public WebElement getPdcSummaryVeres() {
			return pdcSummaryVeres;
		}

		public WebElement getPdcSummaryVeres_Y() {
			return pdcSummaryVeres_Y;
		}

		public WebElement getPdcSummaryVeres_N() {
			return pdcSummaryVeres_N;
		}

		public WebElement getPdcSummaryVeres_U() {
			return pdcSummaryVeres_U;
		}

		public WebElement getPdcSummaryPareq() {
			return pdcSummaryPareq;
		}

		public WebElement getPdcSummaryPares_A() {
			return pdcSummaryPares_A;
		}

		public WebElement getPdcSummaryPares_Y() {
			return pdcSummaryPares_Y;
		}

		public WebElement getPdcSummaryPares_N() {
			return pdcSummaryPares_N;
		}

		public WebElement getPdcSummaryPares_U() {
			return pdcSummaryPares_U;
		}

		public WebElement getPdcSummaryProgInit() {
			return pdcSummaryProgInit;
		}

		public WebElement getPdcSummaryProgAbort() {
			return pdcSummaryProgAbort;
		}

		public WebElement getPdcSummaryProgResp() {
			return pdcSummaryProgResp;
		}

		public WebElement getPdcSummaryProgComp() {
			return pdcSummaryProgComp;
		}

		public WebElement getPdcSummaryCacheMiss() {
			return pdcSummaryCacheMiss;
		}

		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[12]")
		private WebElement pdcSummaryVeres_U;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[13]")
		private WebElement pdcSummaryPareq;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[14]")
		private WebElement pdcSummaryPares_A;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[15]")
		private WebElement pdcSummaryPares_Y;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[16]")
		private WebElement pdcSummaryPares_N;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[17]")
		private WebElement pdcSummaryPares_U;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[18]")
		private WebElement pdcSummaryProgInit;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[19]")
		private WebElement pdcSummaryProgAbort;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[20]")
		private WebElement pdcSummaryProgResp;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[21]")
		private WebElement pdcSummaryProgComp;
		
		@FindBy(xpath = "//body/div[@id='app']/div/div[@class='main']/div[@class='main__body']/div[@class='main__wrapper']/div[@class='page']/div[@class='page__content is-paddingless']/div/div[@class='flex-table example']/div[@class='table-responsive tabl-scroll']/table[@class='table table-bordered']/tbody[2]/tr[1]/td[22]")
		private WebElement pdcSummaryCacheMiss;

		//Bin Wise
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[1]")
	    private WebElement binWiseSystemType;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[2]")
	    private WebElement binWiseBINId;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[3]")
	    private WebElement binWiseCardUnion;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[4]")
	    private WebElement binWiseCardType;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[5]")
	    private WebElement binWiseVeresPareq;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[6]")
	    private WebElement binWisePareqPares;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[7]")
	    private WebElement binWiseVeresPares;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[8]")
	    private WebElement binWiseADSReg;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[9]")
	    private WebElement binWiseVereq;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[10]")
	    private WebElement binWiseVeres;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[11]")
	    private WebElement binWiseVeres_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[12]")
	    private WebElement binWiseVeres_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[13]")
	    private WebElement binWiseVeres_U;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[14]")
	    private WebElement binWisePareq;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[15]")
	    private WebElement binWisePares_A;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[16]")
	    private WebElement binWisePares_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[17]")
	    private WebElement binWisePares_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[18]")
	    private WebElement binWisePares_U;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[19]")
	    private WebElement binWiseParesProgInit;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[20]")
	    private WebElement binWiseParesProgAbort;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[21]")
	    private WebElement binWiseParesProgResp;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[22]")
	    private WebElement binWiseParesProgComp;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[23]")
	    private WebElement binWiseCacheMiss;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[24]")
	    private WebElement binWiseEcom_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[25]")
	    private WebElement binWiseEcom_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[26]")
	    private WebElement binWiseEcomOther;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[27]")
	    private WebElement binWiseIVR_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[28]")
	    private WebElement binWiseIVR_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[29]")
	    private WebElement binWiseIVROther;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[30]")
	    private WebElement binWiseStatic_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[31]")
	    private WebElement binWiseStatic_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[32]")
	    private WebElement binWiseStaticOther;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[33]")
	    private WebElement binWisePreOTP_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[34]")
	    private WebElement binWisePreOTP_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[35]")
	    private WebElement binWisePreOTP_Other;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[36]")
	    private WebElement binWiseOTP_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[37]")
	    private WebElement binWiseOTP_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[38]")
	    private WebElement binWiseOTP_Other;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[39]")
	    private WebElement binWiseITP_Y;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[40]")
	    private WebElement binWiseITP_N;
		@FindBy(xpath="//div[text()='BIN Wise MIS Summary']/../../following::div[@class='page__content is-paddingless']/div/div/div/table/thead/following::tbody[2]/tr/td[41]")
	    private WebElement binWiseITPOther;

		public WebElement getBinWiseSystemType() {
			return binWiseSystemType;
		}

		public WebElement getBinWiseBINId() {
			return binWiseBINId;
		}

		public WebElement getBinWiseCardUnion() {
			return binWiseCardUnion;
		}

		public WebElement getBinWiseCardType() {
			return binWiseCardType;
		}

		public WebElement getBinWiseVeresPareq() {
			return binWiseVeresPareq;
		}

		public WebElement getBinWisePareqPares() {
			return binWisePareqPares;
		}

		public WebElement getBinWiseVeresPares() {
			return binWiseVeresPares;
		}

		public WebElement getBinWiseADSReg() {
			return binWiseADSReg;
		}

		public WebElement getBinWiseVereq() {
			return binWiseVereq;
		}

		public WebElement getBinWiseVeres() {
			return binWiseVeres;
		}

		public WebElement getBinWiseVeres_Y() {
			return binWiseVeres_Y;
		}

		public WebElement getBinWiseVeres_N() {
			return binWiseVeres_N;
		}

		public WebElement getBinWiseVeres_U() {
			return binWiseVeres_U;
		}

		public WebElement getBinWisePareq() {
			return binWisePareq;
		}

		public WebElement getBinWisePares_A() {
			return binWisePares_A;
		}

		public WebElement getBinWisePares_Y() {
			return binWisePares_Y;
		}

		public WebElement getBinWisePares_N() {
			return binWisePares_N;
		}

		public WebElement getBinWisePares_U() {
			return binWisePares_U;
		}

		public WebElement getBinWiseParesProgInit() {
			return binWiseParesProgInit;
		}

		public WebElement getBinWiseParesProgAbort() {
			return binWiseParesProgAbort;
		}

		public WebElement getBinWiseParesProgResp() {
			return binWiseParesProgResp;
		}

		public WebElement getBinWiseParesProgComp() {
			return binWiseParesProgComp;
		}

		public WebElement getBinWiseCacheMiss() {
			return binWiseCacheMiss;
		}

		public WebElement getBinWiseEcom_Y() {
			return binWiseEcom_Y;
		}

		public WebElement getBinWiseEcom_N() {
			return binWiseEcom_N;
		}

		public WebElement getBinWiseEcomOther() {
			return binWiseEcomOther;
		}

		public WebElement getBinWiseIVR_Y() {
			return binWiseIVR_Y;
		}

		public WebElement getBinWiseIVR_N() {
			return binWiseIVR_N;
		}

		public WebElement getBinWiseIVROther() {
			return binWiseIVROther;
		}

		public WebElement getBinWiseStatic_Y() {
			return binWiseStatic_Y;
		}

		public WebElement getBinWiseStatic_N() {
			return binWiseStatic_N;
		}

		public WebElement getBinWiseStaticOther() {
			return binWiseStaticOther;
		}

		public WebElement getBinWisePreOTP_Y() {
			return binWisePreOTP_Y;
		}

		public WebElement getBinWisePreOTP_N() {
			return binWisePreOTP_N;
		}

		public WebElement getBinWisePreOTP_Other() {
			return binWisePreOTP_Other;
		}

		public WebElement getBinWiseOTP_Y() {
			return binWiseOTP_Y;
		}

		public WebElement getBinWiseOTP_N() {
			return binWiseOTP_N;
		}

		public WebElement getBinWiseOTP_Other() {
			return binWiseOTP_Other;
		}

		public WebElement getBinWiseITP_Y() {
			return binWiseITP_Y;
		}

		public WebElement getBinWiseITP_N() {
			return binWiseITP_N;
		}

		public WebElement getBinWiseITPOther() {
			return binWiseITPOther;
		}
		
		
		//for 2.0 protocol version
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Message version']/following::td[1]")
		private WebElement ACSTransactionMis_Messageversion_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Areq(Areq)']/following::td[1]")
		private WebElement ACSTransactionMis_Areq_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Success ARes(ARes Y)']/following::td[1]")
		private WebElement ACSTransactionMis_ARes_Y_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Failed ARes(ARes N)']/following::td[1]")
		private WebElement ACSTransactionMis_ARes_N_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Unable to Authenticate ARes(ARes U)']/following::td[1]")
		private WebElement ACSTransactionMis_ARes_U_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No of Rejected Ares(Ares R)']/following::td[1]")
		private WebElement ACSTransactionMis_Ares_R_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No of Challenge Ares(Ares C) ']/following::td[1]")
		private WebElement ACSTransactionMis_Ares_C_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No of Creq(Creq)']/following::td[1]")
		private WebElement ACSTransactionMis_Creq_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No Of Success Cres(Cres Y) ']/following::td[1]")
		private WebElement ACSTransactionMis_Cres_Y_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No of Failed Cres(Cres N)  ']/following::td[1]")
		private WebElement ACSTransactionMis_Cres_N_2_0	;
		
		public WebElement getACSTransactionMis_Messageversion_2_0() {
			return ACSTransactionMis_Messageversion_2_0;
		}

		public WebElement getACSTransactionMis_Areq_2_0() {
			return ACSTransactionMis_Areq_2_0;
		}

		public WebElement getACSTransactionMis_ARes_Y_2_0() {
			return ACSTransactionMis_ARes_Y_2_0;
		}

		public WebElement getACSTransactionMis_ARes_N_2_0() {
			return ACSTransactionMis_ARes_N_2_0;
		}

		public WebElement getACSTransactionMis_ARes_U_2_0() {
			return ACSTransactionMis_ARes_U_2_0;
		}

		public WebElement getACSTransactionMis_Ares_R_2_0() {
			return ACSTransactionMis_Ares_R_2_0;
		}

		public WebElement getACSTransactionMis_Ares_C_2_0() {
			return ACSTransactionMis_Ares_C_2_0;
		}

		public WebElement getACSTransactionMis_Creq_2_0() {
			return ACSTransactionMis_Creq_2_0;
		}

		public WebElement getACSTransactionMis_Cres_Y_2_0() {
			return ACSTransactionMis_Cres_Y_2_0;
		}

		public WebElement getACSTransactionMis_Cres_N_2_0() {
			return ACSTransactionMis_Cres_N_2_0;
		}

		public WebElement getACSTransactionMis_RReq_2_0() {
			return ACSTransactionMis_RReq_2_0;
		}

		public WebElement getACSTransactionMis_RRes_Y_2_0() {
			return ACSTransactionMis_RRes_Y_2_0;
		}

		public WebElement getACSTransactionMis_RRes_N_2_0() {
			return ACSTransactionMis_RRes_N_2_0;
		}

		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of RReq(RReq) ']/following::td[1]")
		private WebElement ACSTransactionMis_RReq_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Success RRes (Rres Y)  ']/following::td[1]")
		private WebElement ACSTransactionMis_RRes_Y_2_0	;
		
		@FindBy(xpath = "//th[text()='Particulars']/ancestor::thead/following-sibling::tbody/tr/td[text()='Total No.of Failed RRes (RRes N) ']/following::td[1]")
		private WebElement ACSTransactionMis_RRes_N_2_0	;
}

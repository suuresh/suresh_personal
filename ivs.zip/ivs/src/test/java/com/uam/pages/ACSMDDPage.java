package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ACSMDDPage {

	public WebDriver driver;

	public ACSMDDPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[contains(text(),'MDD Report')]")
	private WebElement mddReportLink;
	
	@FindBy(xpath = "//button[text()=' 3DS1.0']")
	private WebElement ThreeDS1Button;

	@FindBy(xpath = "//button[text()=' 3DS2.0']")
	private WebElement ThreeDS2Button;
	
	@FindBy(xpath = "(//*[@class='date-picker'])[2]")
	private WebElement datePicker;
	
	// Select Time
	@FindBy(xpath = "(//select[@class='hourselect'])[1]")
	private WebElement fromHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[1]")
	private WebElement fromMinuteselectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[1]")
	private WebElement fromSecondselectDropdown;

	@FindBy(xpath = "(//select[@class='hourselect'])[2]")
	private WebElement toHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[2]")
	private WebElement toMinuteselectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[1]")
	private WebElement toSecondselectDropdown;

	@FindBy(xpath = "//button[text()='Apply']")
	private WebElement ApplyButton;

	@FindBy(xpath = "//button[text()='Cancel']")
	private WebElement CancelButton;

	@FindBy(xpath = "//a[text()='Fetch Report']")
	private WebElement mddfetchReportButton;

//  2.0 MDD Report table columns values
	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[2]")
	private WebElement mddTotalAreqCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[3]")
	private WebElement mddAresYCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[4]")
	private WebElement mddAresNCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[5]")
	private WebElement mddAresRCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[6]")
	private WebElement mddAresCCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[7]")
	private WebElement mddAresUCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[8]")
	private WebElement mddTotalCreqCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[9]")
	private WebElement mddTotalCresCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[10]")
	private WebElement mddTotalRreqCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[11]")
	private WebElement mddTotalRresCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[12]")
	private WebElement mddRreqWithStatusYCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[13]")
	private WebElement mddRreqWithStatusNCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[14]")
	private WebElement mddRreqWithStatusUCountValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[15]")
	private WebElement mddFrictionLessSuccessWithYPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[16]")
	private WebElement mddChallengeTxnPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[17]")
	private WebElement mddFrictionlessRejectWithRPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[18]")
	private WebElement mddFrictionlessDeclineWithNPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[19]")
	private WebElement mddFrictionlessRejectWithUPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[20]")
	private WebElement mddChallengeSuccessPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[21]")
	private WebElement mddChallengeFailureNPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[22]")
	private WebElement mddChallengeDeclineUPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[23]")
	private WebElement mddOverallSuccessYPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[24]")
	private WebElement mddOverallFailurePercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[25]")
	private WebElement mddOverallSuccessWithYNRPercentageValue;

//  1.0 MDD Report table columns values
	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[2]")
	private WebElement mddTotalVEReqValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[3]")
	private WebElement mddVEResYValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[4]")
	private WebElement mddVEResNValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[5]")
	private WebElement mddVEResUValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[6]")
	private WebElement mddTotalPAReqValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[7]")
	private WebElement mddPAResYValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[8]")
	private WebElement mddPAResNValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[9]")
	private WebElement mddPAResUValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[10]")
	private WebElement mddPAReqDidNotComeValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[11]")
	private WebElement mddAbondonedValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[12]")
	private WebElement mddDroppedPareqDidNotComePlusAbandonedValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[13]")
	private WebElement mddDroppedPAResOrVReqPErcentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[14]")
	private WebElement mddAbandonedPAResOrPAReqPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[15]")
	private WebElement mddPAReqOrVReqPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[16]")
	private WebElement mddPAResYOrVReqPercentageSuccessValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[17]")
	private WebElement mddPAResYPlusNOrVReqPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[18]")
	private WebElement mddPAResYPlusNOrVReqPercentageFailureValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[19]")
	private WebElement mddPAResYOrPAReqPercentageValue;

	@FindBy(xpath = "//table[@class='table table-bordered']//tbody//tr/td[20]")
	private WebElement mddPAResYPlusNOrPAReqPercentageValue;
	
	
	public WebElement getThreeDS1Button() {
		return ThreeDS1Button;
	}

	public WebElement getThreeDS2Button() {
		return ThreeDS2Button;
	}

	public WebElement getDatePicker() {
		return datePicker;
	}

	public WebElement getMddReportLink() {
		return mddReportLink;
	}

	public WebElement getFromHourSelectDropdown() {
		return fromHourSelectDropdown;
	}

	public WebElement getFromMinuteselectDropdown() {
		return fromMinuteselectDropdown;
	}

	public WebElement getFromSecondselectDropdown() {
		return fromSecondselectDropdown;
	}

	public WebElement getToHourSelectDropdown() {
		return toHourSelectDropdown;
	}

	public WebElement getToMinuteselectDropdown() {
		return toMinuteselectDropdown;
	}

	public WebElement getToSecondselectDropdown() {
		return toSecondselectDropdown;
	}

	public WebElement getApplyButton() {
		return ApplyButton;
	}

	public WebElement getCancelButton() {
		return CancelButton;
	}

	public WebElement getMddfetchReportButton() {
		return mddfetchReportButton;
	}

	public WebElement getMddTotalAreqCountValue() {
		return mddTotalAreqCountValue;
	}

	public WebElement getMddAresYCountValue() {
		return mddAresYCountValue;
	}

	public WebElement getMddAresNCountValue() {
		return mddAresNCountValue;
	}

	public WebElement getMddAresRCountValue() {
		return mddAresRCountValue;
	}

	public WebElement getMddAresCCountValue() {
		return mddAresCCountValue;
	}

	public WebElement getMddAresUCountValue() {
		return mddAresUCountValue;
	}

	public WebElement getMddTotalCreqCountValue() {
		return mddTotalCreqCountValue;
	}

	public WebElement getMddTotalCresCountValue() {
		return mddTotalCresCountValue;
	}

	public WebElement getMddTotalRreqCountValue() {
		return mddTotalRreqCountValue;
	}

	public WebElement getMddTotalRresCountValue() {
		return mddTotalRresCountValue;
	}

	public WebElement getMddRreqWithStatusYCountValue() {
		return mddRreqWithStatusYCountValue;
	}

	public WebElement getMddRreqWithStatusNCountValue() {
		return mddRreqWithStatusNCountValue;
	}

	public WebElement getMddRreqWithStatusUCountValue() {
		return mddRreqWithStatusUCountValue;
	}

	public WebElement getMddFrictionLessSuccessWithYPercentageValue() {
		return mddFrictionLessSuccessWithYPercentageValue;
	}

	public WebElement getMddChallengeTxnPercentageValue() {
		return mddChallengeTxnPercentageValue;
	}

	public WebElement getMddFrictionlessRejectWithRPercentageValue() {
		return mddFrictionlessRejectWithRPercentageValue;
	}

	public WebElement getMddFrictionlessDeclineWithNPercentageValue() {
		return mddFrictionlessDeclineWithNPercentageValue;
	}

	public WebElement getMddFrictionlessRejectWithUPercentageValue() {
		return mddFrictionlessRejectWithUPercentageValue;
	}

	public WebElement getMddChallengeSuccessPercentageValue() {
		return mddChallengeSuccessPercentageValue;
	}

	public WebElement getMddChallengeFailureNPercentageValue() {
		return mddChallengeFailureNPercentageValue;
	}

	public WebElement getMddChallengeDeclineUPercentageValue() {
		return mddChallengeDeclineUPercentageValue;
	}

	public WebElement getMddOverallSuccessYPercentageValue() {
		return mddOverallSuccessYPercentageValue;
	}

	public WebElement getMddOverallFailurePercentageValue() {
		return mddOverallFailurePercentageValue;
	}

	public WebElement getMddOverallSuccessWithYNRPercentageValue() {
		return mddOverallSuccessWithYNRPercentageValue;
	}

	public WebElement getMddTotalVEReqValue() {
		return mddTotalVEReqValue;
	}

	public WebElement getMddVEResYValue() {
		return mddVEResYValue;
	}

	public WebElement getMddVEResNValue() {
		return mddVEResNValue;
	}

	public WebElement getMddVEResUValue() {
		return mddVEResUValue;
	}

	public WebElement getMddTotalPAReqValue() {
		return mddTotalPAReqValue;
	}

	public WebElement getMddPAResYValue() {
		return mddPAResYValue;
	}

	public WebElement getMddPAResNValue() {
		return mddPAResNValue;
	}

	public WebElement getMddPAResUValue() {
		return mddPAResUValue;
	}

	public WebElement getMddPAReqDidNotComeValue() {
		return mddPAReqDidNotComeValue;
	}

	public WebElement getMddAbondonedValue() {
		return mddAbondonedValue;
	}

	public WebElement getMddDroppedPareqDidNotComePlusAbandonedValue() {
		return mddDroppedPareqDidNotComePlusAbandonedValue;
	}

	public WebElement getMddDroppedPAResOrVReqPErcentageValue() {
		return mddDroppedPAResOrVReqPErcentageValue;
	}

	public WebElement getMddAbandonedPAResOrPAReqPercentageValue() {
		return mddAbandonedPAResOrPAReqPercentageValue;
	}

	public WebElement getMddPAReqOrVReqPercentageValue() {
		return mddPAReqOrVReqPercentageValue;
	}

	public WebElement getMddPAResYOrVReqPercentageSuccessValue() {
		return mddPAResYOrVReqPercentageSuccessValue;
	}

	public WebElement getMddPAResYPlusNOrVReqPercentageValue() {
		return mddPAResYPlusNOrVReqPercentageValue;
	}

	public WebElement getMddPAResYPlusNOrVReqPercentageFailureValue() {
		return mddPAResYPlusNOrVReqPercentageFailureValue;
	}

	public WebElement getMddPAResYOrPAReqPercentageValue() {
		return mddPAResYOrPAReqPercentageValue;
	}

	public WebElement getMddPAResYPlusNOrPAReqPercentageValue() {
		return mddPAResYPlusNOrPAReqPercentageValue;
	}
	
	
}

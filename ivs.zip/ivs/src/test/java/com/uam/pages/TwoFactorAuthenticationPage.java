package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TwoFactorAuthenticationPage {

	public WebDriver driver;

	public TwoFactorAuthenticationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[contains(text(),'Manage Resources')]")
	private WebElement ManageResourceLink;
	
	@FindBy(xpath = "//div[@class='level-right']/div/a[contains(text(),'Admin Params')]")
	private WebElement AdminParamsButton;
	
	@FindBy(xpath = "//input[@placeholder='Search by Key Name']")
	private WebElement SearchByKeyNameInPutField;
	
	
//	  @FindBy(xpath = "//div[@class='flex-table__row columns odd']//div[@class='options__edit']") 
//	  private WebElement TwoFactorEditOption;
	 
	@FindBy(xpath ="//body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[10]/div[4]/div[1]/div[1]")
	//@FindBy(xpath = "//div[@class='flex-table__row columns'][1]//div[@class='options__edit']") 
	private WebElement TwoFactorEditOption;
	 
	@FindBy(xpath = "//div[@class='flex-table__row columns odd']") 
	private WebElement FirstRecordAfterSearch;
	 /*	
	@FindBy(xpath = "//body/div[@id='app']/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/*[1]") 
	private WebElement TwoFactorEditOption;
	*/
	@FindBy(xpath = "//h4[contains(text(),'Edit Admin Params')]")
	private WebElement EditAdminParamsHeading;
	
	@FindBy(xpath = "//input[@id='root_KeyName']")
	private WebElement rootKeyNameText;
	
	@FindBy(xpath = "//textarea[@id='root_KeyValue']")
	private WebElement rootKeyValueTextArea;
	
	@FindBy(xpath = "//textarea[@id='root_Comments']")
	private WebElement rootKeyCommentTextArea;
	
	@FindBy(xpath = "//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement AdminParamsCancelButton;
	
	@FindBy(xpath="//a[normalize-space()='Save Changes']")	
	private WebElement SaveChangesButton;
	
	@FindBy(xpath = "//div[@class='column is-9 login__section']//div[@class='mar-20']/span[2]")
	private WebElement CatpchText;
	
	@FindBy(xpath = "//input[@placeholder='Enter Captcha']")
	private WebElement EnterCaptchTextArea;
	
	@FindBy(xpath = "//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement SendOTPButton;
	
	@FindBy(xpath = "//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement TwoFACancelButton;
	
	@FindBy(xpath = "//input[@placeholder='Enter 6 Digit OTP']")
	private WebElement EnterOTPTextArea;
	
	@FindBy(xpath = "//a[contains(text(),'Resend OTP')]")
	private WebElement ResendOTPTextLink;
	
	@FindBy(xpath = "//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement OTPSubmitButton;
	
	@FindBy(xpath = "//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement OTPCancelButton;

	public WebElement getManageResourceLink() {
		return ManageResourceLink;
	}

	public WebElement getAdminParamsButton() {
		return AdminParamsButton;
	}

	public WebElement getSearchByKeyNameInPutField() {
		return SearchByKeyNameInPutField;
	}

	public WebElement getTwoFactorEditOption() {
		return TwoFactorEditOption;
	}

	public WebElement getEditAdminParamsHeading() {
		return EditAdminParamsHeading;
	}

	public WebElement getRootKeyNameText() {
		return rootKeyNameText;
	}

	public WebElement getRootKeyValueTextArea() {
		return rootKeyValueTextArea;
	}

	public WebElement getRootKeyCommentTextArea() {
		return rootKeyCommentTextArea;
	}

	public WebElement getAdminParamsCancelButton() {
		return AdminParamsCancelButton;
	}

	public WebElement getSaveChangesButton() {
		return SaveChangesButton;
	}

	public WebElement getCatpchText() {
		return CatpchText;
	}

	public WebElement getEnterCaptchTextArea() {
		return EnterCaptchTextArea;
	}

	public WebElement getSendOTPButton() {
		return SendOTPButton;
	}

	public WebElement getTwoFACancelButton() {
		return TwoFACancelButton;
	}

	public WebElement getEnterOTPTextArea() {
		return EnterOTPTextArea;
	}

	public WebElement getResendOTPTextLink() {
		return ResendOTPTextLink;
	}

	public WebElement getOTPSubmitButton() {
		return OTPSubmitButton;
	}

	public WebElement getOTPCancelButton() {
		return OTPCancelButton;
	}
		
}

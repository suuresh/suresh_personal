package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminACSFetchTxnPage {

	public WebDriver driver;

	public AdminACSFetchTxnPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath = "//a[text()='Reset']")
	private WebElement acsResetButton;

	@FindBy(xpath = "//*[@class='btn-icon']")
	private WebElement acsAdevanceSearchButton;

	@FindBy(xpath = "//*[@class='date-picker']")
	private WebElement datePickerButton;
	
	@FindBy(xpath = "(//div[@class='transaction-date__info'])[1]")
	private WebElement from_DateInfoText;
	
	@FindBy(xpath = "(//div[@class='transaction-date__info'])[2]")
	private WebElement to_DateInfoText;
	
	@FindBy(xpath = "//div[@class='transaction-date__item'][1]//div/span[1]")
	private WebElement fromDate;

	@FindBy(xpath = "//div[@class='transaction-date__item'][1]//span[3]")
	private WebElement fromTimeRange;
	
	//@FindBy(xpath = "//div[contains(@class,'dropdown--type3')] //*[contains(@class,'dropdown__icon')]")	
	//@FindBy(xpath = "//div[@class='dropdown dropdown--type3 is-active']//a[@class='button button dropdown-btn']//*[name()='svg']")
	
	@FindBy(xpath = "//div[@class='level-item width-100']//a[@class='button button dropdown-btn']")
	private WebElement dropDownFormatIcon;
	
	/*
	 * @FindBy(
	 * xpath="//div[@class='drp-calendar left']//td[@class='active start-date available in-range'][contains(text(),'1')]"
	 * ) private WebElement todayActiveStartDateCurrentMonth;
	 */

	@FindBy(xpath = "(//div[@class='level']//div[3]//*[local-name()='svg'])[1]")
	private WebElement acsCalenderIcon;

	@FindBy(xpath = "//div[@class='drp-calendar left']//select[@class='hourselect']")
	private WebElement acsLeftHoursSelect;

	@FindBy(xpath = "//select[@class='hourselect']")
	private WebElement hoursSelect;

	@FindBy(xpath = "//select[@class='minuteselect']")
	private WebElement minutesSelect;

	@FindBy(xpath = "//td[@class='active end-date in-range available']")
	private WebElement activeEndDateCurrentMonth;

	@FindBy(xpath = "//div[@class='drp-calendar right']//select[@class='hourselect']")
	private WebElement EndDateCurrentMonth;

	@FindBy(xpath = "//td[@class='active end-date in-range available']")
	private WebElement endDateHoursSelect;

	@FindBy(xpath = "//div[@class='drp-calendar right']//select[@class='minuteselect']")
	private WebElement endDateMinutes;

	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	private WebElement applyButton;

	@FindBy(name = "acs_txn_id")
	private WebElement acsTxnIDTextField;

	@FindBy(name = "card_number")
	private WebElement cardNumberTextField;

	@FindBy(xpath = "//span[contains(text(),'Select Transaction Status')]")
	private WebElement TransactionStatusField;
	
	@FindBy(xpath = "//label[contains(text(),'Success')]")
	private WebElement TransactionStatusSuccess;

	@FindBy(xpath = "//label[contains(text(),'Failure')]")
	private WebElement TransactionStatusFailure;

	@FindBy(xpath = "//label[contains(text(),'Rejected')]")
	private WebElement TransactionStatusRejected;
		
	@FindBy(xpath = "//span[contains(text(),'Select Authentication Type')]")
	private WebElement AuthenticationTypeField;
	
	@FindBy(xpath = "//label[contains(text(),'FrictionLess')]")
	private WebElement AuthenticationTypeFrictionLess;
	
	@FindBy(xpath = "//label[contains(text(),'Challenge')]")
	private WebElement AuthenticationTypeChallenge;
	
	@FindBy(xpath = "//span[contains(text(),'Select Device Channel')]")
	private WebElement DeviceChannelField;
	
	@FindBy(xpath = "//label[contains(text(),'Browser')]")
	private WebElement DeviceChannelBrowser;
	
	@FindBy(xpath = "//label[contains(text(),'App')]")
	private WebElement DeviceChannelApp;
	
	@FindBy(xpath = "//span[contains(text(),'Select Card Union')]")
	private WebElement CardUnionField;
	
	@FindBy(xpath = "//label[contains(text(),'Mastercard')]")
	private WebElement CardUnionMaster;
	
	@FindBy(xpath = "//label[contains(text(),'Visa')]")
	private WebElement CardUnionVisa;
	
	@FindBy(xpath = "//label[contains(text(),'Diners')]")
	private WebElement CardUnionDiners;
	
	@FindBy(xpath = "//label[contains(text(),'RuPay')]")
	private WebElement CardUnionRuPay;
	
	@FindBy(xpath = "//span[contains(text(),'Select Card Type')]")
	private WebElement CardTypeField;
	
	@FindBy(xpath = "//label[contains(text(),'Debit')]")
	private WebElement CardTypeDebit;
	
	@FindBy(xpath = "//label[contains(text(),'Credit')]")
	private WebElement CardTypeCredit;
	
	@FindBy(xpath = "//label[contains(text(),'Prepaid')]")
	private WebElement CardTypePrepaid;
		
	@FindBy(xpath = "//span[contains(text(),'Select BIN Number')]")
	private WebElement BinNumberField;
	
	@FindBy(xpath = "//input[@id='myInput']")
	private WebElement BinNumberSearchField;
	
	@FindBy(xpath = "//label[@class='checkbox__lable']")
	private WebElement BinNumberSearchedCheckBox;
	
	@FindBy(xpath = "//span[contains(text(),'Select Data Center')]")
	private WebElement DataCenterField;
	
	@FindBy(xpath = "//label[contains(text(),'blrrel')]")
	private WebElement DataCenterBlr;
	
	@FindBy(xpath = "//span[contains(text(),'Select Ruleset Id')]")
	private WebElement RuleSetIdField;
	
	@FindBy(xpath = "//input[@id='myInput']")
	private WebElement RuleSetIdSearchField;
	
	@FindBy(xpath = "//label[@class='checkbox__lable']")
	private WebElement RuleSetIdSearchedCheckBox;
	
	@FindBy(xpath = "//input[@name='production_node']")
	private WebElement ProductionNodeField;
	
	@FindBy(xpath = "//input[@name='risk_engine_client_id']")
	private WebElement RiskEngineClientIdField;
	
	@FindBy(xpath = "//span[contains(text(),'Select transaction Type')]")
	private WebElement TransactionTypeField;
	
	@FindBy(xpath = "//label[contains(text(),'ECOM')]")
	private WebElement TransactionTypeECOM;
	
	@FindBy(xpath = "//label[contains(text(),'IVR')]")	
	private WebElement TransactionTypeIVR;
	
	@FindBy(xpath = "//label[contains(text(),'EXPRESSPAY')]")
	private WebElement TransactionTypeExpressPay;
	
	@FindBy(xpath = "//label[contains(text(),'BEPG')]")
	private WebElement TransactionTypeBEPG;

	@FindBy(xpath = "//label[contains(text(),'REDIRECTION')]")
	private WebElement TransactionTypeRedirection;

	@FindBy(xpath = "//label[contains(text(),'ITP')]")
	private WebElement TransactionTypeITP;	
	
	@FindBy(xpath = "//span[contains(text(),'Select Client Id')]")
	private WebElement ClientIdField;
	
	@FindBy(xpath = "//label[contains(text(),'AMAZON')]")
	private WebElement ClientIdAMAZON;
	
	@FindBy(xpath = "//label[contains(text(),'PAYU')]")
	private WebElement ClientIdPAYU;
	
	@FindBy(xpath = "//span[contains(text(),'Select Version')]")
	private WebElement ProtocolVersionField;
	
	@FindBy(xpath = "//span[contains(text(),'Select Currency')]")
	private WebElement CurrencyField;
	
	@FindBy(xpath = "//input[@name='merchant_name']")
	private WebElement merchantName;
	
	@FindBy(xpath = "//input[@name='txn_error_code']")
	private WebElement errorCode;
	
	@FindBy(xpath = "//span[contains(text(),'Select Error Description')]")
	private WebElement ErrorDescription;
	
	
	@FindBy(xpath = "//label[contains(text(),'1.0.2')]")
	private WebElement ProtocolVersionOneDotO;
	
	@FindBy(xpath = "//span[contains(text(),'1.0.2')]")
	private WebElement ProtocolVersionOneDotOSelected;
	
	@FindBy(xpath = "//label[contains(text(),'2.1.0')]")
	private WebElement ProtocolVersionTwoDotO;
	
	@FindBy(xpath = "//span[contains(text(),'2.1.0')]")
	private WebElement ProtocolVersionTwoDotOSelected;
	
	@FindBy(xpath = "//a[contains(text(),'Clear All')]")
	private WebElement ClearTheFiltersText;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]")
	private WebElement txnFirstRecordInTheList;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[3]")
	private WebElement txnRecordCardNumber;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[4]")
	private WebElement txnRecordProtocalVersion;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[5]")
	private WebElement txnRecordMerchantName;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[6]")
	private WebElement txnRecordTxnAmount;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[7]")
	private WebElement txnRecordTxnType;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[8]")
	private WebElement txnRecordCardType;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[9]")
	private WebElement txnRecordTxnCardUnion;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[9]/img")
	private WebElement txnRecordTxnCardUnionImage;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[10]")
	private WebElement txnRecordDataCenter;

	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[11]")
	private WebElement txnRecordDeviceChannel;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[12]")
	private WebElement txnRecordAuthType;
	
	@FindBy(xpath = "//div[contains(@class,'flex-table__body')]/div[1]/div[13]")
	private WebElement txnRecordStatus;

	@FindBy(xpath = "//a[contains(text(),'Fetch Report')]")
	private WebElement fetchReportButton;

	@FindBy(xpath = "//div[@class='flex-table__body']")
	private WebElement recordRow;

	@FindBy(xpath = "//span[@class='err_desc']")
	private WebElement errorDescText;

	@FindBy(xpath = "//span[@class='total-count']")
	private WebElement totalItemCount;

	@FindBy(xpath = "(//*[@class='date-picker'])[2]")
	private WebElement datePicker;

	@FindBy(xpath = "//*[@class='date-picker']")
	private WebElement datePickerWithoutToggle;

	@FindBy(xpath = "//div[span[text()='Card Number']]/div/span")
	private WebElement acstxnDetailPageCardNumberValue;

	@FindBy(xpath = "//div[span[text()='ECI indicator']]/div/span")
	private WebElement acstxnDetailPageECIindicatorValue;

	@FindBy(xpath = "//div[span[text()='Merchant Name']]/div/span")
	private WebElement acstxnDetailPageMerchantNameValue;

	@FindBy(xpath = "//div[span[text()='Card Type']]/div/span")
	private WebElement acstxnDetailPageCardTypeValue;

	@FindBy(xpath = "//div[span[text()='Acquirer Bin']]/div/span")
	private WebElement acstxnDetailPageAcquirerBinValue;

	@FindBy(xpath = "//div[span[text()='Transaction Amount']]/div/span")
	private WebElement acstxnDetailPageTransactionAmountValue;
	
	@FindBy(xpath = "//div[span[text()='Transaction Type']]/div/span")
	private WebElement acstxnDetailPageTransactionTypeValue;	

	@FindBy(xpath = "//div[span[text()='Authentication flow type']]/div/span")
	private WebElement acstxnDetailPageAuthenticationFlowTypeValue;

	@FindBy(xpath = "//div[span[text()='Device Channel']]/div/span")
	private WebElement acstxnDetailPageDeviceChannelValue;

	@FindBy(xpath = "//div[span[text()='CAVV']]/div/span")
	private WebElement acstxnDetailPageCAVVValue;

	@FindBy(xpath = "//div[span[text()='AAV']]/div/span")
	private WebElement acstxnDetailPageAAVValue;

	@FindBy(xpath = "//div[span[text()='Risk engine Client ID']]/div/span")
	private WebElement acstxnDetailPageRiskengineClientIDValue;

	@FindBy(xpath = "//div[span[text()='Risk Score']]/div/span")
	private WebElement acstxnDetailPageRiskScoreValue;

	@FindBy(xpath = "//div[span[text()='Risk Suggestion']]/div/span")
	private WebElement acstxnDetailPageRiskSuggestionValue;
	
	@FindBy(xpath = "//div[span[text()='Error Description']]/div")
	private WebElement acstxnDetailPageErrorDescription;

	// Detailed Transaction Output
	@FindBy(xpath = "(//h4[text()='Detailed Transaction Output']/../following::div/div/a[1])[1]")
	private WebElement detailedTransactionOutputExpandLink;
						
	//@FindBy(xpath = "//div[@class='flex-table__cell column is-narrow xl newclass'][normalize-space()='message_catagory']/div/div[1]")
	@FindBy(xpath = "//div[div[text()='message_catagory']]/div[2]")
	private WebElement messageCategory;
	
	@FindBy(xpath = "//div[div[text()='message_extension']]/div[2]")
	private WebElement messageExtension;
	

	@FindBy(xpath = "//a[contains(text(),'Audit log')]")
	private WebElement transactionAuditLogs;

	@FindBy(xpath = "//th[contains(text(),'CUSTOMER JOURNEY')]")
	private WebElement customerJourneyLabel;
	
	//OTP detail module
	@FindBy(xpath = "(//*[text()='OTP Details']/../../following::div/div/a[1])[1]")
	private WebElement otpDetailPlusSign;
	
	@FindBy(xpath = "//span[contains(text(),'Email ID')]/../div/span[1]")
	private WebElement otpDetailEmailIdText;
	
	@FindBy(xpath = "//span[contains(text(),'Mobile Number')]/../div/span[1]")
	private WebElement otpDetailMobileNoText;
	
	@FindBy(xpath = "//span[contains(text(),'Maximum allowed OTP attempts')]/../div/span[1]")
	private WebElement otpDetailMaximumAllowedOTPAttempsText;
	
	@FindBy(xpath = "//span[contains(text(),'Resend OTP Count')]/../div/span[1]")
	private WebElement otpDetailResendOtpCountText;
	
	@FindBy(xpath = "//span[contains(text(),'Invalid OTP Attempts')]/../div/span[1]")
	private WebElement otpDetailInvalidOtpAttemptsText;
	
	@FindBy(xpath = "//span[contains(text(),'Last OTP Status')]/../div/span[1]")
	private WebElement otpDetailLastOtpStatusText;
	
	//AuditLogs Technical Information
	
	@FindBy(xpath = "//span[@data-tip='TECHNICAL INFORMATION']")
	private WebElement AuditLogsTechInfoPlusButton;
	
	@FindBy(xpath = "//a[contains(text(),'Download Report')]")
	private WebElement downloadReportButton;
	
	
	@FindBy(xpath = "//div[div[text()='trans_status']]/div[2]")
	private WebElement aatransStatus;
	
	@FindBy(xpath = "//a[contains(text(),'Areq / Ares')]")
	private WebElement AreqAres;

	@FindBy(xpath = "//a[contains(text(),'Creq / Cres')]")
	private WebElement CreqCres;
	
	@FindBy(xpath = "//a[contains(text(),'Rreq / Rres')]")
	private WebElement RreqRres;
	
	@FindBy(xpath = "//a[contains(text(),'Audit log')]")
	private WebElement Auditlog;
	
	
	
	@FindBy(xpath = "//input[@name='merchant_id']")
	private WebElement merchantId;
	
	@FindBy(xpath = "//input[@name='ds_txn_id']")
	private WebElement dsTransactionId;
		
	@FindBy(xpath = "//span[contains(text(),'Select Authentication Flow Type')]")
	private WebElement authenticationFlowType;
	
	@FindBy(xpath = "//input[@name='risk_score_range_from']")
	private WebElement riskScoreRangeFrom;
	
	@FindBy(xpath = "//input[@name='risk_score_range_to']")
	private WebElement riskScoreRangeTo;
	
	@FindBy(xpath = "//input[@name='amount_range_from']")
	private WebElement amountRangeFrom;
	
	@FindBy(xpath = "//input[@name='amount_range_to']")
	private WebElement amountRangeTo;	
	
	@FindBy(xpath = "//div[span[text()='EMI MONTH']]/div")
	private WebElement acstxnDetailPageEMIMonth;
	
	@FindBy(xpath = "//div[span[text()='EMI AMOUNT']]/div")
	private WebElement acstxnDetailPageEMIAmount;
	
	
	
	
	public WebElement getAcstxnDetailPageEMIMonth() {
		return acstxnDetailPageEMIMonth;
	}
	public WebElement getAcstxnDetailPageEMIAmount() {
		return acstxnDetailPageEMIAmount;
	}
	public WebElement getAmountRangeTo() {
		return amountRangeTo;
	}
	public WebElement getAmountRangeFrom() {
		return amountRangeFrom;
	}
	public WebElement getRiskScoreRangeTo() {
		return riskScoreRangeTo;
	}
	public WebElement getRiskScoreRangeFrom() {
		return riskScoreRangeFrom;
	}	
	public WebElement getAuthFlowType() {
		return authenticationFlowType;
	}	
	public WebElement getDSTransactionId() {
		return dsTransactionId;
	}
	public WebElement getMerchantId() {
		return merchantId;
	}
		
	public WebElement getAcsResetButton() {
		return acsResetButton;
	}
	
	public WebElement getAuditLogsTechInfoPlusButton() {
		return AuditLogsTechInfoPlusButton;
	}

	public WebElement getFrom_DateInfoText() {
		return from_DateInfoText;
	}

	public WebElement getTo_DateInfoText() {
		return to_DateInfoText;
	}
	
	public WebElement getOtpDetailPlusSign() {
		return otpDetailPlusSign;
	}

	public WebElement getOtpDetailEmailIdText() {
		return otpDetailEmailIdText;
	}

	public WebElement getOtpDetailMobileNoText() {
		return otpDetailMobileNoText;
	}

	public WebElement getOtpDetailMaximumAllowedOTPAttempsText() {
		return otpDetailMaximumAllowedOTPAttempsText;
	}

	public WebElement getOtpDetailResendOtpCountText() {
		return otpDetailResendOtpCountText;
	}

	public WebElement getOtpDetailInvalidOtpAttemptsText() {
		return otpDetailInvalidOtpAttemptsText;
	}

	public WebElement getOtpDetailLastOtpStatusText() {
		return otpDetailLastOtpStatusText;
	}

	public WebElement getDetailedTransactionOutputExpandLink() {
		return detailedTransactionOutputExpandLink;
	}
	
	public WebElement getMessageCategory() {
		return messageCategory;
	}
	
	public WebElement getMessageExtension() {
		return messageExtension;
	}

	public WebElement getTransactionAuditLogs() {
		return transactionAuditLogs;
	}

	public WebElement getCustomerJourneyLabel() {
		return customerJourneyLabel;
	}

	public WebElement getAcstxnDetailPageRiskScoreValue() {
		return acstxnDetailPageRiskScoreValue;
	}

	public WebElement getAcstxnDetailPageRiskSuggestionValue() {
		return acstxnDetailPageRiskSuggestionValue;
	}
	
	public WebElement getAcstxnDetailPageErrorDescription() {
		return acstxnDetailPageErrorDescription;
	}

	public WebElement getAcsCalenderIcon() {
		return acsCalenderIcon;
	}

	public WebElement getAcsLeftHoursSelect() {
		return acsLeftHoursSelect;
	}

	public WebElement getAcstxnDetailPageCardNumberValue() {
		return acstxnDetailPageCardNumberValue;
	}

	public WebElement getAcstxnDetailPageECIindicatorValue() {
		return acstxnDetailPageECIindicatorValue;
	}

	public WebElement getAcstxnDetailPageMerchantNameValue() {
		return acstxnDetailPageMerchantNameValue;
	}

	public WebElement getAcstxnDetailPageCardTypeValue() {
		return acstxnDetailPageCardTypeValue;
	}

	public WebElement getAcstxnDetailPageAcquirerBinValue() {
		return acstxnDetailPageAcquirerBinValue;
	}

	public WebElement getAcstxnDetailPageTransactionAmountValue() {
		return acstxnDetailPageTransactionAmountValue;
	}
	
	public WebElement getAcstxnDetailPageTransactionTypeValue() {
		return acstxnDetailPageTransactionTypeValue;
	}
	

	public WebElement getAcstxnDetailPageAuthenticationFlowTypeValue() {
		return acstxnDetailPageAuthenticationFlowTypeValue;
	}

	public WebElement getAcstxnDetailPageDeviceChannelValue() {
		return acstxnDetailPageDeviceChannelValue;
	}

	public WebElement getAcstxnDetailPageCAVVValue() {
		return acstxnDetailPageCAVVValue;
	}

	public WebElement getAcstxnDetailPageAAVValue() {
		return acstxnDetailPageAAVValue;
	}

	public WebElement getAcstxnDetailPageRiskengineClientIDValue() {
		return acstxnDetailPageRiskengineClientIDValue;
	}

	public WebElement getTxnFirstRecordInTheList() {
		return txnFirstRecordInTheList;
	}

	public WebElement getTxnRecordCardNumber() {
		return txnRecordCardNumber;
	}

	public WebElement getTxnRecordProtocalVersion() {
		return txnRecordProtocalVersion;
	}

	public WebElement getTxnRecordStatus() {
		return txnRecordStatus;
	}

	public WebElement getAcsAdevanceSearchButton() {
		return acsAdevanceSearchButton;
	}

	public WebElement getDatePickerButton() {
		return datePickerButton;
	}

	public WebElement getFromDate() {
		return fromDate;
	}

	public WebElement getFromTimeRange() {
		return fromTimeRange;
	}

	public WebElement getHoursSelect() {
		return hoursSelect;
	}

	public WebElement getTxnRecordTxnType() {
		return txnRecordTxnType;
	}

	public WebElement getMinutesSelect() {
		return minutesSelect;
	}

	public WebElement getActiveEndDateCurrentMonth() {
		return activeEndDateCurrentMonth;
	}

	public WebElement getEndDateCurrentMonth() {
		return EndDateCurrentMonth;
	}

	public WebElement getEndDateHoursSelect() {
		return endDateHoursSelect;
	}

	public WebElement getEndDateMinutes() {
		return endDateMinutes;
	}

	public WebElement getApplyButton() {
		return applyButton;
	}

	public WebElement getAcsTxnIDTextField() {
		return acsTxnIDTextField;
	}

	public WebElement getCardNumberTextField() {
		return cardNumberTextField;
	}

	public WebElement getTransactionStatusField() {
		return TransactionStatusField;
	}

	public WebElement getTransactionStatusFailure() {
		return TransactionStatusFailure;
	}

	public WebElement getTransactionStatusRejected() {
		return TransactionStatusRejected;
	}

	public WebElement getTxnRecordMerchantName() {
		return txnRecordMerchantName;
	}

	public WebElement getTxnRecordAuthType() {
		return txnRecordAuthType;
	}

	public WebElement getTxnRecordTxnAmount() {
		return txnRecordTxnAmount;
	}

	public WebElement getFetchReportButton() {
		return fetchReportButton;
	}

	public WebElement getRecordRow() {
		return recordRow;
	}
	// Detail page web Elements.

	public WebElement getDatePickerWithoutToggle() {
		return datePickerWithoutToggle;
	}

	public WebElement getDatePicker() {
		return datePicker;
	}

	public WebElement getTotalItemCount() {
		return totalItemCount;
	}

	public WebElement getErrorDescText() {
		return errorDescText;
	}

	public WebElement getTransactionStatusSuccess() {
		return TransactionStatusSuccess;
	}

	public WebElement getAuthenticationTypeField() {
		return AuthenticationTypeField;
	}

	public WebElement getAuthenticationTypeFrictionLess() {
		return AuthenticationTypeFrictionLess;
	}

	public WebElement getAuthenticationTypeChallenge() {
		return AuthenticationTypeChallenge;
	}

	public WebElement getDeviceChannelField() {
		return DeviceChannelField;
	}

	public WebElement getDeviceChannelBrowser() {
		return DeviceChannelBrowser;
	}

	public WebElement getDeviceChannelApp() {
		return DeviceChannelApp;
	}

	public WebElement getCardUnionField() {
		return CardUnionField;
	}

	public WebElement getCardUnionMaster() {
		return CardUnionMaster;
	}

	public WebElement getCardUnionVisa() {
		return CardUnionVisa;
	}

	public WebElement getCardUnionDiners() {
		return CardUnionDiners;
	}

	public WebElement getCardUnionRuPay() {
		return CardUnionRuPay;
	}

	public WebElement getCardTypeField() {
		return CardTypeField;
	}

	public WebElement getCardTypeDebit() {
		return CardTypeDebit;
	}

	public WebElement getCardTypeCredit() {
		return CardTypeCredit;
	}

	public WebElement getCardTypePrepaid() {
		return CardTypePrepaid;
	}

	public WebElement getBinNumberField() {
		return BinNumberField;
	}

	public WebElement getBinNumberSearchField() {
		return BinNumberSearchField;
	}
	
	public WebElement getDataCenterField() {
		return DataCenterField;
	}

	public WebElement getDataCenterBlr() {
		return DataCenterBlr;
	}

	public WebElement getBinNumberSearchedCheckBox() {
		return BinNumberSearchedCheckBox;
	}

	public WebElement getRuleSetIdField() {
		return RuleSetIdField;
	}

	public WebElement getRuleSetIdSearchField() {
		return RuleSetIdSearchField;
	}

	public WebElement getRuleSetIdSearchedCheckBox() {
		return RuleSetIdSearchedCheckBox;
	}

	public WebElement getProductionNodeField() {
		return ProductionNodeField;
	}

	public WebElement getRiskEngineClientIdField() {
		return RiskEngineClientIdField;
	}

	public WebElement getTransactionTypeField() {
		return TransactionTypeField;
	}

	public WebElement getTransactionTypeECOM() {
		return TransactionTypeECOM;
	}

	public WebElement getTransactionTypeIVR() {
		return TransactionTypeIVR;
	}

	public WebElement getTransactionTypeExpressPay() {
		return TransactionTypeExpressPay;
	}
	
	public WebElement getTransactionTypeBepg() {
		return TransactionTypeBEPG;
	}
	
	public WebElement getTransactionTypeRedirection() {
		return TransactionTypeRedirection;
	}
	
	public WebElement getTransactionTypeITP() {
		return TransactionTypeITP;
	}

	public WebElement getClientIdField() {
		return ClientIdField;
	}

	public WebElement getClientIdAMAZON() {
		return ClientIdAMAZON;
	}

	public WebElement getClientIdPAYU() {
		return ClientIdPAYU;
	}

	public WebElement getProtocolVersionField() {
		return ProtocolVersionField;
	}
	
	public WebElement getCurrencyField() {
		return CurrencyField;
	}
	
	public WebElement getMerchantNameField() {
		return merchantName;
	}
	
	public WebElement getErrorCodeField() {
		return errorCode;
	}
	
	public WebElement getErrorDescriptionField() {
		return ErrorDescription;
	}

	public WebElement getProtocolVersionOneDotO() {
		return ProtocolVersionOneDotO;
	}

	public WebElement getProtocolVersionTwoDotO() {
		return ProtocolVersionTwoDotO;
	}

	public WebElement getProtocolVersionOneDotOSelected() {
		return ProtocolVersionOneDotOSelected;
	}

	public WebElement getProtocolVersionTwoDotOSelected() {
		return ProtocolVersionTwoDotOSelected;
	}

	public WebElement getTxnRecordCardType() {
		return txnRecordCardType;
	}

	public WebElement getTxnRecordTxnCardUnion() {
		return txnRecordTxnCardUnion;
	}

	public WebElement getTxnRecordDataCenter() {
		return txnRecordDataCenter;
	}

	public WebElement getTxnRecordDeviceChannel() {
		return txnRecordDeviceChannel;
	}

	public WebElement getClearTheFiltersText() {
		return ClearTheFiltersText;
	}

	public WebElement getTxnRecordTxnCardUnionImage() {
		return txnRecordTxnCardUnionImage;
	}
	
	public WebElement getDropDownFormatIcon() {
		return dropDownFormatIcon;
	}
	
	public WebElement getDownloadReportButton() {
		return downloadReportButton;
	}
	
	public WebElement getAatransStatus() {
		return aatransStatus;
	}
	
	public WebElement getAreqAres() {
		return AreqAres;
	}
	
	public WebElement getCreqCres() {
		return CreqCres;
	}
	
	public WebElement getRreqRres() {
		return RreqRres;
	}
	
	public WebElement getAuditLog() {
		return Auditlog;
	}
	
	
	
}

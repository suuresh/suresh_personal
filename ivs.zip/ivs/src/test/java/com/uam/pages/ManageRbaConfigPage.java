package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageRbaConfigPage {

	public WebDriver driver;

	public ManageRbaConfigPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//li[text()='Manage RBA Config']")
	private WebElement manageRbaConfigLink;

	@FindBy(xpath = "//li[text()='Issuer Bin Range Configurations']")
	private WebElement issuerBinRangeConfigLink;

	@FindBy(xpath = "//a[text()='ADD NEW RULE SET']")
	private WebElement addNewRuleSetButton;

	// Page DropDown
	@FindBy(xpath = "//a[@aria-controls='dropdown-menu']/span[@class='dropdown-trigger-item']")
	private WebElement perPageDropdown;

	@FindBy(xpath = "//label[text()='10 per page']")
	private WebElement perPage10_DropdownList;

	@FindBy(xpath = "//label[text()='20 per page']")
	private WebElement perPage20_DropdownList;

	@FindBy(xpath = "//label[text()='30 per page']")
	private WebElement perPage30_DropdownList;

	// Add Rule Set Page
	@FindBy(xpath = "//input[@placeholder='Rule Set Name']")
	private WebElement ruleSetNameTextField;

	@FindBy(xpath = "//span[text()='Select Rule Set Status']")
	private WebElement ruleSetStatusDropdown;

	@FindBy(xpath = "//label[text()='Active']")
	private WebElement activeRuleSetStatusDropdown;

	@FindBy(xpath = "//label[text()='Inactive']")
	private WebElement inActiveRuleSetStatusDropdown;

	// Default Mode Of Authentication
	@FindBy(xpath = "//div[text()='Default Mode of Authentication']/following::div[@class='dropdown dropdown--type3 is-active']/div/a")
	private WebElement defaultModeOfAuthenticationDropdown;

	@FindBy(xpath = "//label[@for='OTP0']")
	private WebElement otpModeOfAuthenticationDropdownlist;

	@FindBy(xpath = "//label[@for='Frictionless1']")
	private WebElement frictionlessModeOfAuthenticationDropdownlist;

	@FindBy(xpath = "//label[@for='Deny/Decline2']")
	private WebElement denyModeOfAuthenticationDropdownlist;

	@FindBy(xpath = "//input[@placeholder='Rule Set Description']")
	private WebElement ruleSetDescTextField;

	// Create New Rule- Rule priority #1
	@FindBy(xpath = "//span[text()='+ CREATE NEW RULE']")
	private WebElement createNewRuleIcon;

	@FindBy(xpath = "//label[text()='AND']")
	private WebElement AND_RadioButton;

	@FindBy(xpath = "//label[text()='OR']")
	private WebElement OR_RadiButton;

	@FindBy(xpath = "(//*[text()='Condition'])[1]")
	private WebElement plusConditionButton;

	@FindBy(xpath = "(//*[text()='Group'])[1]")
	private WebElement plusGroupButton;

	@FindBy(xpath = "(//div[@class='main__wrapper']//li[3]//*[local-name()='svg'])[1]")
	private WebElement deleteIcon;

	// Common xpath for parameter, Condition and value
	@FindBy(xpath = "(//span[text()='parameter'])[1]")
	private WebElement firstParameterDropdown;

	@FindBy(xpath = "(//span[text()='parameter'])[1]")
	private WebElement secondParameterDropdown;

	@FindBy(xpath = "(//span[text()='parameter'])[1]")
	private WebElement thirdParameterDropdown;

	@FindBy(xpath = "(//span[text()='condition'])[1]")
	private WebElement firstConditionDropdown;

	@FindBy(xpath = "(//span[text()='condition'])[1]")
	private WebElement secondConditionDropdown;

	@FindBy(xpath = "(//input[@placeholder='value'])[1]")
	private WebElement firstValueTextField;

	@FindBy(xpath = "(//input[@placeholder='value'])[2]")
	private WebElement secondValueTextField;

	@FindBy(xpath = "(//span[text()='value'])[1]")
	private WebElement firstValueDropdown;

	@FindBy(xpath = "(//span[text()='value'])[1]")
	private WebElement secondValueDropdown;

	// And Parameter DropdownList
	@FindBy(xpath = "//a[text()='Risk Engine Score']")
	private WebElement riskEngineScoreDropdownList;

	@FindBy(xpath = "//a[text()='Risk Engine Suggestion']")
	private WebElement riskEngineSuggestionDropdownlist;

	@FindBy(xpath = "//a[text()='Merchant Name']")
	private WebElement merchantNameDropdownList;

	@FindBy(xpath = "//a[text()='Amount']")
	private WebElement amountDropdownList;

	@FindBy(xpath = "//a[text()='Transaction Type']")
	private WebElement transactionTypeDropdownList;

	@FindBy(xpath = "//a[text()='Merchant Category Code']")
	private WebElement merchantCategoryCodeDropdownList;

	@FindBy(xpath = "//a[text()='Merchant Id']")
	private WebElement merchantIdDropdownList;

	// Sub-part of Risk Engine Score

	@FindBy(xpath = "//span[text()='condition']")
	private WebElement RiskEngineScore_conditionDropdown;

	@FindBy(xpath = "//a[text()='Equals']")
	private WebElement RiskEngineScor_equalsDropdownList;

	@FindBy(xpath = "//a[text()='< Less than']")
	private WebElement RiskEngineScor_lessThanDropdownList;

	@FindBy(xpath = "//a[text()='> Greater than']")
	private WebElement RiskEngineScor_greatetThanDropdownList;

	@FindBy(xpath = "//a[text()='<= Less than Equal to']")
	private WebElement RiskEngineScor_lessThanEqualToDropdownList;

	@FindBy(xpath = "//a[text()='>= Greater than Equal to']")
	private WebElement RiskEngineScor_greaterThanEqualToDropdownList;

	@FindBy(xpath = "//a[text()='Between']")
	private WebElement RiskEngineScor_betweenDropdownList;

	@FindBy(xpath = "//input[@placeholder='value']")
	private WebElement RiskEngineScor_valueTextField;

	// Sub-part of Risk Engine Suggestion

	@FindBy(xpath = "(//span[text()='value'])[1]")
	private WebElement RES_valueDropdown;

	@FindBy(xpath = "//a[text()='DENY']")
	private WebElement RES_denyDropdownList;

	@FindBy(xpath = "//a[text()='CRITICAL']")
	private WebElement RES_criticalDropdownList;

	@FindBy(xpath = "//a[text()='HIGH']")
	private WebElement RES_highDropdownList;

	@FindBy(xpath = "//a[text()='MEDIUM']")
	private WebElement RES_mediumDropdownList;

	@FindBy(xpath = "//a[text()='LOW']")
	private WebElement RES_lowDropdownList;

	@FindBy(xpath = "//a[text()='ACCEPT']")
	private WebElement RES_acceptDropdownList;

	// Sub part of Merchant Name

	@FindBy(xpath = "(//span[text()='condition'])[1]")
	private WebElement MerchantName_ConditionsDropdown;

	@FindBy(xpath = "//a[text()='Equals']")
	private WebElement MerchantName_EqualsDropdownList;

	@FindBy(xpath = "//a[text()='Contains']")
	private WebElement MerchantName_ContainsDropdown;

	@FindBy(xpath = "//a[text()='Does not contain']")
	private WebElement MerchantName_DoesNotContainsDropdown;

	@FindBy(xpath = "(//input[@placeholder='value'])[1]")
	private WebElement MerchantName_ValueTextField;

	// Sub-part of Amount

	@FindBy(xpath = "(//span[text()='condition'])[1]")
	private WebElement Amount_conditionDropdown;

	@FindBy(xpath = "//a[text()='Equals']")
	private WebElement Amount_equalsDropdownList;

	@FindBy(xpath = "//a[text()='< Less than']")
	private WebElement Amount_lessThanDropdownList;

	@FindBy(xpath = "//a[text()='> Greater than']")
	private WebElement Amount_greatetThanDropdownList;

	@FindBy(xpath = "//a[text()='<= Less than Equal to']")
	private WebElement Amount_lessThanEqualToDropdownList;

	@FindBy(xpath = "//a[text()='>= Greater than Equal to']")
	private WebElement Amount_greaterThanEqualToDropdownList;

	@FindBy(xpath = "//a[text()='Between']")
	private WebElement Amount_betweenDropdownList;

	@FindBy(xpath = "//input[@placeholder='value']")
	private WebElement Amount_valueTextField;

	// Sub Part of Transaction Type

	@FindBy(xpath = "(//span[text()='value'])[1]")
	private WebElement TransactionType_valueDropdown;

	@FindBy(xpath = "(//a[text()='E-commerce'])[1]")
	private WebElement TransactionType_E_Commerce;

	@FindBy(xpath = "(//a[text()='Non-payment'])[1]")
	private WebElement TransactionType_Non_payment;

	@FindBy(xpath = "(//a[text()='IVR'])[1]")
	private WebElement TransactionType_IVR;

	// Sub part of Merchant Category Code
	@FindBy(xpath = "(//input[@placeholder='value'])[1]")
	private WebElement MerchantCategoryCode_valueTextField;

	// Sub part of merchant id
	@FindBy(xpath = "(//input[@placeholder='value'])[1]")
	private WebElement MerchantId_valueTextField;

	// Mode of Authentication
	@FindBy(xpath = "//span[text()='Select']")
	private WebElement ModeOfAuthDropdown;

	@FindBy(xpath = "(//a[text()='OTP'])[1]")
	private WebElement ModeOfAuth_Otp;

	@FindBy(xpath = "(//a[text()='Frictionless'])[1]")
	private WebElement ModeOfAuth_Frictionless;

	@FindBy(xpath = "(//a[text()='Deny/Decline'])[1]")
	private WebElement ModeOfAuth_DenyDecline;

	// Save button
	@FindBy(xpath = "//a[text()='Save Changes']")
	private WebElement saveChangesButton;

	@FindBy(xpath = "//a[text()='Cancel']")
	private WebElement cancelButton;

	@FindBy(xpath = "//a[text()='Clone Rule Set']")
	private WebElement cloneRuleSetButton;

	public WebElement getManageRbaConfigLink() {
		return manageRbaConfigLink;
	}

	public WebElement getAddNewRuleSetButton() {
		return addNewRuleSetButton;
	}

	public WebElement getPerPageDropdown() {
		return perPageDropdown;
	}

	public WebElement getPerPage10_DropdownList() {
		return perPage10_DropdownList;
	}

	public WebElement getPerPage20_DropdownList() {
		return perPage20_DropdownList;
	}

	public WebElement getPerPage30_DropdownList() {
		return perPage30_DropdownList;
	}

	public WebElement getRuleSetNameTextField() {
		return ruleSetNameTextField;
	}

	public WebElement getRuleSetStatusDropdown() {
		return ruleSetStatusDropdown;
	}

	public WebElement getActiveRuleSetStatusDropdown() {
		return activeRuleSetStatusDropdown;
	}

	public WebElement getInActiveRuleSetStatusDropdown() {
		return inActiveRuleSetStatusDropdown;
	}

	public WebElement getDefaultModeOfAuthenticationDropdown() {
		return defaultModeOfAuthenticationDropdown;
	}

	public WebElement getOtpModeOfAuthenticationDropdownlist() {
		return otpModeOfAuthenticationDropdownlist;
	}

	public WebElement getFrictionlessModeOfAuthenticationDropdownlist() {
		return frictionlessModeOfAuthenticationDropdownlist;
	}

	public WebElement getDenyModeOfAuthenticationDropdownlist() {
		return denyModeOfAuthenticationDropdownlist;
	}

	public WebElement getRuleSetDescTextField() {
		return ruleSetDescTextField;
	}

	public WebElement getCreateNewRuleIcon() {
		return createNewRuleIcon;
	}

	public WebElement getAND_RadioButton() {
		return AND_RadioButton;
	}

	public WebElement getOR_RadiButton() {
		return OR_RadiButton;
	}

	public WebElement getPlusConditionButton() {
		return plusConditionButton;
	}

	public WebElement getPlusGroupButton() {
		return plusGroupButton;
	}

	public WebElement getDeleteIcon() {
		return deleteIcon;
	}

	public WebElement getFirstParameterDropdown() {
		return firstParameterDropdown;
	}

	public WebElement getSecondParameterDropdown() {
		return secondParameterDropdown;
	}

	public WebElement getThirdParameterDropdown() {
		return thirdParameterDropdown;
	}

	public WebElement getRiskEngineScoreDropdownList() {
		return riskEngineScoreDropdownList;
	}

	public WebElement getRiskEngineSuggestionDropdownlist() {
		return riskEngineSuggestionDropdownlist;
	}

	public WebElement getMerchantNameDropdownList() {
		return merchantNameDropdownList;
	}

	public WebElement getAmountDropdownList() {
		return amountDropdownList;
	}

	public WebElement getTransactionTypeDropdownList() {
		return transactionTypeDropdownList;
	}

	public WebElement getMerchantCategoryCodeDropdownList() {
		return merchantCategoryCodeDropdownList;
	}

	public WebElement getMerchantIdDropdownList() {
		return merchantIdDropdownList;
	}

	public WebElement getFirstConditionDropdown() {
		return firstConditionDropdown;
	}

	public WebElement getRiskEngineScor_equalsDropdownList() {
		return RiskEngineScor_equalsDropdownList;
	}

	public WebElement getRiskEngineScor_lessThanDropdownList() {
		return RiskEngineScor_lessThanDropdownList;
	}

	public WebElement getRiskEngineScor_greatetThanDropdownList() {
		return RiskEngineScor_greatetThanDropdownList;
	}

	public WebElement getRiskEngineScor_lessThanEqualToDropdownList() {
		return RiskEngineScor_lessThanEqualToDropdownList;
	}

	public WebElement getRiskEngineScor_greaterThanEqualToDropdownList() {
		return RiskEngineScor_greaterThanEqualToDropdownList;
	}

	public WebElement getRiskEngineScor_betweenDropdownList() {
		return RiskEngineScor_betweenDropdownList;
	}

	public WebElement getRiskEngineScor_valueTextField() {
		return RiskEngineScor_valueTextField;
	}

	public WebElement getRES_valueDropdown() {
		return RES_valueDropdown;
	}

	public WebElement getRES_denyDropdownList() {
		return RES_denyDropdownList;
	}

	public WebElement getRES_criticalDropdownList() {
		return RES_criticalDropdownList;
	}

	public WebElement getRES_highDropdownList() {
		return RES_highDropdownList;
	}

	public WebElement getRES_mediumDropdownList() {
		return RES_mediumDropdownList;
	}

	public WebElement getRES_lowDropdownList() {
		return RES_lowDropdownList;
	}

	public WebElement getRES_acceptDropdownList() {
		return RES_acceptDropdownList;
	}

	public WebElement getMerchantName_ConditionsDropdown() {
		return MerchantName_ConditionsDropdown;
	}

	public WebElement getMerchantName_EqualsDropdownList() {
		return MerchantName_EqualsDropdownList;
	}

	public WebElement getMerchantName_ContainsDropdown() {
		return MerchantName_ContainsDropdown;
	}

	public WebElement getMerchantName_DoesNotContainsDropdown() {
		return MerchantName_DoesNotContainsDropdown;
	}

	public WebElement getAmount_conditionDropdown() {
		return Amount_conditionDropdown;
	}

	public WebElement getAmount_equalsDropdownList() {
		return Amount_equalsDropdownList;
	}

	public WebElement getAmount_lessThanDropdownList() {
		return Amount_lessThanDropdownList;
	}

	public WebElement getAmount_greatetThanDropdownList() {
		return Amount_greatetThanDropdownList;
	}

	public WebElement getAmount_lessThanEqualToDropdownList() {
		return Amount_lessThanEqualToDropdownList;
	}

	public WebElement getAmount_greaterThanEqualToDropdownList() {
		return Amount_greaterThanEqualToDropdownList;
	}

	public WebElement getAmount_betweenDropdownList() {
		return Amount_betweenDropdownList;
	}

	public WebElement getAmount_valueTextField() {
		return Amount_valueTextField;
	}

	public WebElement getTransactionType_valueDropdown() {
		return TransactionType_valueDropdown;
	}

	public WebElement getTransactionType_E_Commerce() {
		return TransactionType_E_Commerce;
	}

	public WebElement getTransactionType_Non_payment() {
		return TransactionType_Non_payment;
	}

	public WebElement getTransactionType_IVR() {
		return TransactionType_IVR;
	}

	public WebElement getMerchantCategoryCode_valueTextField() {
		return MerchantCategoryCode_valueTextField;
	}

	public WebElement getMerchantId_valueTextField() {
		return MerchantId_valueTextField;
	}

	public WebElement getModeOfAuthDropdown() {
		return ModeOfAuthDropdown;
	}

	public WebElement getModeOfAuth_Otp() {
		return ModeOfAuth_Otp;
	}

	public WebElement getModeOfAuth_Frictionless() {
		return ModeOfAuth_Frictionless;
	}

	public WebElement getModeOfAuth_DenyDecline() {
		return ModeOfAuth_DenyDecline;
	}

	public WebElement getSaveChangesButton() {
		return saveChangesButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getCloneRuleSetButton() {
		return cloneRuleSetButton;
	}

	public WebElement getMerchantName_ValueTextField() {
		return MerchantName_ValueTextField;
	}

	public WebElement getIssuerBinRangeConfigLink() {
		return issuerBinRangeConfigLink;
	}

	public WebElement getSecondConditionDropdown() {
		return secondConditionDropdown;
	}

	public void setFirstConditionDropdown(WebElement firstConditionDropdown) {
		this.firstConditionDropdown = firstConditionDropdown;
	}

	public WebElement getFirstValueTextField() {
		return firstValueTextField;
	}

	public WebElement getSecondValueTextField() {
		return secondValueTextField;
	}

	public WebElement getRiskEngineScore_conditionDropdown() {
		return RiskEngineScore_conditionDropdown;
	}

	public WebElement getFirstValueDropdown() {
		return firstValueDropdown;
	}

	public WebElement getSecondValueDropdown() {
		return secondValueDropdown;
	}

}

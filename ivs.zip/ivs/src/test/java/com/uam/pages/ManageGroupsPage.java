package com.uam.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManageGroupsPage {
	
public WebDriver driver;
	
	public ManageGroupsPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//input[contains(@placeholder,'Search by Group Name')]")
	private WebElement groupSearchField;
	
	@FindBy(xpath="//a[contains(text(),'Create Group')]")
	private WebElement groupCreatePlusButton;
	
	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement groupCancelButton;
	
	@FindBy(xpath="//a[contains(text(),'Create Group')]")
	private WebElement groupCreateButton;
	
	@FindBy(xpath="//input[@placeholder='Group name']")
	private WebElement groupNameTextField;
	
	@FindBy(xpath="//input[@placeholder='first name']")
	private WebElement groupNameTextEditField;
	
	@FindBy(xpath="//a[contains(text(),'Save Changes')]")
	private WebElement groupEditSavesButton;

	@FindBy(xpath="//input[@id='root_BankID']")
	private WebElement groupBankId;
	
	@FindBy(xpath="(//a[contains(@class,'button dropdown-btn is-fullwidth')]//span[@class='dropdown-trigger-item'])[2]")
	private WebElement groupProductsSelectDropDown;
	
	@FindBy(xpath="//label[contains(text(),'ACS')]")
	private WebElement groupProductACSRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'3DS')]")
	private WebElement groupProduct3DSRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'UAM')]")
	private WebElement groupProductUAMRadioButton;
	
	@FindBy(xpath="//a[@class='button button dropdown-btn']")
	private WebElement listPerPageDropDown;
	
	@FindBy(xpath="//label[contains(text(),'10 per page')]")
	private WebElement list10PerPageRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'20 per page')]")
	private WebElement list20PerPageRadioButton;
	
	@FindBy(xpath="//label[contains(text(),'30 per page')]")
	private WebElement list30PerPageRadioButton;

	@FindBy(xpath="//input[@placeholder='Search by Group Name']")
	private WebElement seacrhByGroupName;
	
	@FindBy(xpath="//div[@class='options manage_opt'][1]//div[@class='options__edit'][1]")
	private WebElement editGroups;
	
	@FindBy(xpath="//div[@class='options manage_opt'][1]//div[@class='options__delete' and @data-tip='Assign Users'][1]")
	private WebElement assignUsersToGroup;
	
	@FindBy(xpath="//input[@class='input secondary-input is-marginless']")
	private WebElement assignUsersToGroupSearchField;
	
	@FindBy(xpath="//label[@class='checkbox__lable']")
	private WebElement assignUsersCheckBox;
	
	@FindBy(xpath="//a[@class='button primary-btn is-fullwidth  ']")
	private WebElement assignUsersButton;
	
	@FindBy(xpath="//a[@class='button secondary-btn is-fullwidth  ']")
	private WebElement assignUsersCancelButton;

	@FindBy(xpath="//div[@class='options manage_opt'][1]//div[@data-tip='Delete'][1]")
	private WebElement deleteGroups;
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column lg truncate'][1]")
	private WebElement listedGroupName;
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column sm'][1]")
	private WebElement listedProductName;
	
	@FindBy(xpath="//div[@class='flex-table__body'][1]//div[@class='flex-table__cell column sm'][2]")
	private WebElement Status;

	@FindBy(xpath="//span[text()='Group Name']")
	private WebElement groupname;
	
	@FindBy(xpath="//span[text()='Products']")
	private WebElement productname;
	
	@FindBy(xpath="//span[contains(text(),' GroupName should NOT be shorter than 8 characters')]")
	private WebElement groupnamelesschar;

	// View permission xpaths for ACS,3DSS and UAM's
	@FindBy(xpath="(//span[text()='Transaction Report']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSTrnxReportViewCheckBox;
	
	@FindBy(xpath="(//span[text()='MDD Report']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSMddReportViewCheckBox;

	@FindBy(xpath="(//span[text()='RBA Configuration']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSRbaViewCheckBox;
		
	@FindBy(xpath="(//span[text()='ACS Dashboard']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSDashboardViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage Cardholder Details']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSCardholderViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Alerts Report']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSAlertViewCheckBox;
	
	@FindBy(xpath="(//span[text()='RBA MIS']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSRbaMisViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage RBA Config']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSManageRBAViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage RBA Config']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSManageRBAManageDefaultCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage RBA Config']//following::label[@class='lbl-dis'])[3]")
	private WebElement ACSManageRBAManageMakerCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage Resources']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSManageResourceViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage Resources']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSManageResourceManageCheckBox;
	
	@FindBy(xpath="(//span[text()='Monitoring Dashboard']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSMonitoringDashboardViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Customer Data Upload']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSCustDataUploadViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Transaction Report']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsTrnxfView;
	
	@FindBy(xpath="(//span[text()='3DSS Dashboard']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsDashboardfView;
	
	@FindBy(xpath="(//span[text()='Manage 3DS RBA Configurations']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsRbaView;
	
	@FindBy(xpath="(//span[text()='Acquirer Configurations']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsacquirerView;
	
	@FindBy(xpath="(//span[text()='Maker Checker Request']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsMakerCheckerView;
	
	@FindBy(xpath="(//span[text()='Acquirer Bin Range']//following::label[@class='lbl-dis'])[1]")
	private WebElement threedsAcquirerBinView;
	
	@FindBy(xpath="(//span[text()='Manage Users']//following::label[@class='lbl-dis'])[1]")
	private WebElement UAMMngUserView;

	@FindBy(xpath="(//span[text()='Manage Banks']//following::label[@class='lbl-dis'])[1]")
	private WebElement UAMMngBankView;
	
	@FindBy(xpath="(//span[text()='Manage Groups']//following::label[@class='lbl-dis'])[1]")
	private WebElement UAMMngGrpsView;
	
	@FindBy(xpath="(//span[text()='Audit Trail']//following::label[@class='lbl-dis'])[1]")
	private WebElement UAMAuditView;
	
	//ACS Transaction Report 
	@FindBy(xpath="(//span[text()='Transaction Report']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSTransactionReportViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Transaction Report']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSTransactionReportViewClearCheckBox;
	
	//ACS RBA Configurations Check boxes
	@FindBy(xpath="(//span[text()='RBA Configuration']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSRBAConfigViewCheckBox;
	
	@FindBy(xpath="(//span[text()='RBA Configuration']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSRBAConfigManageDefaultCheckBox;
	
	@FindBy(xpath="(//span[text()='RBA Configuration']//following::label[@class='lbl-dis'])[3]")
	private WebElement ACSRBAConfigManageMakerCheckBox;
	
	@FindBy(xpath="(//span[text()='RBA Configuration']//following::label[@class='lbl-dis'])[4]")
	private WebElement ACSRBAConfigManageCheckerCheckBox;
	
	//ACS manage card block---manage permission
	@FindBy(xpath="(//span[text()='Manage Blocked Cards']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSMangeBlockCardViewCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage Blocked Cards']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSManageBlockCardManageCheckBox;
	
	@FindBy(xpath="(//span[text()='Manage Blocked Cards']//following::label[@class='lbl-dis'])[3]")
	private WebElement ACSManageBlockCardViewClearCheckBox;
	
	// ACS Card holder -- manage permission
	@FindBy(xpath="(//span[text()='Manage Cardholder Details']//following::label[@class='lbl-dis'])[1]")
	private WebElement ACSManageHolderView;
	
	@FindBy(xpath="(//span[text()='Manage Cardholder Details']//following::label[@class='lbl-dis'])[2]")
	private WebElement ACSManageHolderManage;
			
	// 3DSS RBA Config-- manage permission
	@FindBy(xpath="(//span[text()='Manage 3DS RBA Configurations']//following::label[@class='lbl-dis'])[2]")
	private WebElement threedsRbaManage;
	
	// 3DSS Acquirer BIN Range-- manage permission
	@FindBy(xpath="(//span[text()='Acquirer Bin Range']//following::label[@class='lbl-dis'])[2]")
	private WebElement threedsAcquirerBINManage;
	
	// UAM Manage user ---- manage and manage default
	@FindBy(xpath="(//span[text()='Manage Users']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMngUserManage;
	
	@FindBy(xpath="(//span[text()='Manage Users']//following::label[@class='lbl-dis'])[3]")
	private WebElement UAMMngUserManageDefault;
	
	@FindBy(xpath="(//span[text()='Manage Users']//following::label[@class='lbl-dis'])[4]")
	private WebElement UAMMngUserManageMaker;
	
	@FindBy(xpath="(//span[text()='Manage Users']//following::label[@class='lbl-dis'])[5]")
	private WebElement UAMMngUserManageChecker;
	
	// UAM Manage Banks ---- manage and manage default
	
	@FindBy(xpath="(//span[text()='Manage Banks']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMngBanksManage;
	
	@FindBy(xpath="(//span[text()='Manage Banks']//following::label[@class='lbl-dis'])[3]")
	private WebElement UAMMngBanksManageDefault;

	@FindBy(xpath="(//span[text()='Manage Banks']//following::label[@class='lbl-dis'])[4]")
	private WebElement UAMMngBanksManageMaker;

	@FindBy(xpath="(//span[text()='Manage Banks']//following::label[@class='lbl-dis'])[5]")
	private WebElement UAMMngBanksManageChecker;
	
	// UAM Manage Groups ---- manage and manage default
	
	@FindBy(xpath="(//span[text()='Manage Groups']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMnggroupsManage;
	
	@FindBy(xpath="(//span[text()='Manage Groups']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMnggroupsManageDefault;
	
	@FindBy(xpath="(//span[text()='Manage Groups']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMnggroupsManageMaker;
	
	@FindBy(xpath="(//span[text()='Manage Groups']//following::label[@class='lbl-dis'])[2]")
	private WebElement UAMMnggroupsManageChecker;
	
		
	public WebElement getAssignUsersToGroup() {
		return assignUsersToGroup;
	}

	public WebElement getAssignUsersToGroupSearchField() {
		return assignUsersToGroupSearchField;
	}

	public WebElement getAssignUsersCheckBox() {
		return assignUsersCheckBox;
	}

	public WebElement getAssignUsersButton() {
		return assignUsersButton;
	}

	public WebElement getAssignUsersCancelButton() {
		return assignUsersCancelButton;
	}

	public WebElement getACSManageRBAManageDefaultCheckBox() {
		return ACSManageRBAManageDefaultCheckBox;
	}

	public WebElement getACSManageRBAManageMakerCheckBox() {
		return ACSManageRBAManageMakerCheckBox;
	}

	public WebElement getACSManageResourceViewCheckBox() {
		return ACSManageResourceViewCheckBox;
	}

	public WebElement getACSManageResourceManageCheckBox() {
		return ACSManageResourceManageCheckBox;
	}

	public WebElement getACSTransactionReportViewCheckBox() {
		return ACSTransactionReportViewCheckBox;
	}

	public WebElement getACSTransactionReportViewClearCheckBox() {
		return ACSTransactionReportViewClearCheckBox;
	}

	public WebElement getACSRBAConfigViewCheckBox() {
		return ACSRBAConfigViewCheckBox;
	}

	public WebElement getACSRBAConfigManageDefaultCheckBox() {
		return ACSRBAConfigManageDefaultCheckBox;
	}

	public WebElement getACSRBAConfigManageMakerCheckBox() {
		return ACSRBAConfigManageMakerCheckBox;
	}

	public WebElement getACSRBAConfigManageCheckerCheckBox() {
		return ACSRBAConfigManageCheckerCheckBox;
	}

	public WebElement getACSManageHolderView() {
		return ACSManageHolderView;
	}

	public WebElement getGroupnamelesschar() {
		return groupnamelesschar;
	}

	public WebElement getGroupname() {
		return groupname;
	}

	public WebElement getProductname() {
		return productname;
	}
	
	public WebElement getGroupEditSavesButton() {
		return groupEditSavesButton;
	}
	
	public WebElement getGroupNameTextEditField() {
		return groupNameTextEditField;
	}
	
	public WebElement getThreedsAcquirerBinView() {
		return threedsAcquirerBinView;
	}

	public WebElement getThreedsAcquirerBINManage() {
		return threedsAcquirerBINManage;
	}

	public WebElement getThreedsRbaManage() {
		return threedsRbaManage;
	}

	public WebElement getACSManageHolderManage() {
		return ACSManageHolderManage;
	}
	
	public WebElement getThreedsTrnxfView() {
		return threedsTrnxfView;
	}

	public WebElement getThreedsDashboardfView() {
		return threedsDashboardfView;
	}

	public WebElement getThreedsRbaView() {
		return threedsRbaView;
	}

	public WebElement getThreedsacquirerView() {
		return threedsacquirerView;
	}

	public WebElement getThreedsMakerCheckerView() {
		return threedsMakerCheckerView;
	}

	public WebElement getUAMMngUserView() {
		return UAMMngUserView;
	}

	public WebElement getUAMMngBankView() {
		return UAMMngBankView;
	}

	public WebElement getUAMMngGrpsView() {
		return UAMMngGrpsView;
	}

	public WebElement getUAMAuditView() {
		return UAMAuditView;
	}

	
	public WebElement getGroupSearchField() {
		return groupSearchField;
	}

	public WebElement getGroupCreatePlusButton() {
		return groupCreatePlusButton;
	}

	public WebElement getGroupCancelButton() {
		return groupCancelButton;
	}

	public WebElement getGroupCreateButton() {
		return groupCreateButton;
	}

	public WebElement getGroupNameTextField() {
		return groupNameTextField;
	}

	public WebElement getGroupBankId() {
		return groupBankId;
	}

	public WebElement getGroupProductsSelectDropDown() {
		return groupProductsSelectDropDown;
	}

	public WebElement getGroupProductACSRadioButton() {
		return groupProductACSRadioButton;
	}

	public WebElement getGroupProduct3DSRadioButton() {
		return groupProduct3DSRadioButton;
	}

	public WebElement getGroupProductUAMRadioButton() {
		return groupProductUAMRadioButton;
	}

	public WebElement getACSTrnxReportViewCheckBox() {
		return ACSTrnxReportViewCheckBox;
	}

	public WebElement getACSRbaViewCheckBox() {
		return ACSRbaViewCheckBox;
	}

	public WebElement getACSMangeBlockCardViewCheckBox() {
		return ACSMangeBlockCardViewCheckBox;
	}

	public WebElement getACSDashboardViewCheckBox() {
		return ACSDashboardViewCheckBox;
	}

	public WebElement getACSCardholderViewCheckBox() {
		return ACSCardholderViewCheckBox;
	}
	
	public WebElement getACSManageBlockCardManageCheckBox() {
		return ACSManageBlockCardManageCheckBox;
	}

	public WebElement getACSManageBlockCardViewClearCheckBox() {
		return ACSManageBlockCardViewClearCheckBox;
	}

	public WebElement getACSAlertViewCheckBox() {
		return ACSAlertViewCheckBox;
	}

	public WebElement getACSRbaMisViewCheckBox() {
		return ACSRbaMisViewCheckBox;
	}

	public WebElement getACSManageRBAViewCheckBox() {
		return ACSManageRBAViewCheckBox;
	}

	public WebElement getACSMonitoringDashboardViewCheckBox() {
		return ACSMonitoringDashboardViewCheckBox;
	}

	public WebElement getACSCustDataUploadViewCheckBox() {
		return ACSCustDataUploadViewCheckBox;
	}


	public WebElement getACSMddReportViewCheckBox() {
		return ACSMddReportViewCheckBox;
	}
	
	public WebElement getListPerPageDropDown() {
		return listPerPageDropDown;
	}

	public WebElement getList10PerPageRadioButton() {
		return list10PerPageRadioButton;
	}

	public WebElement getList20PerPageRadioButton() {
		return list20PerPageRadioButton;
	}

	public WebElement getList30PerPageRadioButton() {
		return list30PerPageRadioButton;
	}
	
	public WebElement getSeacrhByGroupName() {
		return seacrhByGroupName;
	}

	public WebElement getListedGroupName() {
		return listedGroupName;
	}

	public WebElement getListedProductName() {
		return listedProductName;
	}

	public WebElement getStatus() {
		return Status;
	}

	public WebElement getEditGroups() {
		return editGroups;
	}

	public WebElement getDeleteGroups() {
		return deleteGroups;
	}
	
	public WebElement getUAMMngUserManage() {
		return UAMMngUserManage;
	}

	public WebElement getUAMMngUserManageDefault() {
		return UAMMngUserManageDefault;
	}

	public WebElement getUAMMngUserManageMaker() {
		return UAMMngUserManageMaker;
	}

	public WebElement getUAMMngUserManageChecker() {
		return UAMMngUserManageChecker;
	}

	public WebElement getUAMMngBanksManage() {
		return UAMMngBanksManage;
	}

	public WebElement getUAMMngBanksManageDefault() {
		return UAMMngBanksManageDefault;
	}

	public WebElement getUAMMngBanksManageMaker() {
		return UAMMngBanksManageMaker;
	}

	public WebElement getUAMMngBanksManageChecker() {
		return UAMMngBanksManageChecker;
	}

	public WebElement getUAMMnggroupsManage() {
		return UAMMnggroupsManage;
	}

	public WebElement getUAMMnggroupsManageDefault() {
		return UAMMnggroupsManageDefault;
	}

	public WebElement getUAMMnggroupsManageMaker() {
		return UAMMnggroupsManageMaker;
	}

	public WebElement getUAMMnggroupsManageChecker() {
		return UAMMnggroupsManageChecker;
	}
}

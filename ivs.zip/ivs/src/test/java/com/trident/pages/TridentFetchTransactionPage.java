package com.trident.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TridentFetchTransactionPage {

	public WebDriver driver;

	public TridentFetchTransactionPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Search Transaction History')]")
	private WebElement searchTransactionHistoryTextLink;

	@FindBy(xpath = "//select[@id='period']")
	private WebElement periodDropdown;

	// From Date xpath
	@FindBy(xpath = "//input[@name='fromDate']")
	private WebElement fromDate;

	@FindBy(xpath = "(//select[@class='hourselect'])[1]")
	private WebElement fromDateHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[1]")
	private WebElement fromDateMinuteSelectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[1]")
	private WebElement fromDateSecondSelectDropdown;

	@FindBy(xpath = "(//button[text()='Apply'])[1]")
	private WebElement fromDateApplyButton;

	// To Date xpath
	@FindBy(xpath = "//input[@name='toDate']")
	private WebElement toDate;

	@FindBy(xpath = "(//select[@class='hourselect'])[3]")
	private WebElement toDateHourSelectDropdown;

	@FindBy(xpath = "(//select[@class='minuteselect'])[3]")
	private WebElement toDateMinuteSelectDropdown;

	@FindBy(xpath = "(//select[@class='secondselect'])[3]")
	private WebElement toDateSecondSelectDropdown;

	@FindBy(xpath = "(//button[text()='Apply'])[2]")
	private WebElement toDateApplyButton;

	@FindBy(xpath = "//input[@name='merchantName']")
	private WebElement merchantNameTextField;

	@FindBy(xpath = "//input[@name='merchantId']")
	private WebElement merchantIdTextField;

	@FindBy(xpath = "//select[@name='merchantCountry']")
	private WebElement merchantCountryDropdown;

	@FindBy(xpath = "//select[@name='suggestion']")
	private WebElement suggestionSelectOption;

	@FindBy(xpath = "//input[@name='txtCid']")
	private WebElement clientIdTextField;

	@FindBy(xpath = "//input[@name='txtCardNumber']")
	private WebElement cardNumberTextField;

	@FindBy(xpath = "//button[contains(text(),'Fetch Report')]")
	private WebElement fetchReportButton;

	@FindBy(xpath = "//tr[@class='odd footable-even']")
	private WebElement Row;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[1]")
	private WebElement Suggestion;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[2]")
	private WebElement Score;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[3]")
	private WebElement CardNumber;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[4]")
	private WebElement TimeStamp;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[5]")
	private WebElement Status;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[6]")
	private WebElement MerchantCity;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[7]")
	private WebElement MerchantName;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[8]")
	private WebElement PurchaseAmount;

	@FindBy(xpath = "//tr[@class='odd footable-even']/td[9]")
	private WebElement TransactionType;

	public WebElement getSearchTransactionHistoryTextLink() {
		return searchTransactionHistoryTextLink;
	}

	public WebElement getCardNumberTextField() {
		return cardNumberTextField;
	}

	public WebElement getClientIdTextField() {
		return clientIdTextField;
	}

	public WebElement getFetchReportButton() {
		return fetchReportButton;
	}

	public WebElement getRow() {
		return Row;
	}

	public WebElement getSuggestion() {
		return Suggestion;
	}

	public WebElement getScore() {
		return Score;
	}

	public WebElement getCardNumber() {
		return CardNumber;
	}

	public WebElement getTimeStamp() {
		return TimeStamp;
	}

	public WebElement getStatus() {
		return Status;
	}

	public WebElement getMerchantCity() {
		return MerchantCity;
	}

	public WebElement getMerchantName() {
		return MerchantName;
	}

	public WebElement getPurchaseAmount() {
		return PurchaseAmount;
	}

	public WebElement getTransactionType() {
		return TransactionType;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getPeriodDropdown() {
		return periodDropdown;
	}

	public WebElement getFromDate() {
		return fromDate;
	}

	public WebElement getFromDateHourSelectDropdown() {
		return fromDateHourSelectDropdown;
	}

	public WebElement getFromDateMinuteSelectDropdown() {
		return fromDateMinuteSelectDropdown;
	}

	public WebElement getFromDateSecondSelectDropdown() {
		return fromDateSecondSelectDropdown;
	}

	public WebElement getFromDateApplyButton() {
		return fromDateApplyButton;
	}

	public WebElement getToDate() {
		return toDate;
	}

	public WebElement getToDateHourSelectDropdown() {
		return toDateHourSelectDropdown;
	}

	public WebElement getToDateMinuteSelectDropdown() {
		return toDateMinuteSelectDropdown;
	}

	public WebElement getToDateSecondSelectDropdown() {
		return toDateSecondSelectDropdown;
	}

	public WebElement getToDateApplyButton() {
		return toDateApplyButton;
	}

	public WebElement getMerchantNameTextField() {
		return merchantNameTextField;
	}

	public WebElement getMerchantIdTextField() {
		return merchantIdTextField;
	}

	public WebElement getMerchantCountryDropdown() {
		return merchantCountryDropdown;
	}

	public WebElement getSuggestionSelectOption() {
		return suggestionSelectOption;
	}

}

package com.trident.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TridentLogOutPage {
	
	public WebDriver driver;

	public TridentLogOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@class='nav-link dropdown-toggle text-muted waves-effect waves-dark']")
	private WebElement userProfileLink;
	
	@FindBy(xpath = "//a[contains(text(),'Logout')]")
	private WebElement userLogOutLink;
	
	
	public void tridentlogout() throws InterruptedException {
		userProfileLink.click();
		Thread.sleep(2000);
		userLogOutLink.click();
	}
	
}

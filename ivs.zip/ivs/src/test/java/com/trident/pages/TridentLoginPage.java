package com.trident.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TridentLoginPage {

	public WebDriver driver;

	public TridentLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@placeholder='UserId']")
	private WebElement userIdTextField;

	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement passwordTextField;

	@FindBy(xpath = "//input[@placeholder='Instance Id']")
	private WebElement instanceIdTextField;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement loginButton; //// button[normalize-space()='Log In']

	@FindBy(xpath = "//button[normalize-space()='Log In']")
	private WebElement loginButton1;

	public WebElement getUserIdTextField() {
		return userIdTextField;
	}

	public WebElement getPasswordTextField() {
		return passwordTextField;
	}

	public WebElement getInstanceIdTextField() {
		return instanceIdTextField;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void tridentlogin(String un, String pwd) throws Exception {

		// Thread.sleep(2000);

		userIdTextField.click();
		userIdTextField.clear();
		userIdTextField.sendKeys(un);

		// Thread.sleep(2000);
		instanceIdTextField.click();
		instanceIdTextField.clear();
		instanceIdTextField.sendKeys("9111");
		Thread.sleep(2000);
		passwordTextField.click();
		passwordTextField.clear();
		passwordTextField.sendKeys(pwd);
		/*
		 * Actions builder = new Actions(driver);
		 * builder.moveToElement(loginButton).sendKeys(Keys.RETURN); builder.perform();
		 */

		/*
		 * JavascriptExecutor executor = (JavascriptExecutor) driver;
		 * executor.executeScript("arguments[0].submit();", loginButton);
		 */
//		clickSubmit();

		// loginButton1.click();
		/*
		 * try { Thread.sleep(2000); } catch (InterruptedException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

		// instanceIdTextField.sendKeys(Keys.ENTER);

		loginButton.click();

	}

}

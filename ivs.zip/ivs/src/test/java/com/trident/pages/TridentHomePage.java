package com.trident.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TridentHomePage {
	
	public WebDriver driver;

	public TridentHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Home')]")
	private WebElement homeTextLink;
	
	@FindBy(xpath = "//select[@name='instanceId']")
	private WebElement instanceIdDropDown;
	
	@FindBy(xpath = "//select[@id='channelId']")
	private WebElement channelIdDropDown;

	public WebElement getHomeTextLink() {
		return homeTextLink;
	}

	public WebElement getInstanceIdDropDown() {
		return instanceIdDropDown;
	}

	public WebElement getChannelIdDropDown() {
		return channelIdDropDown;
	}
		
}

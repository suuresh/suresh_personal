package com.trident.testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.acs.libraries.Config;
import com.acs.libraries.ErrorCollector;
import com.acs.libraries.GenericMethods;
import com.acs.testcases.ACSInitialSetUp;
import com.acs.utils.ExtentTestManager;
import com.trident.pages.TridentFetchTransactionPage;
import com.trident.pages.TridentHomePage;

public class TridentTxnVerification extends ACSInitialSetUp {

	GenericMethods generic = new GenericMethods(driver);
	int invocationCount = 2;

	@BeforeMethod
	public void beforeTxnVerificationMethod() throws Exception {
		driver.get(Config.BASE_TRIDENT_URL);

		generic.explicitWait(1);
//		tloginPage.tridentlogin(Config.BASE_TRIDENT_USERNAME, Config.BASE_UAM_ADMIN_PASSWD);

		driver.findElement(By.xpath("//input[@placeholder='UserId']")).sendKeys(Config.BASE_TRIDENT_USERNAME);
		generic.explicitWait(2);
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(Config.BASE_TRIDENT_PASSWORD);
		generic.explicitWait(2);
		System.out.println("Password:-" + Config.BASE_TRIDENT_PASSWORD);
		driver.findElement(By.xpath("//input[@placeholder='Instance Id']")).sendKeys(Config.BASE_TRIDENT_INSTANCEID);
		generic.explicitWait(2);

		driver.findElement(By.xpath("//button[@type='submit']")).click();
		System.out.println("Submit button clicked");
		generic.explicitWait(2);

		// Second Attempt to login
		driver.findElement(By.xpath("//input[@placeholder='UserId']")).sendKeys(Config.BASE_TRIDENT_USERNAME);
		generic.explicitWait(2);
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(Config.BASE_TRIDENT_PASSWORD);
		generic.explicitWait(2);
		driver.findElement(By.xpath("//input[@placeholder='Instance Id']")).sendKeys(Config.BASE_TRIDENT_INSTANCEID);
		generic.explicitWait(2);

		driver.findElement(By.xpath("//button[@type='submit']")).click();

	}

	@DataProvider
	public Object[][] DataSet() throws IOException {

		System.out.println("Reading data from excell file");
		return generic.getData(XlFileName, TridentTxn2_0SheetName);
	}

	@Test(dataProvider = "DataSet")
	public void tridentTxnVerification(String IssuerBankId, String IssuerBankName, String AccquirerBankId,
			String AcquirerBankName, String Cardnumber, String ProtocalVersion, String Flow, String merchantname,
			String amount, String currencytype, String CardUnionType, String acsTxnId, String CavvOrAvv,
			String ThreeDSTxnId, String RiskengineClientID, String RiskScore, String RiskSuggestion, String decs)
			throws Exception {
		SoftAssert sAssertion = new SoftAssert();
		ExtentTestManager.getTest().setDescription(decs);
		TridentHomePage homepage = new TridentHomePage(driver);
		TridentFetchTransactionPage txnpage = new TridentFetchTransactionPage(driver);
		generic.explicitWait(2);
		if(Flow.equalsIgnoreCase("Failed")|| Flow.equalsIgnoreCase("Blocked"))
		{
			System.out.println("Flow of the Transaction : "+Flow );
			System.out.println("Trident is not hitting for Failed and Blocked card ");
			//throw new SkipException("Trident is not hitting for Failed and Blocked card");
		}
		else
		{
		homepage.getInstanceIdDropDown().sendKeys(IssuerBankId);
		generic.explicitWait(2);
		homepage.getChannelIdDropDown().sendKeys(Config.BASE_TRIDENT_CHANNELID);
		generic.explicitWait(2);
		homepage.getHomeTextLink().click();
		try {
		// Adding scripts for 1.0 transaction
		if (ProtocalVersion.equalsIgnoreCase("2.1.0")) {
			
			//Avoiding Failed and blocked card
			
			// txnpage.getSearchTransactionHistoryTextLink().click();
			// ******Selecting period********

			generic.selectByVisibleText(txnpage.getPeriodDropdown(), "Custom Range");
			generic.explicitWait(2);
			txnpage.getFromDate().click();
			generic.selectByVisibleText(txnpage.getFromDateHourSelectDropdown(), "0");
			generic.selectByVisibleText(txnpage.getFromDateMinuteSelectDropdown(), "00");
			generic.selectByVisibleText(txnpage.getFromDateSecondSelectDropdown(), "00");
			txnpage.getFromDateApplyButton().click();
			generic.explicitWait(2);

			txnpage.getClientIdTextField().sendKeys(RiskengineClientID);

			generic.explicitWait(1);
			txnpage.getCardNumberTextField().click();
			txnpage.getCardNumberTextField().clear();
			txnpage.getCardNumberTextField().sendKeys(Cardnumber);
			System.out.println("Card Number entered");
			// txnpage.getClientIdTextField().sendKeys(RiskengineClientID);
			txnpage.getFetchReportButton().click();
			generic.explicitWait(2);

			String suggestion = txnpage.getSuggestion().getText();

			sAssertion.assertFalse(suggestion.equalsIgnoreCase("UNKNOWN"));
			
			sAssertion.assertEquals(txnpage.getCardNumber().getText(), Cardnumber);
			if(Flow.equalsIgnoreCase("BlockCard") ||Flow.equalsIgnoreCase("Canceled")||Flow.equalsIgnoreCase("OTPExpiry")) {
				sAssertion.assertEquals(txnpage.getStatus().getText(), "FAILED");
			}else {
				sAssertion.assertEquals(txnpage.getStatus().getText(), "SUCCESS");
			}
			
			sAssertion.assertEquals(txnpage.getMerchantName().getText(), merchantname);
			// sAssertion.assertEquals(txnpage.getPurchaseAmount().getText(), amount +
			// ".00");
			sAssertion.assertEquals(txnpage.getTransactionType().getText(), "ACS");
		//	sAssertion.assertEquals(txnpage.getSuggestion().getText(), RiskSuggestion);
		//	sAssertion.assertEquals(txnpage.getScore().getText(), RiskScore);

			
			}
		 else {
			System.out.println("We are not hitting trident for 1.0 protocol");
		}
		}catch(Exception e) {
			System.out.println("Handling unexpected popup");
			ErrorCollector.addVerificationFailure(e);
		}
		}
		sAssertion.assertAll();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		driver.findElement(By.xpath("//a[@class='nav-link dropdown-toggle text-muted waves-effect waves-dark']"))
				.click();
		generic.explicitWait(2);
		driver.findElement(By.xpath("//a[contains(text(),'Logout')]")).click();

	}
}

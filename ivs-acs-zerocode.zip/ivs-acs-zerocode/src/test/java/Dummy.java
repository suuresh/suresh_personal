
import java.io.File;
import java.sql.Timestamp;

import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.report.ZeroCodeReportGeneratorImpl;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

//@TargetEnv("github_host.properties")
@RunWith(ZeroCodeUnitRunner.class)

public class Dummy {

	@BeforeClass
	public static void cleandata() throws Exception {

		System.out.print("Inside Clean data");

		String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				System.out.println("successfully deleted");
			} else {
				System.out.println("cant delete a file due to open or error");
			}
		}
	}

	@Test
	@Scenario("helloworld/test.json")
	public void testGet() throws Exception {
	}
	
	//@Test
	@Scenario("helloworld/retrieve_cust_record_1.json")
	public void retrieveCustRecord() throws Exception {
	}

//}
}

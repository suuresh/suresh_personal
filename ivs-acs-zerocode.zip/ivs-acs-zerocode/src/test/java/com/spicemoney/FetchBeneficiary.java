package com.spicemoney;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class FetchBeneficiary {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_1.json")
    public void fetch_beneficiary_1Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_10.json")
    public void fetch_beneficiary_10Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_11.json")
    public void fetch_beneficiary_11Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_12.json")
    public void fetch_beneficiary_12Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_13.json")
    public void fetch_beneficiary_13Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_14.json")
    public void fetch_beneficiary_14Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_15.json")
    public void fetch_beneficiary_15Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_16.json")
    public void fetch_beneficiary_16Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_17.json")
    public void fetch_beneficiary_17Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_18.json")
    public void fetch_beneficiary_18Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_19.json")
    public void fetch_beneficiary_19Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_2.json")
    public void fetch_beneficiary_2Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_20.json")
    public void fetch_beneficiary_20Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_21.json")
    public void fetch_beneficiary_21Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_22.json")
    public void fetch_beneficiary_22Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_23.json")
    public void fetch_beneficiary_23Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_24.json")
    public void fetch_beneficiary_24Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_25.json")
    public void fetch_beneficiary_25Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_3.json")
    public void fetch_beneficiary_3Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_4.json")
    public void fetch_beneficiary_4Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_5.json")
    public void fetch_beneficiary_5Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_6.json")
    public void fetch_beneficiary_6Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_7.json")
    public void fetch_beneficiary_7Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_8.json")
    public void fetch_beneficiary_8Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\FetchBeneficiary\\fetch_beneficiary_9.json")
    public void fetch_beneficiary_9Test() throws Exception {
    }
}

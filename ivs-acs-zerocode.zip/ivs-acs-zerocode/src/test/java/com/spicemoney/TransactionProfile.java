package com.spicemoney;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class TransactionProfile {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_1.json")
    public void transaction_profiler_1Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_10.json")
    public void transaction_profiler_10Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_11.json")
    public void transaction_profiler_11Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_12.json")
    public void transaction_profiler_12Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_13.json")
    public void transaction_profiler_13Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_14.json")
    public void transaction_profiler_14Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_15.json")
    public void transaction_profiler_15Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_16.json")
    public void transaction_profiler_16Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_17.json")
    public void transaction_profiler_17Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_18.json")
    public void transaction_profiler_18Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_19.json")
    public void transaction_profiler_19Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_2.json")
    public void transaction_profiler_2Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_20.json")
    public void transaction_profiler_20Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_21.json")
    public void transaction_profiler_21Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_22.json")
    public void transaction_profiler_22Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_23.json")
    public void transaction_profiler_23Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_24.json")
    public void transaction_profiler_24Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_3.json")
    public void transaction_profiler_3Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_4.json")
    public void transaction_profiler_4Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_5.json")
    public void transaction_profiler_5Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_6.json")
    public void transaction_profiler_6Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_7.json")
    public void transaction_profiler_7Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_8.json")
    public void transaction_profiler_8Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\TransactionProfile\\transaction_profiler_9.json")
    public void transaction_profiler_9Test() throws Exception {
    }
}

package com.spicemoney;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class CheckStatus {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_1.json")
    public void check_status_1Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_10.json")
    public void check_status_10Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_11.json")
    public void check_status_11Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_12.json")
    public void check_status_12Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_13.json")
    public void check_status_13Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_14.json")
    public void check_status_14Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_15.json")
    public void check_status_15Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_16.json")
    public void check_status_16Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_17.json")
    public void check_status_17Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_18.json")
    public void check_status_18Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_19.json")
    public void check_status_19Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_2.json")
    public void check_status_2Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_20.json")
    public void check_status_20Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_21.json")
    public void check_status_21Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_22.json")
    public void check_status_22Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_3.json")
    public void check_status_3Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_4.json")
    public void check_status_4Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_5.json")
    public void check_status_5Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_6.json")
    public void check_status_6Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_7.json")
    public void check_status_7Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_8.json")
    public void check_status_8Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CheckStatus\\check_status_9.json")
    public void check_status_9Test() throws Exception {
    }
}

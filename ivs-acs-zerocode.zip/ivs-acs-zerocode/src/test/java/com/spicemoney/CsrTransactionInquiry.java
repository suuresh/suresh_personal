package com.spicemoney;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class CsrTransactionInquiry {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\spicemoney\\CsrTransactionInquiry\\csr_transaction_inquiry_1.json")
    public void csr_transaction_inquiry_1Test() throws Exception {
    }
}

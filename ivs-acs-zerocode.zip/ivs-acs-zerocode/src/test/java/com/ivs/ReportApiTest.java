package com.ivs;

import java.io.File;


import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@TargetEnv("ivs_dcs_config.properties")
@RunWith(ZeroCodeUnitRunner.class)
public class ReportApiTest {
	@BeforeClass
	public static void cleandata() throws Exception {

		System.out.print("Inside Clean data");

		String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				System.out.println("successfully deleted");
			} else {
				System.out.println("cant delete a file due to open or error");
			}
		}

	}

//	@Test
//	@Scenario("IVS/report_api/fetchBillingMisReport.json")
//	public void testfetchBillingMisReport() throws Exception {
//	}
//	@Test
//	@Scenario("IVS/report_api/getBinRangesFromIssuerConfig.json")
//	public void testgetBinRangesFromIssuerConfigt() throws Exception {
//	}
//	@Test
//	@Scenario("IVS/report_api/fetchAlertDetails.json")
//	public void testfetchAlertDetails() throws Exception {
//	
//	}
	

//	@Test
//	@Scenario("IVS/report_api/fetchACSCardUsageBreakdownt.json")
//	public void testfetchACSCardUsageBreakdown() throws Exception {
//}
//	@Test
//	@Scenario("IVS/report_api/fetchMDDReportSummaryV2.json")
//	public void testfetchMDDReportSummaryV2() throws Exception {
//	}
//	@Test
//	@Scenario("IVS/report_api/fetchACSHighlights.json")
//	public void testfetchACSHighlight() throws Exception {
//	}
//	@Test
//	@Scenario("IVS/report_api/fetchACSTopMerchants.json")
//	public void testfetchACSTopMerchants() throws Exception {
//	}
//	
//	@Test
//	@Scenario("IVS/report_api/fetchRbaMisReportBaseOnRuleSetBased.json")
//	public void testfetchRbaMisReportBaseOnRuleSetBased() throws Exception {
//	}
//	
//	@Test
//	@Scenario("IVS/report_api/fetchRbaMisReportBaseOnRiskEngineScoreOrSuggestion.json")
//	public void testfetchRbaMisReportBaseOnRiskEngineScoreOrSuggestion() throws Exception {
//	}
//	
//	@Test
//	@Scenario("IVS/report_api/fetchRbaMisReportBaseOnAuthenticationMode.json")
//	public void testfetchRbaMisReportBaseOnAuthenticationMode() throws Exception {
//	}
	
	@Test
	@Scenario("IVS/report_api/fetchSMSMISEventsCount.json")
	public void testfetchSMSMISEventsCount() throws Exception {
	}

	@Test
	@Scenario("IVS/report_api/transactionSummaryMISPDCReport.json")
	public void testtransactionSummaryMISPDCReport() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/fetchTransactionMISReport.json")
	public void testfetchTransactionMISReport() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/transactionSummaryMISReport.json")
	public void testtransactionSummaryMISReport() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/binwiseSummaryMISReport.json")
	public void testbinwiseSummaryMISReportt() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/amountSummaryMISReport.json")
	public void testamountSummaryMISReport() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/auditTrailReport.json")
	public void testauditTrailReport() throws Exception {
	}
	
	@Test
	@Scenario("IVS/report_api/fetchACSCardUsageBreakdown.json")
	public void testfetchACSCardUsageBreakdown() throws Exception {
	}
	
	

}
	
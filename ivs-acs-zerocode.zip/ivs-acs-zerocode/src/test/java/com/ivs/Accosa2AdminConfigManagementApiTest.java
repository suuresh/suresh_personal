package com.ivs;

import java.io.File;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@TargetEnv("ivs_dcs_config.properties")
@RunWith(ZeroCodeUnitRunner.class)
public class Accosa2AdminConfigManagementApiTest {
	@BeforeClass
	public static void cleandata() throws Exception {

		System.out.print("Inside Clean data");

		String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				System.out.println("successfully deleted");
			} else {
				System.out.println("cant delete a file due to open or error");
			}
		}

	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/listRbaRules.json")
	public void testlist() throws Exception {
	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/createRBARule.json")
	public void testcreate() throws Exception {
	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/updateRBARule.json")
	public void testupdate() throws Exception {
	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/listOfIssuerBinRanges.json")
	public void testlistissuers() throws Exception {
	}

	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/fetchIssuerBinRangesById.json")
	// public void testfetchissuers() throws Exception {
	// }
	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/getRbaRule.json")
	public void testgetRbaRule() throws Exception {
	}

	//
	//
	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/getIssuerBinConfigTypeClass.json")
	// public void testgetIssuerBinConfigTypeClass() throws Exception {
	// }
	//
	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/getIssuerConfigsByBankId.json")
	public void testgetIssuerConfigsByBankId() throws Exception {
	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/getIssuerConfigsAsKeyValues.json")
	public void testgetIssuerConfigsAsKeyValues() throws Exception {
	}

	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/insertOnboardingBinAndAssociation.json")
	// public void testinsertOnboardingBinAndAssociation() throws Exception {
	// }
	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/fetchListOfCCDGroupNames.json")
	public void testfetchListOfCCDGroupNames() throws Exception {
	}

	@Test
	@Scenario("IVS/accosa2_admin_config_management_api/reloadConfigTypes.json")
	public void testreloadConfigTypes() throws Exception {
	}
	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/upsertListOfErrorCodeLookupData.json")
	// public void testupsertListOfErrorCodeLookupData() throws Exception {
	// }
	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/getErrorCodeLookupDataByCode.json")
	// public void testgetErrorCodeLookupDataByCode() throws Exception {
	// }
	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/getMerchantConfigs.json")
	// public void testgetMerchantConfigs() throws Exception {
	// }
	// @Test
	// @Scenario("IVS/accosa2_admin_config_management_api/createOrUpdateAcquirerConfig.json")
	// public void testcreateOrUpdateAcquirerConfig() throws Exception {
	// }

}

package com.ivs;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)

@SuiteClasses({ 
	Accosa2AdminConfigManagementApiTest.class, 
	CardDataManagementTest.class, 
	OtpEngineTest.class,
	ReportApiTest.class, 
	UserAdministrationApiTest.class 
})

public class AllTests {

}

package com.ivs;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@TargetEnv("ivs_uat_config.properties")
@RunWith(ZeroCodeUnitRunner.class)
public class AlertManagementRunner {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendAlertBallBank.json")
    public void sendAlertBallBankTest() throws Exception {
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendAlertV1.json")
    public void sendAlertV1Test() throws Exception {
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendAlertV2.json")
    public void sendAlertV2Test() throws Exception {
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendAlertWithBankIdV1.json")
    public void sendAlertWithBankIdV1Test() throws Exception {
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendAlertWithBankIdV2.json")
    public void sendAlertWithBankIdV2Test() throws Exception {
    }

    @Test
    @Scenario("D:\\zerocode_tool\\ivs\\exceltoJsonOutput\\acs2-alert-management\\sendEmail.json")
    public void sendEmailTest() throws Exception {
    }
}

package com.ivs;

import java.io.File;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@TargetEnv("ivs_dcs_config.properties")
@RunWith(ZeroCodeUnitRunner.class)
public class CardDataManagementTest {
	@BeforeClass
	public static void cleandata() throws Exception {

		System.out.print("Inside Clean data");

		String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				System.out.println("successfully deleted");
			} else {
				System.out.println("cant delete a file due to open or error");
			}
		}

	}
	
//	@Test
//	@Scenario("ivs/card_data_management_api/actionOnCardInfo.json")
//	public void testactionOnCardInfo() throws Exception {
//	}

	@Test
	@Scenario("ivs/card_data_management_api/createCardData.json")
	public void testcreateCardData() throws Exception {
	}
	
//	@Test
//	@Scenario("ivs/card_data_management_api/defaultColumnOrder.json")
//	public void testdefaultColumnOrder() throws Exception {
//	}
//	
//	@Test
//	@Scenario("ivs/card_data_management_api/fileupload.json")
//	public void testfileupload() throws Exception {
//	}
	
//	@Test
//	@Scenario("ivs/card_data_management_api/getJobStatus.json")
//	public void testgetJobStatus() throws Exception {
//	}
//	
//	
//	@Test
//	@Scenario("ivs/card_data_management_api/saveConfigDetails.json")
//	public void testsaveConfigDetails() throws Exception {
//	}
//
//	@Test
//	@Scenario("ivs/card_data_management_api/update_card.json")
//	public void testupdate_card() throws Exception {
//	}


}

package com.ivs;

import java.io.File;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@TargetEnv("ivs_dcs_config.properties")
@RunWith(ZeroCodeUnitRunner.class)
public class OtpEngineTest {
	@BeforeClass
	public static void cleandata() throws Exception {

		System.out.print("Inside Clean data");

		String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.isFile() && f.exists()) {
				f.delete();
				System.out.println("successfully deleted");
			} else {
				System.out.println("cant delete a file due to open or error");
			}
		}

	}

	@Test
	@Scenario("ivs/otp_engine/generateOTP.json")
	public void testgenerateOTP() throws Exception {
	}

	@Test
	@Scenario("ivs/otp_engine/resendOTP.json")
	public void testresendOTP() throws Exception {
	}

	@Test
	@Scenario("ivs/otp_engine/verifyOTP.json")
	public void testverifyOTP() throws Exception {
	}

}

package com.groupdigital;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class ResetPin {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }
   
    
    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_1.json")
    public void reset_pin_1Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_10.json")
    public void reset_pin_10Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_11.json")
    public void reset_pin_11Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_12.json")
    public void reset_pin_12Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_13.json")
    public void reset_pin_13Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_14.json")
    public void reset_pin_14Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_15.json")
    public void reset_pin_15Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_16.json")
    public void reset_pin_16Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_17.json")
    public void reset_pin_17Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_18.json")
    public void reset_pin_18Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_19.json")
    public void reset_pin_19Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_2.json")
    public void reset_pin_2Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_3.json")
    public void reset_pin_3Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_4.json")
    public void reset_pin_4Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_5.json")
    public void reset_pin_5Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_6.json")
    public void reset_pin_6Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_7.json")
    public void reset_pin_7Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_8.json")
    public void reset_pin_8Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\ResetPin\\reset_pin_9.json")
    public void reset_pin_9Test() throws Exception {
    }
}

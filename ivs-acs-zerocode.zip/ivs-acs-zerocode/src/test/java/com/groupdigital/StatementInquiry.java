package com.groupdigital;

import java.io.File;
import java.lang.Exception;
import org.jsmart.zerocode.core.constants.ZeroCodeReportConstants;
import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(ZeroCodeUnitRunner.class)
public class StatementInquiry {
    @BeforeClass
    public static void cleanData() throws Exception {
        System.out.print("Inside Clean data");
        String path = ZeroCodeReportConstants.TARGET_REPORT_DIR;
        File file = new File(path);
        File[] files = file.listFiles();
        for (File f : files)  {
            if (f.isFile() && f.exists()) {
                f.delete();
                System.out.println("successfully deleted");
            }
            else {
                System.out.println("cant delete a file due to open or error");
            }
        }
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_1.json")
    public void stmnt_inq_1Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_10.json")
    public void stmnt_inq_10Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_11.json")
    public void stmnt_inq_11Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_12.json")
    public void stmnt_inq_12Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_13.json")
    public void stmnt_inq_13Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_14.json")
    public void stmnt_inq_14Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_15.json")
    public void stmnt_inq_15Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_16.json")
    public void stmnt_inq_16Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_17.json")
    public void stmnt_inq_17Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_18.json")
    public void stmnt_inq_18Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_19.json")
    public void stmnt_inq_19Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_2.json")
    public void stmnt_inq_2Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_20.json")
    public void stmnt_inq_20Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_21.json")
    public void stmnt_inq_21Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_22.json")
    public void stmnt_inq_22Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_23.json")
    public void stmnt_inq_23Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_24.json")
    public void stmnt_inq_24Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_25.json")
    public void stmnt_inq_25Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_26.json")
    public void stmnt_inq_26Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_27.json")
    public void stmnt_inq_27Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_28.json")
    public void stmnt_inq_28Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_29.json")
    public void stmnt_inq_29Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_3.json")
    public void stmnt_inq_3Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_30.json")
    public void stmnt_inq_30Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_31.json")
    public void stmnt_inq_31Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_32.json")
    public void stmnt_inq_32Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_33.json")
    public void stmnt_inq_33Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_34.json")
    public void stmnt_inq_34Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_35.json")
    public void stmnt_inq_35Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_36.json")
    public void stmnt_inq_36Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_37.json")
    public void stmnt_inq_37Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_38.json")
    public void stmnt_inq_38Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_39.json")
    public void stmnt_inq_39Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_4.json")
    public void stmnt_inq_4Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_40.json")
    public void stmnt_inq_40Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_41.json")
    public void stmnt_inq_41Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_42.json")
    public void stmnt_inq_42Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_43.json")
    public void stmnt_inq_43Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_44.json")
    public void stmnt_inq_44Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_45.json")
    public void stmnt_inq_45Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_46.json")
    public void stmnt_inq_46Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_47.json")
    public void stmnt_inq_47Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_48.json")
    public void stmnt_inq_48Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_49.json")
    public void stmnt_inq_49Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_5.json")
    public void stmnt_inq_5Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_6.json")
    public void stmnt_inq_6Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_7.json")
    public void stmnt_inq_7Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_8.json")
    public void stmnt_inq_8Test() throws Exception {
    }

    @Test
    @Scenario("C:\\Users\\suresh.madisetty\\workspace\\ivs-acs-zerocode\\src\\test\\resources\\groupdigital\\StatementInquiry\\stmnt_inq_9.json")
    public void stmnt_inq_9Test() throws Exception {
    }
}

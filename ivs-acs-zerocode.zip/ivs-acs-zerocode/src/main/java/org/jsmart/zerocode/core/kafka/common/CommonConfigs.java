package org.jsmart.zerocode.core.kafka.common;

public class CommonConfigs {
    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";

}

package org.jsmart.zerocode.core.report;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvParser;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.jsmart.zerocode.core.domain.builders.ExtentReportsFactory;
import org.jsmart.zerocode.core.domain.builders.HighChartColumnHtmlBuilder;
import org.jsmart.zerocode.core.domain.builders.ZeroCodeChartKeyValueArrayBuilder;
import org.jsmart.zerocode.core.domain.builders.ZeroCodeChartKeyValueBuilder;
import org.jsmart.zerocode.core.domain.builders.ZeroCodeCsvReportBuilder;
import org.jsmart.zerocode.core.domain.reports.ZeroCodeExecResult;
import org.jsmart.zerocode.core.domain.reports.ZeroCodeReport;
import org.jsmart.zerocode.core.domain.reports.ZeroCodeReportStep;
import org.jsmart.zerocode.core.domain.reports.chart.HighChartColumnHtml;
import org.jsmart.zerocode.core.domain.reports.csv.ZeroCodeCsvReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang.StringUtils.substringBetween;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.AUTHOR_MARKER_NEW;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.CATEGORY_MARKER;
import static org.jsmart.zerocode.core.domain.builders.ExtentReportsFactory.getReportName;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.ANONYMOUS_CAT;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.AUTHOR_MARKER_OLD;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.DEFAULT_REGRESSION_CATEGORY;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.HIGH_CHART_HTML_FILE_NAME;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.LINK_LABEL_NAME;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.RESULT_PASS;
//import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.TARGET_FILE_NAME;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.TARGET_FULL_REPORT_CSV_FILE_NAME;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.TARGET_FULL_REPORT_DIR;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.TARGET_REPORT_DIR;
import static org.jsmart.zerocode.core.constants.ZeroCodeReportConstants.TEST_STEP_CORRELATION_ID;

public class ZeroCodeReportGeneratorImpl implements ZeroCodeReportGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(ZeroCodeReportGeneratorImpl.class);

    private static String spikeChartFileName;
 //   String TARGET_FILE_NAME = "target/Test_Reports.html";
    
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	String time=timestamp.toString().replaceAll(" ", "_").replaceAll(":", "_").replaceAll("\\.", "");
   String fileName = "target/Test_Results_22"+time+".html";
//	String Resultfile1="Test_Reports_"+time+".html";
	String Resultfile1=fileName;
	String Resultfile2=Resultfile1;
	
	// File file = new File(TARGET_FULL_REPORT_DIR + Resultfile);
	
	//System.out.println(test);
    
  //  public static String TARGET_FILE_NAME;

    /**
     * Spike chat is disabled by default
     */
    @Inject(optional = true)
    @Named("report.spike.chart.enabled")
    private boolean spikeChartReportEnabled;

    /**
     * Spike chat is disabled by default
     */
    @Inject(optional = true)
    @Named("interactive.html.report.disabled")
    private boolean interactiveHtmlReportDisabled;

    private final ObjectMapper mapper;

    private List<ZeroCodeReport> treeReports;

    private List<ZeroCodeCsvReport> zeroCodeCsvFlattenedRows;

    private List<ZeroCodeCsvReport> csvRows = new ArrayList<>();

    @Inject
    public ZeroCodeReportGeneratorImpl(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    /**
     * Gets unique steps from a scenario. In case of retries, the steps have same correlation id and if
     * one of the retries is successful, we include it in the result(not the one which failed).
     * In a normal case(without retry), both PASS and FAIL will be included as usual.
     *
     * @param steps
     * @return
     */
    
    
    @SuppressWarnings("null")
	public void dummya()
    {
    	ZeroCodeReportStep s1 = null;
    //	s1.getRequest().toString();
    	System.out.println("hello"+ s1.getRequest().toString());
    //	System.out.print("hello world"+test);
    //	result.
    	
    }
    List<ZeroCodeReportStep> getUniqueSteps(List<ZeroCodeReportStep> steps) {
        Map<String, ZeroCodeReportStep> result = new LinkedHashMap<>();
        steps.forEach(step -> {
            result.merge(step.getCorrelationId(), step,
                    (s1, s2) -> RESULT_PASS.equals(s1.getResult()) ? s1 : s2);
            
        });
      //  result.
        return new ArrayList<>(result.values());
    }

    @SuppressWarnings("null")
	public void dummy()
    {
    	ZeroCodeReportStep s1 = null;
    //	s1.getRequest().toString();
    	System.out.println("hello"+ s1.getRequest().toString());
    //	result.
    	
    }
    @Override
    public void generateExtentReport() {

        if (interactiveHtmlReportDisabled) {
            return;
        }

        ExtentReports extentReports = ExtentReportsFactory.createReportTheme(Resultfile1);
        System.out.println("Resultfile1 :"+Resultfile1);
        		//(TARGET_FILE_NAME);

        linkToSpikeChartIfEnabled();

        treeReports.forEach(thisReport -> {

            thisReport.getResults().forEach(thisScenario -> {
                ExtentTest test = extentReports.createTest(thisScenario.getScenarioName());
                test.assignCategory(DEFAULT_REGRESSION_CATEGORY); //Super set
                test.assignCategory(optionalCategory(thisScenario.getScenarioName())); //Sub sets
              //   thisScenario.
       //         test.assignAuthor(optionalAuthor(thisScenario.getScenarioName()));
                List<ZeroCodeReportStep> thisScenarioUniqueSteps = getUniqueSteps(thisScenario.getSteps());
                thisScenarioUniqueSteps.forEach(thisStep -> {
                    test.getModel().setStartTime(utilDateOf(thisStep.getRequestTimeStamp()));
                    test.getModel().setEndTime(utilDateOf(thisStep.getResponseTimeStamp()));

                    final Status testStatus = thisStep.getResult().equals(RESULT_PASS) ? Status.PASS : Status.FAIL;

                    ExtentTest step = test.createNode(thisStep.getName(), TEST_STEP_CORRELATION_ID + " " + thisStep.getCorrelationId());
                  //   step.getModel().
                    if (testStatus.equals(Status.PASS)) {
                    	System.out.print("generating report---!!!----gerating report pass case");
                      //  step.pass(thisStep.getResult());
                    	step.info(MarkupHelper.createCodeBlock(thisStep.getOperation() + "\t" + thisStep.getUrl()));
                       step.info(MarkupHelper.createCodeBlock(thisStep.getRequest(), CodeLanguage.JSON));
                       step.info(MarkupHelper.createCodeBlock(thisStep.getResponse(), CodeLanguage.JSON));
                       // step.pass(thisStep.getResult());
                       System.out.println("operation is"+thisStep.getOperation());
                        System.out.print("1....request is"+thisStep.getRequest());
                        System.out.println("1....response is"+thisStep.getResponse());
                   //     step.pass(thisStep.getRequest());
                        step.log(testStatus.PASS, thisStep.getResponse());
                   //  
                    } else {
                    	System.out.print("generating report---!!!----gerating report fail case");
                    	   System.out.print(" 2-----request is"+thisStep.getRequest());
                           System.out.println("2-----response is"+thisStep.getResponse());
                    	
                        step.info(MarkupHelper.createCodeBlock(thisStep.getOperation() + "\t" + thisStep.getUrl()));
                       
                        step.info(MarkupHelper.createCodeBlock(thisStep.getRequest(), CodeLanguage.JSON));
                        step.info(MarkupHelper.createCodeBlock(thisStep.getResponse(), CodeLanguage.JSON));
                        step.fail(MarkupHelper.createCodeBlock("Reason:\n" + thisStep.getAssertions()));
                    //    steps.
                    }
                    extentReports.flush();
                });

            });

        });
        
//    	System.out.print("renaming file");
//    	String path="D:/POC/POCCode/core/target/"+"Test_Reports.html";
//    	String newpath="D:/POC/POCCode/core/target/"+Resultfile1;
//    	File source=new File(path);
//    	File rename=new File(newpath);
//    	File file = new File(path);
//   System.out.println("after source");
//    	File destination=new File(Resultfile2);
//    	System.out.println("after destination");
//    	source.renameTo(destination);
//    	System.out.println("renamed");
//    	
//    	try
//    	{
//    		file.renameTo(rename);
//    		FileUtils.copyFile(source, destination);
//    	}catch (Exception e)
//    	{
//    		e.printStackTrace();
//    	}
    }

    public void linkToSpikeChartIfEnabled() {

        // ------------------------------------------------
        // If spikeChartFileName is not null,
        // that means it was enabled by one of the runner.
        // (might be disabled by current runner)
        // Then it's good to link it to that spike report.
        // ------------------------------------------------
        if (spikeChartReportEnabled || spikeChartFileName != null) {
            final String reportName = getReportName();

            String linkCodeToTargetSpikeChartHtml =
                    String.format("<code>&nbsp;&nbsp;<a href='%s' style=\"color: #006; background: #ff6;\"> %s </a></code>",
                            spikeChartFileName,
                            LINK_LABEL_NAME);

            ExtentReportsFactory.reportName(reportName + linkCodeToTargetSpikeChartHtml);
        }
    }

    /**
     * @param scenarioName String containing a name of an author
     * @return author of the test scenario
     */
    protected String optionalAuthor(String scenarioName) {
        String authorName = deriveName(scenarioName, AUTHOR_MARKER_OLD);
        authorName = ANONYMOUS_CAT.equals(authorName) ? deriveName(scenarioName, AUTHOR_MARKER_NEW) : authorName;
        return authorName;
    }

    /**
     * @param scenarioName String containing hash tags of a category
     * @return category of the test scenario
     */
    protected String optionalCategory(String scenarioName) {
        return deriveName(scenarioName, CATEGORY_MARKER);
    }

    private String deriveName(String scenarioName, String marker) {
        String authorName = substringBetween(scenarioName, marker, marker);

        if (authorName == null) {
            authorName = substringBetween(scenarioName, marker, ",");
        }

        if (authorName == null) {
            authorName = substringBetween(scenarioName, marker, " ");
        }

        if (authorName == null) {
            authorName = scenarioName.substring(scenarioName.lastIndexOf(marker) + marker.length());
        }

        if (scenarioName.lastIndexOf(marker) == -1 || StringUtils.isEmpty(authorName)) {
            authorName = ANONYMOUS_CAT;
        }

        return authorName;
    }

    protected String onlyScenarioName(String scenarioName) {

        int index = scenarioName.indexOf(AUTHOR_MARKER_OLD);
        if (index == -1) {
            return scenarioName;
        } else {
            return scenarioName.substring(0, index - 1);
        }
    }

    @Override
    public void generateCsvReport() {
        /*
         * Read individual reports for aggregation
         */
        treeReports = readZeroCodeReportsByPath(TARGET_REPORT_DIR);

        /*
         * Generate: CSV report
         */
        zeroCodeCsvFlattenedRows = buildCsvRows();
        generateCsvReport(zeroCodeCsvFlattenedRows);
    }

    @Override
    public void generateHighChartReport() {
        LOGGER.info("####spikeChartReportEnabled: " + spikeChartReportEnabled);

        /*
         * Generate: Spike Chart using HighChart
         */
        if (spikeChartReportEnabled) {
            HighChartColumnHtml highChartColumnHtml = convertCsvRowsToHighChartData(zeroCodeCsvFlattenedRows);
            generateHighChartReport(highChartColumnHtml);
        }
    }


    private HighChartColumnHtml convertCsvRowsToHighChartData(List<ZeroCodeCsvReport> zeroCodeCsvReportRows) {

        HighChartColumnHtmlBuilder highChartColumnHtmlBuilder = HighChartColumnHtmlBuilder.newInstance()
                .chartSeriesName("Test Results")
                .chartTitleTop("Request Vs Response Delay Chart")
                .textYaxis("Response Delay in Milli Sec")
                .chartTitleTopInABox("Spike Chart ( Milli Seconds )");

        ZeroCodeChartKeyValueArrayBuilder dataArrayBuilder = ZeroCodeChartKeyValueArrayBuilder.newInstance();

        zeroCodeCsvReportRows.forEach(thisRow ->
                dataArrayBuilder.kv(ZeroCodeChartKeyValueBuilder.newInstance()
                        .key(thisRow.getScenarioName() + "->" + thisRow.getStepName())
                        .value(thisRow.getResponseDelayMilliSec())
                        .result(thisRow.getResult())
                        .build())
        );

        highChartColumnHtmlBuilder.testResult(dataArrayBuilder.build());

        return highChartColumnHtmlBuilder.build();

    }

    public void generateHighChartReport(HighChartColumnHtml highChartColumnHtml) {

        HighChartColumnHtmlWriter highChartColumnHtmlWriter = new HighChartColumnHtmlWriter();

        spikeChartFileName = createTimeStampedFileName();

        highChartColumnHtmlWriter.generateHighChart(highChartColumnHtml, spikeChartFileName);
    }

    public void generateCsvReport(List<ZeroCodeCsvReport> zeroCodeCsvReportRows) {

        /*
         * Write to a CSV file
         */
        CsvSchema schema = CsvSchema.builder()
                .setUseHeader(true)
                .addColumn("scenarioName")
                .addColumn("scenarioLoop", CsvSchema.ColumnType.NUMBER)
                .addColumn("stepName")
                .addColumn("stepLoop", CsvSchema.ColumnType.NUMBER)
                .addColumn("correlationId")
                .addColumn("requestTimeStamp")
                .addColumn("responseDelayMilliSec", CsvSchema.ColumnType.NUMBER)
                .addColumn("responseTimeStamp")
                .addColumn("result")
                .addColumn("method")
                .build();

        CsvMapper csvMapper = new CsvMapper();
        csvMapper.enable(CsvParser.Feature.WRAP_AS_ARRAY);

        ObjectWriter writer = csvMapper.writer(schema.withLineSeparator("\n"));
        try {
            writer.writeValue(
                    new File(TARGET_FULL_REPORT_DIR +
                            TARGET_FULL_REPORT_CSV_FILE_NAME
                            //"_" +
                            //LocalDateTime.now().toString().replace(":", "-") +
                            //".csv"
                    ),
                    zeroCodeCsvReportRows);

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Exception while Writing full CSV report. Details: " + e);
        }
    }

    public List<ZeroCodeCsvReport> buildCsvRows() {
        /*
         * Map the java list to CsvPojo
         */
        ZeroCodeCsvReportBuilder csvFileBuilder = ZeroCodeCsvReportBuilder.newInstance();

        treeReports.forEach(thisReport ->
                thisReport.getResults().forEach(thisResult -> {

                    csvFileBuilder.scenarioLoop(thisResult.getLoop());
                    csvFileBuilder.scenarioName(thisResult.getScenarioName());

                    thisResult.getSteps().forEach(thisStep -> {
                        csvFileBuilder.stepLoop(thisStep.getLoop());
                        csvFileBuilder.stepName(thisStep.getName());
                        csvFileBuilder.correlationId(thisStep.getCorrelationId());
                        csvFileBuilder.result(thisStep.getResult());
                        csvFileBuilder.method(thisStep.getOperation());
                        csvFileBuilder.requestTimeStamp(thisStep.getRequestTimeStamp().toString());
                        csvFileBuilder.responseTimeStamp(thisStep.getResponseTimeStamp().toString());
                        csvFileBuilder.responseDelayMilliSec(thisStep.getResponseDelay());

                        /*
                         * Add one by one row
                         */
                        csvRows.add(csvFileBuilder.build());

                    });
                })
        );

        return csvRows;
    }

    public List<ZeroCodeReport> readZeroCodeReportsByPath(String reportsFolder) {

        validateReportsFolderAndTheFilesExists(reportsFolder);

        List<String> allEndPointFiles = getAllEndPointFilesFrom(reportsFolder);

        List<ZeroCodeReport> scenarioReports = allEndPointFiles.stream()
                .map(reportJsonFile -> {
                    try {
                        return mapper.readValue(new File(reportJsonFile), ZeroCodeReport.class);
                    } catch (IOException e) {
                        e.printStackTrace();

                        throw new RuntimeException("Exception while deserializing to ZeroCodeReport. Details: " + e);

                    }
                })
                .collect(Collectors.toList());

        for (ZeroCodeReport zeroCodeReport : scenarioReports) {
            for (ZeroCodeExecResult zeroCodeExecResult : zeroCodeReport.getResults()) {
                zeroCodeExecResult.setSteps(getUniqueSteps(zeroCodeExecResult.getSteps()));
            }
          //  ZeroCodeExecResult.class.
        }
        return scenarioReports;
    }


    public static List<String> getAllEndPointFilesFrom(String folderName) {

        File[] files = new File(folderName).listFiles((dir, name) -> {
            return name.endsWith(".json");
        });

        if (files == null || files.length == 0) {

            LOGGER.error("\n\t\t\t************\nNow files were found in folder:{}, hence could not proceed. " +
                    "\n(If this was intentional, then you can safely ignore this error)" +
                    " \n\t\t\t************** \n\n", folderName);
            return emptyList();

        } else {
            return ofNullable(Arrays.asList(files)).orElse(emptyList()).stream()
                    .map(thisFile -> thisFile.getAbsolutePath())
                    .collect(Collectors.toList());
        }
    }

    protected void validateReportsFolderAndTheFilesExists(String reportsFolder) {

        try {
            File[] files = new File(reportsFolder).listFiles((dir, fileName) -> fileName.endsWith(".json"));

            ofNullable(files).orElseThrow(() -> new RuntimeException("Somehow the '" + reportsFolder + "' has got no files."));

        } catch (Exception e) {
            final String message = "\n----------------------------------------------------------------------------------------\n" +
                    "Somehow the '" + reportsFolder + "' is not present or has no report JSON files. \n" +
                    "Possible reasons- \n" +
                    "   1) No tests were activated or made to run via ZeroCode runner. -or- \n" +
                    "   2) You have simply used @RunWith(...) and ignored all tests -or- \n" +
                    "   3) Permission issue to create/write folder/files \n" +
                    "   4) Please fix it by adding/activating at least one test case or fix the file permission issue\n" +
                    "   5) If you are not concerned about reports, you can safely ignore this\n" +
                    "----------------------------------------------------------------------------------------\n";

            // TODO- Can Suppress as this error as this is only related to report. It doesn't hurt or affect the tests at all.
            throw new RuntimeException(message + e);
        }

    }

    private static Date utilDateOf(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    private String createTimeStampedFileName() {
        return HIGH_CHART_HTML_FILE_NAME +
                LocalDateTime.now().toString().replace(":", "-") +
                ".html";
    }
    
    
    

}

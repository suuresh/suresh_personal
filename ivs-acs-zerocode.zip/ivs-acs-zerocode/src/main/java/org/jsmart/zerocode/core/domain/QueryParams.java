package org.jsmart.zerocode.core.domain;

public class QueryParams {
}

package org.jsmart.zerocode.core.domain.reports.chart;

public class ZeroCodeChart {
}

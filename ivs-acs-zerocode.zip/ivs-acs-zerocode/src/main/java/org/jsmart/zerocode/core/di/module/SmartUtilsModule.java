package org.jsmart.zerocode.core.di.module;

public class SmartUtilsModule {
}

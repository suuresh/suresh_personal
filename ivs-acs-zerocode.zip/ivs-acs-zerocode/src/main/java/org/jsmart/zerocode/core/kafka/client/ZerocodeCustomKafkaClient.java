package org.jsmart.zerocode.core.kafka.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZerocodeCustomKafkaClient extends BasicKafkaClient{
    private static final Logger LOGGER = LoggerFactory.getLogger(ZerocodeCustomKafkaClient.class);

    public ZerocodeCustomKafkaClient() {
        super();
    }

}


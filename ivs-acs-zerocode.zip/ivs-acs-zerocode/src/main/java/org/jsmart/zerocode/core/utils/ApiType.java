package org.jsmart.zerocode.core.utils;

public enum ApiType {
    REST_CALL,
    KAFKA_CALL,
    JAVA_CALL,
    NONE;
}

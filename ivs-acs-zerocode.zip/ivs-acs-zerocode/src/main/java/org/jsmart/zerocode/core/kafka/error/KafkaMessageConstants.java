package org.jsmart.zerocode.core.kafka.error;

public interface KafkaMessageConstants {
    String NO_RECORD_FOUND_TO_SEND = "--------> No record was found or invalid record format was found <--------";

}

package Com.Wibmo.Utility;

import java.lang.reflect.InvocationTargetException;
//import mysql*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mysql.*;
import com.mysql.jdbc.Driver;

public class PostGresSqlExecutor {

	private static final Logger LOGGER = LoggerFactory.getLogger(PostGresSqlExecutor.class);
	Map<String, List<Map<String, Object>>> dbRecordsMap = new HashMap<>();
	public static final String RESULTS_KEY = "rows";
	Connection conn = null;
//
	@Inject
	@Named("db_host_url")
	private String dbHostUrl;

	@Inject
	@Named("db_username")
	private String dbUserName;

	@Inject
	@Named("db_password")
	private String dbPassword;

	public Map<String, List<Map<String, Object>>> executeSimpleSql(String simpleSql)
			throws IllegalAccessException, InvocationTargetException, InstantiationException {

		LOGGER.info("DB - Executing SQL query: {}", simpleSql);
		System.out.println("going to execute query" + simpleSql);
		System.out.println("hello test 1");
		//
		List<Map<String, Object>> recordsList = fetchDbRecords(simpleSql);
		//
//	      // -------------------------------------------------------
//	      // Put all the fetched rows into nice JSON key and return.
//	      // -- This make it better to assert SIZE etc in the steps.
//	      // -- You can choose any key.
//	      // -------------------------------------------------------
		dbRecordsMap.put(RESULTS_KEY, recordsList);
		//
		return dbRecordsMap;
		// }

	}

	private Connection getjdbcconnection()
			throws IllegalAccessException, InvocationTargetException, InstantiationException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("making connection");
			Connection conn = DriverManager.getConnection(dbHostUrl, dbUserName, dbPassword);
			return conn;
		} catch (Exception e) {
			System.out.println("couldn't establish a JDBC connection");
			e.printStackTrace();
			return null;
		}

	}

	private List<Map<String, Object>> fetchDbRecords(String simpleSql)
			throws IllegalAccessException, InvocationTargetException, InstantiationException {
		Map<String, Object> aRowColumnValue = new HashMap<>();
		try {
			System.out.println("inside fetch db");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("making connection");
			Connection conn = DriverManager.getConnection(dbHostUrl, dbUserName, dbPassword);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(simpleSql);
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();

			for (int j = 1; j <= columnCount; j++) {
				String columnName = metaData.getColumnName(j);
				Object columnValue = rs.getObject(columnName);

				aRowColumnValue.put(columnName, columnValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return (List<Map<String, Object>>) aRowColumnValue;

	}

	// }

}
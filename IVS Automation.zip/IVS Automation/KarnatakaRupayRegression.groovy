def startNextJob(){
    echo "Build Success start next job"
    /*service = "12_acs-core-junit"
    echo "${version}"
    echo "${params.branch}"
    echo "${params.cluster_name}"
    build job: '12_acs-core-junit', 
    parameters: [
        [$class: 'StringParameterValue', name: 'common', value: version ], 
        [$class: 'StringParameterValue', name: 'branchVersion', value: params.branch ],
        [$class: 'StringParameterValue', name: 'cluster_name', value: params.cluster_name ]
    ]*/
}

pipeline {
    agent any
    tools {maven 'maven'}
    stages {
        stage('deploying acs2_components'){ 
            steps('Running accosa2-config-management'){
                ws('/webserver/jenkins-workspace/Sanity/KarnatakaRupayRegression'){
                    withEnv(["JAVA_HOME=/webserver/softwares/java/jdk-11.0.17/"]){
                        sh"rm -rf /webserver/jenkins-workspace/Sanity/KarnatakaRupayRegression/target/surefire-reports/emailable-report.html"
                        git credentialsId: 'ivsgit',
                                url: 'https://github.com/wibmo-payment-security/acsqa-ui.git',
                                branch: "acsqa-ui-${params.branch}-scripts "
                        sh" chmod 755 -R *"
                        sh "mvn install -Dhttp.proxyHost=192.168.109.32 -Dhttp.proxyPort=6558 -Dsurefire.suiteXmlFiles=TestSuits/Karnataka_Rupay_4131_E2E_Sanity_TestSuite.xml"
                    }
                }     
            }
        }
    }
    post{
        success {
            emailext (
                from: 'ivs.automation@wibmo.com',           
                to: '3ds2.0qa@wibmo.com, arun.srinivasan@wibmo.com, madhusudhan.reddy@wibmo.com',
                mimeType: 'text/html',
                subject: "build  ${currentBuild.number}-${currentBuild.currentResult}:${env.JOB_NAME} Result",
                body: '${FILE, path="/webserver/jenkins-workspace/Sanity/KarnatakaRupayRegression/target/surefire-reports/emailable-report.html"}'
            )

            //startNextJob();
        }
        failure {
            emailext (
                from: 'ivs.automation@wibmo.com',            
                to: '3ds2.0qa@wibmo.com, arun.srinivasan@wibmo.com, madhusudhan.reddy@wibmo.com',
                mimeType: 'text/html',
                subject: "build  ${currentBuild.number}-${currentBuild.currentResult}:${env.JOB_NAME} Result",
                body: '${FILE, path="/webserver/jenkins-workspace/Sanity/KarnatakaRupayRegression/target/surefire-reports/emailable-report.html"}'
            )
        }
    }
}



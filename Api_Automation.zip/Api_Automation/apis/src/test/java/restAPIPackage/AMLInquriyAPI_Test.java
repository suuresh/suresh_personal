package restAPIPackage;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.AMLInquiryPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class AMLInquriyAPI_Test extends Base_Test
{

	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void amlInquiryAPI(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		System.out.println("----------------------AML Inquiry API Started-----------------------");
		
		AMLInquiryPayLoad amlPay=new AMLInquiryPayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		Response responseMessage = given().
		contentType("application/json").
		body(amlPay.amlPayLoad(urn, custId, last4digits)).
		
		when().log().body().
		post(amlInquiryPost).
		
		then().assertThat().statusCode(200).contentType(ContentType.JSON).and().body("responseCode", equalTo("00")).
		
		extract().response();
		
		System.out.println("AML Inquiry API responseMessage is "+responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		String message = jsonValue.get("responseMessage");
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("AML Inquiry is successful");
		System.out.println();
		
		System.out.println("----------------------AML Inquiry API ends here-----------------------");
		
		
	}
}

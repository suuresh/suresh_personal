package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.TransactionInquiryPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class TransactionDetailsAPI_Test extends Base_Test
{
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void transactionDetailsAPI(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create and object of TransactionInquriyPayLoad
		
		System.out.println("----------------------Transaction Inquiry API Started-----------------------");
		
		
		TransactionInquiryPayLoad txnPay=new TransactionInquiryPayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		Response responseMessage = given().
		body(txnPay.txnInqPayLoad(urn,last4digits,custId)).
		
		when().log().body().
		post(transactionDetailsPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		
		extract().response();
		
		System.out.println();
		System.out.println();
		System.out.println("Response message is "+responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		
		String message=jsonValue.get("responseMessage");
		
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("Transaction Inquiry is successfull");
		System.out.println();
		System.out.println("----------------------Transaction Inquiry API Ends here-----------------------");
		System.out.println();
		
		
	}

}

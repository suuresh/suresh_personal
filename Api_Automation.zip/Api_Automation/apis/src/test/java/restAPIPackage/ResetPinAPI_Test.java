package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.ResetPinPayLoad;
import utilities.JsonOrXMLObjects;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class ResetPinAPI_Test
{

	@Test
	public void resetPinAPI()
	{
		RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();
		
		//Create an object of ResetPinPayLoad
		
		ResetPinPayLoad resePay=new ResetPinPayLoad();
		
		Response responseMessage = given().               //response data will be in RAW format. 
		header("Content-Type","application/json").
		
		
		body(resePay.resetPayLoad()).
		
		when().log().body().
		post("v1/6019/resetPIN/1356/20150701235959xhstiesqfds").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("responseCode",equalTo("00")).
		
		extract().response();
		System.out.println("Response message is "+responseMessage.asString());
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String message=jsonValue.get("responseMessage");
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("Reset Pin API is successful");
		
		
		
		
	}
}

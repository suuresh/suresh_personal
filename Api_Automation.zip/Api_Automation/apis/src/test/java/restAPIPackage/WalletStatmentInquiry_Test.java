/**
 * 
 */
package restAPIPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.WalletStatementInquiryPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class WalletStatmentInquiry_Test extends Base_Test
{

	@Test(dataProvider="getCSVData",dataProviderClass=DataProdviderUtility.class)
	public void walletStatementAPI(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------WalletStatmentInquiry API Started-----------------------");
		String last4Digits=lastR4Digits.last4(cardNumber); 
		
		
		//create an object of walletstatement payload
		
		WalletStatementInquiryPayLoad walletPay=new WalletStatementInquiryPayLoad();
		
		Response responseMessage=given().
		contentType("application/json").
		body(walletPay.walletStatementPayload(urn,last4Digits, custId)).
		//body(walletPay.walletStatementPayload("2001093022","4717", "ISriWfap")).
		
		when().log().body().
		post(walletStatementPost).
		
		then().statusCode(200).and().contentType(ContentType.JSON).
		
		extract().response();
		
		System.out.println("WalletStatment response message is "+responseMessage.asString());
		   
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String message = json.get("responseMessage");
		Object avaiBalanceFromJson = json.get("availableBalance");

		System.out.println("avialable balance is "+avaiBalanceFromJson);
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("WalletStatmentInquiry is successfull");
		
		System.out.println("----------------------WalletStatmentInquiry API Ends here-----------------------");
		System.out.println();
		
		
		
	}
}

package restAPIPackage;

import java.util.Calendar;

import io.restassured.RestAssured;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utilities.PropertiesFile;

public class Base_Test 
{

	//public static final String baseURL="https://aero-api-stg.pc.enstage-sas.com"; //this is for staging.
	//public static final String baseURL="http://192.168.105.121:5050/"; // this is for QA 2
	//public static final String baseURL="https://aero-api.pc.enstage-sas.com"; // this is for UAT
	public static final String baseURL="https://mcsuryadev-api.pc.enstage-sas.com/"; //this is for mc surya dev
	//public static final String baseURL="https://mcsuryaqa-api.pc.enstage-sas.com/";
	public static final String activationPost="v1/6019/createCard/0432/20150701235959xhstiesqfds";
	public static final String reloadPost="v1/6019/creditAccount/0250/20150701235959xhstiesqfds";
	public static final String unloadPost="v1/6019/debitAccount/0105/20150701235959xhstiesqfds";
	public static final String blockPost="v1/6019/blockCard/1356/20150701235959xhstiesqfds";
	public static final String unblockPost="v1/6019/unblockCard/1356/20150701235959xhstiesqfds";
	public static final String cardInquiryPost="/v1/6019/cardInquiry/0432/20150701235959xhstiesqfds";
	public static final String updatProfilePost="/v1/6019/cardHolderProfile/IN20014/dsfsdf";
	public static final String transactionDetailsPost="v1/6019/transactionInquiry/1356/20150701235959xhstiesqfds";
	public static final String amlInquiryPost="v1/6019/amlInquiry/5744/201507272454585k498845686";
	public static final String walletStatementPost="v1/6019/statementInquiry/IN20014/2016d1724f";
	
	public static Calendar c = Calendar.getInstance();
	
	public static ExtentReports reports;
	public ExtentTest activationLogger;
	public ExtentTest reloadLogger;
	public ExtentTest logger;
	public String reportName="API Automation";
	
	
	public PropertiesFile myProp=new PropertiesFile();
	
	@BeforeSuite
	public void initialSetUp()
	{
		reports=new ExtentReports(System.getProperty("user.dir")+"\\Reports\\"+toDate()+"\\"+reportName+"_"+timeStamp()+".html");
		//activationLogger=reports.startTest("Activation Test Cases").assignCategory("Regression").assignAuthor("Sanmati Vardhaman");
		//reloadLogger=reports.startTest("Reload Test Cases").assignCategory("Regression").assignAuthor("Sanmati Vardhaman");
				
	}
		
	@BeforeMethod
	public void setUp()
	{
		RestAssured.baseURI = Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();
	}
	
	@AfterSuite
	public void tearDown()
	{
		reports.endTest(logger);
		//reports.endTest(activationLogger);
		//reports.flush();
		//reports.endTest(reloadLogger);
		reports.flush();
		//;
		//reports.flush();
	}
	
	@AfterMethod
	public void finalTearDown(ITestResult result)
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
			logger.log(LogStatus.FAIL,result.getName()+" test case failed");
		}
	}
	
	/**
	 *  this is for dateStamp()
	 * @return
	 */
	public static String toDate()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE);
	}
	
	/**
	 * 
	 * @return
	 */
	
	public static String timeStamp()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE)+"_"+c.get(Calendar.HOUR)+"_"+c.get(Calendar.MINUTE)+"_"+ c.get(Calendar.SECOND);
	}
	
}

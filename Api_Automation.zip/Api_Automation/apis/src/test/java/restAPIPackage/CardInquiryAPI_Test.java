package restAPIPackage;



import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.CardInquiryPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class CardInquiryAPI_Test extends Base_Test
{
	
	public int num=0;
	
	public static String cardStatus="";
	public static String jsonDescription="";
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	//@Test()
	public void cardInquiry(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	//public void cardInquiry()
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		String last4Digits=lastR4Digits.last4(cardNumber);
		logger = reports.startTest("cardInquiry");
		logger.log(LogStatus.INFO, "cardInquiry started");
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		//body(cPay.cardinqPayLoad(urn,custId,last4Digits)).
		body(cPay.cardinqPayLoad("1014272066","F2mu17Xh","0479")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
	
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		/*String message=jsonValue.get("responseMessage");
		cardStatus=jsonValue.get("cardStatus");*/
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		cardStatus=jsonValue.get("cardStatus");
		jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_001_activationWithProperDetails is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		if(cardStatus.contains("0"))
		{
			num++;
		}
		
		//return cardStatus;
	}
	
}

package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.RechargePayLoad;
//import utilities.CSVReadandWrite;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class ReLoadAPI_Test extends Base_Test
{
	
	
   @Test(dataProvider="getCSVData",dataProviderClass=DataProdviderUtility.class)
   public void rechargeAPI(String urn,String custId,String cardNumber,String expiry,String cvv2)
   {
	   System.out.println("----------------------Reload API Started-----------------------");
	   
	   String last4Digits=lastR4Digits.last4(cardNumber);   
	   
	   //RestAssured.baseURI=Base_Test.baseURL;
	   
	   //RestAssured.useRelaxedHTTPSValidation();
	   
	   //Create and object of RechargePayLoad
	   
	   RechargePayLoad recPay=new RechargePayLoad();
	      	
	    
	   Response responseMessage = given().
	   contentType("application/json").
	   //pathParam("last4", last4Digits).
	   
	   
	   
	   body(recPay.recPayload(urn,last4Digits,custId,myProp.getRechargeAmount())).
	  // body(recPay.recPayload("1001034384","7156","IN215143750119",myProp.getRechargeAmount())).
	   when().log().body().
	   post(reloadPost).
	   
	   then().
	   assertThat().and().statusCode(200).and().contentType(ContentType.JSON).and().
	   //body("responseMessage",equalTo("Success")).
	   
	   extract().response();
	   
	   System.out.println("Card recharge response message is "+responseMessage.asString());
	   
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String message = json.get("responseMessage");
		Object avaiBalanceFromJson = json.get("availableBalance");

		System.out.println("avialable balance is "+avaiBalanceFromJson);
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("recharge is successfull");
		
		System.out.println("----------------------Reload API Ends here-----------------------");
		System.out.println();
		
		
	   
	   
   }
}

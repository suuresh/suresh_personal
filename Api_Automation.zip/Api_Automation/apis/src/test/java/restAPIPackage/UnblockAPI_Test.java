package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.UnBlockCardPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class UnblockAPI_Test extends Base_Test
{
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void cardUnblocking(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		
		//create and object of UnBlockCardPayLoad
		
		System.out.println("----------------------Un Block API Started-----------------------");
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		UnBlockCardPayLoad unblockPay=new UnBlockCardPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body(unblockPay.unblockPayLoad(urn,last4digits,custId)).
		//body(unblockPay.unblockPayLoad("2001093128","2584","IN199163866411")).
		
		when().log().body().
		post(unblockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).
		and().
		extract().response();
		
		System.out.println("Unblock response message is "+responseMessage.asString());
		
		//converting the response string into Json format using json path
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String message=json.get("responseMessage");
		Assert.assertEquals(message,"SUCCESS");
		System.out.println("data retrieved from reponse json is "+message);
		System.out.println("unblock api is successful");
		
		System.out.println("----------------------Un Block API Ends here-----------------------");
		System.out.println();
		
	}

}

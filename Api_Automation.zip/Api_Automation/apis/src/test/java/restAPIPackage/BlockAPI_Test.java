package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
//import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import payLoads.BlockPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.PropertiesFile;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;



public class BlockAPI_Test extends Base_Test
{
	
	public static String message="";
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void cardBlocking(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create an object of 	BlockPayLoad
		
		System.out.println("----------------------Block API Started-----------------------");
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		BlockPayLoad blockPay=new BlockPayLoad();
		
		
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,last4digits,custId,new PropertiesFile().getBlockType())).
		
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		message = json.get("responseMessage");
		
		Assert.assertEquals(message,"SUCCESS");
		
		System.out.println("block is successfull");
		
		System.out.println("----------------------Block API Ends here-----------------------");
		
		
	}
}

package restAPIPackage;

//import io.restassured.RestAssured;
import java.util.ArrayList;
//import java.util.List;



import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.ActivationPayLoad;
import utilities.CSVReadandWrite;
import utilities.JsonOrXMLObjects;
import utilities.PropertiesFile;

public class ActivationAPI_Test extends Base_Test{

	PropertiesFile pf=new PropertiesFile();
	/**
	 * 
	 */
	@Test()
	public void activationAPI() {

		/*RestAssured.baseURI = Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create and object of ActivationPayLoadPage
		
		System.out.println("----------------------Activation API Started-----------------------");
		
		ActivationPayLoad actPay=new ActivationPayLoad();
		

		Response responseMessage = given()
				.contentType("application/json").

				body(actPay.actPayload(pf.getProductId(),pf.getCardProfileId(),"150000")).

				when().log().body().
				post(activationPost).

				then().and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().
				//.body("responseCode", equalTo("00")).
				extract().response();
		
				System.out.println("Activation API responseMessage is "+responseMessage.asString());
				
				JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
				 int urn = jsonValue.get("urn");
				String toUrn=Integer.toString(urn);
				String customerId=jsonValue.get("customerId");
				String cardNumber = jsonValue.get("cardNumber");
				String expiry=jsonValue.get("cardExpiry");
				String cvv2=jsonValue.get("cardCVV2");
				
				/*String[] cardDetails=new String[5];
				cardDetails [0]=toUrn;
				cardDetails [1]=customerId;
				cardDetails [2]=cardNumber;
				cardDetails [3]=expiry;
				cardDetails [4]=cvv2;*/
				
				ArrayList<String>myArry=new ArrayList<String>();
				myArry.add(toUrn);
				myArry.add(customerId);
				myArry.add(cardNumber);
				myArry.add(expiry);
				myArry.add(cvv2);
				
				
				
				
				//write in to the file
				CSVReadandWrite.writeToCSV(myArry,"Smoke");
				
				
				
				String message = jsonValue.get("responseMessage");				
				//System.out.println("card number created is "+cardNumber);
				Assert.assertEquals(message, "SUCCESS");
				System.out.println();
				System.out.println("Hurrayyyy...card creation and activation is successful");
				System.out.println();
				
				System.out.println("----------------------Activation API Ends Here-----------------------");
				System.out.println();

	}
	
	
	
	
}

package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.CardHolderUpdateProfilePayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.*;

public class CardHolderUpdateProfileAPI_Test extends Base_Test
{
	/**
	 * tc_001_updateProfileWithValidDetails
	 * tc_002_updateProfiletoKYC
	 * tc_003_updateProfileWithURNCardNumberMismatch
	 * tc_004_updateProfileWithInvalidCustomerID
	 * tc_005_updateProfileforTempBlockCards
	 * tc_006_updateProfileforCustomBlockCards
	 * tc_007_updateProfileforPermanentlyBlockCards.
	 * 
	 */
	
	
	
	
	/**
	 * tc_001_updateProfileWithValidDetails
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */

	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_001_updateProfileWithValidDetails(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_001_updateProfileWithValidDetails");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_001_updateProfileWithValidDetails started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		//body(upPay.updatePayLoad(urn,custId,last4digits,20)).
		body(upPay.updatePayLoad(urn,custId,last4digits,20)).
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"SUCCESS");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_001_updateProfileWithValidDetails is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
	
}

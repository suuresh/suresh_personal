package restAPIPackage;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import payLoads.UnloadPayLoad;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class UnloadAPI_Test extends Base_Test
{
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void unloadAPI(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------Unload API Started-----------------------");
		
		String last4Digits=lastR4Digits.last4(cardNumber); 
		System.out.println(last4Digits);
		
		
		//create and object of UnloadPay
		UnloadPayLoad unloadPay=new UnloadPayLoad();
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body(unloadPay.unloadPayLoad(urn, last4Digits, custId,"25000")).
	
		when().log().body().
		post(unloadPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		System.out.println("Card unload response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String message=json.get("responseMessage");
		
		Assert.assertEquals(message, "SUCCESS");
		System.out.println("Unlaod is successfull");
		
		System.out.println("----------------------Unload API Ends here-----------------------");
		System.out.println();
		
		
		
	}

}

package regressionSuite;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.UnBlockCardPayLoad;
import restAPIPackage.Base_Test;
import restAPIPackage.BlockAPI_Test;
import restAPIPackage.CardInquiryAPI_Test;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class CopyUnblockAPI_Test extends Base_Test
{
	/*
	 * 	Test case covered in this class are
	 *  1.With all valid details-Custom Block/TempBlock
	 *  2.URN and Card number mismatch.
	 *  3.Customer Id mismatch.
	 *  4.Unblocking already unblocked card.
	 *  5.unblocking the Temp Block Card
	 *  6.unBlocking Custom block card //
	 *  7.Unblocking debit_credit_block card.
	 *  8.UnBlocking Permanent block card card.
	 */
	
	// create object of CardInquiryTest and BlockCardTest
	
	CardInquiryAPI_Test cp=new CardInquiryAPI_Test();
	BlockAPI_Test bp=new BlockAPI_Test();
	
	
	/**
	 * tc_001_cardUnblockingwithValidDetails.
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_001_cardUnblockingWithValidDetails(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		
		//create and object of UnBlockCardPayLoad
		
		// check card status, if active, tempblock it.
		//unblock it.
		
		System.out.println("----------------------Un Block API Started-----------------------");
		
		logger = reports.startTest("tc_001_cardUnblockingWithValidDetails");
		
		
		
		cp.cardInquiry(urn, custId, cardNumber, expiry, cvv2);
		if(cp.cardStatus.equals("0"))
		{
			System.out.println("Card is active can't proceed with Unblocking");
			logger.log(LogStatus.INFO, "Card is active can't proceed with Unblocking");
		}
		
		else
		{
			
			
			String last4digits=lastR4Digits.last4(cardNumber);
			
			logger.log(LogStatus.INFO, "tc_001_cardUnblockingWithValidDetails started ");
			UnBlockCardPayLoad unblockPay=new UnBlockCardPayLoad();
			
			Response responseMessage = given().
			contentType("application/json").
			
			body(unblockPay.unblockPayLoad(urn,last4digits,custId)).
			
			when().log().body().
			post(unblockPost).
			
			then().
			assertThat().and().statusCode(200).contentType(ContentType.JSON).
			and().
			extract().response();
			
			logger.log(LogStatus.INFO, "Response is triggered");
			
			System.out.println("Unblock response message is "+responseMessage.asString());
			
			//converting the response string into Json format using json path
			
			JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
			
			String jsonResponseMessage=json.get("responseMessage");
			logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage);
			Assert.assertEquals(jsonResponseMessage,"SUCCESS");
			
			logger.log(LogStatus.PASS, "tc_001_cardUnblockingWithValidDetails is successfull");
			System.out.println("data retrieved from reponse json is "+jsonResponseMessage);
			System.out.println("unblock api is successful");
			
		}
		
		
		System.out.println("----------------------Un Block API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 * tc_002_cardUnblockingWithURNandCardNumberMismatch
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_002_cardUnblockingWithURNandCardNumberMismatch(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		
		//create and object of UnBlockCardPayLoad
		
		System.out.println("----------------------Un Block API Started-----------------------");
		
		logger = reports.startTest("tc_002_cardUnblockingWithURNandCardNumberMismatch");
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		logger.log(LogStatus.INFO, "tc_002_cardUnblockingWithURNandCardNumberMismatch started ");
		UnBlockCardPayLoad unblockPay=new UnBlockCardPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body(unblockPay.unblockPayLoad(urn,ReverseString.reverseString(last4digits),custId)).
		
		when().log().body().
		post(unblockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).
		and().
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Unblock response message is "+responseMessage.asString());
		
		//converting the response string into Json format using json path
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=json.get("responseMessage");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage);
		Assert.assertEquals(jsonResponseMessage,"URN AND LAST 4 DIGITS MISMATCH");
		
		logger.log(LogStatus.PASS, "tc_002_cardUnblockingWithURNandCardNumberMismatch is successfull");
		System.out.println("data retrieved from reponse json is "+jsonResponseMessage);
		System.out.println("unblock api is successful");
		
		System.out.println("----------------------Un Block API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 * tc_003_cardUnblockingWithInvalidCustomerID
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_003_cardUnblockingWithInvalidCustomerID(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		
		//create and object of UnBlockCardPayLoad
		
		System.out.println("----------------------Un Block API Started-----------------------");
		
		logger = reports.startTest("tc_003_cardUnblockingWithInvalidCustomerID");
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		logger.log(LogStatus.INFO, "tc_003_cardUnblockingWithInvalidCustomerID started ");
		UnBlockCardPayLoad unblockPay=new UnBlockCardPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body(unblockPay.unblockPayLoad(urn,last4digits,custId+"a")).
		
		when().log().body().
		post(unblockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).
		and().
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Unblock response message is "+responseMessage.asString());
		
		//converting the response string into Json format using json path
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=json.get("responseMessage");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage);
		Assert.assertEquals(jsonResponseMessage,"URN AND CUSTOMER ID MISMATCH");
		
		logger.log(LogStatus.PASS, "tc_003_cardUnblockingWithInvalidCustomerID is successfull");
		System.out.println("data retrieved from reponse json is "+jsonResponseMessage);
		System.out.println("unblock api is successful");
		
		System.out.println("----------------------Un Block API Ends here-----------------------");
		System.out.println();
		
	}

	/**
	 * tc_004_cardUnblockingUnblockedCard
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_004_cardUnblockingUnblockedCard(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		
		
		//create and object of UnBlockCardPayLoad
		
		System.out.println("----------------------Un Block API Started-----------------------");
		
		logger = reports.startTest("tc_004_cardUnblockingUnblockedCard");
		
		String last4digits=lastR4Digits.last4(cardNumber);
		
		logger.log(LogStatus.INFO, "tc_004_cardUnblockingUnblockedCard started ");
		UnBlockCardPayLoad unblockPay=new UnBlockCardPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body(unblockPay.unblockPayLoad(urn,last4digits,custId)).
		
		when().log().body().
		post(unblockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).
		and().
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Unblock response message is "+responseMessage.asString());
		
		//converting the response string into Json format using json path
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=json.get("responseMessage");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage);
		Assert.assertEquals(jsonResponseMessage,"CARD ALREADY UNBLOCKED");
		
		logger.log(LogStatus.PASS, "tc_004_cardUnblockingUnblockedCard is successfull");
		System.out.println("data retrieved from reponse json is "+jsonResponseMessage);
		System.out.println("unblock api is successful");
		
		System.out.println("----------------------Un Block API Ends here-----------------------");
		System.out.println();
		
	}
	
	
	/* unblock all types of blocked card.
	 * 
	 * do card inquiry and check card is active, then do custom block and unblock.
	 * do TEMP block and unblock
	 * do credit_debit block and unblock.
	 * do permanent block and try to unblock.
	 */
	
	
}

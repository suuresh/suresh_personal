package regressionSuite;

//import io.restassured.RestAssured;
import java.util.ArrayList;
//import java.util.List;




import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.ActivationPayLoad;
import restAPIPackage.Base_Test;
import utilities.CSVReadandWrite;
import utilities.JsonOrXMLObjects;
//import utilities.MyListener;
import utilities.PropertiesFile;
@Listeners(utilities.MyListener.class)
public class CopyOfActivationAPI_Test extends Base_Test {

	/**
	 * Scenarios covered are 
	 * 1.Proper activation.
	 * 2.Duplicate request.
	 * 3.Incorrect Profile id.
	 * 4.Incorrect Product id.
	 * 5.Minimum Limit check
	 * 6.Maximum Limit check.
	 * 7.AMount less than minimum limit check.
	 * 8.Blank Amount in amount field.
	 */

	/**
	 * ********Activation with proper details
	 */
	String customerId;
	String clientTxnid;
	PropertiesFile pf=new PropertiesFile();
	ActivationPayLoad actPay;
	
	
	
	@Test()
	public void tc_001_activationWithProperDetails() {

		// create and object of ActivationPayLoadPage

		System.out
				.println("----------------------Activation API Started-----------------------");
		logger = reports.startTest("tc_001_activationWithProperDetails");
		logger.assignAuthor("Sanmati Vardhaman");
		logger.assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_001_activationWithProperDetails started");
		
		actPay = new ActivationPayLoad();

		Response responseMessage = given().contentType("application/json").

		body(actPay.actPayload(pf.getProductId(),pf.getCardProfileId(),"30000")).

		when().log().body().post(activationPost).

		then().and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().// body("responseCode",
														// equalTo("00")).

				extract().response();

		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());

		JsonPath jsonValue = JsonOrXMLObjects.jsonObject(responseMessage);

		int urn = jsonValue.get("urn");
		String toUrn = Integer.toString(urn);
		customerId = jsonValue.get("customerId");
		String cardNumber = jsonValue.get("cardNumber");
		String expiry = jsonValue.get("cardExpiry");
		String cvv2 = jsonValue.get("cardCVV2");
		clientTxnid=jsonValue.getString("clientTxnId");

		ArrayList<String> myArry = new ArrayList<String>();
		myArry.add(toUrn);
		myArry.add(customerId);
		myArry.add(cardNumber);
		myArry.add(expiry);
		myArry.add(cvv2);

		// write in to the file
		CSVReadandWrite.writeToCSV(myArry,"smoke");

		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		logger.log(LogStatus.PASS, "tc_001_activationWithProperDetails is successfull");
		
		
			
		System.out.println();
		System.out
				.println("Hurrayyyy...card creation and activation is successful");
		System.out.println();

		System.out
				.println("----------------------Activation API Ends Here-----------------------");
		System.out.println();
		//activationLogger.appendChild(logger);
	}
	
	/**
	 * This test case is used to verify activation request api with duplicate details i,e customer id and client txn id
	 */
	
	@Test(description="Duplicate Request")
	public void tc_002_duplicateActivationRequest()
	{
		System.out
		.println("----------------------Activation API Started-----------------------");
		
		logger = reports.startTest("tc_002_duplicateActivationRequest");
		
		logger.log(LogStatus.INFO, "tc_002_duplicateActivationRequest");
		
		actPay = new ActivationPayLoad();
		
		Response responseMessage = given().contentType("application/json").
		body(actPay.actPayloadDuplicateCardCreationCheck(customerId,clientTxnid)).
		
		when().log().body().
		post(activationPost).
		
		then().assertThat().statusCode(200).contentType(ContentType.JSON).and().
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());

		JsonPath jsonValue = JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage, "DUPLICATE REQUEST. SUCCESS");
		logger.log(LogStatus.PASS, "tc_002_duplicateActivationRequest is successfull");
		System.out.println("tc_002_duplicateActivationRequest is successfully verified");
		
		System.out
		.println("----------------------Activation API Ends Here-----------------------");
		System.out.println();
		//activationLogger.appendChild(logger);
	}

	/**
	 * This test case is for incorrect product id.
	 */
	
	@Test(description="TestCase with incorrect Product Id")
	public void tc_003_incorrectProductIDActivationRequest()
	{
		System.out
		.println("----------------------Activation API Started-----------------------");
		
		logger = reports.startTest("tc_003_incorrectProductIDActivationRequest");
		
		actPay = new ActivationPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(actPay.actPayload("7",pf.getCardProfileId(),"30000")).
		
		when().log().body().
		post(activationPost).
		
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");

		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage, "INVALID PRODUCT");
		logger.log(LogStatus.PASS, "tc_003_incorrectProductIDActivationRequest is successfull");
		System.out.println("tc_003_incorrectProductIDActivationRequest is successfully verified");

		//activationLogger.appendChild(logger);
	}
	
	/**
	 * This test case is for incorrect profile id.
	 */
	
	@Test(description="TestCase with incorrect Profile Id")
	public void tc_004_incorrectProfileIDActivationRequest()
	{
		System.out
		.println("----------------------Activation API Started-----------------------");
		
		logger = reports.startTest("tc_004_incorrectProfileIDActivationRequest");
		
		actPay = new ActivationPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(actPay.actPayload(pf.getProductId(),"101","30000")).
		
		when().log().body().
		post(activationPost).
		
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");

		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage, "INVALID CARDPROFILE ID");
		logger.log(LogStatus.PASS, "tc_004_incorrectProfileIDActivationRequest is successfull");
		System.out.println("tc_004_incorrectProfileIDActivationRequest is successfully verified");
	
		//activationLogger.appendChild(logger);
	}
	
	
	/**
	 * This test case is to check minimum limit check.
	 */
	
	@Test(description="Test Case for less than mimimum limit")
	public void tc_005_lessThanMiminumLimitActivationRequest()
	{
		System.out
		.println("----------------------Activation API Started-----------------------");
		
		logger = reports.startTest("tc_005_lessThanMiminumLimitActivationRequest");
		
		actPay = new ActivationPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(actPay.actPayload(pf.getProductId(),pf.getCardProfileId(),"-1")).
		
		when().log().body().
		post(activationPost).
		
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage, "AML MIN LIMIT");
		logger.log(LogStatus.PASS, "tc_005_lessThanMiminumLimitActivationRequest is successfull");
		System.out.println("tc_005_lessThanMiminumLimitActivationRequest is successfully verified");
		
		//activationLogger.appendChild(logger);
	}
	
	/**
	 * This test case is to check maximum limit check
	 */
	
	@Test(description="Test Case for amount greater than mimimum limit")
	public void tc_006_greaterThanMaximumLimitActivationRequest()
	{
		System.out
		.println("----------------------Activation API Started-----------------------");
		
		logger = reports.startTest("tc_006_greaterThanMaximumLimitActivationRequest");
		
		actPay = new ActivationPayLoad();
		
		Response responseMessage = given().contentType("application/json").
		body(actPay.actPayload(pf.getProductId(), pf.getCardProfileId(),"17500000")).
		
		when().log().body().
		post(activationPost).
		
		then().assertThat().statusCode(200).contentType(ContentType.JSON).
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Activation API responseMessage is "
				+ responseMessage.asString());
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage = jsonValue.get("responseMessage");
		String jsonResponseCode = jsonValue.get("responseCode");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage, "AML MAX LIMIT");
		logger.log(LogStatus.PASS, "tc_006_greaterThanMaximumLimitActivationRequest is successfull");
		System.out.println("tc_006_greaterThanMaximumLimitActivationRequest is successfully verified");

		//activationLogger.appendChild(logger);
		
	}
	
}

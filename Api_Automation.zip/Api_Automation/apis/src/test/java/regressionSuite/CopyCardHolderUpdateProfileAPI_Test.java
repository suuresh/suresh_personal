package regressionSuite;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.CardHolderUpdateProfilePayLoad;
import restAPIPackage.Base_Test;
import restAPIPackage.CardInquiryAPI_Test;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.*;

public class CopyCardHolderUpdateProfileAPI_Test extends Base_Test
{
	/**
	 * tc_001_updateProfileWithValidDetails
	 * tc_002_updateProfiletoKYC
	 * tc_003_updateProfileWithURNCardNumberMismatch
	 * tc_004_updateProfileWithInvalidCustomerID
	 * tc_005_updateProfileforTempBlockCards
	 * tc_006_updateProfileforCustomBlockCards
	 * tc_007_updateProfileforPermanentlyBlockCards.
	 * 
	 */
	
	// card details used for temporary blocked block cards 2001092962,ZO6gDgCe,4799470182200669,0823,640.
	// card details used for custom block cards  2001092963,8OBzniwZ,4799470414607616,0823,867
	
	
	
	/**
	 * tc_001_updateProfileWithValidDetails
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */

	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_001_updateProfileWithValidDetails(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_001_updateProfileWithValidDetails");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_001_updateProfileWithValidDetails started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		body(upPay.updatePayLoad(urn,custId,last4digits,20)).
		
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"SUCCESS");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_001_updateProfileWithValidDetails is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 * tc_002_updateProfiletoKYC
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_002_updateProfiletoKYC(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_002_updateProfiletoKYC");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_002_updateProfiletoKYC started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		body(upPay.updatePayLoad(urn,custId,last4digits,100)).
		
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"SUCCESS");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_002_updateProfiletoKYC is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
	
	
	/**
	 * tc_003_updateProfileWithURNCardNumberMismatch
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_003_updateProfileWithURNCardNumberMismatch(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_003_updateProfileWithURNCardNumberMismatch");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_003_updateProfileWithURNCardNumberMismatch started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		body(upPay.updatePayLoad(urn,custId,ReverseString.reverseString(last4digits),100)).
		
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"URN AND LAST 4 DIGITS MISMATCH");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_003_updateProfileWithURNCardNumberMismatch is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 * tc_004_updateProfileWithInvalidCustomerID
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_004_updateProfileWithInvalidCustomerID(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_004_updateProfileWithInvalidCustomerID");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "tc_004_updateProfileWithInvalidCustomerID started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		body(upPay.updatePayLoad(urn,custId+"a",last4digits,20)).
		
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"URN AND CUSTOMER ID MISMATCH");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_004_updateProfileWithInvalidCustomerID is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 * tc_005_updateProfileforTempBlockCards
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_005_updateProfileforTempBlockCards(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_005_updateProfileforTempBlockCards");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "calling card Inquiry to check status for the card ");
		CardInquiryAPI_Test cp=new CardInquiryAPI_Test();
		cp.cardInquiry("2001092962", "ZO6gDgCe", "4799470182200669", "0823","640");
		
		logger.appendChild(cp.logger);
		
		if (cp.jsonDescription.equals("Blocked Temporarily"))
		{
			logger.log(LogStatus.INFO, "tc_005_updateProfileforTempBlockCards started");
			
			CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
			
			String last4digits=lastR4Digits.last4(cardNumber);
			Response responseMessage = given().
			contentType("application/json").
			
			body(upPay.updatePayLoad("2001092962","ZO6gDgCe","0669",20)).
			
			when().log().body().
			post(updatProfilePost).
			
			then().
			assertThat().statusCode(200).and().contentType(ContentType.JSON).
			//body("responseCode",equalTo("00")).
			
			extract().response();
			logger.log(LogStatus.INFO, "Response is triggered");
			
			System.out.println("Response message:"+responseMessage.asString());
			
			//convert the string into JSON
			
			JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
					
			String jsonResponseMessage=jsonValue.get("responseMessage");
			String jsonResponseCode=jsonValue.get("responseCode");
			logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
			
			Assert.assertEquals(jsonResponseMessage,"SUCCESS");
			System.out.println("UpdateCustomerProfile is successful");
			
			logger.log(LogStatus.PASS, "tc_005_updateProfileforTempBlockCards is successfull");
			System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
			System.out.println();
		}
		
		else
		{
			System.out.println("Kindly check the status of the card");
			Assert.fail("Card status is not temp block so failing the test cases");
		}
		
	}
	
	//tc_006_updateProfileforCustomBlockCards
	
	/**
	 * tc_006_updateProfileforCustomBlockCards
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_006_updateProfileforCustomBlockCards(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		/*RestAssured.baseURI=Base_Test.baseURL;
		RestAssured.useRelaxedHTTPSValidation();*/
		
		//create an Object of UpdateProfilePayLoad
		System.out.println();
		System.out.println("----------------------Cardholder update profile API Started-----------------------");
		
		logger = reports.startTest("tc_006_updateProfileforCustomBlockCards");
		logger.assignAuthor("Sanmati Vardhaman").assignCategory("Regression");
		
		logger.log(LogStatus.INFO, "calling card Inquiry to check status for the card ");
		CardInquiryAPI_Test cp=new CardInquiryAPI_Test();
		cp.cardInquiry("2001092963", "8OBzniwZ","4799470414607616","0823","867");
		
		logger.log(LogStatus.INFO, "tc_006_updateProfileforCustomBlockCards started");
		
		CardHolderUpdateProfilePayLoad upPay=new CardHolderUpdateProfilePayLoad();
		
		String last4digits=lastR4Digits.last4(cardNumber);
		Response responseMessage = given().
		contentType("application/json").
		
		body(upPay.updatePayLoad("2001092963","8OBzniwZ","7616",20)).
		
		when().log().body().
		post(updatProfilePost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
				
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String jsonResponseCode=jsonValue.get("responseCode");
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		
		Assert.assertEquals(jsonResponseMessage,"SUCCESS");
		System.out.println("UpdateCustomerProfile is successful");
		
		logger.log(LogStatus.PASS, "tc_006_updateProfileforCustomBlockCards is successfull");
		System.out.println("----------------------Cardholder update profile API Ends here-----------------------");
		System.out.println();
		
	}
	
}

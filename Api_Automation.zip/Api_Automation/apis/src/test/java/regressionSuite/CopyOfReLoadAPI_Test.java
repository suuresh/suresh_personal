package regressionSuite;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import payLoads.RechargePayLoad;
import restAPIPackage.Base_Test;
//import utilities.CSVReadandWrite;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class CopyOfReLoadAPI_Test extends Base_Test {

	/**
	 * Below test cases are covered in this mentioned class
	 * 1.With Valid Card Details
	 * 2.Valid URN and Invalid last4digits.
	 * 3.With Valid Card Details and incorrect customer id.
	 * 4.Minimum AML Reload Limit Check.
	 * 5.Maximum AML Reload Limit Check
	 */
	
	/**
	 * ******************************With Valid Card Details ********************
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_001_rechargeAPI_ValidDetails(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		System.out.println("----------------------tc_001_rechargeAPIValidDetails Started-----------------------");
		
		logger = reports.startTest("tc_001_rechargeAPI_ValidDetails");

		String last4Digits = lastR4Digits.last4(cardNumber);

		logger.log(LogStatus.INFO, "tc_001_rechargeAPI_ValidDetails started");
		RechargePayLoad recPay = new RechargePayLoad();

		Response responseMessage = given()
				.contentType("application/json")
				.
				// pathParam("last4", last4Digits).

				body(recPay.recPayload(urn, last4Digits, custId,myProp.getRechargeAmount())).when().log()
				.body().post(reloadPost).

				then().assertThat().and().statusCode(200).and()
				.contentType(ContentType.JSON).and()
				.//body("responseMessage", equalTo("Success")).

				extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");

		System.out.println("Card recharge response message is "+ responseMessage.asString());

		JsonPath json = JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseMessage = json.get("responseMessage");
		String jsonResponseCode=json.get("responseCode");
		Object avaiBalanceFromJson = json.get("availableBalance");

		System.out.println("avialable balance is " + avaiBalanceFromJson);
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Available balance is "+avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		logger.log(LogStatus.PASS, "tc_001_rechargeAPI_ValidDetails is successfull");
		System.out.println("recharge is successfull");

		System.out.println("----------------------tc_001_rechargeAPIValidDetails Ends here-----------------------");
		System.out.println();
		
		//reloadLogger.appendChild(logger);
		
		

	}
	
	
	
	
	/**
	 * ******************************Valid URN and Invalid last4digits********************
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_002_rechargeAPI_ValidURNandInvalidLast4details(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		System.out.println("----------------------tc_002_rechargeAPIValidURNandInvalidLast4details Started-----------------------");

		logger = reports.startTest("tc_002_rechargeAPIValidURNandInvalidLast4details");
		String last4Digits = lastR4Digits.last4(cardNumber);
	
		logger.log(LogStatus.INFO, "tc_002_rechargeAPIValidURNandInvalidLast4details started");
		RechargePayLoad recPay = new RechargePayLoad();

		Response responseMessage = given()
				.contentType("application/json").
				
				
				 body(recPay.recPayload(urn, ReverseString.reverseString(last4Digits), custId,myProp.getRechargeAmount())).when().log()
				.body().post(reloadPost).

				then().assertThat().and().statusCode(200).and()
				.contentType(ContentType.JSON).and().
				

				extract().response();


		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Card recharge response message is "+ responseMessage.asString());

		JsonPath json = JsonOrXMLObjects.jsonObject(responseMessage);
		 String jsonResponseCode = json.get("responseCode");
		 String jsonResponseMessage=json.get("responseMessage");
		//Object avaiBalanceFromJson = json.get("availableBalance");

		//System.out.println("Available balance is " + avaiBalanceFromJson);
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		Assert.assertEquals(jsonResponseCode,"1083");
		
		logger.log(LogStatus.INFO, "tc_002_rechargeAPIValidURNandInvalidLast4details is successfull");
		
		//System.out.println("Recharges is successful");
		System.out.println();
		System.out.println("----------------------tc_002_rechargeAPIValidURNandInvalidLast4details Ends here-----------------------");
		System.out.println();
	}
	
	/**
	 * ******************************With Valid Card Details and incorrect customer id ********************
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_003_rechargeAPI_ValidURNLast4DigitsandInvalidCustID(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		System.out.println("----------------------tc_003_rechargeAPIValidURNLast4DigitsInvalidCustID Started-----------------------");

		logger = reports.startTest("tc_003_rechargeAPI_ValidURNLast4DigitsandInvalidCustID");
		String last4Digits = lastR4Digits.last4(cardNumber);
	
		
		logger.log(LogStatus.INFO, "tc_003_rechargeAPI_ValidURNLast4DigitsandInvalidCustID started");
		RechargePayLoad recPay = new RechargePayLoad();

		Response responseMessage = given()
				.contentType("application/json").
				
				
				 body(recPay.recPayload(urn,last4Digits, custId+"aa",myProp.getRechargeAmount())).when().log()
				.body().post(reloadPost).

				then().assertThat().and().statusCode(200).and()
				.contentType(ContentType.JSON).and().
				

				extract().response();

		System.out.println("Card recharge response message is "+ responseMessage.asString());

		JsonPath json = JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.get("responseMessage");
		//Object avaiBalanceFromJson = json.get("availableBalance");

		//System.out.println("Available balance is " + avaiBalanceFromJson);
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		Assert.assertEquals(jsonResponseCode,"1084");

		logger.log(LogStatus.INFO, "tc_003_rechargeAPI_ValidURNLast4DigitsandInvalidCustID is successfull");
		//System.out.println("Recharges is successful");
		System.out.println();
		System.out.println("----------------------tc_003_rechargeAPIValidURNLast4DigitsInvalidCustID Ends here-----------------------");
		System.out.println();
	}
	
	
	
	/**
	 * ******************************Minimum AML Recharge Limit Check ********************
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_004_rechargeAPI_MiniumRechargeLimit(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		System.out.println("----------------------tc_004_rechargeAPI_MiniumRechargeLimit Started-----------------------");

		logger = reports.startTest("tc_004_rechargeAPI_MiniumRechargeLimit");
		String last4Digits = lastR4Digits.last4(cardNumber);
	
		
		logger.log(LogStatus.INFO,"tc_004_rechargeAPI_MiniumRechargeLimit started");
		RechargePayLoad recPay = new RechargePayLoad();
		Response responseMessage = given()
				.contentType("application/json").
				
				
				 body(recPay.recPayload(urn,last4Digits, custId,myProp.getMinRechargeAmount())).when().log()
				.body().post(reloadPost).

				then().assertThat().and().statusCode(200).and()
				.contentType(ContentType.JSON).and().
				

				extract().response();

		System.out.println("Card recharge response message is "+ responseMessage.asString());

		JsonPath json = JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.get("responseMessage");
		//Object avaiBalanceFromJson = json.get("availableBalance");

		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		//System.out.println("Available balance is " + avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseCode,"1013");
		
		logger.log(LogStatus.INFO, "tc_004_rechargeAPI_MiniumRechargeLimit is successfull");
		//System.out.println("Recharges is successful");
		System.out.println();
		System.out.println("----------------------tc_004_rechargeAPI_MiniumRechargeLimit Ends here-----------------------");
		System.out.println();
	}
	
	/**
	 * ******************************Maximum AML Recharge Limit Check ********************
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_005_rechargeAPI_MaximumRechargeLimit(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		System.out.println("----------------------tc_005_rechargeAPI_MaximumRechargeLimit Started-----------------------");

		logger = reports.startTest("tc_005_rechargeAPI_MaximumRechargeLimit");
		String last4Digits = lastR4Digits.last4(cardNumber);
	
		

		logger.log(LogStatus.INFO,"tc_005_rechargeAPI_MaximumRechargeLimit started");
		RechargePayLoad recPay = new RechargePayLoad();

		Response responseMessage = given()
				.contentType("application/json").
				
				
				 body(recPay.recPayload(urn,last4Digits, custId,myProp.getMaxRechargeAmount())).when().log()
				.body().post(reloadPost).

				then().assertThat().and().statusCode(200).and()
				.contentType(ContentType.JSON).and().
				

				extract().response();

		System.out.println("Card recharge response message is "+ responseMessage.asString());

		JsonPath json = JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.get("responeMessage");
		//Object avaiBalanceFromJson = json.get("availableBalance");

		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
		//System.out.println("Available balance is " + avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseCode,"1014");
		logger.log(LogStatus.INFO, "tc_005_rechargeAPI_MaximumRechargeLimit is successfull");
		//System.out.println("Recharges is successful");
		System.out.println();
		System.out.println("----------------------tc_005_rechargeAPI_MaximumRechargeLimit Ends here-----------------------");
		System.out.println();
	}
}

package regressionSuite;

//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.UnloadPayLoad;
import restAPIPackage.Base_Test;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.equalTo;

public class CopyUnloadAPI_Test extends Base_Test
{
	/**
	 * 
	 * Below test cases are covered in this mentioned class
	 * 1.With Valid Card Details
	 * 2.Valid URN and Invalid last4digits.
	 * 3.With Valid Card Details and incorrect customer id.
	 * 4.Minimum AML Reload Limit Check.
	 * 5.Maximum AML Reload Limit Check
	 */
	 
	
	
	/**
	 * tc_001_unloadAPIWithValidDetails
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_001_unloadAPIWithValidDetails(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------Unload API Started-----------------------");
		
		logger=reports.startTest("tc_001_unloadAPIWithValidDetails");
		
		String last4Digits=lastR4Digits.last4(cardNumber); 
		System.out.println(last4Digits);
		
		logger.log(LogStatus.INFO, "tc_001_unloadAPIWithValidDetails started");
		//create and object of UnloadPay
		UnloadPayLoad unloadPay=new UnloadPayLoad();
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body(unloadPay.unloadPayLoad(urn, last4Digits, custId,"1000")).
	
		when().log().body().
		post(unloadPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Card unload response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseMessage=json.get("responseMessage");
		String jsonResponseCode=json.get("responseCode");
		Object avaiBalanceFromJson = json.get("availableBalance");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Available balance is "+avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		
		logger.log(LogStatus.PASS, "tc_001_unloadAPIWithValidDetails is successfull");
		System.out.println("Unload is successfull");
		
		System.out.println("----------------------Unload API Ends here-----------------------");
		System.out.println();
			
		
	}

	/**
	 * tc_002_unloadAPIWithValidURNandInvalidLast4Digits
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_002_unloadAPIWithValidURNandInvalidLast4Digits(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------Unload API Started-----------------------");
		
		logger=reports.startTest("tc_002_unloadAPIWithValidURNandInvalidLast4Digits");
		
		String last4Digits=lastR4Digits.last4(cardNumber); 
		System.out.println(last4Digits);
		
		logger.log(LogStatus.INFO, "tc_002_unloadAPIWithValidURNandInvalidLast4Digits started");
		//create and object of UnloadPay
		UnloadPayLoad unloadPay=new UnloadPayLoad();
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body(unloadPay.unloadPayLoad(urn, ReverseString.reverseString(last4Digits), custId,"10000")).
	
		when().log().body().
		post(unloadPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Card unload response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseMessage=json.get("responseMessage");
		String jsonResponseCode=json.get("responseCode");
		Object avaiBalanceFromJson = json.get("availableBalance");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Available balance is "+avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseMessage, "URN AND LAST 4 DIGITS MISMATCH");
		
		logger.log(LogStatus.PASS, "tc_002_unloadAPIWithValidURNandInvalidLast4Digits is successfull");
		System.out.println("Unload is successfull");
		
		System.out.println("----------------------Unload API Ends here-----------------------");
		System.out.println();
			
		
	}
	
	
	
	/**
	 * tc_003_unloadAPIWithInvalidCustID
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_004_unloadAPIWithInvalidCustID(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------Unload API Started-----------------------");
		
		logger=reports.startTest("tc_003_unloadAPIWithInvalidCustID");
		
		String last4Digits=lastR4Digits.last4(cardNumber); 
		System.out.println(last4Digits);
		
		logger.log(LogStatus.INFO, "tc_003_unloadAPIWithInvalidCustID started");
		//create and object of UnloadPay
		UnloadPayLoad unloadPay=new UnloadPayLoad();
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body(unloadPay.unloadPayLoad(urn,last4Digits, custId+last4Digits,"10000")).
	
		when().log().body().
		post(unloadPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Card unload response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseMessage=json.get("responseMessage");
		String jsonResponseCode=json.get("responseCode");
		Object avaiBalanceFromJson = json.get("availableBalance");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Available balance is "+avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseMessage, "URN AND CUSTOMER ID MISMATCH");
		
		logger.log(LogStatus.PASS, "tc_003_unloadAPIWithInvalidCustID is successfull");
		System.out.println("Unload is successfull");
		
		System.out.println("----------------------Unload API Ends here-----------------------");
		System.out.println();
			
		
	}
	
	
	
	/**
	 * tc_004_Check_for_W2A.
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_004_Check_for_W2A(String urn,String custId,String cardNumber,String expiry,String cvv2)
	{
		System.out.println("----------------------Unload API Started-----------------------");
		
		logger=reports.startTest("tc_004_Check_for_W2A");
		
		String last4Digits=lastR4Digits.last4(cardNumber); 
		System.out.println(last4Digits);
		
		logger.log(LogStatus.INFO, "tc_004_Check_for_W2A started");
		//create and object of UnloadPay
		UnloadPayLoad unloadPay=new UnloadPayLoad();
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body(unloadPay.unloadPayLoad(urn,last4Digits, custId+last4Digits,"10000")).
	
		when().log().body().
		post(unloadPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("Card unload response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseMessage=json.get("responseMessage");
		String jsonResponseCode=json.get("responseCode");
		Object avaiBalanceFromJson = json.get("availableBalance");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Available balance is "+avaiBalanceFromJson);
		Assert.assertEquals(jsonResponseMessage, "URN AND CUSTOMER ID MISMATCH");
		
		logger.log(LogStatus.PASS, "tc_004_Check_for_W2A is successfull");
		System.out.println("Unload is successfull");
		
		System.out.println("----------------------Unload API Ends here-----------------------");
		System.out.println();
			
		
	}
	
	
	
	
}

package regressionSuite;



//import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.CardInquiryPayLoad;
import restAPIPackage.Base_Test;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.*;

@Listeners(utilities.MyListener.class)

public class CopyCardInquiryAPI_Test extends Base_Test
{
	/**
	 * tc_001_cardInquirywithValidDetails.
	 * tc_002_cardInquirywithInvalidURNandLast4digits
	 * tc_003_cardInquirywithInvalidCustomerID.
	 * tc_004_cardInquiryWithMalformedRequest
	 * tc_005_cardInquiryonPBlockedCard.
	 * tc_006_cardInquriyOnTBlockedCard
	 * tc_007_cardInquiryOnCustomBlockedCard.
	 * 
	 * 
	 */
	
	
	public int num=0;
	
	
	/**
	 * tc_001_cardInquirywithValidDetails
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	//@Test()
	public void tc_001_cardInquirywithValidDetails(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	//public void cardInquiry()
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_001_cardInquirywithValidDetails");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_001_cardInquirywithValidDetails started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad(urn,custId,last4Digits)).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String cardStatus=jsonValue.get("cardStatus");
		String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_001_activationWithProperDetails is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		if(cardStatus.contains("0"))
		{
			num++;
		}
		
	}
	
	/**
	 * tc_002_cardInquirywithInvalidURNandLast4digits
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	//@Test()
	public void tc_002_cardInquirywithInvalidURNandLast4digits(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	//public void cardInquiry()
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_002_cardInquirywithInvalidURNandLast4digits");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_002_cardInquirywithInvalidURNandLast4digits started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad(urn,custId,ReverseString.reverseString(last4Digits))).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		//String cardStatus=jsonValue.get("cardStatus");
		//String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage);//+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "URN AND LAST 4 DIGITS MISMATCH");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_002_cardInquirywithInvalidURNandLast4digits is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
	
	/**
	 * tc_003_cardInquirywithInvalidCustomerID
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_003_cardInquirywithInvalidCustomerID(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_003_cardInquirywithInvalidCustomerID");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_003_cardInquirywithInvalidCustomerID started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad(urn,custId+"a",last4Digits)).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		//String cardStatus=jsonValue.get("cardStatus");
		//String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage); //+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "URN AND CUSTOMER ID MISMATCH");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_003_cardInquirywithInvalidCustomerID is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
	
	/**
	 * tc_004_cardInquiryWithMalformedRequest
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_004_cardInquiryWithMalformedRequest(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_004_cardInquiryWithMalformedRequest");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_004_cardInquiryWithMalformedRequest started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad("",custId,last4Digits)).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		//String cardStatus=jsonValue.get("cardStatus");
		//String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage); //+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "URN AND CUSTOMER ID MISMATCH");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_004_cardInquiryWithMalformedRequest is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
	
	/**
	 * tc_005_cardInquiryonPBlockedCard -Permanently blocked cards
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_005_cardInquiryonPBlockedCard(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_005_cardInquiryonPBlockedCard");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_005_cardInquiryonPBlockedCard started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad("2001092837","ecYpp2vf","7428")).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String cardStatus=jsonValue.get("cardStatus");
		String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_005_cardInquiryonPBlockedCard is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
	
	/**
	 * tc_006_cardInquiryonTBlockedCard
	 * @param urn
	 * @param custId
	 * @param cardNumber
	 * @param expiry
	 * @param cvv2
	 */
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_006_cardInquiryonTBlockedCard(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_006_cardInquiryonTBlockedCard");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_006_cardInquiryonTBlockedCard started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad("2001092862","qBJ9JuBw","5852")).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String cardStatus=jsonValue.get("cardStatus");
		String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_006_cardInquiryonTBlockedCard is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
	
	
	@Test(dataProvider="unloadCSVData",dataProviderClass=DataProdviderUtility.class)
	public void tc_007_cardInquiryonCBlockedCard(String urn,String custId,String cardNumber,String expiry,String cvv2 )
	{
		System.out.println("----------------------Card Inquiry API Started-----------------------");
		
		logger=reports.startTest("tc_007_cardInquiryonCBlockedCard");
		String last4Digits=lastR4Digits.last4(cardNumber);
		
		/*RestAssured.baseURI=Base_Test.baseURL;
		io.restassured.RestAssured.useRelaxedHTTPSValidation();*/
		
		//Create and Object of CardInquiryPayLoad
		
		logger.log(LogStatus.INFO,"tc_007_cardInquiryonCBlockedCard started");
		CardInquiryPayLoad cPay=new CardInquiryPayLoad();
		
		Response responseMessage = given().
		contentType("application/json").
		body(cPay.cardinqPayLoad("2001092863","YicYnUlj","2844")).
		//body(cPay.cardinqPayLoad("1000035513","IN368865525449","1038")).
		when().log().body().
		post(cardInquiryPost).
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
	
		logger.log(LogStatus.INFO, "Response is triggered");
		System.out.println("card inquiry response string is "+responseMessage.asString());
	
		
		JsonPath jsonValue=JsonOrXMLObjects.jsonObject(responseMessage);
		
		String jsonResponseMessage=jsonValue.get("responseMessage");
		String cardStatus=jsonValue.get("cardStatus");
		String jsonDescription=jsonValue.get("description");
		
		logger.log(LogStatus.INFO, "Json response message is "+jsonResponseMessage+", Card status is "+cardStatus+", description of the card is "+"'"+jsonDescription+"'");
		
		Assert.assertEquals(jsonResponseMessage, "SUCCESS");
		System.out.println("Card Inquriy is sucessfull");
		logger.log(LogStatus.PASS, "tc_007_cardInquiryonCBlockedCard is successfull");
				
		System.out.println("----------------------Card Inquiry API Ends here-----------------------");
		
		/*if(cardStatus.contains("0"))
		{
			num++;
		}*/
		
	}
}

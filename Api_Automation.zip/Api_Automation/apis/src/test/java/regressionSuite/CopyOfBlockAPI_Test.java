package regressionSuite;

//import io.restassured.RestAssured;
import java.util.ArrayList;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.Listeners;
//import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import payLoads.BlockPayLoad;
import restAPIPackage.Base_Test;
import restAPIPackage.CardInquiryAPI_Test;
import restAPIPackage.UnblockAPI_Test;
import utilities.DataProdviderUtility;
import utilities.JsonOrXMLObjects;
//import utilities.PropertiesFile;
import utilities.ReverseString;
import utilities.lastR4Digits;
import static io.restassured.RestAssured.*;

@Listeners(utilities.MyListener.class)
//import static org.hamcrest.Matchers.equalTo;

/*
 * 	Test case covered in this class are
 *  1.With all valid details-Custom Block/TempBlock
 *  2.URN and Card number mismatch.
 *  3.Customer Id mismatch.
 *  4.Blocking already blocked card.
 *  5.Incorrect BlockType
 *  6.TempBlocktheCustomBlockCard
 *  7.Permanent block //
 *  8.Credit block
 *  9.Debit  block
 *  10.Credit_Debit_block
 */


public class CopyOfBlockAPI_Test extends Base_Test
{
	
	String urn=myProp.getURN();
	String cardNumber=myProp.getLast4();
	String last4=lastR4Digits.last4(cardNumber);
	String custId=myProp.getCustomerID();
	
	/**
	 * tc_001_ with valid card details
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_001_cardBlockingProperDetails(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		String myLast=lastR4Digits.last4(cardNumber);
		//call card inquiry api, if status is blocked , then skip this test case saying card is already blocked, else block the card.
				
		logger=reports.startTest("tc_001_cardBlockingProperDetails");
		CardInquiryAPI_Test cp=new CardInquiryAPI_Test();
		
		logger.log(LogStatus.INFO,"calling card inquiry before blocking");
		cp.cardInquiry(urn, custId, cardNumber, expiry, cvv2);
		
		if((cp.num)==1)
		{
		
				
		//Create an object of 	BlockPayLoad
		
		System.out.println("----------------------tc_001_cardBlockingProperDetails Started-----------------------");
				
				
		BlockPayLoad blockPay=new BlockPayLoad();
		
		
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,myLast,custId,myProp.getBlockType())).
	
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.getString("responseMessage");
		
		System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		logger.log(LogStatus.INFO, "Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		
		Assert.assertEquals(jsonResponseCode,"00");
		logger.log(LogStatus.INFO, "Block card is successfull");
		
		System.out.println("block is successfull");
		
		System.out.println("----------------------tc_001_cardBlockingProperDetails API Ends here-----------------------");
		System.out.println();
		
		}
		
		else
		{
			System.out.println("Card is already blocked so skipping *****--- tc_001_cardBlockingProperDetails---*****");
			logger.log(LogStatus.INFO, "Card is already blocked so skipping *****--- tc_001_cardBlockingProperDetails---*****" );
		}
		
	}
	
	/**
	 * tc_002_ with valid invalid last 4 digits details
	 */
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_002_cardBlockingWithIncorrectLast4Digits(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		String last4=lastR4Digits.last4(cardNumber);
		System.out.println("----------------------tc_002_cardBlockingWithIncorrectLast4Digits Started-----------------------");
		
		logger=reports.startTest("tc_002_cardBlockingWithIncorrectLast4Digits");
		logger.log(LogStatus.INFO, "tc_002_cardBlockingWithIncorrectLast4Digits started");
		BlockPayLoad blockPay=new BlockPayLoad();
		
		
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,ReverseString.reverseString(last4),custId,myProp.getBlockType())).
		
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.getString("responseMessage");
		
		System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		logger.log(LogStatus.INFO, "Actual Response code is "+jsonResponseCode);
		logger.log(LogStatus.INFO, "Actual Response messsage is "+jsonResponseMessage);

		
		Assert.assertEquals(jsonResponseCode,"1083");
		logger.log(LogStatus.PASS,"tc_002_cardBlockingWithIncorrectLast4Digits is successfull");
		
		System.out.println("block is successfull");
		
		System.out.println("----------------------tc_002_cardBlockingWithIncorrectLast4Digits API Ends here-----------------------");
		System.out.println();
		
	}
	
	/**
	 *
	 * tc_003_ with wrong Customer id details
	 *
	 **/
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_003_cardBlockingWithIncorrectCustomerId(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		String last4=lastR4Digits.last4(cardNumber);
		System.out.println("----------------------tc_003_cardBlockingWithIncorrectCustomerId Started-----------------------");
		
		logger=reports.startTest("tc_003_cardBlockingWithIncorrectCustomerId");
		BlockPayLoad blockPay=new BlockPayLoad();
				
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,last4,custId+"aa",myProp.getBlockType())).
		
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		
		logger.log(LogStatus.INFO, "Response is triggered");
		
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.getString("responseMessage");
		
		System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		logger.log(LogStatus.INFO, "Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		
		Assert.assertEquals(jsonResponseCode,"1084");
		logger.log(LogStatus.PASS, "tc_003_cardBlockingWithIncorrectCustomerId is successfull");
		System.out.println("block is successfull");
		
		System.out.println("----------------------tc_003_cardBlockingWithIncorrectCustomerId API Ends here-----------------------");
		System.out.println();
	}
	
	
	/**
	 *
	 * tc_004_ blocking already blocked card.
	 *
	 **/
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_004_cardBlockingAlreadyBlockedCard(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		String last4=lastR4Digits.last4(cardNumber);
		System.out.println("----------------------tc_004_cardBlockingAlreadyBlockedCard Started-----------------------");
				
		logger=reports.startTest("tc_004_cardBlockingAlreadyBlockedCard");
		BlockPayLoad blockPay=new BlockPayLoad();
				
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,last4,custId,myProp.getBlockType())).
		
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.getString("responseMessage");
		System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		logger.log(LogStatus.INFO, "Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		
		Assert.assertEquals(jsonResponseCode,"1064");
		logger.log(LogStatus.PASS, "tc_004_cardBlockingAlreadyBlockedCard is successfull");
		
		System.out.println("block is successfull");
		
		System.out.println("----------------------tc_004_cardBlockingAlreadyBlockedCard API Ends here-----------------------");
		System.out.println();
	}
	
	
	/**
	 *
	 * tc_005_ blocking card with incorrect blockType
	 *
	 **/
	
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_005_cardBlockingwithIncorrectBlockType(String urn, String custId, String cardNumber,String expiry, String cvv2)
	{
		String last4=lastR4Digits.last4(cardNumber);
		System.out.println("----------------------tc_005_cardBlockingwithIncorrectBlockType Started-----------------------");
				
		logger=reports.startTest("tc_005_cardBlockingwithIncorrectBlockType");
		BlockPayLoad blockPay=new BlockPayLoad();
				
		Response responseMessage = given().
				contentType("application/json").
					
		body(blockPay.blockPayload(urn,last4,custId,"myBlock")).
		
		when().log().body().
		post(blockPost).
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		//body("responseCode",equalTo("00")).
		
		extract().response();
		logger.log(LogStatus.INFO, "Response is triggered");
		
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
		String jsonResponseCode = json.get("responseCode");
		String jsonResponseMessage=json.getString("responseMessage");
		
		System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		logger.log(LogStatus.INFO, "Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
		
		Assert.assertEquals(jsonResponseCode,"1112");
		logger.log(LogStatus.PASS, "tc_005_cardBlockingwithIncorrectBlockType is successfull");
		
		System.out.println("block is successfull");
		
		System.out.println("----------------------tc_005_cardBlockingwithIncorrectBlockType API Ends here-----------------------");
		System.out.println();
	}
	
	
	/**
	 *
	 * tc_006_ alltypeofCardBlocks.
	 *
	 **/
	@Test(dataProvider = "getCSVData", dataProviderClass = DataProdviderUtility.class)
	public void tc_006_alltypeofCardBlocks(String urn, String custId, String cardNumber_1,String expiry, String cvv2)
	{
		/**
		 *  check the status of the card before proceeding. If card status is blocked ,please unblock it, else proceed with the process.
		 *  
		 *  
		 */
		logger=reports.startTest("tc_006_alltypeofCardBlocks");
		CardInquiryAPI_Test cp=new CardInquiryAPI_Test();
		
		cp.cardInquiry(urn, custId, cardNumber_1, expiry, cvv2);
		logger.log(LogStatus.INFO, "Calling card Inquiry API to check card status before proceeding with blocking");
		
		if((cp.num)==0) //card is not active , its in other status
		{
			UnblockAPI_Test ub=new UnblockAPI_Test();
			ub.cardUnblocking(urn, custId, cardNumber_1, expiry, cvv2);
		}
		
		
		
		String last4=lastR4Digits.last4(cardNumber_1);
		System.out.println("----------------------tc_006_alltypeofCardBlocks Started-----------------------");
		
		/*String urn_All=myProp.getURNALL();
		String cardNumber=myProp.getCardNumberALL();
		String last4_All=lastR4Digits.last4(cardNumber);
		String custId_All=myProp.getALLCustomerID();*/
				
		
		BlockPayLoad blockPay=new BlockPayLoad();
				
		//create an ArrayList of type of blocks;
		ArrayList<String>myBlockType=new ArrayList<String>();
		myBlockType.add("Custom");
		myBlockType.add("Temporary");
		myBlockType.add("Debit");
		myBlockType.add("Credit");
		myBlockType.add("CreditDebit");
		
		//iterate for the size of arraylist and do all types of blocks
		
		for ( int i=0;i<myBlockType.size();i++)
		{
			logger.log(LogStatus.INFO,myBlockType.get(i)+ " block is in progress");
			Response responseMessage = given().
					contentType("application/json").
						
			body(blockPay.blockPayload(urn,last4,custId,myBlockType.get(i))).
			
			when().log().body().
			post(blockPost).
			
			then().
			assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
			//body("responseCode",equalTo("00")).
			
			extract().response();
			logger.log(LogStatus.INFO, "Response is triggered");
			
					
			System.out.println("Card block response message is "+responseMessage.asString());
			
			JsonPath json=JsonOrXMLObjects.jsonObject(responseMessage);
			String jsonResponseCode = json.get("responseCode");
			String jsonResponseMessage=json.getString("responseMessage");
			System.out.println("Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
			logger.log(LogStatus.INFO, "Json response code is "+jsonResponseCode+" and response messsage is "+jsonResponseMessage);
			
			Assert.assertEquals(jsonResponseCode,"00");
			logger.log(LogStatus.PASS, myBlockType.get(i)+"block is successfull");
			
			logger.log(LogStatus.INFO, "-----------------------------------------");
			
			System.out.println(myBlockType.get(i)+"block is successfull");
						
			System.out.println();
			
			///////////////////once the block is successful -- call unblock 
			
			if(jsonResponseCode.equals("00"))
			{
				System.out.println("calling unblock method as block is successfull");
				
				//create an object Unlbock test
				UnblockAPI_Test ublock=new UnblockAPI_Test();
				ublock.cardUnblocking(urn, custId, cardNumber_1,"0322" ,"234");
				
				
			}
			else
			{
				System.out.println("Warningg!!!!!!!---card is not blocked ---please check");
			}
				
		}
		System.out.println("----------------------tc_006_alltypeofCardBlocks API Ends here-----------------------");
		
		
	}
	
	
}

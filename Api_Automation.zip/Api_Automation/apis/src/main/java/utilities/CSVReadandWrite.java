package utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.List;









import java.util.StringTokenizer;

import com.opencsv.CSVWriter;

public class CSVReadandWrite 
{

	public static String csvFilePath="E:\\Sanmati\\Automation\\Api_Automation\\apis\\DataFolder\\myCards.txt";
	public static String csvFilePathRegression="E:\\Sanmati\\Automation\\Api_Automation\\apis\\DataFolder\\RegressionCards.txt";
	public static  BufferedWriter writer=null;
	public static BufferedReader read=null;
	public static FileWriter fWrite=null;
	
	public static String line="";
	static String [] words;
	
	static int numLines=0;
	
	
		
		
	/**
	 * This method is used to write data into CSV
	 * @param myList
	 */
	public static void writeToCSV(ArrayList<String> recArry,String mode)
	{
		try {
			
			if(mode.equalsIgnoreCase("smoke"))
			{
				fWrite=new FileWriter(csvFilePath,true);
				writer=new BufferedWriter(fWrite);
				for(int i=0;i<recArry.size();i++)
				{
					writer.write(recArry.get(i));
					writer.write(",");
				}
				writer.newLine();
			}
			
			else
			{
				fWrite=new FileWriter(csvFilePathRegression,true);
				writer=new BufferedWriter(fWrite);
				for(int i=0;i<recArry.size();i++)
				{
					writer.write(recArry.get(i));
					writer.write(",");
				}
				writer.newLine();
			}
				
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			if (writer!=null)
			{
				try {
					writer.flush();
					writer.close();
					fWrite.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	/**
	 * This method is used to read data from the CSV
	 * @return 
	 */
	
	
	public static String readFromCSV()
	{
		
		try {
			read=new BufferedReader(new FileReader(csvFilePath));
					
			while((line=read.readLine())!=null)
			{
				  
	            return line;
			}
			
			
		} 
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	public static int numberOfLinesCSV()
	{
		try {
			read=new BufferedReader(new FileReader(csvFilePath));
			numLines = 0;	
			while(read.readLine()!=null)
			{
				  
	            numLines++;
			}
			return numLines;
			
		} 
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			try {
				read.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}
}
	
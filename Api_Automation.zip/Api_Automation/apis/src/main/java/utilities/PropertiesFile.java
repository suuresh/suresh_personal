package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFile
{
	
	Properties pro;
	FileInputStream fis;
	File f;
	public static String configFilePath="E:\\Sanmati\\Automation\\Api_Automation\\apis\\Configurations\\config.properties";
	
	public PropertiesFile()
	{
		f=new File (configFilePath);
		try {
			fis=new FileInputStream(f);
			pro=new Properties();
			pro.load(fis);
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	/**
	 * This method is used to get type of block from config.properties file
	 * @return 
	 * 
	 */
	
	public  String getBlockType( )
	{
		return pro.getProperty("blockType");
	}
	
	/**
	 * This method is used to get Bank ID.
	 * @return
	 */

	public  String getBankID()
	{
		return pro.getProperty("bankID");
	}
	
	/**
	 * it returns productID
	 * @return
	 */
	public String getProductId()
	{
		return  (String) pro.getProperty("productId");
	}
	
	/**
	 * it returns profileID
	 * @return
	 */
	
	public String getCardProfileId()
	{
		return pro.getProperty("cardProfileId");
		
	}
	
	/**
	 * it returns Minimum recharge amount
	 * @return
	 */
	public int getMinRechargeAmount()
	{
		return Integer.parseInt(pro.getProperty("minRechargeAmount"));
		
	}
	
	/**
	 * it returns Maximum recharge amount
	 * @return
	 */
	public int getMaxRechargeAmount()
	{
		return Integer.parseInt(pro.getProperty("maxRechargeAmount"));
		
	}
	
	/**
	 * it returns Recharge amount
	 * @return
	 */
	public int getRechargeAmount()
	{
		return Integer.parseInt(pro.getProperty("rechargeAmount"));
		
	}
	
	/**
	 * This method returns URN ,required for cardBlocking
	 * @return
	 */
	public String getURN()
	{
		return pro.getProperty("urn");
		
	}
	
	/**
	 * This method returns last4digits ,required for cardBlocking
	 * @return
	 */
	public String getLast4()
	{
		return pro.getProperty("cardNumber");
			
	}
	
	/**
	 * customerID
	 */
	public String getCustomerID()
	{
		return pro.getProperty("customerId");
			
	}
	
	// ******************Below methods are used to get card numbers to do all modes of block******************
	/**
	 * its returns URN to perform all modes of block
	 * @return
	 */
	
	public String getURNALL()
	{
		return pro.getProperty("urn_all");
			
	}
	
	/**
	 * its returns CardNumber to perform all modes of block
	 * @return
	 */
	public String getCardNumberALL()
	{
		return pro.getProperty("cardNumber_all");
			
	}
	
	/**
	 * its returns CustomerID to perform all modes of block
	 * @return
	 */
	
	public String getALLCustomerID()
	{
		return pro.getProperty("customerId_all");
			
	}
	
	/**
	 * 
	 * @return
	 */
	public String getClientId()
	{
		return pro.getProperty("clientId");
			
	}
}

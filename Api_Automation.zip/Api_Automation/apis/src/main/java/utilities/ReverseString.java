
package utilities;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class ReverseString
{
	/**
	 * This method is used to return reverseString.
	 * @param last4digit
	 * @return
	 */

	public static String reverseString(String last4digit)
	{
		char[]c=last4digit.toCharArray();
		String rev="";
		
		for ( int i=c.length-1;i>=0;i--)
		{
			rev=rev+c[i];
		}
		return rev;
		
	}
}

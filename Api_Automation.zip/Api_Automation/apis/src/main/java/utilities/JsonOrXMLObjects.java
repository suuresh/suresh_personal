package utilities;



import payLoads.BasePayLoad;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class JsonOrXMLObjects extends BasePayLoad
{

	/**
	 * This method return JSON Object
	 * @return 
	 */
	public static JsonPath jsonObject(Response response)
	{
	
		JsonPath myJson=new JsonPath(response.asString());
		
		return myJson;
		
		
	}
	
	/**
	 * This method returns XML Object
	 * @param response
	 * @return
	 */
	
	public static XmlPath xmlObject(Response response)
	{
	
		XmlPath myXml=new XmlPath(response.asString());
		
		return myXml;
		
		
	}
	
	
	
}

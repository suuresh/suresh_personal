package utilities;




import org.apache.commons.lang3.RandomStringUtils;

public class RandomString
{
	
	public static String randomStringGen()
	{
		String randomValue = RandomStringUtils.randomAlphanumeric(8);
		return randomValue;
	}

		
	
}

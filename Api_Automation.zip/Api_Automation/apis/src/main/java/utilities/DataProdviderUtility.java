package utilities;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import org.testng.annotations.DataProvider;

public class DataProdviderUtility
{
	/**
	 * This data provider is for reload
	 * @return
	 */
	@DataProvider(name="getCSVData")
	public static Object[][] reloadDataP()
	{
		int value=CSVReadandWrite.numberOfLinesCSV();
		//System.out.println("number of lines "+value);
		Object[][] obj=new Object[value][5];
		int row=0;
		int col = 0;
		String line=null;
		BufferedReader bufRdr = null;
		FileReader fRdr=null;
		try {
			fRdr=new FileReader(CSVReadandWrite.csvFilePath);
			bufRdr = new BufferedReader(fRdr);
			while ((line=bufRdr.readLine())!=null && row<value)
			{
				StringTokenizer st = new StringTokenizer(line,",");
				while (st.hasMoreTokens())
		        {
		            //get next token and store it in the array
					
					obj[row][col] = st.nextToken();
		            col++;
		        }
		        col = 0;
		        row++;
		        
			}
		
			return obj;
			
		 
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				bufRdr.close();
				fRdr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return obj;
		
		
	}
	
	/**
	 * This data provider is for unload
	 */

	@DataProvider(name="unloadCSVData")
	public static Object[][] unloadDataP()
	{
		int value=CSVReadandWrite.numberOfLinesCSV();
		//System.out.println("number of lines is "+value);
		Object[][] obj1=new Object[value][5];
		int row=0;
		int col = 0;
		String line=null;
		FileReader fRdr1=null;
		BufferedReader bufRdr1 = null;
		try {
			fRdr1=new FileReader(CSVReadandWrite.csvFilePath);
			bufRdr1 = new BufferedReader(fRdr1);
			while ((line=bufRdr1.readLine())!=null && row<value)
			{
				StringTokenizer st = new StringTokenizer(line,",");
				while (st.hasMoreTokens())
		        {
		            //get next token and store it in the array
					
					obj1[row][col] = st.nextToken();
		            col++;
		        }
		        col = 0;
		        row++;
			}
				        
			return obj1;
		 
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				bufRdr1.close();
				fRdr1.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return obj1;
				
	}
	
	
	
	
	
}

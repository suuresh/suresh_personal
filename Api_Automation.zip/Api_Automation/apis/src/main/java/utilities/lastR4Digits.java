package utilities;

public class lastR4Digits
{

	/**
	 * This method returns last 4digits of card number.
	 * @param cardnumber
	 * @return
	 */
	public static String last4(String number)
	{
		String mynum=number.substring(number.length()-4);
		return mynum;
	}
	
	/*public static void main(String[] args)
	{
	
		System.out.println(last4("4670200151695589"));
		
	}*/
}

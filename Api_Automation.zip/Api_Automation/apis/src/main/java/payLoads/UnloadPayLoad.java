package payLoads;

import utilities.RandomString;

public class UnloadPayLoad extends BasePayLoad
{

	public String unloadPayLoad(String urn,String last4digits,String custid,String amount)
	{
		String payLoadBody="{"+
			     "\"messageCode\": \"1480\","+
			    // "\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			     "\"clientTxnId\": "+"\""+RandomString.randomStringGen()+"\""+","+
			     "\"requestDateTime\": \"20161010102112\","+
			    // "\"bankId\": 6019,"+
			    "\"bankId\":"+pf.getBankID()+","+
			     "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			     "\"entityId\": 100,"+
			     "\"last4Digits\":"+"\""+last4digits+"\""+","+
			     "\"urn\":"+"\""+urn+"\""+","+
			     "\"agentComments\": \"Debit to customer\","+
			     "\"customerId\":"+"\""+custid+"\""+","+
			   "\"transactionAmount\":"+amount+","+
			   "\"sourceAccountType\":1,"+
			   "\"sourceAccount\":\"1234\","+
			   "\"originalClientTxnId\":\"201607040918424092qE93qK4\","+
			 	"\"reserved1\":\"Unload-Credit\","+
			 	"\"reserved2\":\"1\","+
			 	"\"reserved3\":\"2\","+
			 	"\"reserved4\":\"3\","+					// O|10016 (Bank account transfer)---unload limit 20000 , 0|10017(IMPS account transfer)--20000. 0|10018, 0|10019,0|10020,0|10021
			 	"\"reserved5\":\"Unlaod-Only\""+
			 "}";
		
		return payLoadBody;
		
	}
}

package payLoads;

import utilities.RandomString;

public class CardHolderUpdateProfilePayLoad extends BasePayLoad
{

	public String updatePayLoad(String urn,String custId,String last4digits,int profileID)
	{
		String payLoadBody="{"+
				"\"messageCode\": \"1280\","+
				//"\"clientId\": \"WIBMO\","+
				"\"clientId\":"+"\""+pf.getClientId()+"\""+","+
				"\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
				//"\"bankId\": 6019,"+
				"\"bankId\":"+pf.getBankID()+","+
				"\"requestDateTime\": \"20160715025837\","+
				"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
				"\"entityId\": 100,"+
				"\"urn\":"+urn+","+
				"\"last4Digits\":"+"\""+last4digits+"\""+","+
				"\"customerId\":"+"\""+custId+"\""+","+
				"\"cardholder\":{"+
				"\"cardProfileId\":"+profileID+","+
				"\"cardholderFirstName\": \"Sanmati \","+
				"\"cardholderLastName\": \"Vardhaman\","+
				"\"cardholderMobile\": \"9900917736\","+
				"\"cardholderDateOfBirth\" :\"01-01-2001\","+
				"\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","+
				"\"cardholderAddress\":\"attiguppe, Vijayanagar\","+
				"\"cardholderCity\":\"Bangalore\","+
				"\"cardholderState\":\"Karnataka\","+
				"\"cardholderZipCode\":\"560040\","+
				"\"cardholderCountry\":\"India\","+
				"\"customerIdentityProfile\":"+
				"{"+            
				"\"customerAadharCardNumber\": \"A_feb13_02\","+ 
				"\"customerPANCardNumber\": \"\","+     
				"\"customerPassportNumber\": \"\","+   
				"\"customerVoterIdNumber\": \"\","+    
				"\"customerDrivingLicenseNumber\": \"\""+ 
				 "}"+
				"}"+
				"}";
		
		return payLoadBody;
	}
}

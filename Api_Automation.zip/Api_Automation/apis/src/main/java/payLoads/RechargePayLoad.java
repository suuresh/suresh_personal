package payLoads;

import utilities.RandomString;

public class RechargePayLoad extends BasePayLoad
{
	
	public String recPayload(String urn,String last4digits,String custid,int rechargeAmount)
	{
		
		String payLoadBody="{"+
			     "\"messageCode\": \"1080\","+
			     //"\"clientId\": \"WIBMO\","+
			     "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			     "\"clientTxnId\": "+"\""+RandomString.randomStringGen()+"\""+","+
			     "\"requestDateTime\": \"20161024102112\","+
			     //"\"bankId\": 6019,"+
			     "\"bankId\":"+pf.getBankID()+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"entityId\": 100,"+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+"\""+urn+"\""+","+
			    "\"customerId\":"+"\""+custid+"\""+","+
			      "\"agentComments\":\"Credit to customer rest\","+
			   "\"transactionAmount\":"+rechargeAmount+","+
			   "\"sourceAccountType\":\"00\","+
			  "\"sourceAccount\":\"1234\","+
			  "\"originalClientTxnId\":\"201607040918424092qE93qK4\","+
			    "\"reserved1\":\"\","+
			     "\"reserved2\":\"\","+
			     "\"reserved3\":\"0\","+
			     "\"reserved4\":\"PG Load\","+
			     "\"reserved5\":\"I|10003\""+
			     /*"\"reserved1\":\"cash_back_file_28Aug18_888.csv|201808281228581504nR78wR5\","+
			     "\"reserved2\":\"Credit from WIBMO Pay zapp Cashback\","+
			     "\"reserved3\":\"1\","+
			     "\"reserved4\":\"I|10016\","+
			     "\"reserved5\":\"System CashBacK\""+*/
			"}";
		
		return payLoadBody;
	}

	
}


package payLoads;

//import java.util.Properties;

//import utilities.PropertiesFile;
import utilities.RandomString;

public class ActivationPayLoad extends BasePayLoad
{
	/**
	 * This method return the payLoadBody
	 * @return
	 */
	
	
	public String actPayload(String productID,String profileID,String amount)
	{
		System.out.println();
		System.out.println("---*** This is Actviation API request***----");
		System.out.println();
		String payLoadBody="{"
				+ "\"messageCode\": \"1010\","
				+ "\"clientId\":"+"\""+pf.getClientId()+"\""+","
				//+ "\"clientId\": \"SURYA\","
				+ "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","			
				+ "\"requestDateTime\": \"20161223121001\","
				+ "\"bankId\":"+pf.getBankID()+","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"entityId\": 100,"
				+ "\"loadAmount\":"+amount+","
				+ "\"productId\":"+productID+","
				+ "\"cardHolder\": {"
				+ "\"cardholderFirstName\":\"Velocity Check Non KYC\","
				+ "\"cardholderLastName\": \"NewAPI\","
				+ "\"cardholderMobile\": \"9900917736\","
				+ "\"cardholderDateOfBirth\" :\"25-12-1997\","
				+ "\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","
				+ "\"cardholderAddress\":\"WINGS,Cambridge Road,Domlur1\","
				+ "\"cardholderCity\":\"Bangalore\","
				+ "\"cardholderState\":\"Karnataka\","
				+ "\"cardholderZipCode\":\"560020\","
				+ "\"cardholderCountry\":\"India\"" + "},"
				+ "\"customerIdentityProfile\": {"
				+ "\"customerAadharCardNumber\": \"A_feb13_02\","
				+ "\"customerPANCardNumber\": \"\","
				+ "\"customerPassportNumber\": \"\","
				+ "\"customerVoterIdNumber\": \"\","
				+ "\"customerDrivingLicenseNumber\": \"\"" + "},"
				+ "\"cardProfileId\":"+ profileID+","
				+ "\"customerId\":"+"\""+RandomString.randomStringGen()+"\""+","
				+ "\"sourceAccountType\":\"00\","
				+ "\"sourceAccount\":\"1234\"" + "}";
		
		return payLoadBody;
	}

	public String actPayloadDuplicateCardCreationCheck(String custID,String clientTxnID)
	{
		System.out.println();
		System.out.println("---*** This is Actviation API request***----");
		System.out.println();
		String payLoadBody="{"
				+ "\"messageCode\": \"1010\","
				+ "\"clientId\": \"WIBMO\","
				+ "\"clientTxnId\":"+"\""+clientTxnID+"\""+","			
				+ "\"requestDateTime\": \"20161223121001\","
				+ "\"bankId\":"+pf.getBankID()+","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"entityId\": 100,"
				+ "\"loadAmount\": \"300000\","
				+ "\"productId\":"+pf.getProductId()+","
				+ "\"cardHolder\": {"
				+ "\"cardholderFirstName\":\"Velocity Check Non KYC\","
				+ "\"cardholderLastName\": \"NewAPI\","
				+ "\"cardholderMobile\": \"9900917736\","
				+ "\"cardholderDateOfBirth\" :\"25-12-1997\","
				+ "\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","
				+ "\"cardholderAddress\":\"WINGS,Cambridge Road,Domlur1\","
				+ "\"cardholderCity\":\"Bangalore\","
				+ "\"cardholderState\":\"Karnataka\","
				+ "\"cardholderZipCode\":\"560020\","
				+ "\"cardholderCountry\":\"India\"" + "},"
				+ "\"customerIdentityProfile\": {"
				+ "\"customerAadharCardNumber\": \"A_feb13_02\","
				+ "\"customerPANCardNumber\": \"\","
				+ "\"customerPassportNumber\": \"\","
				+ "\"customerVoterIdNumber\": \"\","
				+ "\"customerDrivingLicenseNumber\": \"\"" + "},"
				+ "\"cardProfileId\":"+ pf.getCardProfileId()+","
				+ "\"customerId\":"+"\""+custID+"\""+","
				+ "\"sourceAccountType\":\"00\","
				+ "\"sourceAccount\":\"1234\"" + "}";
		
		return payLoadBody;
		
	}
}

package payLoads;

import utilities.RandomString;

public class UnBlockCardPayLoad extends BasePayLoad
{

	public String unblockPayLoad(String urn,String last4digits,String custId)
	{
		String payLoadBody="{"+
			    "\"messageCode\": \"1250\","+
			   // "\"clientId\": \"WIBMO\","+
			   "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			    "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
			    "\"requestDateTime\": \"20161223121001\","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+pf.getBankID()+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"entityId\": 100,"+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+urn+","+
			    "\"customerId\":"+"\""+custId+"\""+","+
				"\"reserved1\":\"imaker\","+
				"\"reserved2\":\"verfication complete.UnBlocking custom block card Rest\""+
			"}";
		
		return payLoadBody;
	}
}

package payLoads;

import org.apache.commons.lang3.RandomUtils;

import utilities.RandomString;

public class AMLInquiryPayLoad extends BasePayLoad
{

	public String amlPayLoad(String urn,String custId,String last4digits)
	{
		String payLoadBody="{"+
			    "\"messageCode\": 1550,"+
			    //"\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
			    "\"requestDateTime\":\"20171118170601\","+
			    //"\"bankId\": \"6019\","+
			    "\"bankId\":"+pf.getBankID()+","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+"\""+urn+"\""+","+
			    "\"customerId\":"+"\""+custId+"\""+
			"}" ;
		return payLoadBody;
		
	}
}

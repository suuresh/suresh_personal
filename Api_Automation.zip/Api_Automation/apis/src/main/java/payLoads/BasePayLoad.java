package payLoads;

//import java.util.Properties;

import utilities.PropertiesFile;

public class BasePayLoad {

	// create a method which return object of properties file
	
	PropertiesFile pf=new PropertiesFile();
}

package payLoads;

import utilities.RandomString;

public class CardInquiryPayLoad extends BasePayLoad
{
	
	/**
	 * This method return the body-
	 * @return
	 */
	
	public String cardinqPayLoad(String urn,String custId,String last4digits)
	{
		String payLoadBody="{"+
			    "\"messageCode\": 1090,"+
			    //"\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
			    "\"requestDateTime\":20161031214559,"+
			    //"\"bankId\": 6019,"+
			    "\"bankId\":"+pf.getBankID()+","+
			    "\"customerId\":"+"\""+custId+"\""+","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+urn+""+

			"}";
		
		return payLoadBody;
	}

}

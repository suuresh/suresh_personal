/**
 * 
 */
package payLoads;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class WalletStatementInquiryPayLoad extends BasePayLoad 
{
	
	public String walletStatementPayload(String urn,String last4digits,String custid)
	{
		System.out.println();
		System.out.println("---*** This is Wallet Statement Inquriy API request***----");
		System.out.println();
		
		String payLoadBody="{"+
			    "\"messageCode\": \"1072\","+
			   // "\"clientId\": \"WIBMO\","+
			   "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+pf.getBankID()+","+
			    "\"requestDateTime\": \"20160627102149\","+
			    "\"clientTxnId\": \"Inq_Sam_cATbRrmibRMArv21\","+
			    "\"fromDate\":\"13/08/2017\","+
			    "\"toDate\": \"13/08/2018\","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+"\""+urn+"\""+","+
			    "\"customerId\":"+"\""+custid+"\""+ 
			"}";
		return payLoadBody;
	}
	

}

package payLoads;

import utilities.RandomString;

public class TransactionInquiryPayLoad extends BasePayLoad 
{

	public String txnInqPayLoad(String urn,String last4digits,String custid)
	{
		System.out.println();
		String payLoadBody=
				"{"+
			    "\"messageCode\": \"1070\","+
			   // "\"clientId\": \"WIBMO\","+
			   "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+pf.getBankID()+","+
			    "\"requestDateTime\": \"20161221210608\","+
			    "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+urn+","+
			    "\"customerId\":"+"\""+custid+"\""+","+
			    "\"fromDate\":\"08/06/2015\","+
			    "\"toDate\": \"30/06/2019\","+
			    "\"pageNumber\":\"1\","+
			    "\"count\":\"10\","+
			    "\"fromRowId\":\"0\""+
			"}";
				
		return payLoadBody;
	}
}


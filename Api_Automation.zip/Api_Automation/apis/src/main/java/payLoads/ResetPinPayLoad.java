package payLoads;

public class ResetPinPayLoad  extends BasePayLoad
{

	public String resetPayLoad()
	{
		String payLoadBody="{"+
			    "\"messageCode\": \"1120\","+
			    //"\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+pf.getBankID()+","+
			    "\"entityId\": 100,"+
			    "\"requestDateTime\": \"20161010102112\","+
			    "\"clientTxnId\": \"201507271458370149gM90jY0\","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"newPIN\": \"1212\","+
			    "\"urn\": 1001195628,"+
			    "\"last4Digits\":\"5277\","+
			    "\"customerId\":\"IN80888888082\""+
							"}";
		
		return payLoadBody;
		
	}
}

package payLoads;

import utilities.RandomString;

public class BlockPayLoad  extends BasePayLoad
{

	public String blockPayload(String urn,String last4digits,String custId,String blockType)
	{
		System.out.println();
		System.out.println("----***This is blocked card API request***----");
		String payLoadBody="{"+
			    "\"messageCode\": \"1240\","+
			    //"\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+pf.getClientId()+"\""+","+
			    "\"clientTxnId\":"+"\""+RandomString.randomStringGen()+"\""+","+
			    "\"requestDateTime\": \"20161223121001\","+
			    //"\"bankId\": 6019,"+
			    "\"bankId\":"+pf.getBankID()+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"entityId\": 100,"+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
				"\"urn\":"+urn+","+
				"\"blockType\":"+"\""+blockType+"\""+","+
				"\"customerId\":"+"\""+custId+"\""+","+
				"\"reserved1\":\"Block\","+
				"\"reserved2\":\"mobile lost so custom Blocking the card API\""+
					"}";
		return payLoadBody;
		
	}
}

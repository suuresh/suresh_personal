package com.csr.pomPage;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.utilities.BaseTest;
import com.utilities.TakeScreenshotUtility;
import com.utilities.ZoomInZoomOutUtility;

public class CSRPage extends BaseTest
{

WebDriver driver;
	

@FindBy(xpath="//input[@name='txtUserId']")
private WebElement csruserName;

@FindBy(xpath="//input[@name='txtPassword']")
private WebElement csrPassword;

@FindBy(xpath="//input[@value='Sign In']")
private WebElement signInButton;

//---post login web Elements --

@FindBy(linkText="ACCOSA (Lite)")
private WebElement accosaLink;

@FindBy(xpath="//input[@id='txtSearch']")
private WebElement userCardNumber;


@FindBy(xpath="//input[@id='urn']")
private WebElement cardURN;

//openAuthSettleCreditsRequired

@FindBy(xpath="//input[@name='openAuthSettleCreditsRequired']")
private WebElement checkBox;

//btnSearch
@FindBy(xpath="//button[text()='GO']")
private WebElement goButton;

//new tab
@FindBy(css="body")
private WebElement newTab;

//back button
@FindBy(xpath="//input[@value='Back']")
private WebElement backButton;

@FindBy(linkText="Sign Out")
private WebElement signOutButton;

/**
 *  intialization of all the webelements
 */

public CSRPage(WebDriver driver)
{
	this.driver=driver;
}


public void loginIntoCSR(String uname,String password) 
{
	csruserName.sendKeys(uname);
	csrPassword.sendKeys(password);
	signInButton.click();
	waitThread();
}

public String checkCardDetails(String cardnumber,String screenshotName) 
{
	String path="";
	accosaLink.click();
	waitThread();
	userCardNumber.sendKeys(cardnumber);
	checkBox.click();
	goButton.click();
	
	//this is two switch to new tab and take screenshot
	
	newTab.sendKeys(Keys.CONTROL + "t");
	ArrayList<String> tab2=new ArrayList<String>(driver.getWindowHandles());
	System.out.println("size of array list is "+tab2.size());
	driver.switchTo().window(tab2.get(0));
	System.out.println("Focus is new tab now");
	ZoomInZoomOutUtility.zoomOut(driver);
	try {
		path=TakeScreenshotUtility.getScreenshot(screenshotName, driver);
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	ZoomInZoomOutUtility.zoomIN(driver);
	waitThread();
	backButton.click();
	//driver.switchTo().window(tab2.get(0));
	System.out.println("Focus is home tab now");
	signOutButton.click();
	return path;
}


}

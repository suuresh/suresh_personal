package com.webservices.services;

import org.json.JSONObject;

//import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
//import com.jayway.restassured.specification.RequestSpecification;
import com.services.reload.requestpojo.ReloadCardPojo;



public class ReloadCardService extends URLBuilder
{
	Response response;

	public Response reloadCard(String clientTxnId,String urn,String last4Digits,String customerId,String transactionAmount)
	{
		ReloadCardPojo loadCardPojo =new ReloadCardPojo();
		loadCardPojo.setMessageCode("1080");
		loadCardPojo.setClientId("WIBMO");
		loadCardPojo.setClientTxnId(clientTxnId);
		loadCardPojo.setRequestDateTime("20161024102112");
		loadCardPojo.setBankId(6019);
		loadCardPojo.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		loadCardPojo.setEntityId(100);
		loadCardPojo.setLast4Digits(last4Digits);
		loadCardPojo.setUrn(urn);
		loadCardPojo.setCustomerId(customerId);
		loadCardPojo.setAgentComments("Test Comments");
		loadCardPojo.setTransactionAmount(transactionAmount);
		loadCardPojo.setSourceAccountType(00);
		loadCardPojo.setSourceAccount("1234");
		loadCardPojo.setOriginalClientTxnId("originalClientTxnId");
		loadCardPojo.setReserved1(" ");
		loadCardPojo.setReserved2(" ");
		loadCardPojo.setReserved3("0");
		loadCardPojo.setReserved4("PG Load");
		loadCardPojo.setReserved4("I|10003");
		
		JSONObject jSon=new JSONObject(loadCardPojo);
		System.out.println("Load Card Request string is "+jSon.toString());
			
		response=PostToURLUtility.postToURl(jSon, URLBuilder.reloadRequestURL);
		
		return response;
		
		
	}
}

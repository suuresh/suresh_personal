package com.webservices.services;

import org.json.JSONObject;

//import org.testng.Assert;



//import com.google.gson.Gson;
//import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
//import com.jayway.restassured.specification.RequestSpecification;
import com.services.createcard.requestpojo.CardHolder;
import com.services.createcard.requestpojo.CreateCardPojo;

public class CreateCardService extends URLBuilder
{

	public Response createCard(String cardholderFirstName,String cardholderLastName,String cardholderMobile,String cardholderDateOfBirth,
    String cardholderEmail,String cardholderAddress,String cardholderCity,String cardholderState,String cardholderZipCode
    ,String clientTxnId,String loadAmount,String customerId)
	{
		CreateCardPojo createcardpojo = new CreateCardPojo();
		CardHolder cardHolder =new CardHolder();
		
		/**
		 * card holder details
		 */
		cardHolder.setCardholderFirstName(cardholderFirstName);
		cardHolder.setCardholderLastName(cardholderLastName);
		cardHolder.setCardholderMobile(cardholderMobile);
		cardHolder.setCardholderDateOfBirth(cardholderDateOfBirth);
		cardHolder.setCardholderEmail(cardholderEmail);
		cardHolder.setCardholderAddress(cardholderAddress);
		cardHolder.setCardholderCity(cardholderCity);
		cardHolder.setCardholderState(cardholderState);
		cardHolder.setCardholderZipCode(cardholderZipCode);
		//cardHolder.setCardholderCountry(cardholderCountry);
		
		
		createcardpojo.setMessageCode("1010");
		createcardpojo.setClientId("WIBMO");
		createcardpojo.setClientTxnId(clientTxnId);
		createcardpojo.setBankId(6019);
		createcardpojo.setRequestDateTime("20171208121001");
		createcardpojo.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		createcardpojo.setEntityId(100);
		createcardpojo.setLoadAmount(loadAmount);
		createcardpojo.setProductId(6);
		createcardpojo.setCardHolder(cardHolder);
		createcardpojo.setCardProfileId(20);
		createcardpojo.setCustomerId(customerId);
		createcardpojo.setSourceAccountType(00);
		createcardpojo.setSourceAccount("1234");
		
		JSONObject jSon=new JSONObject(createcardpojo);
		System.out.println("Card Creation Request string is "+jSon.toString());
	/*	// **Gson gsonObj = new Gson();
		// **String data=gsonObj.toJson(createcardpojo);
		
		
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.header("Content-Type","application/json");
		httpRequest.body(jSon.toString());
		// Test to delete later
		
		/*Response response = RestAssured.given().contentType("application/json").body(jSon.toString())
				.when().post("https://aero-api-stg.pc.enstage-sas.com/v1/6019/createCard/0432/20150701235959xhstiesqfds").then().extract().response();*/
		
		//Response response = httpRequest.relaxedHTTPSValidation().post(URLBuilder.requestURL);
		//Response response = httpRequest.post("https://aero-api-stg.pc.enstage-sas.com/v1/6019/createCard/IN20014/2016d1724f");
		//System.out.println("Response String is "+response.asString());
		
		//int myStatus=response.getStatusCode();
		
		//Assert.assertEquals(myStatus, 00,"working as expected"); */
		
		Response response=PostToURLUtility.postToURl(jSon, URLBuilder.requestURL);
		
		return response;
	}
	
	/*public static void main(String[] args)
	{
		Service myservice =new Service();
		myservice.createCard("Velocity Check Non KYC","NewAPI","9900917736","25-12-1997","sanmati.vardhaman@wibmo.com","WINGS Cambridge Road Domlur1","Bangalore"
				,"Karnataka","560020","SunnyAct20161226-1790",300000,"IN92278");
	}*/
}

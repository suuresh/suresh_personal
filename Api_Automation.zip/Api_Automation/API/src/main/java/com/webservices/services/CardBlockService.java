package com.webservices.services;



import org.json.JSONObject;

import com.jayway.restassured.response.Response;
import com.services.cardBlock.requestpojo.CardBlockRequestPojo;
import com.utilities.CurrentDate;

public class CardBlockService
{

	public Response cardBlock(String clientTxnId,String last4Digits,String urn,String customerId,String blockType)
	{
		CardBlockRequestPojo blockrequest=new CardBlockRequestPojo ();
		
		blockrequest.setMessageCode("1240");
		blockrequest.setClientId("WIBMO");
		blockrequest.setClientTxnId(clientTxnId);
		blockrequest.setRequestDateTime(CurrentDate.getCurrentDate());
		blockrequest.setBankId(6019);
		blockrequest.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		blockrequest.setEntityId(100);
		blockrequest.setLast4Digits(last4Digits);
		blockrequest.setUrn(urn);
		blockrequest.setCustomerId(customerId);
		blockrequest.setBlockType(blockType);
		blockrequest.setReserved1("API Automation-Sanmati");
		blockrequest.setReserved2("Lost Card");
		
		//create json object
		
		JSONObject jSon=new JSONObject(blockrequest);
		System.out.println("Card Block Request is "+jSon.toString());
		
		Response response = PostToURLUtility.postToURl(jSon,URLBuilder.cardBlockRequestURL);
		
		return response;
		
		
	}
}

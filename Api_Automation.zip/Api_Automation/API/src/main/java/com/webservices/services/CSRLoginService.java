package com.webservices.services;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.csr.pomPage.CSRPage;

public class CSRLoginService
{

	
	public String loginIntoCSR(String CardNumber,String screenshotName)
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://aero-pplite-stghdfc.pc.enstage-sas.com/csr/index.jsp");
		driver.manage().window().maximize();
		
		CSRPage csr=PageFactory.initElements(driver, CSRPage.class);
		
		csr.loginIntoCSR("admin","password70");
		String path=csr.checkCardDetails(CardNumber,screenshotName);
		driver.quit();
		return path;
		
	}
}

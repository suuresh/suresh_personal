package com.webservices.services;



public class URLBuilder {

	public static  final String requestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/createCard/IN20014/2016d1724f";
	public static  final String reloadRequestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/creditAccount/IN21014/2016d1724f";
	public static  final String cardInquiryRequestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/cardInquiry/IN20014/2016d1724f";
	public static  final String cardUnloadRequestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/debitAccount/IN20014/2016d1724f";
	public static  final String cardBlockRequestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/blockCard/1356/20150701235959xhstiesqfds";
	public static  final String cardUnBlockRequestURL="https://aero-api-stg.pc.enstage-sas.com/v1/6019/unblockCard/1356/20150701235959xhstiesqfds";
	
}

package com.webservices.services;

import org.json.JSONObject;

import com.jayway.restassured.response.Response;
import com.services.cardinquiry.requestpojo.CardInquiryRequestPojo;

public class CardInquiryService extends URLBuilder

{
	Response response;
	
	public Response cardInquiry(String clientTxnId,String last4Digits,String urn,String customerId)
	{
		CardInquiryRequestPojo cardInquiryPojo=new CardInquiryRequestPojo();
		
		cardInquiryPojo.setMessageCode("1090");
		cardInquiryPojo.setClientId("WIBMO");
		cardInquiryPojo.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		cardInquiryPojo.setBankId(6019);
		cardInquiryPojo.setClientTxnId(clientTxnId);
		cardInquiryPojo.setLast4Digits(last4Digits);
		cardInquiryPojo.setUrn(urn);
		cardInquiryPojo.setCustomerId(customerId);
		cardInquiryPojo.setRequestDateTime("20171213051952");
		
		
		JSONObject jSon=new JSONObject(cardInquiryPojo);
		System.out.println("Card Inquiry Request is "+jSon.toString());
		
		Response response = PostToURLUtility.postToURl(jSon,URLBuilder.cardInquiryRequestURL);
		
		return response;
	}
}

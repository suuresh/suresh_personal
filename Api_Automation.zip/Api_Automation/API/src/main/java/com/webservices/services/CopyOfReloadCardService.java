package com.webservices.services;

import org.json.JSONObject;


//import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
//import com.jayway.restassured.specification.RequestSpecification;
import com.services.reload.requestpojo.copy.ReloadCardPojoCopy;



public class CopyOfReloadCardService extends URLBuilder
{
	Response response;

	public Response reloadCard(String messageCode,String ClientId,String clientTxnId,String BankId,String last4Digits,String urn,String customerId,String transactionAmount,
			String accountType)
	{
		ReloadCardPojoCopy loadCardPojo =new ReloadCardPojoCopy();
		
		loadCardPojo.setMessageCode(messageCode);
		loadCardPojo.setClientId(ClientId);
		loadCardPojo.setClientTxnId(clientTxnId);
		loadCardPojo.setRequestDateTime("20161024102112");
		loadCardPojo.setBankId(Integer.parseInt(BankId));
		loadCardPojo.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		loadCardPojo.setEntityId(100);
		loadCardPojo.setLast4Digits(last4Digits);
		loadCardPojo.setUrn(urn);
		loadCardPojo.setCustomerId(customerId);
		loadCardPojo.setAgentComments("Test Comments");
		loadCardPojo.setTransactionAmount(transactionAmount);
		loadCardPojo.setSourceAccountType(Integer.parseInt(accountType));
		loadCardPojo.setSourceAccount("1234");
		loadCardPojo.setOriginalClientTxnId("originalClientTxnId");
		loadCardPojo.setReserved1(" ");
		loadCardPojo.setReserved2(" ");
		loadCardPojo.setReserved3("0");
		loadCardPojo.setReserved4("PG Load");
		loadCardPojo.setReserved4("I|10003");
		
		JSONObject jSon=new JSONObject(loadCardPojo);
		System.out.println("Load Card Request string is "+jSon.toString());
			
		response=PostToURLUtility.postToURl(jSon, URLBuilder.reloadRequestURL);
		
		return response;
		
		
	}
}

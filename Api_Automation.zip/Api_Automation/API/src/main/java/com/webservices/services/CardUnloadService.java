package com.webservices.services;

import org.json.JSONObject;

import com.jayway.restassured.response.Response;
import com.services.cardUnload.requestpojo.UnloadCardRequestPojo;

public class CardUnloadService
{

	public Response cardUnload(String clientTxnId,String urn,String last4Digits,String customerId,String transactionAmount)
	{
		UnloadCardRequestPojo unloadCard=new UnloadCardRequestPojo();
		unloadCard.setMessageCode("1480");
		unloadCard.setClientId("WIBMO");
		unloadCard.setClientTxnId(clientTxnId);
		unloadCard.setRequestDateTime("20171215103948");
		unloadCard.setBankId(6019);
		unloadCard.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		unloadCard.setEntityId(100);
		unloadCard.setLast4Digits(last4Digits);
		unloadCard.setUrn(urn);
		unloadCard.setCustomerId(customerId);
		unloadCard.setAgentComments("Debit from customer");
		unloadCard.setOriginalClientTxnId("UnLoad_originalClientTxnId_weidAq4wT6uPvm0");
		unloadCard.setTransactionAmount(Integer.parseInt(transactionAmount));
		unloadCard.setSourceAccountType(0);
		unloadCard.setSourceAccount("1234");
		unloadCard.setPaymentMode("0");
		unloadCard.setReserved5("201607040918424092qE93qK4");
		unloadCard.setReserved4("PG Load");
		unloadCard.setReserved3("O|10009");
		unloadCard.setReserved2(" ");
		unloadCard.setReserved1(" ");
		
		//create Json Object
		
		JSONObject jSon=new JSONObject(unloadCard);
		System.out.println("Card unload request is "+jSon.toString());
		
		// call post to URL utility
		
		Response unloadResponse = PostToURLUtility.postToURl(jSon, URLBuilder.cardUnloadRequestURL);
		return unloadResponse;

		}
}

package com.webservices.services;


import org.json.JSONObject;

import com.jayway.restassured.response.Response;
import com.services.cardUnblock.requestpojo.CardUnblockRequestPojo;
import com.utilities.CurrentDate;

public class CardUnblockService
{
	
	public Response cardUnblock(String clientTxnId,String last4Digits,String urn,String customerId)
	{
		CardUnblockRequestPojo cardunblockrequestpojo= new CardUnblockRequestPojo();
			
		cardunblockrequestpojo.setMessageCode("1250");
		cardunblockrequestpojo.setClientId("WIBMO");
		cardunblockrequestpojo.setClientTxnId(clientTxnId);
		cardunblockrequestpojo.setBankId(6019);
		cardunblockrequestpojo.setRequestDateTime(CurrentDate.getCurrentDate());
		cardunblockrequestpojo.setSecureCode("AfYtlO5kqdySIjXyNmGg3F");
		cardunblockrequestpojo.setEntityId(100);
		cardunblockrequestpojo.setLast4Digits(last4Digits);
		cardunblockrequestpojo.setUrn(urn);
		cardunblockrequestpojo.setCustomerId(customerId);
		cardunblockrequestpojo.setReserved1("from restAssured api automation");
		cardunblockrequestpojo.setReserved2("Unblocked");
		
		JSONObject jSon=new JSONObject(cardunblockrequestpojo);
		System.out.println("-*************************Card Unblock**********************");
		System.out.println("Card Unblock request string is "+jSon.toString());
		
		Response unblockResponse = PostToURLUtility.postToURl(jSon, URLBuilder.cardUnBlockRequestURL);
		
		return unblockResponse;
		
	}

}

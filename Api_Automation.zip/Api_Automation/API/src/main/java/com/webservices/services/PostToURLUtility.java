package com.webservices.services;

//import org.json.JSONObject;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class PostToURLUtility 
{

	public static Response postToURl(Object jSon,String endPointURL)
	{
				
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.header("Content-Type","application/json");
		
		httpRequest.body(jSon.toString());
		
		Response response1 = httpRequest.relaxedHTTPSValidation().post(endPointURL);
		
		return response1;
	}
}

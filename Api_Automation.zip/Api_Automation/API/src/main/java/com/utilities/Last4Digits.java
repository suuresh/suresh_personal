package com.utilities;

public class Last4Digits
{
	/** This clas return last4digits of the card number from card number
	 * @return 
	 * 
	 */

	public static String getLast4Digits(String cardNumber)
	{
		
		String last4digits=cardNumber.substring(cardNumber.length()-4);
		//System.out.println(last4digits);
		return last4digits;
	}
	
	
}

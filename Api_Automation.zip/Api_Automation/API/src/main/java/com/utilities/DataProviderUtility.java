package com.utilities;

import org.testng.annotations.DataProvider;

public class DataProviderUtility 
{
	
	
	@DataProvider(name="ReloadProvider")
	public  static Object[][] getRealodDataProvider()
	{
		ExcelUtility excelUtility= new ExcelUtility();
		System.out.println("inside data provider");
		int rows=excelUtility.getLastRowNum("CardHolderDetails");
		int cols=excelUtility.getColumnCount("CardHolderDetails",1);
		
		System.out.println("number or rows: "+rows+" Number of col: "+cols);
		
		Object [][] obj=new Object[rows-1][cols];
		
		for (int i = 1; i <rows; i++)
		{
			for(int j=0;j<cols;j++)
			{
				obj[i-1][j]=excelUtility.getData("CardHolderDetails", i, j);
			}
		}
		//System.out.println(obj);
		return obj;
		
	}
	
	
	@DataProvider(name="ReloadReggression")
	public static Object[][] getDataforReloadReggression()
	{
		CopyOfExcelUtility  excelUtility= new CopyOfExcelUtility();
		int rows=excelUtility.getLastRowNum("ReloadRegression");
		int cols=excelUtility.getColumnCount("ReloadRegression",1);
		
		System.out.println("number or rows: "+rows+" Number of col: "+cols);
		
		Object [][] obj=new Object[rows-1][cols];
		
		for (int i = 1; i <rows; i++)
		{
			for(int j=0;j<cols;j++)
			{
				obj[i-1][j]=excelUtility.getData("ReloadRegression", i, j);
			}
		}
		return obj;
		
		
	}
	

}

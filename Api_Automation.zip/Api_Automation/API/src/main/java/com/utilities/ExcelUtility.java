package com.utilities;

/*
 *  This class is used to read the data from the excel
 */

//package dataProvider;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;

//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.IOException;

//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//import java.io.IOException;
//import java.util.HashMap;
import java.util.List;

//import org.apache.poi.EncryptedDocumentException;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.EncryptedDocumentException;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public  class ExcelUtility
{
	 Workbook wb;
	 Row rowValue;
	 Cell cellValue;
	 DataFormatter formatter;
	 Sheet sheet;
	 
	 
	 	
	public ExcelUtility()
	{
		File src = new File("./ApplicationData/ExcelData.xls");

		formatter = new DataFormatter();

		try
		{
			FileInputStream fis = new FileInputStream(src);

			wb = WorkbookFactory.create(fis);
		
			
		}

		catch (Exception e) {
			System.out.println("error message displayed is " + e.getMessage());

		}
		
		
	}

	// this will return number or rows in excel	

	public  int getLastRowNum(String sheetName)
	{
		try {
			FileInputStream fis=new FileInputStream("./ApplicationData/ExcelData.xls");
			Workbook wb=WorkbookFactory.create(fis);
			int rows= wb.getSheet(sheetName).getLastRowNum();
			return (rows+1);
			} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	// this class is used to write data into excel

	public void setData(String sheetName, int row, int col, String data)
	{
		try {
			//System.out.println("entering into set data method");
			FileInputStream fis=new FileInputStream("./ApplicationData/ExcelData.xls");
			Workbook wb=WorkbookFactory.create(fis);
			sheet = wb.getSheet(sheetName);
			rowValue = sheet.getRow(row);
			cellValue = rowValue.getCell(col);
			cellValue.setCellValue(data);

			//System.out.println("writing into file is completed");
			FileOutputStream fileOut = new FileOutputStream(
					"./ApplicationData/ExcelData.xls");
			wb.write(fileOut);
			fileOut.flush();
			fileOut.close();
		}

		catch (Exception e) {

		}

	}

	public  int getColumnCount(String sheetName, int row) {
		int cols = wb.getSheet(sheetName).getRow(row).getLastCellNum();
		return cols;
	}
	
	
		
	 public String getData(String sheetName, int row, int col)
	 {
		 String data="";
		try
		{
			FileInputStream fis = new FileInputStream("./ApplicationData/ExcelData.xls");
			wb = WorkbookFactory.create(fis);
			data = formatter.formatCellValue(wb.getSheet(sheetName)
					.getRow(row).getCell(col));
			return data;
		}
		
		catch(Exception e)
		{
			
		}
		return data;
	}
	
	 
	 /**
	  *  This method will write data in the excel sheet
	  */
	 
	 public void createRowandWriteData(String sheetName,int lastrowNum,int col,List<String> arrayli)
	 {
					
				try {
					FileInputStream fis = new FileInputStream("./ApplicationData/ExcelData.xls");
					wb = WorkbookFactory.create(fis);
					Sheet sName=wb.getSheet(sheetName);
					
						//int lastrowNum=sName.getLastRowNum();
						Row r=sName.createRow(lastrowNum);
						
						for (int i=0;i<col;i++)
						{
							Cell c=r.createCell(i, CellType.STRING);
							c.setCellValue(arrayli.get(i));
								
							//System.out.println("value in row:- "+lastrowNum+"and column:-"+col+" is "+hMap);
								
							
						}
						
						FileOutputStream fos=new FileOutputStream("./ApplicationData/ExcelData.xls");
						wb.write(fos);
						fos.flush();
						wb.close();
						
				}  catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				
			
	 }
	 
}


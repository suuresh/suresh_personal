package com.utilities;

import java.util.Calendar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest
{
	public WebDriver driver;
	public static ExtentReports reports;
	public ExtentTest logger;
	public WebDriverWait wait;
	public WebElement myElement;
	public static Calendar c = Calendar.getInstance();
	String reportName="API_SmokeTest";
	
	@BeforeSuite
	public void baseSetUp()
	{
		//System.out.println("next iteration");
		reports=new ExtentReports(System.getProperty("user.dir")+"\\Reports\\"+dateStamp()+"\\"+reportName+".html");
	}
	
	
	
	@AfterSuite
	public void tearDown()
	{
		//System.out.println("i m in suite");
		reports.endTest(logger);
		reports.flush();
	}
	
	/*
	 *  This method is used for application to sleep for specified time period using thread.sleep(3000).
	 */
	public void waitThread()
	{
		try {
			Thread.sleep(3000);
		} 
		catch (Exception e) {
			System.out.println("exception is "+e.getMessage());
		}
	}
	
	public WebElement explicitWait(WebElement element)
	{
		wait=new WebDriverWait(driver,3000);
		myElement= wait.until(ExpectedConditions.visibilityOf(element));
		return myElement;
	}
	
	/**
	 *  this is for dateStamp()
	 * @return
	 */
	public static String dateStamp()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE);
	}
	
	/*@AfterMethod
	public void tearDown(ITestResult result)
	{
		if(result.FAILURE==ITestResult.FAILURE)
		{
			logger.log(LogStatus.FAIL, "Load Card is failed");
		}
	}*/
	
	@AfterMethod
	public void tearDown(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			logger.log(LogStatus.FAIL, "Test case failed");
		}
	}
}

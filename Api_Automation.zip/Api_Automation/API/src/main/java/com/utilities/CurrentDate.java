package com.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CurrentDate
{

	public static String getCurrentDate()
	{
		SimpleDateFormat format=new SimpleDateFormat("YYYYMMddHHmmss");
		
		Date d=new Date();
		return(format.format(d));
	
		
	}
	
	/*public static void main(String[] args)
	{
		getCurrentDate();
	}*/
}

package com.services.reload.requestpojo.copy;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ReloadCardPojoCopy {

@SerializedName("messageCode")
@Expose
private String messageCode;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("requestDateTime")
@Expose
private String requestDateTime;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("secureCode")
@Expose
private String secureCode;
@SerializedName("entityId")
@Expose
private Integer entityId;
@SerializedName("last4Digits")
@Expose
private String last4Digits;
@SerializedName("urn")
@Expose
private String urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("agentComments")
@Expose
private String agentComments;
@SerializedName("transactionAmount")
@Expose
private String transactionAmount;
@SerializedName("sourceAccountType")
@Expose
private Integer sourceAccountType;
@SerializedName("sourceAccount")
@Expose
private String sourceAccount;
@SerializedName("originalClientTxnId")
@Expose
private String originalClientTxnId;
@SerializedName("reserved1")
@Expose
private String reserved1;
@SerializedName("reserved2")
@Expose
private String reserved2;
@SerializedName("reserved3")
@Expose
private String reserved3;
@SerializedName("reserved4")
@Expose
private String reserved4;
@SerializedName("reserved5")
@Expose
private String reserved5;

public String getMessageCode() {
return messageCode;
}

public void setMessageCode(String messageCode) {
this.messageCode = messageCode;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getRequestDateTime() {
return requestDateTime;
}

public void setRequestDateTime(String requestDateTime) {
this.requestDateTime = requestDateTime;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getSecureCode() {
return secureCode;
}

public void setSecureCode(String secureCode) {
this.secureCode = secureCode;
}

public Integer getEntityId() {
return entityId;
}

public void setEntityId(Integer entityId) {
this.entityId = entityId;
}

public String getLast4Digits() {
return last4Digits;
}

public void setLast4Digits(String last4Digits) {
this.last4Digits = last4Digits;
}

public String getUrn() {
return urn;
}

public void setUrn(String urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getAgentComments() {
return agentComments;
}

public void setAgentComments(String agentComments) {
this.agentComments = agentComments;
}

public String getTransactionAmount() {
return transactionAmount;
}

public void setTransactionAmount(String transactionAmount) {
this.transactionAmount = transactionAmount;
}

public Integer getSourceAccountType() {
return sourceAccountType;
}

public void setSourceAccountType(Integer sourceAccountType) {
this.sourceAccountType = sourceAccountType;
}

public String getSourceAccount() {
return sourceAccount;
}

public void setSourceAccount(String sourceAccount) {
this.sourceAccount = sourceAccount;
}

public String getOriginalClientTxnId() {
return originalClientTxnId;
}

public void setOriginalClientTxnId(String originalClientTxnId) {
this.originalClientTxnId = originalClientTxnId;
}

public String getReserved1() {
return reserved1;
}

public void setReserved1(String reserved1) {
this.reserved1 = reserved1;
}

public String getReserved2() {
return reserved2;
}

public void setReserved2(String reserved2) {
this.reserved2 = reserved2;
}

public String getReserved3() {
return reserved3;
}

public void setReserved3(String reserved3) {
this.reserved3 = reserved3;
}

public String getReserved4() {
return reserved4;
}

public void setReserved4(String reserved4) {
this.reserved4 = reserved4;
}

public String getReserved5() {
return reserved5;
}

public void setReserved5(String reserved5) {
this.reserved5 = reserved5;
}

}

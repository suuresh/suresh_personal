package com.services.createcard.responsepojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CreateCardResponse {

@SerializedName("urn")
@Expose
private String urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("description")
@Expose
private String description;
@SerializedName("responseCode")
@Expose
private String responseCode;
@SerializedName("messageCode")
@Expose
private Integer messageCode;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("responseDateTime")
@Expose
private String responseDateTime;
@SerializedName("accosaTransactionId")
@Expose
private Integer accosaTransactionId;
@SerializedName("responseMessage")
@Expose
private String responseMessage;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("accosaRefNo")
@Expose
private String accosaRefNo;
@SerializedName("cardNumber")
@Expose
private String cardNumber;
@SerializedName("cardExpiry")
@Expose
private String cardExpiry;
@SerializedName("cardCVV2")
@Expose
private String cardCVV2;
@SerializedName("cardProfileId")
@Expose
private Integer cardProfileId;
@SerializedName("loadAmount")
@Expose
private Integer loadAmount;
@SerializedName("availableBalance")
@Expose
private Integer availableBalance;
@SerializedName("availableCashLimit")
@Expose
private Integer availableCashLimit;

public String getUrn() {
return urn;
}

public void setUrn(String urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getResponseCode() {
return responseCode;
}

public void setResponseCode(String responseCode) {
this.responseCode = responseCode;
}

public Integer getMessageCode() {
return messageCode;
}

public void setMessageCode(Integer messageCode) {
this.messageCode = messageCode;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getResponseDateTime() {
return responseDateTime;
}

public void setResponseDateTime(String responseDateTime) {
this.responseDateTime = responseDateTime;
}

public Integer getAccosaTransactionId() {
return accosaTransactionId;
}

public void setAccosaTransactionId(Integer accosaTransactionId) {
this.accosaTransactionId = accosaTransactionId;
}

public String getResponseMessage() {
return responseMessage;
}

public void setResponseMessage(String responseMessage) {
this.responseMessage = responseMessage;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getAccosaRefNo() {
return accosaRefNo;
}

public void setAccosaRefNo(String accosaRefNo) {
this.accosaRefNo = accosaRefNo;
}

public String getCardNumber() {
return cardNumber;
}

public void setCardNumber(String cardNumber) {
this.cardNumber = cardNumber;
}

public String getCardExpiry() {
return cardExpiry;
}

public void setCardExpiry(String cardExpiry) {
this.cardExpiry = cardExpiry;
}

public String getCardCVV2() {
return cardCVV2;
}

public void setCardCVV2(String cardCVV2) {
this.cardCVV2 = cardCVV2;
}

public Integer getCardProfileId() {
return cardProfileId;
}

public void setCardProfileId(Integer cardProfileId) {
this.cardProfileId = cardProfileId;
}

public Integer getLoadAmount() {
return loadAmount;
}

public void setLoadAmount(Integer loadAmount) {
this.loadAmount = loadAmount;
}

public Integer getAvailableBalance() {
return availableBalance;
}

public void setAvailableBalance(Integer availableBalance) {
this.availableBalance = availableBalance;
}

public Integer getAvailableCashLimit() {
return availableCashLimit;
}

public void setAvailableCashLimit(Integer availableCashLimit) {
this.availableCashLimit = availableCashLimit;
}

}

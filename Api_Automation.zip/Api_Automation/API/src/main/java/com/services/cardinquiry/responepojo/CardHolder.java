package com.services.cardinquiry.responepojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CardHolder {

@SerializedName("cardProfileId")
@Expose
private Integer cardProfileId;
@SerializedName("cardholderFirstName")
@Expose
private String cardholderFirstName;
@SerializedName("cardholderLastName")
@Expose
private String cardholderLastName;
@SerializedName("cardholderMobile")
@Expose
private String cardholderMobile;
@SerializedName("cardholderEmail")
@Expose
private String cardholderEmail;
@SerializedName("cardholderAddress")
@Expose
private String cardholderAddress;
@SerializedName("cardholderCity")
@Expose
private String cardholderCity;
@SerializedName("cardholderState")
@Expose
private String cardholderState;
@SerializedName("cardholderZipCode")
@Expose
private String cardholderZipCode;
@SerializedName("cardholderDateOfBirth")
@Expose
private String cardholderDateOfBirth;

public Integer getCardProfileId() {
return cardProfileId;
}

public void setCardProfileId(Integer cardProfileId) {
this.cardProfileId = cardProfileId;
}

public String getCardholderFirstName() {
return cardholderFirstName;
}

public void setCardholderFirstName(String cardholderFirstName) {
this.cardholderFirstName = cardholderFirstName;
}

public String getCardholderLastName() {
return cardholderLastName;
}

public void setCardholderLastName(String cardholderLastName) {
this.cardholderLastName = cardholderLastName;
}

public String getCardholderMobile() {
return cardholderMobile;
}

public void setCardholderMobile(String cardholderMobile) {
this.cardholderMobile = cardholderMobile;
}

public String getCardholderEmail() {
return cardholderEmail;
}

public void setCardholderEmail(String cardholderEmail) {
this.cardholderEmail = cardholderEmail;
}

public String getCardholderAddress() {
return cardholderAddress;
}

public void setCardholderAddress(String cardholderAddress) {
this.cardholderAddress = cardholderAddress;
}

public String getCardholderCity() {
return cardholderCity;
}

public void setCardholderCity(String cardholderCity) {
this.cardholderCity = cardholderCity;
}

public String getCardholderState() {
return cardholderState;
}

public void setCardholderState(String cardholderState) {
this.cardholderState = cardholderState;
}

public String getCardholderZipCode() {
return cardholderZipCode;
}

public void setCardholderZipCode(String cardholderZipCode) {
this.cardholderZipCode = cardholderZipCode;
}

public String getCardholderDateOfBirth() {
return cardholderDateOfBirth;
}

public void setCardholderDateOfBirth(String cardholderDateOfBirth) {
this.cardholderDateOfBirth = cardholderDateOfBirth;
}

}
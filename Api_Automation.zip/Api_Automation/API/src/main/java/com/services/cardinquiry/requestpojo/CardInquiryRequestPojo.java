package com.services.cardinquiry.requestpojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CardInquiryRequestPojo {

@SerializedName("messageCode")
@Expose
private String messageCode;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("secureCode")
@Expose
private String secureCode;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("last4Digits")
@Expose
private String last4Digits;
@SerializedName("urn")
@Expose
private String urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("requestDateTime")
@Expose
private String requestDateTime;

public String getMessageCode() {
return messageCode;
}

public void setMessageCode(String messageCode) {
this.messageCode = messageCode;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getSecureCode() {
return secureCode;
}

public void setSecureCode(String secureCode) {
this.secureCode = secureCode;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getLast4Digits() {
return last4Digits;
}

public void setLast4Digits(String last4Digits) {
this.last4Digits = last4Digits;
}

public String getUrn() {
return urn;
}

public void setUrn(String urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getRequestDateTime() {
return requestDateTime;
}

public void setRequestDateTime(String requestDateTime) {
this.requestDateTime = requestDateTime;
}

}

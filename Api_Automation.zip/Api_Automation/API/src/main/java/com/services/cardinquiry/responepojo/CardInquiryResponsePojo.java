package com.services.cardinquiry.responepojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CardInquiryResponsePojo {

@SerializedName("urn")
@Expose
private Integer urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("description")
@Expose
private String description;
@SerializedName("responseCode")
@Expose
private String responseCode;
@SerializedName("messageCode")
@Expose
private Integer messageCode;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("responseDateTime")
@Expose
private String responseDateTime;
@SerializedName("accosaTransactionId")
@Expose
private Integer accosaTransactionId;
@SerializedName("responseMessage")
@Expose
private String responseMessage;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("availableBalance")
@Expose
private String availableBalance;
@SerializedName("availableCashLimit")
@Expose
private String availableCashLimit;
@SerializedName("cardNumber")
@Expose
private String cardNumber;
@SerializedName("cardExpiry")
@Expose
private String cardExpiry;
@SerializedName("cardCVV2")
@Expose
private String cardCVV2;
@SerializedName("cardStatus")
@Expose
private String cardStatus;
@SerializedName("activationTimeStamp")
@Expose
private String activationTimeStamp;
@SerializedName("lastActivityTimeStamp")
@Expose
private String lastActivityTimeStamp;
@SerializedName("cardHolder")
@Expose
private CardHolder cardHolder;

public Integer getUrn() {
return urn;
}

public void setUrn(Integer urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getResponseCode() {
return responseCode;
}

public void setResponseCode(String responseCode) {
this.responseCode = responseCode;
}

public Integer getMessageCode() {
return messageCode;
}

public void setMessageCode(Integer messageCode) {
this.messageCode = messageCode;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getResponseDateTime() {
return responseDateTime;
}

public void setResponseDateTime(String responseDateTime) {
this.responseDateTime = responseDateTime;
}

public Integer getAccosaTransactionId() {
return accosaTransactionId;
}

public void setAccosaTransactionId(Integer accosaTransactionId) {
this.accosaTransactionId = accosaTransactionId;
}

public String getResponseMessage() {
return responseMessage;
}

public void setResponseMessage(String responseMessage) {
this.responseMessage = responseMessage;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getAvailableBalance() {
return availableBalance;
}

public void setAvailableBalance(String availableBalance) {
this.availableBalance = availableBalance;
}

public String getAvailableCashLimit() {
return availableCashLimit;
}

public void setAvailableCashLimit(String availableCashLimit) {
this.availableCashLimit = availableCashLimit;
}

public String getCardNumber() {
return cardNumber;
}

public void setCardNumber(String cardNumber) {
this.cardNumber = cardNumber;
}

public String getCardExpiry() {
return cardExpiry;
}

public void setCardExpiry(String cardExpiry) {
this.cardExpiry = cardExpiry;
}

public String getCardCVV2() {
return cardCVV2;
}

public void setCardCVV2(String cardCVV2) {
this.cardCVV2 = cardCVV2;
}

public String getCardStatus() {
return cardStatus;
}

public void setCardStatus(String cardStatus) {
this.cardStatus = cardStatus;
}

public String getActivationTimeStamp() {
return activationTimeStamp;
}

public void setActivationTimeStamp(String activationTimeStamp) {
this.activationTimeStamp = activationTimeStamp;
}

public String getLastActivityTimeStamp() {
return lastActivityTimeStamp;
}

public void setLastActivityTimeStamp(String lastActivityTimeStamp) {
this.lastActivityTimeStamp = lastActivityTimeStamp;
}

public CardHolder getCardHolder() {
return cardHolder;
}

public void setCardHolder(CardHolder cardHolder) {
this.cardHolder = cardHolder;
}

}

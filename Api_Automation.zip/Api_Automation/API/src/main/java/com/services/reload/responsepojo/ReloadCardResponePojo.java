package com.services.reload.responsepojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ReloadCardResponePojo {

@SerializedName("urn")
@Expose
private Integer urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("description")
@Expose
private String description;
@SerializedName("responseCode")
@Expose
private String responseCode;
@SerializedName("messageCode")
@Expose
private Integer messageCode;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("responseDateTime")
@Expose
private String responseDateTime;
@SerializedName("accosaTransactionId")
@Expose
private Integer accosaTransactionId;
@SerializedName("responseMessage")
@Expose
private String responseMessage;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("accosaRefNo")
@Expose
private String accosaRefNo;
@SerializedName("availableBalance")
@Expose
private Integer availableBalance;
@SerializedName("availableCashLimit")
@Expose
private Integer availableCashLimit;
@SerializedName("transactionAmount")
@Expose
private Integer transactionAmount;

public Integer getUrn() {
return urn;
}

public void setUrn(Integer urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getResponseCode() {
return responseCode;
}

public void setResponseCode(String responseCode) {
this.responseCode = responseCode;
}

public Integer getMessageCode() {
return messageCode;
}

public void setMessageCode(Integer messageCode) {
this.messageCode = messageCode;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getResponseDateTime() {
return responseDateTime;
}

public void setResponseDateTime(String responseDateTime) {
this.responseDateTime = responseDateTime;
}

public Integer getAccosaTransactionId() {
return accosaTransactionId;
}

public void setAccosaTransactionId(Integer accosaTransactionId) {
this.accosaTransactionId = accosaTransactionId;
}

public String getResponseMessage() {
return responseMessage;
}

public void setResponseMessage(String responseMessage) {
this.responseMessage = responseMessage;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getAccosaRefNo() {
return accosaRefNo;
}

public void setAccosaRefNo(String accosaRefNo) {
this.accosaRefNo = accosaRefNo;
}

public Integer getAvailableBalance() {
return availableBalance;
}

public void setAvailableBalance(Integer availableBalance) {
this.availableBalance = availableBalance;
}

public Integer getAvailableCashLimit() {
return availableCashLimit;
}

public void setAvailableCashLimit(Integer availableCashLimit) {
this.availableCashLimit = availableCashLimit;
}

public Integer getTransactionAmount() {
return transactionAmount;
}

public void setTransactionAmount(Integer transactionAmount) {
this.transactionAmount = transactionAmount;
}

}

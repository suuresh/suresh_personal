package com.services.createcard.requestpojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

//import com.google.gson.annotations.Expose;
//import com.google.gson.annotations.SerializedName;

public class CreateCardPojo {

@SerializedName("messageCode")
@Expose
private String messageCode;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("requestDateTime")
@Expose
private String requestDateTime;
@SerializedName("secureCode")
@Expose
private String secureCode;
@SerializedName("entityId")
@Expose
private Integer entityId;
@SerializedName("loadAmount")
@Expose
private String loadAmount;
@SerializedName("productId")
@Expose
private Integer productId;
@SerializedName("cardHolder")
@Expose
private CardHolder cardHolder;
@SerializedName("cardProfileId")
@Expose
private Integer cardProfileId;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("sourceAccountType")
@Expose
private Integer sourceAccountType;
@SerializedName("sourceAccount")
@Expose
private String sourceAccount;

public String getMessageCode() {
return messageCode;
}

public void setMessageCode(String messageCode) {
this.messageCode = messageCode;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public String getRequestDateTime() {
return requestDateTime;
}

public void setRequestDateTime(String requestDateTime) {
this.requestDateTime = requestDateTime;
}

public String getSecureCode() {
return secureCode;
}

public void setSecureCode(String secureCode) {
this.secureCode = secureCode;
}

public Integer getEntityId() {
return entityId;
}

public void setEntityId(Integer entityId) {
this.entityId = entityId;
}

public String getLoadAmount() {
return loadAmount;
}

public void setLoadAmount(String loadAmount) {
this.loadAmount = loadAmount;
}

public Integer getProductId() {
return productId;
}

public void setProductId(Integer productId) {
this.productId = productId;
}

public CardHolder getCardHolder() {
return cardHolder;
}

public void setCardHolder(CardHolder cardHolder) {
this.cardHolder = cardHolder;
}

public Integer getCardProfileId() {
return cardProfileId;
}

public void setCardProfileId(Integer cardProfileId) {
this.cardProfileId = cardProfileId;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public Integer getSourceAccountType() {
return sourceAccountType;
}

public void setSourceAccountType(Integer sourceAccountType) {
this.sourceAccountType = sourceAccountType;
}

public String getSourceAccount() {
return sourceAccount;
}

public void setSourceAccount(String sourceAccount) {
this.sourceAccount = sourceAccount;
}
}
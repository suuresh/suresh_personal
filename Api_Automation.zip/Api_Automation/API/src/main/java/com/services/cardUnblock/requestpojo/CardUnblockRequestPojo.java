package com.services.cardUnblock.requestpojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CardUnblockRequestPojo {

@SerializedName("messageCode")
@Expose
private String messageCode;
@SerializedName("clientId")
@Expose
private String clientId;
@SerializedName("clientTxnId")
@Expose
private String clientTxnId;
@SerializedName("bankId")
@Expose
private Integer bankId;
@SerializedName("requestDateTime")
@Expose
private String requestDateTime;
@SerializedName("secureCode")
@Expose
private String secureCode;
@SerializedName("entityId")
@Expose
private Integer entityId;
@SerializedName("last4Digits")
@Expose
private String last4Digits;
@SerializedName("urn")
@Expose
private String urn;
@SerializedName("customerId")
@Expose
private String customerId;
@SerializedName("reserved1")
@Expose
private String reserved1;
@SerializedName("reserved2")
@Expose
private String reserved2;

public String getMessageCode() {
return messageCode;
}

public void setMessageCode(String messageCode) {
this.messageCode = messageCode;
}

public String getClientId() {
return clientId;
}

public void setClientId(String clientId) {
this.clientId = clientId;
}

public String getClientTxnId() {
return clientTxnId;
}

public void setClientTxnId(String clientTxnId) {
this.clientTxnId = clientTxnId;
}

public Integer getBankId() {
return bankId;
}

public void setBankId(Integer bankId) {
this.bankId = bankId;
}

public String getRequestDateTime() {
return requestDateTime;
}

public void setRequestDateTime(String requestDateTime) {
this.requestDateTime = requestDateTime;
}

public String getSecureCode() {
return secureCode;
}

public void setSecureCode(String secureCode) {
this.secureCode = secureCode;
}

public Integer getEntityId() {
return entityId;
}

public void setEntityId(Integer entityId) {
this.entityId = entityId;
}

public String getLast4Digits() {
return last4Digits;
}

public void setLast4Digits(String last4Digits) {
this.last4Digits = last4Digits;
}

public String getUrn() {
return urn;
}

public void setUrn(String urn) {
this.urn = urn;
}

public String getCustomerId() {
return customerId;
}

public void setCustomerId(String customerId) {
this.customerId = customerId;
}

public String getReserved1() {
return reserved1;
}

public void setReserved1(String reserved1) {
this.reserved1 = reserved1;
}

public String getReserved2() {
return reserved2;
}

public void setReserved2(String reserved2) {
this.reserved2 = reserved2;
}

}
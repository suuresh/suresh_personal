package apiAutomation.API;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.services.cardBlock.responsepojo.CardBlockResponsePojo;
import com.utilities.BaseTest;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CSRLoginService;
import com.webservices.services.CardBlockService;

public class CardBlockTest extends BaseTest
{
	CardBlockService blockservice=new CardBlockService();
	String clientTxnId=UUID.randomUUID().toString();
	ExcelUtility excelUtility=new ExcelUtility();
	String last4Digits;
	CSRLoginService csr=new CSRLoginService();
	
	@Parameters("blockType")
	@Test
	public void cardBlock_tc(String blockType)
	{
		int lastrowNum=excelUtility.getLastRowNum("CardDetails");
		logger=BaseTest.reports.startTest("TC_005_Card_Block");
		logger.log(LogStatus.INFO, "Card Block Test Case Started");
		
		if(excelUtility.getData("CardDetails", lastrowNum-1, 7).equals("00"))
		{
			String urn=excelUtility.getData("CardDetails", lastrowNum-1, 0);
			String customerId=excelUtility.getData("CardDetails", lastrowNum-1, 4);
			String cardnumber=excelUtility.getData("CardDetails", lastrowNum-1, 1);
			last4Digits=Last4Digits.getLast4Digits(cardnumber);
			System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Card details sheet,as previous card creation was successful");
			
			Response block_Response = blockservice.cardBlock(clientTxnId, last4Digits, urn, customerId, blockType);
			logger.log(LogStatus.INFO,"Calling Block Card API");
			
			System.out.println("Card Block Response string is "+block_Response.asString());
			logger.log(LogStatus.INFO, "Block Card Response is received");
			
			Gson gson =new Gson();
			CardBlockResponsePojo cardBlockresponPojo = gson.fromJson(block_Response.asString(), CardBlockResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of Block Card Response pojo class");
			
			String responsecode=cardBlockresponPojo.getResponseCode();
			
			Assert.assertEquals(responsecode,"00");
			logger.log(LogStatus.PASS, "Card Blocking is successfull and Verified");
			
			String path=csr.loginIntoCSR(cardnumber,"TC_004_CardBlock");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
			System.out.println("Card Blocking is successfull");
						
		}
		
		else
		{
			String urn=excelUtility.getData("DefaultCardDetails",1, 0);
			String customerId=excelUtility.getData("DefaultCardDetails",1, 4);
			String cardnumber=excelUtility.getData("DefaultCardDetails",1, 1);
			last4Digits=Last4Digits.getLast4Digits(cardnumber);
			System.out.println("**********Previous Card Creation was Successful,hence taking data from DefaultCardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Defaultcard details sheet,as previous card creation was not successful");
			
			Response block_Response = blockservice.cardBlock(clientTxnId, last4Digits, urn, customerId, blockType);
			logger.log(LogStatus.INFO,"Calling Block Card API");
			
			System.out.println("Card Block Response string is "+block_Response.asString());
			logger.log(LogStatus.INFO, "Block Card Response is received");
			
			Gson gson =new Gson();
			CardBlockResponsePojo cardBlockresponPojo = gson.fromJson(block_Response.asString(), CardBlockResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of Block Card Response pojo class");
			String responsecode=cardBlockresponPojo.getResponseCode();
			
			Assert.assertEquals(responsecode,"00");
			logger.log(LogStatus.PASS, "Card Blocking is successfull and Verified");
			
			String path=csr.loginIntoCSR(cardnumber,"TC_004_CardBlock_default_Card_details");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
			System.out.println("Card Blocking is successful");
		}
		
	}
}

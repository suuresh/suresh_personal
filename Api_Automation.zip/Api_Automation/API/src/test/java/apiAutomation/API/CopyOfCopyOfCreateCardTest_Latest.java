package apiAutomation.API;

import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
import com.services.createcard.responsepojo.CreateCardResponse;
import com.utilities.DataProviderUtility;
import com.utilities.ExcelUtility;
import com.webservices.services.CreateCardService;

public class CopyOfCopyOfCreateCardTest_Latest 
{
	CreateCardService service =new CreateCardService();
	Response createCardResponse;
	ExcelUtility excel;

	@Test(dataProvider="ReloadProvider",dataProviderClass=DataProviderUtility.class)
	public void createCard_TC(String cardholderFirstName,String cardholderLastName,String cardholderMobile,String cardholderDateOfBirth,String cardholderEmail,String
			cardholderAddress,String cardholderCity,String cardholderState,String cardholderZipCode,String loadAmount)
	{
		String clienTxnid=UUID.randomUUID().toString();
		String customerID=UUID.randomUUID().toString();
		createCardResponse = service.createCard(cardholderFirstName,cardholderLastName,cardholderMobile,cardholderDateOfBirth,cardholderEmail,cardholderAddress,cardholderCity
				,cardholderState,cardholderZipCode,clienTxnid,loadAmount,customerID);
		
		System.out.println("Card Creation Response String is "+createCardResponse.asString());
		
		Gson gson=new Gson();
		
		CreateCardResponse createCard = gson.fromJson(createCardResponse.asString(), CreateCardResponse.class);
		
		String resultResponse = createCard.getResponseCode();
		
			
		/**
		 *  call excel method to put the data into the sheet
		 */
		
		excel=new ExcelUtility();
		//int newRow=excel.creatNeRow("CardDetails",1);
		/*excel.setData("CardDetails",1, 0,createCard.getUrn());
		excel.setData("CardDetails", 1, 1,createCard.getCardNumber());
		excel.setData("CardDetails", 1, 2,createCard.getCardCVV2());
		excel.setData("CardDetails", 1, 3,createCard.getCardExpiry());
		excel.setData("CardDetails", 1, 4,createCard.getCustomerId());
		excel.setData("CardDetails", 1, 5, String.valueOf(createCard.getLoadAmount()));
		excel.setData("CardDetails", 1, 6, createCard.getClientTxnId());
		excel.setData("CardDetails", 1, 7, createCard.getResponseCode());*/
		
		
		/*excel.createRowandWriteData("CardDetails",rowNumber,0, createCard.getUrn());
		excel.createRowandWriteData("CardDetails",rowNumber,1,createCard.getCardNumber());
		excel.createRowandWriteData("CardDetails",rowNumber,2,createCard.getCardCVV2());
		excel.createRowandWriteData("CardDetails",rowNumber,3,createCard.getCardExpiry());
		excel.createRowandWriteData("CardDetails",rowNumber,4,createCard.getCustomerId());
		excel.createRowandWriteData("CardDetails",rowNumber,5,String.valueOf(createCard.getLoadAmount()));
		excel.createRowandWriteData("CardDetails",rowNumber,6,createCard.getClientTxnId());
		excel.createRowandWriteData("CardDetails",rowNumber,7,createCard.getResponseCode()); */
		
		List<String> arrayli=new ArrayList<String> ();
		arrayli.add(createCard.getUrn());
		arrayli.add(createCard.getCardNumber());
		arrayli.add(createCard.getCardCVV2());
		arrayli.add(createCard.getCardExpiry());
		arrayli.add(createCard.getCustomerId());
		arrayli.add(String.valueOf(createCard.getLoadAmount()));
		arrayli.add(createCard.getClientTxnId());
		arrayli.add(createCard.getResponseCode());
		
		int rowNumber=excel.getLastRowNum("Carddetails");
		int col=arrayli.size();
		
		excel.createRowandWriteData("CardDetails", rowNumber, col, arrayli);
		
		System.out.println("writing into excel is successful");
		
		Assert.assertEquals(resultResponse, "00");
		System.out.println("Card creation successfully verified");
		
	}
	
	
}

package apiAutomation.API;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;











import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.services.cardUnload.responsepojo.UnLoadResponePojo;
import com.utilities.BaseTest;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CSRLoginService;
import com.webservices.services.CardUnloadService;

public class UnloadCardTest extends BaseTest
{
	ExcelUtility excelUtility= new ExcelUtility();
	CSRLoginService csr=new CSRLoginService();
	
	
	@Test
	public void unlaodCard_TC()
	{
			
		CardUnloadService unloadService =new CardUnloadService();
		int lastrowNum=excelUtility.getLastRowNum("CardDetails");
		
		logger=BaseTest.reports.startTest("TC_004_UnLoadCard");
		logger.log(LogStatus.INFO, "UnLoad Card API Test Case Started");
			
		if (excelUtility.getData("CardDetails", lastrowNum-1, 7).equals("00")  )
		{
			
			System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Card details sheet,as previous card creation was successful");
			String clientTxnId=UUID.randomUUID().toString();
			System.out.println(clientTxnId);
			String urn=excelUtility.getData("CardDetails", lastrowNum-1, 0);
			String last4Digits=Last4Digits.getLast4Digits(excelUtility.getData("CardDetails", lastrowNum-1, 1));
			String customerID=excelUtility.getData("CardDetails", lastrowNum-1, 4);
			String uloadAmount=excelUtility.getData("CardDetails", lastrowNum-1, 5);
			
			Response unresponse = unloadService.cardUnload(clientTxnId, urn, last4Digits, customerID, uloadAmount);
			 logger.log(LogStatus.INFO,"Calling UnLoad Card API");
			
			System.out.println("Card unload response is "+unresponse.asString());
			logger.log(LogStatus.INFO, "UnLoad Card Response is received");
			
			Gson gson=new Gson();
			UnLoadResponePojo unloadCard = gson.fromJson(unresponse.asString(), UnLoadResponePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of Unload Card Response pojo class");
			
			String responseMessage = unloadCard.getResponseCode();
			Assert.assertEquals(responseMessage, "00");
			logger.log(LogStatus.PASS, "UnLoad Card is successfull and Verified");
			
			String CardNumber=excelUtility.getData("CardDetails", lastrowNum-1, 1);
			String path=csr.loginIntoCSR(CardNumber,"TC_003_UnlaodCard");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
			
		}
		
		else
		{
			System.out.println("**********Previous Card Creation was not Successful,hence taking data from DefaultCardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Default Card details sheet,as previous card creation was not successful");
			
			String clientTxnId=UUID.randomUUID().toString();
			System.out.println(clientTxnId);
			String urn=excelUtility.getData("DefaultCardDetails",1, 0);
			String last4Digits=Last4Digits.getLast4Digits(excelUtility.getData("DefaultCardDetails",1,1));
			String customerID=excelUtility.getData("DefaultCardDetails",1, 4);
			String uloadAmount=excelUtility.getData("DefaultCardDetails",1, 5);
			Response unresponse = unloadService.cardUnload(clientTxnId, urn, last4Digits, customerID, uloadAmount);
			logger.log(LogStatus.INFO,"Calling Load Card API");
			
			System.out.println("Card unload response is "+unresponse.asString());
			logger.log(LogStatus.INFO, "Load Card Response is received");
			
			Gson gson=new Gson();
			UnLoadResponePojo unloadCard = gson.fromJson(unresponse.asString(), UnLoadResponePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of Reload Card Response pojo class");
			
			String responseMessage = unloadCard.getResponseCode();
			Assert.assertEquals(responseMessage, "00");
			logger.log(LogStatus.PASS, "Load Card is successfull and Verified");
			
			String CardNumber=excelUtility.getData("DefaultCardDetails",1,1);
			String path=csr.loginIntoCSR(CardNumber,"TC_003_UnlaodCard_Default_Card_Details");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
		}
		
	}
}

package apiAutomation.API;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
//import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.services.reload.responsepojo.ReloadCardResponePojo;
import com.utilities.BaseTest;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CSRLoginService;
import com.webservices.services.ReloadCardService;


public class LoadCardTest extends BaseTest
{
	ReloadCardService service1=new ReloadCardService() ;
	Response reloadResponse ;
	ReloadCardResponePojo reloadCard;
	//ExcelUtility excel=new ExcelUtility();
	ExcelUtility excelUtility= new ExcelUtility();
	CSRLoginService csr=new CSRLoginService();
	
	
	
	@Test()
	public void loadCard_TC()
	{
		
		//System.out.println("inside load card test case"+BaseTest.reports);
		
		logger=BaseTest.reports.startTest("TC_002_LoadCard");
		logger.log(LogStatus.INFO, "Load Card API Test Case Started");
		int lastrowNum=excelUtility.getLastRowNum("CardDetails");
		System.out.println(lastrowNum);
		System.out.println((excelUtility.getData("CardDetails", lastrowNum-1, 0)));
		
		if (excelUtility.getData("CardDetails", lastrowNum-1, 7).equals("00"))
		{
				
		
			System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Card details sheet,as previous card creation was successful");
				//String clientTxnId=excel.getData("CardDetails", 1, 6);
				String clientTxnId=UUID.randomUUID().toString();
				System.out.println(clientTxnId);
				String urn=excelUtility.getData("CardDetails", lastrowNum-1, 0);
				//String cardNumber=excel.getData("CardDetails", 1, 0);
				String last4Digits=Last4Digits.getLast4Digits(excelUtility.getData("CardDetails", lastrowNum-1, 1));
				String customerID=excelUtility.getData("CardDetails", lastrowNum-1, 4);
				String loadAmount=excelUtility.getData("CardDetails", lastrowNum-1, 5);
				
				
				 reloadResponse=service1.reloadCard(clientTxnId,urn,last4Digits,customerID,loadAmount);
				 logger.log(LogStatus.INFO,"Calling Load Card API");
				 
				 System.out.println("Load Card Response String is "+reloadResponse.asString());
				 logger.log(LogStatus.INFO, "Load Card Response is received");
				 
				 Gson gson=new Gson();
				 reloadCard = gson.fromJson(reloadResponse.asString(), ReloadCardResponePojo.class);
				 logger.log(LogStatus.INFO, "Creating an object of Load Card Response pojo class");
				 
				 String responseMessage = reloadCard.getResponseMessage();	
				 Assert.assertEquals(responseMessage, "SUCCESS");
				 logger.log(LogStatus.PASS, "Load Card is successfull and Verified");
				 
				 String CardNumber=excelUtility.getData("CardDetails", lastrowNum-1, 1);
				 String path=csr.loginIntoCSR(CardNumber,"TC_002_LoadCard");
				 logger.log(LogStatus.PASS, logger.addScreenCapture(path));
				 
				 System.out.println("Recharge Successful");
			
				 
		}
		
		else
		{
			System.out.println("**********Previous Card Creation was not Successful,hence taking data from DefaultCardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Default Card details sheet,as previous card creation was not successful");
			
				//String clientTxnId=excel.getData("CardDetails", 1, 6);
				String clientTxnId=UUID.randomUUID().toString();
				System.out.println(clientTxnId);
				String urn=excelUtility.getData("DefaultCardDetails", 1, 0);
				System.out.println(urn);
				//String cardNumber=excel.getData("CardDetails", 1, 0);
				System.out.println(excelUtility.getData("DefaultCardDetails",1,1));
				String last4Digits=Last4Digits.getLast4Digits(excelUtility.getData("DefaultCardDetails",1,1));
				String customerID=excelUtility.getData("DefaultCardDetails", 1, 4);
				String loadAmount=excelUtility.getData("DefaultCardDetails", 1, 5);
				
				
				 reloadResponse=service1.reloadCard(clientTxnId,urn,last4Digits,customerID,loadAmount);
				 logger.log(LogStatus.INFO,"Calling Load Card API");
				 
				 System.out.println("Response String is "+reloadResponse.asString());
				 logger.log(LogStatus.INFO, "Load Card Response is received");
				 
				 Gson gson=new Gson();
				 reloadCard = gson.fromJson(reloadResponse.asString(), ReloadCardResponePojo.class);
				 logger.log(LogStatus.INFO, "Creating an object of Reload Card Response pojo class");
				
				 String responseMessage = reloadCard.getResponseMessage();	
				 Assert.assertEquals(responseMessage, "SUCCESS");
				 logger.log(LogStatus.PASS, "Load Card is successfull and Verified");
				 
				 String CardNumber=excelUtility.getData("DefaultCardDetails",1, 1);
				 String path=csr.loginIntoCSR(CardNumber,"TC_002_LoadCard_LoadCard_DefaultCardDetails");
				 logger.log(LogStatus.PASS, logger.addScreenCapture(path));
				 System.out.println("Recharge Successful");
				
			
		}
		
		
		
	}
}

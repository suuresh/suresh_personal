package apiAutomation.API;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.services.cardUnblock.responsepojo.CardUnblockResponsePojo;
import com.utilities.BaseTest;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CSRLoginService;
import com.webservices.services.CardUnblockService;

public class CardUnblockTest extends BaseTest
{
	ExcelUtility excelUtility=new ExcelUtility();
	CardUnblockService unblockservice=new CardUnblockService();
	String clientTxnId=UUID.randomUUID().toString();
	String last4Digits;
	CSRLoginService csr=new CSRLoginService();
	
	@Test
	public void cardUnblock_tc()
	{
		int lastrowNum=excelUtility.getLastRowNum("CardDetails");
		logger=BaseTest.reports.startTest("TC_006_Card_UnBlock");
		logger.log(LogStatus.INFO, "Card Block Test Case Started");
		
		if ((excelUtility.getData("Carddetails",lastrowNum-1, 7).equals("00")))
		{
			String urn=excelUtility.getData("Carddetails",lastrowNum-1, 0);
			String customerId=excelUtility.getData("Carddetails",lastrowNum-1, 4);
			String cardNumber=excelUtility.getData("Carddetails",lastrowNum-1, 1);
			last4Digits=Last4Digits.getLast4Digits(cardNumber);
			
			System.out.println("************************************----------------------------------------********************************");
			System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Card details sheet,as previous card creation was successful");
			
			Response ublockResponse = unblockservice.cardUnblock(clientTxnId, last4Digits, urn, customerId);
			logger.log(LogStatus.INFO,"Calling UnBlock Card API");
			
			System.out.println("Card Unblock Response String is "+ublockResponse.asString());
			logger.log(LogStatus.INFO, "UnBlock Card Response is received");
			
			//create object of card unblock response pojo class
			
			Gson gson=new Gson();
			CardUnblockResponsePojo unblock_response = gson.fromJson(ublockResponse.asString(), CardUnblockResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of UnBlock Card Response pojo class");
			
			String responseMessage = unblock_response.getResponseCode();
			Assert.assertEquals(responseMessage, "00");
			logger.log(LogStatus.PASS, "Card UnBlocking is successfull and Verified");
			String path=csr.loginIntoCSR(cardNumber,"TC_005_CardUnblock");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
			System.out.println("Card Unblock was successful");
			
		}
		
		else
		{
			String urn=excelUtility.getData("DefaultCardDetails",1, 0);
			String customerId=excelUtility.getData("DefaultCardDetails",1, 4);
			String cardNumber=excelUtility.getData("DefaultCardDetails",1, 1);
			last4Digits=Last4Digits.getLast4Digits(cardNumber);
			
			System.out.println("************************************----------------------------------------********************************");
			System.out.println("**********Previous Card Creation was Successful,hence taking data from DefaultCardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Default Card details sheet,as previous card creation was not successful");
			
			Response ublockResponse = unblockservice.cardUnblock(clientTxnId, last4Digits, urn, customerId);
			logger.log(LogStatus.INFO,"Calling UnBlock Card API");
			
			System.out.println("Card Unblock Response String is "+ublockResponse.asString());
			
			//create object of card unblock response pojo class
			
			Gson gson=new Gson();
			CardUnblockResponsePojo unblock_response = gson.fromJson(ublockResponse.asString(), CardUnblockResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of UnBlock Card Response pojo class");
			
			String responseMessage = unblock_response.getResponseCode();
			Assert.assertEquals(responseMessage, "00");
			logger.log(LogStatus.PASS, "Card UnBlocking is successfull and Verified");
			
			String path=csr.loginIntoCSR(cardNumber,"TC_005_CardUnblock_default_card_details");
			logger.log(LogStatus.PASS, logger.addScreenCapture(path));
			System.out.println("Card Unblock was successful");
		}
	}

}

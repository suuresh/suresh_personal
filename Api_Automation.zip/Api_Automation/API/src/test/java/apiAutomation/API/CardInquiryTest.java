package apiAutomation.API;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.services.cardinquiry.responepojo.CardInquiryResponsePojo;
import com.utilities.BaseTest;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CardInquiryService;

public class CardInquiryTest extends BaseTest
{
	CardInquiryService inquiryService=new CardInquiryService() ;
	ExcelUtility excelUtility= new ExcelUtility();
	String clientTxnId=UUID.randomUUID().toString();
	String last4Digits;
	Response cIresponse;
	CardInquiryResponsePojo cardInquiryRespone=new CardInquiryResponsePojo();

	@Test
	public void cardInquiry_TC()
	{
		int lastrowNum=excelUtility.getLastRowNum("CardDetails");
		logger=reports.startTest("TC_003_CardInquiry");
		logger.log(LogStatus.INFO, "Card Inquiry API Test Case Started");
		
		if (excelUtility.getData("CardDetails", lastrowNum-1, 7).equals("00"))
		{	
			String cardNumber=excelUtility.getData("CardDetails", lastrowNum-1, 1);
			System.out.println(cardNumber);
			String urn=excelUtility.getData("CardDetails", lastrowNum-1, 0);
			String customerId=excelUtility.getData("CardDetails", lastrowNum-1, 4);
			
			last4Digits=Last4Digits.getLast4Digits(cardNumber);
			System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Card details sheet,as previous card creation was successful");
			
			cIresponse= inquiryService.cardInquiry(clientTxnId, last4Digits, urn, customerId);
			logger.log(LogStatus.INFO,"Calling Card Inquiry API");
			
			System.out.println("Card Inquiry response is "+cIresponse.asString());
			logger.log(LogStatus.INFO, "Card Inquiry Response is received");
			
			Gson gson =new Gson();
			cardInquiryRespone = gson.fromJson(cIresponse.asString(),CardInquiryResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of CardInquiry Response pojo class");
			
			String responseCode=cardInquiryRespone.getResponseCode();
			Assert.assertEquals(responseCode, "00");
			logger.log(LogStatus.PASS, "Card Inquiry is Successfull and Verified");
			System.out.println("Card Inquiry is successful");
			
			
		}
		
		else
		{
			String cardNumber=excelUtility.getData("DefaultCardDetails", 1, 1);
			String urn=excelUtility.getData("DefaultCardDetails", 1, 0);
			String customerId=excelUtility.getData("DefaultCardDetails", 1, 4);
			
			last4Digits=Last4Digits.getLast4Digits(cardNumber);
			System.out.println("**********Previous Card Creation was not Successful,hence taking data from DefaultCardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Taking data from Default Card details sheet,as previous card creation was not successful");
			
			cIresponse= inquiryService.cardInquiry(clientTxnId, last4Digits, urn, customerId);
			logger.log(LogStatus.INFO,"Calling Card Inquiry API");
			
			System.out.println("Card Inquiry response is "+cIresponse.asString());
			logger.log(LogStatus.INFO, "Card Inquiry Response is received");
			
			Gson gson =new Gson();
			cardInquiryRespone = gson.fromJson(cIresponse.asString(),CardInquiryResponsePojo.class);
			logger.log(LogStatus.INFO, "Creating an object of CardInquiry Response pojo class");
			
			String responseCode=cardInquiryRespone.getResponseCode();
			Assert.assertEquals(responseCode, "00");
			logger.log(LogStatus.PASS, "Card Inquiry is Successfull and Verified");
			System.out.println("Card Inquiry is successful");
		}
		
	}
	
}

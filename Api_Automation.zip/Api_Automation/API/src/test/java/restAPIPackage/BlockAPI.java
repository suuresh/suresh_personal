package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;



public class BlockAPI
{

	@Test
	public void postSample()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().
				contentType("application/json").
				
		body("{"+
    "\"messageCode\": \"1240\","+
    "\"clientId\": \"WIBMO\","+
    "\"clientTxnId\": \"IN812593108\","+
    "\"requestDateTime\": \"20161223121001\","+
    "\"bankId\": 6019,"+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"entityId\": 100,"+
    "\"last4Digits\": \"1091\","+
	"\"urn\": 1012372476,"+
	"\"blockType\": \"Custom\","+
	"\"customerId\":\"IN81259300\","+
	"\"reserved1\":\"Block\","+
	"\"reserved2\":\"mobile lost so custom Blocking the card API\""+
		"}").
		
		when().
		post("v1/6019/blockCard/1356/20150701235959xhstiesqfds").
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).and().
		body("responseCode",equalTo("00")).
		
		extract().response();
		
				
		System.out.println("Card block response message is "+responseMessage.asString());
		
		JsonPath json=new JsonPath(responseMessage.asString());
		String valueFromJson = json.get("responseMessage");

		System.out.println(valueFromJson);
		System.out.println("block is successfull");
		
		
	}
}

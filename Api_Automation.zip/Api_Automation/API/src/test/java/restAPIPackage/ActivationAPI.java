package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

public class ActivationAPI {

	@Test
	public void activationAPI() {

		RestAssured.baseURI = "https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();

		Response responseMessage = given()
				.contentType("application/json")
				.

				body("{"
						+ "\"messageCode\": \"1010\","
						+ "\"clientId\": \"WIBMO\","
						+ "\"clientTxnId\": \"SunnyAct20161226-1930\","
						+ "\"requestDateTime\": \"20161223121001\","
						+ "\"bankId\": 6019,"
						+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
						+ "\"entityId\": 100,"
						+ "\"loadAmount\": \"300000\","
						+ "\"productId\": 6,"
						+ "\"cardHolder\": {"
						+ "\"cardholderFirstName\":\"Velocity Check Non KYC\","
						+ "\"cardholderLastName\": \"NewAPI\","
						+ "\"cardholderMobile\": \"9900917736\","
						+ "\"cardholderDateOfBirth\" :\"25-12-1997\","
						+ "\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","
						+ "\"cardholderAddress\":\"WINGS,Cambridge Road,Domlur1\","
						+ "\"cardholderCity\":\"Bangalore\","
						+ "\"cardholderState\":\"Karnataka\","
						+ "\"cardholderZipCode\":\"560020\","
						+ "\"cardholderCountry\":\"India\"" + "},"
						+ "\"customerIdentityProfile\": {"
						+ "\"customerAadharCardNumber\": \"A_feb13_02\","
						+ "\"customerPANCardNumber\": \"\","
						+ "\"customerPassportNumber\": \"\","
						+ "\"customerVoterIdNumber\": \"\","
						+ "\"customerDrivingLicenseNumber\": \"\"" + "},"
						+ "\"cardProfileId\": 20,"
						+ "\"customerId\": \"IN8121235\","
						+ "\"sourceAccountType\":\"00\","
						+ "\"sourceAccount\":\"1234\"" + "}").

				when().log().body().
				post("v1/6019/createCard/0432/20150701235959xhstiesqfds").

				then().and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and()
				.body("responseCode", equalTo("00")).extract().response();
		
				System.out.println("responseMessage is "+responseMessage.asString());
				
				JsonPath jsonValue=new JsonPath(responseMessage.asString());
				
				Object cardNumber = jsonValue.get("cardNumber");
				System.out.println(cardNumber);

	}
}

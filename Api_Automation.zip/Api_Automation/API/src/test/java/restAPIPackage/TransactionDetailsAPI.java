package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class TransactionDetailsAPI
{
	@Test
	public void transactionDetailsAPI()
	{
		
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().
		body("{"+
    "\"messageCode\": \"1070\","+
    "\"clientId\": \"WIBMO\","+
    "\"bankId\": 6019,"+
    "\"requestDateTime\": \"20160715025837\","+
    "\"clientTxnId\": \"201507271458377149gM91jY7\","+
    "\"fromDate\":\"08/06/2016\","+
    "\"toDate\": \"30/06/2018\","+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"last4Digits\": \"3417\","+
    "\"urn\": 1012341758,"+
    "\"customerId\": \"SOcXMGy001\""+
"}").
		
		when().
		post("v1/6019/transactionInquiry/1356/20150701235959xhstiesqfds").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		
		extract().response();
		
		JsonPath jsonValue=new JsonPath(responseMessage.asString());
		
		System.out.println("Response message is "+responseMessage.asString());
		
		
	}

}

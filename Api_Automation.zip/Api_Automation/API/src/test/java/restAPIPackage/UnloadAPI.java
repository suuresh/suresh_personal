package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class UnloadAPI
{
	
	@Test
	public void unloadAPI()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		
		
		Response responseMessage = given().
		header("Content-Type","application/json").
		
		body("{"+
     "\"messageCode\": \"1480\","+
    "\"clientId\": \"WIBMO\","+
    "\"clientTxnId\": \"ab5ac70e-8d7a-4b18-898e-63eabc1ee8c6\","+
    "\"requestDateTime\": \"20161010102112\","+
    "\"bankId\": 6019,"+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"entityId\": 100,"+
    "\"last4Digits\": \"7208\","+
    "\"urn\": \"1012371304\","+
    "\"agentComments\": \"Debit to customer\","+
    "\"customerId\": \"38d71a15-69b3-482b-ae1b-aa1604e12e2b\","+
  "\"transactionAmount\":300000,"+
  "\"sourceAccountType\":0,"+
  "\"sourceAccount\":\"1234\","+
  "\"originalClientTxnId\":\"201607040918424092qE93qK4\","+
	"\"reserved1\":\"\","+
	"\"reserved2\":\"\","+
	"\"reserved3\":\"0\","+
	"\"reserved4\":\"PG Load\","+
	"\"reserved5\":\"I|10003\""+
"}").
	
		when().
		post("v1/6019/debitAccount/0105/20150701235959xhstiesqfds").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		body("responsecCode",equalTo("00")).
		
		extract().response();
		
		
	}

}

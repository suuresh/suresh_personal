package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class ResetPinAPI
{

	@Test
	public void resetPinAPI()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().               //response data will be in RAW format. 
		header("Content-Type","application/json").
		
		
		body("{"+
    "\"messageCode\": \"1120\","+
    "\"clientId\": \"WIBMO\","+
    "\"bankId\": 6019,"+
    "\"entityId\": 100,"+
    "\"requestDateTime\": \"20161010102112\","+
    "\"clientTxnId\": \"201507271458370149gM90jY0\","+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"newPIN\": \"1212\","+
    "\"urn\": 1001195628,"+
    "\"last4Digits\":\"5277\","+
    "\"customerId\":\"IN80888888082\""+
				"}").
		
		when().
		post("v1/6019/resetPIN/1356/20150701235959xhstiesqfds").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("responseCode",equalTo("00")).
		
		extract().response();
		
		System.out.println("Response message is "+responseMessage.asString());
		
		
		
	}
}

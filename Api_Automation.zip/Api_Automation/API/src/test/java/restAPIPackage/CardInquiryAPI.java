package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class CardInquiryAPI
{

	@Test
	public void cardInquiry()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		io.restassured.RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().
		contentType("application/json").
		body("{"+
    "\"messageCode\": 1090,"+
    "\"clientId\": \"WIBMO\","+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"clientTxnId\": \"207507271458379149gM90jY9\","+
    "\"requestDateTime\":20161031214559,"+
    "\"bankId\": 6019,"+
    "\"customerId\": \"6a8570de-0580-42bc-bc20-c333f11222ed\","+
    "\"last4Digits\": \"4501\","+
    "\"urn\": 1012371452"+

"}").
		
		when().
		post("/v1/6019/cardInquiry/0432/20150701235959xhstiesqfds").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("responseCode",equalTo("00")).
		
		extract().response();
		
		System.out.println("card inquriry response string is "+responseMessage.asString());
				
				
		
		
	}
}

package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class RechargeAPI 
{

   @Test
   public void rechargeAPI()
   {
	   RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
	   
	   RestAssured.useRelaxedHTTPSValidation();
	   
	   Response responseMessage = given().
	   contentType("application/json").
	   
	   body("{"+
     "\"messageCode\": \"1080\","+
     "\"clientId\": \"WIBMO\","+
     "\"clientTxnId\": \"201710748459157562XM91jZB\","+
     "\"requestDateTime\": \"20161024102112\","+
     "\"bankId\": 6019,"+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"entityId\": 100,"+
    "\"last4Digits\": \"1091\","+
    "\"urn\": \"1012372476\","+
    "\"customerId\": \"IN81259300\","+
      "\"agentComments\":\"Credit to customer rest\","+
   "\"transactionAmount\":7000,"+
   "\"sourceAccountType\":\"00\","+
  "\"sourceAccount\":\"1234\","+
  "\"originalClientTxnId\":\"201607040918424092qE93qK4\","+
    "\"reserved1\":\"\","+
     "\"reserved2\":\"\","+
     "\"reserved3\":\"0\","+
     "\"reserved4\":\"PG Load\","+
     "\"reserved5\":\"I|10003\""+
"}").
	   when().
	   post("v1/6019/creditAccount/0105/20150701235959xhstiesqfds").
	   
	   then().
	   assertThat().and().statusCode(200).and().contentType(ContentType.JSON).and().
	   body("responseMessage",equalTo("SUCCESS")).
	   
	   extract().response();
	   
	   System.out.println("Card recharge response message is "+responseMessage.asString());
	   
		JsonPath json=new JsonPath(responseMessage.asString());
		String valueFromJson = json.get("responseMessage");
		 Object avaiBalanceFromJson = json.get("availableBalance");

		System.out.println(valueFromJson);
		System.out.println("recharge is successfull");
		
		System.out.println("avialable balance is "+avaiBalanceFromJson);
	   
	   
   }
}

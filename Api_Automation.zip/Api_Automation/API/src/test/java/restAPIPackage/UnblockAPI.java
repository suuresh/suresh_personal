package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class UnblockAPI 
{
	
	@Test
	public void unblockAPI()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body("{"+
    "\"messageCode\": \"1250\","+
    "\"clientId\": \"WIBMO\","+
    "\"clientTxnId\": \"IN8125911081\","+
    "\"requestDateTime\": \"20161223121001\","+
    "\"bankId\": 6019,"+
    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
    "\"entityId\": 100,"+
    "\"last4Digits\": \"1091\","+
	"\"urn\":1012372476,"+
	"\"customerId\":\"IN81259300\","+
	"\"reserved1\":\"imaker\","+
	"\"reserved2\":\"verfication complete.UnBlocking custom block card Rest\""+
"}").
		
		when().
		post("v1/6019/unblockCard/1356/20150701235959xhstiesqfds").
		
		then().
		assertThat().and().statusCode(200).contentType(ContentType.JSON).
		body("responseCode",equalTo("00")).and().
		
		extract().response();
		
		System.out.println("Unblock response message is "+responseMessage.asString());
		
		//converting the response string into Json format using json path
		
		JsonPath json=new JsonPath(responseMessage.asString());
		
		String valueFromJson=json.get("responseMessage");
		System.out.println("data retrieved from reponse json is "+valueFromJson);
		System.out.println("unblock api is successful");
		
		
		
		
	}

}

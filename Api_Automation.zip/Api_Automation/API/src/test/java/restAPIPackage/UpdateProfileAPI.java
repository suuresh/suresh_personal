package restAPIPackage;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UpdateProfileAPI
{

	@Test
	public void updateProfile()
	{
		RestAssured.baseURI="https://aero-api-stg.pc.enstage-sas.com";
		RestAssured.useRelaxedHTTPSValidation();
		
		Response responseMessage = given().
		contentType("application/json").
		
		body("{"+
"\"messageCode\": \"1280\","+
"\"clientId\": \"WIBMO\","+
"\"clientTxnId\": \"201517271788575149gM91jY2\","+
"\"bankId\": 6019,"+
"\"requestDateTime\": \"20160715025837\","+
"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
"\"entityId\": 100,"+
"\"urn\": 1012372476,"+
"\"last4Digits\": \"1091\","+
"\"customerId\": \"IN81259300\","+
"\"cardholder\":{"+
"\"cardProfileId\":20,"+
"\"cardholderFirstName\": \"Sanmati\","+
"\"cardholderLastName\": \"vardhaman API\","+
"\"cardholderMobile\": \"9900917736\","+
"\"cardholderDateOfBirth\" :\"11-06-1986\","+
"\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","+
"\"cardholderAddress\":\"attiguppe, Vijayanagar\","+
"\"cardholderCity\":\"Bangalore\","+
"\"cardholderState\":\"Karnataka\","+
"\"cardholderZipCode\":\"560040\","+
"\"cardholderCountry\":\"India\","+
"\"customerIdentityProfile\":"+
"{"+            
"\"customerAadharCardNumber\": \"A_feb13_02\","+ 
"\"customerPANCardNumber\": \"\","+     
"\"customerPassportNumber\": \"\","+   
"\"customerVoterIdNumber\": \"\","+    
"\"customerDrivingLicenseNumber\": \"\""+ 
 "}"+
"}"+
"}").
		
		when().log().body().
		post("/v1/6019/cardHolderProfile/IN20014/dsfsdf").
		
		then().
		assertThat().statusCode(200).and().contentType(ContentType.JSON).
		body("responseCode",equalTo("00")).
		
		extract().response();
		
		System.out.println("Response message:"+responseMessage.asString());
		
		//convert the string into JSON
		
		JsonPath jsonValue=new JsonPath(responseMessage.asString());
		
		System.out.println("Respons message is "+jsonValue.get("responseMessage"));
		
		
		
	}
}

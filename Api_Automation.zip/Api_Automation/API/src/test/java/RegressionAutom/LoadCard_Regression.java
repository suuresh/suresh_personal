package RegressionAutom;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;
//import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
//import com.services.reload.responsepojo.ReloadCardResponePojo;
import com.services.reload.responsepojo.copy.ReloadCardResponePojoCopy;
import com.utilities.BaseTest;
import com.utilities.CopyOfExcelUtility;
import com.utilities.DataProviderUtility;
import com.utilities.ExcelUtility;
import com.utilities.Last4Digits;
import com.webservices.services.CSRLoginService;
import com.webservices.services.CopyOfReloadCardService;
//import com.webservices.services.ReloadCardService;


public class LoadCard_Regression extends BaseTest
{
	//ReloadCardService service1=new ReloadCardService() ;
	CopyOfReloadCardService service1=new CopyOfReloadCardService();
	Response reloadResponse ;
	ReloadCardResponePojoCopy reloadCardCopy;

	//ExcelUtility excel=new ExcelUtility();
	CopyOfExcelUtility excelUtility= new CopyOfExcelUtility();
	CSRLoginService csr=new CSRLoginService();
	int rowCount=1;
	int acutalResultCol=13;
	
	
	@Test(dataProvider="ReloadReggression",dataProviderClass=DataProviderUtility.class,description="Regression test case for reload")
	public void testcaseName(String TC_Number,String scenario,String messageCode,String ClientID,String BankID,String CardNumber,String cardLast4digit,String cardURN
			,String customer_ID,String load_Amount,String accountType,String exectionStatus,String expectedResult)
	{
		
		String TestCaseName=TC_Number+scenario;
		int lastrowNum=excelUtility.getLastRowNum("ReloadRegression");
		
		logger=BaseTest.reports.startTest(TestCaseName);
		logger.log(LogStatus.INFO, scenario+"_Test Case Started");
		
		System.out.println(lastrowNum);
		//System.out.println((excelUtility.getData("CardDetails", lastrowNum-1, 0)));
		
		if (exectionStatus.equals("YES"))
		{
				
		
			//System.out.println("**********Previous Card Creation was Successful,hence taking data from CardDetails Sheet**********");
			logger.log(LogStatus.INFO, "Execution Status is YES---we are good to go with this test case");
			String clientTxnId=UUID.randomUUID().toString();
				
							
			reloadResponse=service1.reloadCard(messageCode,ClientID,clientTxnId,BankID,cardLast4digit,cardURN,customer_ID,load_Amount,accountType);
			logger.log(LogStatus.INFO,"Calling Load Card API");
			 
			System.out.println("Load Card Response String is "+reloadResponse.asString());
			logger.log(LogStatus.INFO, "Load Card Response is received");
				 
			Gson gson=new Gson();
			reloadCardCopy = gson.fromJson(reloadResponse.asString(), ReloadCardResponePojoCopy.class);
			logger.log(LogStatus.INFO, "Creating an object of Load Card Response pojo class");
				 
			String responseMessage = reloadCardCopy.getResponseCode();
			excelUtility.setData("ReloadRegression",rowCount++, acutalResultCol, responseMessage);
			System.out.println("row value is "+rowCount+" column value is "+acutalResultCol);
			logger.log(LogStatus.PASS, "writing Response message  to excel is successful");
			
			if(expectedResult.equalsIgnoreCase(responseMessage))
			{
				excelUtility.setStatusWithColor("ReloadRegression",--rowCount, 14, "PASS");
			}
			else
			{
				excelUtility.setStatusWithColor("ReloadRegression",--rowCount, 14, "FAIL");
			}
			
			rowCount++;
			
			Assert.assertEquals(responseMessage,expectedResult);
			logger.log(LogStatus.PASS, "Load Card is successfull and Verified");
				 
			//String CardNumber=excelUtility.getData("CardDetails", lastrowNum-1, 1);
			//String path=csr.loginIntoCSR(CardNumber,TestCaseName);
			//logger.log(LogStatus.PASS, logger.addScreenCapture(path));
				 
			System.out.println(scenario+" is Successful");
			
				 
		}
		
		else if(exectionStatus.equals("NO"))
		{
			System.out.println("Since exection status is NO we are not executing this test case");
		}
		
		
	}
}

/**
 * 
 */
package csrPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import BOB.CSR.Pages.EnhancedReportsPage;
import BOB.utilities.DataProviderUtility;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class EnhancedReportsTest extends CSRBaseTest
{
	
	@Test(dataProvider="CSRData",dataProviderClass=DataProviderUtility.class)
	public void enhancedReportActivation(String reportName,String productName,String fromDate,String toDate,String fileType)
	{
		System.out.println("in CSR prepaidDetails test classs");
		initBrowser("chrome");
		System.out.println(gen.csruserName()+"and "+gen.csruserPassword());
		//loginIntoCSR("admin","password1000");
		loginIntoCSR(gen.csruserName(),gen.csruserPassword());
		EnhancedReportsPage ePage=PageFactory.initElements(driver, EnhancedReportsPage.class);
		ePage.csrReports(reportName,productName, fromDate, toDate,fileType);
		
	}

}

/**
 * 
 */
package csrPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import bobPackage.Test.BaseTest;
import BOB.CSR.Pages.EnhancedReportsPage;
import BOB.CSR.Pages.ExpectionHandlingPage;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class ExceptionHanldingTest extends CSRBaseTest
{
	
	@Test
	public void processExceptionHandling()
	{
		System.out.println("in process Exception Handling test classs");
		initBrowser("chrome");
		System.out.println(gen.csruserName()+"and "+gen.csruserPassword());
		//loginIntoCSR("admin","password1000");
		loginIntoCSR(gen.csruserName(),gen.csruserPassword());
		ExpectionHandlingPage exceptionPage=PageFactory.initElements(driver, ExpectionHandlingPage.class);
		exceptionPage.processExceptionItems("4233640258132590");
	}

}

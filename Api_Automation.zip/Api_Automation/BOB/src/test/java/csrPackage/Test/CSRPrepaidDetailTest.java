/**
 * 
 */
package csrPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import BOB.CSR.Pages.PrepaidDetailsPage;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class CSRPrepaidDetailTest extends CSRBaseTest
{

	@Test(description="login into csr and do Prepaid details")
	public void prepaidDetails()
	{
		System.out.println("in CSR prepaidDetails test classs");
		initBrowser("chrome");
		System.out.println(gen.csruserName()+"and "+gen.csruserPassword());
		//loginIntoCSR("admin","password20");
		loginIntoCSR(gen.csruserName(),gen.csruserPassword());
		
		PrepaidDetailsPage prp=PageFactory.initElements(driver, PrepaidDetailsPage.class);
		System.out.println(prp.accosaLink);
		if(prp.accosaLink.isDisplayed())
			{
			System.out.println("hurray element is present");
			}
		String name=prp.checkPrepaidDetails("4670200141103090");
		System.out.println("product name is "+name);
		Assert.assertTrue(name.contains("BOB"));
		System.out.println("prepaid details is successful");
	}
}

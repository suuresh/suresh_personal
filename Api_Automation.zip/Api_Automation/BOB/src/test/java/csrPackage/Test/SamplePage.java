/**
 * 
 */
package csrPackage.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import BOB.CSR.Pages.CSRBasePage;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class SamplePage extends CSRBasePage
{
	
	@Test
	public void loginCSR() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "E:\\Sanmati\\Automation\\Api_Automation\\BOB\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://192.168.105.50:9898/csr/index.jsp");
		driver.manage().window().maximize();
		driver.findElement(By.name("txtUserId")).sendKeys("admin");
		driver.findElement(By.name("txtPassword")).sendKeys("password1000");
		driver.findElement(By.xpath("//input[@value='Sign In']")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//b[text()='ACCOSA']")).click();
		WebElement myFrame=driver.findElement(By.xpath("//iframe[@src='leftmenu.jsp']"));
		driver.switchTo().frame(myFrame);
		driver.findElement(By.xpath("//a[text()='Prepaid Details']")).click();
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtSearch")).sendKeys("4670200141103090");
		driver.findElement(By.id("btnSearch")).click();
		driver.findElement(By.xpath("//a[contains(@title,'Click')]")).click();
		Thread.sleep(3000);
		
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		//List<String> myWindows = new List<String>(driver.getWindowHandles());
		System.out.println(newTab.size());
		//driver.switchTo().window(myWindow);
		driver.switchTo().window(newTab.get(1));
		Thread.sleep(3000);
		String myText=driver.findElement(By.xpath("//td[contains(text(),'Product :')]/following-sibling::td/font")).getText();
		System.out.println(myText);
		driver.findElement(By.id("cmdDone")).click();
		driver.switchTo().window(newTab.get(0));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//b[text()='Sign Out']")).click();
		driver.close();
		
	
	}

}

package bobPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import BOB.CMS.Pages.ViewOrdersPage;

import com.relevantcodes.extentreports.LogStatus;

public class ViewOrdersTest extends BaseTest
{
	

	@Test
	public void viewOrders_Test()
	{
		System.out.println("In View Orders Method");
		logger=reports.startTest("View Orders");
		
		initBrowser("chrome");
		logger.log(LogStatus.INFO, "Browser stated and Application launched");
		
		String user = gen.userName();
		String pass=gen.userPassword();
		System.out.println("Username and password is "+user+"password is "+pass);
		loginIntoApp(user,pass);
		logger.log(LogStatus.INFO, "Successfully logged into the application");
		
		ViewOrdersPage viewOrder=PageFactory.initElements(driver, ViewOrdersPage.class);
		viewOrder.viewOrders("3076");
		
	}

}

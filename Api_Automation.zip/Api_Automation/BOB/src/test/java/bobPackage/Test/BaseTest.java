package bobPackage.Test;


import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
//import org.testng.annotations.BeforeTest;



import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import BOB.CSR.Pages.CSRBasePage;
import BOB.utilities.CopyOfExcelUtility;
import BOB.utilities.Generics;
import BOB.utilities.TakeScreenshotUtility;

public class BaseTest
{
	public static int count = 0;
	public WebDriver driver;
	public Generics gen=new Generics();
	public static ExtentReports reports;
	public ExtentTest logger;
	public CopyOfExcelUtility excel=new CopyOfExcelUtility();
	
	//public static final String productname="SWADESHI SAMRIDHI CARD";
	
	//****************************************************************************
	
	/**
	 * This method is used to initiate the browser and launch the application URL.
	 * @param browserName
	 */
	public void initBrowser(String browserName)
	{
		
			if (browserName.equalsIgnoreCase("chrome"))
		
			{
			System.setProperty("webdriver.chrome.driver", "E:\\Sanmati\\Automation\\Api_Automation\\BOB\\softwares\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.get(gen.getAppURL());
			driver.manage().window().maximize();
			
			}
			else
			{
				System.setProperty("webdriver.firefox.bin","E:\\Sanmati\\Automation\\Api_Automation\\BOB\\softwares\\geckodriver.exe");
				System.setProperty("webdriver.gecko.driver","E:\\Sanmati\\Automation\\Api_Automation\\BOB\\softwares\\geckodriver.exe");
				
				File pathBinary = new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
				FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);   
				DesiredCapabilities desired = DesiredCapabilities.firefox();
				FirefoxOptions options = new FirefoxOptions();
				desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
				driver = new FirefoxDriver(options);
				
				driver.get(gen.getAppURL());
			}
		
	}
	
	//****************************************************************************
	
	/**
	 * This method is used to login into app
	 * @param uname
	 * @param pwd
	 */
	public void loginIntoApp(String uname,String pwd)
	{
		System.out.println("inside logininto app method");
		driver.findElement(By.name("txtUserId")).sendKeys(uname);
		driver.findElement(By.name("txtPassword")).sendKeys(pwd);
		driver.findElement(By.name("submit")).click();
		Generics.waitThread();
		count=count+1;
	}
	
	//****************************************************************************
	
	/**
	 * this method is used to Sign Out from the application
	 */
	public void signOutFromApp()
	{
		driver.findElement(By.linkText("Sign Out")).click();
	}
		
	//****************************************************************************
	
	
	
	@BeforeSuite(alwaysRun=true)
	public void setUp()
	
	{
		reports =new ExtentReports(System.getProperty("user.dir")+"\\reports\\"+TakeScreenshotUtility.dateStamp()+"\\"+"sample.html");
		
		
	}
	
	//****************************************************************************
	
	@AfterSuite()
	public void tearDown()
	{
		System.out.println("i m in suite");
		reports.endTest(logger);
		reports.flush();
	}
	
	//****************************************************************************
	@AfterMethod
	public void closeBrowser(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			
			System.out.println(count);
			excel.setStatusWithColor("ReloadRegression", count, 14,"fail");
			logger.log(LogStatus.FAIL,"Test case "+result.getName()+" failed");
			
		}
		
		signOutFromApp();
		driver.quit();
		
	}
	
	
}

package bobPackage.Test;


import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import BOB.CMS.Pages.CreateCardsPage;
import BOB.utilities.DataProviderUtility;
import BOB.utilities.TakeScreenshotUtility;

import com.relevantcodes.extentreports.LogStatus;


public class CreateCardTest extends BaseTest
{

	@Test(dataProvider="Smoke",dataProviderClass=DataProviderUtility.class)
	public void loginAndCreateCards(String TestCaseName,String ExpiryMonths,String NumberofCards,String ProductName,String ExpectedResult)
	{
		
		System.out.println("in test class");
		logger=reports.startTest(TestCaseName);
		initBrowser("chrome");
		logger.log(LogStatus.INFO, "Browser stated and Application launched");
		
		String user = gen.userName();
		String pass=gen.userPassword();
		System.out.println("Username and password is "+user+"password is "+pass);
		loginIntoApp(user,pass);
		logger.log(LogStatus.INFO, "Successfully logged into the application");
		
		
		//Call create card request method
		
		CreateCardsPage createCard=PageFactory.initElements(driver, CreateCardsPage.class);
		logger.log(LogStatus.INFO, "Create and object of CreateCard Page");
		String batchID=createCard.createCardsRequestFromCMS(ExpiryMonths,NumberofCards,ProductName);
		
		logger.log(LogStatus.INFO, "Card creation request is successfull and batch id is succesffully returned");
		
		//Call Create card approve method.
		
		String responseMessage=createCard.createCardsApproveFromCMS(batchID);
		//Assert.assertEquals(responseMessage, ExpectedResult);
		Assert.assertTrue(responseMessage.contains(ExpectedResult));
		String screenshotPath = TakeScreenshotUtility.getScreenshot(TestCaseName, driver);
		logger.log(LogStatus.PASS,"Card Creation is Successful" );
		logger.log(LogStatus.PASS, logger.addScreenCapture(screenshotPath));
		
		
	}
}

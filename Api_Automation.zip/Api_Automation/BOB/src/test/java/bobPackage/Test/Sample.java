package bobPackage.Test;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

public class Sample
{
	
	@Test
	public void loginintoAPp()
	{
		//System.setProperty("webdriver.chrome.driver","D:\\Api_Automation\\BOB\\softwares\\chromedriver.exe");
		//System.setProperty("webdriver.gecko.driver", "./softwares/geckodriver.exe");
		System.setProperty("webdriver.firefox.bin","D:\\Api_Automation\\BOB\\softwares\\geckodriver.exe");
		System.setProperty("webdriver.gecko.driver","D:\\Api_Automation\\BOB\\softwares\\geckodriver.exe");
		
		File pathBinary = new File("D:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);   
		DesiredCapabilities desired = DesiredCapabilities.firefox();
		FirefoxOptions options = new FirefoxOptions();
		desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
		WebDriver driver = new FirefoxDriver(options);
		
		
		
		driver.get("http://192.168.105.50:9898/prepaid/cms/index.jsp");
		//driver.manage().window().maximize();
		WebElement userName = driver.findElement(By.xpath("//input[@name='txtUserId']"));
		WebElement pass = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement signIn=driver.findElement(By.xpath("//input[@value='Sign In']"));
		userName.sendKeys("admin");
		pass.sendKeys("password60");
		signIn.click();
		
		
	}

}

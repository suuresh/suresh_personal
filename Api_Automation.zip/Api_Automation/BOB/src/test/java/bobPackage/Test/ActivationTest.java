package bobPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import BOB.CMS.Pages.ActivationRequestPage;
import BOB.utilities.DataProviderUtility;

import com.relevantcodes.extentreports.LogStatus;

public class ActivationTest extends BaseTest
{

	private String last4digit_one;
	
	@Test(dataProvider="ActivationRequest",dataProviderClass=DataProviderUtility.class)
	public void activationRequest_Test(String testcasename,String productname,String amount,String last4digit,String urn,String applicantname,String expectedResult)
	{
		System.out.println("in test class");
		logger=reports.startTest(testcasename);
		initBrowser("chrome");
		logger.log(LogStatus.INFO, "Browser stated and Application launched");
		
		String user = gen.userName();
		String pass=gen.userPassword();
		System.out.println("Username and password is "+user+"password is "+pass);
		loginIntoApp(user,pass);
		logger.log(LogStatus.INFO, "Successfully logged into the application");
		
		//call activation request method
		
		last4digit_one=last4digit;
		ActivationRequestPage activationPage=PageFactory.initElements(driver, ActivationRequestPage.class);
		logger.log(LogStatus.INFO, "initializing the activaton Page");
		String message=activationPage.activationRequest(productname,amount,last4digit_one ,urn,applicantname);
		Assert.assertTrue(message.contains(expectedResult));
		logger.log(LogStatus.PASS, "Activation Request is successful");
		
		//****** calling the activate card Request
		
		
		logger.log(LogStatus.INFO, "calling activedCardRequest method");
		String activateCardSuccessMessage=activationPage.activateCardRequest(last4digit_one);
		
		Assert.assertTrue(activateCardSuccessMessage.contains("Activate Card - Success"));
		logger.log(LogStatus.PASS, "Activate Card is successful");
		logger.log(LogStatus.INFO,"my test ends here");
		
		
	}
	
	/*@Test(dependsOnMethods="activationRequest_Test")
	public void activatedCardRequest_Test()
	{
		
		
		System.out.println("in test class");
		logger=reports.startTest("Activation");
		initBrowser("chrome");
		logger.log(LogStatus.INFO, "Browser stated and Application launched");
		
		String user = gen.userName();
		String pass=gen.userPassword();
		System.out.println("Username and password is "+user+"password is "+pass);
		loginIntoApp(user,pass);
		logger.log(LogStatus.INFO, "Successfully logged into the application");
		ActivationRequestPage activationPage1=PageFactory.initElements(driver, ActivationRequestPage.class);
		activationPage1.activateCardRequest(last4digit_one);
		
	}*/
}

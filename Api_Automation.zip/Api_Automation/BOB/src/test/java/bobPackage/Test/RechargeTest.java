package bobPackage.Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import BOB.CMS.Pages.RechargeRequestPage;
import BOB.utilities.DataProviderUtility;

public class RechargeTest extends BaseTest
{

	
	@Test(dataProvider="ReloadData",dataProviderClass=DataProviderUtility.class)
	public void rechargeRequest_Test(String TCNumber,String TestCaseName,String ProductName,String
			Cnumber,String ReloadAmount,String paymentmode,String ExpectedResult)
	{
		System.out.println("inside Recharge request test method");
		logger=reports.startTest(TCNumber+"__"+TestCaseName);
		initBrowser("chrome");
		logger.log(LogStatus.INFO, "Browser stated and Application launched");
		String user = gen.userName();
		String pass=gen.userPassword();
		System.out.println("Username and password is "+user+"password is "+pass);
		loginIntoApp(user,pass);
		logger.log(LogStatus.INFO, "Successfully logged into the application");
		
		
		RechargeRequestPage rPage=PageFactory.initElements(driver,RechargeRequestPage.class);
		logger.log(LogStatus.INFO, "Initializing the webelements of RechargeRequestPage");
		String rechargeRequestSuccessMessage=rPage.rechargeRequest(ProductName, Cnumber, ReloadAmount, paymentmode);
		
		Assert.assertTrue(rechargeRequestSuccessMessage.contains(ExpectedResult));
		logger.log(LogStatus.PASS, "Recharge Request is successful");
		
		//********************** This section is for calling Re-charge Card method *****************
		
		logger.log(LogStatus.INFO, "Calling Recharge Card Method");
		
		String last4digits=Cnumber.substring(Cnumber.length()-4);
		System.out.println(last4digits);
		
		String rechargeCardSuccessMessage=rPage.rechargeCard(last4digits);
		logger.log(LogStatus.INFO, "Calling rechargeCard method");
		
		Assert.assertTrue(rechargeCardSuccessMessage.contains("Recharge Card"));
		logger.log(LogStatus.PASS, "Recharge card is success");
		
		
	}
}

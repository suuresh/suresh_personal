package BOB.CMS.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import BOB.utilities.Generics;

public class ActivationRequestPage extends BasePage
{

	/**
	 * 	Declaration of all the web elements
	 */
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;
	
	
	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;
	
	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;
	
	@FindBy(linkText="Activation Request")
	private WebElement activationRequestLink;
	
	// ********************************************
	
	@FindBy(name="cmbProduct")
	private WebElement productList;
	
	@FindBy(name="amount")
	private WebElement amountField;
	
	@FindBy(name="lastFourDigits")
	private WebElement lastFourDigitsField;
	
	@FindBy(name="urn")
	private WebElement urnField;
	
	@FindBy(name="submit")
	private WebElement actSubmitButton;
	
	//************ Activation form web elements ************
	
	@FindBy(name="name")
	private WebElement applicantName;
	
	@FindBy(name="dob")
	private WebElement dobField;
	
	@FindBy(name="address")
	private WebElement addressField;
	
	@FindBy(name="mobile")
	private WebElement mobileField;
	
	@FindBy(name="txtEmail")
	private WebElement emailField;
	
	@FindBy(name="paymentMode")
	private WebElement paymentModeList;
	
	@FindBy(name="chequeNo")
	private WebElement chequeField;
	
	@FindBy(name="pancardNumbercb")
	private WebElement pancardCheckBox;
	
	@FindBy(name="panCard")
	private WebElement panCardField;
	
		
	@FindBy(id="journalNum")
	private WebElement cbsID;
			
	@FindBy(name="other")
	private WebElement commentsField;
	
	@FindBy(name="submit")
	private WebElement submitButton;
	
	@FindBy(xpath="//h3[text()='Activation Request - Success']")
	private WebElement activationRequestSuccess;
	
	
	/**
	 * 	Web Elements of Activate Card Request
	 */
	
	@FindBy(linkText="Activate Card")
	private WebElement activateCardLink;
	
	@FindBy(name="checkerComments")
	private WebElement checkerComment;
	
	@FindBy(xpath="//input[@value='Reject Card']")
	private WebElement rejectCard;
		
	@FindBy(xpath="//input[@value='Modify']")
	private WebElement ModifyCard;
	
	@FindBy(xpath="//input[@value='Activate Card']")
	private WebElement ActivateCard;
	
	@FindBy(xpath="//h3[text()='Activate Card - Success']")
	private WebElement successMessage;
	
	@FindBy(xpath="//frame[@name='activateCardConfirm']")
	private WebElement activateFrame;
	
	
	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public ActivationRequestPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	/**
	 * @return 
	 * 
	 */
	public String activationRequest(String productname,String amount,String last4digit,String urn,String applicatname)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		Generics.explicitWait(activationRequestLink, 60);
		activationRequestLink.click();
		driver.switchTo().defaultContent();
		
		//select the product from the product list
		Select selProduct=new Select(productList);
		selProduct.selectByVisibleText(productname);
		
		amountField.sendKeys(amount);
		lastFourDigitsField.sendKeys(last4digit);
		urnField.sendKeys(urn);
		actSubmitButton.click();
		
		//*******enter all the details in the form****
		Generics.explicitWait(applicantName,60);
		applicantName.sendKeys(applicatname);
		dobField.sendKeys(Generics.currentDate());
		addressField.sendKeys("My address");
		
		mobileField.sendKeys("1100917736");
		emailField.sendKeys("v.sunny082@gmail.com");
		
		//select payment mode from the payment mode list
		Select modeList=new Select(paymentModeList);
		modeList.selectByVisibleText("Cheque");
		
		chequeField.sendKeys("cheque1234");
		pancardCheckBox.click();
		panCardField.sendKeys("akup_"+last4digit);
		cbsID.sendKeys("CBS_"+urn);
		commentsField.sendKeys("Test comments of this URN"+urn);
		submitButton.click();
		Generics.waitThread();
		driver.switchTo().alert().accept();
		Generics.waitThread();
		String message=activationRequestSuccess.getText();
		return message;
		
	}
	
	
	public String activateCardRequest(String last4digit)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		Generics.explicitWait(activateCardLink,60);
		activateCardLink.click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		checkerComment.sendKeys("activated card number is "+last4digit );
		ActivateCard.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generics.waitThread();
		String message=successMessage.getText();
		return message;
				
	}
	
}

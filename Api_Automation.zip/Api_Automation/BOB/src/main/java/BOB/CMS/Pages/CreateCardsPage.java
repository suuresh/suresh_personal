package BOB.CMS.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import BOB.utilities.Generics;

public class CreateCardsPage extends BasePage
{

	/**
	 * Declaration of all the web elements of Create Card Request Page.
	 */
	
	
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;
	
	
	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;
	
	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;
	
	@FindBy(xpath="//a[text()='Create Card Request']")
	private WebElement cardCreateRequest;
	
	@FindBy(xpath="//a[text()='Create Card Approve']")
	private WebElement cardCreateApprove;
	
	@FindBy(id="product")
	private WebElement productList;
	
	@FindBy(id="cardCreationMode")
	private WebElement modeOfSelection;
		
	@FindBy(name="submit")
	private WebElement cardCreationSubmit;
	
	@FindBy(name="expiryMon")
	private WebElement expiryMonths;
	
	@FindBy(name="denominationSel")
	private WebElement denominationSelect;
	
	@FindBy(id="persoVendor")
	private WebElement cardVendor;
	
	@FindBy(id="template")
	private WebElement cardsTemplate;
	
	@FindBy(id="makerComments")
	private WebElement mComments;
	
	@FindBy(name="submit")
	private WebElement createCardSumbit;
	
	@FindBy(xpath="//table[@id='QUERY_SUB_TABLE']/tbody/tr/td[2]")
	private WebElement requestId;
	
	@FindBy(name="denominations")
	private WebElement numberCards;
	
	/**
	 *  Declaration of all the web elements of Create Card Approve Request.
	 */
	
	@FindBy(xpath="//td[text()='Non-Personalized']/../../../td[1]")
	private WebElement BatchID;
	
	
	
	@FindBy(name="checkerComments")
	private WebElement commentBox;
	
	@FindBy(name="approve")
	private WebElement approveButton;
	
	/**
	 *  confirmation message
	 */
	
	@FindBy(xpath="//h3[text()='Create Card Approval - Success']")
	private WebElement successMessage;
	
	
	/**	
	 * Initialization of web elements
	 */
	
	public CreateCardsPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	/**
	 * 
	 * This method is used to Create Card Request
	 * @param ExpiryMonths
	 * @param NumberofCards
	 * @param ProductName
	 * @return
	 */
	
	public String createCardsRequestFromCMS(String ExpiryMonths,String NumberofCards,String ProductName)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		Generics.explicitWait(cardManagement,60);
		cardManagement.click();
		Generics.explicitWait(cardCreateRequest,60);
		cardCreateRequest.click();
		driver.switchTo().defaultContent();
		
		//select the product from the product lists
		
		Select select_Product=new Select(productList);
		select_Product.selectByVisibleText(ProductName);
		
		//select card creation mode
		Select mode=new Select(modeOfSelection);
		mode.selectByVisibleText("Non-Personalized");
		cardCreationSubmit.click();
		Generics.waitThread();
		
		//enter the details in second page
		expiryMonths.sendKeys(ExpiryMonths);
		
		//select number of cards from the select box
		Select numberOfCards=new Select(denominationSelect);
		numberOfCards.selectByValue(NumberofCards);
		
		//card perso vendor select box
		
		Select cardPersoVendor=new Select (cardVendor);
		cardPersoVendor.selectByVisibleText("DZ");
		
		//select template from the template select box
		
		Select persoTemplate=new Select(cardsTemplate);
		persoTemplate.selectByVisibleText("Non-EMV Cards");
		mComments.sendKeys("Card creation through Automation-Sunny");
		createCardSumbit.click();
		Generics.waitThread();
		
		String cardsBatchID=requestId.getText();
		System.out.println("batch id is "+cardsBatchID);
		
		return cardsBatchID;
		
			
	}
	
	
	public String createCardsApproveFromCMS(String batchID)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		Generics.explicitWait(cardCreateApprove,60);
		cardCreateApprove.click();
		driver.switchTo().defaultContent();
		
		String pathofBatchID="//a[text()='"+batchID+"']";
		driver.findElement(By.xpath(pathofBatchID)).click();
		commentBox.sendKeys("Approving the "+batchID+" batchid");
		
		approveButton.click();
		
		if(successMessage.isDisplayed())
		{
			return successMessage.getText();
		}
		else
		{
			return "OOps cards are not succesfully created";
		}
		
		
		
	}
	
	
	
}

package BOB.CMS.Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BOB.utilities.Generics;


public class BasePage 
{
   // public static WebDriver driver;
    public static WebDriver driver;
    
    //*** commonly used web elements
    
    @FindBy(xpath="//iframe[@class='iframe']")
	protected WebElement cmsFrame;
	
	
	@FindBy(xpath="//input[@value='Collapse']")
	protected WebElement collapseLink;
	
	@FindBy(xpath="//span[text()='Card Management']")
	protected WebElement cardManagement;
	
	public void switchToFrame()
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		
	}
    
 }

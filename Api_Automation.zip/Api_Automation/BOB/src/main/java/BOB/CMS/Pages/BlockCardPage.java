package BOB.CMS.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import BOB.utilities.Generics;

public class BlockCardPage extends BasePage
{

	/**
	 * Declaration of all the webElements of Block Card Page
	 */

	@FindBy(linkText="Card Blocking")
	private WebElement cardBlockingLink;
	
	@FindBy(name="iccNumber")
	private WebElement cardNumberField;
	
	@FindBy(id="benefcheck")					// this is for only gift cards
	private WebElement checkBoxForGiftCards;
	
	@FindBy(id="mobile")
	private WebElement mobileNumberField;
	
	@FindBy(name="submit")
	private WebElement submitButton;
	
	@FindBy(name="reason")
	private WebElement reasonList;
	
	@FindBy(name="type")
	private WebElement typeOfBlock;
	
	@FindBy(xpath="//input[@value='Block Card']")
	private WebElement blockButton;

	@FindBy(xpath="//frame[@name='blockedCardConfirm']")
	private WebElement blockFrame;
	
	@FindBy(xpath="//h3[text()='Block Card - Success']")
	private WebElement blockSuccessMessage;
	
	
	/**
	 * Declaration of all the web elements for Card Unblock Page
	 */
	
	@FindBy(linkText="Card Unblocking")
	private WebElement cardUnlbockingLink;
	
	
	@FindBy(xpath="//input[@name='reason']")
	private WebElement userComments;
	
	@FindBy(xpath="//input[@value='Unblock Card']")
	private WebElement unblockButton;
	
	
	/**
	 * Initialization of all the web elements
	 */
	
	public BlockCardPage(WebDriver driver)
	{
		BlockCardPage.driver=driver;
	}
	
	
	/**@author sanmati.vardhaman
	 * This method is used to block the card,base on the type of block provided
	 * @param cardNumber
	 * @param mobileNumber
	 * @param reason
	 * @param blockType
	 * @return
	 */
	public String blockCard(String cardNumber,String mobileNumber,String reason,String blockType)
	{
		switchToFrame();
		Generics.explicitWait(cardBlockingLink,60);
		cardBlockingLink.click();
		driver.switchTo().defaultContent();
		
		//enter the card number to be blocked
		cardNumberField.sendKeys(cardNumber);
		submitButton.click();
		
		//Select the reason for blocking
		Select sel_Reason=new Select(reasonList);
		sel_Reason.selectByValue(reason);
	
		//Select the type of blocking
		Select sel_Type=new Select(typeOfBlock);
		sel_Type.selectByVisibleText(blockType);
		
		blockButton.click();
		driver.switchTo().frame(blockFrame);
		
		String message=blockSuccessMessage.getText();
		return message;
		
	}
	
	public void unBlockCard()
	{
		
	}
}

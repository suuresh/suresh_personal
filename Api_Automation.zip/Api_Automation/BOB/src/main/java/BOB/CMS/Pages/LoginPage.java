package BOB.CMS.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage
{

	/**	
	 *  Declaration of all the web elements
	 *  
	 */
	
	@FindBy(xpath="//input[@name='txtUserId']")
	private WebElement userName;
	
	@FindBy(xpath="//input[@name='txtPassword']")
	private WebElement userPassword;
	
	@FindBy(xpath="//input[@name='submit']")
	private WebElement singInButton;
	
	
	/**
	 *  initialization of the web elements
	 */
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void loginIntoAPPlications(String name,String pwd)
	{
		userName.sendKeys(name);
		userPassword.sendKeys(pwd);
		singInButton.click();
		
	}
	
	
}

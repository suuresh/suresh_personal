package BOB.CMS.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import BOB.utilities.Generics;

public class RechargeRequestPage extends BasePage

{

	/**
	 * 	Declaration of all the web elements for Re-charge request details
	 */
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;
	
	
	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;
	
	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;
	
	@FindBy(linkText="Recharge Request")
	private WebElement rechargeRequestLink;
	
	@FindBy(id="cmbProduct")
	private WebElement productList;
	
	@FindBy(name="iccNumber")
	private WebElement cardNumber;
	
	@FindBy(name="amount")
	private WebElement amountField;
	
	@FindBy(name="submit")
	private WebElement sumbitButton;
	
	@FindBy(id="paymentMode")
	private WebElement paymentMethod;
	
	@FindBy(name="journalNum")
	private WebElement jrNumber;
	
	@FindBy(id="paymentDetails")
	private WebElement payDetails;
	
	@FindBy(xpath="//input[@value='Recharge Card']")
	private WebElement rechargeRequestcardButton;
	
	@FindBy(xpath="//h3[text()='Recharge Request - Success']")
	private WebElement succesMessage;
	
	// ******************** Re-charge card page Web Elements
	
	@FindBy(linkText="Recharge Card")
	private WebElement rechargeCardLink;
	
	@FindBy(name="checkerComments")
	private WebElement cComments;
	
	@FindBy(xpath="//input[@value='Recharge Card']")
	private WebElement rechargeCardButton;
	
	@FindBy(xpath="//input[@value='Cancel Recharge']")
	private WebElement cancelRechargeCardButton;
	
	// ** frame where success message is present
	
	@FindBy(xpath="//frame[@name='rechargeCardConfirm']")
	private WebElement rechargeFrame;
	
	@FindBy(xpath="//h3[text()='Recharge Card - Success']")
	private WebElement rechargeSuccessMessage;
	
	/**
	 * Initializing of  all the web elements during run time
	 * @param driver
	 */
	
	public RechargeRequestPage(WebDriver driver)
	{
		RechargeRequestPage.driver=driver;
	}
	
	
	/**
	 * This method is used to send re-charge request
	 * @param prodName
	 * @param number
	 * @param amount
	 * @param paydetails
	 * @return
	 */
	public String rechargeRequest(String prodName,String number,String amount,String paydetails )
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		Generics.explicitWait(rechargeRequestLink,60);
		rechargeRequestLink.click();
		driver.switchTo().defaultContent();
		
		//select product from the list
		
		Select prod=new Select(productList);
		prod.selectByValue(prodName);
		
		cardNumber.sendKeys(number);
		amountField.sendKeys(amount);
		sumbitButton.click();
		
		//select payment mode from the list
		Select pay=new Select (paymentMethod);
		pay.selectByVisibleText(paydetails);
		payDetails.sendKeys(paydetails);
		jrNumber.sendKeys("JR__"+amount);
		rechargeRequestcardButton.click();
		
		//switch to the alert and accept it
		
		driver.switchTo().alert().accept();
		Generics.explicitWait(succesMessage,60);
		String message=succesMessage.getText();
		return message;
		
	}
	
	/**
	 * This method is to approve the re-charge request
	 * @param last4digit
	 * @return
	 */
	public String rechargeCard(String last4digit)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		cardManagement.click();
		Generics.explicitWait(rechargeCardLink,60);
		rechargeCardLink.click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		cComments.sendKeys("recharging the card with end digits "+last4digit);
		rechargeCardButton.click();
		driver.switchTo().alert().accept();
		//Generics.explicitWait(rechargeSuccessMessage);
		Generics.waitThread();
		driver.switchTo().frame(rechargeFrame);
		
		String message=rechargeSuccessMessage.getText();
		//driver.switchTo().parentFrame();
		return message;
	}
	
}

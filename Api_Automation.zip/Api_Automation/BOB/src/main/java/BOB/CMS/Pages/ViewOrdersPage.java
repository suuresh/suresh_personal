package BOB.CMS.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import BOB.utilities.Generics;

public class ViewOrdersPage extends BasePage
{
	

	/***
	 * Declaration of all the web elements
	 */
	
	
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;
	
	
	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;
	
	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;
	
	@FindBy(linkText="View Orders")
	private WebElement viewOrderLink;
	
	@FindBy(xpath="//input[@name='batchId']")
	private WebElement batch;
	
	@FindBy(name="persoVendorSel")
	private WebElement vendorName;
	
	@FindBy(name="submit")
	private WebElement submitButton;
	
	

	@FindBy(xpath="//u[text()='Pin File']")
	private WebElement pinFileLink;
	
	@FindBy(xpath="//u[contains(text(),'Vendor ')]")
	private WebElement persoFileLink;
	
	/**
	 * initialization of all the web elements
	 */
	public ViewOrdersPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	public void viewOrders(String cardBatchID)
	{
		driver.switchTo().frame(cmsFrame);
		collapseLink.click();
		Generics.waitThread();
		Generics.explicitWait(cardManagement,60);
		cardManagement.click();
		Generics.explicitWait(viewOrderLink,60);
		viewOrderLink.click();
		driver.switchTo().defaultContent();
		Generics.waitThread();
		batch.sendKeys(cardBatchID);
		
		//select the vendor for the select box
		
		Select vendorSelect=new Select(vendorName);
		vendorSelect.selectByVisibleText("DZ");
		submitButton.click();
		
		//Generics.explicitWait(pinFileLink);
		pinFileLink.click();
		driver.switchTo().alert().accept();
		
		persoFileLink.click();
		driver.switchTo().alert().accept();
	}
}

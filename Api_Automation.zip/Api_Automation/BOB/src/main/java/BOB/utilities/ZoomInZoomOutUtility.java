package BOB.utilities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
public class ZoomInZoomOutUtility
{
		/**
		 * This is used for ZoomIN
		 * @param driver
		 */
	
	public static void zoomIN(WebDriver driver)
	{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("document.body.style.zoom='100%'");
	
	}
	
	/**
	 * This method is used to ZoomOut
	 * @param driver
	 */
	public static void zoomOut(WebDriver driver)
	{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("document.body.style.zoom='75%'");
	
	}
}

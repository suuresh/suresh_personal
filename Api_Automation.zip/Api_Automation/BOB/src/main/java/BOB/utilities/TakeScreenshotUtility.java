package BOB.utilities;


import java.io.File;
import java.io.IOException;
//import java.nio.file.Files;
//import java.text.SimpleDateFormat;
import java.util.Calendar;
//import java.util.Date;

import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TakeScreenshotUtility
{
	static Calendar c = Calendar.getInstance();
	
	public static String getScreenshot(String screenshotname,WebDriver driver) 
	{
		TakesScreenshot ts=(TakesScreenshot)driver;
		
		File sourceFile=ts.getScreenshotAs(OutputType.FILE);
		
		//File destFile=new File("D:\\HybdridFrameWork\\com.enstage.hybdridFramework\\Screenshots\\"+dateStamp()+"\\"+screenshotname+"_"+new SimpleDateFormat("MM-dd-yyyy").format(new Date())+".png");
		
		String destPath="E:\\Sanmati\\Automation\\Api_Automation\\BOB\\screenshots\\"+dateStamp()+"\\"+screenshotname+"_"+timeStamp()+".png";
		File destFile=new File(destPath);
		try {
			FileUtils.copyFile(sourceFile, destFile,true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 	destPath;
		
	}
	
	public static String dateStamp()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE);
	}
	
	public static String timeStamp()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE)+"_"+c.get(Calendar.HOUR)+"_"+c.get(Calendar.MINUTE)+"_"+ c.get(Calendar.SECOND);
	}
}

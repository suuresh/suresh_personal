package BOB.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BOB.CMS.Pages.BasePage;

//public class Generics extends BOB.CMS.Pages.BasePage
public class Generics 
{
	public static WebDriverWait wait;
	public static WebElement myElement;
	Properties pro;
	static Date d;
	public static WebDriver driver;
	//public  WebDriver driver;
	
	public String downloadPath="C:\\Users\\sanmati.vardhaman\\Downloads\\";
	public String extenSion=".pdf";
	
	
	
	public Generics()
	{
		File src=new File ("E:\\Sanmati\\Automation\\Api_Automation\\BOB\\Configurations\\config.properties");
		
		try
		{
			FileInputStream fis =new FileInputStream(src);
			
			pro=new Properties();
			pro.load(fis);
		}
		
		catch (IOException e)
		
		{
			System.out.println("error mesage is "+e.getMessage());
		}
		
	}
	
	public static void waitThread()
	{
		try {
			Thread.sleep(3000);
		} 
		catch (Exception e) {
			System.out.println("exception is "+e.getMessage());
		}
	}
	
	
	public static void explicitWait(WebElement element,int timeUnit)
	{
		wait=new WebDriverWait(driver,timeUnit);
		myElement= wait.until(ExpectedConditions.visibilityOf(element));
		
	}
	
	/**
	 * 
	 * @return
	 */
	
	public static void myexplicitWait(WebElement element,int timeUnit)
	{
		wait=new WebDriverWait(driver,timeUnit);
		myElement= wait.until(ExpectedConditions.visibilityOf(element));
		
	}
	

	public String  getAppURL()
	{
		return pro.getProperty("URL");
	}
	
	public String userName()
	{
		return pro.getProperty("UserName");
		
	}
	
	public String userPassword()
	{
		return pro.getProperty("Password");
		
	}
	
	/**
	 * This method is used to get CSR URL
	 * @return
	 */
	
	
	public String  getCSRAppURL()
	{
		return pro.getProperty("csrURL");
	}
	
	/**
	 * This method is used to get csr user name
	 * @return
	 */
	public String csruserName()
	{
		return pro.getProperty("csrUserName");
		
	}
	
	/**
	 * This method is used to get csr user password.
	 * @return
	 */
	
	public String csruserPassword()
	{
		return pro.getProperty("csrPassword");
		
	}
	
	public static String currentDate()
	{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-YYYY");
		LocalDateTime now = LocalDateTime.now();
        //LocalDateTime then = now.minusDays(7);
		LocalDateTime then = now.minusYears(22);
		String todaysDate = then.format(format);
		return todaysDate;
		 
		
	}
	/*public static void main(String[] args)
	{
		String dd=currentDate();
		System.out.println(dd);
	}*/
	
	
	
	public String getPath()
	{
		return pro.getProperty("Filepath");
		
		
	}
	
	/**
	 * This method is use to switch to frame
	 * @param frameId
	 */
	public void switchToFrame(WebElement frameId)
	{
		driver.switchTo().frame(frameId);
			
	}
	
	/**
	 * 
	 */
	
	public void swithWindows(int handle)
	{
		ArrayList<String> myList =new ArrayList<String>(driver.getWindowHandles());
		System.out.println("size of window handle is "+myList.size());
		driver.switchTo().window(myList.get(handle));
	}
	
	/**
	 * 
	 * @param browserName
	 */
	
	/**
	 * This method is used to check whether given file is download in specified file path or not.
	 * @param dirPath
	 * @param ext
	 * @return
	 */
	
	public boolean isFileDownloaded_Ext(){
		boolean flag=false;
	    File dir = new File(downloadPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        flag = false;
	    }
	    
	    for (int i = 1; i < files.length; i++) {
	    	if(files[i].getName().contains(extenSion)) {
	    		flag=true;
	    	}
	    }
	    return flag;
	}
	
	/**
	 * This method is used to get card number from the config files.
	 */
	
	public String getCardNumber()
	{
		return pro.getProperty("cardnumber");
		 
		
	}
}

package BOB.utilities;		//my data provider

import org.testng.annotations.DataProvider;



public class DataProviderUtility
{
		
	
	/**
	 * This data provider is used for passing details required for activating the cards
	 * @return
	 */
	@DataProvider(name="Smoke")
		public static Object[][] getDataforReloadReggression()
		{
		
		
			CopyOfExcelUtility  excelUtility= new CopyOfExcelUtility();
			int rows=excelUtility.getLastRowNum("CreateCards");
			int cols=excelUtility.getColumnCount("CreateCards",1);
			
			System.out.println("number or rows: "+rows+" Number of col: "+cols);
			
			Object [][] obj=new Object[rows-1][cols];
			
			for (int i = 1; i <rows; i++)
			{
				for(int j=0;j<cols;j++)
				{
					obj[i-1][j]=excelUtility.getData("CreateCards", i, j);
				}
			}
			return obj;
					
		}
	
	/**
	 * This data provide is for pass the data required for reload.
	 * @return
	 */
	
	@DataProvider(name="ReloadData")
	public static Object[][] getDataforReload()
	{
		CopyOfExcelUtility  excelUtility= new CopyOfExcelUtility();
		int rows=excelUtility.getLastRowNum("ReloadData");
		int cols=excelUtility.getColumnCount("ReloadData",1);
		
		System.out.println("number or rows: "+rows+" Number of col: "+cols);
		
		Object [][] obj=new Object[rows-1][cols];
		
		for (int i = 1; i <rows; i++)
		{
			for(int j=0;j<cols;j++)
			{
				obj[i-1][j]=excelUtility.getData("ReloadData", i, j);
			}
		}
		return obj;
				
	}
	
	/**
	 * This data provider is to pass data required for activation
	 * @return
	 */
	
	@DataProvider(name="ActivationRequest")
	public static Object[][] getDataforActivation()
	{
		CopyOfExcelUtility  excelUtility= new CopyOfExcelUtility();
		int rows=excelUtility.getLastRowNum("ActivationRequest");
		int cols=excelUtility.getColumnCount("ActivationRequest",1);
		
		System.out.println("number or rows: "+rows+" Number of col: "+cols);
		
		Object [][] obj=new Object[rows-1][cols];
		
		for (int i = 1; i <rows; i++)
		{
			for(int j=0;j<cols;j++)
			{
				obj[i-1][j]=excelUtility.getData("ActivationRequest", i, j);
			}
		}
		return obj;
				
	}
	
	/**
	 * 
	 * @return
	 */
	
	@DataProvider(name="CSRData")
	public static Object[][] getCSRData()
	{
		CopyOfExcelUtility  excelUtility= new CopyOfExcelUtility();
		int rows=excelUtility.getLastRowNum("CSR_EnhanceReports");
		int cols=excelUtility.getColumnCount("CSR_EnhanceReports",1);
		
		System.out.println("number or rows: "+rows+" Number of col: "+cols);
		
		Object [][] obj=new Object[rows-1][cols];
		
		for (int i = 1; i <rows; i++)
		{
			for(int j=0;j<cols;j++)
			{
				obj[i-1][j]=excelUtility.getData("CSR_EnhanceReports", i, j);
			}
		}
		return obj;
				
	}
	
}


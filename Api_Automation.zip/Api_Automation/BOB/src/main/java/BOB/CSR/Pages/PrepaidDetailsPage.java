/**
 * 
 */
package BOB.CSR.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BOB.utilities.Generics;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class PrepaidDetailsPage extends CSRBasePage
{
	//Declaration of all the webElements of Prepaid Details Page
	
	@FindBy(id="txtSearch")
	private WebElement cardNumberId;
	
	@FindBy(id="btnSearch")
	private WebElement goButton;
	
	//search card number link
		
	@FindBy(xpath="//a[contains(@title,'Click')]")
	private WebElement cardNumberLink;
	
	
	//close button in next page
	
	@FindBy(id="cmdDone")
	private WebElement closeButton;
	
	//web Element to get product name and status
	
	@FindBy(xpath="//td[contains(text(),'Product :')]/following-sibling::td/font")
	private WebElement productName;
	
	
	// Initialization of all the web Elements using page factory
	
	public PrepaidDetailsPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	//method to check card status and 
	
	public String checkPrepaidDetails(String cardNumber)
	{
		driver.switchTo().frame(leftFrame);
		//driver.switchTo().frame(leftFrame);
		prepaidDetails.click();
		driver.switchTo().defaultContent();
		cardNumberId.sendKeys(cardNumber);
		goButton.click();
		explicitWait(cardNumberLink, 60);
		//gen.explicitWait(cardNumberLink,60);
		cardNumberLink.click();
		//switch to new window
		swithWindows(1);
		
		String productDetails=productName.getText();
		closeButton.click();
		swithWindows(0);
		
		return productDetails;
			
	}
	
	
			
	

}

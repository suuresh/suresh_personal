/**
 * 
 */
package BOB.CSR.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BOB.utilities.Generics;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class ExpectionHandlingPage extends CSRBasePage
{

	@FindBy(linkText="Process Exception Items")
	private WebElement processExceptionItemsLink;
	
	@FindBy(linkText="Chargeback Billed Items")
	private WebElement chargebackBilledItemsLink;
	
	@FindBy(linkText="Process Chargeback Items")
	private WebElement processChargebackItemsLink;
	
	@FindBy(linkText="Credit Chargeback Amount")
	private WebElement creditChargebackAmountLink;
	
	// ****************below elements are with respective link--------Process exception Items link web element *************
	
	@FindBy(xpath="//iframe[@src='exceptionRecords.jsp']")		//exception frame
	private WebElement exceptionFrame;
	
	@FindBy(xpath="//iframe[@src='exceptionDetailRecord.jsp']")
	private WebElement insideExceptionFrame;
	
	@FindBy(id="searchOptions")
	private WebElement selectType;
	
	@FindBy(id="iccNumber")					//Card number field
	private WebElement cardNumber;
	
	@FindBy(id="cardUnion")					//Card union
	private WebElement cardUnion;	
		
	@FindBy(id="productId")					//Product Name
	private WebElement productName;
	
	@FindBy(id="binNumber")					//Bin Number
	private WebElement binNumber;
	
	@FindBy(xpath="//input[@value='Search']")
	private WebElement searchButton;
	
	@FindBy(xpath="//font[@class='text1']")
	private WebElement successMessage;
	
	
	//@FindBy(xpath="//a[@href='../ExceptionHandlingServer?perform=exceptionDetails&amp;EPF_TXN_ID=16888&amp;ICC_NUMBER=g9ktvvFkarGu76lNn0G8W1FDQJmMg86E']")
	//private WebElement exceptionNumber;
	
	@FindBy(xpath="//u[text()='1']")
	private WebElement exceptionNumber;
	
	@FindBy(id="cboDestination")			//destination select dropDown.
	private WebElement destinationAction;
	
	@FindBy(name="txtMsg")					//message text box.
	private WebElement messageTextBox;
	
	@FindBy(name="Submit")
	private WebElement submitButton;
	
	
	//***********Charge back Billed Items ********************
	
	@FindBy(xpath="//iframe[@src='billedRecords.jsp']")
	private WebElement chargebackBilledRecordsFrame;
	
	
	@FindBy(xpath="//input[@name='txtCCNumber']")
	private WebElement cardNumberField;
	
	@FindBy(xpath="//input[@value='Go']")
	private WebElement goButton;
	

	//***********Credit Chargeback Amount*********************
	@FindBy(id="searchOptions")
	private WebElement creditSearchOption;
	
	@FindBy(id="iccNumber")
	private WebElement creditChargebacCardNumber;
	
	@FindBy(xpath="//a[@href='/csr/accosa/updateChargeBackInfo.jsp?value=16545']")
	private WebElement transactionID;
	
	
	@FindBy(xpath="//input[@value='Reverse']")
	private WebElement reverseButton;
	
	@FindBy(xpath="//input[name='abort']")
	private WebElement abortButton;
	
	/**
	 * initialization of all the web elements
	 * @param driver
	 */
	
	public ExpectionHandlingPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	/**
	 * Utilization of all the web elements .
	 * @param cardNo
	 */
	public void processExceptionItems(String cardNo)
	{
		//accosaLink.click();
		try {
			driver.switchTo().frame(leftFrame);
			processExceptionItemsLink.click();
			driver.switchTo().defaultContent();
			productSelection(selectType,"Card Number");	//select card number option from the drop down.
			cardNumber.sendKeys(cardNo);
			searchButton.click();
			Generics.waitThread();
			driver.switchTo().frame(exceptionFrame);
			exceptionNumber.click();
			driver.switchTo().frame(insideExceptionFrame);
			scrollDown();								//scroll down to bottom of page.
			productSelection(destinationAction,"Accept");	//select accept option from the drop down.
			messageTextBox.sendKeys("accepting the exception");
			submitButton.click();
			driver.switchTo().alert().accept();
			explicitWait(successMessage,3000);
			//driver.switchTo().parentFrame();
			if(successMessage.getText().contains("The record has been successfully updated"))
			{
				System.out.println("exception is successfully cleared");
			}
			else
			{
				System.out.println("something went wrong");
			}
			driver.switchTo().defaultContent();
		} 
		catch (Exception e)
		{
			driver.switchTo().defaultContent();
			System.out.println("some exception occured");
		}
	}
	
	
}

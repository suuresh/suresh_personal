/**
 * 
 */
package BOB.CSR.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class ProcessBlockedcardPage extends CSRBasePage
{

	@FindBy(xpath="//u[contains(text(),'View All Blocked Cards')]")
	private  WebElement viewAllBlockedCardsLink;
	
	@FindBy(id="txtSearch")
	private WebElement cardNumberField;
	
	@FindBy(id="btnSearch")
	private WebElement goButton;
	
	@FindBy(xpath="//u[contains(.,'Process')]")
	private WebElement processLink;
	
	//-------------below fields are for unblocking the cards which are blocked due to incorrect pin attempts at customer portal---
	
	@FindBy(name="txtDescription")
	private WebElement descriptionField;
	
	@FindBy(name="txtStatus")
	private WebElement statusSelectBox;
	
	
	@FindBy(name="txtTextArea")
	private WebElement commentsBox;
	
	@FindBy(xpath="//input[@value='Back']")
	private WebElement backButton;
	
	@FindBy(xpath="//input[@value='Save']")
	private WebElement saveButton;
	
	
	
	
	
}

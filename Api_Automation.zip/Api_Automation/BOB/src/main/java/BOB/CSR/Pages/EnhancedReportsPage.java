/**
 * 
 */
package BOB.CSR.Pages;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import BOB.utilities.Generics;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class EnhancedReportsPage extends CSRBasePage
{
	// declaration of all the web Elements 
	
	@FindBy(xpath="//a[contains(@href,'62')]")			// this web element is for Activation Report Link
	private WebElement cardAcativationReportLink;
	
	@FindBy(xpath="//a[contains(@href,'64')]")			// this web element is for Recharge Report Link;
	private WebElement cardRechargeReportLink;
	
	@FindBy(xpath="//strong[contains(text(),'Card Cancellation Report by Program/Branch')]")		//this is for Cancellation Report Link
	private WebElement cardCancellationReportLink;
	
	@FindBy(xpath="//strong[contains(text(),'Authorization Report')]")		//this is for Authorization Report Link.
	private WebElement authorisationReportLink;
	
	@FindBy(xpath="//strong[contains(text(),'5.  Settlements Report by Program/Branch ')]")		//this is for Settlement Report Link.
	private WebElement settlementReportLink;
	
	@FindBy(xpath="//strong[contains(text(),'7.  Blocked Card Report ')]")
	private WebElement blockedReportLink;
	
	@FindBy(xpath="//strong[contains(text(),'9.  Card Enquiry Report ')]")
	private WebElement cardInquiryReportLink;
	
	
	
	//***********************************************************************
	
	@FindBy(xpath="//iframe[contains(@src,'BMW_ProductActivationReport_M.rptdesign')]")
	private WebElement actreportFrame;
			
	@FindBy(xpath="//iframe[contains(@src,'Prg_ProductCancelationReport')]")
	private WebElement cancelReportFrame;
	
	@FindBy(xpath="//iframe[contains(@src,'BMW_ProductRechargeReport_M.rptdesign')]")
	private WebElement recReportFrame;
	
	@FindBy(xpath="//iframe[contains(@src,'BMW_ProductAuthReceivedReport')]")
	private WebElement authReportFrame;
	
	@FindBy(xpath="//iframe[contains(@src,'Prg_mw_ProductSettlements')]")
	private WebElement settReportFrame;
	
	@FindBy(xpath="//iframe[contains(@src,'ProductBlockUnblockReport')]")
	private WebElement blockedReportFrame;
	
	@FindBy(xpath="//iframe[contains(@src,'mw_cardenquirydetailreport')]")
	private WebElement cardInquiryFrame;
	
	
	
	@FindBy(id="Product_selection")
	private WebElement productType;
	
	@FindBy(id="Card_type_selection")
	private WebElement productName;
	
	//******************These data elements are exclusively for settlement report ********
	@FindBy(xpath="//select[@class='birtviewer_parameter_dialog_Select']")
	private WebElement _settlementProductType;
	
	@FindBy(id="ProgramProduct_selection")
	private WebElement _settlementProductList;
	
	@FindBy(id="SettlementType_selection")
	private WebElement _settByDateType;
	
	@FindBy(id="Bin_selection")
	private WebElement _settBinSelection;
	
	
	
	//*********************These data elements are exclusively for cancellation ******************
	
	@FindBy(id="TypeofProgramProduct_selection")	//only for cancellation
	private WebElement _cancelProductType;
	
	@FindBy(id="ProgramProduct_selection")
	private WebElement _cancelProductList;
	
	@FindBy(id="Branch_selection")	//only for cancellation
	private WebElement _cancelbranchName;
	
	//********************These data elemetns are exclusively for card inquiry report*************
	
	@FindBy(id="By_selection")
	private WebElement cardInquirySelect;
	
	@FindBy(id="cardNumber")
	private WebElement urn_CardNumber_dataTextBox;
	
	
	//****************---------------------********************************************************
			
	//parameterDialogokButton
	
	@FindBy(id="parameterDialogokButton")
	private WebElement okButton;
	
	@FindBy(xpath="//input[@value='Cancel']")
	private WebElement cancelButton;
	
	@FindBy(xpath="//div[contains(text(),'GPR Card')]")
	private WebElement gprCardText;
	
	@FindBy(xpath="//div[contains(text(),'CARD ACTIVATION REPORT')]")
	private WebElement cardActivationText;
	
	
	@FindBy(name="exportReport")
	private WebElement exportReport;
	
	//dialogue box
	
	@FindBy(id="exportReportDialog")
	private WebElement dialogueBox;
	
	@FindBy(id="exportReportDialogokButton")
	private WebElement dialogueBoxButton;
	
	//format for downloading type of file
	
	@FindBy(id="exportFormat")
	private WebElement typeFormat;
	
	//progress bar
	
	@FindBy(xpath="//table[@class='birtviewer_progressbar']")
	private WebElement progressBar;
	
	
	
	//Initialization of all the web elements
	
	public EnhancedReportsPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	/**
	 * 
	 */
	
	public void csrReports(String reportName,String ProductName,String frDate,String trDate,String fileType)
	{
		
		driver.switchTo().frame(leftFrame);
		enhacedReports.click();
		driver.switchTo().defaultContent();
		//Generics.explicitWait(cardAcativationReportLink, 20);
		Generics.waitThread();
		//click on the link
		
		switch(reportName)
		{
		
		case "Activation":
			cardAcativationReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(actreportFrame);
			break;
		
		case "Recharge":
			cardRechargeReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(recReportFrame);
			break;
			
		case "Cancellation":
			cardCancellationReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(cancelReportFrame);
			
			break;
			
		case "Authorisation":
			authorisationReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(authReportFrame);
			break;
			
		case "Settlement":
			settlementReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(settReportFrame);
			break;
			
		case "BlockCard":
			blockedReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(blockedReportFrame);
			break;
			
		case "CardInquiry":
			cardInquiryReportLink.click();
			Generics.waitThread();
			driver.switchTo().frame(cardInquiryFrame);
			break;
		
				
			
		default:
			System.out.println("invalid report name");
			
		
		}
		
		if(reportName.equalsIgnoreCase("cancellation"))
		{
			productSelection(_cancelProductType,"Product");
			productSelection(_cancelProductList, ProductName);
			productSelection(_cancelbranchName,"ALL");
			enterFromToDate(frDate,trDate);
			
		}
		else if(reportName.equalsIgnoreCase("authorisation"))
		{
			enterFromToDate(frDate,trDate);
			productSelection(productType, ProductName);
			
		}
		else if(reportName.equalsIgnoreCase("settlement"))
		{
			productSelection(_settlementProductType,"Product");
			productSelection(_settlementProductList,ProductName);
			productSelection(_settByDateType, "By Processing Date");
			enterFromToDate(frDate,trDate);			
		}
		else if (reportName.equalsIgnoreCase("blockcard"))
		{
			enterFromToDate(frDate,trDate);
			productSelection(productType, ProductName);
		}
		else if(reportName.equalsIgnoreCase("cardinquiry"))
		{
			String cardNumber=gen.getCardNumber();
			productSelection(cardInquirySelect, "Clear Card Number"); //here prodcut nam
			urn_CardNumber_dataTextBox.sendKeys(cardNumber);
		}
		else
		{
			enterFromToDate(frDate,trDate);
			productSelection(productType,"Single Wallet Product");	//method to call type of product(Single wallet,multiwallet)
			productSelection(productName,ProductName);	//method to call selection of product from the drop down list
		}
		
		Generics.waitThread();
		okButton.click();
		explicitWait(gprCardText,3000);
		//Assert.assertTrue(cardActivationText.isDisplayed(),"Report name is incorrect hence terminating");
		Generics.waitThread();
		exportReport.click();
		Generics.waitThread();
		dialogueBox.click();
		Generics.waitThread();
		productSelection(typeFormat,fileType);		//method to select type of file to download(pdf,excel) from the type list.
		dialogueBoxButton.click();
		Generics.waitThread();
		Assert.assertTrue(gen.isFileDownloaded_Ext(), "Failed to download document which has extension .xls");
		System.out.println("Successfully asserted the downloaded file");
		driver.switchTo().defaultContent();
				
	}

}

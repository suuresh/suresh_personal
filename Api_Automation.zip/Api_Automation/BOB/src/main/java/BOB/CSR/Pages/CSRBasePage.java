/**
 * 
 */
package BOB.CSR.Pages;

import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import BOB.utilities.Generics;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class CSRBasePage 
{
	Generics gen=new Generics();
	
	public WebDriver driver;
	
			
	@FindBy(linkText="/csr/accosa/Accosa.jsp")
	public WebElement accosaLink;
	
	//left Frame
	
	@FindBy(xpath="//iframe[@src='leftmenu.jsp']")
	public WebElement leftFrame;
	
	@FindBy(xpath="//a[text()='Prepaid Details']")
	protected WebElement prepaidDetails;
	
	@FindBy(xpath="//a[text()='Download Statement']")
	private WebElement downloadStatement;
	
	@FindBy(xpath="//a[text()='Enhanced Report']")
	protected WebElement enhacedReports;
	
	@FindBy(xpath="//a[text()='Exception Handling']")
	private WebElement exceptionHandling;
	
	@FindBy(xpath="//a[text()='Process Exception Items']")
	private WebElement processExceptionItems;
	
	@FindBy(xpath="//a[text()='Chargeback Billed Items']")
	private WebElement chargebackBilledItems;
	
	@FindBy(xpath="//a[text()='Process Chargeback Items']")
	private WebElement processChargebackItems;
	
	@FindBy(xpath="//a[text()='Credit Chargeback Amount']")
	private WebElement creditChargebackAmount;
	
	@FindBy(xpath="//a[text()='Process Blocked Cards']")
	private WebElement processBlockedCards;
	
	@FindBy(xpath="//a[text()='Process By Card Number']")
	private WebElement processByCardNumber;
		
	@FindBy(id="FromDate")
	private WebElement fromDate;
	
	@FindBy(id="ToDate")
	private WebElement toDate;
	
	
	public void explicitWait(WebElement element,int timeUnit)
	{
		WebDriverWait wait=new WebDriverWait(driver,timeUnit);
		wait.until(ExpectedConditions.visibilityOf(element));
		
	}
	
	/**
	 * This method is used to enter from and to date
	 * @param fDate
	 * @param tDate
	 */
	public void enterFromToDate(String fDate,String tDate)
	{
		fromDate.sendKeys(fDate);
		toDate.sendKeys(tDate);
	}
	
	/**
	 * This method take two parameter, one is Webelement of ProductdropDown list, Second is name of the product.
	 * @param _prodName
	 * @param productName
	 */
	public void  productSelection(WebElement _prodName,String productName)
	{
		Select product=new Select(_prodName);
		product.selectByVisibleText(productName);
	}

	/**
	 * 
	 * @param handle
	 */
	
	public void swithWindows(int handle)
	{
		ArrayList<String> myList =new ArrayList<String>(driver.getWindowHandles());
		System.out.println("size of window handle is "+myList.size());
		driver.switchTo().window(myList.get(handle));
	}
	
	public void scrollDown()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}
}

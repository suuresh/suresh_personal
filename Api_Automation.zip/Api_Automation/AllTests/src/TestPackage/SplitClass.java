package TestPackage;

public class SplitClass 
{
	public static void main(String[] args)
	{
		ExcelUtility excel=new ExcelUtility();
		
		
		excel.dataFromExcel("CardHolderDetails",1);
		
	}

}

package TestPackage;

public class WriteDatatoExcel
{

	public static void main(String[] args)
	{
		for (int i=0;i<5;i++)
		{
			
		ExcelUtility.writeDataToExcel("CardHolderDetails", "sanmati"+"_"+i,"Vardhaman"+"_"+i);
		
		}
		
	}
}

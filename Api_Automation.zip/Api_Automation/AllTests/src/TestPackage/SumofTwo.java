package TestPackage;



import org.testng.Assert;
import org.testng.annotations.Test;

public class SumofTwo
{

	@Test()
	
	public void addition()
	{
		
		int sum=Addtion.addtionTwo(5,10);
		System.out.println(sum);
		
		Assert.assertEquals(15,sum);
		System.out.println(" addtion is validated and successful");
		
	}
}

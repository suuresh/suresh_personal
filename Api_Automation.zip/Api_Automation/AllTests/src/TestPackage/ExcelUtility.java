package TestPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtility 
{
	DataFormatter formater;

	public static void writeDataToExcel(String sheetName,String fname,String lname )
	{
		try {
			FileInputStream fis=new FileInputStream("./Data/ExcelData.xls");
			Workbook wb=WorkbookFactory.create(fis);
			Sheet sName=wb.getSheet(sheetName);
			
			int lastrowNum=sName.getLastRowNum();
			Row r=sName.createRow(++lastrowNum);
			Cell c=r.createCell(0, CellType.STRING);
			c.setCellValue(fname);
			
			c=r.createCell(1, CellType.STRING);
			c.setCellValue(lname);
			
			System.out.println("writing in row "+lastrowNum+ " is successfull");
		
			FileOutputStream fos=new FileOutputStream("./Data/ExcelData.xls");
			wb.write(fos);
			fos.flush();
			wb.close();
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
	}
	
	public void dataFromExcel(String sheetName,int rowNum)
	{
		
		try
		{
			FileInputStream fis=new FileInputStream("./Data/ExcelData.xls");
			Workbook wb=WorkbookFactory.create(fis);
			Sheet sName=wb.getSheet(sheetName);
			Row r=sName.getRow(rowNum);
			String data = r.getCell(0).getStringCellValue();
			
			String [] arr=data.split(",");
			System.out.println(arr.length);
			
			for(String value:arr)
			{
			
				System.out.println(value);
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

package TestPackage;

import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;

public class DataproviderClass
{

	@DataProvider(name="loginLogount")
	public  static Object[][] getCredentials()
	{
		Object[][] obj =new Object [][]
				{ {"pmaker","password50","Bad Username or Password"},
					{"pmaker","password70","Help"}
				
				} ;
		
		return obj;
				
		}
	
}
	


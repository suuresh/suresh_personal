package TestPackage;

public class Addtion
{

	public static int addtionTwo(int x,int y)
	
	{
	  return x+y;	
	}
}

package TestPackage;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestMethod 
{

	WebDriver driver;
	
	@BeforeClass(alwaysRun=true)
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://192.168.105.50:9898/prepaid/cms/index.jsp");
		
	}
	
		
	
	@Test(dataProvider="loginLogount",dataProviderClass=DataproviderClass.class)
	public void credentials(String uName,String pass,String expected) throws Exception
	{
		System.out.println("username is "+uName+ " password is "+pass);
		driver.findElement(By.xpath("//input[@name='txtUserId']")).sendKeys(uName);
		driver.findElement(By.xpath("//input[@name='txtPassword']")).sendKeys(pass);
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		Thread.sleep(3000);
		
		String text = driver.findElement(By.xpath("//b")).getText();
		System.out.println(text);
		
		
			
		
		
		if (text!=null) {
			Assert.assertEquals(text,expected);
		}
		else
		{
			//String helpText
		}
		
		
	}
	
	
	
	
	
	@AfterClass(alwaysRun=true)
	public void tearDown()
	{
		driver.quit();
	}
}

/**
 * 
 */
package collectionPackage;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class EmployeeClass 
{
	
	String name;
	String dept;
	int empID;
	
	//create a constructor to add values to global variables.
	
	public EmployeeClass(String name,String dept,int empID)
	{
		this.name=name;
		this.dept=dept;
		this.empID=empID; 	//this key word is used to refer current class variables.
	}

}

/**
 * 
 */
package collectionPackage;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class HashCollectionObject 
{

	public static void main(String[] args) 
	{
		
		//create hashamap of empolyee class
		
		HashMap<Integer,EmployeeClass> mp=new HashMap<Integer,EmployeeClass>();
		
		//create an objects of Employee class
		EmployeeClass el=new EmployeeClass("Sunny","QA",5);
		EmployeeClass e2=new EmployeeClass("Arun","Dev",6);
		EmployeeClass e3=new EmployeeClass("Sandy","Admin",7);
		
		//adding employee class objects to hashmap
		
		mp.put(1, el);
		mp.put(2, e2);
		mp.put(3, e3);
		
		System.out.println("size of my hashmap is "+mp.size());
		
		for (Entry<Integer,EmployeeClass> m:mp.entrySet())
		{
			Integer mykey = m.getKey();
			EmployeeClass myValue = m.getValue();
			
			System.out.println("Key is "+mykey);
			System.out.println("values are name :"+myValue.name+ " dept :"+myValue.dept+" emp id:"+myValue.empID);
			
			
		}
		
		
		
		
	}
}

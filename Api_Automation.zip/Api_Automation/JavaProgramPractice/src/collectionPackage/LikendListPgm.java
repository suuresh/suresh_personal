/**
 * 
 */
package collectionPackage;

import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class LikendListPgm 
{
	/**
	 * Linked list is dynamic in nature.
	 * it maintain insertion order
	 * its fast as compare to array list.
	 * its non synchornised
	 * its dynamic in nature
	 * its faster than arraylist , as there is no much shifting of elements.
	 * @param args
	 */

	public static void main(String[] args)
	{
		
		LinkedList<String>myList=new LinkedList<String>();
		
		//adding data to list
		
		myList.add("sanmati");
		myList.add("Gouri");
		myList.add("Navya");
		
		//size of linkedList
		
		int myListSize=myList.size();
		
		System.out.println("Size of linkedList is "+myListSize);
		//add fist and add last
		myList.addFirst("Vardhaman");
		myList.addLast("family");
		
		System.out.println("Size of linkedList after adding elements is "+myList.size());
		System.out.println();
		//iterating the list using for loop
		
		for(int i=0;i<myList.size();i++)
		{
			
			System.out.println("values in list are "+myList.get(i));
		}
		
		//***************************
		System.out.println();
		System.out.println("using for each loop");
		
		for(String value:myList)
		{
			System.out.println(value);
		}
		 
		System.out.println();
		System.out.println("---------using iterator");
		
		Iterator<String> it = myList.iterator();
		while(it.hasNext())
		{
			String x=it.next();
			System.out.println(x);
		}
		
		System.out.println();
		System.out.println("---------using while loop");
		
		int num=0;
		
		while(myList.size()>num)
		{
			System.out.println(myList.get(num));
			num++;
		}
		
		//removing data from the list
		
		myList.removeFirst();
		myList.removeLast();
		myList.set(0,"edited from sanmati");
		System.out.println(myList.size());
		
		for(String value:myList)
		{
			System.out.println(value);
		}
		
		///customised linkedList 
		
		LinkedList<EmployeeClass> emp=new LinkedList<EmployeeClass>();
		
		//create object of employee class
		EmployeeClass el=new EmployeeClass("Yon","QA",1212);
		EmployeeClass e2=new EmployeeClass("Jun","Dev",1217);
		EmployeeClass e3=new EmployeeClass("Kim moon","Admin",1218);
		
		//add list of employeed to linkedList
		
		emp.add(el);
		emp.add(e2);
		emp.add(e3);
		
		System.out.println("size of emp list is "+emp.size());
		
		System.out.println("------*********---------");
		//use for each loop to iterate
		
		for(EmployeeClass ex:emp)
		{
			System.out.println("name "+ex.name);
			System.out.println("dep "+ex.dept);
			System.out.println("emp id "+ex.empID);
			System.out.println("----------");
			
		}
		
		
		
	}
}

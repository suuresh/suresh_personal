package collectionPackage;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class CollectionPrograms
{

	/*	ArrayList- its dynamic in nature.
	 * it allows duplicate values
	 * it maintains insertion order.
	 * its not synchronized. its thread safe
	 * It provide random access, we can access any element randomly using indexes.
	 * it slow in nature.
	 * 
	 */
	public static void arrayListProgram()
	{
		
		ArrayList al=new ArrayList();
		
		//to add data in aray list use add method
		
		al.add("sanmati");
		al.add('c');
		al.add(15);
		al.add(12.35);
		
		System.out.println("size of array list is "+al.size());
		
		al.add("new element");
		System.out.println("size of array list after adding new item "+al.size());
		
		//how to print data from the array list
		
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
	}
	
	public static void main(String[] args) {
		arrayListProgram();
	}
}

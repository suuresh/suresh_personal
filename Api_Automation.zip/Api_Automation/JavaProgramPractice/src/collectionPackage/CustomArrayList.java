/**
 * 
 */
package collectionPackage;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class CustomArrayList
{

	public static void main(String[] args)
	{
	
		//create three objects of Employee table
		
		EmployeeClass e1=new EmployeeClass("Sanmati", "Prepaid",122);
		EmployeeClass e2=new EmployeeClass("Sanjeev", "Prepaid",555);
		EmployeeClass e3=new EmployeeClass("Swathi", "Prepaid",565);
		
		//Create and ArrayList of employee
		
		ArrayList<EmployeeClass> myAl=new ArrayList<EmployeeClass>();
		myAl.add(e1);
		myAl.add(e2);
		myAl.add(e3);
		
		System.out.println("size of employeeClass ArrayList is "+myAl.size());
		
		//how to read data from custom ArrayList, make use of Iterator
		
		Iterator<EmployeeClass> it = myAl.iterator();
		
		//iterate through it
		
		while(it.hasNext())
		{
			EmployeeClass val = it.next();
			
			System.out.println(val.name);
			System.out.println(val.empID);
			System.out.println(val.dept);
			System.out.println("----------------------------------");
		}
		
		
	}
}

/**
 * 
 */
package collectionPackage;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class HashCollection 
{
	public static void main(String args[])
	{
		
		
		/**
		 * HashMap -is one of the collection framework which implements map interface and extends Abstract map
		 * Hashmap-contain unique values.
		 * it doesn't maintain insertion order.
		 * data is store in the form of key value pair
		 * its synchronized, its not threads afe. 
		 * its fast in nature
		 * it can have on null key and multiple null values.
		 * its prone to fail fast condition and Concurrent modification exception
		 * 
		 */
		
		
		HashMap<Integer,String>myMap=new HashMap<Integer,String>();
		
		//add data to map using PUT
		
		myMap.put(1,"Sanmati");
		myMap.put(2,"QA");
		myMap.put(3,"Indi");
		
		//size of map
		System.out.println("my map size is "+myMap.size());
		myMap.put(4,null);
		System.out.println("my map size is "+myMap.size());
		
		System.out.println(myMap.get(1));
		
		//how to iterate hashmap
		
		for(Entry<Integer,String> m:myMap.entrySet())
		{
			System.out.println(m.getKey()+" value is "+m.getValue());
		}
		
	}

}

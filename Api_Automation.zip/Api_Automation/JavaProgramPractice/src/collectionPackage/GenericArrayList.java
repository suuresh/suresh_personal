/**
 * 
 */
package collectionPackage;

import java.util.ArrayList;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class GenericArrayList
{
	/*	ArrayList is dynamic in nature
	 *  it accepts duplication
	 *  it maintains insertion order.
	 *  it allow random access of any data by using index.
	 *  its not synchronised.
	 * 
	 */
	
	public static void main(String[] args)
	{
	
		//create generic array list which takes only String value
		
		ArrayList<String> al=new ArrayList<String>();
		
		al.add("Sanmati");
		al.add("Sanjeev");
		al.add("Swathi");
		al.add("Sambit");
		al.add("Madhu");
		
		System.out.println("Size of string arrayList is "+al.size());
		
		for ( int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		//merging two array list using addAll
		
		ArrayList<String> a2=new ArrayList<String>();
		a2.add("PG");
		a2.add("Prepaid");
		a2.add("Retail");
		a2.add("Sanmati");
		
		System.out.println("---------*******----------------------");
		System.out.println("Size of string arrayList is "+a2.size());
		
		for ( int j=0;j<a2.size();j++)
		{
			System.out.println(a2.get(j));
		}
		
		// merging of two arraylist using add all
		
		/*al.addAll(a2);
		System.out.println("---------*******----------------------");
		System.out.println("Size of string arrayList after merging is "+al.size());
		/*al.removeAll(a2);
		System.out.println("---------*******----------------------");
		System.out.println("Size of string arrayList after removing is "+al.size());*/
		
		al.retainAll(a2);
		System.out.println("---------*******----------------------");
		System.out.println("Size of string arrayList after retaining is "+al.size());
		System.out.println(al.get(0));
	}

}

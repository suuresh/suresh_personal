package javaP;

public class NumberOfOccurance
{

	public static void main(String[] args) {
		
		String s="i am a new comer to seleiumaaaaaaa";
		
		char c='a';
		
		int numOfOccurance=s.length()-s.replace("a","").length();
		System.out.println(numOfOccurance);
	}
	
}

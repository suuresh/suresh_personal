/**
 * 
 */
package javaP;

import java.util.Arrays;

/**
 * @author ${Sanmati Vardhaman}
 *
 */
public class Anagrams
{

	/**
	 * Two string are called anagram ,if two string have same set of characters but in different order
	 * 
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		String s1="School master";
		String s2="The Plassroom";
		
		boolean status=false;
		
		//first check if legnth of two string is same
		
		if(s1.length()!=s2.length())
		{
			System.out.println("length of two string is not equal to each other");
			status=false;
		}
		//replaceAll("\\s","")
		else
		{
			char []c1=s1.trim().toLowerCase().toCharArray();
			char []c2=s2.trim().toLowerCase().toCharArray();
			
			//sort these two using arrays
			
			Arrays.sort(c1);
			Arrays.sort(c2);
			
			//check if both are equal
			
			status=Arrays.equals(c1, c2);
			
		}
		
		if(status)
		{
			System.out.println("both are aanagram");
		}
		
		else
		{
			System.out.println("both are not aanagram");
		}
			
		
	}


	
	
}

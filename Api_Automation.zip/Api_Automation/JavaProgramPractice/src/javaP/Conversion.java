package javaP;

public class Conversion 
{
	
	public static void main(String[] args)
	{
	
		String s="12121212";
		
		int x=Integer.valueOf(s);
		System.out.println(++x);
		
		
		int s1=12121212;
		
		String x1=String.valueOf(s1);
		System.out.println(x1);
		
		
		System.out.println(6%10);
		
	}

}

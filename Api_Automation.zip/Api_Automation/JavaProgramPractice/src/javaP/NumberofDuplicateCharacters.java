package javaP;

import java.util.HashMap;
import java.util.Set;

public class NumberofDuplicateCharacters
{
	
	public static void main(String[] args)
	{
		String sunny="i am new to a seleinum auto mation";
		
		char[] carray=sunny.toCharArray();
		
		//create and hashmap
		
		HashMap<Character,Integer> cmap=new HashMap<Character,Integer>();
		
		 for(char c:carray)
		 {
			 if(cmap.containsKey(c))
			 {
				 cmap.put(c, cmap.get(c)+1);
			 }
			 else
			 {
				 cmap.put(c,1);
			 }
		 }
		
		 System.out.println(cmap);
		 
		 //use set for iteration
		 
		 Set<Character> myset=cmap.keySet();
		 
		 for(char x:myset)
		 {
			 if(cmap.get(x)>1)
			 {
				 System.out.println(x + "---->"+cmap.get(x));
			 }
		 }
	}

}

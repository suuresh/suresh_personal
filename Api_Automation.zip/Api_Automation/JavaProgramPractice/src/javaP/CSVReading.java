package javaP;

import java.io.BufferedReader;
import java.io.FileReader;

public class CSVReading 
{

	public static void main(String[] args)
	{
		String filePath="F:\\sunny.txt";
		BufferedReader b=null;
		String spiltBy=",";
		String line="";
		
		
		try
		{
			b=new BufferedReader(new FileReader(filePath));
			
			while((line=b.readLine())!=null)
			{
				String []words=line.split(spiltBy);
				System.out.println(words[1] +"---"+words[2]);
			}
			
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}
}

package javaP;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class NumberOfDuplicatesWords
{
	
	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		
		String newString=sc.nextLine();
		
		String []words=newString.split(" ");
		
		int lenthOfArray=words.length;
		System.out.println("length of any array is "+lenthOfArray);
		
		HashMap<String,Integer> myMap=new HashMap<String,Integer>();
		
		for(String myString:words)
		{
			
			if(myMap.containsKey(myString.toLowerCase()))
					{
				
					myMap.put(myString.toLowerCase(), myMap.get(myString.toLowerCase())+1);
				
					}
			
			else
			{
				myMap.put(myString.toLowerCase(),1);
			}
		}
		
		//System.out.println(myMap);
		
		//iterator through Set
		
		Set<String>myset =myMap.keySet();
		
		for(String s:myset)
		{
			if(myMap.get(s)>1)
			{
				System.out.println(s+"  :"+myMap.get(s) );
			}
		}
		
	}

}

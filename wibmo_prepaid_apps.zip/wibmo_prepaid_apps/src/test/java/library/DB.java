package library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Prepaid.testScripts.BaseTest1;
import org.testng.Assert;

/**
 * The Class DB contains all static methods pertaining to DB Interactions
 * 
 *
 */
public class DB {
	public static String DB_URL = Generic.getPropValues("DB_URL");

	private static String DB_USER;
	private static String DB_PWD;

	private static Connection conn;
	private static Statement stmt;

	private boolean DBflag = true;

	/**
	 * Opens a DB connection statement. Singleton class.
	 * 
	 * @return Connection Statement
	 * @see result()
	 */
	public static Statement stmt() {
		DB_USER = ExcelLibrary.getExcelData(BaseTest1.configXLPath, "Database_Configuration", 1, 1); // Generic.getPropValues("DB_USER",
																										// Prepaid.testScripts.BaseTest1.configPath);
		DB_PWD = ExcelLibrary.getExcelData(BaseTest1.configXLPath, "Database_Configuration", 1, 2); // Generic.getPropValues("DB_PWD",
																									// Prepaid.testScripts.BaseTest1.configPath);

		try {
			System.out.println("Connecting to DB as " + DB_USER + ' ' + DB_PWD);
			if (stmt!= null)
				return stmt;
			else {
				return (conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD)).createStatement();
			}

		} catch (SQLException s) {
			closeDB();
			Assert.fail("Error connecting to DB \n" + s.getSQLState());
			s.printStackTrace();
		}
		return stmt;
	}
//changing to public access
	public static ResultSet result(String query) {
		try {
			return stmt().executeQuery(query);
		} catch (SQLException s) {
			Assert.fail("Unable to Execute Query : " + query + '\n' + s.getSQLState());
			return null;
		}
	}

	public static void executeQuery(String query) {
		try {
			Log.info("==== Executing Update Query : " + query + " ====");
			stmt().executeUpdate(query);
		} catch (SQLException s) {
			Assert.fail("Unable to Execute Query : " + query + '\n' + s.getSQLState());
			s.printStackTrace();
		}
	}

	/**
	 * Closes the current ResultSet. To be used under the corresponding method
	 * 
	 * @param result
	 */
	private static void close(ResultSet result) {
		if (result != null)
			try {
				result.close();
			} catch (SQLException e) {
				System.err.println("Warning : Error Closing ResultSet ");
				e.printStackTrace();
			}
	}

	/**
	 * Closes the DB connection. To be used under @AfterSuite
	 * 
	 * @see close(ResultSet)
	 */
	public static void closeDB() {
		try {

			if (conn != null && !conn.isClosed()) {
				System.out.println("Closing DB Connection  " + conn.getCatalog());
				conn.close();
			}
			if (stmt != null && !stmt.isClosed()) {
				System.out.println("Closing DB Statement ");
				stmt.close();
			}
			conn = null;
			stmt = null;
		} catch (Exception e) {
			System.err.println("Warning : Error closing DB Connection");
			e.printStackTrace();
		}
	}

//=====================================================================================================================================================================//
	/**
	 * Returns claim code from the DB Can be overloaded to include TXN_ID as param
	 * 
	 * 
	 * @param mobileNo
	 * @return ClaimCode
	 * 
	 */
	public static String getClaimCode(String mobileNo) {
		String claimCodeQuery = "SELECT * FROM wibmo_in_6019_data.unclamed_user_funds where ACCESS_DATA='mobileNo'" // and
																													// OF_TXN_ID='201504301113217338lI63nM2'
				.replace("mobileNo", mobileNo),

				claimCode = "", column_label = "CONFIRMATION_CODE";

		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + claimCodeQuery + " ====");
			result = result(claimCodeQuery);
			result.next(); // Result pointer starts from null

			return result.getString("CONFIRMATION_CODE");
		} catch (SQLException e) {
			Assert.fail("Unable to obtain ClaimCode. " + column_label + '\n' + e.getMessage());
			e.printStackTrace();
		} finally {
			close(result);
		}

		return claimCode;
	}

	/**
	 * Polls for the given value in the table every 5 seconds per poll
	 * 
	 * @param query
	 * @param columnName
	 * @param columnValue
	 * @param retryCount
	 * @return true if columnValue found
	 */
	public static boolean waitUntilValueInColumn(String query, String columnName, String columnValue, int retryCount) {
		ResultSet result = null;
		int count = 0;

		Log.info("==== Executing Query : " + query + " ====");
		Log.info("==== Polling for value : " + columnValue + " under  " + columnName + " ====");

		try {
			do {

				Generic.wait(5);
				result = result(query);
				result.next();
				count++;

				System.out.println("Value in " + columnName + ':' + result.getString(columnName));

			} while (!result.getString(columnName).equals(columnValue) && count < retryCount);

			if (count == retryCount)
				Log.info("=== " + columnValue + " not found in " + columnName);

			return result.getString(columnName).equals(columnValue);
		} catch (Exception e) {
			Assert.fail("Error in executinG query " + query + "\n" + e.getMessage());
			return false;
		}

	}

	public static void setClaimDate(String recipientId, String dateInDBFormat) {
		String claimDateUpdateQuery = "update wibmo_in_6019_data.unclamed_user_funds SET  LAST_DATE_TO_CLIAM='dateInDBFormat' where access_data='recipientId'"
				.replace("dateInDBFormat", dateInDBFormat).replace("recipientId", recipientId);

		executeQuery(claimDateUpdateQuery);

	}

	public static void setKYCAutoUpgrade(String autoUpgradeStatus, String autoUpgradeLevel, String mobileNumber) {
		String updateQuery = "UPDATE wibmo_in_6019_data.pc_ac_master SET KYC_AUTO_UPGRADE='autoUpgradeStatus', "
				+ "KYC_AUTO_UPGRADE_LEVEL='autoUpgradeLevel' "
				+ "WHERE PC_AC_NUMBER in (select PC_AC_NUMBER from wibmo_in.geo_user_reg_info where access_data in ('mobileNumber'))";

		updateQuery = updateQuery.replace("autoUpgradeStatus", autoUpgradeStatus)
				.replace("autoUpgradeLevel", autoUpgradeLevel).replace("mobileNumber", mobileNumber);

		executeQuery(updateQuery);

	}

	public static void setDateUpgrade(String mobileNumber) {
		String updateQuery = "UPDATE wibmo_in_6019_usr_data.user_fav_bank_account SET NOMINEE_ADDED_DATE = '2019-01-04 15:38:08' where "
				+ "PC_AC_NUMBER in(select PC_AC_NUMBER from wibmo_in.geo_user_reg_info where access_data in ('mobileNumber'))";

		updateQuery = updateQuery.replace("mobileNumber", mobileNumber);
		executeQuery(updateQuery);

	}

	public static String getPCACNumber(String mobileNo) {

		String pcAcNumberQuery = "select * from wibmo_in.geo_user_reg_info "
				+ "where access_data = 'mobileNo' and program_id=6019".replace("mobileNo", mobileNo);
		String pcAcNumber = null, column_label = "PC_AC_NUMBER";
		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + pcAcNumberQuery + " ====");
			result = result(pcAcNumberQuery);
			result.next();
			pcAcNumber = result.getString(column_label);
		} catch (Exception e) {
			Assert.fail("Unable to obtain " + column_label + '\n' + e.getMessage());
		} finally {
			close(result);
		}

		return pcAcNumber;
	}

	/**
	 * Returns the pgTxnId corresponding to the wibmoTxnId
	 * 
	 * 
	 * @param wibmoTxnId
	 * @return pgTxnId corresponding to the wibmoTxnId
	 */
	public static String getPgTxnId(String wibmoTxnId) {
		String pgTxnId = "", column_label = "pg_txn_id";

		String currentYear = Generic.getCurrentYear() + "";
		String currentMonth = Generic.getCurrentMonth() + "";

		currentMonth = currentMonth.length() == 1 ? "0" + currentMonth : currentMonth;

		String pgTxnQuery = "select pg_txn_id from wibmo_in_6019_data.merchant_iap_req_res_yyyymm where wibmo_2fa_txn_id='wibmoTxnId'"
				.replace("yyyy", currentYear).replace("mm", currentMonth).replace("wibmoTxnId", wibmoTxnId);

		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + pgTxnQuery + " ====");
			result = result(pgTxnQuery);
			result.next();
			pgTxnId = result.getString(column_label);
		} catch (Exception e) {
			Assert.fail("Unable to obtain " + column_label + '\n' + e.getMessage());
		} finally {
			close(result);
		}

		Log.info("==== pgTxnId is " + pgTxnId + " corresponding to " + wibmoTxnId + " ====");
		return pgTxnId;

	}

	public static String getURN(String mobileNo) {
		String urnQuery = "select * from wibmo_in_6019_data.pc_ac_master " + "where pc_ac_number="
				+ "(select PC_AC_NUMBER from wibmo_in.geo_user_reg_info "
				+ "where access_data = 'mobileNo' and program_id=6019)".replace("mobileNo", mobileNo);
		String urn = null, column_label = "BANK_URN";
		ResultSet result = null;
		try {
			Log.info("==== Executing Query : " + urnQuery + " ====");
			result = result(urnQuery);
			result.next();
			urn = result.getString(column_label);
		} catch (Exception e) {
			Assert.fail("Unable to obtain " + column_label + '\n' + e.getMessage());
		} finally {
			close(result);
		}

		return urn;
	}

	/**
	 * 
	 * 
	 * @return DEVICE_REG_MAX_COUNT under program_parameters . -1 if query
	 *         unsuccessful
	 */
	public static int getDeviceRegMaxCountParameter() {
		String query = "SELECT PARAM_VALUE FROM wibmo_in.program_parameters where PARAM_NAME='DEVICE_REG_MAX_COUNT' and PROGRAM_ID = '6019'";
		String column_label = "PARAM_VALUE";

		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + query + " ====");
			result = result(query);
			result.next();

			return Integer.parseInt(result.getString(column_label));

		} catch (SQLException e) {
			Assert.fail("Unable to obtain  column value " + column_label + '\n' + e.getMessage());
			e.printStackTrace();
		} finally {
			close(result);
		}

		return -1;
	}

	/**
	 * Sets the current registration count in data.user_registration_device
	 * 
	 * @param deviceId
	 * @return count set , if successful , -1 otherwise
	 * 
	 */
	public static int setDeviceRegistrationCount(String deviceId, int count) {
		String setCountQuery = "UPDATE wibmo_in_6019_data.user_registration_device SET COUNT='count' WHERE DEVICE_ID='deviceId'"
				.replace("deviceId", deviceId).replace("count", count + "");

		try {
			Log.info("==== Executing Query : " + setCountQuery + " ====");
			executeQuery(setCountQuery);
			return count;
		} catch (Exception e) {
			Assert.fail("Unable to update count for deviceId  " + deviceId + '\n' + e.getMessage());
			return -1;
		}

	}

	/**
	 * 
	 * @param userId
	 */
	public static void modifyCoolingPeriodTimestamp(String userId, String cardNumber) {
		String txnDate, txnHour, modifiedDate, modifiedDateQuery;
		int modifiedHour;

		String txnDateQuery = "SELECT TXN_START_DATE FROM wibmo_in_6019_usr_data.user_sf_txn_detail where USER_ID='userId' and SF_AC_NUMBER_MASKED like '%last4Digits'"
				.replace("userId", userId).replace("last4Digits", cardNumber.substring(cardNumber.length() - 4));

		try {
			ResultSet result = result(txnDateQuery);
			result.next();

			txnDate = result.getString("TXN_START_DATE").split("\\.")[0];
			System.out.println(txnDate);
			txnHour = txnDate.split(" ")[1].split(":")[0];

			modifiedHour = Integer.parseInt(txnHour) - 2;
			modifiedDate = txnDate.replace(txnHour + ":", modifiedHour + ":");

			modifiedDateQuery = "UPDATE wibmo_in_6019_usr_data.user_sf_txn_detail SET TXN_START_DATE='modifiedDate' WHERE USER_ID='userId' and SF_AC_NUMBER_MASKED like '%last4Digits'"
					.replace("userId", userId).replace("last4Digits", cardNumber.substring(cardNumber.length() - 4))
					.replace("modifiedDate", modifiedDate);

			System.out.println(modifiedDateQuery);

			executeQuery(modifiedDateQuery);

		} catch (SQLException s) {
			Assert.fail("Unable to modify date " + s.getMessage());
		}
	}

	public static void verifyCoolingStatus(String userId, String cardNumber, String expectedStatus) {
		String statusCodeQuery = "SELECT COOLING_PERIOD_STATUS FROM wibmo_in_6019_usr_data.user_payment_cards where USER_ID='userId' and CARD_MASK like '%last2Digits'"
				.replace("userId", userId).replace("last2Digits", cardNumber.substring(cardNumber.length() - 2));

		try {
			Log.info("======== Executing Query : " + statusCodeQuery + " ========");
			ResultSet result = result(statusCodeQuery);
			result.next();

			Assert.assertEquals(result.getString("COOLING_PERIOD_STATUS"), expectedStatus,
					"Invalid cooling period status");
		} catch (SQLException s) {
			Assert.fail("Unable to verify status " + s.getMessage());
		}

	}

	/**
	 * Method to update a merchant permission to charge again if 1st charge fails
	 * Sets the value to 1
	 * 
	 * @param merchantId
	 * @see updateMerchantToPreventChargeReAttempt()
	 */
	public static void updateMerchantToAllowChargeReAttempt(String merchantId) {
		String updateQuery = "UPDATE `wibmo_in_6019_data`.`merchant_iap_master` SET `ALLOW_CHARGE_REATTEMPT_ON_FAILURE`='1'"
				+ " WHERE `MERCHANT_ID`='merchantId'".replace("merchantId", merchantId);
		ResultSet result = null;
		try {
			Log.info("==== Executing Query : " + updateQuery + " ====");
			executeQuery(updateQuery);
		} catch (Exception e) {
			Assert.fail("Unable to update merchant to allow charge reattempt");
		} finally {
			close(result);
		}
	}

	/**
	 * Method to update a merchant permission to prevent charge again if 1st charge
	 * fails Sets the value to 0
	 * 
	 * @param merchantId
	 * @see updateMerchantToAllowChargeReAttempt()
	 * 
	 */
	public static void updateMerchantToPreventChargeReAttempt(String merchantId) {
		String updateQuery = "UPDATE `wibmo_in_6019_data`.`merchant_iap_master` SET `ALLOW_CHARGE_REATTEMPT_ON_FAILURE`='0'"
				+ " WHERE `MERCHANT_ID`='merchantId'".replace("merchantId", merchantId);
		ResultSet result = null;
		try {
			Log.info("==== Executing Query : " + updateQuery + " ====");
			executeQuery(updateQuery);
		} catch (Exception e) {
			Assert.fail("Unable to update merchant to prevent charge reattempt");
		} finally {
			close(result);
		}
	}

	/**
	 * Triggers a Cashback using the callableStatement under executeQuery()
	 * 
	 * If necessary update to Singleton conn().prepareCall(callStatement);
	 */
	public static void callCashbackStoredProcedure() {
		String callStmt = "call wibmo_in_6019_data.Promo_cashback_program(now())";
		try {
			result(callStmt);
		} catch (Exception e) {
			Assert.fail(" Unable to execute " + callStmt + '\n' + e.getMessage());
		}

	}

	public static void deleteUser(String mobileNo) {
		
		String deleteUserQuery1 = "SET SQL_SAFE_UPDATES=0;";
		String deleteUserQuery2 = "DELETE FROM wibmo_ph_2000_usr_data.mobile_device_info where `REG_DEFAULT_PHONE_NO`='"+mobileNo+"';";
		String deleteUserQuery3 = "DELETE FROM wibmo_ph.geo_user_reg_info WHERE ACCESS_DATA='919620819851' and ACCESS_DATA_TYPE ='0' and PROGRAM_ID='2000';";	
		String deleteUserQuery4 = "DELETE FROM wibmo_ph_2000_usr_data.user_mobile_info WHERE `MOBILE`='"+mobileNo+"';";
		String deleteUserQuery5 = "DELETE FROM wibmo_ph_2000_usr_data.external_user_data WHERE `ACCESS_STRING`='"+mobileNo+"';";
		String deleteUserQuery6 = "DELETE FROM wibmo_ph_2000_data.request_money_201908 where requester_mobile_no or recipient_mobile_no ='"+mobileNo+"';";
		String deleteUserQuery7 = "DELETE FROM wibmo_ph_2000_usr_data.registration_info where PC_AC_NUMBER=(SELECT PC_AC_NUMBER from wibmo_ph_2000_usr_data.external_user_data WHERE ACCESS_STRING='"+mobileNo+"');";
		String deleteUserQuery8 = "DELETE FROM wibmo_ph_2000_usr_data.USER_PAYMENT_BANK_ACCOUNTS where USER_ID=(SELECT USER_ID FROM wibmo_ph_2000_usr_data.USER_MOBILE_INFO where mobile='"+mobileNo+"');";
		String deleteUserQuery9 = "DELETE FROM wibmo_ph_2000_usr_data.user_fav_bank_account where USER_ID=(SELECT USER_ID FROM wibmo_ph_2000_usr_data.USER_MOBILE_INFO where mobile='"+mobileNo+"');";
		
		String urn = null;
		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + deleteUserQuery1 + " ====");
			executeQuery(deleteUserQuery1);
			Log.info("==== Executing Query : " + deleteUserQuery2 + " ====");
			executeQuery(deleteUserQuery2);
			Log.info("==== Executing Query : " + deleteUserQuery3 + " ====");
			executeQuery(deleteUserQuery3);
			Log.info("==== Executing Query : " + deleteUserQuery4 + " ====");
			executeQuery(deleteUserQuery4);
			Log.info("==== Executing Query : " + deleteUserQuery5 + " ====");
			executeQuery(deleteUserQuery5);
			Log.info("==== Executing Query : " + deleteUserQuery6 + " ====");
			executeQuery(deleteUserQuery6);
			Log.info("==== Executing Query : " + deleteUserQuery7 + " ====");
			executeQuery(deleteUserQuery7);
			Log.info("==== Executing Query : " + deleteUserQuery8 + " ====");
			executeQuery(deleteUserQuery8);
			Log.info("==== Executing Query : " + deleteUserQuery9 + " ====");
			executeQuery(deleteUserQuery9);
		} catch (Exception e) {
			Assert.fail("Unable to delete user " + '\n' + e.getMessage());
		} finally {
			close(result);
		}

	}

	/**
	 * @author aravindanath
	 * @param mobileNo
	 */

	public static void deleteWalletTxn() {
		String MM = Generic.getCurrentMonth() + "";
		MM = (MM.length() == 1) ? "0" + MM : MM;

		String YYYY = Generic.getCurrentYear() + "";

		String deleteUserQuery1 = "DELETE FROM `wibmo_in_6019_data`.`wallet_statement_inquiry_YYYYMM` WHERE `ID`='201902271454022707gX34uU0' or`PC_ACC_NUMBER`='IN008618479185'"
				.replace("YYYY", YYYY).replace("MM", MM);
		// deleteUserQuery1.replace("YYYY", YYYY).replace("MM", MM);

		String urn = null;
		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + deleteUserQuery1 + " ====");
			executeQuery(deleteUserQuery1);

		} catch (Exception e) {
			Assert.fail("Unable to delete user " + '\n' + e.getMessage());
		} finally {
			close(result);
		}

	}

	public static void verifymVisaTxnId(String txnId, double amt) {

		String amtInDb = "";

		String query = "SELECT * FROM wibmo_in_6019_data.pc_iap_mvisa_txn_yyyymm where PC_IAP_TXN_ID='txnId'"
				.replace("yyyymm", txnId.substring(0, 6)).replace("txnId", txnId),

				column_label = "AMOUNT";

		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + query + " ====");
			result = result(query);
			result.next(); // Result pointer starts from null
			amtInDb = result.getString(column_label);
			Log.info("==== Verifying amount in DB : " + amtInDb + " ====");
			Assert.assertEquals(Double.parseDouble(amtInDb), amt * 100, 0.01,
					"Incorrect Amount value in DB for Txn : " + txnId);
		} catch (SQLException e) {
			Assert.fail("Unable complete transaction " + column_label + '\n' + e.getMessage());
			e.printStackTrace();
		} finally {
			close(result);
		}

	}

	public static void verifyVoidStatus(String txnId, String expectedStatusCode) {
		String actualStatusCode;
		ResultSet result = null;

		String MM = Generic.getCurrentMonth() + "";
		MM = (MM.length() == 1) ? "0" + MM : MM;

		String YYYY = Generic.getCurrentYear() + "";

		String query = "SELECT VOID_STATUS FROM wibmo_in_6019_data.pc_iap_txn_YYYYMM where TXN_ID='iapTxnId'"
				.replace("YYYY", YYYY).replace("MM", MM).replace("iapTxnId", txnId);

		String columnLabel = "VOID_STATUS";

		Log.info("======== Executing query : " + query + " ========");

		try {

			result = result(query);
			result.next();
			actualStatusCode = result.getString(columnLabel);

			Log.info("======== Verifying " + columnLabel + " value : " + actualStatusCode + " ========");
			Assert.assertEquals(actualStatusCode, expectedStatusCode);

		} catch (SQLException e) {
			Assert.fail("Unable to execute query " + query);
			e.printStackTrace();
		}

	}

	//
	public static void verifyReleaseStatus(String txnId, String expectedStatusCode) {

		String actualStatusCode;
		ResultSet result = null;

		String MM = Generic.getCurrentMonth() + "";
		MM = (MM.length() == 1) ? "0" + MM : MM;

		String YYYY = Generic.getCurrentYear() + "";

		String query = "SELECT CASH_BACK_ERROR_DESC FROM wibmo_in_6019_data.promo_txn_YYYYMM where WIBMO_TXN_ID = 'iapTxnId';"
				.replace("YYYY", YYYY).replace("MM", MM).replace("iapTxnId", txnId);

		String columnLabel = "CASH_BACK_ERROR_DESC";

		Log.info("======== Executing query : " + query + " ========");

		try {

			result = result(query);
			result.next();
			actualStatusCode = result.getString(columnLabel);

			Log.info("======== Verifying " + columnLabel + " value : " + actualStatusCode + " ========");
			Assert.assertTrue(actualStatusCode.contains(expectedStatusCode), expectedStatusCode + "Not found ");

		} catch (SQLException e) {
			Assert.fail("Unable to execute query " + query);
			e.printStackTrace();
		}

	}

	/**
	 * @author aravindanath BDO QA DB
	 * @param mobile
	 */

	public static void deleteMobileNumber(String mob, String accountNo) {

		String deleteUserQuery1 = "delete from wibmo_ph_2000_usr_data.registration_info where PC_AC_NUMBER='"
				+ accountNo + "';";

		String deleteUserQuery2 = "delete from wibmo_ph_2000_usr_data.EXTERNAL_USER_DATA where access_string='" + mob
				+ "';";

		String deleteUserQuery3 = "delete from wibmo_ph_2000_usr_data.USER_MOBILE_INFO where mobile='" + mob + "';";

		String deleteUserQuery4 = "delete from wibmo_ph.GEO_USER_REG_INFO where access_data='" + mob + "';";

		ResultSet result = null;

		try {
			Log.info("==== Executing Query : " + deleteUserQuery1 + " ====");
			// stmt.executeQuery(deleteUserQuery1);
			executeQuery(deleteUserQuery1);
			Log.info("==== Executing Query : " + deleteUserQuery2 + " ====");
			// stmt.executeQuery(deleteUserQuery2);
			executeQuery(deleteUserQuery2);
			Log.info("==== Executing Query : " + deleteUserQuery3 + " ====");
			// stmt.executeQuery(deleteUserQuery3);
			executeQuery(deleteUserQuery3);
			Log.info("==== Executing Query : " + deleteUserQuery3 + " ====");
			// stmt.executeQuery(deleteUserQuery4);
			executeQuery(deleteUserQuery4);

		} catch (Exception e) {
			Assert.fail("Unable to delete user " + '\n' + e.getMessage());
		} finally {
			close(result);
		}

	}

	/**
	 * 
	 * BDO QA DB, Validates whether mobile number is registered or not
	 * 
	 * @author Rashmi
	 * @param mobile
	 * @return
	 * 
	 */

	public static String validateMobileNumber(String mobile) {

		ResultSet result = null;
		String mobileNum = null, column_label = "ACCESS_DATA";

		String validateMobileQuery = "select * from wibmo_ph.GEO_USER_REG_INFO where access_data=" + mobile + ";";

		try {

			Log.info("==== Executing Query : " + validateMobileQuery + " ====");
			result = result(validateMobileQuery);
			result.next();
			if (result != null)
				System.out.println(result.getString(1) + " : User has entered the registered mobile number ");

		} catch (Exception e) {
			// Assert.fail("Mobile no is not registered " + '\n' + e.getMessage());
			System.err.println("=======Warning : Mobile no is not registered============= ");
			return "NotRegistered";
		} finally {
			close(result);
		}
		return "Registered";

	}
	
	public static void main(String[] args) {
		DB db = new DB();
		db.deleteUser("919620819851");
	}


	public static Connection connectToDB(String dbIP, String dbPort, String schema, String dbUsername, String dbPassword)throws ClassNotFoundException, SQLException {
		// Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"
		String dbUrl = "jdbc:mysql://" + dbIP + ":"+ dbPort + "/"+ schema + "?useSSL=false";
		System.out.println("dbUrl: "+dbUrl);
		// Load mysql jdbc driver
		Class.forName("com.mysql.jdbc.Driver");
		// Create Connection to DB
		Connection con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
		return con;
	}

	public static int executeUpdateQuery(Connection con, String query)	throws SQLException {
		// Create Statement Object
		Statement stmt = con.createStatement();
		// Execute the SQL Query. Store results in ResultSet
		int result = stmt.executeUpdate(query);
		return result;
	}

	public static ResultSet executeSelectQuery(Connection con, String query)	throws SQLException {
		// Create Statement Object
		Statement stmt = con.createStatement();
		// Execute the SQL Query. Store results in ResultSet
		ResultSet result = stmt.executeQuery(query);
		return result;
	}

}

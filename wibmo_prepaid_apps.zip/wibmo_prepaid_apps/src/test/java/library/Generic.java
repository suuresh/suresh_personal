package library;

import Prepaid.testScripts.BaseTest1;
import com.github.javafaker.Faker;
import com.github.javafaker.IdNumber;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.paulhammant.ngwebdriver.NgWebDriver;
import io.appium.java_client.*;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.restassured.builder.ResponseBuilder;
import io.restassured.response.Response;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.ini4j.Ini;
import org.ini4j.Wini;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import ru.yandex.qatools.ashot.shooting.ShootingStrategy;

import javax.imageio.ImageIO;
import java.io.*;
import java.nio.file.*;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

//import java.awt.event.KeyEvent;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.internal.WrapsElement;
//import io.appium.java_client.MobileBy;

/**
 * The Class Generic.
 */
public class Generic {

	/** The soft assert. */
	public static SoftAssert softAssert = new SoftAssert();
	public static boolean multipleDevices;
	private String executionDeviceId = "";



	/**
	 * Check environment between qa and staging
	 *
	 * @param environment the environment
	 * @return true, if successful
	 */
	public static boolean checkEnv(String environment) {
		return BaseTest1.env.contains(environment);
	}

	/**
	 * Uses JS SendKeys
	 *

	 */
	public static void sendKeys(WebDriver driver, WebElement textField, String text) {
		int i = (Integer) ((AndroidDriver) driver).executeScript(
				"try{var el = document.arguments[0];el.value = 'arguments[1]';return 0;}catch{return 1;}", textField,
				text);

		if (i == 1)
			System.out.println("Unable to sendKeys");
	}

	/**
	 * Use Generic.hideKeyboard() instead
	 * 
	 * @param driver
	 */
	public static void iosKey_Go(WebDriver driver) {
		IOSDriver iDriver = (IOSDriver) driver;
		Log.info("======== Clicking on Go Key ========");
		iDriver.findElementByAccessibilityId("Go").click();
	}

	/**
	 * Hides the Keyboard if the Keyboard is displayed.
	 *
	 * @param driver the driver
	 */
	public static void enterNumKey(WebDriver driver, int key) {
		if (checkWebView(driver))
			return;
		try {
			if (isIos(driver)) // IOS
			{
				List<WebElement> keyBoardChk = driver.findElements(MobileBy.iOSNsPredicateString(
						"type='XCUIElementTypeNavigationBar' or (type='XCUIElementTypeButton' && name IN {'Done','Next','Return'})"));
				for (WebElement e : keyBoardChk)
					if (e.getAttribute("type").contains("Button")) {
						driver.findElement(MobileBy.iOSNsPredicateString("name IN {'Done','Next','Return'}")).click();
						break;
					}
			} else // Android
			{
				if (isKeyboardDisplayed(driver))
					switch (key) {
					case 1:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_1));
						break;
					case 2:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_2));
						break;
					case 3:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_3));
						break;
					case 4:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_4));
						break;
					case 5:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_5));
						break;
					case 6:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_6));
						break;
					case 7:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_7));
						break;
					case 8:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_8));
						break;
					case 9:
						((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.DIGIT_9));
						break;
					}
			}
		} catch (Exception e) {
		}

	}

	public static void hideKeyBoard(WebDriver driver) {
		if (checkWebView(driver))
			return;
		try {
			if (isIos(driver)) // IOS
			{
				List<WebElement> keyBoardChk = driver.findElements(MobileBy.iOSNsPredicateString(
						"type='XCUIElementTypeNavigationBar' or (type='XCUIElementTypeButton' && name IN {'Done','Next','Return'})"));
				for (WebElement e : keyBoardChk)
					if (e.getAttribute("type").contains("Button")) {
						driver.findElement(MobileBy.iOSNsPredicateString("name IN {'Done','Next','Return'}")).click();
						break;
					}
			} else // Android
			{
				if (isKeyboardDisplayed(driver))
					((AndroidDriver) driver).hideKeyboard();
			}
		} catch (Exception e) {
		}

	}

	/**
	 * Ignores the alert popup by clicking on the Cancel.
	 *
	 * @param driver the driver
	 */
	public static void ignorePopup(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		try {
			driver.findElement(By.name("Cancel")).click();
		} catch (Exception e) {
		}
	}

	/**
	 * Android only
	 * 
	 * @param driver
	 * @return true if keyboard is present
	 */
	public static boolean isKeyboardDisplayed(WebDriver driver) {
		if (isAndroid(driver)) {
			AndroidDriver adriver = (AndroidDriver) driver;
			return adriver.isKeyboardShown();
		}
//		if(isIos(driver)) // Keyboard abcense results in XCUIElementTypeKeyboard element not found delay 
//		{
//			IOSDriver idriver = (IOSDriver) driver;
//			return idriver.isKeyboardShown();
//		}
		return false;
	}

	/**
	 * Accepts the alert popup by clicking on the Cancel. Used to handle permissions
	 * alert popup
	 *
	 * @param driver the driver
	 */
	public static void allowPopup(WebDriver driver) // D
	{
		try {
			driver.findElement(By.id("permission_allow_button")).click(); // Click Allow Button
		} catch (Exception e) {
		}
	}

	/**
	 * To fetch Text from Alert popup
	 *
	 * @param driver the driver
	 * @return the String
	 *
	 */
	public static String getAlertText(WebDriver driver) {
		return driver.switchTo().alert().getText();
	}

	/**
	 * Scrolls to the given text. IOS requires more RnD Cannot use mobile : scroll ,
	 * Unexpected Auto Click
	 *
	 * @param driver the driver
	 * @param text   the text
	 * @return the web element
	 * 
	 */
	public static WebElement scroll(WebDriver driver, String text) {
		if (isIos(driver)) // === IOS === //
		{
			IOSDriver<IOSElement> iDriver = (IOSDriver<IOSElement>) driver;

			String elementPredicate = "name contains 'text' or value contains 'text'".replaceAll("text", text);
			By scrollToElement = MobileBy.iOSNsPredicateString(elementPredicate);

			if (Generic.getAttribute(iDriver.findElement(scrollToElement), "visible").equals("true"))
				return iDriver.findElement(scrollToElement);
			else
				swipeToBottom(iDriver);

			waitUntilIOSElementVisible(driver, iDriver.findElement(scrollToElement), 2);

			if (Generic.getAttribute(iDriver.findElement(scrollToElement), "visible").equals("true"))
				return (WebElement) iDriver.findElement(scrollToElement);
			else {
				Log.info("IOS Element with " + text + " not visible");
				return (WebElement) iDriver.findElement(scrollToElement);
			}
		} else {

			// === Android === //
			String automatorString = "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\""
					+ text + "\"));";
			return ((AndroidDriver) driver).findElementByAndroidUIAutomator(automatorString);
		}
	}

	public static void scrollToAndroid(WebDriver driver, WebElement ele1, WebElement ele2) {
		// IOSDriver idriver = (IOSDriver<IOSElement>) driver;
		TouchActions action = new TouchActions(driver);

	}

	public static void scrollIOS(WebDriver driver, WebElement ele1, WebElement ele2) {
		// scroll to the last item in the list by accessibility id
		/*
		 * IOSDriver<IOSElement> idriver = (IOSDriver<IOSElement>) driver; Map<String,
		 * Object> args = new HashMap<>(); args.put("direction", "down"); //
		 * args.put("name", eleName); idriver.executeScript("mobile: scroll", args);
		 */

		TouchActions tc = new TouchActions(driver);
		tc.longPress(ele1).moveToElement(ele2).release().build().perform();

	}

	/**
	 * 
	 * 
	 * @param driver
	 * @param text
	 * @deprecated Under development. Auto Clicks on Random elements in IOS
	 */
	public static void scrollClick(WebDriver driver, String text) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap scrollObject = new HashMap<>();
		scrollObject.put("predicateString", "value == '" + text + "'"); // or name ==' '
		js.executeScript("mobile: scroll", scrollObject);
	}

	/**
	 * Scrolls to the given text, case insensitive.(Under development)
	 *
	 * @param driver the driver
	 * @param text   the text
	 * @return the web element
	 */
	public static WebElement scroll1(WebDriver driver, String text) {
		text = regInsensitive(text);
		String automatorString1 = "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textMatches(\""
				+ text + "\"));";
		System.out.println("automatorString1 : " + automatorString1);

		// return
		// ((AndroidDriver)driver).findElement(MobileBy.AndroidUIAutomator(automatorString));
		return ((AndroidDriver) driver).findElementByAndroidUIAutomator(automatorString1);
	}

	/**
	 * Scrolls to the end of the page.
	 *
	 * @param driver the driver
	 */
	public static void scrollToEnd(WebDriver driver) {
		try {
//			String automatorString = "new UiScrollable(new UiSelector()).scrollToEnd(3);";
//			((AndroidDriver) driver).findElementByAndroidUIAutomator(automatorString);
			((AndroidDriver) driver).findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollToEnd(9);");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Scrolls to the given text.
	 *
	 * @param driver the driver
	 * @return void
	 * 
	 */
	public static void scrollToText(WebDriver driver, String text) {
		String automatorString = "new UiScrollable(new UiSelector()).scrollTextIntoView(\"" + text + "\")";
		System.out.println(automatorString);
		((AndroidDriver) driver).findElementByAndroidUIAutomator(automatorString);
		MobileElement e = (MobileElement) ((AndroidDriver) driver).findElementByAndroidUIAutomator(automatorString);

//MobileElement elementToClick = (MobileElement) ((FindsByAndroidUIAutomator<MobileElement>) driver)
//    .findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
//        + ".resourceId(\"com.android.settings:id/content\")).scrollIntoView("
//        + "new UiSelector().text(\"Lock screen and security\"));");
//elementToClick.click();
	}

	// scrolls to the element with the mentioned text and clicks it

	public static void scrollToElement(WebDriver driver, String elementVisibleText) {
		String uiSelector = "new UiSelector().textMatches(\"" + elementVisibleText + "\")";
		String command = "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(" + uiSelector
				+ ");";
		((AndroidDriver) driver).findElementByAndroidUIAutomator(command);
	}

	/**
	 * Swipes from right to left. Mainly used in the Select Card Page. <---------||
	 * 
	 * @param driver the driver
	 */
	public static void swipeLeftTillEnd(WebDriver driver) {
		System.out.println("Swiping Left");

		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);
		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width * 0.95);
		int endx = (int) (size.width * 0.1);
		int starty = size.height / 3;

		try {
			if (isIos(driver)) {
				// touchAction.press(PointOption.point(startx,
				// starty)).moveTo(PointOption.point(endx - startx, 0))
				// .release().perform(); // Relative final Co-ordinates
				
				Map<String, Object> args = new HashMap<>();
				args.put("direction", "left");
				adriver.executeScript("mobile: swipe", args);
			} else
				System.out.println("============Dimension :" + size);
			touchAction.press(PointOption.point(startx, starty))
					.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(endx, starty))
					.release().perform(); // Absolute final Co-ordinates
		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}

	}

	/**
	 * Simulates a tap on the element
	 *
	 * @param driver  the driver
	 * @param element
	 */
	public static void tap(WebDriver driver, WebElement element) {

		if (isAndroid(driver)) {

			AndroidDriver<AndroidElement> aDriver = (AndroidDriver<AndroidElement>) driver;
			TouchAction touchAction = new TouchAction(aDriver);

			AndroidElement aElement = (AndroidElement) element;
			int x = aElement.getCenter().x, y = aElement.getCenter().y;

			System.out.println("Executing tap on " + x + ',' + y);

			touchAction.press(PointOption.point(x, y)).release().perform();

		} else {
			IOSDriver<IOSElement> iDriver = (IOSDriver<IOSElement>) driver;
			TouchAction touchAction = new TouchAction(iDriver);

			IOSElement iElement = (IOSElement) element;
			int x = iElement.getCenter().x, y = iElement.getCenter().y;

			System.out.println("Executing tap on " + x + ',' + y);
			touchAction.press(PointOption.point(x, y)).release().perform(); // May Upgrade , if 'visible' attribute is
																			// true then syso and print "Clicking
																			// directly" under log
		}
	}

	/**
	 * 
	 * Clicks on the x,y co-ordinates which are to be calculated dynamically
	 * previously. Can be upgraded to finger customization.
	 * 
	 * 
	 */
	public static void tap(WebDriver driver, int x, int y) {

		System.out.println("Executing x,y tap on " + x + ',' + y);

		if (isAndroid(driver)) {

			AndroidDriver<AndroidElement> aDriver = (AndroidDriver<AndroidElement>) driver;
			TouchAction touchAction = new TouchAction(aDriver);

			touchAction.press(PointOption.point(x, y)).release().perform();

		} else {
			IOSDriver<IOSElement> iDriver = (IOSDriver<IOSElement>) driver;
			TouchAction touchAction = new TouchAction(iDriver);

			touchAction.press(PointOption.point(x, y)).release().perform();
		}

	}

	/**
	 * Swipes from left to right. Mainly used to open Navigation Pane. ||--------->
	 * 
	 * @param driver the driver
	 */
	public static void swipeRight(WebDriver driver) {
		System.out.println("Swiping Right");
		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);

		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width * 0.01);
		int endx = (int) (size.width * 0.95);
		int starty = size.height / 2; // or use /3

		touchAction.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
				.moveTo(PointOption.point(endx, starty)).release().perform(); // Absolute final Co-ordinates

	}

	// Element locator
	public static WebElement fileXpathBuilder(WebDriver driver, String xpath, String fileName) {
		WebElement element = driver.findElement(By.xpath(xpath + fileName + "']"));
		return element;
	}

	/**
	 * Moves to bottom of the page by swiping to top.
	 *
	 * @param driver the driver
	 */
	public static void swipeToBottom(WebDriver driver) {
		Log.info("Swiping down verically");
		AppiumDriver aDriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(aDriver);

		Dimension size = aDriver.manage().window().getSize();

		// System.out.println(size);
		int startx = (int) (size.width / 2);
		int endy = (int) (size.height * 0.2);
		int starty = (int) (size.height * 0.8);
		// endy = 10;

		try {

			if (isIos(driver)) // IOS
			{
				System.out.println("Swiping Up");
				Map<String, Object> args = new HashMap<>();
				args.put("direction", "up");
				aDriver.executeScript("mobile: swipe", args);

			} else // Android
				touchAction.press(PointOption.point(startx, starty))
						.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
						.moveTo(PointOption.point(startx, endy)).release().perform(); // Absolute final Co-ordinates

		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}
	}

	public static void swipeSlight(WebDriver driver) {

		AppiumDriver aDriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(aDriver);

		Dimension size = aDriver.manage().window().getSize();

		System.out.println(size);
		int startx = (int) (size.width / 2);
		int endy = (int) (size.height * 0.5);
		int starty = (int) (size.height * 0.6);

		try {

			if (isIos(driver)) // IOS
			{
				System.out.println("Swiping Up");
				Map<String, Object> args = new HashMap<>();
				args.put("direction", "up");
				aDriver.executeScript("mobile: swipe", args);

			} else // Android
				touchAction.press(PointOption.point(startx, starty))
						.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
						.moveTo(PointOption.point(startx, endy)).release().perform(); // Absolute final Co-ordinates

		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}
	}

	/**
	 * Swipes to top of the page by swiping down.
	 *
	 * @param driver the driver

	 * 
	 */
	public static void swipeUp(WebDriver driver) {
		Log.info("Swiping Up verically");
		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);

		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width / 2);
		int starty = (int) (size.height * 0.20);
		int endy = (int) (size.height * 0.80);

		try {
			if (isIos(driver)) {
				System.out.println("Swiping Down");
				Map<String, Object> args = new HashMap<>();
				args.put("direction", "down");
				adriver.executeScript("mobile: swipe", args);
			} else
				touchAction.press(PointOption.point(startx, starty))
						.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
						.moveTo(PointOption.point(startx, endy)).release().perform(); // Absolute final Co-ordinates for

		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}

	}

	/**
	 * Simulates a Generic tap on the screen when the page is not recognized by
	 * autowebview capability.
	 *
	 * @param driver the driver
	 */
	public static void tap3DS(WebDriver driver) {
		if (Generic.isIos(driver))
			return;
		// Log.info("======== Trying to identify 3DS page ========");
		((AndroidDriver) driver).pressKeyCode(61); // KEYCODE_TAB
	}

	/**
	 * Simulates a double tab and enter on the screen Android Only
	 * 
	 * @param driver the driver
	 */
	public static void doubleTapEnter(WebDriver driver) {
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB)); // KEYCODE_TAB // KEYCODE_TAB
		wait(1);
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
		; // KEYCODE_TAB
		wait(1);
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		; // KEYCODE_ENTER
	}

	/**
	 * Double taps on the given element
	 *
	 * @param driver  the driver
	 * @param element
	 * 
	 */
	public static void doubleTap(WebDriver driver, WebElement element) {
		AppiumDriver adriver = Generic.isAndroid(driver) ? (AndroidDriver) driver : (IOSDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);

		Log.info("======== Performing Double Tap ========");
		try {
			touchAction.tap(tapOptions().withElement(element(element)).withTapsCount(2)).perform();

			// touchAction.tap(element).perform().waitAction(Duration.ofMillis(100)).tap(element).perform();
			// touchAction.press(locX,locY).release().perform().waitAction(Duration.ofMillis(100)).press(locX,locY).release().perform();
		} catch (Exception e) {
			// Log.info("== Unable to Perform double tap == ");
		}
	}



	/**
	 * Navigates back from the page. Android only.
	 * 
	 * @param driver
	 */
	public static void navigateBack(WebDriver driver) {
		if (isIos(driver))
			return;
		driver.navigate().back();
	}

	/**
	 * Navigates to the Welcome page if the default landing Page is Login Page.
	 *
	 * @param driver the driver
	 */
	public static void gotoWelcome(WebDriver driver) {
		String xp = "//android.widget.TextView[contains(@text,'Logging') or contains(@text,'Register')]";

		WebElement homeCheck = driver.findElement(By.xpath(xp));

		if (homeCheck.getText().contains("Logging"))
			driver.findElement(By.id("home_button_login")).click();
	}

	/**
	 * Waits until any of the text in String... is displayed in the page
	 * 
	 * @return text which is found, "notFound"
	 */
	public static String waitUntilTextInPage(WebDriver driver, int timeoutSeconds, String... args) {
		String textFound = "notFound";

		for (int i = 0; i < timeoutSeconds; i++) {
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}
			if (!(textFound = checkTextInPageSource(driver, args)).equals("notFound"))
				return textFound;
		}

		// Assert.fail("Page taking toomuch time to load while waiting for " +
		// Arrays.asList(args));
		return textFound;
	}

	/**
	 * Handles the Coach messages occuring in the Home Page The coach messages may
	 * appear after the Home Page is validated.
	 * 
	 * 
	 * @param driver the driver
	 * @deprecated Coach Message in HomePage handled from Prepaid.testScripts.BaseTest1 verifyLogin
	 *             method
	 */
	public static void handleHomeCoach(WebDriver driver) {
		try {
			String gotItXp = "//*[contains(@text,'Got It') or contains(@resource-id,'title_text') or contains(@resource-id,'got_it')]"; // Exclude
																																		// later
																																		// on
																																		// Observation
			WebElement coachElement = driver.findElement(By.xpath(gotItXp));

			if (coachElement.getText().contains("Proceed")) {
				Log.info("== Handling Proceed Coach ==");
				driver.navigate().back();
			} else
				driver.findElement(By.xpath(gotItXp)).click(); // dont use coachElement
		} catch (Exception e) {
			Log.info("== Home Coach delay ==" + e.getMessage());
		}

	}



	public static void activateIOSApp(WebDriver driver, String bundleId) {
		System.out.println("=== Activating IOS App with bundleId " + bundleId + "===");
		((IOSDriver) driver).activateApp(bundleId);
	}

	/**
	 * @Aravindanath
	 * @param driver
	 * @param bundleId
	 */
	public static void switchBtApps(WebDriver driver, String bundleId) {
		HashMap<String, Object> args = new HashMap<>();
		args.put("bundleId", bundleId);
		((IOSDriver) driver).executeScript("mobile: launchApp", args);
	}

	/**
	 * @Author Aravindanath
	 * @param smsContent
	 * @return
	 */

	public static String getOtpFromNotificationAdv(String smsContent) {

		String smsText = smsContent;

		System.out.println("==================== Sms Text: " + smsText + "====================");

		for (String str : smsText.replace(".", "").split(" ")) {
			if (str.matches("\\d{6}")) {
				return str;
			}

		}
		return "fb";

	}

	/**
	 * @Aravindanath GetPin is for extracting PIN from OTP of BDO
	 * @param driver
	 * @return
	 */

	public static String getPIN(WebDriver driver, String bundleId) {
		String otp = "";
		boolean otpMsg = false;
		if (otpMsg == true) {
			if (Generic.isIos(driver)) {
				Generic.switchBtApps(driver, "com.apple.MobileSMS");
				try {
					WebElement msg = driver.findElement(MobileBy.iOSNsPredicateString(
							"type='XCUIElementTypeStaticText' and value contains 'Your One-Time PIN'"));
					System.out.println(msg.getText());
					Generic.tap(driver, msg);
				} catch (Exception e) {
				}
				Generic.wait(2);
				String sms = driver
						.findElement(
								MobileBy.xpath("(//XCUIElementTypeCell[contains(@name,'DO NOT SHARE THIS WITH')])[last()]"))
						.getText();
				otp = Generic.getOtpFromNotificationAdv(sms);
				Log.info("OTP: " + otp);
				activateIOSApp(driver, bundleId);
			} else {
				Generic.switchToApp(driver, "com.google.android.apps.messaging",
						"com.google.android.apps.messaging.home.HomeActivity");
				try {
					WebElement justNow = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Just now')]"));

					Generic.waitForElement(driver, justNow, 60);

					WebElement msg = driver
							.findElement(By.xpath("//android.widget.TextView[contains(@text, 'Your One-Time PIN')]"));
					System.out.println(msg.getText());
					Generic.tap(driver, msg);
				} catch (Exception e) {
				}
				Generic.wait(2);

				String sms = driver
						.findElement(MobileBy
								.xpath("(//android.widget.TextView[contains(@text,'DO NOT SHARE THIS WITH')])[last()]"))
						.getText();
				otp = Generic.getOtpFromNotificationAdv(sms);
				Log.info("OTP: " + otp);
				switchToAppWithState(driver);
			}
			return otp;
		}else if(otpMsg == false){
			return "fb";
		}
		return otp;
	}

	public static boolean isAppInstalled(WebDriver driver, String pkgBundle) {
		return ((AppiumDriver) driver).isAppInstalled(pkgBundle);
	}

	/**
	 * Switches to the AUT which was previously launched by using Android Keycodes
	 * 
	 * Can be updated to use monkeyrunner if screens are consistent
	 *
	 * 
	 * @param driver the driver

	 * 
	 */
	public static void switchToAppWithState(WebDriver driver) {
		// ((AndroidDriver) driver).startActivity(Prepaid.testScripts.BaseTest1.packageName,activity);

		Log.info("======== Switching to app with previous state =======");
		String appName = BaseTest1.programName;

		String xp = "//*[contains(@text,'BDO')]";

		String checkerXp = "//android.widget.TextView[contains(@text,'Submit')]";

		try {
			((AndroidDriver) driver).pressKeyCode(187); // KEYCODE_APP_SWITCH
			Generic.wait(1);
			driver.findElement(By.xpath(xp)).click();
			Generic.wait(1);

			Log.info("======== Switched to app with previous state =======");
			String title = driver.findElement(By.xpath(checkerXp)).getText();
			Log.info("======== Verifying AUT Page Title : " + title + " ========");

		} catch (Exception e) {
			Log.info("Error during App Switch\n" + e.getMessage());
		}
	}

	/**
	 * Switches to the Merchant App which was previously launched by using Android
	 * Keycode KEYCODE_APP_SWITCH.
	 *
	 * @param driver the driver
	 */
	public static void switchToMerchantWithState(WebDriver driver) {
		Log.info("======== Switching to merchant app with previous state =======");
		String xp = "//*[contains(@text,'Wibmo')]/..";
		String checkerXp = "//android.widget.TextView[contains(@text,'Wibmo') or contains(@resource-id,'title_text') or contains(@resource-id,'approve_textbutton') or contains(@text,'Authentication')]";

		try {
			((AndroidDriver) driver).pressKeyCode(187); // KEYCODE_APP_SWITCH
			Generic.wait(2);
			driver.findElement(By.xpath(xp)).click();
			Generic.wait(2);

			String title = driver.findElement(By.xpath(checkerXp)).getText();
			if (title.contains("Add")) // Reswitch if not switched to Merchant App (''Wibmo' or 'Secure Pin' prompt)
			// if(!getFocusedAppPkg(driver).contains(getPropValues("MERCHANTPACKAGE",
			// Prepaid.testScripts.BaseTest1.configPath)))
			{
				Log.info("==== Attempting reswitch ====");
				Runtime.getRuntime().exec("adb -s " + getUdId(driver) + " shell input keyevent KEYCODE_APP_SWITCH");
				Generic.wait(2);
				driver.findElement(By.xpath(xp)).click();
			} else
				Log.info("======== Successfully switched to Merchant App ========");

		} catch (Exception e) {
			Log.info("Error during App Switch\n" + e.getMessage());
		}
	}

	/**
	 * Verifies whether the current page is Pay / Send page
	 * 
	 *
	 * @param driver the driver
	 * @return true if current page is Pay / Send
	 */
	public static boolean checkAddSend(WebDriver driver) {
		String checkerXp = "//android.widget.TextView[contains(@resource-id,'title_text') or contains(@text,'SDK')]";

		// adb shortcut can be attempted with try{}
		try {
			return driver.findElement(By.xpath(checkerXp)).getText().contains("Pay");
		} catch (Exception e) {
			Log.info("==== Error in determining Pay Send Page ====");
			return false;
		}
	}


	/**
	 * Uninstalls the app with the given package name.
	 *
	 * @param driver      the driver
	 * @param packageName the package name
	 */
	public static void unInstallApp(WebDriver driver, String packageName) {
		if (((AndroidDriver) driver).isAppInstalled(packageName)) {
			Log.info("======== Uninstalling App with package name : " + packageName + " ========");
			try {
				((AndroidDriver) driver).removeApp(packageName);
				Log.info("======== App uninstalled ========");
			} catch (Exception e) {
				Assert.fail("App with package name : " + packageName + " was not uninstalled\n" + e.getMessage());
			}
		} else
			Log.info("======== App with package " + packageName + " already uninstalled ========");
	}



	/**
	 *
	 * @author : Rashmi
	 *
	 */
	public static int getDateDay() {
		//return 27;
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		//getTime() returns the current date in default time zone
		Date date = calendar.getTime();
		int day = calendar.get(Calendar.DATE);
		return day;
	}

    // To be used by Baseclass using adb commands only and static boolean
	// isAppInstalled & before the driver is launched
	public void installProgram() {
		// if(packageName does not contain QA) return;

	}

	public void uninstallProgram() {

	}



	/**
	 * Sets the current execution device Id after reading it from the driver
	 * capabilities
	 * 
	 *
	 * @param driver the driver
	 * 
	 */
	public void setExecutionDeviceId(WebDriver driver) {
		if (executionDeviceId.isEmpty()) {
			try {
				executionDeviceId = (String) ((AndroidDriver) driver).getCapabilities().getCapability("deviceName");
			} catch (Exception e) {
				System.out.println("=== Obtaining deviceId from adb ===");
				String deviceCmd = "adb devices";
				try {
					executionDeviceId = execCmd(deviceCmd).split("\\n")[1].split("\\s+")[0];
				} catch (Exception e1) {
					System.out.println("Warning : unable to execute cmd : " + deviceCmd);
				}
			}
		}
	}

	/**
	 * Gets the current execution device Id from driver capabilities.
	 * 
	 *
	 * @param driver the driver
	 * 
	 */
	public static String getExecutionDeviceId(WebDriver driver) {

		if (isAndroid(driver))
			return (String) ((AndroidDriver) driver).getCapabilities().getCapability("udid");

		if (isIos(driver))
			return (String) ((IOSDriver) driver).getCapabilities().getCapability("udid");

		System.err.println("Warning : Udid not present for the driver : " + driver.toString());
		return "--";

	}

	public static String getUdId(WebDriver driver) {
		return getExecutionDeviceId(driver);
	}

	public static String getPackageName(WebDriver driver) {
		if (!isAndroid(driver))
			return "WebDriverPackage";

		// String pkgName=((AndroidDriver<WebElement>)driver).getCurrentPackage();
		// Retrieving Session Details on session id is unstable

		return parseDataVal(driver, driver.toString(), "appPackage=");

	}

	public static String getAttribute(WebElement element, String attribute) {

		if (element.toString().toLowerCase().contains("ios") && attribute.toLowerCase().contains("content"))
			return "attributeNotFound";

		String attributeValue = element.getAttribute(attribute);
		System.out.println("Retrieving " + attribute + " value  as " + attributeValue + " for " + element.toString());

		return attributeValue == null ? "" : attributeValue;
	}

	/**
	 * For IOS Element return "value" attribute or "name" attribute whichever is not
	 * null
	 * 
	 * @param driver
	 * @param element
	 * @return text value present in the element
	 */
	public static String getText(WebDriver driver, WebElement element) {

		String txtVal = element.getText();

		if (isIos(driver))
			return ((txtVal == null || txtVal.isEmpty()) ? getAttribute(element, "name") : txtVal);

		return txtVal;

	}


	public static void uninstallAppPreserveData(WebDriver driver, String packageName) {
		Log.info("======== Uninstalling  App : " + packageName + "========");
		String uninstallCmd = "adb -s " + getExecutionDeviceId(driver) + " shell pm uninstall -k " + packageName;
		try {
			if (!Runtime.getRuntime().exec(uninstallCmd).waitFor(2, TimeUnit.MINUTES))
				Assert.fail("App Uninstall Timeout");
		} catch (Exception e) {
			Log.info("======== Force removing App ========");
			try {
				((AndroidDriver) driver).removeApp(packageName);
			} catch (Exception e1) {
				Assert.fail("Unable to uninstall app :" + packageName + '\n' + e1.getMessage());
			}
		}
		Log.info("======== App successfully uninstalled ========");
	}




	/**
	 * Closes the App display by pressing the Home button
	 * 
	 * @param driver
	 */
	public static void closeApp(WebDriver driver) {
		Log.info("======== Minimising App ========");
		((AndroidDriver) driver).pressKeyCode(3); // KEYCODE_HOME
		wait(2);
	}

	public static void backgroundIOSApp(WebDriver driver, int seconds) {
		Log.info("======== Backgrounding IOS App for " + seconds + " seconds ========");
		((IOSDriver) driver).runAppInBackground(Duration.ofSeconds(seconds));
	}

	public static void terminateIOSApp(WebDriver driver, String bundleId) {
		Log.info("======== Closing App with bundleId : " + bundleId + " ========");
		if (isAppInstalled(driver, bundleId))
			((IOSDriver) driver).terminateApp(bundleId);
	}

	/**
	 * Handles 'prepaid balance deducted' popup or 'rate app' occurring while
	 * logging in.
	 *
	 * @param driver the driver
	 */
	public static void handlePrepaidOrRateApp(WebDriver driver) {
		String xp = "//android.widget.Button[contains(@text,'OK') or contains(@text,'No thanks')]";

		driver.findElement(By.xpath(xp)).click();

		// On rare possibility, Rateapp popup might still be present

		xp = "//android.widget.TextView[contains(@resource-id,'title_text')] | //android.widget.Button[contains(@text,'No thanks')]";
		if (driver.findElement(By.xpath(xp)).getText().contains("thanks"))
			driver.findElement(By.name("No thanks")).click();
	}



	/**
	 * Gets the prop values corresponding to the Key from the config.properties
	 * file.
	 *
	 * @param key  the key

	 * @return the prop values
	 */
	public static String getPropValues(String key) {
		String path = System.getProperty("user.dir")+File.separator+"config"+File.separator+"Web"+File.separator+"config.properties";
//		String path="E:\\D backup\\Shankar\\Automation\\Wibmo_Prepaid_Apps"+File.separator+"config"+File.separator+"Web"+File.separator+"config.properties";
		String value = "";
		Properties prop = new Properties();
		try {
			InputStream input = new FileInputStream(path);
			prop.load(input);
		} catch (Exception e) {
			System.err.println(
					"--------------------------------------------------------------------------------------------------");
			System.err.println("Please Check The path of Properties file: Provided Path is: " + path);
			System.err.println(
					"--------------------------------------------------------------------------------------------------");
			System.out.println(e.toString());
			System.exit(0);
		}

		value = prop.getProperty(key);
		return value;
	}

	/**
	 * Launches and returns a Firefox driver
	 * 
	 * @return FirefoxDriver
	 */
	public static FirefoxDriver createFirefoxDriver() {
		return new FirefoxDriver();
	}

	/**
	 * Launches and returns a Firefox driver with the given profile
	 * 
	 * @return FirefoxDriver
	 */
	public static FirefoxDriver createFirefoxDriver(FirefoxProfile profile) {
		return new FirefoxDriver(new FirefoxOptions().setProfile(profile));
	}

	/**
	 * Launches and returns a ChromeDriver
	 * 
	 * @return ChromeDriver
	 */
	public static ChromeDriver createChromeDriver() {
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setBinary("./ChromeBinary/chrome.exe"); // Version Control across end user systems

		if (System.getProperty("os.name").contains("Mac"))
			return new ChromeDriver();
		else
			return new ChromeDriver(chromeOptions);

	}

	public static WebDriver createCSRDriver() {
		WebDriver driver = getPropValues("CSRBROWSER").contains("Fire") ? createFirefoxDriver()
				: createChromeDriver();
		return driver;
	}

	public static String getHTTPResponseString(String url) {
		String USER_AGENT = "Mozilla/5.0";

		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		HttpResponse response = null;
		String OTP = "";

		System.out.println(url);
		HttpGet request = new HttpGet(url);
		request.addHeader("User-Agent", USER_AGENT);

		try {
			response = client.execute(request);
			int responseCode = response.getStatusLine().getStatusCode();
			if (responseCode == 200) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null)
					result.append(line);
			}
			return result.toString();
		} catch (Exception ex) {
			Log.info("== Get Response failed ==");
			return "null";
		}

	}

	public static synchronized String getOTP(String mobileNo, String bank, String event) {
		String USER_AGENT = "Mozilla/5.0";

		StringBuffer result = new StringBuffer();
		HttpClient client = new DefaultHttpClient();
		HttpResponse response = null;
		String OTP = "";

		String url = getPropValues("OTPURL").replace("AccessData", mobileNo)
				.replace("ProgramId", bank).replace("EventId", event);
		System.out.println(url);
		HttpGet request = new HttpGet(url);
		request.addHeader("User-Agent", USER_AGENT);

		try {
			response = client.execute(request);
			int responseCode = response.getStatusLine().getStatusCode();
			if (responseCode == 200) {
				// System.out.println("Get Response is Successfull");
				BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}
			}
			OTP = result.toString();
		} catch (Exception ex) {
			Log.info("== OTP Get Response failed, Attempting OTP from Browser ==");
			OTP = getOTPBrowser(mobileNo, bank, event);
		}

		if (OTP.length() != 6) {
			Log.info("== Invalid OTP : " + OTP + "==");
			OTP = getOTPChrome(mobileNo, bank, event);
		}

		return OTP.split("\n")[0];
	}

	/**
	 * Gets the otp from DB corresponding to the given Event.
	 *
	 * @param mobileNo the mobile no
	 * @param bank     the bank
	 * @param event    the event
	 * @return the otp
	 */
	public static String getOTPBrowser(String mobileNo, String bank, String event) {
		String otp = "";
		WebDriver driver = null;

		try {

			driver = createFirefoxDriver();

			String URL = getPropValues("OTPURL" ).replace("AccessData", mobileNo)
					.replace("ProgramId", bank).replace("EventId", event);
			driver.get(URL);
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			otp = driver.findElement(By.xpath("//body")).getText().trim();
		} catch (Exception e) {
			Log.info("== Error retreiving OTP ==");
		} finally {
			if (driver != null)
				driver.quit();
		}

		if (otp.isEmpty())
			otp = getOTPChrome(mobileNo, bank, event);
		return otp;
	}

	public static String getOTPChrome(String mobileNo, String bank, String event) {
		String otp = "";
		System.setProperty("webdriver.chrome.driver", "./config/chromedriver.exe");
		WebDriver driver = null;

		try {

			driver = createChromeDriver();
			String URL = getPropValues("OTPURL").replace("AccessData", mobileNo)
					.replace("ProgramId", bank).replace("EventId", event);
			driver.get(URL);
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			otp = driver.findElement(By.xpath("//body")).getText().trim();
		} catch (Exception e) {
			Log.info("== Error retreiving OTP from Chrome ==");
		} finally {
			if (driver != null)
				driver.quit();
		}
		if (otp.isEmpty())
			Log.info("== Error retreiving OTP from Chrome ,OTP is blank ==");

		Log.info("== OTP " + otp + " was retrieved using Chrome driver ==");
		return otp;

	}

	/**
	 * Waits until the given text is visible inside the element.
	 *
	 * @param driver         the driver
	 * @param element        the element
	 * @param text           the text
	 * @param timeoutSeconds the timeout seconds
	 * @return true, if successful
	 */
	public static boolean waitUntilElementTextVisible(WebDriver driver, WebElement element, String text,
			int timeoutSeconds) {

		if (isIos(driver))
			return false; // TBI

		String content;
		for (int i = 0; i < timeoutSeconds; i++) // Need to create separate method for element Attribute visible, cannot
													// include getAttribute() here
		{
			wait(1);
			content = element.getText();
			if (!(content.toLowerCase().contains(text.toLowerCase()) || content.equals("")))
				return true;

		}
		return false;
	}

	/**
	 * Waits until an element is populated by text.
	 *
	 * @param driver
	 * @param element
	 * @param timeoutSeconds
	 */
	public static String waitUntilAnyTextVisible(WebDriver driver, WebElement element, int timeoutSeconds) {
		String content;
		for (int i = 0; i < timeoutSeconds; i++) // Need to create separate method for element Attribute visible, cannot
													// include getAttribute() here
		{
			wait(1);
			content = element.getText();
			if (!content.isEmpty()) {
				Log.info("======== Element text found : " + content + " ========");
				return content;
			}
		}
		return "No Text found";
	}

	/**
	 * Verifies the balance deducted by comparing the balances before and after
	 * transaction.
	 *
	 * @param balanceBeforeTransaction the balance before transaction
	 * @param amt                      the amt
	 * @param balanceAfterTransaction  the balance after transaction
	 */
	public static void verifyBalanceDeduct(double balanceBeforeTransaction, double amt,
			double balanceAfterTransaction) {
		if (checkEnv("qa"))
			return; // program cards currently not recognised in QA
		Log.info("======== Balance before transaction : " + balanceBeforeTransaction + " ========");
		Log.info("======== Balance after transaction : " + balanceAfterTransaction + " ========");
		Log.info("======== Verifying deducted balance :" + amt + " ========");
		Assert.assertEquals(balanceBeforeTransaction - balanceAfterTransaction, amt, 0.05,
				" Balance amount not deducted correctly \n ");
	}

	/**
	 * This method verifies balance is unchanged
	 * 
	 */
	public static void verifyBalanceUnchanged(double balanceBeforeTransaction, double balanceAfterTransaction) {
		Log.info("======== Balance before transaction : " + balanceBeforeTransaction + " ========");
		Log.info("======== Balance after transaction : " + balanceAfterTransaction + " ========");
		Assert.assertTrue(balanceAfterTransaction == balanceBeforeTransaction, "======== Balance changed ========");
	}

	/**
	 * Verifies the balance added by comparing the balances before and after
	 * transaction.
	 *
	 * @param balanceBeforeTransaction the balance before transaction
	 * @param amt                      the amt
	 * @param balanceAfterTransaction  the balance after transaction
	 */
	public static void verifyBalanceAdded(double balanceBeforeTransaction, double amt, double balanceAfterTransaction) {
		// if(checkEnv("qa")) return; // program cards currently not recognised in QA
		Log.info("======== Balance before transaction : " + balanceBeforeTransaction + " ========");
		Log.info("======== Balance after transaction : " + balanceAfterTransaction + " ========");
		Log.info("======== Verifying added balance :" + amt + " ========");
		Assert.assertEquals(balanceAfterTransaction - balanceBeforeTransaction, amt, 0.05,
				" Balance amount not added correctly \n ");
	}

	/**
	 * Returns the month name corresponding to the month index
	 * 
	 * @param monthIndex
	 * @return
	 */
	public static String getMonthName(int monthIndex) {
		if (monthIndex <= 12)
			return new DateFormatSymbols().getMonths()[monthIndex - 1].toString();
		else
			return "October";
	}

	/**
	 * 
	 * @return Integer value for current month
	 */
	public static int getCurrentMonth() {
		return Calendar.getInstance().get(Calendar.MONTH) + 1;
	}

	/**
	 * 
	 * @return Integer value for current year
	 */
	public static int getCurrentYear() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}

	/**
	 * Performs a static wait for the given number of seconds.
	 *
	 * @param Seconds the seconds
	 */
	public static void wait(int Seconds) {
		try {
			Thread.sleep(Seconds * 1000);
		} catch (InterruptedException e) {
		}
	}

	/**
	 * IOS Only. Imitates the Settings API for Android .
	 * Setting.WAIT_FOR_IDLE_TIMEOUT
	 * 
	 * @param driver
	 * @param element
	 * @param timeout
	 */
	public static void waitUntilIOSElementVisible(WebDriver driver, WebElement element, int timeout) {
		if (!isIos(driver))
			return;

		// for int i 1 to timeout
		for (int i = 0; i < timeout; i++)
			if (getAttribute(element, "visible").equals("true"))
				return;
			else
				wait(1);

		System.out.println("Warning : Element not yet visible");
	}

	public static void waitForEmbeddedWebview(WebDriver driver, int seconds) {
		if (!checkAndroid(driver))
			return;

		String xp = "//*[contains(@class,'android.view') or contains(@class,'android.webkit')]";

		try {
			new WebDriverWait(driver, seconds).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
			Log.info("======== Context currently in Embedded WebView ========");
		} catch (Exception e) {
			Log.info("== WebView Delay ==");
		}
	}

	/**
	 * Requires setWebContentsDebuggingEnabled=true by App developer Waits for
	 * embeddedWebView
	 * 
	 *
	 * @param driver the driver
	 * @return true, if successful
	 */
	public static boolean switchToWebView(WebDriver driver) {
		/*
		 * if(getAndroidVersion(driver).split("v")[1].split("\\.")[0].equals("4")) {
		 * System.out.println("Unable to Switch to WebView for Android"
		 * +getAndroidVersion(driver));return false; }
		 */

		waitForEmbeddedWebview(driver, 90);
		if (checkWebView(driver))
			return true;

		AndroidDriver adriver = (AndroidDriver) driver;

		Set<String> contexts = adriver.getContextHandles();

		Log.info("== Contexts : " + contexts + " ==");

		for (String context : contexts)
			if (context.contains("WEB") && !context.contains("chrome") && context.contains("bdo")) // skip
																									// WEBVIEW_chrome ,
																									// select
																									// WEBVIEW_com.enstage.wibmo.sdk.test
			{
				System.out.println("Switching to " + context);
				Generic.wait(1);
				adriver.context(context);
				Generic.wait(1);
			}
		// adriver.context("WEBVIEW_com.enstage.wibmo.sdk.test");

		Log.info("== Context After Switching to WebView : " + adriver.getContext() + " == ");
		if (!adriver.getContext().contains("WEB")) {
			Log.info("== Unable to Switch To WebView ==");
			return false;
		} else
			return true;
	}

	public static void switchToNative(WebDriver driver) {
		if (!checkWebView(driver) || !checkAndroid(driver))
			return;

		AndroidDriver adriver = (AndroidDriver) driver;

		Set<String> contexts = adriver.getContextHandles();

		System.out.println("Switching to Native");

		for (String context : contexts)
			if (context.contains("NATIVE"))
				adriver.context(context);

		System.out.println("Context After Switch : " + adriver.getContext());
	}

	/**
	 * Verifies the Toast message.
	 *
	 * @param driver       the driver
	 * @param toastContent to be verified
	 * @return Toast Message text
	 */
	public static String verifyToastContent(WebDriver driver, String toastContent) {
		if (!Generic.isUiAuto2(driver))
			return ""; // Check for version >= Android 6 & UiAuto2
		if (Generic.getAPILevel(getUdId(driver)) <= 22)
			return "";

		String toastTxt = "", txp = "//*[contains(@text,'toastContent')]".replace("toastContent", toastContent);

		try {
			new WebDriverWait(driver, 30).pollingEvery(1, TimeUnit.SECONDS)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath(txp))); // polling necessary for Uiauto2

			toastTxt = driver.findElement(By.xpath(txp)).getText();

			Log.info("======== Verifying Toast message : " + toastTxt + " ========");
			return toastTxt;

		} catch (Exception e) {
			Assert.fail("Toast Message with content " + toastContent + " not found " + e.getMessage());
		}

		return toastTxt;
	}

	public static void angularWait(WebDriver driver) {

		try {
			driver.manage().timeouts().setScriptTimeout(25, TimeUnit.SECONDS);
			new NgWebDriver((JavascriptExecutor) driver).waitForAngularRequestsToFinish();
		} catch (Exception e) {
			Log.info("== JS Exception ==" + e.getMessage().split(":")[0]);
		}
	}

	public static void waitForElement(WebDriver driver, WebElement element, int timeOutInSeconds) {
		try {
			new WebDriverWait(driver, timeOutInSeconds).until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			Log.info("== Timed out waiting for element ==");
		}
	}

	public static boolean checkWebView(WebDriver driver) {
		if (!checkAndroid(driver))
			return false;

		return ((AndroidDriver) driver).getContext().contains("WEB");
	}

	public static boolean checkNativeApp(WebDriver driver) {
		if (!checkAndroid(driver))
			return false;

		AndroidDriver adriver = (AndroidDriver) driver;

		System.out.println("Checking Native App context : " + adriver.getContext());

		return adriver.getContextHandles().contains("NATIVE") && adriver.getContextHandles().size() == 1;
	}

	/**
	 * Checks whether any of the text arguments are present in the pageSource Any
	 * number of comma separated text arguments can be passed
	 * 
	 * @param driver the driver
	 * @return the String among the String args if pageSource contains any of the
	 *         String args. "notFound" if none of the args are found
	 * 
	 */
	public static String checkTextInPageSource(WebDriver driver, String... args) {
		if (isIos(driver))
			return "notFound"; // pageSource command not reliable for IOS

		String pageSource = driver.getPageSource();

		for (String text : args) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException ie) {
			} // Prevent target server exception
			if (pageSource.contains(text))
				return text;
		}
		return "notFound";
	}

	/**
	 * Waits for Phone verification page to occur and then cancels the Phone
	 * verification.
	 *
	 * @param driver the driver
	 */
	public static void abortPhoneVerification(WebDriver driver) // BT1
	{
		waitForPhoneVerification(driver);
		if (driver.findElement(By.id("title_text")).getText().contains("Verify")) {
			Log.info("======== Aborting Phone verification ========");
			driver.navigate().back();
		}
	}

	/**
	 * Waits for phone verification page to occur.
	 *
	 * @param driver the driver
	 */
	public static void waitForPhoneVerification(WebDriver driver) // BT1
	{
		String xp = "//android.widget.TextView[contains(@text,'Verify')]";
		try {
			new WebDriverWait(driver, 40).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xp)));
		} catch (Exception e) {
			Assert.fail("Phone Verification page not found\n" + e.getMessage());
		}
	}





	/**
	 * Launches the given package name and activity
	 * 
	 * @param driver
	 * @param pkgName
	 * @param activityName
	 */
	public static void startAppActivity(WebDriver driver, String pkgName, String activityName) {
		((AndroidDriver) driver).startActivity(new Activity(pkgName, activityName));
	}

	/**
	 * @author aravindanathdm
	 * 
	 *         Launches the iOS app
	 * @param driver
	 * @param bundleId
	 */

	public static void startAppActivity(WebDriver driver, String bundleId) {
		((IOSDriver<WebElement>) driver).activateApp(bundleId);
	}

	/**
	 * Returns the the current activity of the Android driver.
	 *
	 * @param driver the driver
	 * @return the current activity
	 */
	public static String getCurrentActivity(WebDriver driver) {
		return ((AndroidDriver) driver).currentActivity();
	}

	public static SessionId getSessionId(WebDriver driver) {
		if (!checkAndroid(driver))
			return null;

		System.out.println("Returning Session Id");

		return ((AndroidDriver) driver).getSessionId();
	}

	public static void openNotifications(WebDriver driver) {
		((AndroidDriver) driver).openNotifications();
		Generic.wait(1); // Wait for Multiple Notifications to settle

	}

	public static void openNotificationsAndClickTxt(WebDriver driver, String txt) {
		boolean notificationFound = true;
		String txtXpath = "//*[contains(@text,txt)]".replace("txt", txt);

		Generic.openNotifications(driver);

		Log.info("======== Clicking on Notiifcation Text : " + txtXpath + " ========");

		try {
			driver.findElement(By.xpath(txtXpath)).click();
		} catch (Exception e) {
			notificationFound = false;
			Assert.fail("Send Money Notification not found");
		} finally {
			if (!notificationFound)
				switchToAppWithState(driver);
		}
	}

	/**
	 * @author aravindanath
	 * @param driver
	 */

	private static void showNotifications(WebDriver driver) {
		manageNotifications(true, driver);
	}

	/**
	 * * Mainly used for IOS
	 * 
	 * @author aravindanath
	 * @param driver
	 */

	private static void hideNotifications(WebDriver driver) {
		manageNotifications(false, driver);
	}

	/**
	 * @author aravindanath
	 * @param show
	 * @param driver
	 */

	private static void manageNotifications(Boolean show, WebDriver driver) {
		int yMargin = 5;
		Dimension screenSize = driver.manage().window().getSize();
		int xMid = screenSize.width / 2;
		PointOption top = PointOption.point(xMid, yMargin);
		PointOption bottom = PointOption.point(xMid, screenSize.height - yMargin);

		TouchAction action = new TouchAction((PerformsTouchActions) driver);
		if (show) {
			action.press(top);
		} else {
			action.press(bottom);
		}
		action.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)));
		if (show) {
			action.moveTo(bottom);
		} else {
			action.moveTo(top);
		}
		action.perform();
	}

	public static void gotoIAPFromNotifications(WebDriver driver) {
		openNotifications(driver);

		String notificationXp = "//*[contains(@text,'InApp')]";

		Log.info("======== Clicking on Notification ========");
		try {
			driver.findElement(By.xpath(notificationXp)).click();
		} catch (Exception e) {
			Assert.fail("Required Notification not found\n");
		}
	}

	/**
	 * Opens Notifications . Clicks on Notifications & navigates to Messages to
	 * verify the SMS message
	 * 
	 * @param driver
	 * @param notificationTxt
	 * @param smsContent
	 * @param waitTimeForNotification
	 * 
	 */
	public static void verifySMSContentFromNotifications(WebDriver driver, String notificationTxt, String smsContent,
			int waitTimeForNotification) {
		boolean notificationFound = false;
		Generic.wait(waitTimeForNotification);
		if (Generic.isAndroid(driver)) {
			openNotifications(driver);
			String notificationXp = "//*[contains(@text,'notificationTxt')]".replace("notificationTxt",
					notificationTxt), contentXp = "//*[contains(@text,'smsContent')]".replace("smsContent", smsContent);
			Log.info("======== Clicking on Notification with notification Text : " + notificationTxt + " ========");
			try {
				driver.findElement(By.xpath(notificationXp)).click();
				wait(1);
				driver.findElement(By.xpath(notificationXp)).click(); // Handle Selection from multiople notiifcations
				wait(1);
				driver.findElement(By.xpath(notificationXp)).click();

				notificationFound = true;

			} catch (Exception e) {
				try {
					Assert.fail("Notification with " + notificationTxt + " text not found ");
				} finally {

					if (!notificationFound) {
						Log.info("=== Navigating Back to close Notifications ===");
						switchToAppWithState(driver);
					}

				}
			}
			try {
				Log.info("======== Verifying SMS Content : " + (driver.findElement(By.xpath(contentXp)).getText())
						+ " ========");
			} catch (Exception e) {
				Assert.fail("SMS not found");
			} finally {
				Generic.wait(5);
				driver.navigate().back();
			} // Navigate Back to AppActivity

			/**
			 * @author aravindanath This method will handle push notification on ios
			 *         devices.
			 */

		} else if (Generic.isIos(driver)) {
			Generic.showNotifications(driver);
			Generic.wait(3);
			Generic.hideNotifications(driver);
		}

	}

	public static void verifyNotificationAbsent(WebDriver driver) {
		openNotifications(driver);

		String notificationXp = "//*[contains(@text,'InApp')]";
		Log.info("======== Verifying Absence of Notification ========");

		if (checkElementOccurenceOnXpath(driver, notificationXp, 3))
			Assert.fail("Notification message found");

	}

	/**
	 * Resets the Thread static fields as true i.e ready to handle popups.
	 */
	public static void resetPopups() {
		// HandleHomePopup.handled=HandleOverlayPopup.handled=HandleLoginPopup.handled=false;
	}

	public static void resetPopups(WebDriver driver) {
		// HandleHomePopup.handled=HandleOverlayPopup.handled=HandleLoginPopup.handled=false;
		// HandleHomePopup.setHandledStatus(driver, false);
	}

	/**
	 * Sets the driver implicit wait to a lower timeout value.
	 *
	 * @param driver       the driver
	 * @param shortTimeout the short timeout
	 */
	public static void quicken(WebDriver driver, int shortTimeout) {
		driver.manage().timeouts().implicitlyWait(shortTimeout, TimeUnit.SECONDS);
	}

	/**
	 * Sets the driver implicit wait to a normal timeout value..
	 *
	 * @param driver        the driver
	 * @param normalTimeout the normal timeout
	 */
	public static void normalize(WebDriver driver, int normalTimeout) {
		driver.manage().timeouts().implicitlyWait(normalTimeout, TimeUnit.SECONDS);
	}

	/**
	 * Checks whether the containedString is present within the containerString
	 * while ignoring the case.
	 *
	 * @param containerString the container string
	 * @param containedString the contained string
	 * @return true, if successful
	 */
	public static boolean containsIgnoreCase(String containerString, String containedString) {
		return containerString.toLowerCase().contains(containedString.toLowerCase());
	}

	/**
	 * Parses the number present in the given string.
	 *
	 * @param numberText the number text
	 * @return the number in double which is present within the text

	 */
	public static double parseNumber(String numberText) {
		return Double.parseDouble(parseNumberString(numberText));
	}

	public static String parseNumberString(String numberText) {
		String number = "";
		char c;
		for (int i = 0; i < numberText.length(); i++) {
			c = numberText.charAt(i);
			if (Character.isDigit(c) || c == '.')
				number += c;
		}
		return number;
	}

	/**
	 * Converts the given value to implied decimal
	 * 
	 * @param val
	 * @return implied decimal String
	 */
	public static String convertToImpliedDecimal(String val) {
		return (Integer.parseInt(val) * 100) + "";
	}

	// Deprecated after IAP parallel integration
	public static String parseCVVStatus(String data) {
		if (!data.contains("CVV"))
			Assert.fail(" 'CVV' Status value not found in TestData :" + data);

		String value = data.split("CVV")[1].substring(0, 1);

		Log.info("======== Parsing CVV value from testdata : " + value + " ========");

		if (containsIgnoreCase(value, "Y"))
			return "Yes";
		if (containsIgnoreCase(value, "N"))
			return "No";

		return "Unknown";
	}

	/**
	 * Retrieves the data value from TestData based on the dataLabel
	 * 
	 * Ex : For TestData 9066946245,1234,panNumber_ABCDE1234P Use dataLabel as
	 * panNumber_ or panNumber to retrieve ABCDE1234P
	 * 
	 * @param driver
	 * @param data
	 * @param dataLabel
	 * @return
	 * @see BaseTest1 getVal()
	 */
	public static String parseDataVal(WebDriver driver, String data, String dataLabel) {
		if (!data.contains(dataLabel)) {
			System.err.println(dataLabel + " label not found in Testdata : " + data);
			return "nullVal";
		}

		dataLabel = data.contains(dataLabel + '_') ? dataLabel + '_' : dataLabel; // Parse label_ as well as label

		return data.split(dataLabel)[1].split(",")[0];
	}

	public static String parseReferralCode(String data) {
		if (!data.contains("RC_"))
			Assert.fail("Referral Code RC_referralCode not found in Test Data : " + data);

		return data.split("RC_")[1].substring(0, 6);
	}

	/**
	 * Generates a mobile number.
	 * 
	 * @return String
	 */
	public static String generateMobileNumber() {
		long x = 7000000000L;
		long y = 8999999999L;

		Random r = new Random();

		long number = x + ((long) (r.nextDouble() * (y - x)));

		System.out.println("Number generated " + number);

		return number + "";
	}

	public static char generateRandomChar() {
		Random r = new Random();
		return (char) (r.nextInt(26) + 'A');
	}

	public static String randomPAN() {
		final String randomString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final java.util.Random rand = new java.util.Random();
		// consider using a Map<String,Boolean> to say whether the identifier is
		// being used or not
		final Set<String> identifiers = new HashSet<String>();
		int min = 1001;
		int max = 9998;
		int randomNum = ThreadLocalRandom.current().nextInt(min, max + 1);
		StringBuilder builder = new StringBuilder();
		while (builder.toString().length() == 0) {
			for (int i = 0; i < 5; i++) {
				builder.append(randomString.charAt(rand.nextInt(randomString.length())));
			}
			builder.append(randomNum);
			for (int i = 0; i < 1; i++) {
				builder.append(randomString.charAt(rand.nextInt(randomString.length())));
			}
			if (identifiers.contains(builder.toString())) {
				builder = new StringBuilder();
			}
		}
		return builder.toString();
	}

	public static String getBootStrapPort(String port) {
		long x = 1023;
		long y = 65535;

		String bootStrapPort = "";

		Random r = new Random();

		long number = x + ((long) (r.nextDouble() * (y - x)));

		System.out.println("Number generated " + number);

		// ----------------------//

		int separator = Integer.parseInt("" + (port.charAt(r.nextInt(port.length() - 1))));

		bootStrapPort = separator + number + "";

		// ---------------------//

		return separator + number + "";
	}

	public static String generateAlphaNumeric() {
		return UUID.randomUUID().toString().replace("-", "").substring(0, 10);
	}

	/**
	 * Checks whether the given mobile no. can receive OTP.
	 * 
	 * @return true if mobile can receive OTP.
	 */
	public static boolean checkOTPMobile(String mobileNo) {
		return Integer.parseInt(mobileNo.substring(0, 1)) > 6;
	}



	public static boolean checkAndroid(WebDriver driver) {
		if (driver == null)
			return false;

		System.out.println("driver type : " + driver.toString());
		return Generic.containsIgnoreCase(driver.toString(), "Android");
	}

	/**
	 * Checks whether a given udid belongs to an IOS device
	 * 
	 * @param udid
	 * @return true if yhe udid is ios

	 */
	public static boolean isIos(String udid) {
		return udid.length() > 24;
	}

	/**
	 * Checks whether the device is an emulator or not
	 * 
	 * 
	 * @param udid
	 * @return true if device is an emulator
	 */
	public static boolean isEmulator(String udid) {
		return udid.contains("emu") || udid.contains("."); // Cloud emulator as 192.168.239.101:5555
	}

	public static boolean isEmulator(WebDriver driver) {
		return isEmulator(getUdId(driver));
	}

	public static boolean isIos(WebDriver driver) {

		if (driver == null)
			System.err.println("Warning : Driver not initialized");

		return driver != null && driver.toString().toLowerCase().contains("ios");
	}

	/**
	 * Checks whether the driver is Android
	 * 
	 * @param driver
	 * @return true if driver is AndroidDriver
	 * 
	 */
	public static boolean isAndroid(WebDriver driver) {
		return driver != null && driver.toString().toLowerCase().contains("android");
	}

	/**
	 * Checks whether the given driver is WebDriver or not
	 * 
	 * @param driver
	 * @return true if driver is WebDriver
	 */
	public static boolean isWebDriver(WebDriver driver) {
		if (driver == null)
			return false;

		String driverChk = driver.toString().toLowerCase();
		return !driverChk.contains("android") && !driverChk.contains("ios"); // AndroidDriver contains ChromeDriver path

	}

	/**
	 * 
	 * 
	 * @param driver
	 * @return
	 */

	public static boolean isUiAuto2(WebDriver driver) {
		if (checkAndroid(driver))
			return ((AndroidDriver) driver).getAutomationName().contains("2"); // UiAuto2 driver
		else
			return false;
	}

	/**
	 * Exception to be caught from calling method. IOS logic can be implemented for
	 * wait until visible=true for the given element
	 * 
	 * @param element
	 */
	public synchronized static boolean isDisplayed(WebElement element) {
		return element.isDisplayed();
	}

	/**
	 * Exception to be caught from calling method. IOS logic can be implemented for
	 * wait until visible=true for the given element
	 *
	 * @param element
	 */
	public synchronized static boolean isDisabled(WebElement element) {
		return !element.isEnabled();
	}

	/**
	 * Exception to be caught from calling method. IOS logic can be implemented for
	 * wait until visible=true for the given element
	 *
	 * @param element
	 */
	public synchronized static boolean isEnabled(WebElement element) {
		return element.isEnabled();
	}

	/**
	 * Retrieves the device model from adb shell.
	 *
	 * @deprecated Use getDeviceModel(WebDriver driver) instead
	 * @return the device model
	 */
	public static String getDeviceModel() {
		String model = "", cmdOutput = "", cmd = "adb devices -l", productCmd = "adb shell getprop ro.product.brand",
				product = "";

		// ---- Obtain model ---- //
		try {
			cmdOutput = execCmd(cmd);
			model = cmdOutput.split("\\n")[1].split("\\s+")[3].split(":")[1];
			Log.info("======== Obtaining device model : " + model + " ========");
		} catch (Exception e) {
			Log.info("==== Could not obtain Device Model ====" + e.getMessage());
		}

		try {
			product = execCmd(productCmd).trim();
		} catch (Exception e) {
			Log.info("==== Could not obtain Product Name ====" + e.getMessage());
		}
		if (Generic.containsIgnoreCase(model, product))
			product = "";

		return product + " " + model;
	}

	/*
	 * Refreshes Android DOM to avoid UiAuto2 StaleElement . Use Sparingly.
	 * 
	 */
	public static void refreshAndroidDOM(WebDriver driver) {
		if (!isAndroid(driver))
			return;

		System.out.println("Refreshing Android DOM");
		driver.findElement(By.xpath("//*"));

	}
	/**
	 * Retrieves the device Android Version from adb shell.
	 *
	 * @return the Version
	 */
	/*
	 * public static String getAndroidVersion() { String
	 * version="",cmd="adb shell getprop ro.build.version.release";
	 * 
	 * if(multipleDevices) cmd="adb -s "+getExecutionDeviceId(driver)
	 * +" shell getprop ro.build.version.release";
	 * 
	 * try { String cmdOutput=execCmd(cmd);
	 * 
	 * if(!cmdOutput.toLowerCase().contains("error:")) version=cmdOutput.trim();
	 * 
	 * Log.info("======== Obtaining Android version : "+version+" ========"); }
	 * catch(Exception e) {
	 * Log.info("==== Could not obtain Android version ===="+e.getMessage());
	 * version="default"; } return version; }
	 */

	/**
	 * Retrieves the Device model with Android Version
	 * 
	 * @param driver
	 * @return
	 */
	public static String getDeviceModel(WebDriver driver) {

		if (!checkAndroid(driver))
			return "WebDriverExecution";

		AndroidDriver adriver = (AndroidDriver) driver;
		String model = "", product = "";
		String modelCmd = "adb -s udid shell getprop ro.product.model".replace("udid", getUdId(driver)),
				productCmd = "adb -s udid shell getprop ro.product.brand".replace("udid", getUdId(driver));

		// System.out.println("Capabilities : "+adriver.getCapabilities());

		if (adriver.getAutomationName().contains("2")) // UiAuto2
		{
			model = execCmd(modelCmd).split("[A-Za-z0-9]*")[0];
			product = execCmd(productCmd).split("\\W+")[0];
		} else {
			model = (String) adriver.getCapabilities().getCapability("deviceModel");
			product = (String) adriver.getCapabilities().getCapability("deviceManufacturer");
		}

		Log.info("======== Retreiving device model : " + model + " ========");

		if (Generic.containsIgnoreCase(model, product))
			product = "";

		return product + " " + model + getAndroidVersion(driver);
	}

	/**
	 * Retrieves the device Android Version from Capabilities.
	 *
	 * @return the Version
	 */
	public static String getAndroidVersion(WebDriver driver) {
		if (!checkAndroid(driver))
			return "";

		String versionCmd = "adb -s udid shell getprop ro.build.version.release".replace("udid", getUdId(driver));

		AndroidDriver adriver = (AndroidDriver) driver;

		String ver = "";
		try {
			ver = adriver.getAutomationName().contains("2") ? // UiAuto2
					execCmd(versionCmd) : (String) (adriver).getCapabilities().getCapability("platformVersion");
		} catch (Exception e) {
			Log.info("==== Unable to obtain Android Version ====\n" + e.getMessage());
		}
		return " v" + ver;
	}

	public static synchronized int getAPILevel(String udid) {
		String verCmd = "adb -s " + udid + " shell getprop ro.build.version.sdk";
		try {
			return Integer.parseInt(execCmd(verCmd).substring(0, 2));
		} catch (Exception e) {
			System.err.println("Unable to obtain API level for " + udid + e.getMessage());
			return 23;
		}
	}


	public static void androidM(WebDriver driver) // DeviceSpecific
	{
		try // Does not work . As soon as Update Service is stopped , It restarts again
			// resulting in unmanageable popup.
		{
			if (getExecutionDeviceId(driver).contains("ZY"))
				Runtime.getRuntime().exec("adb shell am force-stop com.motorola.ccc.ota");
		} catch (Exception e) {
			System.err.println("Unable to stop Moto update service ");
		} catch (Error e) {
			System.err.println("Unable to stop Moto update service ");
		}
	}

	/**
	 * Retrieves the device screen resolution from adb shell.
	 *
	 * @return String the ScreenResolution
	 */
	/*
	 * public static String getScreenResolution() { String
	 * res="default",cmd="adb shell dumpsys window";
	 * 
	 * if(multipleDevices) cmd="adb -s "+executionDeviceId+" shell dumpsys window";
	 * 
	 * try { String cmdOutput=execCmd(cmd);
	 * 
	 * if(!cmdOutput.toLowerCase().contains("error:"))
	 * res=execCmd(cmd).split("init=")[1].split("\\s")[0];
	 * 
	 * Log.info("======== Obtaining device screen resolution : "+res+" ========"); }
	 * catch(Exception e) {
	 * com.libraries.Log.info("==== Could not obtain screen resolution ===="+e.
	 * getMessage()); res="default"; } return res; }
	 */

	/**
	 * Retrieves the device screen resolution from driver
	 *
	 * @return String the ScreenResolution
	 */
	public static String getScreenResolution(WebDriver driver) {
		String res = "";
		try {
			res = driver.manage().window().getSize().width + "X" + driver.manage().window().getSize().height;
		} catch (Exception e) {
			// com.libraries.Log.info("==== Unable to obtain Screen resolution ====\n" +
			// e.getMessage());
		}
		return res;
	}


	/**
	 * Retrieves the App Version from adb shell. Returns the Base Version if app
	 * updates are installed.
	 *
	 * @return String the App Version
	 */
	public static String getAppVersion(String udid, String pkgName) {
		String ver = "DefaultVersion" + udid;
		String cmd = "adb -s " + udid + " shell dumpsys package " + pkgName + " | grep versionName";
		String cmdOutput;

		try {
			cmdOutput = execProcess(cmd);
			ver = cmdOutput.split("=")[cmdOutput.split("=").length - 1]; // return the base version from output
		} catch (Exception e) {
			// com.libraries.Log.info("~ Unable to obtain App version ~\n" +
			// e.getMessage());
		}

		return ver;
	}

	/**
	 * Executes a command line command and returns the output as a String
	 *
	 * @return String the command output
	 */
	public static String execCmd(String cmd) // throws java.io.IOException
	{
		try {
			java.util.Scanner s = new java.util.Scanner(Runtime.getRuntime().exec(cmd).getInputStream())
					.useDelimiter("\\A");

			String cmdOutput = s.hasNext() ? s.next() : "";
			s.close();
			return cmdOutput; // Implement close logic by storing in separate string before returning
		} catch (Exception e) {
			System.err.println("-- Unable to execute command " + cmd + " --" + e.getMessage());
			return "";
		}

	}

	public static String execProcess(String processCmd) {
		String output = "noRes";

		try {
			ProcessBuilder pb = new ProcessBuilder(processCmd.split(" "));
			output = IOUtils.toString(pb.start().getInputStream());
		} catch (Exception e) {
		}
		return output;
	}

	/**
	 * Checks whether an Alert is present or not and handles the Alert. Extra alerts
	 * are generated while using ChromeDriver
	 *
	 */
	public static void checkAlert(WebDriver driver) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			Log.info("==== Handlng optional alert : " + alert.getText() + "====");
			alert.accept();
		} catch (Exception e) {
			Log.info("==== Optional Alert not found ====");
		}
	}

	/**
	 * Executes a javascript click
	 * 
	 * @param driver
	 * @param element to be clicked
	 */
	public static void javascriptClick(WebDriver driver, WebElement element) {
		System.out.println("Executing JS Click ");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click()", element);
	}

	/**
	 * Checks for the occurrence of the given element
	 * 
	 * @param driver
	 * @param element
	 * @param timeoutSeconds
	 * @return true if the element occurs

	 */
	public static boolean checkElementOccurenceOverrideImplicit(WebDriver driver, WebElement element,
			int timeoutSeconds) {
		try {
			driver.manage().timeouts().implicitlyWait(timeoutSeconds, TimeUnit.SECONDS); // Use 0 on observation

			WebDriverWait wait = new WebDriverWait(driver, timeoutSeconds);
			wait.until(ExpectedConditions.visibilityOf(element));

			return true;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	/**
	 * 
	 * @param driver
	 * @param xp
	 * @param timeoutSeconds
	 * @return
	 */
	public static boolean checkElementOccurenceOnXpath(WebDriver driver, String xp, int timeoutSeconds) {
		boolean occurence;
		try {
			driver.manage().timeouts().implicitlyWait(timeoutSeconds, TimeUnit.SECONDS); // Use 0 or 1 on observation

			occurence = driver.findElements(By.xpath(xp)).size() > 0;

			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			return occurence;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public static boolean checkElementOccurence(WebDriver driver, WebElement element, int timeoutSeconds,
			String locatorAttribute) {
		boolean occurence = false;

		System.out.println("~--- Checking Element Occurence ---~");

		// locatorAttribute as "resourceId" or "name"
		driver.manage().timeouts().implicitlyWait(timeoutSeconds, TimeUnit.SECONDS);
		try {
			if (Generic.containsIgnoreCase(locatorAttribute, "Id"))
				occurence = driver.findElements(By.id(element.getAttribute("resourceId"))).size() > 0;

			if (Generic.containsIgnoreCase(locatorAttribute, "Name"))
				occurence = driver.findElements(By.name(element.getAttribute("contentDescription"))).size() > 0;

			return occurence;
		} catch (Exception e) {
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
	}

	public static String regInsensitive(String text) {
		return "(?i:" + text + ")";
	}

	/**
	 * To be used wherever sendKeys cannot be used . UiAuto2 limited TxtField
	 * workaround for Android 5
	 * 
	 * @param driver
	 * @param element
	 * @param text

	 */
	public static void setValue(WebDriver driver, WebElement element, String text) {

		Log.info("======== Executing setValue : " + text + " ========");
		if (isIos(driver)) {
			System.out.println("Setting value attribute ");
			IOSElement iElement = (IOSElement) element;
			iElement.setValue(text);
		} else // Android
		{
			element.click();
			try {
				new ProcessBuilder(
						new String[] { "adb", "-s", getExecutionDeviceId(driver), "shell", "input", "text", text })
								.redirectErrorStream(true).start();
			} catch (Exception e) {
				e.printStackTrace();
			} // UiAuto2 for Android 5 workaround
		}

	}

	/**
	 * Currently used for IOS only. Clicks on the co-ordinates of the element
	 * 
	 * Can be updated to use MobilElement.getCenter().x & y;
	 */
	public static void coOrdinateClick(WebDriver driver, WebElement element) {
		if (!isIos(driver))
			return;

		int x = 0, y = 0;

		try {
			Point coOrdinates = element.getLocation();
			x = coOrdinates.x;
			y = coOrdinates.y;

			IOSDriver<WebElement> iDriver = (IOSDriver<WebElement>) driver;
			TouchAction touchAction = new TouchAction(iDriver);

			System.out.println("Clicking on Co-ordinates : " + x + ' ' + y);
			touchAction.press(PointOption.point(x, y)).release().perform();

		} catch (Exception e) {
			Log.info("Error in Co-ordinate click on " + x + " " + y + e.getMessage());
		}
	}

	/**
	 * 
	 * Closes a non AUT app which is already open.
	 * 
	 * @param appName for Android , bundleId for IOS

	 * @update integrate isAppInstalled on pkgName and bundleId
	 * 
	 */
	public static void closeExternalApp(WebDriver driver, String appName) {
		if (isAndroid(driver)) {
			Log.info("======== Closing " + appName + " ========");
			String ytCloseBtnXpath = "//*[contains(@content-desc,'Dismiss appName')]" // Android X button
					.replace("appName", appName);

			navigateBack(driver);
		}
		if (isIos(driver)) {
			terminateIOSApp(driver, appName);
		}

		// Implement context swipe after AndroidKey.APP_SWITCH

//		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.APP_SWITCH));
//		Generic.wait(1); // Wait for open recents
//		
//		swipeLeft(driver); 
//		
//		driver.findElement(By.xpath(ytCloseBtnXpath)).click();
//		Generic.wait(1); // Wait for close 
//		
//		Log.info("======== Switching to previously opened app ========");
//		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.APP_SWITCH)); 

	}

	/**
	 * Executes a keyboard sendKeys on the previously focused element
	 * 
	 * @param driver
	 * @param text
	 */
	public static void keyboardSendKeys(WebDriver driver, String text) {

		Log.info("======== Executing Keyboard sendKeys : " + text + " ========");

		if (isAndroid(driver))
			((AndroidDriver<WebElement>) driver).getKeyboard().sendKeys(text);
		else
			((IOSDriver<WebElement>) driver).getKeyboard().sendKeys(text);

	}

	public static void pressEnter(WebDriver driver) {

		Log.info("======== Executing press enter method  ========");

		((AndroidDriver<WebElement>) driver).pressKeyCode(66);

	}

	/**
	 * Workaround for IOS WDA 'Element not interactable'
	 *
	 * @param driver
	 * @param txtField
	 * @param text
	 */
	public static void keyboardSendKeys(WebDriver driver, WebElement txtField, String text) {
		tap(driver, txtField);
		keyboardSendKeys(driver, text);
	}

	public static void clearVal(WebDriver driver, WebElement element) {
		AndroidDriver adriver = (AndroidDriver) driver;

		element.click();
		element.clear();
	}

//	public static void customSkip(WebDriver driver, String skipMsg) {
//		Log.skip(skipMsg);
//
//		new Prepaid.testScripts.BaseTest1().setSkipStatus(driver, true);
//	}

	public static void groupExecutePass(String testName) {
		Log.groupPass(testName);
	}

	/**
	 * 
	 * Row & Column numbers start from 0
	 * 
	 * @param csvVal
	 * @param rowNo
	 * @param colNo
	 * @param filePath
	 * 
	 */
	public static void writeCSV(String csvVal, int rowNo, int colNo, String filePath) {
		Log.info("======== Writing " + csvVal + " to Row " + rowNo + " and Col " + colNo + " at " + filePath
				+ " ========");

		List<String[]> csvEntries;

		try {
			CSVReader reader = new CSVReader(new FileReader(filePath));
			csvEntries = reader.readAll();

			csvEntries.get(rowNo)[colNo] = csvVal;

			CSVWriter writer = new CSVWriter(new FileWriter(filePath));
			writer.writeAll(csvEntries, false);

			// for(String[] stringArray:csvEntries)
			// writer.writeNext(stringArray);

			reader.close();
			writer.close();

		} catch (Exception e) {
			Assert.fail("Error reading CSV from " + filePath + " \n" + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Clears the given directory
	 * 

	 */
	public static void cleanDir(String relativePath) {
		if (!relativePath.startsWith("/"))
			relativePath = '/' + relativePath;

		File dir_to_clean = new File(BaseTest1.path + relativePath);
		System.out.println("Absolute Path of directory : " + dir_to_clean);

		try {
			FileUtils.cleanDirectory(dir_to_clean);
		} catch (IOException e) {
			System.err.println("Unable to clear directory at " + dir_to_clean);
			e.printStackTrace();
		}

	}

	public static void waitForDownload(File f) {
		long length1, length2;
		int timeout = 60, count = 0;

		System.out.println("Waiting for Download .." + f.getAbsolutePath());

		do {
			length1 = f.length(); // check file size
			wait(5);
			length2 = f.length(); // check file size again

			if (count++ == timeout)
				break;

		} while (length2 != length1);

	}

	public static void Zip(String sourceDirPath, String zipFilePath) throws IOException {
		Path p = Files.createFile(Paths.get(zipFilePath));
		try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p))) {
			Path pp = Paths.get(sourceDirPath);

			Files.walk(pp).filter(path -> !Files.isDirectory(path)).forEach(path -> {
				ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
				try {
					zs.putNextEntry(zipEntry);
					Files.copy(path, zs);
					zs.closeEntry();
				} catch (IOException e) {
					System.err.println(e);
				}
			});
		}
	}

	/**
	 * Waits until an operaion can be performed before clearing the TxtField
	 *
	 * @param driver
	 * @param element
	 */
	public static void clear(WebDriver driver, WebElement element) {
		if (isAndroid(driver)) // Android
			element.clear();
		else // IOS
		{
			waitUntilIOSElementVisible(driver, element, 30);
			element.clear();
		}

	}

	public static String[] getFilepathsInFolder(String relativeFolderPath) {
		String[] filePaths = { "Filepath1", "Filepath2" };
		int fileCount = 0;

		File folder = new File(relativeFolderPath);
		File[] listOfFiles = folder.listFiles();
		for (File file : listOfFiles) {
			if (file.isFile()) {
				System.out.println(file.getAbsolutePath());
				filePaths[fileCount++] = file.getAbsolutePath();
			}
		}

		return filePaths;
	}

	/**
	 * Generates a mobile number.
	 * 
	 * @return String
	 */
	public static String generateMobileNumber15Digits() {
		long x = 100000000000000L;
		long y = 499999999999999L;

		Random r = new Random();

		long number = x + ((long) (r.nextDouble() * (y - x)));

		System.out.println("Number generated " + number);

		return number + "";
	}

	/**
	 * 
	 * Simulates a tab and enter on the screen Android Only
	 * 
	 * @author rashmi
	 * @param driver the driver
	 * 
	 */
	public static void TapEnter(WebDriver driver) {
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
		; // KEYCODE_TAB
		wait(1);

	}

	/**
	 * 
	 * Simulates a tab and enter on the screen Android Only
	 * 
	 * @author rashmi
	 * @param driver the driver
	 * 
	 */
	public static void TapOnEnter(WebDriver driver) {
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		; // KEYCODE_TAB
		wait(1);

	}

	/**
	 * 
	 * @author aravindanathdm
	 * @param header
	 * @param key
	 * @param path
	 * @return
	 */

	public static String getValFromIni(String header, String key, String path) {

		String value = "";
		Ini ini = new Ini();
		try {
			InputStream input = new FileInputStream(path);
			ini.load(input);
		} catch (Exception e) {
			System.err.println(
					"--------------------------------------------------------------------------------------------------");
			System.err.println("Please Check The path of Ini file: Provided Path is: " + path);
			System.err.println(
					"--------------------------------------------------------------------------------------------------");
			System.out.println(e.toString());
			System.exit(0);
		}

		value = ini.get(header, key);
		return value;

	}


	/**
	 *
	 * @author Srikiran
	 * @param header
	 * @param key
	 * @param path
	 * @return
	 */

	public static void updateValToIni(String path, String header, String key, String value) throws Exception{
		Wini ini = new Wini(new File(path));
		ini.put(header, key, value);
	}

	/**
	 * @author aravindanath
	 * @param element
	 * @param expected
	 */

	public static void assertTitle(WebElement element, String expected) {
		String actual = element.getText();
		Log.info("======== Verifing title:  " + actual + " is displayed:  " + element.isDisplayed() + " ========");
		Assert.assertEquals(actual, expected, "MisMatch in actaul vs expected!");
	}

	/**
	 * @author aravindanath
	 * @param element
	 * @param contains
	 */
	public static void assertTitleContains(WebElement element, String contains) {
		String actual = element.getText();
		Log.info("======== Verifing title:  " + actual + " ========");
		Assert.assertTrue(actual.trim().contains(contains), "Alert Title mismatch!");
	}

	/**
	 * @author aravindanathdm
	 * @param element

	 */

	public static void assertTitleActualVsExcepted(WebElement element) {
		String actual = element.getText();
		Log.info("======== Verifing title:  " + actual + " ========");
//		Assert.assertTrue(actual.contains(contains), "Alert Title mismatch!");
		Assert.assertEquals(actual, element, "Alert Title mismatch!");
	}

	/**
	 * @author aravindanath
	 * @param element
	 * @param btnName
	 */
	public static void assertTrue(WebElement element, String btnName) {

		Log.info("======== Verifing " + btnName + "/ button / title is displayed:  " + element.isDisplayed()
				+ " ========");
		Assert.assertTrue(element.isDisplayed(), btnName + " button / title is not present!");
	}

	/**
	 * @author aravindanathdm
	 * @param element
	 * @param btnName
	 */
	public static void assertElementEnable(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertTrue(element.isEnabled(), btnName + " button / title is not Enabled!");
	}

	/**
	 * @author aravindanathdm
	 * @param element
	 * @param btnName
	 */
	public static void assertElementIsSelected(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertTrue(element.isSelected(), btnName + " button / title is not Enabled!");
	}

	public static void assertElementIsNotSelected(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertFalse(element.isSelected(), btnName + " button / title is not Enabled!");
	}

	/**
	 * @author aravindanathdm
	 * @param element
	 * @param btnName
	 */
	public static void assertElementDisabled(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertFalse(element.isEnabled(), btnName + " button / title is Enabled!");
	}

	/**
	 * @author aravindanathdm
	 */

	public static void extractNumberInMaskedCardNumber(String smsText) {
		Log.info("======== Verifing masked card number:  " + smsText + " ========");
		for (String str : smsText.replace("•", "").split(" ")) {
			if (str.matches("\\d{4}")) {
				Log.info("======== Verifing masked card  ending number:  " + str + " ========");
			}
		}
	}

	public static void stringComparision(String actual, String excepted) {
		Log.info("========  String count  " + actual.length() + " ========");
		Assert.assertTrue(actual.contains(excepted), " mismatch!");

	}

	public static void countCardNumber(String actual, int excepted) {
		Log.info("========  String count  " + actual.length() + " ========");
		Assert.assertEquals(actual.length(), excepted, "Mis match!");

	}

	/**
	 * @author aravindanath
	 * @param driver
	 */
	public static void navigateBackBtn(WebDriver driver) {
		if (isIos(driver))
			return;
		Log.info("====== Navigating back ======");
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
	}

	/**
	 * @author rashmi
	 * @param expectedCount,data,expectedData
	 */
	public static int characterCount(long expectedCount, String data, String expectedData) {

		Pattern pattern = Pattern.compile(data);
		java.util.regex.Matcher matcher = pattern.matcher(expectedData);
		int count = 0;
		while (matcher.find()) {
			count++;
		}

		Assert.assertEquals(expectedCount, count);
		Log.info("Character Count of " + expectedData + " = " + count);
		return count;

	}

	/**
	 * Swipes from right to left. Mainly used in the Select Card Page. <---------||
	 * 
	 * @author rashmi
	 * @param driver the driver
	 */
	public static void swipeLeftByScreen(WebDriver driver) {
		System.out.println("=Performing New Swipe =");

		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);
		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width * .99);
		int endx = (int) (size.width * 0.001);
		int starty = size.height / 2;

		try {

			touchAction.press(PointOption.point(startx, starty))
					.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(endx, starty))
					.release().perform(); // Absolute final Co-ordinates
		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}

	}

	/**
	 * removes duplicates from Arraylist <---------||
	 * 
	 * @author rashmi
	 * @param //driver the driver
	 */
	public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list) {

		Set<T> set = new LinkedHashSet<>();
		set.addAll(list);
		list.clear();
		list.addAll(set);
		return list;
	}

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	private static final String SPECIAL_CHAR_STRING = "#$%^&*())(*&^%$#$%^&";

	public static String randomSpecialChar(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * SPECIAL_CHAR_STRING.length());
			builder.append(SPECIAL_CHAR_STRING.charAt(character));
		}
		return builder.toString();
	}

	public static void assertCount(int acctual, int excepted) {
		Log.info("======== Verifing " + excepted + " count :  " + acctual + " ========");
		Assert.assertEquals(acctual, excepted, " Char count mismatch");

	}

	public static void assertListOfElements(List<WebElement> actual, List<WebElement> excepted, String section) {
		for (WebElement li : actual) {
			Log.info("======== Verifing list of elements in" + section + " and elements are  " + li.getText()
					+ " ========");
		}
		Assert.assertEquals(actual, excepted, "List of Elements mismatch");
	}



	public static void assertData(String actual, String expected) {

		Log.info("======== Verifing actual v/s expected :  " + actual + " & " + expected + " ========");
		Assert.assertEquals(actual, expected, "MisMatch in actaul vs expected!");

	}

	public static void assertElementNotDisplayed(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertFalse(element.isDisplayed(), btnName + " button / title is Enabled!");
	}

	public static String randomAmount() {
		double d = Math.random();
		int rs = (int) (d * 20);
		String rup = Integer.toString(rs);
		return rup;
	}

	/**
	 * to generate randon numeric value in a particular range
	 *
	 * ex-  min-1000, max-9999
	 */
	public static String getRandomNumberInRange(int min, int max)	{
		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}
		Random r = new Random();
		return String.format("%04d", r.nextInt((max - min) + 1) + min);
	}

	/**
	 * Moves to bottom of the page by swiping to left to right. @ Arvindanath
	 * 
	 * @param driver the driver
	 */
	public static void swipeToLeft(WebDriver driver, WebElement element, String direction) {

		System.out.println("Swiping " + direction);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Map<String, Object> args = new HashMap<>();
		args.put("direction", direction);
		args.put("text", "Send Money");
		args.put("element", ((RemoteWebElement) element).getId());
		js.executeScript("mobile: swipe", args);

	}

	/**
	 * @author aravindanath
	 * @param element
	 * @param btnName
	 */
	public static void assertFalse(WebElement element, String btnName) {

		Log.info("======== Verifing " + btnName + "/ button / title is displayed:  " + element.isDisplayed()
				+ " ========");
		Assert.assertFalse(element.isDisplayed(), btnName + " button / title is not present!");
	}

	/**
	 * @author rashmi

	 */
	public static void assertCompareString(String value1, String value2) {

		Log.info("======== Verifing " + value1 + " versus " + value2 + " ========");
		Assert.assertEquals(value1, value2, "Mismatch in the actual versus expected");
	}

	public static void swipeLeftByScreen(WebDriver driver, double d) {
		System.out.println("=Performing New Swipe =");

		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);
		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width * .99);
		int endx = (int) (size.width * 0.001);
		int starty = (int) (size.height / d);

		try {

			touchAction.press(PointOption.point(startx, starty))
					.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(endx, starty))
					.release().perform(); // Absolute final Co-ordinates
		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}

	}

	/**
	 * Launches / Relaunches the main AUT.Used mainly in Prepaid.testScripts.BaseClass
	 *
	 *
	 * @param driver the driver
	 * @see BaseTest1 switchToApp() for usage in TestClasses
	 */
	public static void switchToApp(WebDriver driver, String packageName, String activity) {
		if (isAndroid(driver)) { // Android

			System.out.println("==== Opening AUT ====");
			((AndroidDriver) driver).startActivity(new Activity(packageName, activity));

		}
	}

	public static void activateAndroidApp(WebDriver driver, String packageName) {
		// .out.println("=== Activating IOS App with bundleId " + packageName + "===");
		((AndroidDriver) driver).activateApp(packageName);
	}

	/**
	 * Swipes from right to left. Mainly used in the Select Card Page. <---------||
	 * 
	 * @param driver the driver
	 */
	public static void swipeMiddleOfScreenLeftTillEnd(WebDriver driver) {
		System.out.println("=Performing New Swipe =");

		AppiumDriver adriver = (AppiumDriver) driver;
		TouchAction touchAction = new TouchAction(adriver);
		Dimension size = adriver.manage().window().getSize();
		int startx = (int) (size.width * 0.95);
		int endx = (int) (size.width * 0.15);
		int starty = (int) (size.height / 1.5);

		try {
			if (isIos(driver)) {
				// touchAction.press(PointOption.point(startx,
				// starty)).moveTo(PointOption.point(endx - startx, 0))
				// .release().perform(); // Relative final Co-ordinates
				System.out.println("Swiping Left");
				Map<String, Object> args = new HashMap<>();
				args.put("direction", "left");
				adriver.executeScript("mobile: swipe", args);
			} else
				System.out.println("============Dimension :" + size);
			touchAction.press(PointOption.point(startx, starty))
					.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(endx, starty))
					.release().perform(); // Absolute final Co-ordinates
		} catch (Exception e) {
			System.err.println("Scroll error ");
			e.printStackTrace();
		}

	}
	
	public static void clickHomeButton(WebDriver driver) {
		((AndroidDriver) driver).pressKeyCode(187);
	}

	
	public static boolean verifyDecimal(String value){
	    String regex = "^\\d*\\.\\d+|\\d+\\.\\d*\\W$";
	    boolean decimalVal =value.matches(regex);
	    return decimalVal;
	}


	public static void assertElementDisplayed(WebElement element, String btnName) {
		Log.info("======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertTrue(element.isDisplayed(), btnName + " button / title is Enabled!");
	}


	public static void waitForVisibilityOf(WebDriver driver, WebElement element, int time){
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	public static void waitAndClickOn(WebElement element, WebDriver driver) {
		waitForVisibilityOf(driver, element, 10);
		element.click();
	}
	public static void waitSendKeysAndEnterTo(WebElement element, String txt, WebDriver driver) {
		waitForVisibilityOf(driver, element, 10);
		element.clear();
		element.sendKeys(txt);
	}

	public static String waitAndGetText(WebElement element, WebDriver driver) {
		waitForVisibilityOf(driver, element, 10);
		return element.getText();
	}

	public static void assertNotEqualsString(String value1, String value2) {

		Log.info("======== Verifing " + value1 + " versus " + value2 + " ========");
		Assert.assertNotEquals(value1, value2, "Mismatch in the actual versus expected");
	}

	public static void assertElementNotEnable(WebElement element, String btnName) {

		Log.info(
				"======== Verifing " + btnName + "/ button / title is enabled :  " + element.isEnabled() + " ========");
		Assert.assertFalse(element.isEnabled(), btnName + " button / title is not Enabled!");
	}

	/**
	 * @Author Arvindanath
	 * @param val
	 * @return
	 */
	public static String intToString(int val){
		String str = String.valueOf(val);
		return str;
	}

	/**
	 * author : Aravindanath
	 *
	 */


	public static void readFromCSV(String moduleName) {
		String day = Generic.intToString(Generic.getDateDay());
		if (day.length() == 1) {
			day = "0" + day;
		}
		String month = Generic.intToString(Generic.getCurrentMonth());
		String year = Generic.intToString(Generic.getCurrentYear());

		String path = null;
		try {
			if (month.length() == 1) {
				System.out.println("0" + month);
				path = System.getProperty("user.dir") + File.separator + "CSR_Reports" + File.separator + moduleName+"-" + year + "-" + "0" + month + "-" + day + ".csv";
			} else {
				path = System.getProperty("user.dir") + File.separator + "CSR_Reports" + File.separator + moduleName+"-" + year + "-" + month + "-" + day + ".csv";
			}
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line = "";
			while ((line = br.readLine()) != null) {
				Log.info(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
	/**
	 *
	 * @Author: Aravindanath
	 *
	 */

	public static void foulderCleanUp(){
		String foulder = System.getProperty("user.dir") + File.separator + "CSR_Reports" ;
		File file=new File(foulder);
		File[] listOfFiles = file.listFiles();
		String fileName = null;
		for(File fil : listOfFiles){
			fileName = fil.getName();
			Log.info("CSV File Names: " +fileName);
		}
		int fileCount=file.list().length;
		if(fileCount>1) {
			try {
				Files.deleteIfExists(Paths.get(foulder+File.separator+fileName));
			}catch(NoSuchFileException e)
			{
				Log.info("No such file/directory exists");
			}
			catch(DirectoryNotEmptyException e)
			{
				Log.info("Directory is not empty.");
			}
			catch(IOException e)
			{
				Log.info("Invalid permissions.");
			}
		}

		Log.info("File Count:"+fileCount);
	}

	/**
	 *
	 * @Author: Aravindanath
	 *
	 */
	public static void unzip(String zipFilePath, String destDir) {
		File dir = new File(destDir);
		// create output directory if it doesn't exist
		if(!dir.exists()) dir.mkdirs();
		FileInputStream fis;
		//buffer for read and write data to file
		byte[] buffer = new byte[1024];
		try {
			fis = new FileInputStream(zipFilePath);
			ZipInputStream zis = new ZipInputStream(fis);
			ZipEntry ze = zis.getNextEntry();
			while(ze != null){
				String fileName = ze.getName();
				File newFile = new File(destDir + File.separator + fileName);
				System.out.println("Unzipping to "+newFile.getAbsolutePath());
				//create directories for sub directories in zip
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				//close this ZipEntry
				zis.closeEntry();
				ze = zis.getNextEntry();
			}
			//close last ZipEntry
			zis.closeEntry();
			zis.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/**
	 *
	 * @Author: Aravindanath
	 *
	 */

	public static void readFromCompressedCSV(String moduleName) throws IOException {

		String day = Generic.intToString(Generic.getDateDay());
		if (day.length() == 1) {
			day = "0" + day;
		}
		String month = Generic.intToString(Generic.getCurrentMonth());
		String year = Generic.intToString(Generic.getCurrentYear());


		try {
			String path;
			if (month.length() == 1) {
				System.out.println("0" + month);
				path = System.getProperty("user.dir") + File.separator + "CSR_Reports" + File.separator + moduleName+"-" + year + "-" + "0" + month + "-" + day + ".zip";
			} else {
				path = System.getProperty("user.dir") + File.separator + "CSR_Reports" + File.separator + moduleName+"-" + year + "-" + month + "-" + day + ".zip";
			}
			//String  path = System.getProperty("user.dir") + File.separator + "CSR_Reports" + File.separator + "REQUEST_MONEY_TRANSACTION_REPORT-" + "2021" + "-" + "0" + "2" + "-" + "02" + ".zip";
			String dest = System.getProperty("user.dir") + File.separator + "CSR_Reports";
			unzip(path, dest);

			String foulder = System.getProperty("user.dir") + File.separator + "CSR_Reports";
			File file = new File(foulder);
			File[] listOfFiles = file.listFiles();
			BufferedReader br = new BufferedReader(new FileReader(listOfFiles[1]));
			String line = "";
			while ((line = br.readLine()) != null) {
				Log.info(line);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			System.out.println("The 'try catch' is finished.");
		}
	}

	/**
	 *
	 * @Author: Aravindanath
	 *
	 */

	public static void completFoulderCleanUp(){
		String foulder = System.getProperty("user.dir") + File.separator + "CSR_Reports" ;
		File file=new File(foulder);
		File[] listOfFiles = file.listFiles();
		String fileName = null;
		for(File fil : listOfFiles){
			fileName = fil.getName();
			Log.info("CSV File Names: " +fileName);
		}
		int fileCount=file.list().length;

			try {
				Files.deleteIfExists(Paths.get(foulder+File.separator+fileName));
			}catch(NoSuchFileException e)
			{
				Log.info("No such file/directory exists");
			}
			catch(DirectoryNotEmptyException e)
			{
				Log.info("Directory is not empty.");
			}
			catch(IOException e)
			{
				Log.info("Invalid permissions.");
			}


		Log.info("File Count:"+fileCount);
	}


	public static void pageScrollDown(int size, WebDriver driver) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0," + size + ")", "");
	}

	public static void scrollDown(WebDriver driver){
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
	}

	public static String getAddress(){
		Faker faker = new Faker(new Locale("en-IND"));
		String streetAddress = faker.address().fullAddress();
		return streetAddress;
	}

	public static String getStreetAddress(){
		Faker faker = new Faker(new Locale("en-IND"));
		String streetAddress = faker.address().streetAddress();
		return streetAddress;
	}

	public static String  getCity(){
		Faker faker = new Faker(new Locale("en-IND"));
		String cityName = faker.address().cityName();
		return cityName;
	}

	public static String  getState(){
		Faker faker = new Faker(new Locale("en-IND"));
		String stateName = faker.address().state();
		return stateName;
	}

	public static String  getCountry(){
		Faker faker = new Faker(new Locale("en-IND"));
		String countryName = faker.address().country();
		return countryName;
	}

	public static String  getZipCode(){
		Faker faker = new Faker(new Locale("en-IND"));
		String zipCode = faker.address().zipCode();
		return zipCode;
	}

	public static String  getName(){
		Faker faker = new Faker(new Locale("en-IND"));
		String firstName = faker.name().firstName();
		return firstName;
	}

	public static String  getFilipinoName(){
		Faker faker = new Faker(new Locale("fi-FI"));
		String firstName = faker.name().firstName();
		return firstName;
	}

	public static String getIdentityNumber(){
		String idNumber = Generic.getRandomNumberInRange(1000000, 9999999);
		return idNumber;
	}


	public static String getPassword(){
		String pass = "Password@123";
		return pass;
	}

	public static String  getEmail(){
		Faker faker = new Faker(new Locale("en-IND"));
		String firstName = faker.name().firstName();
		return firstName+"@testmail.com";
	}

	public static void scrollTillEnd(WebDriver driver,WebElement element){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",element);
	}

    //@author srikiran.d
	public static String getMaskedCardNumber(String card16DigitNumber)	{
		String maskedCardNumber = card16DigitNumber.replace(card16DigitNumber.subSequence(4, 12), "XXXXXXXX");
		return maskedCardNumber;
	}

	//This method is to capture the screenshot and return the path of the screenshot.
	//@author srikiran.d
	public String getScreenshot(WebDriver driver) throws Exception {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		//after execution, you could see a folder "FailedTestsScreenshots" under src folder
		String destination = System.getProperty("user.dir")+File.pathSeparator+"TestScreenshot"+File.pathSeparator+dateName+".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}


	//This method is to capture the Full page screenshot and return the path of the screenshot.
	//@author srikiran.d
	public static String getFullPageScreenshot(WebDriver driver, String tc_id) {
		File destinationFile;
		File destinationFolder = null;
		String dateFolder = new SimpleDateFormat("yyyy_M_d").format(new Date());
		ShootingStrategy strategy = ShootingStrategies.viewportPasting(1000);
		Screenshot screenshot = new AShot().shootingStrategy(strategy).takeScreenshot(driver);
		String basePath = System.getProperty("user.dir");
		destinationFolder = new File(basePath+File.separator+"screenshots"+File.separator+dateFolder);
		if(!destinationFolder.exists()){
			destinationFolder.mkdir();
		}
		destinationFile = new File(destinationFolder+File.separator+tc_id+".png");

		String relatvePath = new File(basePath).toURI().relativize(new File(destinationFile.toString()).toURI()).getPath();
//		String[] relatvePath = destinationFile.toString().split(dateFolder);
//		File relativescreenshotPath = new File(".\\" + relatvePath[1]);

		try {
			ImageIO.write(screenshot.getImage(),"PNG",destinationFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return relatvePath;
//		return destinationFile.getPath();
	}

	//This method is to capture the Full page screenshot and return the path of the screenshot.
	//@author srikiran.d
	public File getelementScreenshot(WebDriver driver, WebElement element) throws Exception {
		File destinationFile;
		File destinationFolder = null;
		String dateFolder = new SimpleDateFormat("yyyy_M_d").format(new Date());
		ShootingStrategy strategy = ShootingStrategies.viewportPasting(1000);
		Screenshot screenshot = new AShot().shootingStrategy(strategy).takeScreenshot(driver, element);
		destinationFolder = new File(System.getProperty("user.dir")+"/reports/"+dateFolder+"/images/");
		if(!destinationFolder.exists()){
			destinationFolder.mkdir();
		}
		destinationFile = new File(destinationFolder +"/image_" + System.currentTimeMillis()+ ".png");
		String[] relatvePath = destinationFile.toString().split(dateFolder);
		File relativescreenshotPath = new File(".\\" + relatvePath[1]);
		System.out.println("screenshot1"+relativescreenshotPath);
		ImageIO.write(screenshot.getImage(),"PNG",destinationFile);
		return relativescreenshotPath;
	}
    //@author srikiran.d
	public static boolean assertTitleValuesDisplaying(WebElement element){
		return element.getText().length() > 0;
	}
    //@author srikiran.d
	public static String formatDate(String date, String format){
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}


    //@author srikiran.d
    public static String currentDate(String dateTimeFormat){
        DateFormat df = new SimpleDateFormat(dateTimeFormat);
        Date date = new Date();
        System.out.println(df.format(date));
        return df.format(date);
    }
    //author:Srikiran
    public static String getLast4DigitCardNumber(String Card16DigitNumber)	{
        String CardLast4Digit = Card16DigitNumber.substring(12, 16);
        return CardLast4Digit;
    }
    //@author srikiran.d
    public static String ExpiryMMYY(int Month, int Year){
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.MONTH, Month);
        int ExpMonth = cal.get(Calendar.MONTH);
        String MM = null;
        if(ExpMonth<=9)MM = "0"+ExpMonth;
        System.out.println(MM);
        cal.add(Calendar.YEAR, Year);
        int ExpYear = cal.get(Calendar.YEAR);
        String YY = Integer.toString(ExpYear).substring(2,4);
        System.out.println(MM+""+YY);
        return MM+YY;
    }

    //@srikiran.d
    public static File lastFileModified(String dir) {
        File fl = new File(dir);
        File choice = null;
        if (fl.listFiles().length>0) {
            File[] files = fl.listFiles(new FileFilter() {
                public boolean accept(File file) {
                    return file.isFile();
                }
            });
            long lastMod = Long.MIN_VALUE;

            for (File file : files) {
                if (file.lastModified() > lastMod) {
                    choice = file;
                    lastMod = file.lastModified();
                }
            }
        }
        return choice;
    }

    //@Srikiran.d
    public static String waitForFileToDownload(String matchingFileName){
        String fileName;
        do{
            wait(5);
            File DownloadedFileName = lastFileModified(System.getProperty("user.dir")+"\\Downloads\\");
            fileName = DownloadedFileName.getName();
        }while (matchingFileName.contains(fileName));
        return fileName;
    }
	//@Srikiran.d
    public static File MoveFile(String fileName) throws IOException {
        File DownloadedFileName = lastFileModified(System.getProperty("user.dir")+"\\Downloads\\");
        Path temp = Files.move(Paths.get(System.getProperty("user.dir")+File.separator+"Downloads"+File.separator+DownloadedFileName.getName()), Paths.get(System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+getPropValues("ENV")+File.separator+"Downloads"+File.separator+DownloadedFileName.getName()), REPLACE_EXISTING);
        if(temp != null) {
            System.out.println("File renamed and moved successfully");
        }
        else{
            System.out.println("Failed to move the file");
        }
        return DownloadedFileName;
    }
	//@Srikiran.d
	public static String getPastOrFutureDate(String dateTimeFormat, int Days){
		Calendar c = Calendar.getInstance();
		SimpleDateFormat dateF = new SimpleDateFormat(dateTimeFormat);
		c.add(Calendar.DAY_OF_MONTH, Days);
		String date = dateF.format(c.getTime());
		return date;
	}


	/**
	 * @author sanmati.vardhaman
	 */

	// method to scrolldown to webelement

	public static void scrollToWebElement(WebDriver driver,WebElement element)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", element);
	}

	/**
	 * @author sanmati.vardhaman
	 */

	public static void handleWindows(WebDriver driver)
	{
		String parentWindow=driver.getWindowHandle();
		System.out.println("parent window is "+parentWindow);
		//to handle all the child windows
		Set<String> S1 = driver.getWindowHandles();
		Iterator<String> i1=S1.iterator();

		while(i1.hasNext())
		{
			String childWindow=i1.next();

			if(!parentWindow.equalsIgnoreCase(childWindow))
			{

				// Switching to Child window
				driver.switchTo().window(childWindow);

			}
		}
	}

	public static void switchWindows(WebDriver driver, int handle)	{
		ArrayList<String> myList =new ArrayList<String>(driver.getWindowHandles());
		System.out.println("size of window handle is "+myList.size());
		driver.switchTo().window(myList.get(handle));
	}

	public static String decimalFormatter(String value){
		double decimalValue = Double.parseDouble(value)/100;
		return String.format("%.2f", decimalValue);

	}

	//@author-Srikiran
	public static HashMap<String, String> parseStringToHashmap(String value) {
		value = value.replace("{", "").replace("}", "");

		HashMap<String, String> map = new HashMap<String, String>();
		String[] pairs = value.split(",");
		for (int i = 0; i < pairs.length; i++) {
			String pair = pairs[i].trim();
			String[] keyValue = pair.split("=");
			try {
				if (keyValue.length == 1) {
					if (keyValue[0].contains("\"\"")) {
						keyValue[0] = "";
					}
					map.put("value" + i, keyValue[0]);
				} else {
					map.put(keyValue[0], keyValue[1]);
				}
			} catch (Exception e) {
				if (keyValue.length == 1) {
					map.put("value" + i, "");
				} else {
					map.put(keyValue[0], "");
				}
			}
		}
		return map;
	}

	public static String JulianDate()	{
		Date now = new Date();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyDDD");
		//System.out.println("Julian date : "+dateFormatter.format(now));
		String julianDate = dateFormatter.format(now);
		return julianDate;
	}

	//format date as per prepaid reports
    public static String reportFormattedDate(String responseDateTime, String pattern){

        int year = Integer.parseInt(responseDateTime.substring(0, 4));
        int month = Integer.parseInt(responseDateTime.substring(5, 7));
        int date = Integer.parseInt(responseDateTime.substring(8, 10));

        int hour = Integer.parseInt(responseDateTime.substring(11, 13));
        int minute = Integer.parseInt(responseDateTime.substring(14,16));

        LocalDateTime datetime = LocalDateTime.of(year, month, date, hour, minute);
        DateTimeFormatter dformat = DateTimeFormatter.ofPattern(pattern);
        String fdate = datetime.format(dformat);
        return fdate;
    }

	public static Response buildRestResponse(String request){
		ResponseBuilder responseb = new ResponseBuilder();
		responseb.setStatusCode(200);
		responseb.setBody(request);
		return responseb.build();
	}
	//To Generate random alpha characters.
	//shankar added method
	public static String randomAlphaChar(int count) {
		String ALPHA_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_STRING.length());
			builder.append(ALPHA_STRING.charAt(character));
		}
		return builder.toString();
	}

	public static String randomStringGen()
	{
		String randomValue = RandomStringUtils.randomAlphanumeric(8);
		return randomValue;
	}

	public static String switchToNewWindow(WebDriver driver, String openWindowName){
		String newWindowHandle = null;
		Set<String> activeOpenWindows= driver.getWindowHandles();
		for (String window:activeOpenWindows){
			if(!window.equalsIgnoreCase(openWindowName)){
				driver.switchTo().window(window);
				newWindowHandle = window;
			}
		}
		return newWindowHandle;
	}




}
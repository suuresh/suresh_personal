package library;

import Prepaid.testScripts.BaseTest1;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.DataProvider;

import java.io.File;


/**
 * @author ${Srikiran D}
 *
 */

public class  DataProviderUtility
{
	public static final String transactionsfilePath = BaseTest1.TRANSACTION_XLSX_FILE_PATH;
			//System.getProperty("user.dir")+ File.separator+"excel_lib"+File.separator+"Authorization_TestData.xlsx";
	public static final String testExecutionDatafilePath = BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH;
	public static final String apitestDatafilePath = BaseTest1.APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	public static final String apitestDatafilePathtestDatafilePath = BaseTest1.APIREQUESTBODY_TESTDATA_XLSX_FILE_PATH;


	public static Object[][] GetData(String filePath, String sheet)	{
//		ExcelUtilities  ExcelLibrary= new ExcelUtilities();
		int rows=ExcelLibrary.getExcelRowCount(filePath, sheet);
		int cols=ExcelLibrary.getExcelCellCount(filePath, sheet, 0);
		Object[][] obj =new Object[rows][cols];
		for (int i = 0, k=0; i<rows; i++,k++){
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, sheet, i, j);
			}
		}
		return obj;
	}

	public static Object[][] GetDataOfaColumn(String filePath, String sheet, int[] column){
		//ExcelUtilities  ExcelLibrary= new ExcelUtilities();
		int rows=ExcelLibrary.getExcelRowCount(filePath, sheet);
		System.out.println("number or rows: "+rows);
		System.out.println("column length: "+column.length);
		Object[][] obj =new Object[rows-1][column.length];
		System.out.println(obj.length);
		for (int i = 1; i<rows; i++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, sheet, i);
			for (int j=0; j<column.length;j++){
				if(ExcelLibrary.getExcelData(filePath, sheet, rows, column[j])!= null && ExcelLibrary.getExcelData(filePath, sheet, i, column[j])!=""){
					obj[i-1][j]=ExcelLibrary.getExcelData(filePath, sheet, rows, column[j]);
				}
			}
		}
		return obj;
	}

	/**
	 * This data provider is to pass data required for Authorizations
	 * @return
	 */	
	@DataProvider (name="Authorization")
	public Object[][] authorization()	{
		int rows=ExcelLibrary.getExcelRowCount(transactionsfilePath, "Authorizations");
		int cols=ExcelLibrary.getExcelCellCount(transactionsfilePath, "Authorizations", 0);
		Object[][] obj =new Object[rows][cols];
		for (int i=1, k=0; i<=rows; i++,k++){
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(transactionsfilePath, "Authorizations", i, j);
			}
		}
		return obj;
	}
	
	
	/**
	 * This data provider is to pass data required for Settlements
	 * @return
	 */	
	@DataProvider(name="Settlements")
	public Object[][] settlements()	{
		int rows=ExcelLibrary.getExcelRowCount(transactionsfilePath, "AuthSettlement");
		int cols=ExcelLibrary.getExcelCellCount(transactionsfilePath, "AuthSettlement", 0);
		Object[][] obj =new Object[rows][cols];
		for (int i = 1, k=0; i<=rows; i++,k++){
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(transactionsfilePath, "AuthSettlement", i, j);
			}
		}
		return obj;
	}

	/**
	 * This data provider is used for passing details required for activating the cards
	 * @return
	 */
	@DataProvider(name = "ApproveCards")
	public static Object[][] getExcelDataforReloadReggression() {
		int rows=ExcelLibrary.getExcelRowCount(testExecutionDatafilePath, "CreatedCardBatchDetails");
		int cols= 4;
//		ExcelLibrary.getExcelCellCount(transactionsfilePath, "CreatedCardBatchDetails", 0);
		Object[][] obj =new Object[rows][cols];
		for (int i = 1, k=0; i<=rows; i++,k++){
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(testExecutionDatafilePath, "CreatedCardBatchDetails", i, j);
			}
		}
		return obj;
	}


	/**
	 * This data provider is to pass data required for Perso and pin file details
	 * @return
	 */
	@DataProvider(name="CardBatchPersoPinFileDetails")
	public static Object[][] getExcelDataforCardsPersoPinFileDetails() throws Exception{
		int rows=ExcelLibrary.getExcelRowCount(testExecutionDatafilePath, "CreatedCardBatchDetails");
		int[] cols= {0,6,7,1};
		Object[][] obj =new Object[rows][cols.length];
		for (int i = 1, k=0; i<=rows; i++,k++){
			for(int j=0;j<cols.length;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(testExecutionDatafilePath, "CreatedCardBatchDetails", i, cols[j]);
			}
		}
		return obj;
	}

//	/**
//	 * This data provider is to pass data required for InventoryOperations
//	 * @return
//	 */
//	@DataProvider(name="InventoryOperations")
//	public static Object[][] getExcelDataforInventoryOperations(){
//		Generic  gen= new Generic();
//		int[] columns = {4};
//		Object[][] obj = GetDataOfaColumn(Generic.getPropertyTestDataFilePath(), "ActivationRequest", columns);
//		return obj;
//	}

	//Regression Data Provider
	/**
	 * This data provider is to pass data required for CreateCard_api
	 * @return
	 */
	@DataProvider(name="CreateCard_api")
	public Object[][] aeroCreateCardapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		//ExcelUtilities  ExcelLibrary= new ExcelUtilities();
		int rows=ExcelLibrary.getExcelRowCount(filePath, "CreateCard");
		//System.out.println("The Row num"+rows);
		int cols=ExcelLibrary.getExcelCellCount(filePath, "CreateCard", 1);
		//System.out.println("The colum num"+cols);

		Object[][] obj =new Object[rows][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<=rows; i++,k++){
//			if(i==2 || i==3){continue;}
			//System.out.println("row: "+rows);
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "CreateCard", i);
			for(int j=0;j<cols;j++)	{
				//System.out.println("columns i: "+cols);
				//System.out.println("The Row num"+i+"columns: "+j);
				//System.out.println("The data from excel:"+ExcelLibrary.getExcelData(filePath, "CreateCard", i, j));
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "CreateCard", i, j);
				//System.out.println("columns i: "+cols);


				//System.out.println("The column data:"+obj[k][j]);
			}
		}
//		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for ReloadCard_api
	 * @return
	 */
	@DataProvider(name="ReloadCard_api")
	public Object[][] aeroReloadCardapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		//ExcelUtilities  ExcelLibrary= new ExcelUtilities();
		int rows=ExcelLibrary.getExcelRowCount(filePath, "Reload");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "Reload", 1);

		Object[][] obj =new Object[rows][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<=rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "Reload", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "Reload", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for UnloadCard_api
	 * @return
	 */
	@DataProvider(name="unloadCard_api")
	public Object[][] aeroUnloadCardapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		//ExcelUtilities  ExcelLibrary= new ExcelUtilities();
		int rows=ExcelLibrary.getExcelRowCount(filePath, "Unload");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "Unload", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "Unload", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "Unload", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for CardInquiry_api
	 * @return
	 */
	@DataProvider(name="CardInquiry_api")
	public Object[][] aeroCardInquiryapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "CardInquiry");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "CardInquiry", 1);

		Object[][] obj =new Object[rows][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<=rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "CardInquiry", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "CardInquiry", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for CardBlock_api
	 * @return
	 */
	@DataProvider(name="CardBlock_api")
	public Object[][] aeroCardBlockapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "CardBlock");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "CardBlock", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "CardBlock", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "CardBlock", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for CardUnblock_api
	 * @return
	 */
	@DataProvider(name="CardUnblock_api")
	public Object[][] aeroCardUnblockapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "CardUnblock");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "CardUnblock", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "CardUnblock", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "CardUnblock", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for UpdateProfile_api
	 * @return
	 */
	@DataProvider(name="UpdateProfile_api")
	public Object[][] aeroUpdateProfileapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "UpdateProfile");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "UpdateProfile", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "UpdateProfile", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "UpdateProfile", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for TransactionInquiry_api
	 * @return
	 */
	@DataProvider(name="TransactionInquiry_api")
	public Object[][] aeroTransactionInquiryapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "TransactionInquiry");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "TransactionInquiry", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "TransactionInquiry", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "TransactionInquiry", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for FundTransfer_api
	 * @return
	 */
	@DataProvider(name="FundTransfer_api")
	public Object[][] aeroFundTransferapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "FundTransfer");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "FundTransfer", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "FundTransfer", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "FundTransfer", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for AMLInquiry_api
	 * @return
	 */
	@DataProvider(name="AMLInquiry_api")
	public Object[][] aeroAMLInquiryapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "AMLInquiry");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "AMLInquiry", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "AMLInquiry", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "AMLInquiry", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for WalletSettlement_api
	 * @return
	 */
	@DataProvider(name="WalletSettlement_api")
	public Object[][] aeroWalletStatementapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "WalletSettlement");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "WalletSettlement", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "WalletSettlement", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "WalletSettlement", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for ResetPin_api
	 * @return
	 */
	@DataProvider(name="ResetPin_api")
	public Object[][] aeroResetPinapi()	{
		String filePath = apitestDatafilePathtestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "ResetPin");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "ResetPin", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "ResetPin", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "ResetPin", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for Authorization report
	 * @return
	 */
	@DataProvider(name="AuthorizationReport")
	public Object[][] authorizationReport()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "AuthorizationReportData");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "AuthorizationReportData", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "AuthorizationReportData", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "AuthorizationReportData", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}


	/**
	 * This data provider is to pass data required for Failed Authorization report
	 * @return
	 */
	@DataProvider(name="failedAuthorizationReport")
	public Object[][] failedAuthorizationReport()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "FailedAuthorizationReport");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "FailedAuthorizationReport", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "FailedAuthorizationReport", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "FailedAuthorizationReport", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for Settlement report
	 * @return
	 */
	@DataProvider(name="settlementReport")
	public Object[][] settlementReport()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "SettlementReport");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "SettlementReport", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "SettlementReport", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "SettlementReport", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}


	/**
	 * This data provider is to pass data required for  Authorization Expiry report
	 * @return
	 */
	@DataProvider(name="authorizationExpiryReport")
	public Object[][] authorizationExpiryReport()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "AuthorizationExpiryReport");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "AuthorizationExpiryReport", 1);
		Object[][] obj =new Object[rows-1][cols];
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "AuthorizationExpiryReport", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "AuthorizationExpiryReport", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}



	/**
	 * This data provider is to pass data required for Settlement report
	 * @return
	 */
	@DataProvider(name="BulkSettlement")
	public Object[][] bulksettlement()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "BulkSettlement");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "BulkSettlement", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "BulkSettlement", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "BulkSettlement", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for Settlement report
	 * @return
	 */
	@DataProvider(name="ChargebackReport")
	public Object[][] chargeBack()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "ChargebackReport");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "ChargebackReport", 1);
		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "ChargebackReport", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "ChargebackReport", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}


	/**
	 * This data provider is to pass data required for Exception Clearing cases
	 * @return
	 */
	@DataProvider(name="ExceptionClearing")
	public Object[][] exceptionClearing()	{
		String filePath = System.getProperty("user.dir")+transactionsfilePath;
		int rows=ExcelLibrary.getExcelRowCount(filePath, "Exception Clearing");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "Exception Clearing", 1);
		Object[][] obj =new Object[rows-1][cols];
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "Exception Clearing", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "Exception Clearing", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for UCICReg_API
	 * @return
	 */
	@DataProvider(name="UCICReg_API")
	public Object[][] aeroUCICRegapi()	{
		String filePath = System.getProperty("user.dir")+apitestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "UCICReg");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "UCICReg", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "UCICReg", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "UCICReg", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

	/**
	 * This data provider is to pass data required for CardRenewal_API
	 * @return
	 */
	@DataProvider(name="CardRenewal_API")
	public Object[][] aeroCardRenewalapi()	{
		String filePath = System.getProperty("user.dir")+apitestDatafilePath;
		
		int rows=ExcelLibrary.getExcelRowCount(filePath, "CardRenewal");
		int cols=ExcelLibrary.getExcelCellCount(filePath, "CardRenewal", 1);

		Object[][] obj =new Object[rows-1][cols];
		//System.out.println(obj.length);
		for (int i = 1, k=0; i<rows; i++,k++){
			Row rowValue = ExcelLibrary.getrowvalue(filePath, "CardRenewal", i);
			for(int j=0;j<cols;j++)	{
				obj[k][j]=ExcelLibrary.getExcelData(filePath, "CardRenewal", i, j);
			}
		}
		//ExcelLibrary.wb = null;
		return obj;
	}

}


package library;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;

/**
 * The Class ExtentManager for report generation.
 */
public class ExtentManager {
	
	/** The extent object. */
	static ExtentReports extent;
	
	static String path;
    
    /** The file path of Reports generated. */
    static String filePath="";
    
    /** The screen path for screens generated. */
    public static String screenPath;
    
    public static String timeStamp;
    
    private static String configXLPath="./config/config.xlsx";
    
    /**
     * Generates file path for reports
     */
    public static synchronized void generateFilePath() {
    	
    	//if(Prepaid.testScripts.BaseTest1.deviceTrialRun) return;
    	
    	timeStamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date()); 
    	path=System.getProperty("user.dir");
    	filePath=path+"/ExtReport/Report_"+timeStamp+"/Report_"+timeStamp+".html"; 
    	screenPath=path+"/ExtReport/Report_"+timeStamp+"/";   	
    	
	}
    
    /**
     * Gets the reporter for Extent Reports.
     *
     * @return the reporter
     */
    public static synchronized ExtentReports getReporter() {
        if (extent == null) {
            extent = new ExtentReports(filePath, true);  //new ExtentReports(filePath, true) do not append
            //extent.x("",23); // Use only on MongoDB , previously extent.x() default localhost and port
            extent.loadConfig(new File("config/extent-config.xml"));	
            System.out.println("Extent Initialized");
        }        
        return extent;
    }  
     
    public static void createExtZip()
    {
    	
    	if(!ExcelLibrary.getExcelData(configXLPath, "Android_setup", 8,7).contains("true")) 	// Check CI 
    		return;
    	
    	System.out.println("======== Archiving Extent ========");
    	
    	resetZipDir();
    	
    	getDashboard();
    	
    	try
		{
			Generic.Zip(path+"/ExtReport/Report_"+timeStamp, path+"/ExtReport/ExtZip/Report_"+timeStamp+".zip");
		}
		catch(Exception e)
		{
			System.err.println("-----------------------------------------------------------");
			System.err.println("Unable to zip Extent results ");
			e.printStackTrace();
			System.err.println("-----------------------------------------------------------");
		}
    }
    
    
    /**
     *   Clear ExtZip folder 
     */
    public static void resetZipDir()
    {
    	
    	File dir_to_clean = new File(path+"/ExtReport/ExtZip");
    	try
    	{
    		FileUtils.cleanDirectory(dir_to_clean);
    	}
    	catch(Exception e)
    	{
    		System.err.println("Unable to reset ExtZip");e.printStackTrace();
    	}
    	
    }
    
    /**
     *  Used to take Screenshot of the Report Dashboard after Jenkins Execution
     *  
     */
    public static void getDashboard()
    {
      try{
	    	//WebDriver driver = Generic.createFirefoxDriver(); 	
    	  WebDriver driver = Generic.createChromeDriver();
    			  
	    	String htmlPath="file://"+filePath.replace("\\", "/");

	    	System.out.println("Reports HTML Path : "+htmlPath);
	    	
	    	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    	driver.get(htmlPath);
	    	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    	
	    
	    	new WebDriverWait(driver, 45).until(ExpectedConditions.presenceOfElementLocated(By.className("mdi-action-track-changes")));
	    	Generic.wait(3);

	    	driver.findElement(By.className("mdi-action-track-changes")).click(); // Click On Dashboard Icon
	    	Generic.wait(2);
	
			if (driver != null)
	        {
				System.out.println("Obtaining Dashboard Screen");
	            File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	            try 
	            {
	            		FileUtils.copyFile(f, new File((path+"/ExtReport/ExtZip/ReportSnapshot.png")));	            	
				} 
	            catch (Exception e) 
	            {
					System.err.println("Dashboard Exception");
					e.printStackTrace(); 
				}			
	        } 
			driver.close();
    	}
    	catch(Exception e)
    	{
    		System.err.println("Error opening result file");
    		e.printStackTrace();
    	}
    	Generic.wait(5); // Wait for Zip file Creation 
      
    }
    
    public static void sendMail()
    {
     	if(!ExcelLibrary.getExcelData(configXLPath, "Android_setup", 8,7).contains("true")) 	// Check CI 
    		return;
     String sheetName=	"Email_settings";
     	
    	
    	String    host=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,0), 
				   port=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,1),
				   userName=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,2),
				   password=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,3),
				   subject=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,5),
				   message=ExcelLibrary.getExcelData(configXLPath, sheetName, 1,6);
		
		String[] toAddresses=getRecipientListFromExcel();
		
		String[] attachFiles= Generic.getFilepathsInFolder("./ExtReport/ExtZip"); 	// Attach files in ExtZip folder 
		
		try {
			
			BackUp.sendEmailWithAttachments(host, port, userName, password, toAddresses, subject, message, attachFiles);
			
		}catch(Exception e) {System.err.println("Send email failed ");e.printStackTrace();}
			
		}
    
    public static String[] getRecipientListFromExcel()
    {
    		String sheetName="Email_settings";
    		String recipient;
    		
    		
    		int recipientCount=ExcelLibrary.getExcelRowCount(configXLPath, sheetName),
    				j=0;
    		
    		System.out.println("No. of recipients : "+(recipientCount));
    		String[] recipients=new String[recipientCount];
    		
    		for(int i=0;i<=recipientCount;i++)
    		{
    			
    			recipient=ExcelLibrary.getExcelData(configXLPath, sheetName, i,4);
    			System.out.println(recipient);
    			
    			if(recipient.contains("@"))
    				recipients[j++]=recipient;
    		}
    		
    		return recipients;
    }
		
    }
    
    


package library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * The Class ExcelLibrary used to read and write data to the given excel file.
 */
public class ExcelLibrary 
{
	
	/**
	 * Gets the excel data.
	 *
	 * @param filePath the file path
	 * @param sheetName the sheet name
	 * @param rowNo the row no
	 * @param cellNo the cell no
	 * @return the excel data
	 */
	public static String getExcelData(String filePath, String sheetName, int rowNo, int cellNo)
	{
		try
		{
			File f = new File(filePath);
			FileInputStream fileInput = new FileInputStream(f);
			Workbook wb = WorkbookFactory.create(fileInput);
			Sheet st = wb.getSheet(sheetName);
			Row r = st.getRow(rowNo); 			
			
			if(r==null)
			{
				//System.out.println("Row "+rowNo+" detected as null"); // xl Diagnostic
				return " ";
			}		
			
			Cell c = r.getCell(cellNo,Row.RETURN_NULL_AND_BLANK); // Prevent NullPointerException for

			if(c==null)
			{
			//	System.out.println("Cell "+rowNo+" detected as null"); // xl Diagnostic
				return " ";
			}

			c.setCellType(Cell.CELL_TYPE_STRING);
			String data = c.getStringCellValue();
			return data;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return " ";
		}
	}
	
		/**
		 * 	Writes excel data.
		 *
		 * 	@param filePath the file path
		 * 	@param sheetName the sheet name
		 * 	@param rowNo the row no
		 * 	@param cellNo the cell no
		 * 	@param data the data
		 * 
		 */
		public static void writeExcelData(String filePath, String sheetName, int rowNo, int cellNo, String data)
		{
			try
			{
				FileInputStream fileInput = new FileInputStream(filePath);
				Workbook wb = WorkbookFactory.create(fileInput);
				
				//---------------------------Re evaluate formulas for all sheets ------------------------------------------//
					//	wb.getCreationHelper().createFormulaEvaluator().evaluateAll();
					//	wb.setForceFormulaRecalculation(true);
				//---------------------------------------------------------------------------------------------------------//
				
				//wb.createSheet();
				Sheet st = wb.getSheet(sheetName);
				Row r = st.getRow(rowNo);
				if (r == null)
			        r = st.createRow(rowNo);
				Cell c = r.createCell(cellNo);
				if (c == null)
			        c = r.createCell(cellNo);
				c.setCellType(Cell.CELL_TYPE_STRING);
				c.setCellValue(data);
				FileOutputStream fileOut = new FileOutputStream(filePath);
				wb.write(fileOut);	
				fileOut.close();
			}
			catch(Exception e)
			{
				System.out.println("Exception:"+ e.getStackTrace());
			}
			
	}
		
		/**
		 * Gets the excel row count.
		 *
		 * @param filePath the file path
		 * @param sheetName the sheet name
		 * @return the excel row count
		 */
		public static int getExcelRowCount(String filePath, String sheetName)
		{
			int rowNo = 0;
			try
			{
				FileInputStream fileInput = new FileInputStream(filePath);
				//System.out.println("filepath is"+filePath);
				Workbook wb = WorkbookFactory.create(fileInput);
				Sheet st = wb.getSheet(sheetName);
				//System.out.println("sheetname is"+sheetName);
				rowNo = st.getLastRowNum();
				//System.out.println("rownumber is"+rowNo);

				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return rowNo+1;
	}
		
		/**
		 * Gets the excel cell count.
		 *
		 * @param filePath the file path
		 * @param sheetName the sheet name
		 * @param rowNo the row no
		 * @return the excel cell count
		 */
		public static int getExcelCellCount(String filePath, String sheetName, int rowNo)
		{
			try
			{
				FileInputStream fileInput = new FileInputStream(filePath);
				Workbook wb = WorkbookFactory.create(fileInput);
				Sheet st = wb.getSheet(sheetName);
				Row r = st.getRow(rowNo);
				System.out.println("row r"+rowNo);
				return r.getLastCellNum();
			}
			catch(Exception e)
			{
				System.err.println("Error in getting cell count\n");
				return -1; 
			}
	}
		
		/**
		 * Gets the excel data.
		 *
		 * @param filePath the file path
		 * @param sheetName the sheet name
		 * @param rowNo the row no
		 * @param cellNo the cell no
		 * @return the excel data
		 */
		public static Object getBooleanExcelData(String filePath, String sheetName, int rowNo, int cellNo)
		{
			try
			{
				File f = new File(filePath);
				FileInputStream fileInput = new FileInputStream(f);
				Workbook wb = WorkbookFactory.create(fileInput);
				Sheet st = wb.getSheet(sheetName);			
				Row r = st.getRow(rowNo); 			
				
				if(r==null)
				{
					//System.out.println("Row "+rowNo+" detected as null"); // xl Diagnostic
					return " ";
				}		
				
				Cell c = r.getCell(cellNo,Row.RETURN_NULL_AND_BLANK); // Prevent NullPointerException for 
				
				if(c==null)
				{
				//	System.out.println("Cell "+rowNo+" detected as null"); // xl Diagnostic
					return " ";
				}
				
				Object data = c.getBooleanCellValue();
				return data;
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return " ";
			}
		}

	public static void writeResultToExcel(String path, String sheetName, int i, String result) {

		Workbook wb;
		try {
			FileInputStream file = new FileInputStream(path);
			wb = WorkbookFactory.create(file);
			Sheet sheet = wb.getSheet(sheetName);
			// int rowToUpdate = sheet.getLastRowNum() + 1;

			writeExcelData(path, sheetName, i, 3, result);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	//@Author Srikiran
	/** This method LoadWorkBook loads the workbook of the defined file and returns the value of workbook
	 *
	 * @param filePath
	 * @param
	 * @return WorkBook Value
	 */
	public static Workbook loadWorkBook(String filePath) {
		Workbook wb =null;
		try{
			FileInputStream fis = new FileInputStream(filePath);
			wb = WorkbookFactory.create(fis);
		}catch (Exception e){
			System.out.println("WorkBook loaded failed - error message displayed is " + e.getMessage());
			e.printStackTrace();
		}
		return wb;
	}

	//@author Srikiran
	/** This method GetSheet gets the sheet value of the defined workbook and returns sheet value
	 *
	 * @param filePath, sheetName
	 * @param
	 * @return
	 */
	public static Sheet getSheet(String filePath, String sheetName) {
		Sheet sheetValue;
		Workbook wb = loadWorkBook(filePath);
		sheetValue = wb.getSheet(sheetName);
		return sheetValue;
	}

	/** This method GetSheet gets the sheet value of the defined workbook and returns sheet value
     *
     * @param filePath, SheetIndex
     * @param
     * @return
     */
    public static Sheet getSheet(String filePath, int sheetIndex) {
		Sheet sheetValue;
		Workbook wb = loadWorkBook(filePath);
		sheetValue = wb.getSheetAt(sheetIndex);
		return sheetValue;
    }

	/** This method SearchTextFindCellAddress is to search a text in a excel sheet and return the cell address (row,column)
	 *
	 *@param filePath, sheetName, row, col, data
	 *@return none
	 */
	@SuppressWarnings("deprecation")
	public static int[] searchTextFindCellAddress(String filePath, String sheetName, String SearchText) {
		Sheet sheet = getSheet(filePath, sheetName);
		for(Row row : sheet) {
			for(Cell cell : row) {
				if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if(cell.getRichStringCellValue().getString().trim().equals(SearchText)) {
						return new int[] {row.getRowNum(), cell.getColumnIndex()};
					}
				}
			}
		}
		return new int[] {,};
	}

    /**
     * This method SearchTextFindCellAddress is to search a text in a excel
     * sheet and return the cell address (row,column)
     *
     * @param filePath, sheetIndex, row, col, data
     * @return none
     */
    public static int[] searchTextFindCellAddress(String filePath, int sheetIndex, String SearchText) {
        Sheet sheet = getSheet(filePath, sheetIndex);
        for (Row row : sheet) {
            for (Cell cell : row) {
                if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
                    if (cell.getRichStringCellValue().getString().trim()
                            .equals(SearchText)) {
                        return new int[] { row.getRowNum(),
                                cell.getColumnIndex() };
                    }
                }
            }
        }
        return new int[] {,};
    }

	//@Srikiran
	/** This method SearchTextFindCellAddress is to search a text in a excel sheet and return the cell address (row,column)
	 *
	 *@param filePath, sheetName, row, col, data
	 *@return none
	 */
	public static int searchTextFindCellRoworColumn(String filePath, String sheetName, String SearchText, String rowORcolumn) {

		int i=0;
		Sheet sheet = getSheet(filePath, sheetName);

		for(Row row : sheet) {
			for(Cell cell : row) {
				if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if(cell.getRichStringCellValue().getString().trim().equals(SearchText)) {
						//System.out.println(cell.getRichStringCellValue().getString());
						switch(rowORcolumn) {
							case "Row":
								i=row.getRowNum();
								break;
							case "Column":
								i=cell.getColumnIndex();
								break;
							default:
								i=-1;

						}
					}
				}
			}
		}
		return i;
	}

    /** This method CreateCellSetValue is to enter a value by creating a new row to the cell of an excel sheet
     *
     *@param filePath, sheetName, row, col, data
     *@return none
     */
    public static int createCellSetValue(String filePath, String sheetName, int col, String data) throws IOException {
        Sheet sheet = getSheet(filePath, sheetName);
        int row = sheet.getLastRowNum();
        row = row+1;
        Row rowValue = sheet.createRow(row);
        Cell cellValue=rowValue.createCell(col);
        cellValue.setCellValue(data);
        closeWorkBook(sheet.getWorkbook(), filePath);
        return row;
    }


	/** This method getrowvalue gets the Row value of the defined Sheet and returns Row value
	 *
	 * @param filePath, sheetName, rowNumber
	 * @param
	 * @return rowValue
	 */
	public static Row getrowvalue(String filePath, String sheetName, int rowNumber) {
		Sheet SheetValue = getSheet(filePath, sheetName);
		Row rowValue = SheetValue.getRow(rowNumber);
		if(rowValue==null)rowValue = SheetValue.createRow(rowNumber);
		return rowValue;
	}
	/** This method getLastCellinColumn gets last cell of a column and enters values in the target cell
	 *
	 * @param filePath
	 * @param sheetName
	 * @param column
	 * @return
	 */

	public static int getLastCellinColumn(String filePath, String sheetName, int column){
		Sheet sheet = getSheet(filePath, sheetName);
		int lastRow = sheet.getLastRowNum();
		while (lastRow >= 0 && ((sheet.getRow(lastRow).getCell(column) == null) || (sheet.getRow(lastRow).getCell(column).getStringCellValue().equalsIgnoreCase("")))) {
			lastRow--;
		}
		return lastRow;
	}

	/** This method CloseWorkBook Closes the workbook of the defined file and returns none
	 *
	 * @param filePath
	 * @param
	 * @return
	 */
	public static void closeWorkBook(Workbook wb, String filePath) throws IOException {
		FileOutputStream fileOut = new FileOutputStream(filePath);
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static int getTestDataRowNum(String filePath, String sheetName,String productName){
		Sheet sheet = getSheet(filePath, sheetName);
		int colNum=0;
		String status=null;
		Cell cell=null;
		for(int i=1;i<sheet.getLastRowNum();i++){
			Row r=sheet.getRow(i);
			 cell=r.getCell(colNum,Row.RETURN_NULL_AND_BLANK);
			if(cell.getStringCellValue().equals(productName)){
				  cell=r.getCell(5,Row.RETURN_NULL_AND_BLANK);
				 if(cell==null){
					 return i;
				 }
			 }

		}
		return 0;
	}

	/** This method getNoofSheets gets the active sheet count of the defined workbook and returns sheet count
	 *
	 * @param filePath
	 * @param
	 * @return
	 */
	public static int getNoofSheets(String filePath) {
		Workbook wb = loadWorkBook(filePath);
		return wb.getNumberOfSheets();
	}

	/** This method getSheetName gets the sheet name
	 *
	 * @param filePath
	 * @param
	 * @return String sheet name
	 */
	public static String getSheetName(String filePath, int sheetIndex) {
		Workbook wb = loadWorkBook(filePath);
		return wb.getSheetName(sheetIndex);
	}

	/** This method gets the active sheet name form the Workbook
	 *
	 * @param * @return Sheet Name
	 */
	public static String getActiveExcelSheetName(String filePath){
		Workbook wb = loadWorkBook(filePath);
		return wb.getSheetName(wb.getActiveSheetIndex());
	}

}


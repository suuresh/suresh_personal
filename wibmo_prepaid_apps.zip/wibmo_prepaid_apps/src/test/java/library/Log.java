package library;




import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.libraries.Log; 
public class Log 
{
	//private static final Logger log = LoggerFactory.getLogger(Log.class);
	private static final Logger log = LoggerFactory.getLogger(Log.class);
	public static void info(String infoMsg)
	{
//com.libraries.Log.info(infoMsg); if(BaseTest1.deviceTrialRun) return; // Distinguish between Individual Run & Suite Run

// include non null check for getTest()
		log.info(infoMsg);
		ExtentTestManager.getTest().log(LogStatus.INFO,infoMsg);

	}
	//@author:Srikiran
	public static void error(String infoMsg)
	{
		//com.libraries.Log.info(infoMsg); if(BaseTest1.deviceTrialRun) return; // Distinguish between Individual Run & Suite Run
		// include non null check for getTest()
		ExtentTestManager.getTest().log(LogStatus.ERROR,infoMsg);
//		ExtentTestManager.getTest().addScreenCapture(screenshotpath);
	}
	//@author:Srikiran
	public static void pass(String infoMsg)
	{
		//com.libraries.Log.info(infoMsg); if(BaseTest1.deviceTrialRun) return; // Distinguish between Individual Run & Suite Run

		// include non null check for getTest()
		ExtentTestManager.getTest().log(LogStatus.PASS,infoMsg);
	//	ExtentTestManager.getTest().addScreenCapture(screenshotpath);

	}
	//@author:Srikiran
	public static void fail(String infoMsg)
	{
		//com.libraries.Log.info(infoMsg); if(BaseTest1.deviceTrialRun) return; // Distinguish between Individual Run & Suite Run

		// include non null check for getTest()
		ExtentTestManager.getTest().log(LogStatus.FAIL,infoMsg);
//		ExtentTestManager.getTest().addScreenCapture(screenshotpath);
	}

	//@author:Srikiran
	public static void tagScreeshot(String screenshotpath)
	{
		// include non null check for getTest()
		ExtentTestManager.getTest().addScreenCapture(screenshotpath);
	}
	
	public static void groupPass(String testName)
	{
		//com.libraries.Log.info("========== Passed: "+testName+" ==========");if(BaseTest1.deviceTrialRun) return;
		
		ExtentTestManager.getTest().log(LogStatus.PASS,"========== Passed: "+testName+" ==========");
	}
	
	/**
	 * 
	 * 
	 * @param skipMsg
	 */
	public static void skip(String skipMsg) // Please Note : This method is to be called from TestScripts only followed by script exit. 
	{
		//com.libraries.Log.info(skipMsg);if(BaseTest1.deviceTrialRun) return;
		
		try
		{
			if(ExtentTestManager.getTest()==null) {System.err.println("Warning : Test not initialised"); return;}
			
			ExtentTestManager.getTest().log(LogStatus.SKIP,skipMsg);
		}
		catch(Exception e)
		{
			System.err.println("Unable to log skip message to Extent  \n"+e.toString());e.printStackTrace();
		}			
	}
}

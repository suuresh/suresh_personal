package library;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;

import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class DriverSuite {
	static List<XmlClass> classes = null;
	static String pkgName = "";
	static int t = 0;
	static String configXlPath = "./config/config.xlsx";
	static String suiteName = ExcelLibrary.getExcelData(configXlPath, "Android_setup", 8, 0);

	private static final int REGRESSION = 4,FULLSUITE=5, APPREGRESSION = 6; // execution Status Column Numbers in TestData.xlsx

	public static void main(String[] args) {

		String env, platform, testDataPath;
		int executionStatusColumn = 3;
		int pkgColumn = 5;

		env = ExcelLibrary.getExcelData(configXlPath, "Android_setup", 8, pkgColumn);
		XmlSuite suite = new XmlSuite();

		System.out.println("Suite : " + suiteName);
		suite.setName(suiteName);
		// suite.setParallel("tests");
		suite.setPreserveOrder("true"); // Preserve Order is Default

		int cr = ExcelLibrary.getExcelRowCount(configXlPath, "Program_Setup");
		int mr = ExcelLibrary.getExcelRowCount(configXlPath, "Modules");

		for (int i = 0; i <= cr; i++) {

			// ==== If Program is selected Yes then only create xml file ==== //
			if (ExcelLibrary.getExcelData(configXlPath, "Program_Setup", i, 2).equalsIgnoreCase("yes")) {
				// System.out.println("Setting suite xml");
				LinkedHashSet<String> devices = devices();
				if (devices.size() > 1) {
					suite.setThreadCount(devices.size());
					suite.setParallel("tests");
				}

				// Select TestData Execution Status Column //
				if (suiteName.contains("Regression"))
					executionStatusColumn = REGRESSION;
				if (suiteName.contains("App"))
					executionStatusColumn = APPREGRESSION;
				if (suiteName.contains("FullSuite"))
					executionStatusColumn = FULLSUITE;
				// ======================== //

				System.out.println("Generating Test classes. Please Wait ... ");
				for (String device : devices) {
					// ==== Set platform for TestData path ==== //

					platform = "Web";
					testDataPath = System.getProperty("user.dir")+ File.separator +"excel_lib"+File.separator + "TestData.xlsx";

					// ==== Assign Test and Test Name ==== //
					pkgName = ExcelLibrary.getExcelData(configXlPath, "Program_Setup", i, 1);
					String[] s = pkgName.split("\\.");
					String bankName = s[(s.length - 1)];

					XmlTest test = new XmlTest(suite);
					test.setName("Device_" + device.substring(0, 4) + "_Test");
					test.setPreserveOrder("true");

					// ==== Assign Parameter to Test ==== //
					HashMap<String, String> m = new HashMap();
					m.put("device-id", device);
					test.setParameters(m);

					// ==== Add classes from TestData.xlsx to Test==== //
					classes = new ArrayList();
					for (int j = 0; j <= mr; j++) {

						if (ExcelLibrary.getExcelData(configXlPath, "Modules", j, 1).equalsIgnoreCase("yes")
								&& ExcelLibrary.getExcelData(configXlPath, "Modules", j, 2).equalsIgnoreCase(device)) {

							t += 1;
							String module = ExcelLibrary.getExcelData(configXlPath, "Modules", j, 0);

							int tr = ExcelLibrary.getExcelRowCount(testDataPath, module);
//							System.err.println("testDataPath "+testDataPath);
//							System.err.println("module "+module);
//							System.err.println("executionStatusColumn "+executionStatusColumn);
							for (int k = 0; k <= tr; k++) {
								if (ExcelLibrary.getExcelData(testDataPath, module, k, executionStatusColumn)
										.equalsIgnoreCase("yes")) {
									XmlClass cls = new XmlClass(); // Modules list and TestData sheet names should match
									cls.setName("Prepaid.testScripts." + module.replace("_", ".") + "."
											+ ExcelLibrary.getExcelData(testDataPath, module, k, 0));
									classes.add(cls);
								}
							}
						}
					}
					test.setXmlClasses(classes);
				}
			}
		}

		// ==== Write Suite generated to scripts.xml ==== //
		File f = new File("./scripts.xml");
		try {
			FileWriter writer = new FileWriter(f);
			writer.write(suite.toXml());
			writer.flush();
			writer.close();
		} catch (IOException localIOException) {
			localIOException.printStackTrace();
		}
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("TestNG file generated");
	}

	public static LinkedHashSet<String> devices() {
		LinkedHashSet<String> devices = new LinkedHashSet<String>();

		int mr = ExcelLibrary.getExcelRowCount(configXlPath, "Modules");

		for (int j = 0; j <= mr; j++)
			if (ExcelLibrary.getExcelData(configXlPath, "Modules", j, 1).toLowerCase().contains("yes"))
				devices.add(ExcelLibrary.getExcelData(configXlPath, "Modules", j, 2));

		System.out.println(":: Devices " + devices + " ::");

	//	checkDevices(devices);

		return devices;
	}

	public static void checkDevices(LinkedHashSet<String> devices) {
		String checker = execCmd("adb devices");

		// === IOS === //
		for (String iChk : devices)
			if (iChk.length() > 25)
				checker += execCmd("xcrun instruments -s devices");
		// ======== //

		for (String device : devices)
			if (!checker.contains(device)) {
				System.err.println("-------------------------------------------------------------");
				System.err.println(" -------- Device with udid " + device + " not detected -------- ");
				System.err.println("-------------------------------------------------------------");
				System.exit(0);
			}
		if (checker.contains("ffline"))
			System.out.println("Warning : Device Offline ");
	}

	/**
	 * Executes a command line command and returns the output as a String
	 *
	 * @return String the command output
	 */
	public static String execCmd(String cmd) {
		try {
			java.util.Scanner s = new java.util.Scanner(Runtime.getRuntime().exec(cmd).getInputStream())
					.useDelimiter("\\A");
			return s.hasNext() ? s.next() : ""; // Implement close logic by storing in separate string before returning
		} catch (Exception e) {
			System.err.println("Error in Executing Cmd ");
			e.printStackTrace();
			return "";
		}
	}

	public static boolean isIos(String udid) {
		return udid.length() > 25;// || udid.contains("-");
	}

}

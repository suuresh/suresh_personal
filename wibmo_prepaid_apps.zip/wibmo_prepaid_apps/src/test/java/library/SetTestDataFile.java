package library;

import java.io.File;
import org.apache.commons.io.FileUtils;

public class SetTestDataFile // Currently to be used only for jenkins runs only  
{
	private static String env="";
	private static String configXl="./config/config.xlsx";
	
	public static void main(String[] args) 
	{
		String jenkinsParam="";
		
		
		if (args.length>0)
		{
			jenkinsParam=args[0];
			System.out.println("Jenkins_Param : "+jenkinsParam);			
		}
		
		
		if(jenkinsParam=="") // If not jenkins read environment from config
		{
		
			
			String packageName=ExcelLibrary.getExcelData(configXl, "Android_setup", 8,5);
			System.out.println("Reading Package from config file : "+packageName);
			
			if(packageName.contains("staging"))
				env="staging";
			if(packageName.contains("qa"))
				env="qa";		
			
			ExcelLibrary.writeExcelData(configXl, "Android_setup", 8,7,env); // Communicate env for Maven Execution
		}
		else
		{
			env=jenkinsParam;
			jenkinsConfigSelection();			
			return; 
		}	
		
		System.out.println("Environment : "+env);
		String excelPath="./excel_lib/"+env+"/TestData.xlsx";
		try
		{
			System.out.println("Copying TestData from "+env+" folder");
			FileUtils.copyFile(new File(excelPath),new File("./excel_lib/TestData.xls"));
			System.out.println("TestData successfully copied from "+env+" folder");
		}
		catch(Exception e){System.out.println("File copy failed\n"+e.getMessage());}		
	}
	
	public static void jenkinsConfigSelection()
	{
		String selectModule="Smoke"; // current jenkins configuration only for Smoke module		
		
		//==== Copy Jenkins TestData ==== //
		System.out.println("Copying scripts.xml for Jenkins Run");
		File jenkinsDataSource=new File("./scripts_jenkins/scripts.xml"),
			 jenkinsDataDest=new File("scripts.xml");
		
		try
		{
			FileUtils.copyFile(jenkinsDataSource, jenkinsDataDest);			
			Thread.sleep(3000);
		}
		catch(Exception e){System.err.println();e.printStackTrace();System.exit(0);}
		//=============================== //
		
		// Communicate env for Maven execution
		ExcelLibrary.writeExcelData(configXl, "Android_setup",8,7,env);
		
		// Set app package to Environment 
		if(!ExcelLibrary.getExcelData(configXl, "Android_setup", 8 , 5).contains("staging"))
			ExcelLibrary.writeExcelData(configXl, "Android_setup", 8,5,"com.enstage.wibmo.staging.hdfc");		
		
		// Selecting only Smoke as of now.
		
//		try{
//			for(int i=0;i<20;i++)
//				if(ExcelLibrary.getExcelData(".\\config\\config.xls", "Modules", i , 0).contains(selectModule))	
//				{				
//					ExcelLibrary.writeExcelData(".\\config\\config.xls", "Modules", i , 1, "Yes");
//					return;
//				}
//			}
//		catch(Exception e)
//			{
//				System.out.println("Configuration setting was not done\n"+e.getMessage());
//			}
	}
	
	

}

package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.testng.SkipException;
import org.testng.annotations.Test;


import static io.restassured.RestAssured.given;


public class CardRenewalAPI extends APIBaseTest {

	ActivationPayLoad activation = new ActivationPayLoad(driver);
	int urn;
	int last4Digits;
	String customerId;
	
	JsonPath jsonValue;
	String jsonResponseMessage;
	String jsonResponseCode;
	boolean responseCodeAssert = false;
	boolean responseMessageAssert= false;
	boolean responseURNAssert= false;
	boolean responseCustomerIdAssert= false;

	// test method to call AeroPayloadBody() method for the api request body
	// formation
	@Test()
	public void CardRenewal() {
		try {
			activation.AeroPayloadBody("CardRenewal");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Sanity Card Renewal Test Method
	@Test(dataProvider = "CardRenewal_API", dataProviderClass = DataProviderUtility.class)
	public void CardRenewal(String testCaseID, String testScenario,String requestPayLoad, String responseCode, String responseMessage,String responseStatusCode, String preCondition, String csr_report_Validation) {
		try{
			Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
			//Precondition
			Response preConditionRequestResponse = null;
			if (!preCondition.equals(null) && !preCondition.equals("")) {
				Log.info( "Executing Precondition :"+ preCondition);
				preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
				if (preConditionRequestResponse != null) {
					String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
					Log.info( "Precondition of " + preCondition+ "is Successfull");
					Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
					if (!preConditionAPIResponseCode.equals("00")){
						System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
						throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");					
					}
				}
			}
	
			JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
			last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
			urn = Integer.parseInt(requestObject.get("urn").toString());
			customerId = requestObject.get("customerId").toString();
			
			switch (preCondition) {			
			// to replace URN with invalid URN
			case "Invalid URN":
				Log.info( "actual URN :"+ urn);
				requestObject.replace("urn",urn - 1);
				break;
			// to replace Last4Digits with invalid Last4Digits
			case "Invalid CardNo":
				Log.info( "actual last4Digits :"+ last4Digits);
				requestObject.replace("last4Digits", last4Digits + 1);
				break;
			// to replace caustomer id with invalid customer id
			case "Invalid CustID":
				Log.info( "actual customerId :"+ customerId);
				requestObject.replace("customerId", customerId + "abc");
				break;
			}

			Log.info( "requestPayLoad :"+requestObject);
			
			Log.info( "Post URL: " + cardRenewalPost);
	
			Response response = given().contentType("application/json")
					.body(requestObject).when().log().body().post(cardRenewalPost)
					.then().and()
					.extract().response();
			
			int actualResponseCode = response.getStatusCode();
			boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
			
			if(!response.asString().isEmpty()){
				jsonValue = basePayLoad.jsonObject(response);
				jsonResponseMessage = jsonValue.get("responseMessage");
				jsonResponseCode = jsonValue.get("responseCode");
		
				Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
		
				responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
				responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				responseURNAssert = jsonValue.get("urn").toString().equalsIgnoreCase(requestObject.get("urn").toString());
				responseCustomerIdAssert = jsonValue.get("customerId").toString().equalsIgnoreCase(requestObject.get("customerId").toString());
			}
	
			if (responseCodeAssert && responseMessageAssert && responseURNAssert&& responseCustomerIdAssert) {				
				Log.info("URN: " + jsonValue.get("urn"));
				Log.info("Cust ID: " + jsonValue.get("customerId").toString());
				Log.info("Card Status: "+ jsonValue.get("description").toString());
				Log.info("Card Renewal API Event Request response is "+ response.asString());
				Log.pass( "Case execution is Pass");
			} else {
				if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
					Log.info("Card Renewal API Event Request Status is "+ response.statusLine());
					Log.pass("Card Renewal API Event Request is Successfull as per testcase");
				}else{
					if(responseCodeAssert && responseMessageAssert ){
						Log.info("Card Renewal API Event Request response is "+ response.asString());
						Log.pass( "Case execution is Pass");
					}else{
						Log.info("Card Renewal API Event Request response is "+ response.asString());
						Log.fail( "Case execution is Fail");
					}
				}
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
		Log.fail("Card Renewal API Event Request is Unsuccessfull");
	}
	}	
}
package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;


import static io.restassured.RestAssured.given;

public class AMLInquiryAPI extends APIBaseTest{
	
	ActivationPayLoad activation = new ActivationPayLoad(driver);
	int i=1;
	
	int last4Digits;
	int urn;
	String customerId;
	
	JsonPath jsonValue;
	String jsonResponseMessage;
	String jsonResponseCode;
	boolean responseCodeAssert = false;
	boolean responseMessageAssert= false;
	int[] Cell = null;
	
		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void AMLInquiry()
		{
			try {
				activation.AeroPayloadBody("AMLInquiry");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card AMLInquiry Test Method
		@Test( dataProvider = "AMLInquiry_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CreateCardAPI"
		public void AMLInquiry(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition) {
			try{

				//precondition
				if (!preCondition.equals(null) && !preCondition.equals("")) {
					Response preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
					if (preConditionRequestResponse != null) {
						String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
						String preConditionAPIResponseMesssage = basePayLoad.getResponseValue(preConditionRequestResponse,"responseMessage");
						if (!preConditionAPIResponseCode.equals("00")){
							System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
						}
					}
				}
				
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
				urn = Integer.parseInt(requestObject.get("urn").toString());
				customerId = requestObject.get("customerId").toString();
				
				switch (preCondition) {			
				// to replace URN with invalid URN
				case "Invalid URN":
					Log.info( "actual URN :"+ urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "Invalid CardNo":
					Log.info( "actual last4Digits :"+ last4Digits);
					requestObject.replace("last4Digits", last4Digits + 1);
					break;
				// to replace caustomer id with invalid customer id
				case "Invalid CustID":
					Log.info( "actual customerId :"+ customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;
				}
				Log.info( "requestPayLoad :"+ requestObject.toString());
				
				Log.info( cardAMLInquiryPost);
				Response response = given().contentType("application/json").
						body(requestObject).
						when().log().body().post(cardAMLInquiryPost).
						then()
//						.and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
//						.contentType(ContentType.JSON).and()
						.extract().response();
				
				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
				
				if(!response.asString().isEmpty()){
					jsonValue= basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
					
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
					Cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",String.valueOf(requestObject.get("last4Digits")));
				}			
				
				if(responseCodeAssert && responseMessageAssert)
				{
					if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {	
						Assert.assertEquals(String.valueOf(jsonValue.get("urn")), String.valueOf(requestObject.get("urn")));
						Assert.assertEquals(String.valueOf(jsonValue.get("customerId")), String.valueOf(requestObject.get("customerId")));						
					} 
					Log.info("Card AML Inquiry API Event Request responseMessage is "+ response.asString());
					Log.pass("Card AML Inquiry API Event Request is Successfull");
				}else {
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.info("Card AML Inquiry API Event Request Status is "+ response.statusLine());
						Log.pass("Card AML Inquiry API Event Request is Successfull as per testcase");
					}else{
						Log.info("Card AML Inquiry API Event Request responseMessage is "+ response.asString());
						Log.fail("Card AML Inquiry API Event Request is Unsuccessfull");
					}
				}				
				if(responseMessage.equalsIgnoreCase("SUCCESS")){
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", Cell[0], 21, "true");
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", Cell[0], 22, response.asString());
					i++;
				}			
			}
			catch(Exception e){
				Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
				Log.fail("Card AML Inquiry API Event Request is Unsuccessfull");
			}	
		}
}
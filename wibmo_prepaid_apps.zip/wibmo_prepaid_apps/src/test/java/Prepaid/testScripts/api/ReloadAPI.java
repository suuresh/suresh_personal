package Prepaid.testScripts.api;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import java.util.ArrayList;

import static Prepaid.testScripts.kotak.BaseTest.browser;
import static io.restassured.RestAssured.given;

/**
 * @author ${Srikiran D}
 *
 */

public class ReloadAPI extends APIBaseTest {


	String testDataExcel = System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	int i = 1;
	int loadAmount;
	int transactionFee;
	String jsonResponseclientTxnId;
	Response response;
	int last4Digits;
	int urn;
	String customerId;
	int[] Cell = null;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	Response preConditionRequestResponse;
	String unloadClientTxnId;

	// test method to call AeroPayloadBody() method for the api request body
	// formation
	@Test()
	public void ReloadBody() {
		try {
			basePayLoad.AeroPayloadBody("Reload");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Sanity Reload Test Method
	@Test(dataProvider = "ReloadCard_api", dataProviderClass = DataProviderUtility.class)// , dependsOnMethods= "CreateCardAPI"
	public void ReloadCard(String testCaseID, String testScenario,String requestPayLoad, String responseCode, String responseMessage,String responseStatusCode, String preCondition, String reportValidation) {
		try{
			String [] required = reportValidation.split(",");
		String jsonRequestReferenceNumber = null;
		System.out.println( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
			Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
		// if testcase has a precondition then executing the precondition scenarion and validating the result

		/*if (!preCondition.equals(null) && !preCondition.equals("")) {
			preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
			System.out.println(preCondition);
			System.out.println(requestPayLoad);
			if (preConditionRequestResponse != null) {
				String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
				String preConditionAPIResponseMesssage = basePayLoad.getResponseValue(preConditionRequestResponse,"responseMessage");
				if (!preConditionAPIResponseCode.equals("00")){
					Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
					Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.toString());
					throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");					
				}
			}
		}*/
		// To update AML profile prameters value
			//basePayLoad.UpdateAMLProfileValue(testCaseID);
			// loginIntoCSR();
			// CSRBasePage csr=PageFactory.initElements(driver,
			// CSRBasePage.class);
			// csr.processCache("6019|CLEAR|AML_PROFILE");
			// csrSignOut();
			// driver.close();
			System.out.println(requestPayLoad);
		JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
		//System.out.println(requestPayLoad);
		last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
//		last4Digits = requestObject.get("last4Digits").toString();
		urn = Integer.parseInt(requestObject.get("urn").toString());
		customerId = requestObject.get("customerId").toString();
		switch (preCondition) {			
		// to replace URN with invalid URN
		case "Invalid URN":
			Log.info( "actual URN :"+ urn);
			requestObject.replace("urn",urn - 1);
			break;
		// to replace Last4Digits with invalid Last4Digits
		case "Invalid CardNo":
			Log.info( "actual last4Digits :"+ last4Digits);
			requestObject.replace("last4Digits", last4Digits + 1);
			break;
		// to replace customer id with invalid customer id
		case "Invalid CustID":
			Log.info( "actual customerId :"+ customerId);
			requestObject.replace("customerId", customerId + "abc");
			break;
		// to replace customer id with invalid customer id
		case "Unload":
		case "Duplicate Reload Event":
			unloadClientTxnId = basePayLoad.getResponseValue(preConditionRequestResponse,"clientTxnId");
			requestObject.replace("originalClientTxnId", unloadClientTxnId);
			break;
		case "Invalid Reload Event":
			unloadClientTxnId = basePayLoad.getClientTxnID();
			requestObject.replace("originalClientTxnId", unloadClientTxnId);
			break;
		}
		Log.info( "requestObject :"+ requestObject.toString());
		Log.info( "requestObject Post URL :"+cardReloadPost);
			System.out.println( "requestObject Post URL :"+cardReloadPost);
		response = given().contentType("application/json").body(requestObject)
				//.when().log().body().post(cardReloadPost).then()
				.when().log().body().post("https://aero-api.pc.enstage-sas.com/v1/6019/creditAccount/IN20014/ReLOAD_JM_SBDFFUslsMoo2h0")
				.then().and().extract().response();
		
		int actualResponseCode = response.getStatusCode();
		boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

		if(!response.asString().isEmpty()){
			// Response is in RAW format, JsonPath class has ability to convert into JsonPath.
			jsonValue= basePayLoad.jsonObject(response);
			jsonResponseMessage = jsonValue.get("responseMessage");
			jsonResponseCode = jsonValue.get("responseCode");
			
			Log.info( "Json Status Code"+ actualResponseCode + ", Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
			System.out.println("jsonValue"+response.asString());
			responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
			responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
			System.out.println(requestObject.get("urn"));
			Cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",String.valueOf(requestObject.get("urn")));
		}		

		if(responseCodeAssert && responseMessageAssert){			
			if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {				
				loadAmount = jsonValue.get("transactionAmount");
				
				transactionFee = requestObject.get("txnFee")!=null?Integer.parseInt(requestObject.get("txnFee").toString()):0;
				
				jsonRequestReferenceNumber = jsonValue.get("accosaRefNo");
				jsonResponseclientTxnId = jsonValue.get("clientTxnId");
				Log.info( "RequestReferenceNumber "+ jsonRequestReferenceNumber);
				Assert.assertEquals(jsonValue.get("urn").toString(),requestObject.get("urn").toString());
				Assert.assertEquals(jsonValue.get("customerId").toString(),requestObject.get("customerId").toString());
			}
			Log.info("Reload API Event Request responseMessage is "+ response.asString());
			Log.pass("Reload API Event Request is Successfull");
		} else {
			if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
				Log.info("Reload API Event Request Status is "+ response.statusLine());
				Log.pass("Reload API Event Request is Successfull as per testcase");
			}else{
				Log.info("Reload API Event Request responseMessage is "+ response.asString());
				Log.fail("Reload API Event Request is Unsuccessfull");
			}
		}		

			if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
				// updating the Card Last 4 Digits, URN and Customer ID details on Reload API Data sheet
//				ExcelLibrary.writeExcelData(testDataExcel, "Unload", i, 10,String.valueOf(requestObject.get("last4Digits")));
//				ExcelLibrary.writeExcelData(testDataExcel, "Unload", i, 11,String.valueOf(requestObject.get("urn")));
//				ExcelLibrary.writeExcelData(testDataExcel, "Unload", i, 12,String.valueOf(requestObject.get("customerId")));
				ExcelLibrary.writeExcelData(testDataExcel, "CardDetails", Cell[0], 7,"true");
				ExcelLibrary.writeExcelData(testDataExcel, "CardDetails", Cell[0], 8,response.asString());
				i++;
			}
		boolean transactionValidation = false;
		if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
			String cardNumber = ExcelLibrary.getExcelData(testDataExcel, "CardDetails",Cell[0], 0);
			Log.info("**************In CSR Application to validate the Reload card event in prepaid details**************");
			Log.info( "CSR Prepaid Details for an Reload card");
			initBrowser("chrome", "CSR");
			Log.info("Browser stated and Application launched");
			String[] Credentials = getAppCredentials("CSR");
			LoginPage csrLogin = new LoginPage(driver);
			csrLogin.csrLogin(Credentials[0], Credentials[1]); // Username, Password

			PrepaidDetailsPage prp = new PrepaidDetailsPage(driver);
			prp.checkPrepaidDetails(cardNumber);
			Log.info( "cardNumber " + cardNumber);
			String txnfeetype = ExcelLibrary.getExcelData(testDataExcel, "General",5, 5);
			if(txnfeetype.equalsIgnoreCase("Inclusive")){
				loadAmount = loadAmount;
			}else{
				loadAmount = loadAmount-transactionFee;
			}
			transactionValidation = prp.CSRValidateCardTransaction("Reload", loadAmount, jsonRequestReferenceNumber);
			if (transactionValidation) {
				Log.pass("CSR Reload Transaction Validation is Successfull");
			} else {
				Log.fail("CSR Reload Transaction Validation is Not Successfull");
			}
		}
		
		ArrayList<Boolean> reportvalidation= new ArrayList<Boolean>();
		//External Activation Report Validation
		if(jsonResponseMessage.equalsIgnoreCase("SUCCESS") && required[1].equalsIgnoreCase("true")){
			Log.info("**************In External Report to validate the Reload card in Reload report**************");
			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Card Load/Unload Report");
			enhancedReports.selectReportType("Recharge Report");
			enhancedReports.generateReport(Generic.currentDate("yyyy-MM-dd"), Generic.currentDate("yyyy-MM-dd"));
			enhancedReports.selectProductreport(basePayLoad.getProductName());
			enhancedReports.searchRecordInReport("//div[contains(text(),'"+urn+"')]");		
			reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed());
			Log.info(urn+" URN is populating in report");
			reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4Digits+"')]")).isDisplayed());
			Log.info(last4Digits+" last4Digits is populating in report");
			reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+jsonResponseclientTxnId+"')]")).isDisplayed());
			Log.info(jsonResponseclientTxnId+" clientTxnId is populating in report");

			if (!reportvalidation.contains(false)) {
				Log.pass("CSR Card Reload Report Validation is Successfull");
			} else {
				Log.fail("CSR Card Reload Report Validation is Not Successfull");
			}
		}
//	} catch (ClassNotFoundException | SQLException | IOException e) {
		} catch (Exception e) {
		Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
		Log.fail("Card Reload API Event Request is Unsuccessfull");
		} 
	}
}
package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;


import java.util.ArrayList;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertTrue;

public class CardUnblockAPI extends APIBaseTest{

	ActivationPayLoad activation = new ActivationPayLoad(driver);
	String sanityTestDataExcel = System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	String jsonRequestReferenceNumber;
	int amount;
	int i=1;
	int last4Digits;
	int urn;
	String customerId;
	
	int[] Cell = null;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	
		//test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void CardUnBlock()
		{
			try {
				activation.AeroPayloadBody("CardUnblock");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card Unblock Test Method
		@SuppressWarnings("unchecked")
		@Test(dataProvider = "CardUnblock_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CardBlockAPI"
		public void CardUnBlock(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition,  String reportValidation) {
			try{
				String [] required = reportValidation.split(",");
				Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
				//Precondition
				if (!preCondition.equals(null) && !preCondition.equals("")) {
					Response preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
					if (preConditionRequestResponse != null) {
						String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
						String preConditionAPIResponseMesssage = basePayLoad.getResponseValue(preConditionRequestResponse,"responseMessage");
						if (!preConditionAPIResponseCode.equals("00")){
							System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
							throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");					
						}
					}
				}
				
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				
				last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
				urn = Integer.parseInt(requestObject.get("urn").toString());
				customerId = requestObject.get("customerId").toString();
				
				switch (preCondition) {			
				// to replace URN with invalid URN
				case "Invalid URN":
					Log.info( "actual URN :"+ urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "Invalid CardNo":
					Log.info( "actual last4Digits :"+ last4Digits);
					requestObject.replace("last4Digits", last4Digits + 1);
					break;
				// to replace caustomer id with invalid customer id
				case "Invalid CustID":
					Log.info( "actual customerId :"+ customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;
				}
				Log.info( "requestPayLoad :"+ requestPayLoad);
				
				Log.info( cardUnblockPost);
				System.out.println("cardUnblockPost: "+cardUnblockPost);
				Response response = given().contentType("application/json").
						body(requestObject).
						when().log().body().post(cardUnblockPost).
						then().and()
//						.assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
//						.contentType(ContentType.JSON).and()
						.extract().response();
		
				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
				
				if(!response.asString().isEmpty()){
					jsonValue= basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					
					Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode + ", Status Code is "+ actualResponseCode);
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				
					Cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",String.valueOf(requestObject.get("last4Digits")));
				}
				if(responseCodeAssert && responseMessageAssert)
				{
					if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
						jsonRequestReferenceNumber = jsonValue.get("accosaRefNo");				
						Assert.assertEquals(jsonValue.get("urn").toString(), requestObject.get("urn").toString());
						Assert.assertEquals(jsonValue.get("customerId").toString(), requestObject.get("customerId").toString());
						Log.info( "RequestReferenceNumber "+ jsonRequestReferenceNumber);
					} 
					Log.info("Card Unblock API Event Request responseMessage is "+ response.asString());
					Log.pass("Card Unblock API Event Request is Successfull");
				}else {
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.info("Block API Event Request Status is "+ response.statusLine());
						Log.pass("Block API Event Request is Successfull as per testcase");
					}else{
						Log.info("Card Unblock API Event Request responseMessage is "+ response.asString());
						Log.fail("Card Unblock API Event Request is Unsuccessfull");
					}
				}
				
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")){		
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", Cell[0], 21, "true"); //update Card Unblock event as true if performed
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", Cell[0], 22, response.asString()); //update Card Unblock event as true if card is active
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", Cell[0], 4, "Active");
					i++;
				}				
				boolean transactionValidation = false;
				if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
					String cardNumber = ExcelLibrary.getExcelData(sanityTestDataExcel, "CardDetails", Cell[0], 0);
					Log.info("**************In CSR Application to validate the card unblock event in prepaid details**************");
					Log.info("CSR Prepaid Details for an card unblock event");
					initBrowser("chrome", "CSR");
					Log.info( "Browser stated and Application launched");
					String[] Credentials = getAppCredentials("CSR");
					System.out.println("Username and password is "+Credentials[0]+" password is "+Credentials[1]);
					LoginPage csrLogin= new LoginPage(driver);
					csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password
					Log.info( "Successfull logged into Application");
					
					PrepaidDetailsPage prp= new PrepaidDetailsPage(driver);
					prp.checkPrepaidDetails(cardNumber);
					transactionValidation = prp.CSRValidateCardTransaction("Unblock", amount, jsonRequestReferenceNumber);
					assertTrue(transactionValidation);
					if (transactionValidation) {
						Log.pass("CSR Unblock Transaction Validation is Successfull");
					} else {
						Log.fail("CSR Unblock Transaction Validation is Not Successfull");
					}
				}
				
				ArrayList<Boolean> reportvalidation= new ArrayList<Boolean>();
				//External Activation Report Validation
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")&& required[1].equalsIgnoreCase("true")){
					Log.info("**************In External Report to validate for Card block event in Block/Unblock Report**************");
					initBrowser(BROWSER, "ExternalReports");
//					initBrowser("firefox", "ExternalReports");
					Log.info( "Browser started and Application launched");
					AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
//					WebDriverWait wait = new WebDriverWait(driver, 60000);
					enhancedReports.selectReport("Block/Unblock Report");
					enhancedReports.generateReport(Generic.currentDate("yyyy-MM-dd"), Generic.currentDate("yyyy-MM-dd"));
					enhancedReports.searchRecordInReport("//div[contains(text(),'"+urn+"')]");	
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed());
					Log.info(urn+" URN is populating in report");
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4Digits+"')]")).isDisplayed());
					Log.info(last4Digits+" last4Digits is populating in report");
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'CARD_UNBLOCK')]")).isDisplayed());
					Log.info("TEMP_BLOCK card is populating in report");
					
					if (!reportvalidation.contains(false)) {
						Log.pass("CSR Card Block/Unblock Report Validation is Successfull");
					} else {
						Log.fail("CSR Card Block/Unblock Report Validation is Not Successfull");
					}
				}
			}
			catch(Exception e){
				Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
				Log.fail("Card Unblock API Event Request is Unsuccessfull");
			}
		}		
}
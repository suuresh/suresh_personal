package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.testScripts.BaseTest1;

public class APIBaseTest extends BaseTest1
{

	public BasePayLoad basePayLoad = new BasePayLoad(driver);
//	public static final String baseURL = pf.getbaseURL();
	public static final String APIPAYLOAD_TESTDATA_XLSX_FILE_PATH = BaseTest1.APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	public static final String cardCreationPost = getapiPostUrl("CardCreation");
	public static final String cardReloadPost = getapiPostUrl("CardReload");
	public static final String cardUnloadPost = getapiPostUrl("CardUnload");
	public static final String cardInquiryPost = getapiPostUrl("CardInquiry");
	public static final String cardBlockPost = getapiPostUrl("CardBlock");
	public static final String cardUnblockPost = getapiPostUrl("CardUnblock");
	public static final String cardUpdateProfilePost = getapiPostUrl("CardUpdateProfile");
	public static final String cardTransactionInquiryPost = getapiPostUrl("CardTransactions");
	public static final String cardFundTransferPost = getapiPostUrl("CardFundTransfer");
	public static final String cardAMLInquiryPost = getapiPostUrl("CardAMLInquiry");
	public static final String cardWalletStatementPost = getapiPostUrl("CardWalletStatement");
	public static final String cardResetpinPost = getapiPostUrl("CardResetPin");
	public static final String cardUCICRegPost = getapiPostUrl("CardUCICReg");
	public static final String cardRenewalPost = getapiPostUrl("CardRenewal");

}

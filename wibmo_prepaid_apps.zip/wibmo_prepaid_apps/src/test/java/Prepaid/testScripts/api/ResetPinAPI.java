package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;


import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertTrue;

public class ResetPinAPI extends APIBaseTest{
	
	ActivationPayLoad activation = new ActivationPayLoad(driver);
	String sanityTestDataExcel = System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	String jsonRequestReferenceNumber;
	int amount;
	int i=1;
	String last4Digits;
	int urn;
	String customerId;
	String cardNumber;
	
	int[] Cell = null;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	
	Response preConditionRequestResponse;

	//Test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void ResetPin()
		{
			try {
				activation.AeroPayloadBody("ResetPin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card ResetPin Test Method
		@Test(dataProvider = "ResetPin_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CreateCardAPI"
		public void ResetPin(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition, String reportValidation) {
			try{
				if (!preCondition.equals(null) && !preCondition.equals("")) {
					preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
					if (preConditionRequestResponse != null) {
						String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
//						String preConditionAPIResponseMesssage = basePayLoad.GetResponseValue(preConditionRequestResponse,"responseMessage");
						cardNumber = basePayLoad.getResponseValue(preConditionRequestResponse, "cardNumber");
						if (!preConditionAPIResponseCode.equals("00")){
							System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
							throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");					
						}
					}
				}
				
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				
				last4Digits = requestObject.get("last4Digits").toString();
				urn = Integer.parseInt(requestObject.get("urn").toString());
				customerId = requestObject.get("customerId").toString();
				
				switch (preCondition) {			
				// to replace URN with invalid URN
				case "Invalid URN":
					Log.info( "actual URN :"+ urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "Invalid CardNo":
					Log.info( "actual last4Digits :"+ last4Digits);
					requestObject.replace("last4Digits", String.format("%04d", Integer.parseInt(last4Digits)+1));
					break;
				// to replace caustomer id with invalid customer id
				case "Invalid CustID":
					Log.info( "actual customerId :"+ customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;
				case "KYC Card":
				case "Non-KYC Card":
					requestObject.replace("last4Digits", Generic.getLast4DigitCardNumber(cardNumber));
					requestObject.replace("urn", basePayLoad.getResponseValue(preConditionRequestResponse, "urn"));
					requestObject.replace("customerId", basePayLoad.getResponseValue(preConditionRequestResponse, "customerId"));
					break;					
				}

				Log.info( "requestObject :"+ requestObject.toString());
				Log.info( cardResetpinPost);
				
				Response response = given().contentType("application/json").
						body(requestObject).
						when().log().body().post(cardResetpinPost).
						then()
//						.and().assertThat().statusCode(Integer.parseInt(responseStatusCode))
//						.and().contentType(ContentType.JSON).and()
						.extract().response();
				
				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

				if(!response.asString().isEmpty()){
					jsonValue= basePayLoad.jsonObject(response);
				
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");				
				
					Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
					
//					cell = csv.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",String.valueOf(requestObject.get("last4Digits")));
				}
				
				if(responseCodeAssert && responseMessageAssert){
					if (jsonResponseMessage.equalsIgnoreCase("Success")) {
						jsonRequestReferenceNumber = jsonValue.get("accosaRefNo").toString();				
						Assert.assertEquals(jsonValue.get("urn").toString(), requestObject.get("urn").toString());
						Assert.assertEquals(jsonValue.get("customerId").toString(), requestObject.get("customerId").toString());
						Log.info( "Resetpin RequestReferenceNumber "+ jsonRequestReferenceNumber);
					} 
					Log.pass("Card Resetpin API Event Request is Successfull");
					Log.info("Card Resetpin API Event Request responseMessage is "+ response.asString());
				}else {
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.info("Resetpin API Event Request Status is "+ response.statusLine());
						Log.pass("Resetpin API Event Request is Successfull as per testcase");
					}else{
						Log.fail("Resetpin API Event Request is Unsuccessfull");
						Log.info("Resetpin API Event Request responseMessage is "+ response.asString());
					}
				}
				
//				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")){		
//					excel.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 21, "true"); //update Card Unblock event as true if performed
//					excel.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 22, response.asString()); //update Card Unblock event as true if card is active
//					i++;
//				}	
				if (responseMessage.equalsIgnoreCase("SUCCESS") && (preCondition.equalsIgnoreCase("KYC Card") || preCondition.equalsIgnoreCase("Non-KYC Card"))) {
							
					Log.info("**************In CSR Application to validate the Card Resetpin event in prepaid details**************");
					Log.info("CSR Prepaid Details for an Card Resetpin event");
					initBrowser("chrome", "CSR");
					Log.info( "Browser stated and Application launched");
					String[] Credentials = getAppCredentials("CSR");
					System.out.println("Username and password is "+Credentials[0]+" password is "+Credentials[1]);
					LoginPage csrLogin= new LoginPage(driver);
					csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password
					Log.info( "Successfull logged into Application");
					
					PrepaidDetailsPage prp= new PrepaidDetailsPage(driver);
					Log.info( "cardNumber: "+cardNumber);
					prp.checkPrepaidDetails(cardNumber);
					boolean transactionValidation = prp.CSRValidateCardTransaction("Reset Pin", amount, jsonRequestReferenceNumber);
					assertTrue(transactionValidation);
					if (transactionValidation) {
						Log.pass("CSR Card Reset Pin Transaction Validation is Successfull");
					} else {
						Log.fail("CSR Card Reset Pin Transaction Validation is Not Successfull");
					}
				}
			}
			catch(Exception e){
				Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
				Log.fail("Card ResetPin API Event Request is Unsuccessfull");
			}	
		}
}
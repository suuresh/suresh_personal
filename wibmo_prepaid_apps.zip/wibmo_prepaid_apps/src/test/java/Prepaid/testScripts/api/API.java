package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.io.IOException;

import static io.restassured.RestAssured.given;

public class API extends APIBaseTest{

	ActivationPayLoad activation = new ActivationPayLoad(driver);

	String filepath = System.getProperty("user.dir");
	int i=0;

	String jsonResponseFullCardNumber;
	String cardLast4Digit;
	int jsonResponseURN;
	String jsonResponseCustID;

		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=1)
		public void ActivationBody()
		{
			try {
				activation.AeroPayloadBody("CreateCard");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Activation Test Method
		@Test(priority=2, dataProvider = "CreateCard_api", dataProviderClass = DataProviderUtility.class)
		public void CreateCardAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			i++;
			System.out.println("Sanity Activation ##########################"+i);
			// boolean reloadTest = true;
			JSONParser parser = new JSONParser();		// JsonParser and Jsonobject class are used to converst Json string to JSON Object.
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardCreationPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Activation API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response); /// Response is in RAW format, JsonPath class has ability to convert into JsonPath.

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");
			jsonResponseFullCardNumber = jsonValue.get("cardNumber");
			jsonResponseURN = jsonValue.get("urn");
			jsonResponseCustID = jsonValue.get("customerId");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Log.pass( "Case execution is Pass");
			System.out.println("ActivationRequest is successfully Executed");
			try {
				if(responseMessage.equalsIgnoreCase("SUCCESS"))
				{
					cardLast4Digit = Generic.getLast4DigitCardNumber(jsonResponseFullCardNumber);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card Details API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", i, 0, jsonResponseFullCardNumber);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", i, 1, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", i, 2, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", i, 3, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Reload API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 9, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 10, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 11, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on CardBlock API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 9, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 10, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 11, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card inquiry API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 7, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 8, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 9, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card UpdateProfile API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 8, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 9, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 10, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card TransactionInquiry API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 8, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 9, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 10, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card AMLInquiry API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 8, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 9, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 10, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card WalletSettlement API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 10, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 11, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 12, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card ResetPin API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 10, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 11, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 12, jsonResponseCustID);

						//updating the Card Last 4 Digits, URN and Customer ID details on Card FundTransfer API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 9, cardLast4Digit);
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 10, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 11, jsonResponseCustID);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=3)
		public void ReloadBody()
		{
			i=0;
			try {
				activation.AeroPayloadBody("Reload");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Reload Test Method
		@Test(priority=4, dataProvider = "ReloadCard_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void ReloadCardAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity Reload ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardReloadPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Reload API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Reload Request is successfully Executed");

			try {
				if(responseMessage.equalsIgnoreCase("SUCCESS"))
				{
						//updating the Card Last 4 Digits, URN and Customer ID details on Reload API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Unload", i, 9, String.valueOf(requestObject.get("last4Digits")));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Unload", i, 10, String.valueOf(requestObject.get("urn")));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Unload", i, 11, String.valueOf(requestObject.get("customerId")));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=5)
		public void UnloadBody()
		{
			i=0;
			try {
				activation.AeroPayloadBody("Unload");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Unload Test Method
		@Test(priority=6, dataProvider = "UnloadCard_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void UnloadCardAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity Unload ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardUnloadPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Unload API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Unload Request is successfully Executed");
		}


		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=7)
		public void CardInquiry()
		{
			i=0;
			try {
				activation.AeroPayloadBody("CardInquiry");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card Inquiry Test Method
		@Test(priority=8, dataProvider = "CardInquiry_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void CardInquiryAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity CardInquiry ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardInquiryPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("CardInquiry API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("CardInquiry Request is successfully Executed");
		}


		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=9)
		public void CardBlock()
		{
			i=0;
			try {
				activation.AeroPayloadBody("CardBlock");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card Temp Block Test Method
		@Test(priority=10, dataProvider = "CardBlock_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void CardBlockAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity CardBlock ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardBlockPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("CardBlock API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));
			Log.pass( "Case execution is Pass");
			System.out.println("CardBlock Request is successfully Executed");

			try {
				if(responseMessage.equalsIgnoreCase("SUCCESS"))
				{
						//updating the Card Last 4 Digits, URN and Customer ID details on Card Block API Data sheet
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 9, requestObject.get("last4Digits").toString());
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 10, jsonValue.get("urn"));
						ExcelLibrary.writeExcelData(filepath+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 11, jsonValue.get("customerId"));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}


		//test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=11)
		public void CardUnBlock()
		{
			i=0;
			try {
				activation.AeroPayloadBody("CardUnblock");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card Unblock Test Method
		@Test(priority=12, dataProvider = "CardUnblock_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CardBlockAPI")
		public void CardUnBlockAPI(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity CardUnblock ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardUnblockPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card Unblock API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card Unblock Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=13)
		public void UpdateProfile()
		{
			i=0;
			try {
				activation.AeroPayloadBody("UpdateProfile");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card update profile Test Method
		@Test(priority=14, dataProvider = "UpdateProfile_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void CardUpdateProfile(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity UpdateProfile ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardUpdateProfilePost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card UpdateProfile API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card UpdateProfile Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=15)
		public void TransactionInquiry()
		{
			i=0;
			try {
				activation.AeroPayloadBody("TransactionInquiry");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card TransactionInquiry Test Method
		@Test(priority=16, dataProvider = "TransactionInquiry_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void TransactionInquiry(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity Transaction Inquiry ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardTransactionInquiryPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card TransactionInquiry API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card TransactionInquiry Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=17)
		public void FundTransfer()
		{
			i=0;
			try {
				activation.AeroPayloadBody("FundTransfer");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card FundTransfer Test Method
		@Test(priority=18, dataProvider = "FundTransfer_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void FundTransfer(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity FundTransfer ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardFundTransferPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card FundTransfer API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card FundTransfer Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=19)
		public void AMLInquiry()
		{
			i=0;
			try {
				activation.AeroPayloadBody("AMLInquiry");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card AMLInquiry Test Method
		@Test(priority=20, dataProvider = "AMLInquiry_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void AMLInquiry(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity AMLInquiry ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardAMLInquiryPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card AMLInquiry API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card AMLInquiry Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=21)
		public void WalletStatement()
		{
			i=0;
			try {
				activation.AeroPayloadBody("WalletSettlement");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card WalletStatement Test Method
		@Test(priority=22, dataProvider = "WalletSettlement_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void WalletStatement(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity WalletStatement ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardWalletStatementPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card WalletStatement API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);

			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");

			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);

			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));

			Log.pass( "Case execution is Pass");
			System.out.println("Card WalletStatement Request is successfully Executed");
		}


		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test(priority=23)
		public void ResetPin()
		{
			i=0;
			try {
				activation.AeroPayloadBody("ResetPin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card ResetPin Test Method
		@Test(priority=24, dataProvider = "ResetPin_api", dataProviderClass = DataProviderUtility.class, dependsOnMethods= "CreateCardAPI")
		public void ResetPin(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode) {
			System.out.println("Sanity ResetPin ##########################"+i);

			JSONParser parser = new JSONParser();
			JSONObject requestObject=null;
			try{
				 requestObject = (JSONObject) parser.parse(requestPayLoad);
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
			Response response = given().header("contentType", "application/json").
					body(requestObject).
					when().log().body().post(cardResetpinPost).
					then().and().assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
					.contentType(ContentType.JSON).and().
					extract().response();

			System.out.println("Card ResetPin API responseMessage is "+ response.asString());

			JsonPath jsonValue= basePayLoad.jsonObject(response);
			
			String jsonResponseMessage = jsonValue.get("responseMessage");
			String jsonResponseCode = jsonValue.get("responseCode");
					
			Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
			
			Assert.assertEquals(jsonResponseCode, responseCode);
			Assert.assertEquals(jsonResponseMessage, responseMessage);
			Assert.assertEquals(jsonValue.get("urn"), requestObject.get("urn"));
			Assert.assertEquals(jsonValue.get("customerId"), requestObject.get("customerId"));
			
			Log.pass( "Case execution is Pass");
			System.out.println("Card ResetPin Request is successfully Executed");
		}
}
package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.support.PageFactory;
import org.testng.SkipException;
import org.testng.annotations.Test;


import java.util.ArrayList;
import java.util.HashMap;

import static Prepaid.testScripts.kotak.BaseTest.browser;
import static io.restassured.RestAssured.given;

public class FundTransferAPI extends APIBaseTest{
	
	ActivationPayLoad activation = new ActivationPayLoad(driver);
	String sanityTestDataExcel = System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	String jsonSenderReferenceNumber;
	String jsonReceiverReferenceNumber;
	String jsonSenderURN;
	String jsonReceiverURN;
	int amount;
	int i=1;
	String last4Digits;
	int urn;
	String customerId;
	int[] recevierURNcell;
	int[] senderURNcell;
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert, senderDebitCSRValidation, recevierCreditCSRValidation;
	boolean responseMessageAssert;
	boolean requestResponseURNValidation;
	boolean requestResponseCustIdValidation;
	
		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void FundTransfer()
		{
			try {
				activation.AeroPayloadBody("FundTransfer");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card FundTransfer Test Method
		@Test( dataProvider = "FundTransfer_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CreateCardAPI"
		public void FundTransfer(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition, String reportValidation) {
			try{				
				if (!preCondition.equals(null) && !preCondition.equals("")) {
					Response preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
					if (preConditionRequestResponse != null) {
						String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
						String preConditionAPIResponseMesssage = basePayLoad.getResponseValue(preConditionRequestResponse,"responseMessage");
						if (!preConditionAPIResponseCode.equals("00")){
							System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
							Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.toString());
							throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");					
						}
					}
				}
				
				// To update AML profile prameters value
				basePayLoad.UpdateAMLProfileValue(testCaseID);
				// loginIntoCSR();
				// CSRBasePage csr=PageFactory.initElements(driver,
				// CSRBasePage.class);
				// csr.processCache("6019|CLEAR|AML_PROFILE");
				// csrSignOut();
				// driver.close();
				//TODO - If Sender Card Details Not available then create one and process the payment 
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				System.out.println("FundTransfer Request Object"+requestPayLoad);
				//To Fetch Sender details from Request Object
				ArrayList requestObjectsender = (ArrayList) requestObject.get("senders");
				HashMap<String, String> senderDetails = (HashMap) requestObjectsender.get(0);
				//To Fetch Recevier details from Request Object
				ArrayList requestObjectrecevier = (ArrayList) requestObject.get("receivers");				
				HashMap<String, String> recevierDetails = (HashMap) requestObjectrecevier.get(0);
				
				//sender Card details
				last4Digits = senderDetails.get("last4Digits");
				urn = Integer.parseInt(senderDetails.get("urn"));
				customerId = senderDetails.get("customerId");
				
				switch (preCondition) {			
				// to replace URN with invalid URN
				case "Invalid URN":
					Log.info( "actual URN :"+ urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "Invalid CardNo":
					Log.info( "actual last4Digits :"+ last4Digits);
					requestObject.replace("last4Digits", String.format("%04d", Integer.parseInt(last4Digits)+1));
					break;
				// to replace caustomer id with invalid customer id
				case "Invalid CustID":
					Log.info( "actual customerId :"+ customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;
				}
				
				Log.info( "Fund Transfer requestObject :"+ requestObject.toString());
				Log.info( " Fund Transfer request Post URL :"+cardFundTransferPost);
				
				Response response = given().header("contentType", "application/json").
						body(requestObject).
						when().log().body().post(cardFundTransferPost).
						then().and()
						.extract().response();
				
				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
		
							
				if(!response.asString().isEmpty()){
					Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode);
					jsonValue= basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					amount =  jsonValue.get("transactionAmount");
															
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);					
				}			
				jsonSenderURN = senderDetails.get("urn");
				jsonReceiverURN = recevierDetails.get("urn");
				recevierURNcell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", jsonReceiverURN);
				senderURNcell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", jsonSenderURN);
				Log.info("Card FundTransfer API Event Request responseMessage is "+ response.asString());
				if(responseCodeAssert && responseMessageAssert){
						Log.pass("Card FundTransfer API request is as expected "+ response.asString());
					}else{
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.pass("Card FundTransfer API Event Request is Un Successfull as per testcase");
						}else{							
							Log.fail("Card FundTransfer API Event Request is Unsuccessfull");
							}
					}
				
				if(responseMessage.equalsIgnoreCase("SUCCESS")){					
					// to fetch Sender and Receiver details from response
					ArrayList responsesender = jsonValue.get("senders");
					ArrayList responsereceiver = jsonValue.get("receivers");
					HashMap responseSenderDetails = (HashMap) responsesender.get(0);
					HashMap responseReceviersDetails = (HashMap) responsereceiver.get(0);			
					jsonSenderReferenceNumber = responseSenderDetails.get("accosaRefNo").toString();
					jsonReceiverReferenceNumber = responseReceviersDetails.get("accosaRefNo").toString();
					
					//Sender URN
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", senderURNcell[0], 11, "true"); //update Fund Transfer event as true if performed
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", senderURNcell[0], 12, response.asString()); //update Fund Transfer event as true if card is active
					//Recevier URN
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", recevierURNcell[0], 13, "true"); //update Fund Transfer event as true if performed
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", recevierURNcell[0], 14, response.asString()); //update Fund Transfer event as true if card is active
				}else{
					//Sender URN
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", senderURNcell[0], 11, "false"); //update Fund Transfer event as false if not performed
					//Recevier URN
					ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", recevierURNcell[0], 13, "false"); //update Fund Transfer event as false if performed
				}			
			
				if(responseMessage.equalsIgnoreCase("SUCCESS")){
					i++;
					Log.info("**************In CSR Application to validate the Card Fund Transfer event in prepaid details**************");
					System.out.println("In CSR Application to validate the Card Fund Transfer event in prepaid details");
					Log.info("CSR Prepaid Details for an Card Fund Transfer event");
					initBrowser(BROWSER, "CSR");
					Log.info( "Browser stated and Application launched");
					String[] Credentials = getAppCredentials("CSR");
					System.out.println("Username and password is "+Credentials[0]+" password is "+Credentials[1]);
					LoginPage csrLogin= new LoginPage(driver);
					csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password
					Log.info( "Successfull logged into Application");
					
					PrepaidDetailsPage prp=new PrepaidDetailsPage(driver);
					Log.info( "Validate Sender Transaction details");
					
					//validate Fundtransfer statement for sender card			
					prp.checkPrepaidDetails(jsonSenderURN);			
					senderDebitCSRValidation = prp.CSRValidateCardTransaction("Fund Transfer Debit", amount, jsonSenderReferenceNumber);	
					
					Log.info( "Validate Receiver Transaction details");
					//validate Fundtransfer statement for recevier card
					prp.checkPrepaidDetails(jsonReceiverURN);	
					recevierCreditCSRValidation = prp.CSRValidateCardTransaction("Fund Transfer Credit", amount, jsonReceiverReferenceNumber);
					
					if(senderDebitCSRValidation && recevierCreditCSRValidation){
						Log.pass("Card FundTransfer API Event Request is Successfull as per testcase");
					}else{
						Log.fail("Card FundTransfer API Event Request is Unsuccessfull as per testcase");
					}
				}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Fund Transfer API Event Request is Unsuccessfull");
		}
}
}
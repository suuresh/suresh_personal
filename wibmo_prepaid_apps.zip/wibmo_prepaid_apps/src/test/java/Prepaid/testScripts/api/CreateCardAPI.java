package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.ArrayList;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertTrue;

public class CreateCardAPI extends APIBaseTest{
	
	BasePayLoad basePayLoad = new BasePayLoad(driver);
	int i=1;
	
	String jsonResponseFullCardNumber;
	String cardLast4Digit;
	String jsonRequestReferenceNumber;
	String jsonResponseclientTxnId;
	int loadAmount;
	
	String jsonResponseURN;
	String jsonResponseCustID;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	
//		test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void ActivationBody()
		{
			try {
				basePayLoad.AeroPayloadBody("CreateCard");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Sanity Activation Test Method
		@Test(dataProvider = "CreateCard_api", dataProviderClass = DataProviderUtility.class)
		public void CreateCard(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition, String reportValidation) {
			try {
				String [] required = reportValidation.split(",");
				Log.info(testCaseID+": "+testScenario);
				//System.out.println("tID "+testCaseID+" scenario "+testScenario);
				Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
				//System.out.println("Expected Result:"+requestPayLoad);
				//System.out.println("Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
				// if testcase has a precondition then executing the precondition scenarion and validating the result

				//if (!preCondition.equals(null) && !preCondition.equals("")) {
                 //   basePayLoad.UpdateAMLProfileValue(preCondition);
               // }

//				// To update AML profile prameters value
//				basePayLoad.UpdateAMLProfileValue(testCaseID);
//				csrBasepage.fetchAMLProfileValue("fetchAMLProfileValue");
//				//To clear cache
////				loginIntoCSR();
////				CSRBasePage csr=PageFactory.initElements(driver, CSRBasePage.class);
////				csr.processCache("6019|CLEAR|AML_PROFILE");
////				csrSignOut();
////				driver.close();
				
				Log.info( "requestPayLoad :"+requestPayLoad);
				//System.out.println("requestPayLoad :"+requestPayLoad);
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				Log.info( cardCreationPost);
				Response response = given().contentType("application/json").and().
						body(requestObject).and().
						when().post(cardCreationPost).
								//when().log().body().post("https://aero-api.pc.enstage-sas.com/v1/6019/createCard/0432/20150701235959xhstiesqfds").
						then()
//						.and().assertThat().statusCode(Integer.parseInt(responseStatusCode))
//						.and().contentType(ContentType.JSON)
						.and().extract().response();
				
				int actualResponseCode = response.getStatusCode();
				String apibody = response.getBody().toString();
				//System.out.println(apibody);
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
				
				if(!response.asString().isEmpty()) {
					// Response is in RAW format, JsonPath class has ability to convert into JsonPath.
					//System.out.println("inside validation");
					jsonValue = basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					//System.out.println("actual responcecode" + jsonResponseCode + "Responcemessage" + jsonResponseMessage);
					//System.out.println("Card number" + jsonValue.get("cardNumber"));

					Log.info("Json Status Code" + actualResponseCode + ", Json response message is " + jsonResponseMessage + ", Json response code is " + jsonResponseCode);
				}
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);


				if(responseCodeAssert && responseMessageAssert)
				{
					//System.out.println("if loop 1");
					if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
						jsonResponseFullCardNumber = jsonValue.get("cardNumber");
						jsonResponseURN = jsonValue.get("urn").toString();
						jsonResponseCustID = jsonValue.get("customerId");
						jsonResponseclientTxnId = jsonValue.get("clientTxnId");
						jsonRequestReferenceNumber = jsonValue.get("accosaRefNo");
						loadAmount = jsonValue.get("loadAmount");
						Log.info( "RequestReferenceNumber "+ jsonRequestReferenceNumber);
						//Assert.assertTrue(true, "Test Passed");
					}

					Log.info("Card Creation API Event Request responseMessage is "+ response.asString());
					Log.pass("Card Creation API Event Request is Successfull");
				}else {
					//if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						//Log.info("Card Creation API Event Request Status is "+ response.statusLine());
						//Log.pass("Card Creation API Event Request is Successfull as per testcase");
					//}else{
					Log.info("Card Creation API Event Request responseMessage is "+ response.asString());
					Log.fail("Card Creation API Event Request is Unsuccessfull");
					//System.out.println("Card Creation API Event Request responseMessage is "+ response.asString());
					//System.out.println("Card Creation API Event Request is Unsuccessfull");
					//Assert.assertTrue(false, "Test Failed");
					//}
				}
				//System.out.println("Json responce message"+jsonResponseMessage);
					if(jsonResponseMessage.equalsIgnoreCase("SUCCESS"))
					{
						//System.out.println("inside write1");
						cardLast4Digit = Generic.getLast4DigitCardNumber(jsonResponseFullCardNumber);
						//updating the Card Last 4 Digits, URN and Customer ID details on Card Details API Data sheet
						int j = ExcelLibrary.getExcelRowCount(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH,"CardDetails");
						//System.out.println("inside write2");
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 0, jsonResponseFullCardNumber);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 1, cardLast4Digit);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 2, jsonResponseURN);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 3, jsonResponseCustID);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 4, "Active");
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 5, "true"); //update activation event as true if card is active
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", j+1, 6, response.asString()); //update activation event as true if card is active
//						ExcelLibrary.writeExcelData(authorizationsTestData, "AuthSettlement", i, 0, jsonResponseFullCardNumber);//updating activated card details for authorization settlement process
//						ExcelLibrary.writeExcelData(authorizationsTestData, "Authorizations", i, 5, jsonResponseFullCardNumber);//updating activated card details for authorization settlement process
						
						//updating the Card Last 4 Digits, URN and Customer ID details on Reload API Data sheet
					ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 13, cardLast4Digit);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 14, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "Reload", i, 15, jsonResponseCustID);
						
						//updating the Card Last 4 Digits, URN and Customer ID details on CardBlock API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 10, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 11, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardBlock", i, 12, jsonResponseCustID);
						
						//updating the Card Last 4 Digits, URN and Customer ID details on Card inquiry API Data sheet
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 9, cardLast4Digit);
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 10, String.valueOf(jsonResponseURN));
						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardInquiry", i, 11, jsonResponseCustID);
						
						//updating the Card Last 4 Digits, URN and Customer ID details on Card UpdateProfile API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 9, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 10, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "UpdateProfile", i, 11, jsonResponseCustID);
						
						//updating the Card Last 4 Digits, URN and Customer ID details on Card TransactionInquiry API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 9, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 10, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "TransactionInquiry", i, 11, jsonResponseCustID);
												
						//updating the Card Last 4 Digits, URN and Customer ID details on Card AMLInquiry API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 9, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 10, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "AMLInquiry", i, 11, jsonResponseCustID);
												
						//updating the Card Last 4 Digits, URN and Customer ID details on Card WalletSettlement API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 11, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 12, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "WalletSettlement", i, 13, jsonResponseCustID);
						
						//updating the Card Last 4 Digits, URN and Customer ID details on Card ResetPin API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 11, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 12, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "ResetPin", i, 13, jsonResponseCustID);
												
						//updating the Card Last 4 Digits, URN and Customer ID details on Card FundTransfer API Data sheet
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 11, cardLast4Digit);
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 12, String.valueOf(jsonResponseURN));
//						ExcelLibrary.writeExcelData(APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "FundTransfer", i, 13, jsonResponseCustID);
						i++;
					}

                LoginPage csrLogin= new LoginPage(driver);

				boolean transactionValidation = false;
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS"))
				{
					Log.info("**************In CSR Application to validate the create card event in prepaid details**************");
					Log.info("CSR Prepaid Details for an active card");
					Log.info("**************CSR Prepaid Details for an active card**************");
					initBrowser(BROWSER, "CSR");
					Log.info( "Browser stated and Application launched");
					String[] Credentials = getAppCredentials("CSR");
                    csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password
					Log.info( "Successfull logged into Application");
					
					PrepaidDetailsPage prp=PageFactory.initElements(driver, PrepaidDetailsPage.class);

			
					prp.checkPrepaidDetails(jsonResponseFullCardNumber);
					Log.info( "cardNumber " + jsonResponseFullCardNumber);
					transactionValidation = prp.CSRValidateCardTransaction("Activation", loadAmount, jsonRequestReferenceNumber);
					assertTrue(transactionValidation);
					if (transactionValidation) {
						Log.info("CSR Card Activation Transaction Validation is Successfull");
					} else {
						Log.info("CSR Card Activation Transaction Validation is Not Successfull");
					}
					driver.close();
				}
				ArrayList<Boolean> reportvalidation= new ArrayList<Boolean>();
				//External Activation Report Validation
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS") && required[1].equalsIgnoreCase("true"))
				{
					Log.info("**************In External Report to validate the created card in activation report**************");
					initBrowser(BROWSER, "ExternalReports");
//					initBrowser("firefox", "ExternalReports");
					Log.info( "Browser stated and Application launched");
					AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
					enhancedReports.selectReport("Card Creation Report");
					enhancedReports.generateReport(Generic.currentDate("yyyy-MM-dd"), Generic.currentDate("yyyy-MM-dd"));
					enhancedReports.searchRecordInReport("//div[contains(text(),'"+jsonResponseURN+"')]");
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+jsonResponseURN+"')]")).isDisplayed());
					Log.info(jsonResponseURN+" URN is populating in report");
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+jsonResponseURN+"')]//following::div[contains(text(),'"+cardLast4Digit+"')]")).isDisplayed());
					Log.info(cardLast4Digit+" cardLast4Digit is populating in report");
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+jsonResponseURN+"')]//following::div[contains(text(),'"+jsonResponseclientTxnId+"')]")).isDisplayed());
					Log.info(jsonResponseclientTxnId+" clientTxnId is populating in report");
					if (!reportvalidation.contains(false)) {
						Log.info("CSR Card Activation Report Validation is Successfull");
					} else {
						Log.info("CSR Card Activation Report Validation is Not Successfull");
					}
				}
			} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.error("Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.info("Card Creation API Event Request is Unsuccessfull");
		}
	}
}

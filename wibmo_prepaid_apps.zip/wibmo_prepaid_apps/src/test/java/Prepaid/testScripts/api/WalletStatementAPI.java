package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.apiPayLoads.WalletStatementPayLoad;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class WalletStatementAPI extends APIBaseTest{
	ActivationPayLoad activation = new ActivationPayLoad(driver);
	WalletStatementPayLoad walletStatement = new WalletStatementPayLoad(driver);
	String testDataExcel = System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
//	int i=1;
	Response response;

	int last4Digits;
	int urn;
	String customerId;
	int[] Cell = null;
	int[] row=null;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	Response preConditionRequestResponse;
	boolean statementValidation = false;

		//Test method to call AeroPayloadBody() method for the api request body formation
		@Test()
		public void WalletStatement()
		{
			try {
				activation.AeroPayloadBody("WalletSettlement");
			}catch (Exception e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Sanity Card WalletStatement Test Method
		@SuppressWarnings("unchecked")
		@Test(dataProvider = "WalletSettlement_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CreateCardAPI"
		public void WalletStatement(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition, String reportValidation) {
			try{

				if (!preCondition.equals(null) && !preCondition.equals("")) {
					preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
					Log.info( "preConditionRequestResponse: "+preConditionRequestResponse);
//					if (preConditionRequestResponse == null) {
////						String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
////						if (!preConditionAPIResponseCode.equals("00")) {
//							System.out.println("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
//							Log.info( "Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
//							Log.info( "Precondition of "+ preCondition + " Response is "+ preConditionRequestResponse.asString());
//							throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
//						}
					}
//				}
				
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
				urn = Integer.parseInt(requestObject.get("urn").toString());
				customerId = requestObject.get("customerId").toString();
				switch (preCondition) {
				// to replace URN with invalid URN
				case "InvalidURN":
					Log.info( "actual URN :" + urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "InvalidCardNo":
					Log.info( "actual last4Digits :" + last4Digits);
					requestObject.replace("last4Digits", last4Digits + 1);
					break;
				// to replace caustomer id with invalid customer id
				case "InvalidCustID":
					Log.info( "actual customerId :" + customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;//To Fetch Sender Details
				case "FundDebit":
					//To Fetch Sender details from Request Object
					String senderDetails = basePayLoad.getResponseValue(preConditionRequestResponse,"senders").replace("[", "").replace("]", "");
					HashMap<String, String> senderDetail = Generic.parseStringToHashmap(senderDetails);
					//sender Card details	
					requestObject.replace("urn",senderDetail.get("urn"));					
					requestObject.replace("customerId",senderDetail.get("customerId"));
					row = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", senderDetail.get("urn"));
					requestObject.replace("last4Digits",ExcelLibrary.getExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", row[0], 1));
					break;
					//To Fetch Receiver Details
				case "FundCredit":
					//To Fetch Recevier details from Request Object
					String recevierDetails = basePayLoad.getResponseValue(preConditionRequestResponse,"receivers").replace("[", "").replace("]", "");
					HashMap<String, String> recevierDetail = Generic.parseStringToHashmap(recevierDetails);
					//Receiver Card details
					requestObject.replace("urn",recevierDetail.get("urn"));
					requestObject.replace("customerId",recevierDetail.get("customerId"));
					
					row = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", recevierDetail.get("urn"));
					requestObject.replace("last4Digits",ExcelLibrary.getExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", row[0], 1));
					break;
				case "Authorization":
				case "DebitSettlement":
				case "CreditSettlement":
				case "DebitReversal":
				case "CreditReversal":
				case "CreditChargeback":
					requestObject = basePayLoad.ParseStringToJSON(preConditionRequestResponse.asString());
					break;
				}

				Log.info("requestObject :" + requestObject.toString());
				Log.info( "requestObject Post URL :"+ cardWalletStatementPost);
				response = given().contentType("application/json")
						.body(requestObject).when().log().body()
						.post(cardWalletStatementPost).then()
						.extract().response();
				Log.info("Card Wallet Statement Request Response :" + response.asString());

				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

				if(!response.asString().isEmpty()){
					jsonValue = basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
					
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				}
				if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
					Assert.assertEquals(jsonValue.get("urn").toString(),requestObject.get("urn").toString());
					Assert.assertEquals(jsonValue.get("customerId").toString(),requestObject.get("customerId"));
					ArrayList statements = jsonValue.get("statementDetails");
					for(int i =0; i<statements.size();i++){
						HashMap<String, String> statementDetail = (HashMap) statements.get(i);
					}			
					statementValidation = walletStatement.ValidateWalletStatementEvent(jsonValue, requestObject.get("urn").toString(), "Wallet", preCondition);
				}				
				Log.info( "Statement Validation: "+statementValidation +"responseCodeAssert"+ responseCodeAssert +"responseMessageAssert"+ responseMessageAssert);
				if (statementValidation && responseCodeAssert && responseMessageAssert) {
					Log.pass("Card Wallet Statement API Event Request is Successfull");
//					cell = csv.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH,"CardDetails", requestObject.get("last4Digits").toString());
				} else {
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.pass("Wallet Statement and Event validation is successful");
					}else{
						Log.fail("Card Wallet Statement API Request or Event validation is Unsuccessfull");
					}
				}
		}
		catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Wallet Statement API Event Request is Unsuccessfull");
		}	
	}
}
package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.apiPayLoads.CardInquiryPayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;


import java.util.ArrayList;

import static io.restassured.RestAssured.given;

public class UnloadAPI extends APIBaseTest{

	ActivationPayLoad activation = new ActivationPayLoad(driver);
	CardInquiryPayLoad cardInquiry = new CardInquiryPayLoad(driver);

	String sanityTestDataExcel = System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	int i=1;
	int UnloadAmount;
	String jsonRequestReferenceNumber;
	String jsonResponseclientTxnId;
	String last4Digits;
	int urn;
	String customerId;
	int[] cell = null;
	Response preConditionRequestResponse;
	String reloadClientTxnId;

	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;

	//test method to call AeroPayloadBody() method for the api request body formation
	@Test()
	public void UnloadBody(){
		try {
			activation.AeroPayloadBody("Unload");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//Sanity Unload Test Method
	@Test(dataProvider = "unloadCard_api", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods= "CreateCardAPI"
	public void UnloadCard(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String preCondition,  String reportValidation) {
		try{
			String [] required = reportValidation.split(",");
			System.out.println("Sanity Unload ##########################"+i);
			Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);

			if(!preCondition.equals(null) && !preCondition.equals("")){
				preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
				if(preConditionRequestResponse!=null){
					String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse, "responseCode");
					String preConditionAPIResponseMesssage = basePayLoad.getResponseValue(preConditionRequestResponse, "responseMessage");
					if (!preConditionAPIResponseCode.equals("00")){
						System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
						throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
					}
				}
			}

			// To update AML profile prameters value
			basePayLoad.UpdateAMLProfileValue(testCaseID);
			//
			JSONObject requestObject= basePayLoad.ParseStringToJSON(requestPayLoad);
			last4Digits = requestObject.get("last4Digits").toString();
			urn = Integer.parseInt(requestObject.get("urn").toString());
			customerId = requestObject.get("customerId").toString();

			switch(preCondition){
				//to replace URN with invalid URN
				case "Invalid URN":
					requestObject.replace("urn", urn-1);
					break;
				//to replace Last4Digits  with invalid Last4Digits
				case "Invalid CardNo":
					requestObject.replace("last4Digits", String.format("%04d", Integer.parseInt(last4Digits)+1));
					break;
				//to replace caustomer id with invalid customer id
				case "Invalid CustID":
					requestObject.replace("customerId", customerId+"abc");
					break;
				// to replace customer id with invalid customer id
				case "Reload":
				case "Duplicate Unload Event":
					reloadClientTxnId = basePayLoad.getResponseValue(preConditionRequestResponse,"clientTxnId");
					requestObject.replace("originalClientTxnId", reloadClientTxnId);
					break;
				case "Invalid Unload Event":
					reloadClientTxnId = basePayLoad.getClientTxnID();
					requestObject.replace("originalClientTxnId", reloadClientTxnId);
					break;
			}

			JSONObject cardInquiryPost = cardInquiry.cardInqPayLoad(String.valueOf(urn), customerId, last4Digits);
			Response cardInquiryResponse = cardInquiry.cardInquiry(cardInquiryPost);
			JsonPath responseValue = BasePayLoad.jsonObject(cardInquiryResponse);
			String cardBalance = responseValue.get("availableCashLimit");
			if(cardBalance.equalsIgnoreCase("0")){
				basePayLoad.reloadCard(String.valueOf(urn), last4Digits,customerId,50000, "","", "");
			}

			Log.info( requestObject.toString());
			Log.info( cardUnloadPost);
			System.out.println("cardUnloadPost: "+cardUnloadPost);
			Response response = given().contentType("application/json").
					body(requestObject).
					when().log().body().post(cardUnloadPost).
					then()
					//					.and().assertThat().statusCode(Integer.parseInt(responseStatusCode))
					//					.and().contentType(ContentType.JSON)
					.and().extract().response();

			Log.info( "Unload API responseMessage is "+ response.asString());

			int actualResponseCode = response.getStatusCode();
			boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

			if(!response.asString().isEmpty()){
				jsonValue= basePayLoad.jsonObject(response);
				jsonResponseMessage = jsonValue.get("responseMessage");
				jsonResponseCode = jsonValue.get("responseCode");

				Log.info( "Json response message is "+jsonResponseMessage+", Json response code is "+jsonResponseCode+", Status Code is "+actualResponseCode);

				responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
				responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", String.valueOf(requestObject.get("urn")));
			}

			if(responseCodeAssert && responseMessageAssert){
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS"))	{
					UnloadAmount = jsonValue.get("transactionAmount");
					jsonRequestReferenceNumber = jsonValue.get("accosaRefNo");
					jsonResponseclientTxnId = jsonValue.get("clientTxnId");
					Log.info( "RequestReferenceNumber "+jsonRequestReferenceNumber);
					Assert.assertEquals(jsonValue.get("urn").toString(), requestObject.get("urn").toString());
					Assert.assertEquals(jsonValue.get("customerId").toString(), requestObject.get("customerId").toString());
				}
				Log.pass( "Unload API Event Request is Successfull");
				Log.info( "Unload API Event Request responseMessage is "+ response.asString());
			}else{
				if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
					Log.info("Unload API Event Request Status is "+ response.statusLine());
					Log.pass("Unload API Event Request is Successfull as per testcase");
				}else{
					Log.fail( "Unload API Event Request is Unsuccessfull");
					Log.info( "Unload API Event Request responseMessage is "+ response.asString());
				}
			}

			if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")){
				ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 9, "true");
				ExcelLibrary.writeExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 10, response.asString());
				i++;
			}
			boolean transactionValidation = false;
			if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")){
				String cardNumber = ExcelLibrary.getExcelData(sanityTestDataExcel, "CardDetails", cell[0], 0);
				Log.info("**************In CSR Application to validate the Unload card event in prepaid details**************");
				System.out.println("In CSR Application to validate the Unload card event in prepaid details");
				Log.info("CSR Prepaid Details for an Unload card");
				initBrowser("chrome", "CSR");
				Log.info( "Browser stated and Application launched");
				String[] Credentials = getAppCredentials("CSR");
				System.out.println("Username and password is "+Credentials[0]+" password is "+Credentials[1]);
				LoginPage csrLogin= new LoginPage(driver);
				csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password

				PrepaidDetailsPage prp=new PrepaidDetailsPage(driver);
				prp.checkPrepaidDetails(cardNumber);
				transactionValidation = prp.CSRValidateCardTransaction("Unload", UnloadAmount, jsonRequestReferenceNumber);
				if(transactionValidation){
					Log.pass( "CSR Unload Transaction Validation is Successfull");
				}else{
					Log.fail( "CSR Unload Transaction Validation is Not Successfull");
				}
			}

			ArrayList<Boolean> reportvalidation= new ArrayList<Boolean>();
			//External Activation Report Validation
			if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")&& required[1].equalsIgnoreCase("true")){
				Log.info("**************In External Report to validate the Unload event in Unload Report**************");
				initBrowser(BROWSER, "ExternalReports");
				//				initBrowser("firefox", "ExternalReports");
				Log.info( "Browser started and Application launched");
				AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
				enhancedReports.selectReport("Card Load/Unload Report");
				enhancedReports.selectReportType("Unload Report");
				enhancedReports.generateReport(Generic.currentDate("yyyy-MM-dd"), Generic.currentDate("yyyy-MM-dd"));
				enhancedReports.selectProductreport(basePayLoad.getProductName());
				enhancedReports.searchRecordInReport("//div[contains(text(),'"+urn+"')]");
				reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed());
				Log.info(urn+" URN is populating in report");
				reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4Digits+"')]")).isDisplayed());
				Log.info(last4Digits+" last4Digits is populating in report");
				reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+jsonResponseclientTxnId+"')]")).isDisplayed());
				Log.info(jsonResponseclientTxnId+" clientTxnId is populating in report");
				if (!reportvalidation.contains(false)) {
					Log.pass("CSR Card Unload Report Validation is Successfull");
				} else {
					Log.fail("CSR Card Unload Report Validation is Not Successfull");
				}
			}
		}
		catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Unload API Event Request is Unsuccessfull");
		}
	}
}
package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.CSRBasePage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class UCIC_Registration extends APIBaseTest{
	
	BasePayLoad basePayLoad = new BasePayLoad(driver);
	CSRBasePage csrBasePage = new CSRBasePage(driver);
	int i;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	
		@Test()
		public void ActivationBody()
		{
			try {
				basePayLoad.AeroPayloadBody("UCICReg");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Sanity Activation Test Method
		@Test(dataProvider = "UCICReg_API", dataProviderClass = DataProviderUtility.class)
		public void CreateCard(String testCaseID, String testScenario, String requestPayLoad, String responseCode, String responseMessage, String responseStatusCode, String precondition, String reportValidation) {
			try {
				Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
				Log.info( "requestPayLoad :"+requestPayLoad);
				JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
				
				requestObject.remove("ucicId", "");
				requestObject.remove("customerIdentityProof", "");
				
				Log.info( cardUCICRegPost);
				Response response = given().contentType("application/json").
						body(requestObject).
						when().log().body().post(cardUCICRegPost).
						then()
						.and().extract().response();
				
				int actualResponseCode = response.getStatusCode();
				boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));
				
				if(!response.asString().isEmpty()){
					// Response is in RAW format, JsonPath class has ability to convert into JsonPath.
					jsonValue= basePayLoad.jsonObject(response);
					jsonResponseMessage = jsonValue.get("responseMessage");
					jsonResponseCode = jsonValue.get("responseCode");
					
					Log.info( "Json Status Code"+ actualResponseCode + ", Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
					
					responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
					responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				}
				if(responseCodeAssert && responseMessageAssert)
				{ 
					Log.info("UCIC Reg API Event Request responseMessage is "+ response.asString());
					Log.pass("UCIC Reg API Event Request is Successfull");
				}else {
					if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
						Log.info("UCIC Reg API Event Request Status is "+ response.statusLine());
						Log.pass("UCIC Reg API Event Request is Successfull as per testcase");
					}else{
					Log.info("UCIC Reg API Event Request responseMessage is "+ response.asString());
					Log.fail("UCIC Reg API Event Request is Unsuccessfull");
					}
				}	
			} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.error("Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("UCIC Reg API Event Request is Unsuccessfull");
		}
	}
}

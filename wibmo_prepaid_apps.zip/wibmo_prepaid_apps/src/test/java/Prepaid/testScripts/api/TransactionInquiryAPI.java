package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.apiPayLoads.WalletStatementPayLoad;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.ExcelLibrary;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.SkipException;


import java.util.ArrayList;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class TransactionInquiryAPI extends APIBaseTest {

	ActivationPayLoad activation = new ActivationPayLoad(driver);
	WalletStatementPayLoad walletStatement = new WalletStatementPayLoad(driver);
	String testDataExcel = System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	int i=1;
	int loadAmount;
	String transactionFee;
	String jsonRequestReferenceNumber;
	Response response;
	
	int last4Digits;
	int urn;
	String customerId;
	int[] cell = null;
	
	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;
	boolean transactionValidations;
	Response preConditionRequestResponse;


	// Test method to call AeroPayloadBody() method for the api request body
	// formation
	//@Test()
	public void TransactionInquiry() {
		i=0;
		try {
			activation.AeroPayloadBody("TransactionInquiry");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Sanity Card TransactionInquiry Test Method
	//@Test(dataProvider = "TransactionInquiry_api", dataProviderClass = DataProviderUtility.class)
	public void TransactionInquiry(String testCaseID, String testScenario,String requestPayLoad, String responseCode, String responseMessage,String responseStatusCode, String preCondition, String reportValidation) {
		try {

			if (!preCondition.equals(null) && !preCondition.equals("")) {
				preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
				if (preConditionRequestResponse != null) {
					String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
					Log.info( "preConditionRequestResponse: "+preConditionRequestResponse.asString());
					if (!preConditionAPIResponseCode.equals("00")) {
						System.out.println("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
						Log.info( "Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
						Log.info( "Precondition of "+ preCondition + " Response is "+ preConditionRequestResponse.asString());
						throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
					}
				}
			}
			

			JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
			last4Digits = Integer.parseInt(requestObject.get("last4Digits").toString());
			urn = Integer.parseInt(requestObject.get("urn").toString());
			customerId = requestObject.get("customerId").toString();
			
			switch (preCondition) {
			// to replace URN with invalid URN
			case "Invalid URN":
				Log.info( "actual URN :" + urn);
				requestObject.replace("urn",urn - 1);
				break;
			// to replace Last4Digits with invalid Last4Digits
			case "Invalid CardNo":
				Log.info( "actual last4Digits :" + last4Digits);
				requestObject.replace("last4Digits", last4Digits + 1);
				break;
			// to replace caustomer id with invalid customer id
			case "Invalid CustID":
				Log.info( "actual customerId :" + customerId);
				requestObject.replace("customerId", customerId + "abc");
				break;
			// Fetch Sender URN Details from fund transfer response
			case "Fund Debit":
				jsonValue= basePayLoad.jsonObject(preConditionRequestResponse);
				Log.info( "sender Details: "+preConditionRequestResponse.asString());
				ArrayList senderDetails = jsonValue.get("senders");
				HashMap senderInfo = (HashMap) senderDetails.get(0);
				requestObject.replace("urn", senderInfo.get("urn").toString());				
				requestObject.replace("customerId", senderInfo.get("customerId").toString());
				cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", senderInfo.get("urn").toString());
				requestObject.replace("last4Digits", ExcelLibrary.getExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 1));
				break;
			//Fetch Sender URN Details from fund transfer response
			case "Fund Credit":
				jsonValue= basePayLoad.jsonObject(preConditionRequestResponse);
				Log.info( "receiver Details: "+preConditionRequestResponse.asString());
				ArrayList receiverDetails = jsonValue.get("receivers");
				HashMap receiverInfo = (HashMap) receiverDetails.get(0);
				requestObject.replace("urn", receiverInfo.get("urn").toString());				
				requestObject.replace("customerId", receiverInfo.get("customerId").toString());
				cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", receiverInfo.get("urn").toString());
				requestObject.replace("last4Digits", ExcelLibrary.getExcelData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 1));
				break;
			}

			Log.info("requestObject :" + requestObject.toString());
			
			Log.info( "requestObject Post URL :"+ cardTransactionInquiryPost);
			response = given().contentType("application/json")
					.body(requestObject).when().log().body()
					.post(cardTransactionInquiryPost).then()
//					.and().assertThat().statusCode(Integer.parseInt(responseStatusCode))
//					.and().contentType(ContentType.JSON).and()
					.extract().response();
			Log.info("Card Transaction Inquiry API Event Request responseMessage is "+ response.asString());
			
			
			int actualResponseCode = response.getStatusCode();
			boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

			if(!response.asString().isEmpty()){
				jsonValue = basePayLoad.jsonObject(response);
				jsonResponseMessage = jsonValue.get("responseMessage");
				jsonResponseCode = jsonValue.get("responseCode");
				Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode);
	
				responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
				responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
			}
			
			if (responseCodeAssert && responseMessageAssert) {
				if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
					Assert.assertEquals(String.valueOf(jsonValue.get("urn")),String.valueOf(requestObject.get("urn")));
					Assert.assertEquals(String.valueOf(jsonValue.get("customerId")),String.valueOf(requestObject.get("customerId")));
					transactionValidations = walletStatement.ValidateWalletStatementEvent(jsonValue,jsonValue.get("urn").toString(), "Transactions", "");
				}
				Log.pass("Card Transaction Inquiry API Event Request is Successfull");
				Log.info("Card Transaction Inquiry API Event Request responseMessage is "+ response.asString());
				cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH,"CardDetails", String.valueOf(requestObject.get("last4Digits")));
			} else {
				if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
					Log.info("Reload API Event Request Status is "+ response.statusLine());
					Log.pass("Reload API Event Request is Successfull as per testcase");
				}else{
					Log.fail("Card Transaction Inquiry API Event Request is Unsuccessfull");
					Log.info("Card Transaction Inquiry API Event Request responseMessage is "+ response.asString());
				}
			}

//			if (responseMessage.equalsIgnoreCase("SUCCESS")) {
//				String cardNumber = ExcelLibrary.getExcelData(testDataExcel, "CardDetails",cell[0], 0);
//				Log.info("**************In CSR Application to validate the "+preCondition +" event in prepaid details wrt card transaction inquiry**************");
//				Log.info("CSR Prepaid Details for "+preCondition +" event");
//				initBrowser("chrome", "CSR");
//				Log.info("Browser stated and Application launched");
//				String[] Credentials = getAppCredentials("CSR");
//				LoginPage csrLogin= new LoginPage(driver);
//				csrLogin.csrLogin(Credentials[0], Credentials[1]); // Username, Password
//				Log.info("Successfull logged into Application");
//
//				PrepaidDetailsPage prp = PageFactory.initElements(driver,PrepaidDetailsPage.class);
//				prp.checkPrepaidDetails(cardNumber);
//				Log.info( "cardNumber " + cardNumber);
//				boolean transactionValidation = prp.CSRValidateCardTransaction(preCondition, ,jsonRequestReferenceNumber);
//				assertTrue(transactionValidation);
//				if (transactionValidation) {
//					Log.pass("CSR Reload Transaction Validation is Successfull");
//				} else {
//					Log.fail("CSR Reload Transaction Validation is Not Successfull");
//				}
//			}			
			
		} catch (Exception e) {
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Transaction Inquiry API Event Request is Unsuccessfull");
			e.printStackTrace();
			
		}
	}
}
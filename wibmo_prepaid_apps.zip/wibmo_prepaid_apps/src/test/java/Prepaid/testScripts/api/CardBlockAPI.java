package Prepaid.testScripts.api;

import Prepaid.pageRepo.apiPayLoads.ActivationPayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;


import java.util.ArrayList;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertTrue;

public class CardBlockAPI extends APIBaseTest {

	ActivationPayLoad activation = new ActivationPayLoad(driver);
	String sanityTestDataExcel = System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
	String jsonRequestReferenceNumber;
	int amount;
	int i = 1;

	int[] Cell = null;

	int urn;
	String last4Digits;
	String customerId;

	JsonPath jsonValue;
	String jsonResponseMessage="Failure";
	String jsonResponseCode="Failure";
	boolean responseCodeAssert;
	boolean responseMessageAssert;

	// test method to call AeroPayloadBody() method for the api request body
	// formation
	@Test()
	public void CardBlock() {
		try {
			activation.AeroPayloadBody("CardBlock");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Sanity Card Temp Block Test Method
	@Test(dataProvider = "CardBlock_api", dataProviderClass = DataProviderUtility.class)
	// , dependsOnMethods= "CreateCardAPI"
	public void CardBlock(String testCaseID, String testScenario,String requestPayLoad, String responseCode, String responseMessage,String responseStatusCode, String preCondition,  String reportValidation) {
		try{
			String [] required = reportValidation.split(",");

			Log.info( testCaseID + "- "+ testScenario+" Expected Result:"+responseMessage+", "+responseCode+", "+responseStatusCode);
			Response preConditionRequestResponse = null;
			if (!preCondition.equals(null) && !preCondition.equals("")) {
				Log.info( "Executing Precondition :"+ preCondition);
				preConditionRequestResponse = basePayLoad.Precondition(preCondition, requestPayLoad);
				if (preConditionRequestResponse != null) {
					String preConditionAPIResponseCode = basePayLoad.getResponseValue(preConditionRequestResponse,"responseCode");
					Log.info( "Precondition of " + preCondition+ "is Successfull");
					Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
					if (!preConditionAPIResponseCode.equals("00")){
						System.out.println("Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info( "Skipping the excecution " + testCaseID+ "-" + testScenario + "as precondition failed");
						Log.info("Precondition of " + preCondition + " Response is "+ preConditionRequestResponse.asString());
						throw new SkipException("Skipping the excecution "+ testCaseID + "-" + testScenario+ "as precondition failed");
					}
				}
			}

			JSONObject requestObject = basePayLoad.ParseStringToJSON(requestPayLoad);
			last4Digits = requestObject.get("last4Digits").toString();
			urn = Integer.parseInt(requestObject.get("urn").toString());
			customerId = requestObject.get("customerId").toString();

			switch (preCondition) {
				// to replace URN with invalid URN
				case "Invalid URN":
					Log.info( "actual URN :"+ urn);
					requestObject.replace("urn",urn - 1);
					break;
				// to replace Last4Digits with invalid Last4Digits
				case "Invalid CardNo":
					Log.info( "actual last4Digits :"+ last4Digits);
					requestObject.replace("last4Digits", String.format("%04d", Integer.parseInt(last4Digits)+1));
					break;
				// to replace caustomer id with invalid customer id
				case "Invalid CustID":
					Log.info( "actual customerId :"+ customerId);
					requestObject.replace("customerId", customerId + "abc");
					break;
			}

			Log.info( "requestPayLoad :"+requestPayLoad);
			Log.info( cardBlockPost);
			System.out.println("cardBlockPost: " + cardBlockPost);
			Response response = given().contentType("application/json")
					.body(requestObject).when().log().body().post(cardBlockPost)
					.then().and()
//				.assertThat().statusCode(Integer.parseInt(responseStatusCode)).and()
//				.contentType(ContentType.JSON).and()
					.extract().response();

			int actualResponseCode = response.getStatusCode();
			boolean statusCodeAssert = (actualResponseCode == Integer.parseInt(responseStatusCode));

			if(!response.asString().isEmpty()){
				jsonValue = basePayLoad.jsonObject(response);
				jsonResponseMessage = jsonValue.get("responseMessage");
				jsonResponseCode = jsonValue.get("responseCode");
				jsonRequestReferenceNumber = jsonValue.get("accosaRefNo");

				Log.info( "Json response message is "+ jsonResponseMessage + ", Json response code is "+ jsonResponseCode+ ", Status Code is "+ actualResponseCode);

				responseCodeAssert = jsonResponseCode.equalsIgnoreCase(responseCode);
				responseMessageAssert = jsonResponseMessage.equalsIgnoreCase(responseMessage);
				System.out.println("Last4Digits########"+last4Digits);
				Cell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", String.valueOf(last4Digits));
			}


			if(responseCodeAssert && responseMessageAssert){
				if(jsonResponseMessage.equalsIgnoreCase("SUCCESS"))	{
					Assert.assertEquals(jsonValue.get("urn").toString(),requestObject.get("urn").toString());
					Assert.assertEquals(jsonValue.get("customerId").toString(),requestObject.get("customerId").toString());
				}
				Log.info( "Block API Event Request responseMessage is "+ response.asString());
				Log.pass( "Block API Event Request is Successfull");
			}else{
				if(statusCodeAssert && responseMessage.isEmpty() && responseCode.isEmpty()){
					Log.info("Block API Event Request Status is "+ response.statusLine());
					Log.pass("Block API Event Request is Successfull as per testcase");
				}else{
					Log.info( "Block API Event Request responseMessage is "+ response.asString());
					Log.fail( "Block API Event Request is Unsuccessfull");
				}
			}

//		try {
//			if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
//				// updating the Card Last 4 Digits, URN and Customer ID details
//				// on Card Block API Data sheet
////				ExcelLibrary.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 11,requestObject.get("last4Digits").toString());
////				ExcelLibrary.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 12,jsonValue.get("urn").toString());
////				ExcelLibrary.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardUnblock", i, 13,jsonValue.get("customerId").toString());
////				System.out.println(requestObject.get("blockType").toString()+ ":::::::::::"	+ requestObject.get("blockType").toString().equals("Temporary"));
//				if (requestObject.get("blockType").toString().equals("Temporary")) {
//					excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],17, "true"); // update Card Block event(t) as true if performed
//					excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 18, response.asString()); // update Card Block event(t) as true if card is active
//					excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],4, "Temporary Blocked"); // update Card Block event(t) as true if performed
//				} else {
//					if(requestObject.get("blockType").toString().equals("Custom")){
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],23, "true"); // update Card Block event(p) as true if performed
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 24, response.asString()); // update Card Block event(p) as true if card is active
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],4, "Custom Blocked"); // update Card Block event(t) as true if performed
//					}else{
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],19, "true"); // update Card Block event(p) as true if performed
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 20, response.asString()); // update Card Block event(p) as true if card is active
//						excel.writeExcelData(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0],4, "Permanent Blocked"); // update Card Block event(t) as true if performed
//					}
//				}
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
			i++;
			boolean transactionValidation=false;
			if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")){
				String cardNumber = ExcelLibrary.getExcelData(sanityTestDataExcel, "CardDetails",Cell[0], 0);
				Log.info("**************In CSR Application to validate the card block event in prepaid details**************");
				System.out.println("In CSR Application to validate the card block event in prepaid details");
				Log.info("CSR Prepaid Details for an card block event");
				initBrowser("chrome", "CSR");
				Log.info( "Browser stated and Application launched");
				String[] Credentials = getAppCredentials("CSR");
				System.out.println("Username and password is " + Credentials[0]+ " password is " + Credentials[1]);
				LoginPage csrLogin= new LoginPage(driver);
				csrLogin.csrLogin(Credentials[0], Credentials[1]); // Username, Password
				Log.info( "Successfull logged into Application");

				PrepaidDetailsPage prp = new PrepaidDetailsPage(driver);
				prp.checkPrepaidDetails(cardNumber);
				Log.info( "Card Number: "+cardNumber);
				transactionValidation = prp.CSRValidateCardTransaction(requestObject.get("blockType").toString(), amount, jsonRequestReferenceNumber);
				assertTrue(transactionValidation);
				if(transactionValidation){
					Log.pass( "CSR Block Transaction Validation is Successfull");
				}else{
					Log.fail( "CSR Block Transaction Validation is Not Successfull");
				}
			}

			ArrayList<Boolean> reportvalidation= new ArrayList<Boolean>();
			//External Activation Report Validation
			if(jsonResponseMessage.equalsIgnoreCase("SUCCESS")  && required[1].equalsIgnoreCase("true")){
				Log.info("**************In External Report to validate for Card block event in Block/Unblock Report**************");
				initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
				Log.info( "Browser started and Application launched");
				AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
//			WebDriverWait wait = new WebDriverWait(driver, 60000);
				enhancedReports.selectReport("Block/Unblock");
				enhancedReports.generateReport(Generic.currentDate("yyyy-MM-dd"), Generic.currentDate("yyyy-MM-dd"));
				enhancedReports.searchRecordInReport("//div[contains(text(),'"+urn+"')]");
				reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed());
				Log.info(urn+" URN is populating in report");
				reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4Digits+"')]")).isDisplayed());
				Log.info(last4Digits+" last4Digits is populating in report");

				if (requestObject.get("blockType").toString().equals("Temporary")) {
					reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'TEMP_BLOCK')]")).isDisplayed());
					Log.info("TEMP_BLOCK card is populating in report");
				} else {
					if(requestObject.get("blockType").toString().equals("Custom")){
						reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'CUSTOM_BLOCK')]")).isDisplayed());
						Log.info("CUSTOM_BLOCK card is populating in report");
					}else{
						reportvalidation.add(driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'PERMANENT_BLOCK')]")).isDisplayed());
						Log.info(" PERMANENT_BLOCK card is populating in report");
					}
				}
				if (!reportvalidation.contains(false)) {
					Log.pass("CSR Card Block/Unblock Report Validation is Successfull");
				} else {
					Log.fail("CSR Card Block/Unblock Report Validation is Not Successfull");
				}
			}

		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Block API Event Request is Unsuccessfull");
		}
	}
}
package Prepaid.testScripts.kotak.netCard;

import Prepaid.pageRepo.kotak.BasePage;
import Prepaid.pageRepo.kotak.CancelNetCardPage;
import Prepaid.testScripts.kotak.BaseTest;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Sep,2021
 */
public class TC_REG_KTK_NC_01 extends BaseTest {


    public TC_REG_KTK_NC_01(WebDriver driver) {
        super(driver);
    }

    @Test
    public void TC_REG_KTK_NC_01(){
        String cardNumber="4788 9368 5219 1647";
        BasePage basePage=new BasePage(driver);
        CancelNetCardPage cancelNetCardPage=new CancelNetCardPage(driver);
            basePage.loginNetCard("1234543","password1234");
        basePage.loadFrame();
            cancelNetCardPage.clickCancelLink();
            cancelNetCardPage.selectNetCard(cardNumber);
            Boolean status=cancelNetCardPage.verifyCheckBoxSelected(cardNumber);
            if(status) {
                Assert.assertTrue(true, "The Check box is enabled");
            }
                else{
                    Assert.assertTrue(false,"The check box is not selected");
                }


            cancelNetCardPage.clickCancelCard();

            String successMessage=cancelNetCardPage.getSuccessMessage();

            if(successMessage.contains("Ypur ne@tcard "+cardNumber+"cancelled successfully")){
                Assert.assertTrue(true,"The Net card has been cancelled successfully");
            }      else{
                Assert.assertTrue(false,"The Cancel Net card success message is not displayed");
            }

    }
}

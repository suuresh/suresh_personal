package Prepaid.testScripts.kotak;

import Prepaid.pageRepo.kotak.BasePage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import library.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import java.util.Calendar;
import java.util.HashMap;

public class BaseTest extends BasePage {
	

	public static int count = 0;
	public static WebDriver driver;
	public static WebDriverWait wait;
	public String DataSheet;
	public static ExtentReports reports;
	public static ExtentTest logger;
	public static String app;
	public static String browser = "chrome";
	public static String executionType="Regression";
	//public static String authorizationsTestData = pf.getProperty(executionType+"AuthorizationData");
	public static Calendar c = Calendar.getInstance();

	String url=null;

	public BaseTest(WebDriver driver) {
		super(driver);
	}

	/**
	 * This method is used to initiate the browser and launch the application URL.
	 * 
	 * @param browserName
	 */
	public WebDriver initBrowser(String browserName, String application) {
		String downloadFilepath = System.getProperty("") + "\\Downloads";
		if (browserName.equalsIgnoreCase("chrome")) {
			//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\softwares\\chromedriver.exe");
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadFilepath);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", chromePrefs);
			options.addArguments("--disable-notifications");
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(options);
			driver.get(url);
			app = application;
			wait = new WebDriverWait(driver, 60000);
			driver.manage().window().maximize();	
		} else {
			//System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\softwares\\geckodriver.exe");
			DesiredCapabilities cap = DesiredCapabilities.firefox();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			cap.setCapability("marionette", false);
			
			driver = new FirefoxDriver();
			
			driver.get(url);
			app = application;	        
			wait = new WebDriverWait(driver, 60000);
			driver.manage().window().maximize();
		}
		return driver;
	}


	
	@BeforeSuite(alwaysRun = true)
	public void initialSetUp(){
		reports=new ExtentReports(System.getProperty("user.dir")+"\\Reports\\"+toDate()+"\\Kotak_"+timeStamp()+".html");

				
	}

	// ****************************************************************************

	@AfterSuite()
	public void tearDownSuite() {
		System.out.println("i m in suite");
		reports.endTest(logger);
		reports.flush();
	
	}

	// ****************************************************************************
	@AfterMethod
	public void closeBrowser(ITestResult result) {
		try{
			if (result.getStatus() == ITestResult.FAILURE) {
				System.out.println(count);
				Log.fail( "Test case " + result.getName() + " failed");
				driver.quit();
//				reports.endTest(logger);
//				reports.flush();
			}
			if (driver != null && !driver.getWindowHandle().isEmpty()) {

				driver.quit();
				}
		}
		catch(Exception e){
			return;
		}
	}
	
	@AfterClass
	public void tearDownClass()
	{
		if (driver != null) {
	    driver.quit();
		}
	}
	
	/**
	 *  this is for dateStamp()
	 * @return
	 */
	public static String toDate()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE);
	}
	
	/**
	 * 
	 * @return
	 */
	
	public static String timeStamp()
	{
		return c.get(Calendar.YEAR) +"_"+ (c.get(Calendar.MONTH)+1)+"_"+ c.get(Calendar.DATE)+"_"+c.get(Calendar.HOUR)+"_"+c.get(Calendar.MINUTE)+"_"+ c.get(Calendar.SECOND);
	}
}

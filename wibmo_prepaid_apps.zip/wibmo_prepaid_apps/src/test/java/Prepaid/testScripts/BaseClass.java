package Prepaid.testScripts;

import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.config.DriverManagerType;
import io.github.bonigarcia.wdm.managers.ChromeDriverManager;
import io.github.bonigarcia.wdm.managers.FirefoxDriverManager;
import library.*;
import org.apache.commons.io.FileUtils;
//import org.apache.log4j.PropertyConfigurator;
import org.ini4j.Ini;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

//import org.testng.annotations.Listeners;


/**
 * The Class Prepaid.testScripts.BaseClass used to start the appium server and launch the AUT.
 */

// @Listeners({MyTestListner.class})
public class BaseClass {

	/*public static final String USERNAME = "srikiran3";
	public static final String AUTOMATE_KEY = "7qwjfct57QopZ61VPvXL";
	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";*/

	public static final String USERNAME = "srikiran.d";
	public static final String AUTOMATE_KEY = "UjvOcHvYHgENLbih6YzQfs8XYxTHGUFlLNx8H2xWXO5x8yDYTJ";
	public static final String URL = "http://" + USERNAME + ":" + AUTOMATE_KEY + "@hub.lambdatest.com/wd/hub";



	/**
	 * For running testcases on browserless enable to TRUE
	 */

	public boolean headless = false;


	/**
	 * The skipStatus used to check whether a d
	 *river with a given udid has custom
	 * skipped an @Test Used to add skip status to Report. Mapped as udid=true means
	 * a Generic.customSkip() was executed by the corresponding driver
	 * 
	 */
	public static HashMap<String, Boolean> skipStatus = new HashMap<String, Boolean>();

	/** The udidModel used to Map udid=Device Model. */



	/** The br version. */
	public static String brVersion = " ";

	/** The package name of AUT */
	public static String packageName = " ";

	/** The driver non static . */
	public WebDriver driver;

	/** The udid Unique Device Identifier non static used to represent the thread */
	public String udid;

	/** The path. */
	public static String path = System.getProperty("user.dir").replace("\\", "/"); // MAC

	/** The test scenario name. */
	public String testScenarioName;

	/** The test scenario. */
	public String testScenario;

	/** The class name. */
	public String className;

	/** The path to config xlsx */
	public static String configXLPath = "./config/config.xlsx";

	/** The environment variable. */
	public static String env = "Web"; //ExcelLibrary.getExcelData(configXLPath, "Android_setup", 8, 5);

	/** The environment config folder. */
	private static String envConfigFolder;

	/** The port. */
	public String port;

	public String executionDeviceId = "";

	public String bootstrapPort;

	/** The address. */
	private static String address;

	/** The count. */
	static int count = 0;

	/** Methods which uninstall the app will set this to false */
	static boolean appPresent = true;

	/** IOS Bundle ID */
	public static String bundleId = "";

	/** The app activity. */
	public static String appActivity = "";

	/** The bank name. */
	public static String bankName = "";

	/** The bank code. */
	public static String bankCode = "";

	/** The path to config folder. */
	public static String configPath;

	public static String chromeDriverPath;

	/** The qa variable used to previously check for qa environment. */
	// public static boolean qa=false;

	/** The program name. */
	public static String programName = "";

	/** The path to TestData excel File. */
	public static String excelPath;

	public boolean isAppPresent = true;

	public static String model = "";

	public static String version = "";

	public static String resolution = "";

	public static String appVersion = "";

	public static String category = "";

	public static boolean runtimePermissionsGranted = false; // Use static map in devicePermission

	public static ChromeDriverService chromeService;

	// Used to match development codebase //
	public static boolean deviceTrialRun;

	public static int bootstrapNumber = 4820;

	// public static final String iniPath = "./excel_lib/" + env + '/'
	// +"android"+'/'+ "TestData.ini";

	// public static String testDescription="";

	/**
	 * Returns the main driver
	 *
	 * @return the driver
	 */
	public WebDriver getDriver() {
		return driver;
	}

	/**
	 * Gets the test Scenario name.
	 *
	 * @return the class name
	 */
	public String getClassName() {
		return testScenarioName;
	}

	/**
	 * Gets the test scenario.
	 *
	 * @return the test scenario
	 */
	public String getTestScenario() {
		return testScenario;
	}

	/**
	 * Sets the test scenario.
	 *
	 * @param testScenario
	 *            the new test scenario
	 */
	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	/**
	 * Gets the browser os information from driver Capabilities.
	 *
	 * @param driver
	 *            the driver
	 * @return the browser os info
	 * 
	 */


	/**
	 * Cleans the reports directory and initializes paths for TestData.xls and
	 * config.properties based on the environment.
	 */
	@BeforeSuite
	public void executeCleanUpFile() {
		//setWebDriverProperty();

		// ==== E ==== //
		ExtentManager.generateFilePath();
		// =========== //

		File file_to_delete = new File(path + "/target/surefire-reports");
		File screen_shot_dir = new File(path + "/screenshots");



	}

	/**
	 * Initializes paths for TestData.xls and config.properties based on the
	 * environment set by SetTestData.jar
	 */
	public static void initializeEnvPaths() {
		// -------- Retrieve package name from config.xls -------- //
		// Prepaid.testScripts.BaseClass.packageName=ExcelLibrary.getExcelData(".\\config\\config.xls",
		// "Android_setup", 8,5);

		// env = ExcelLibrary.getExcelData(configXLPath, "Android_setup", 8, 5);
		configPath = "./config" + "/" + env + "/config.properties";
		//packageName = Generic.getPropValues("PACKAGENAME", configPath);
		//System.out.println("Setting package name : " + packageName);

		// env = packageName.split("\\.")[3];

		System.out.println("Environment initialized to " + env);

		// --------------------------Jenkins Support
		// -------------------------------------//
		// if(ExcelLibrary.getExcelData(configXLPath, "Android_setup",
		// 8,7).equalsIgnoreCase("true"))
		// env="jenkins_"+env; Use Global variable instead
		// ------------------------------------------------------- //

		// -------- Set config folder and path--------/
		if (env.contains("_")) // Jenkins
			envConfigFolder = env.split("_")[1]; /*
													 * Folders under config i.e qa and staging are same for jenkins ,
													 * env=jenkins_staging
													 */
		else
			envConfigFolder = env;

		// configPath="./config"+"/"+envConfigFolder+"/config.properties";
		System.out.println("configPath set to " + configPath);
		// -----------------------------------------------------//


	}


	//@Parameters("device-id")
	@BeforeTest
	public void initializeLogger() {
//		PropertyConfigurator.configure("log4j.properties");
		//baseSetup();

		// grantAppRuntimePermissions(deviceId);

	}

	/**
	 * Initializes the AUT configuration attributes for all Test Classes.
	 *
	 */



	@BeforeMethod
	public void startMethod(Method testMethod) {

		// setSkipStatus(driver,false); WebSDK driver not initialized for overloaded
		// @BeforeMethod launchApplication()
		// Do not use any driver here. Only reflect class names

		// --------------------------------E------------------------------------------//

		String tcName = testMethod.getName();

//		if (tcName.contains("navi")) {
//			System.out.println("navigate() method found ");
//			return;
//		}
//
//		if (!tcName.contains("_")) {
//			System.out.println("Invalid TC name in startMethod : " + tcName);
//			return;
//		}

		String testDescription = "Default";

		try {
			Method classMethod = this.getClass().getMethod("getTestScenario", String.class);
			testDescription = (String) classMethod.invoke(this, tcName);
		} catch (Exception e) {
			System.out.println("== Error in invoking method ==");
			e.printStackTrace();
		}

		String category = this.getClass().getCanonicalName().split("testScripts.")[1].split("\\.")[0];// previously
																										// global
																										// category used

		System.out.println("------------------------------------- " + tcName + " : " + testDescription
				+ " ---------------------------------------");
		try {

//			if (Generic.isIos(driver))
//				category += " IOS";

			ExtentTestManager.startTest(tcName, testDescription);
			ExtentTestManager.getTest().assignCategory(category);

		} catch (Exception e) {
			System.out.println("Warning : Unable to write to Extent");
		}

		// ---------------------------------------------------------------------------//
	}

	public String getTcId(Method testMethod) {
		String classPackage = this.getClass().getCanonicalName().split("testScripts.")[1].split("\\.")[0],
				methodPackage = testMethod.getDeclaringClass().getCanonicalName().split("testScripts.")[1]
						.split("\\.")[0];

		return (classPackage == methodPackage) ? this.getClass().getSimpleName() : testMethod.getName();
	}

	@BeforeMethod
	public void launchApplication(){
		String path = System.getProperty("user.dir")+File.separator+"Downloads";
		Map<String, Object> prefsMap = new HashMap<String, Object>();
		prefsMap.put("profile.default_content_settings.popups", 0);
		prefsMap.put("download.default_directory",path);
		ChromeOptions option = new ChromeOptions();
		option.setExperimentalOption("prefs", prefsMap);
		option.addArguments("--test-type");
		option.addArguments("--disable-extensions");
		if(headless==true) {
			option.addArguments("--headless");
		}
		WebDriverManager.chromedriver().setup();
		//driver = new ChromeDriver(option);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
	}

	@Parameters({"browserName", "version", "platform", "resolution"})
//	@BeforeMethod
	public void setUp(String browserName, String version, String platform, Method name, String resolution) {

		System.out.println("browser name is : " + browserName);
		String methodName = name.getName();

        String path = System.getProperty("user.dir")+File.separator+"Downloads";
        Map<String, Object> prefsMap = new HashMap<String, Object>();
        prefsMap.put("profile.default_content_settings.popups", 0);
        prefsMap.put("download.default_directory",path);
        ChromeOptions option = new ChromeOptions();
        option.setExperimentalOption("prefs", prefsMap);
        option.addArguments("--test-type");
        option.addArguments("--disable-extensions");

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("browser_version", version);
		caps.setCapability("platform", platform);
		caps.setCapability("name", methodName);
		caps.setCapability("resolution", resolution);

		caps.setCapability("tunnel", true);


		caps.setCapability("network", true); // To enable network logs
		caps.setCapability("visual", true); // To enable step by step screenshot
		caps.setCapability("video", true); // To enable video recording
		caps.setCapability("console", true); // To capture console logs

//		caps.setCapability("browserstack.local", true);


		if (browserName.equals("Chrome")) {
			caps.setCapability("browserName", "Chrome");
			ChromeOptions options = new ChromeOptions();
//			WebDriverManager.chromedriver().setup();
//			driver = new ChromeDriver();
		} else if (browserName.equals("Firefox")) {
			caps.setCapability("browserName", "Firefox");
			FirefoxOptions options = new FirefoxOptions();
			options.addPreference("browser.download.folderList", 2);
			options.addPreference("browser.download.dir", "D:\\Downloads");
			options.addPreference("browser.download.useDownloadDir", true);
			options.addPreference("browser.helperApps.neverAsk.saveToDisk", "image/jpeg");
//			WebDriverManager.firefoxdriver().setup();
//			driver = new FirefoxDriver();
		}else if (browserName.equals("Safari")) {
			caps.setCapability("browserName", "Safari");
			DriverManagerType safari = DriverManagerType.SAFARI;
			WebDriverManager.getInstance(safari).setup();
//			driver = new SafariDriver();
		}else if (browserName.equals("IE")) {
			caps.setCapability("browserName", "IE");
			WebDriverManager.iedriver().setup();
//			driver = new InternetExplorerDriver();
		}else if (browserName.equals("Edge")) {
			caps.setCapability("browserName", "Edge");
			WebDriverManager.edgedriver().setup();
//			driver = new EdgeDriver();
		}else if (browserName.equals("Opera")) {
			caps.setCapability("browserName", "Opera");
			WebDriverManager.operadriver().setup();
//			driver = new OperaDriver();
		}

		try {
			driver = new RemoteWebDriver(new URL(URL), caps);
//			((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}


	/**
	 * Updates the @Test result status to the Extent Report
	 * 
	 * 
	 * @return udid corresponding to the driver
	 */
	@AfterMethod
	public void updateResults(ITestResult iRes) {
		int res = iRes.getStatus();
		String testName = iRes.getMethod().getMethodName();
		String extScreens = "./" + testName + ".jpg";
		// if(testName.contains("IAPT")) testName=className;

		// ---- Custom Skip Logic ---- //
//		if (getSkipStatus(driver)) {
//			ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
//			ExtentManager.getReporter().flush();
//			setSkipStatus(driver, false);
//			return;
//		}

		// ------------ //
		if (res == 2) // SUCCESS=1 , FAILURE=2, SKIP=3
		{
//			setResult(testName, "FAIL");
			if (driver == null) {
				System.out.println("No Screenshot for null driver ");
				return;
			} // Support driverless execution

			WebDriver driver = this.driver;
			System.out.println("Failure --- Capturing screenshot");
			// ---------------------------------------------------------------//
			// if(csr.getCSRStatus())
			// driver=csr.getDriver();
			// ---------------------------------------------------------------//
			try {
				if (driver != null) {
					File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					try {

						if (Generic.isIos(driver))
							testName += "_IOS";

						FileUtils.copyFile(f, new File(ExtentManager.screenPath + testName + ".jpg")); // Extent
						try {
							Thread.sleep(2000);
						} catch (Exception e) {
						}

					} catch (IOException e) {
						System.out.println("== Error in copying screenshot ==\n" + e.getMessage());
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
				System.out.println("======== Error in obtaining screenshot ========\n");
				e.printStackTrace();
			}


			ExtentTestManager.getTest().log(LogStatus.FAIL, "HTML",
					"There is an error: <br/><br/> " + iRes.getThrowable().getMessage()
							+ " <br/><br/> Error Snapshot : "
							+ ExtentTestManager.getTest().addScreenCapture(extScreens));
		}
		if (res == 1) {
			ExtentTestManager.getTest().log(LogStatus.PASS, "========== Passed: " + testName + " ==========" , ExtentTestManager.getTest().addScreenCapture(extScreens));

		}
		if (res == 3) {
			// Refer Framework Skip Logic

		}


		ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
		ExtentManager.getReporter().flush();
		//driver.quit();
	}



//	@Parameters("device-id")
//	@BeforeClass

	/**
	 * Closes the application. Closes the csr window specific to the driver if it is
	 * open.
	 */
	// @AfterClass(alwaysRun=true)
	public void quit() {

		// ==== E ==== // System/Device Info can be added only before flush().

		// Log.endTestCase(this.getClass().getSimpleName());

		// ---------------------csr---------------------------//
		try {
			// if(csr.getDriver(driver)!=null &&
			// !csr.getDriver(driver).toString().contains("null"))
			// {
			// csr.getDriver(driver).quit();
			// //csr.setCSRNull();
			// csr.setCSRStatus(driver,false);
			// }
			// csr.setCSRNull(driver);
		} catch (Exception e) {
			System.out.println("== csr driver delay ==\n" + e.getMessage());
		}
		// ---------------------------------------------//

		try {
			BaseTest1.setWebOverlayStatus(driver, false);

			handleIOSDelayedAlert();

			// ======== Advanced Launch ========//
			// if(driver!=null) driver.quit(); Toggle for advancedLaunch()

			// ==== Close Web SDK driver ==== //
			if (Generic.isWebDriver(driver)) {
				System.out.println("Closing WebDriver : " + driver.toString());

				try {
					driver.close();
					driver.quit();
				} catch (Exception e) {
					System.err.println("WebDriver Close	Error");
				}
				return;
			}
			// ======================//

		  
			// ==================//

		} catch (Exception e) {
			System.err.println("Unable to close driver/logout under @AfterClass");
			e.printStackTrace();
			/* driver=null */;
		}

	}


	public synchronized void launchApp() {
		String path = System.getProperty("user.dir")+File.separator+"CSR_Reports";
		Map<String, Object> prefsMap = new HashMap<String, Object>();
		prefsMap.put("profile.default_content_settings.popups", 0);
		prefsMap.put("download.default_directory",path);
		ChromeOptions option = new ChromeOptions();
		option.setExperimentalOption("prefs", prefsMap);
		option.addArguments("--test-type");
		option.addArguments("--disable-extensions");
		WebDriverManager.chromedriver().setup();
		//driver = new ChromeDriver(option);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		driver.get(url);
		//driver.manage().window().maximize();

	}


	/**
	 * Checks for the environment - Staging or QA.
	 *
	 * @param environment
	 *            the environment
	 * @return true if environment string (in lowercase) matches the static env
	 *         variable.
	 */
	public static boolean checkEnv(String environment) {
		return env.contains(environment.toLowerCase());
	}

	/**
	 * Closes Appium server.
	 */
	@AfterSuite(alwaysRun = true)
	public void close() {
		try {

			Thread.sleep(5000);

			// ======== E ========== //
			ExtentManager.createExtZip();
			ExtentManager.sendMail();
			// =================== //

			SendMailUsingAuthentication sm = new SendMailUsingAuthentication();

		} catch (Exception e) {
			System.out.println("Error in closing After Suite process  " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Gets the complete class name for the given Test Class.
	 *
	 * @return the complete class name
	 */
	public String getCompleteClassName() {
		return className;
	}

	/**
	 * Returns an available Port.
	 *
	 * @return the port
	 */
	private String getPort() {
		try {
			ServerSocket socket = new ServerSocket(0);
			socket.setReuseAddress(true);
			String port = "";
			if (socket.getLocalPort() != -1) {
				port = Integer.toString(socket.getLocalPort());
				socket.close();
				return port;
			} else {
				socket.close();
				return getPort();
			}
		} catch (Exception e) {
			return getPort();
		} catch (Error e) {
			return getPort();
		} // ECONNRESET Error
	}



	/**
	 * Gets the IP address.
	 *
	 * @return the address
	 */
	private String getAddress() {
		try {
			InetAddress addr = InetAddress.getLocalHost();
			return addr.getHostAddress();
		} catch (Exception e) {
			return "127.0.0.1";
		}
	}



	/**
	 * Selects the qa program within the QA app after creating a new object of
	 * Prepaid.testScripts.BaseClass.
	 *
	 * @param driver
	 *            the driver
	 */
	public void selectQaProgram(WebDriver driver) {
		if (!checkEnv("qa"))
			return;

		String xp = "//android.widget.TextView[contains(@resource-id,'title_text')]";
		String txt = driver.findElement(By.xpath(xp)).getText();

		if (Generic.containsIgnoreCase(txt, "QA")) {
			System.out.println("======== Waiting for  QA screen pageload ========");
			Generic.wait(3); // Wait for loading screen to complete
			txt = driver.findElement(By.xpath(xp)).getText();
		}

		System.out.println("======== Selecting Program based on " + env + " env from " + txt + " screen ========");

		if (txt.contains("Select Program")) {
			System.out.println(
					"======== Clicking " + programName + " based on " + env + " env in " + txt + " screen========");
			driver.findElement(By.name(programName)).click();
		}
	}

	public static boolean checkUDIDConnected(String udid) {
		try {
			String chkCmd = Generic.isIos(udid) ? "xcrun instruments -s devices" : "adb devices";

			return Generic.execCmd(chkCmd).contains(udid);
		} catch (Exception e) {
			System.err.println("Error while checking for connected UDID " + udid + "\n" + e.getMessage());
			return false;
		}
	}

	public void getExecutionDeviceId() {
		if (executionDeviceId.isEmpty()) {
			try {
				executionDeviceId = (String) ((AndroidDriver) driver).getCapabilities().getCapability("deviceName");
			} catch (Exception e) {
				System.err.println("=== Unable to obtain execution device Id ===");
			}
		}
	}



	public void setWebDriverProperty() {
		// setFirefoxBinary();

		String geckoExecutablePath = "./config/geckodriver"
				+ (System.getProperty("os.name").contains("Mac") ? "" : ".exe");
		String chromeExecutablePath = "./config/chromedriver"
				+ (System.getProperty("os.name").contains("Mac") ? "" : ".exe");

		System.out.println("Setting WebDriver properties \n " + geckoExecutablePath + '\n' + chromeExecutablePath);
		// System.setProperty("webdriver.firefox.marionette",geckoExecutablePath);
		System.setProperty("webdriver.gecko.driver", geckoExecutablePath);
		System.setProperty("webdriver.chrome.driver", chromeExecutablePath);

	}

	public void setFirefoxBinary() {
		String firefoxBinaryPath = ExcelLibrary.getExcelData(configXLPath, "Android_setup", 2, 5);
		try {
			if (firefoxBinaryPath.length() > 3) // " "
			{
				if (!new File(firefoxBinaryPath).exists())
					return;

				System.out.println("Setting Firefox Binary Path to " + firefoxBinaryPath);
				System.setProperty("webdriver.firefox.bin", firefoxBinaryPath);
			}
		} catch (Exception e) {
			System.err.println("Error in Setting Firefox Binary Path . Check config.xlsx file");
		}
	}

	/**
	 * 
	 * @param udid
	 * @return the platform version as specified in the Devices.ini
	 * @author aravindanath
	 */
	public String getPlatformVersion(String udid) {

		String path = "./config/" + env + '/' + "Devices.ini";

		Ini ini = null;
		try {
			ini = new Ini(new File(path));
		} catch (IOException e) {
			System.err.println("Devices.ini file not found");
			System.exit(1);
		}

		String value = ini.get(udid, "platformVersion");
		if ((value == null)) {
			System.err.println("Platform Version  not found for " + udid);
			System.exit(1);
		}
		return value;
	}

	/**
	 * 
	 * @param udid
	 * @return Device Name as specified in Devices.ini
	 * @author aravindanath
	 */
	public String getDeviceName(String udid) {

		String path = "./config/" + env + '/' + "Devices.ini";

		Ini ini = null;
		try {
			ini = new Ini(new File(path));
		} catch (IOException e) {
			System.err.println("Devices.ini file not found " + udid);
			System.exit(0);
		}

		String value = ini.get(udid, "deviceName");
		if ((value == null)) {
			System.err.println("Device name not found for " + udid);
			System.exit(0);
		}

		return value;
	}


	public String appiumChromeDriverExecutable(String udid) {
		try {
			String chromePkgName = "com.android.chrome";
			String chromeExecutableVersionPath = System.getProperty("user.dir") + File.separator
					+ "ChromeDriverExecutables" + File.separator + getChromeDriverExecutableVersion(udid)
					+ File.separator + "chromedriver.exe"; // Ex : ./ChromeDriverExecutables/2.18/chromedriver.exe

			chromeExecutableVersionPath = System.getProperty("os.name").contains("Mac")
					? chromeExecutableVersionPath.replace(".exe", "")
					: chromeExecutableVersionPath; // OS Adjust
			System.out.println("Relative Path for ChromeDriverExecutable : " + chromeExecutableVersionPath);

			if (chromeExecutableVersionPath.contains("builtin"))
				return "builtin";
			else
				return new File(chromeExecutableVersionPath).getAbsolutePath();
		} catch (Exception e) {
			return "builtin";
		}
	}

	/**
	 * Retrieves the ChromeDriverExecutableVersion from config.xlsx
	 * 
	 * 
	 * @param udid
	 * @return chromeDriverExecutableVersion corresponding to the udid
	 */
	public String getChromeDriverExecutableVersion(String udid) {
		// Get version corresponding to the udid from config file
		// If no version found return "chromeDriverExecutableVersionNotFound" , Print
		// Warning at Capabilities & Launch

		String sheet = "Modules", version = "", tcRowVal;

		int rc, udidColumn = 9, versionColumn = 11;

		try {
			rc = ExcelLibrary.getExcelRowCount(configXLPath, sheet);

			for (int i = 0; i <= rc; i++) {
				tcRowVal = ExcelLibrary.getExcelData(configXLPath, sheet, i, udidColumn);
				if (tcRowVal.equals(udid)) {
					version = ExcelLibrary.getExcelData(configXLPath, sheet, i, versionColumn);
					break;
				}
			}
		} catch (Exception e) {
			System.err.println("Error retrieving Device model for " + udid + '\n');
			e.printStackTrace();
		}

		return version.length() > 2 ? version : "builtin";

	}

	/**
	 * Handle delayed Alerts generated from previous TestCases To be
	 * executed @AfterClass IOS Only
	 * 
	 */
	public void handleIOSDelayedAlert() {

		if (!Generic.isIos(driver))
			return;

		try {

			String alertChkPredicate = "(name contains 'battery' or name='Ok') and visible=true";

			if (driver.findElements(MobileBy.iOSNsPredicateString(alertChkPredicate)).size() > 1) {
				System.out.println("Handling delayed alert");
				driver.findElement(MobileBy.AccessibilityId("Ok")).click();
			}

		} catch (Exception e) {
			System.err.println("Error in handling delayed alert ");
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * @param chromeAppVersion
	 * @return
	 * @deprecated
	 */
	public String getChromeExecutableVersion(String chromeAppVersion) {
		try {
			double chromeAppVer = Double.parseDouble(chromeAppVersion.split("\\.")[0]);

			if (chromeAppVer < 47)
				return "2.18";
			if (chromeAppVer > 58)
				return "builtin";
		} catch (Exception e) {
			System.err.println("-- Unable to get Chrome Executable version --");
			e.printStackTrace();
		}
		// ... Add based on future Chrome App versions 7 Check ... //

		return "builtin"; // Use BuiltIn ChromeDriver version bundled with Appium
	}



	@AfterClass
	public void killApp() {
		//driver.quit();
	}






}

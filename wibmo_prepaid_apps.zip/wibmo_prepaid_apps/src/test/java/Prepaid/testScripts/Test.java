package Prepaid.testScripts;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Test {

    public static void main(String args[]) {
       Test test = new Test();
       test.sort();
    }

    public void findNumbers() {
        String value = "Sr1k1r@n";

        char character[] = value.toCharArray();

        StringBuilder characters = new StringBuilder();
        StringBuilder integers = new StringBuilder();
        StringBuilder specialchar = new StringBuilder();


        for (int i = 0; i < character.length; i++) {
            if (Character.isDigit(character[i])) {
                integers = integers.append(character[i]);
            }
            if (Character.isAlphabetic(character[i])) {
                characters = characters.append(character[i]);
            }
            if (Character.isSpaceChar(character[i])) {
                specialchar = specialchar.append(character[i]);
            }
        }
        System.out.println("Integer :" + integers);
        System.out.println("Character :" + new String(characters));
    }

    public void whilereverse() {
        String value = "How are you Doing? All Good!";
        int i = value.length();
        while (i > 0) {
            System.out.print(value.charAt(i - 1));
            i--;
        }
    }

    public void duplicateword() {
        String name = "Big black bug bit a big black dog on his big black nose";
        int count;
        String[] words = name.split(" ");

        for (int i = 0; i < words.length; i++) {
            count = 1;
            for (int j = i + 1; j < words.length; j++) {
                if (words[i].equalsIgnoreCase(words[j])) {
                    count++;
                    words[j] = "0";
                }
            }

            if (count > 1 && words[i] != "0") {
                System.out.println(words[i] + " count: " + count);
            }
        }
    }


    public void duplicate() {
        String name = "Srikiran";
        int count;
        char string[] = name.toCharArray();

        for (int i = 0; i < string.length; i++) {
            count = 1;
            for (int j = i + 1; j < string.length; j++) {

                if (string[i] == string[j] && string[i] != ' ') {
                    count++;
                    string[j] = 0;
                    System.out.println("String: " + new String(string));
                }
            }
            if (count > 1 && string[i] != 0) {
                System.out.println(string[i] + " count " + count);

            }
        }
    }

    public void find() {
        String string = "blr bangalore";

        String[] word = string.split(" ");

        for (int i = 0; i < word[0].length(); i++) {
            for (int j = 0; j < word[1].length(); j++) {
                if (word[0].charAt(i) == word[1].charAt(j)) {
                    System.out.println(word[0].charAt(i));
                }
            }
        }
    }

    public void reverse() {
        try {

//           How are you Doing? All Good!
//              Output: dooG! llA gnioD? uoy era woH

            String string = "How are you Doing? All Good!";

            byte[] bites = string.getBytes();

            byte[] result = new byte[bites.length];

            for (int i = 0; i < bites.length; i++) {
                result[i] = bites[bites.length - i - 1];
            }

            System.out.println("reverse String : " + new String(result));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sort() {
        try {
            {
                int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8};
                int[] sorted;
                int t;
                for (int i = 0; i < numbers.length; i++) {
                    int a = numbers[i];
                    for (int j = 1; j < numbers.length; j++) {
                        int b = numbers[j];
                        if (a < b) {
                            numbers[i] = b;
                            numbers[j] = a;
                            break;
                        }
                    }
                }

                System.out.println("sorted" + numbers);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

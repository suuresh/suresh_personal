package Prepaid.testScripts;

//import com.libraries.Log;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.MobileBy;
import io.appium.java_client.Setting;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import library.ExcelLibrary;
import library.ExtentManager;
import library.ExtentTestManager;
import library.Generic;
import org.apache.commons.io.FileUtils;
//import org.apache.log4j.PropertyConfigurator;
import org.ini4j.Ini;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class BaseDev // imitates Prepaid.testScripts.BaseClass for Script Development
{
    protected String url = Generic.getPropValues("CMS_URL");  //"https://bdocsr-s2qa.pc.enstage-sas.com/#/login";
    static boolean KillApp = false;
    public static String env = ExcelLibrary.getExcelData("./config/config.xlsx", "Android_setup", 8, 2); // read

    public static String hostname;
    public static InetAddress ip;
    public static String OS = System.getProperty("os.name").toLowerCase();

    public static boolean deviceTrialRun = true;
    public static String path = System.getProperty("user.dir").replace("\\", "/"); // MAC
    public static final String configPath = "./config/" + env + "/config.properties"; // env= "staging" or "qa"
    public static final String iniPathiOS = "./excel_lib/" + env + '/' + "ios" + '/' + "TestData.ini";

    public static final String configXLPath = "E:\\D backup\\Shankar\\Automation\\Wibmo_Prepaid_Apps\\config\\config.xlsx";


    protected WebDriver driver;
    public static String bankCode = "2000", programName = "BDO";


    public static String appVersion = "";

    public static HashMap<String, String> udidModel = new HashMap<String, String>();


    public static HashMap<String, Boolean> skipStatus = new HashMap<String, Boolean>();

    public static HashMap<String, WebDriver> driverHolder = new HashMap<String, WebDriver>();


    // ==== ------------------------------ ==== //

    private String testScenarioName;
    private String className, category = "";
    private String model = "";
    private String version = "";
    private String resolution = "";

    @Parameters("device-id")
    @BeforeClass
    public void launchApplication(@Optional("Chrome") String udid) // cannot remove String udid => impacts
    // individual launchApplication()to
    // match Prepaid.testScripts.BaseClass <test> Parameter //
    {

        ExtentManager.generateFilePath();
        System.out.println("Declared Methods :" + this.getClass().getDeclaredMethods().length);
        System.out.println("Declared Annotations :" + this.getClass().getDeclaredAnnotations().length);
        System.out.println("Simple name: " + this.getClass().getSimpleName());


        launchApp();

        driverHolder.put(udid, driver);
        System.out.println("Driver Holder :" + driverHolder);

        testScenarioName = this.getClass().getSimpleName();
        className = this.getClass().getCanonicalName();

        BaseTest1.setWebOverlayStatus(driver, false);
    }

    @BeforeSuite // Match to Prepaid.testScripts.BaseClass
    public void executeCleanUpFile() {
        setWebDriverProperty();
        try {
            ip = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        hostname = ip.getHostName();
        // BaseAPI.init();
    }

    @AfterSuite
    public void closeAll() {
        // DB.closeDB();
    }

    // Sets the Firefox Binary Path if the Firefox/exe is not in the default path.
    //
    public static void setFirefoxBinary() {
        String firefoxBinaryPath = ExcelLibrary.getExcelData("./config/config.xlsx", "Android_setup", 2, 5); // read
        // from
        // config.xls

        if (firefoxBinaryPath.toLowerCase().contains("fox")) {
            System.out.println("Setting Firefox Binary Path to " + firefoxBinaryPath);
            System.setProperty("webdriver.firefox.bin", firefoxBinaryPath);
        }
    }


        @BeforeMethod
    public void startMethod() {
        System.out.println("*** Executing Report Initialization ***");
    }

//    @BeforeMethod
    public void startMethod(Method testMethod) {
        try{
            // --------------------------------E------------------------------------------//

            String tcName = testMethod.getName();

            String testDescription = "Default";

            try {
                Method classMethod = this.getClass().getMethod("getTestScenario", String.class);
                testDescription = (String) classMethod.invoke(this, tcName);
            } catch (Exception e) {
                library.Log.info("== Error in invoking method ==");
                e.printStackTrace();
            }

            category = this.getClass().getCanonicalName().split("testScripts.")[1].split("\\.")[0];

           // Log.info("------------------------------------- " + tcName + " : " + testDescription
             //       + " ---------------------------------------");
            try {
                ExtentTestManager.startTest(tcName, testDescription);
                ExtentTestManager.getTest().assignCategory(category);
            } catch (Exception e) {
                System.out.println("Warning : Unable to write to Extent");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // ---------------------------------------------------------------------------//
    }

        @AfterMethod
    public void updateResults() {
    } // Stub to match Prepaid.testScripts.BaseClass

//    @AfterMethod
    public void updateResults(ITestResult iRes) {
        int res = iRes.getStatus();
        String testName = iRes.getMethod().getMethodName();

        System.out.println("=== Updating Test Result ===");

        {

            WebDriver driver = this.driver;
            //Log.info("Failure --- Capturing screenshot");
            // ---------------------------------------------------------------//
//			if (csr.getCSRStatus())
//				driver = csr.getDriver();
            // ---------------------------------------------------------------//
            try {
                if (driver != null) {
                    File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                    try {
                        File tmpFile = new File("./temp/Screen.png");
                        FileUtils.copyFile(f, tmpFile); // Extent
                        try {
                            Thread.sleep(2000);
                        } catch (Exception e) {
                        }

                    } catch (IOException e) {
                       // Log.info("======== Error in obtaining Screenshot ========");
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
              //  Log.info("======== Error in obtaining screenshot ========\n" + e.getMessage());
            }

            String extScreens = "./" + testName + ".jpg";
            ExtentTestManager.getTest().log(LogStatus.FAIL, "HTML",
                    "There is an error: <br/><br/> " + iRes.getThrowable().getMessage()
                            + " <br/><br/> Error Snapshot : "
                            + ExtentTestManager.getTest().addScreenCapture(extScreens));
        }
        if (res == 1) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "========== Passed: " + testName + " ==========");
        }
        if (res == 3) {
            // ExtentTestManager.getTest().log(LogStatus.SKIP,"========== Skipped:
            // "+testName+" =========="); // can add depends on logic or not executed
        }

        // ==== E ==== //
        try {
            if (!Generic.containsIgnoreCase(driver.toString(), "Firefox")) // If AndroidDriver then get Device details
            {
                if (model == "" || version == "" || resolution == "") {
                    model = (model == "") ? Generic.getDeviceModel(driver) : model;
                    version = (version == "") ? Generic.getAndroidVersion(driver) : version;
                    resolution = (resolution == "") ? Generic.getScreenResolution(driver) : resolution;
//                    appVersion = (appVersion == "") ? Generic.getAppVersion(driver) : appVersion;

                    /*
                     * ExtentManager.getReporter().addSystemInfo("Device Model", model);
                     * ExtentManager.getReporter().addSystemInfo("Android Version", version);
                     * ExtentManager.getReporter().addSystemInfo("Screen Resolution", resolution);
                     * ExtentManager.getReporter().addSystemInfo("App Version", appVersion);
                     */
                }
            }
        } catch (Exception e) {
           // Log.info("== Unable to obtain device details ==\n" + e.getMessage());
        }

        ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
        ExtentManager.getReporter().flush();
        // =========== //
    }

    public void selectQaProgram(WebDriver driver) {
        if (!checkEnv("qa"))
            return;

        library.Log.info("======== Selecting Program based on " + env + " env ========");

        String xp = "//android.widget.TextView[contains(@resource-id,'title_text')]";
        String txt = driver.findElement(By.xpath(xp)).getText();
        System.out.println("Title text : " + txt);

        if (txt.contains("Select Program")) {
            String prgXp = "//*[@text='programName']".replace("programName", programName);
            library.Log.info(
                    "======== Clicking " + programName + " based on " + env + " env in " + txt + " screen========");
            driver.findElement(By.xpath(prgXp)).click();
        }
    }

    public void launchApp() {
        String path = System.getProperty("user.dir")+File.separator+"Downloads";
        Map<String, Object> prefsMap = new HashMap<String, Object>();
        prefsMap.put("profile.default_content_settings.popups", 0);
        prefsMap.put("download.default_directory",path);
        ChromeOptions option = new ChromeOptions();
        option.setExperimentalOption("prefs", prefsMap);
        option.addArguments("--test-type");
        option.addArguments("--disable-extensions");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(option);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//        driver.get(url);
        driver.manage().window().maximize();
    }



    // Stub method mainly used to match BaseTest2 with Prepaid.testScripts.BaseClass
    public void launchApp(String packageName, String appActivity, String udid) {
        launchApp();
    }

    /**
     * Returns the ChromeDriver Absolute Executable Path corresponding to the Chrome
     * App Version present in the device If unable to map to a version "builtin" is
     * returned , i.e use the ChromeDriver version that comes built in with Appium
     * desktop
     *
     * Uses getChromeDriverExecutableVersion Make sure corresponding version folders
     * are present under ./ChromeDriverExecutables
     *
     * @param udid
     * @return
     * @see //Ex : ./ChromeDriverExecutables/2.18/chromedriver.exe
     */
    public String appiumChromeDriverExecutablePath(String udid) {
        try {
            // sString chromePkgName="com.android.chrome";
            String chromeExecutableVersionPath = "ChromeDriverExecutables/" + getChromeDriverExecutableVersion(udid)
                    + "/chromedriver.exe"; // Ex : ./ChromeDriverExecutables/2.18/chromedriver.exe

            chromeExecutableVersionPath = System.getProperty("os.name").contains("Mac")
                    ? chromeExecutableVersionPath.replace(".exe", "")
                    : chromeExecutableVersionPath; // Trim .exe for Mac

            System.out.println("Relative Path for ChromeDriverExecutable : " + chromeExecutableVersionPath);

            if (chromeExecutableVersionPath.contains("builtin")) {
                System.out.println("ChromeDriverExecutable not found for " + udid + ", using Appium builtin");
                return "builtin";
            } else
                return new File(chromeExecutableVersionPath).getAbsolutePath();
        } catch (Exception e) {
            return "builtin";
        }
    }

    /**
     *
     * Returns the chrome executable version corresponding to the chromeAppVersion
     * of the Chrome Browser App in the mobile "builtin" version means use the
     * chrome executable that is bundled with Appium Desktop.
     *
     * {@link //https://appium.io/docs/en/writing-running-appium/web/chromedriver/}
     *
     *
     * @param chromeAppVersion in the device
     * @return ChromeDriver version corresponding to the chromeAppVersion //
     * @see //Upgrade to Appium 1.8.1 to use the chromedriverExecutableDir &
     *      chromedriverChromeMappingFile Android Capability
     * @deprecated Dynamic mapping to chrome app version unreliable, Use
     *             chromeDriverExecutableVersion()
     */
    public String getChromeExecutableVersion(String chromeAppVersion) {

        if (true)
            return "2.28";

        try {
            double chromeAppVer = Double.parseDouble(chromeAppVersion.split("\\.")[0]);

            System.out.println("Chrome App Version on Device : " + chromeAppVer);

            if (chromeAppVer < 47)
                return "2.18";
            if (chromeAppVer <= 54)
                return "2.28"; // <=55
            if (chromeAppVer > 58)
                return "2.38";
        } catch (Exception e) {
            System.err.println("-- Unable to get Chrome Executable version --");
            e.printStackTrace();
        }
        // ... Add based on future Chrome App versions 7 Check ... //

        return "2.28"; // builtin // Use BuiltIn ChromeDriver version bundled with Appium
    }

    /**
     * Retrieves the ChromeDriverExecutableVersion from config.xlsx
     *
     *
     * @param udid
     * @return chromeDriverExecutableVersion corresponding to the udid
     */
    public String getChromeDriverExecutableVersion(String udid) {
        // Get version corresponding to the udid from config file
        // If no version found return "chromeDriverExecutableVersionNotFound" , Print
        // Warning at Capabilities & Launch

        String sheet = "Modules", version = "", tcRowVal;

        int rc, udidColumn = 9, versionColumn = 11;

        try {
            rc = ExcelLibrary.getExcelRowCount(configXLPath, sheet);

            for (int i = 0; i <= rc; i++) {
                tcRowVal = ExcelLibrary.getExcelData(configXLPath, sheet, i, udidColumn);
                if (tcRowVal.equals(udid)) {
                    version = ExcelLibrary.getExcelData(configXLPath, sheet, i, versionColumn);
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving Device model for " + udid + '\n');
            e.printStackTrace();
        }

        return version.length() > 2 ? version : "builtin";

    }



    public String getCompleteClassName() {
        return className;
    }

    public String getClassName() {
        return testScenarioName;
    }

    //
    public static boolean checkEnv(String environment) {
        return env.contains(environment);
    }

    public AndroidDriver getDriver() {
        return (AndroidDriver) driver;
    }

    // ==========================Skip Status====================================//
    public void setSkipStatus(WebDriver driver, boolean status) {
        skipStatus.put(getUdid(driver), status);
    }

    public boolean getSkipStatus(WebDriver driver) {
        return skipStatus.get(getUdid(driver));
    }
    // =========================================================================//

    public String getUdid(WebDriver driver) {
        if (!Generic.containsIgnoreCase(driver.toString(), "Android"))
            return "";

        return ((String) ((AndroidDriver) driver).getCapabilities().getCapability(MobileCapabilityType.UDID));

        // return
        // ((String)((AndroidDriver)driver).getCapabilities().getCapability("deviceName"));
    }

    // @AfterMethod
    public void tear() {
        Generic.resetPopups();
        if (driver != null)
            driver.quit();

        /*
         * try{ Runtime.getRuntime().
         * exec("adb shell am start com.enstage.wibmo.staging.hdfc/com.enstage.wibmo.main.MainActivity"
         * ); }catch(Exception e){System.out.println("Runtime!");}
         */
    }


    public static void setWebDriverProperty() {
        setFirefoxBinary();

        String geckoExecutablePath = "./config/geckodriver"
                + (System.getProperty("os.name").contains("Mac") ? "" : ".exe");
        String chromeExecutablePath = "./config/chromedriver"
                + (System.getProperty("os.name").contains("Mac") ? "" : ".exe");

        System.out.println("Setting WebDriver properties");
        // System.setProperty("webdriver.firefox.marionette",geckoExecutablePath);
        System.setProperty("webdriver.gecko.driver", geckoExecutablePath);
        System.setProperty("webdriver.chrome.driver", chromeExecutablePath);
    }




    public boolean checkUDIDConnected(String udid) {
        try {
            return (Generic.isIos(udid)) ? Generic.execCmd("xcrun instruments -s devices").contains(udid)
                    : Generic.execCmd("adb devices").contains(udid); // sca
        } catch (Exception e) {
            System.err.println("Error while checking for connected UDID " + udid + '\n' + e.getMessage());
            return false;
        }
    }



    public void handleColorOS(WebDriver driver) {
        if (getUdid(driver).equals("SK55NZ7H99999999")) // Oppo
        {
            System.out.println("Setting Idle timeout to 0 ms");
            ((AndroidDriver) driver).setSetting(Setting.WAIT_FOR_IDLE_TIMEOUT, 0); // or 0
        }
    }

    public static void grantAppRuntimePermissions(WebDriver driver) // Stub to match Prepaid.testScripts.BaseClass
    {
    }

    public String getDeviceModel(WebDriver driver) {
        String udid = getUdid(driver), sheet = "Modules", deviceModel = "", tcRowVal;

        int rc, udidColumn = 9, deviceModelColumn = 10;

        if (udidModel.get(udid) != null)
            return udidModel.get(udid);

        try {
            rc = ExcelLibrary.getExcelRowCount(configXLPath, sheet);

            for (int i = 0; i <= rc; i++) {
                tcRowVal = ExcelLibrary.getExcelData(configXLPath, sheet, i, udidColumn);
                if (tcRowVal.equals(udid)) {
                    deviceModel = ExcelLibrary.getExcelData(configXLPath, sheet, i, deviceModelColumn);
                    udidModel.put(udid, deviceModel);
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving Device model for " + udid + '\n');
            e.printStackTrace();
        }

        return deviceModel;
    }

    public synchronized int getUiAuto2Port(String udid) {
        long x = 1023;
        long y = 65535;

        long uiAuto2Port;

        Random r = new Random();
        long number = x + ((long) (r.nextDouble() * (y - x)));

        System.out.println("UIAutomator2 port for " + udid + " : " + number);
        return (int) number;
    }

    /**
     * @author aravindanath
     * @param udid
     * @return
     */

    public String getPlatformVersion(String udid) {

        String path = "./config/" + env + '/' + "Devices.ini";

        Ini ini = null;
        try {
            ini = new Ini(new File(path));
        } catch (IOException e) {
            System.err.println("Devices.ini file not found");
            System.exit(1);
        }

        String value = ini.get(udid, "platformVersion");
        if ((value == null)) {
            System.err.println("Devices.ini file not found");
            System.exit(1);
        }
        return value;
    }

    /**
     * @author aravindanath
     * @param udid
     * @return
     */
    public String getDeviceName(String udid) {

        String path = "./config/" + env + '/' + "Devices.ini";

        Ini ini = null;
        try {
            ini = new Ini(new File(path));
        } catch (IOException e) {
            System.err.println("Device name not found for " + udid);
            System.exit(0);
        }

        String value = ini.get(udid, "deviceName");
        if ((value == null)) {
            System.err.println("Device name not found for " + udid);
            System.exit(0);
        }

        return value;
    }

    /**
     * Handle Alerts generated from previous TestCases , To be used under After
     * Class for IOS Only
     */
    public void handleIOSDelayedAlert() {

        if (!Generic.isIos(driver))
            return;

        try {

            String alertChkPredicate = "(name contains 'battery' or name='Ok') and visible=true";

            if (driver.findElements(MobileBy.iOSNsPredicateString(alertChkPredicate)).size() > 1) {
                System.out.println("Handling delayed alert");
                driver.findElement(MobileBy.AccessibilityId("Ok")).click();
            }

        } catch (Exception e) {
            System.err.println("Error in handling delayed alert ");
            e.printStackTrace();
        }

    }

    // @AfterClass Comment this for WebSDK development to prevent multisession
    public void quit() {

        handleIOSDelayedAlert();

        System.out.println("== Logging Out ==");
        //new BasePage(driver).logOut();

        // handleIOSDelayedAlert();

        // DB.closeDB();

        if (Generic.isWebDriver(driver) && driver != null) {
            try {
                driver.close();
                driver.quit();
            } catch (Exception e) {
                System.err.println("WebDriver Close	Error");
            }
            return;
        }

    }

    @AfterClass
    public void killApp() {
        Generic.wait(2);
        System.out.println("Finished the test case execution in a class. Closing the webDriver");
        driver.close();
        driver.quit();

    }


}

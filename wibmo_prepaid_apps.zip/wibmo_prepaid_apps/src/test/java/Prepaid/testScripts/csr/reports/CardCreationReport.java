package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertTrue;

public class CardCreationReport extends BaseTest {
	String last4digit;
	String urn;
	String customerId;
	String product;
	String cardNumber;
	int[] cell = null;
	int activationAmount;
	String clientTxnId;
	String responseDateTime;
	String cardcreationDate;
	String reportDate;
	JSONObject Jsonresponse;
	boolean reporturnvalidation;
	BasePayLoad basePayLoad = new BasePayLoad(driver);
	WebDriverWait wait = new WebDriverWait(driver, 60);
	
		
//	cardNumber = csrbasepage.GetCardNumber(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", "Active");
//	last4digit = Generic.GetLast4DigitCardNumber(cardNumber);
//	cell = excel.SearchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",cardNumber);
//	urn = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 2);
//	customerId = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 2);
//	product = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", 3, 3);
//	CSRBasePage csrbasepage = new CSRBasePage();
	
	//Validating All active Cards in activation/card Creation report
	@Test()
	public void activationReport(){		
		try{	
		Object[][] activeCards = DataProviderUtility.GetData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails");
		System.out.println("activeCards.length: "+activeCards.length);
		
		initBrowser(BROWSER, "ExternalReports");
		AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
		enhancedReports.selectReport("Card Creation Report");
		
		for(int i=0; i<activeCards.length;i++){
			System.out.println("activeCards[0].length: "+activeCards[0].length);
					if(activeCards[i][4].toString().equalsIgnoreCase("Active")){
						//last4digits
						last4digit = activeCards[i][1].toString();
						//urn
						urn = activeCards[i][2].toString();
						Log.info( "#-------------------------------------------------------------------------------------------------------------#");
						Log.info("**************In External Report to validate the created card in activation report**************");
						Log.info( "Browser stated and Application launched");
						//Json activation response
						String response = activeCards[i][6].toString();
						//parsing response String to JSON response
						Jsonresponse = basePayLoad.ParseStringToJSON(response);
						//Fetching JSON response values like Card Limit, URN, Card Last4Digits, TxnId, Creation Date
						activationAmount = Integer.parseInt(Jsonresponse.get("loadAmount").toString());
						int cardlimit = activationAmount/100;
//						cardlimit = Double.parseDouble(String.format("%.2f", cardlimit));
						product = Jsonresponse.get("cardProfileId").toString();		
						clientTxnId = Jsonresponse.get("clientTxnId").toString();
						responseDateTime = Jsonresponse.get("responseDateTime").toString();
						cardcreationDate = Generic.reportFormattedDate(responseDateTime, "mmddyyyy");
						reportDate = Generic.formatDate(responseDateTime, "mmddyyyy");
						//Generating Report for the required date range
						enhancedReports.generateReport(reportDate, reportDate);	
						WebDriverWait wait = new WebDriverWait(driver, 60000);
						wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
						
						//Navigating to Default Page Number One
						driver.findElement(By.id("gotoPage")).clear();
						driver.findElement(By.id("gotoPage")).sendKeys("1");
						driver.findElement(By.name("goto")).click();
						//Validating if URN exist in the report Open page if not then searching in rest report pages
						System.out.println(driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty());
						if(driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty()){
							do{
								if(driver.findElement(By.xpath("//input[@name='next']")).isEnabled() && !reporturnvalidation){
									driver.findElement(By.xpath("//input[@name='next']")).click();
									}else{
										break;
										}	
								}while(reporturnvalidation = !driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty());
							}else{
								reporturnvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed();
								Log.info(urn+" URN is populating in report "+reporturnvalidation);
							}
						//
						if(reporturnvalidation){
							boolean reportcard4digitvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4digit+"')]")).isDisplayed();
							Log.info(last4digit+" cardLast4Digit is populating in report "+reportcard4digitvalidation);
							boolean reportTxnIdvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+clientTxnId+"')]")).isDisplayed();
							Log.info(clientTxnId+" clientTxnId is populating in report "+reportTxnIdvalidation);
							boolean reportcardlimitvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+cardlimit+"')]")).isDisplayed();
							Log.info(cardlimit+" Card Limit is populating in report "+reportcardlimitvalidation);
							boolean reportProductvalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[2]")).getText().isEmpty();
							Log.info("Card Product is populating in report "+reportProductvalidation);
							boolean reportCardHolderNamevalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[3]")).getText().isEmpty();
							Log.info("Card Holder Name is populating in report "+reportCardHolderNamevalidation);
							boolean reportEntityIdvalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[5]")).getText().isEmpty();
							Log.info("Card Entity ID is populating in report "+reportEntityIdvalidation);
							assertTrue(reporturnvalidation&&reportcard4digitvalidation&&reportTxnIdvalidation&&reportcardlimitvalidation&&reportProductvalidation&&reportCardHolderNamevalidation&&reportEntityIdvalidation);
							Log.info( "reporturnvalidation: "+reporturnvalidation+" ;reportcard4digitvalidation: "+reportcard4digitvalidation+" ;reportTxnIdvalidation: "+reportTxnIdvalidation+" ;reportcardlimitvalidation: "+reportcardlimitvalidation+" ;reportProductvalidation: "+reportProductvalidation+" ;reportCardHolderNamevalidation: "+reportCardHolderNamevalidation+" ;reportEntityIdvalidation: "+reportEntityIdvalidation);
							if (reporturnvalidation&&reportcard4digitvalidation&&reportTxnIdvalidation&&reportcardlimitvalidation&&reportProductvalidation&&reportCardHolderNamevalidation&&reportEntityIdvalidation) {
								Log.pass("CSR Card Activation Report Validation is Successfull");
							} else {
								Log.fail("CSR Card Activation Report Validation is Not Successfull");
							}
						} else {
							Log.fail("CSR Card Activation Report Validation is Not Successfull");
						}
					}
				}
		driver.close();
		}
		catch(Exception e){
			e.printStackTrace();
			Log.error( "Exception is "+e);
			Log.fail( "Card Creation Report Validation is unsuccessful");
		}
	}
	
	
	
//	//Downloading activation/Card Creation report as excel or other format and validating the Product Summary
	@Test()
	public void reportDownloadandProductSummaryValidation(){
		File reportFilePath;
		long fileSize;
		boolean pdfFileSizeValidation = false;
		boolean xlsxFileSizeValidation = false;
		boolean summaryValidationInExport = false;
		
		try{
			Log.info( "Browser stated and Application launched");
			initBrowser(BROWSER, "ExternalReports");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info("**************In External Report to validate the created card in activation report**************");
			enhancedReports.selectReport("Card Creation Report");
			//Generating Report for the required date range
			Log.info( "Generating Report for Today -90 days From & To Date: "+Generic.getPastOrFutureDate("YYYY-MM-dd", -90)+" & "+Generic.currentDate("YYYY-MM-dd"));
			enhancedReports.generateReport(Generic.getPastOrFutureDate("YYYY-MM-dd", -90), Generic.currentDate("YYYY-MM-dd"));
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(enhancedReports.loadingDialog));				//(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			
//			enhancedReports.lastPage.click();
//			List<WebElement> w = driver.findElements(By.xpath("//table[@id='__bookmark_3']//tr"));
//			assertEquals(driver.findElement(By.xpath("//table[@id='__bookmark_3']//tr[w]//td[1]")).getText(), );			
			
			Log.info( "Fetching Product wise summary details from Activation Report Page");
			//Getting Activation Summary Details
			Object[][] productSummary = enhancedReports.fetchReportsCardsSummary();
			Log.info( "Exporting all pages report as xlsx format");
			//Export report
			enhancedReports.exportReports("XLSX", "All Pages", null);
			//waiting for file download and getting file name
			String xlsxfileName = Generic.waitForFileToDownload("Aero_Card_Creation");
			Log.info( "Report File Downloaded Successfully");
			//validate File size id not Zero
			reportFilePath = new File(System.getProperty("user.dir")+"\\Downloads\\"+xlsxfileName);
			fileSize = reportFilePath.length();
			Log.info( "Downloaded File Size is: "+fileSize);
			xlsxFileSizeValidation = (fileSize!=0);
			
			String[] summaryHeader = {"Product", "count", "Card Limit"};
			assertTrue(!xlsxfileName.isEmpty());
			String excelReportPath = System.getProperty("user.dir")+"\\Downloads\\"+xlsxfileName;
			String sheetName = ExcelLibrary.getActiveExcelSheetName(excelReportPath);
			Log.info( "Validation of Product wise Summary wrt downloaded report data");
			for(int i=0, r=1; i<productSummary.length; i++, r++){
				for(int c=0; c<summaryHeader.length;c++){
					int[] cell = ExcelLibrary.searchTextFindCellAddress(excelReportPath, sheetName, summaryHeader[c]);
					Log.info( "Summary validation wrt to web report and exported data: "+ExcelLibrary.getExcelData(excelReportPath, sheetName, cell[0]+r, cell[1])+" == "+productSummary[i][c]);
					summaryValidationInExport = ExcelLibrary.getExcelData(excelReportPath, sheetName, cell[0]+r, cell[1]).equalsIgnoreCase(productSummary[i][c].toString());
					}
				}	
			
			
			Log.info( "#-------------------------------------------------------------------------------------------------------------#");
			Log.info( "Validating Export of PDF file format report");
			enhancedReports.exportReports("PDF", "All Pages", null);
			//waiting for file download and getting file name			
			String pdffile= Generic.waitForFileToDownload("Aero_Card_Creation");
			Log.info( "Report File Downloaded Successfully");
			reportFilePath = new File(System.getProperty("user.dir")+"\\Downloads\\"+pdffile);
			fileSize = reportFilePath.length();
			Log.info( "Downloaded File Size is: "+fileSize);
			pdfFileSizeValidation = (fileSize!=0);
			Log.info( "summaryValidationInExport: "+summaryValidationInExport+" ;xlsxFileSizeValidation: "+xlsxFileSizeValidation+" ;pdfFileSizeValidation: "+pdfFileSizeValidation);
			if(summaryValidationInExport&&xlsxFileSizeValidation&&pdfFileSizeValidation){
				Log.pass( "XLSX and PDF file Download and Summary validation is Successfull");
			}else{
				Log.fail( "XLSX and PDF file Download and Summary validation is Unsuccessfull");
			}
			driver.close();
			}
			catch(Exception e){
				e.printStackTrace();
				Log.error( "Exception is "+e);
				Log.fail( "Card Creation Export Report is unsuccessful");
			}		
	}
}

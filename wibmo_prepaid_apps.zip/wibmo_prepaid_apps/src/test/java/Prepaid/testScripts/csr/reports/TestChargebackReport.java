package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;

//@param HashMap authorizationDetails : urn, cardLast4digit, authDate, authAmount, MCC Amount, crossCurrencyFee, Auth Available to settle, Approval Code, RRN, Currency Code, Message, MCC Code
public class TestChargebackReport extends BaseTest {
	
//	Validating Chargeback Report after executing Chargeback cases
	@Test(description="Chargeback Report", dataProvider="ChargebackReport", dataProviderClass = DataProviderUtility.class)
	public void chargebackReportValidation(String chargebackDetails){
		try{
			HashMap<String, String> chargebackDetail =  Generic.parseStringToHashmap(chargebackDetails);

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Chargeback Report");
			
			String chargeBackDate = chargebackDetail.get("Chargeback Request Date");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(chargeBackDate, formatter);
			// 2010-01-02
			chargeBackDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			enhancedReports.generateReport(chargeBackDate, chargeBackDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			boolean reportValidation = enhancedReports.validateChargebackReport(chargebackDetail);
			
			if(reportValidation){
				Log.pass( "Chargeback report validation is successfull Chargeback details are populating in report");
			}else{
				Log.fail( "Chargeback report validation is not successfull Chargeback details are not populating in report");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Chargeback Report validation is unsuccessfull");
		}
	}
	
	
	@Test()
	public void chargeBackReportDownload(){
		try{
			Object[][] chargeBackDetails = DataProviderUtility.GetData(System.getProperty("user.dir")+TRANSACTION_XLSX_FILE_PATH, "ChargebackReport");
			String firstchargeBackDetail = chargeBackDetails[1][0].toString();
			HashMap<String, String> firstchargeBackDetails =  Generic.parseStringToHashmap(firstchargeBackDetail);
			
			String lastchargeBackDetail = chargeBackDetails[chargeBackDetails.length-1][0].toString();
			HashMap<String, String> lastchargeBackDetails =  Generic.parseStringToHashmap(lastchargeBackDetail);
			

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info( "Navigating to Authorization Report");
			enhancedReports.selectReport("Chargeback Report");
			
			String string = firstchargeBackDetails.get("Chargeback Request Date");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String fromDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			
			string = lastchargeBackDetails.get("Chargeback Request Date");
			date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String toDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			Log.info( "Loading Report for following dates "+fromDate+" To "+toDate);
			enhancedReports.generateReport(fromDate, toDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			Log.info( "Downloading Report as excel .xlsx format");
			enhancedReports.exportReports("XLSX", "All Pages", "");
			if(Generic.waitForFileToDownload("ChargeBack_Report_HDFC_v1")!= null){
				Log.pass( "Report Exported Successfully");
			}else{
				Log.fail( "Report Exported Failed");
			}
			Generic.MoveFile("Chargeback_Report_"+fromDate+"_to_"+toDate);
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
		}
	}
}

package Prepaid.testScripts.csr;

import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import Prepaid.pageRepo.transactions.ProcessExceptionItemsPage;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;


import java.util.HashMap;

import static Prepaid.testScripts.kotak.BaseTest.reports;

public class ExceptionClearing extends BaseTest{
	
	public static PrepaidDetailsPage pdp;	
	public static ProcessExceptionItemsPage processException;	
	String settlementId = null, authorizedAmount= null, authorizedDate = null, arn = null,
	authCode = null, errorMsg = null, processedCode= null, cardNumber = null, authorizationId = null, 
	settledAmount = null, settlementEvent = null;
	String transactionDestination;
	
	@Test(description="ExceptionClearing", dataProvider="ExceptionClearing", dataProviderClass = DataProviderUtility.class)
	public void exceptionClearing(String authorizationDetails, String settlementDetails){
		try{			
			HashMap<String, String> authorizationDetail = Generic.parseStringToHashmap(authorizationDetails);
			HashMap<String, String> settlementDetail = Generic.parseStringToHashmap(settlementDetails);
			cardNumber = authorizationDetail.get("Card Number");
					
			Log.info("Authorization Details are "+authorizationDetail);
			Log.info("Settlement Details are "+settlementDetail);
			
			
			settlementId = settlementDetail.get("settlementRefNumber");			
			authorizationId = settlementDetail.get("authorizationID");
			settledAmount = settlementDetail.get("destinationAmount");
			
			authorizedAmount = authorizationDetail.get("Authorization Amount");
			authorizedAmount = String.valueOf(Double.parseDouble(authorizedAmount)/100.00);
			authorizedDate = authorizationDetail.get("Transaction Date");
			arn = settlementDetail.get("acquirerRefNumber");
			authCode = authorizationDetail.get("Approval Code");
			errorMsg = settlementDetail.get("Error Message");
			processedCode = settlementDetail.get("Processed Flag");
			settlementEvent = settlementDetail.get("Settlement Type");
				
			//Launching CSR Web Application
			Log.info("Launching CSR Web Application");
			initBrowser(BROWSER, "CSR");
			processException = PageFactory.initElements(driver, ProcessExceptionItemsPage.class);
			pdp = PageFactory.initElements(driver, PrepaidDetailsPage.class);
			String[] Credentials = getAppCredentials("CSR");
			LoginPage csrLogin = new LoginPage(driver);
			csrLogin.csrLogin(Credentials[0],Credentials[1]); // Username, Password
//			basepage.driver = driver;
			Log.info( "As Exception Clearing is Successfull validation of Base I and Base II");
			pdp.checkPrepaidDetails(cardNumber);
			//Fetching card baseI and baseII details before processing exception items 
			String[] preExeptionBaseValues = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
			pdp.back.click();
			Log.info("Search For Card in Exception: "+cardNumber);	
			processException.searchForExceptionItems(cardNumber);
			Log.info("View the Exception Transaction: "+settlementId);
			processException.viewExceptionItems(settlementId);
			Log.info("Validate the exception transaction details");
			Boolean validation = processException.validateExceptionItem(cardNumber, settlementId, settledAmount, authorizedAmount, 
					authorizedDate, arn, authCode, errorMsg, processedCode);
			Log.info("Process the Exceptioned Transaction");
			switch(settlementEvent){
			case "P1":
			case "L1":
			case "L2":
			case "L3":
			case "R1":
			case "R2":
				transactionDestination = "Write Off";
				break;
			default:
				transactionDestination = "Accept";
				break;
			}
			Boolean Processed = processException.processExceptionItem(authorizationId, transactionDestination);
			Log.info("validation flag is "+validation+" Processed flag is "+Processed);
			if(validation && Processed){
				Log.pass("Exception Clearing is Successfull");
				Log.info( "As Exception Clearing is Successfull validation of Base I and Base II");
				pdp.checkPrepaidDetails(cardNumber);
				//Fetching card baseI and baseII details before processing exception items 
				String[] postExeptionClearBaseValues = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
				pdp.pre_post_Transaction_BaseIBaseIIValidation(preExeptionBaseValues, postExeptionClearBaseValues, Double.parseDouble(authorizedAmount), "Credit");		
			}else{
				Log.fail("Exception Clearing is Unsuccessfull");
			}			
		}
		catch(Exception e){
			e.printStackTrace();
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Exception Clearing is Unsuccessfull");
		}	
	}		
//	@AfterClass
//	public void clearExcelData()  
//	{  
//	    int r = excel.getNoOfRowsInSheet(System.getProperty("user.dir")+authorizationsTestData, "Exception Clearing");
//	    Sheet sheet = excel.getSheet(System.getProperty("user.dir")+authorizationsTestData, "Exception Clearing");
//	    for(int i =1; i<r; i++){
//	    	Row row = sheet.getRow(i);
//	    	sheet.removeRow(row);
//	    	sheet.shiftRows(r-1, r, -1);
//	    }
//	}  
}
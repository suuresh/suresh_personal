package Prepaid.testScripts.csr.settlements;

import Prepaid.pageRepo.transactions.SettlementPage;
import Prepaid.testScripts.api.APIBaseTest;
import library.DataProviderUtility;
import org.testng.annotations.Test;


public class Bulk_Settlement_File_Generation extends APIBaseTest {
	@Test(description="BulkSettlement", dataProvider="BulkSettlement", dataProviderClass = DataProviderUtility.class)
	public void Test(String cardNumber, String approvalCode,String mcc, String settlementType, String transactionAmount, String acquiringInstution, String transactionDate, String mccBuffer, String  crossCurrencyFee) {	
		
	SettlementPage settlement= new SettlementPage(driver);
	
	String[] transactionDetails = {cardNumber, approvalCode, mcc, settlementType, transactionAmount, acquiringInstution, transactionDate, approvalCode, mccBuffer, crossCurrencyFee};

	Object[][] settlementCardDetails = {transactionDetails};
	
	String settlementFileName = settlement.GenerateSettlementFile(true, settlementCardDetails);
	
	System.out.println("Settlement Files: "+settlementFileName);
	}
}
package Prepaid.testScripts.csr.settlements;

import Prepaid.pageRepo.transactions.AuthorizationJSPPage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.pageRepo.transactions.ChargeBackPage;
import Prepaid.pageRepo.transactions.SettlementPage;
import Prepaid.testScripts.csr.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
//import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.testng.Assert.assertTrue;

public class AuthSettlements extends BaseTest {

	public static WebDriver csrDriver;
	public static WebDriver eodDriver;
	public static WebDriver settlementDriver;

	public int debitSettlementAmount;
	public int creditSettlementAmount;
	public int debitReversalSettlementAmount;
	public int creditReversalSettlementAmount;

	public static PrepaidDetailsPage pdp;

	//Card Number, Expiry, Approval Code, MCC, Authorization RRN, Authorization Amount, Authorization Currency Code, Authorization RRN, Response Code, Transaction Date, MCC Buffer Charges, Cross Currency Fee}
	HashMap<String, String> transactionDetails = new HashMap<String, String>();

	boolean settlementFileGenerated = false, settlementFileUpload = false, settlementProcessed = false;
	public HashMap<String, String> settledApprovalCode = new HashMap<String, String>();
	String[] cardBaseDetails;
	HashMap<String, String> settlementDetails = new HashMap<String, String>();
	HashMap<String, String>  authorizationDetails = new HashMap<String, String>();
	String secondPresentment;
	int cellRowNumber;
	String  authrrn;
	List<String> settlementFileName;

	@Test(description="Settlements", dataProvider="Settlements", dataProviderClass = DataProviderUtility.class)
	public void Settlement(String cardNumber, String approvalCode,String mcc, String settlementType,
						   String transactionAmount, String acquiringInstution, String transactionDate,
						   String mccBuffer, String crossCurrencyFee, String testCaseID, String testScenario,
						   String debitPrimaryCondition, String debitSecondaryCondition,
						   String creditPrimaryCondition, String creditSecondaryCondition, String debitRPrimaryCondition,
						   String debitRSecondaryCondition, String creditRPrimaryCondition, String creditRSecondaryCondition,
						   String auth_precondition, String settlementProcessStatus, String secondPresentmentProcessStatus,
						   String gtaqEventExpectedStatus){
		try{
			Log.info("Test Execution for settlement :"+settlementType+" "+testScenario);
			secondPresentment = settlementType;
			settlementType = settlementType.substring(0, 2);
			// Check if Authorization Approval code is available else triggering an authorization 
			if(cardNumber.isEmpty() || approvalCode.isEmpty()){
				AuthorizationJSPPage authorization = new AuthorizationJSPPage(driver);
				//transactionDetails  = {cardNumber, approvalCode, mcc, transactionAmountDE4, acquiringInstutionD19, responseCode, transactionDate}
				transactionDetails = authorization.authorize("visa", "ECOM", "Transaction",cardNumber, transactionAmount, transactionAmount, "", mcc, "1", "2", acquiringInstution, "", acquiringInstution, acquiringInstution, acquiringInstution, "0", "0", "1", "0");
				if(cardNumber.isEmpty()){
					cardNumber = transactionDetails.get("Card Number");
				}else{
					transactionDetails.put("Card Number", cardNumber);
				}
				approvalCode = transactionDetails.get("Approval Code");
				transactionDate = transactionDetails.get("Transaction Date");
				mccBuffer = transactionDetails.get("MCC Buffer Charges");
				crossCurrencyFee = transactionDetails.get("Cross Currency Fee");
				authrrn = transactionDetails.get("Authorization RRN");
			}

			// Debit / Credit Settlement Process

			String[] authCardDetails = {cardNumber, approvalCode, mcc, settlementType, transactionAmount, acquiringInstution, transactionDate};
			Object[][] settlementCardDetails = {authCardDetails}; //ExcelLibrary.GetSheetData(authorizationsTestData, "AuthSettelement");

			//Launching CSR Web Application
			csrDriver = initBrowser("chrome", "csr");
			String csrWindow = csrDriver.getWindowHandle();
			pdp = new PrepaidDetailsPage(csrDriver, BANK);
			String[] credentials = getAppCredentials("csr");
			LoginPage csrlp = new LoginPage(csrDriver);
			csrlp.csrLogin(credentials[0],credentials[1]); // Username, Password
			pdp.checkPrepaidDetails(cardNumber);

			//Launching Settlement  Web Application
			settlementDriver = initBrowser("chrome", "Settlement");
			String settlementWindow = settlementDriver.getWindowHandle();
			// Settlement Process started
			SettlementPage settlement= new SettlementPage(settlementDriver);
			//cardNumber, approvalCode, mcc, settlement type, transactionAmountDE4, acquiringInstutionD19
			settlementFileName = settlement.settlementType(settlementType, approvalCode, cardNumber, mcc, transactionAmount, acquiringInstution, transactionDate, debitPrimaryCondition,debitSecondaryCondition, creditPrimaryCondition, creditSecondaryCondition, debitRPrimaryCondition,debitRSecondaryCondition, creditRPrimaryCondition, creditRSecondaryCondition, mccBuffer, crossCurrencyFee);
			Log.info("Settlement File :"+settlementFileName);
			List<String> sendToIBSRunStatus = new ArrayList<String>();
			if(!settlementFileName.isEmpty()) {
				settlementFileGenerated=true;
			}

			//Launching EOD Web Application
			eodDriver = initBrowser("chrome", "eod");
			String eodWindow = eodDriver.getWindowHandle();
			EOD_Login_Page eod= new EOD_Login_Page(eodDriver);
			String [] eodCred = getAppCredentials("eod");
			eod.eodLogin(eodCred[0], eodCred[1]);
			eod.selectBank(BANK);

			for(int s=0; s<settlementFileName.size();s++) {
				if (settlementFileName.get(s) == null) {
					continue;
				}
				//Fetching BaseI and BaseII Details before to authorization
//				driver = csrDriver;
				csrDriver.switchTo().window(csrWindow);
				cardBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
				settlementDriver.switchTo().window(settlementWindow);
				settlementDriver.navigate().refresh();
//				basepage.driver = settlementDriver;
				settlementFileUpload = settlement.UploadFileUsingSendKeys(settlementFileName.get(s));
				assertTrue(settlementFileUpload, "Settlement File Upload is Successful");

				if (settlementFileUpload) {
					Log.pass("Settelement file is uploaded successfully");
					settlementFileUpload = false;
				}else{
					Log.fail("Settelement file is upload un-successfully");
				}


				eodDriver.switchTo().window(eodWindow);
				String fileHandlerRunStatus = eod.wibmoExecuteEODJob("File Handler");
				if (fileHandlerRunStatus.equalsIgnoreCase("SUCCESS")) {
					sendToIBSRunStatus.add(eod.wibmoExecuteEODJob("Send To IBS"));
				} else {
					sendToIBSRunStatus.add("Job Not Triggred");
				}
				driver = csrDriver;
				if (sendToIBSRunStatus.contains("SUCCESS")) {
					pdp.refresh.click();
					Generic.wait(3);
					settlementType = settlementFileName.get(s).substring(0, 2);
					pdp.validateBaseIBaseIIPostSettlement(settlementType, cardNumber, cardBaseDetails, settledApprovalCode, approvalCode, debitSettlementAmount, creditSettlementAmount, debitReversalSettlementAmount, creditReversalSettlementAmount);
					settlementDetails = pdp.fetchSettlementDetails(approvalCode, settledApprovalCode, settlementType);
					pdp.validateSettlement(cardNumber, approvalCode, settlementType, debitSettlementAmount, creditSettlementAmount, debitReversalSettlementAmount, creditReversalSettlementAmount);
					settlementProcessed = true;
				} else {
					Log.info("Send To IBS Run Status: "+sendToIBSRunStatus);
					Log.fail( "Send To IBS Job Status is Faliure");
					Log.fail( "File Handler Job is Faliure as "+fileHandlerRunStatus);
				}
			}
			if(settlementProcessed){
				Log.pass("Settlement processing is successful");
				Log.info("validating Settlement process status and auth status");
				pdp.validateSettlementProcessStatus(approvalCode, settlementType, settlementProcessStatus, transactionDetails, settlementDetails);
				//Fetching Settled Authorization details for Report Validations
				authrrn = csrDriver.findElement(By.xpath(pdp.authRequestTag+"//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[5]")).getText().trim();
				authorizationDetails= pdp.fetchAuthorizationDetails(authrrn);
				cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", 0);
				ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", cellRowNumber, 0, authorizationDetails.toString());
				if(authorizationDetails.get("Auth Status").equalsIgnoreCase("Closed")){
					Log.pass("Authorization is closed successfully");
					cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", 0);
					ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", cellRowNumber, 0, settlementDetails.toString());
				}else{
					Log.info("### Authorization status is "+authorizationDetails.get("Auth Status"));
				}
			}else{
				Log.fail("Settlement processing is unsuccessful");
			}

			HashMap<String, String> chargebackDetails;
			String secondPurdebitCondition ="";
			if(debitSecondaryCondition.contains("Second Presentment")){
				HashMap<String, String> secondPresentmentCondition =  Generic.parseStringToHashmap(debitSecondaryCondition);
				secondPurdebitCondition = secondPresentmentCondition.get("value1");
				debitSecondaryCondition = secondPresentmentCondition.get("value0");
				if(secondPurdebitCondition == null){
					secondPurdebitCondition="";
				}
				Log.info("second Presentment Condition: "+secondPurdebitCondition+", SecondaryCondition: "+debitSecondaryCondition);
			}
			ChargeBackPage chargeback = new ChargeBackPage(csrDriver);

			if(debitPrimaryCondition.contains("Chargeback") || debitSecondaryCondition.equalsIgnoreCase("Chargeback")){
				Log.info("Performing Chargeback Request scenario");
				//Fetching card baseI and baseII details before raising chargeback
				cardBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
				pdp.back.click();

				Object[] dateRange = {Generic.currentDate("dd/MM/YYYY"), Generic.getPastOrFutureDate("dd/MM/YYYY", -10)};
				settlementDetails = chargeback.raiseChargebackRequest(cardNumber, dateRange, settlementDetails);

				pdp.checkPrepaidDetails(cardNumber);
				if(!(debitSecondaryCondition.equalsIgnoreCase("Credit Chargeback") || debitSecondaryCondition.equalsIgnoreCase("Second Presentment")) && Boolean.parseBoolean(settlementDetails.get("Chargeback Processed"))){
					String[] postChargebackRequest = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
					pdp.pre_post_Transaction_BaseIBaseIIValidation(cardBaseDetails, postChargebackRequest, 0, "");
					chargebackDetails = pdp.fetchChargebackDetails(approvalCode, "Chargeback Request");
					Log.info("Updating Chargeback details to excel to validate chargeback report");
					cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "ChargebackReport", 0);
					ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "ChargebackReport", cellRowNumber, 0, chargebackDetails.toString());
				}
			}

			boolean chargebackCredited = false;
			String[] postChargebackBaseDetails = null;
			if(((debitSecondaryCondition.equalsIgnoreCase("Credit Chargeback") || debitSecondaryCondition.equalsIgnoreCase("Second Presentment")) && Boolean.parseBoolean(settlementDetails.get("Chargeback Processed"))) && !debitPrimaryCondition.contains("No Credit")){
				pdp.back.click();
				Log.info("Performing Credit Chargeback scenario");
				chargebackCredited = chargeback.creditChargeback(settlementDetails);
				if(chargebackCredited){
					Log.info("Requested Chargeback has been processed successfully");
					pdp.checkPrepaidDetails(cardNumber);
					//Fetching card baseI and baseII details after processing credit chargeback 
					postChargebackBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
					pdp.pre_post_Transaction_BaseIBaseIIValidation(cardBaseDetails, postChargebackBaseDetails, Double.parseDouble(settlementDetails.get("Settlement Amt")), "Credit");
					chargebackDetails = pdp.fetchChargebackDetails(approvalCode, "Credit Chargeback");
					Log.info("Updating Chargeback details to excel to validate chargeback report");
					cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "ChargebackReport", 0);
					ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "ChargebackReport", cellRowNumber, 0, chargebackDetails.toString());
				}
			}else{
				chargebackCredited = true;
				postChargebackBaseDetails = cardBaseDetails;
			}
			if(debitSecondaryCondition.equalsIgnoreCase("Second Presentment") && chargebackCredited){
				Log.info("Performing Second Presentment scenario");
				boolean flag1=false, flag2=false;
				String[] postSecondPresentmentBaseDetails=null;
				String settlementEvent = secondPresentment.substring(3);
				secondPresentment = secondPresentment.substring(0,3);
				List<String> fileName = null;
				fileName = settlement.settlementType(secondPresentment, approvalCode, cardNumber, mcc, transactionAmount, acquiringInstution, transactionDate, secondPurdebitCondition,"", "", "", "","", "", "", mccBuffer, crossCurrencyFee);
				boolean settlementProcessed = settlement.procesSettlements(fileName);

//				basepage.driver = csrDriver;
				driver = csrDriver;
				if(settlementProcessed){
					//validate the second presentment transaction in csr.
					secondPresentment = secondPresentment.substring(0, 3);
					flag1 = pdp.validateSettlement(cardNumber, approvalCode, secondPresentment, debitSettlementAmount, creditSettlementAmount, debitReversalSettlementAmount, creditReversalSettlementAmount);
					Log.info("Settlement processed and Transaction is populating in CSR : "+flag1);
					if(flag1){
						Log.info("Second Presentment Debit Settlement is as expected");
						for (int i=0 ; i< fileName.size(); i++){
							settlementDetails.clear();
							settlementDetails = pdp.fetchSettlementDetails(approvalCode, settledApprovalCode, secondPresentment);
							if(!settlementDetails.isEmpty()){
								cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", 0);
								ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", cellRowNumber, 0, settlementDetails.toString());
							}
						}
						String transactionType = pdp.validateSettlementProcessStatus(approvalCode, secondPresentment,secondPresentmentProcessStatus, transactionDetails, settlementDetails);
						postSecondPresentmentBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "Second Presentment Debit", approvalCode);
						double SettledAmount = debitSettlementAmount/100.00;
						flag2 = pdp.pre_post_Transaction_BaseIBaseIIValidation(postChargebackBaseDetails, postSecondPresentmentBaseDetails, SettledAmount, transactionType);
						Log.pass("Second Debit Settlement Transaction in CSR populating : "+flag1+
								"/n Post Second Presentment BaseI and BaseII are update as expected: "+ flag2);
					}else{
						Log.fail("Second Presentment Debit Settlement is not processed as expected");
					}
				}

				boolean settlementEventsProcessed = false;
				if(settlementEvent.contains("L1") || settlementEvent.contains("L2") || settlementEvent.contains("L3") || settlementEvent.contains("R2") || settlementEvent.contains("R3")){
					fileName = settlement.settlementType(secondPresentment+settlementEvent, approvalCode, cardNumber, mcc, transactionAmount, acquiringInstution, transactionDate, secondPurdebitCondition,"", "", "", "","", "", "", mccBuffer, crossCurrencyFee);
					settlementEventsProcessed = settlement.procesSettlements(fileName);
				}
//				basepage.driver = csrDriver;
				driver = csrDriver;

				if(settlementEventsProcessed){
					//validate the second presentment transaction in csr.					
					flag1 = pdp.validateSettlement(cardNumber, approvalCode, settlementEvent, debitSettlementAmount, creditSettlementAmount, debitReversalSettlementAmount, creditReversalSettlementAmount);
					Log.info("GTAQ Settlement process "+settlementEvent+" Transaction is populating in CSR : "+flag1);
					if(flag1){
						for (int i=0 ; i< fileName.size(); i++){
							settlementDetails.clear();
							settlementDetails = pdp.fetchSettlementDetails(approvalCode, settledApprovalCode, settlementEvent);
							if(!settlementDetails.isEmpty()){
								cellRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", 0);
								ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "SettlementReport", cellRowNumber, 0, settlementDetails.toString());
							}
						}
						String transactionType = pdp.validateSettlementProcessStatus(approvalCode, settlementEvent,gtaqEventExpectedStatus, transactionDetails, settlementDetails);
						String[] postGTAQEventBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "Second Presentment Debit", approvalCode);
						double SettledAmount = debitSettlementAmount/100.00;
						pdp.pre_post_Transaction_BaseIBaseIIValidation(postSecondPresentmentBaseDetails, postGTAQEventBaseDetails, SettledAmount, transactionType);
						Log.info("GTAQ Settlement Event process Status, Base I & Base II Details are updated as expected");
					}else{
						Log.info( "GTAQ Settlement Event is not processed as expected");
					}
				}
			}
			eodDriver.close();
			settlementDriver.close();
			csrDriver.close();
			settledApprovalCode.clear();
		}
		catch(Exception e){
//			driver.close();
			settledApprovalCode.clear();
			e.printStackTrace();
			//Log.info(  "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.info( "Settlement Process is Unsuccessfull");
		}
	}
}
package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class CardUnloadReport extends BaseTest {
	
	String product;
	String urn;
	String last4digit;
	String profile;
	int rechargeAmount;
	int transactionFee;
	String clientEventId;
	String clientTxnId;
	
	String customerId;
	String cardNumber;
	int[] cell = null;	
	
	String responseDateTime;	
	String reportDate;
	String transactionDate;
	JSONObject Jsonresponse;
	boolean reporturnvalidation;
	BasePayLoad basePayLoad=new BasePayLoad(driver);
	WebDriverWait wait = new WebDriverWait(driver,60);
	
		
//	cardNumber = csrbasepage.GetCardNumber(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", "Active");
//	last4digit = Generic.GetLast4DigitCardNumber(cardNumber);
//	cell = excel.SearchTextFindCellAddress(System.getProperty("user.dir") + APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails",cardNumber);
//	urn = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 2);
//	customerId = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", cell[0], 2);
//	product = excel.getData(System.getProperty("user.dir")+APIPAYLOAD_TESTDATA_XLSX_FILE_PATH, "CardDetails", 3, 3);
//	CSRBasePage csrbasepage = new CSRBasePage();
	
	//Validating All active Cards in activation/card Creation report
	@Test()
	public void unloadReport(){
		try{
			Object[][] unloadedCards = DataProviderUtility.GetData(APIREQUESTBODY_TESTDATA_XLSX_FILE_PATH, "CardDetails");
			System.out.println("rechargedCards.length: "+unloadedCards.length);
			
			initBrowser(BROWSER, "ExternalReports");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Card Load/Unload Report");
			enhancedReports.selectReportType("Unload Report");
			
				for(int i=0; i<unloadedCards.length;i++){					
					System.out.println("rechargedCards[0].length: "+unloadedCards[0].length);
					if(unloadedCards[i][4].toString().equalsIgnoreCase("Active")){
						if(unloadedCards[i][9].toString().equalsIgnoreCase("true")){
						//last4digits
						last4digit = unloadedCards[i][1].toString();
						//urn
						urn = unloadedCards[i][2].toString();
						Log.info( "#-------------------------------------------------------------------------------------------------------------#");
						Log.info("**************In External Report to validate the Unload Events on an active cards in unload report**************");
						Log.info( "Browser stated and Application launched");
						//Json Recharge response
						String response = unloadedCards[i][10].toString();
						//parsing response String to JSON response
						Jsonresponse = basePayLoad.ParseStringToJSON(response);
						//Fetching JSON response values like Card Limit, URN, Card Last4Digits, TxnId, Creation Date
						rechargeAmount = Integer.parseInt(Jsonresponse.get("transactionAmount").toString());
						int transactionAmount = rechargeAmount/100;	
						clientTxnId = Jsonresponse.get("clientTxnId").toString();
						responseDateTime = Jsonresponse.get("responseDateTime").toString();
						transactionDate = Generic.reportFormattedDate(responseDateTime,"mmddyyyy");
						reportDate = Generic.formatDate(responseDateTime,"mmddyyyy");
						//Generating Report for the required date range
						enhancedReports.generateReport(reportDate, reportDate);	
						wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
						
						enhancedReports.selectProductreport("POWRPAY");
						wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
						
						if(enhancedReports.nextPage.isEnabled()){
						//Navigating to Default Page Number One
						driver.findElement(By.id("gotoPage")).clear();
						driver.findElement(By.id("gotoPage")).sendKeys("1");
						driver.findElement(By.name("goto")).click();
						}
						
						//Validating if URN exist in the report Open page if not then searching in rest report pages
						System.out.println(driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty());
						if(driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty()){
							do{
								if(driver.findElement(By.xpath("//input[@name='next']")).isEnabled() && !reporturnvalidation){
									driver.findElement(By.xpath("//input[@name='next']")).click();
									}else{
										break;
										}	
								}while(reporturnvalidation = !driver.findElements(By.xpath("//div[contains(text(),'"+urn+"')]")).isEmpty());
							}else{
								reporturnvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]")).isDisplayed();
								Log.info(urn+" URN is populating in report "+reporturnvalidation);
							}
						
						if(reporturnvalidation){
							boolean reportcard4digitvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+last4digit+"')]")).isDisplayed();
							Log.info(last4digit+" cardLast4Digit is populating in report "+reportcard4digitvalidation);
							
							boolean reportTxnIdvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+clientTxnId+"')]")).isDisplayed();
							Log.info(clientTxnId+" clientTxnId is populating in report "+reportTxnIdvalidation);
							
							boolean reportcardlimitvalidation = driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[contains(text(),'"+transactionAmount+"')]")).isDisplayed();
							Log.info(transactionAmount+" Card Limit is populating in report "+reportcardlimitvalidation);
							
							boolean reportProductvalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//preceding::div[1]")).getText().isEmpty();
							Log.info("Card Product is populating in report "+reportProductvalidation);
							
							boolean reportCardHolderNamevalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[2]")).getText().isEmpty();
							Log.info("Card Holder Name is populating in report "+reportCardHolderNamevalidation);
							
							boolean reportProfilevalidation = !driver.findElement(By.xpath("//div[contains(text(),'"+urn+"')]//following::div[3]")).getText().isEmpty();
							Log.info("Card Holder Name is populating in report "+reportProfilevalidation);
							
							assertTrue(reporturnvalidation&&reportcard4digitvalidation&&reportTxnIdvalidation&&reportcardlimitvalidation&&reportProductvalidation&&reportCardHolderNamevalidation&&reportProfilevalidation);
							Log.info( "reporturnvalidation: "+reporturnvalidation+" ;reportcard4digitvalidation: "+reportcard4digitvalidation+" ;reportTxnIdvalidation: "+reportTxnIdvalidation+" ;reportcardlimitvalidation: "+reportcardlimitvalidation+" ;reportProductvalidation: "+reportProductvalidation+" ;reportCardHolderNamevalidation: "+reportCardHolderNamevalidation+" ;reportProfilevalidation: "+reportProfilevalidation);
							
							if (reporturnvalidation&&reportcard4digitvalidation&&reportTxnIdvalidation&&reportcardlimitvalidation&&reportProductvalidation&&reportCardHolderNamevalidation&&reportProfilevalidation) {
								Log.pass("CSR Card Recharge Report Validation is Successfull");
							} else {
								Log.fail("CSR Card Recharge Report Validation is Not Successfull");
							}
						}else{
							Log.fail("CSR Card Recharge Report Validation is Not Successfull");
						}
					}
				}
			}
		driver.close();
		}
		catch(Exception e){
			e.printStackTrace();
			Log.error( "Exception is "+e);
			Log.fail( "Card Creation Report Validation is unsuccessful");
		}
	}
	
	
	
//	//Downloading Unload report as excel or other format and validating the Product Summary
	@Test()
	public void reportDownloadandProductSummaryValidation(){
		File reportFilePath;
		long fileSize;
		boolean pdfFileSizeValidation = false;
		boolean xlsxFileSizeValidation = false;
		
		try{

			Log.info( "Browser stated and Application launched");
			initBrowser(BROWSER, "ExternalReports");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info("**************In External Report to validate the export of unload report**************");
			enhancedReports.selectReport("Card Load/Unload Report");
			enhancedReports.selectReportType("Unload Report");
			//Generating Report for the required date range
			Log.info( "Generating Report for Today -90 days From & To Date: "+Generic.getPastOrFutureDate("YYYY-MM-dd", -90)+" & "+Generic.currentDate("YYYY-MM-dd"));
			enhancedReports.generateReport(Generic.getPastOrFutureDate("YYYY-MM-dd", -90), Generic.currentDate("YYYY-MM-dd"));
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
									
//			enhancedReports.lastPage.click();
//			List<WebElement> w = driver.findElements(By.xpath("//table[@id='__bookmark_3']//tr"));
//			assertEquals(driver.findElement(By.xpath("//table[@id='__bookmark_3']//tr[w]//td[1]")).getText(), );			
			
			Log.info( "Fetching Product wise summary details from Activation Report Page");
			//Getting Activation Summary Details
			Object[][] productSummary = enhancedReports.fetchReportsCardsSummary();
			
			int noOfRechargedCards = Integer.parseInt(driver.findElement(By.xpath("//div[contains(text(),'POWRPAY')]//following::a")).getText());
			enhancedReports.selectProductreport("POWRPAY");
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			
			Log.info( "Exporting all pages report as xlsx format");
			//Export report
			enhancedReports.exportReports("XLSX", "All Pages", null);
			//waiting for file download and getting file name
			String xlsxfileName = "Transactions_Detail_Aero (7).xlsx";//Generic.waitForFileToDownload("Transactions_Detail_Aero");
			Log.info( "Report File Downloaded Successfully");
			//validate File size id not Zero
			reportFilePath = new File(System.getProperty("user.dir")+"\\Downloads\\"+xlsxfileName);
			fileSize = reportFilePath.length();
			Log.info( "Downloaded File Size is: "+fileSize);
			xlsxFileSizeValidation = (fileSize!=0);
			
			assertTrue(!xlsxfileName.isEmpty());
			String excelReportPath = System.getProperty("user.dir")+"\\Downloads\\"+xlsxfileName;
			Workbook wb = ExcelLibrary.loadWorkBook(excelReportPath);
			int sheetsCount = wb.getNumberOfSheets();
			String sheet = wb.getSheetAt(sheetsCount-1).getSheetName();
			int lastSheetRecords = ExcelLibrary.getExcelRowCount(excelReportPath, sheet)-1;
			int exportNoOfRecords = ((sheetsCount-2)*40)+lastSheetRecords;		
			assertEquals(exportNoOfRecords, noOfRechargedCards);
			boolean rechargeCardsCountValidation =  (exportNoOfRecords == noOfRechargedCards);					
			
			
			Log.info( "#-------------------------------------------------------------------------------------------------------------#");
			Log.info( "Validating Export of PDF file format report");
			enhancedReports.exportReports("PDF", "All Pages", null);
			//waiting for file download and getting file name			
			String pdffile= Generic.waitForFileToDownload("Transactions_Detail_Aero");
			Log.info( "Report File Downloaded Successfully");
			reportFilePath = new File(System.getProperty("user.dir")+"\\Downloads\\"+pdffile);
			fileSize = reportFilePath.length();
			Log.info( "Downloaded File Size is: "+fileSize);
			pdfFileSizeValidation = (fileSize!=0);
			
			Log.info( "rechargeCardsCountValidation: "+rechargeCardsCountValidation+" ;xlsxFileSizeValidation: "+xlsxFileSizeValidation+" ;pdfFileSizeValidation: "+pdfFileSizeValidation);
			if(rechargeCardsCountValidation&&xlsxFileSizeValidation&&pdfFileSizeValidation){
				Log.pass( "XLSX and PDF file Download and Summary validation is Successfull");
			}else{
				Log.fail( "XLSX and PDF file Download and Summary validation is Unsuccessfull");
			}
			driver.close();
			}
			catch(Exception e){
				e.printStackTrace();
				Log.error( "Exception is "+e);
				Log.fail( "Card Creation Export Report is unsuccessful");
			}		
	}
}

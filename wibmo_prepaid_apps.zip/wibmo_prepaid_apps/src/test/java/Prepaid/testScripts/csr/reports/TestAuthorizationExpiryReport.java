package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;

//@param HashMap authorizationDetails : urn, cardLast4digit, authDate, authAmount, MCC Amount, crossCurrencyFee, Auth Available to settle, Approval Code, RRN, Currency Code, Message, MCC Code
public class TestAuthorizationExpiryReport extends BaseTest {
	
//	Validating Authorization Report after executing authorization cases
	@Test(description="Authorization Expiry Report", dataProvider="authorizationExpiryReport", dataProviderClass = DataProviderUtility.class)
	public void authorizationExpiryReportValidation(String authorizationExpiryDetails){
		try{
			HashMap<String, String> authExpiryDetails =  Generic.parseStringToHashmap(authorizationExpiryDetails);
			

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Auth Expiry report");
			
			String string = authExpiryDetails.get("Auth Expired Date").replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String reportDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			enhancedReports.generateReport(reportDate, reportDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			boolean reportValidation = enhancedReports.validateAuthExpiryReport(authExpiryDetails);
			
			if(reportValidation){
				Log.pass( "Authorization Expiry report validation is successfull authorization details are populating in report");
			}else{
				Log.fail( "Authorization Expiry report validation is not successfull authorization details are not populating in report");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Authorization Expiry Report validation is unsuccessfull");
		}
	}
}

package Prepaid.testScripts.csr.authorizations;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.cms.ActivateCardPage;
import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.csr.CSRBasePage;
import Prepaid.pageRepo.csr.LoginPage;
//import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import Prepaid.pageRepo.transactions.AuthorizationJSPPage;
import Prepaid.testScripts.BaseTest1;
import Prepaid.testScripts.csr.BaseTest;
import io.restassured.response.Response;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import java.util.HashMap;

public class Authorization extends BaseTest {
	//	private static Logger Log = Logger.getLogger(Log.class.getName());
	JSONObject requestBody;
	Response response = null;
	String status;
	int i=1;
	Object[] transactionDetails;
	HashMap<String, String> cardPersoDetails = new HashMap<String, String>();
	HashMap<String, String> cardPinDetails = new HashMap<String, String>();
	boolean authorizedAmountValidation = false;
	boolean availableToAuthorizeValidation = false;
	boolean availableToSettleValidation= false;
	boolean settledAmountValidation=false;
	boolean authTransactionValidation = false;
	boolean authTransactionEvent = false;
	int authRowNumber;
	boolean flag1=false;
	WebDriver eodDriver, csrDriver, jspDriver;

	@Test(description="Authorizations", dataProvider="Authorization", dataProviderClass = DataProviderUtility.class)
	public void Authorization(String tcid, String  testScenario, String precondition, String authType, String transactionType,
							  String cardNumber, String transactionAmountDE4, String cardHolderBillingDE6, String expiry,
							  String mcc, String panEntryMode, String pinEntryCapability, String serviceCode, String pvv,
							  String acquiringInstutionD19, String AuthCurrencyD49, String CardCurrencyD51, String posCondCode,
							  String terminalType, String terminalEntry, String additionAuthindicator,
							  String expectedAuthResponseCode){
		try{
			BasePayLoad basePayLoad = new BasePayLoad(driver);
			if(cardNumber.length()>1){
				status = basePayLoad.getCardStatus(cardNumber);
				Log.info("Card "+cardNumber+" is "+status);
			}

			if(tcid=="no"){

			}

			//To Check if a cardnumber exist/active if not creating a new card via api create card request and proceeding with test execution.
			if(cardNumber.length()<16 || status.equalsIgnoreCase("Card Inactive")){
				switch(authType){
					case "ECOM":
						Log.info("Creating a new active card via API");
						//creating api Payload body for card creation
						requestBody = basePayLoad.activationPayload("10000", basePayLoad.getFullKYCProfileID());
						//hitting the request body and returening response
						response = basePayLoad.createCard(requestBody, false);
						Log.info("Card creation response :" + response.asString());
						//fetching card number and card expiry details for the created Card
						cardNumber = basePayLoad.getResponseValue(response, "cardNumber");
						expiry = basePayLoad.getResponseValue(response, "cardExpiry");
						break;
					case "POS":
					case "ATM":
						Log.info("Picking a new card from excel pin/perso details sheet");
						cardPersoDetails = getCardPersoDetails();
						cardNumber = cardPersoDetails.get("cardNumber");
						expiry = cardPersoDetails.get("expiry");
						serviceCode = cardPersoDetails.get("serviceCode");
						pvv=cardPersoDetails.get("cvv");
						serviceCode=cardPersoDetails.get("serviceCode");

						cardPinDetails = getCardPinDetails();

//						BaseTest1.initBrowser("chrome", "cms");
						initBrowser("chrome", "cms");
						Prepaid.pageRepo.cms.LoginPage cmsloginp = new Prepaid.pageRepo.cms.LoginPage(driver);
						driver.get(getAppURL("cms"));
						String[] creds = getAppCredentials("cms");
						cmsloginp.cmsLogin(creds[0],creds[1]);
						ActivationRequestPage arp = new ActivationRequestPage(driver);
						arp.placeCardActivationRequest(cardPinDetails.get("product"), "1000", Generic.getLast4DigitCardNumber(cardPinDetails.get(cardNumber)), cardPinDetails.get("urn"), "Passport");
						ActivateCardPage acp = new ActivateCardPage(driver);
						boolean isActivated = acp.processCardActivationRequest(cardNumber);
						if(isActivated) {
							Log.pass("Card Creation from CMS is Successful");
						}else{
							Log.fail("Card Creation from CMS is UnSuccessful");
						}
						break;
				}
			}

			CSRBasePage csrBasePage = new CSRBasePage(driver);
			//Verifying and executing the pre-condition 
			String conditionReturn = csrBasePage.authorizationPrecondition(precondition, cardNumber);

			//validating if precondition retun value if condition is MCC Authoriation
			if(precondition.equalsIgnoreCase("MCC Authoriation")){
				mcc =  conditionReturn;
			}
			//validating if precondition retun value if condition is No MCC Authoriation
			if(precondition.equalsIgnoreCase("No MCC Authorization")){
				mcc =  conditionReturn;
			}
			//validating if precondition is Full Card Limit then return value is transaction amount
			if(precondition.equalsIgnoreCase("Full Card Limit")){
				transactionAmountDE4 =  conditionReturn;
				cardHolderBillingDE6 =  conditionReturn;
			}
			//validating if condition is Greater than Card Balance then  return value is transaction amount
			if(precondition.equalsIgnoreCase("Greater than Card Balance")){
				transactionAmountDE4 =  conditionReturn;
				cardHolderBillingDE6 =  conditionReturn;
			}


//			csrDriver = initBrowser("chrome", "csr");
			Log.info("Opening CSR To Fetch Card Base I and Base II values before Authorization");
			driver.get(getAppURL("csr"));
			csrDriver=driver;
			PrepaidDetailsPage pdp = new PrepaidDetailsPage(csrDriver, BANK);
			String[] Credentials = getAppCredentials("csr");
			LoginPage csrlp = new LoginPage(csrDriver);
			csrlp.csrLogin(Credentials[0],Credentials[1]); // Username, Password
			//Navigating to Prepaid details page
			pdp.checkPrepaidDetails(cardNumber);
			String csrWindow = csrDriver.getWindowHandle();

			//Fetching BaseI and BaseII Details before to authorization
			String[] cardBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "none", "");
			Log.info("pre authorization - authorizedAmount: "+cardBaseDetails[0]+", "+"availableToAuthorize: "+cardBaseDetails[1] +", "+"availableToSettle: "+cardBaseDetails[2] +", "+"settledAmount: "+cardBaseDetails[3] +", "+"closingBalance: "+cardBaseDetails[4] +", "+"ledgerBalance: "+cardBaseDetails[5]);

			//Initiating authorization JSP page
			Log.info("Launching Auth JSP for initiating transaction");
			jspDriver = initBrowser("chrome", "AuthJSP");
//			openNewTab(getAppURL("AuthJSP"));
			AuthorizationJSPPage ajspPage= new AuthorizationJSPPage(jspDriver);
			//checking if expiry is empty or null if then fetching expiry details from api response
			if(expiry.equalsIgnoreCase("")||expiry.equalsIgnoreCase(null)){
				expiry = basePayLoad.getRequestResponse("activation", "cardExpiry", cardNumber);
			}
			//Sending an authorization request from Auth JSP Page
//			authType, transactionType, cardNumber, transactionAmountDE4, cardHolderBillingDE6, expiry, mcc, panEntryMode, pinEntryCapability, serviceCode, pvv, acquiringInstutionD19, AuthCurrencyD49, CardCurrencyD51, posCondCode
			ajspPage.authorization("visa",authType, transactionType, cardNumber, transactionAmountDE4, cardHolderBillingDE6, expiry, mcc, panEntryMode, pinEntryCapability, serviceCode, pvv, acquiringInstutionD19, AuthCurrencyD49, CardCurrencyD51, posCondCode, terminalType, terminalEntry, additionAuthindicator);

			String approvalCode = ajspPage.fetchAuthResponse("38");
			String responseCode = ajspPage.fetchAuthResponse("39");
			String authrrn = ajspPage.fetchAuthResponse("37").trim();
			String transactionDate = Generic.currentDate("MMdd");

//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "Authorizations", cellRowNumber, 5, cardNumber);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 0, cardNumber);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 1, approvalCode);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 2, mcc);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 4, transactionAmountDE4);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 5, acquiringInstutionD19);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 6, transactionDate);
//			excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", i, 7, responseCode);
			jspDriver.close();

			i++;
//			driver = csrDriver;
			Log.info("Authorization Details: cardNumber: "+cardNumber +" approvalCode: "+approvalCode+" mcc: "+mcc+" transactionAmount: "+transactionAmountDE4+" acquiringInstution: "+acquiringInstutionD19+" responseCode: "+responseCode);
			if(approvalCode!=null && responseCode.equalsIgnoreCase("00")){
				csrDriver.switchTo().window(csrWindow);
				pdp.refresh.click();
				Generic.wait(5);

				//Fetching Orginal Transaction Amount, MCC Buffer, Cross Currency Fee
				double orginalTransAmount = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[10]")).getText().trim());
				double mccbuffer = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[9]")).getText().trim());
				double crossCurrencyFee = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[8]")).getText().trim());
				double totalTransaction = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[12]")).getText().trim());

				//Fetching Base I and Base II details post sending an authorization request
				//postAuthCardBaseDetails return = {authorizedAmount, availableToAuthorize, availableToSettle, settledAmount, closingBalance, ledgerBalance};
				String[] postAuthCardBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "Authorization", approvalCode);
				Log.info("Post authorization - authorizedAmount: "+postAuthCardBaseDetails[0]+", "+"availableToAuthorize: "+postAuthCardBaseDetails[1] +", "+"availableToSettle: "+postAuthCardBaseDetails[2] +", "+"settledAmount: "+postAuthCardBaseDetails[3] +", "+"closingBalance: "+postAuthCardBaseDetails[4] +", "+"ledgerBalance: "+postAuthCardBaseDetails[5]);
				authorizedAmountValidation = Double.parseDouble(postAuthCardBaseDetails[0]) > Double.parseDouble(cardBaseDetails[0]);
				availableToAuthorizeValidation = Double.parseDouble(postAuthCardBaseDetails[1]) < Double.parseDouble(cardBaseDetails[1]);
				availableToSettleValidation = postAuthCardBaseDetails[2].equalsIgnoreCase(cardBaseDetails[2]);
				settledAmountValidation = postAuthCardBaseDetails[3].equalsIgnoreCase(cardBaseDetails[3]);
				double transactionAmount = Double.parseDouble(Generic.decimalFormatter(transactionAmountDE4));
				double expectedTransactionAmount = Double.parseDouble(postAuthCardBaseDetails[0]) - Double.parseDouble(cardBaseDetails[0]);
				authTransactionValidation = (expectedTransactionAmount == totalTransaction) && (transactionAmount==orginalTransAmount);

//				if(authTransactionValidation){
//					excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 7, String.format("%.2f", mccbuffer).replace(".",""));
//					excel.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", authRowNumber, 8, String.format("%.2f", crossCurrencyFee).replace(".",""));
//				}
				int[] cell = ExcelLibrary.searchTextFindCellAddress(TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cardNumber);
				ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				transactionDetails = new Object[] {cardNumber, approvalCode, mcc, transactionAmountDE4, acquiringInstutionD19, responseCode, transactionDate, String.format("%.2f", mccbuffer).replace(".",""), String.format("%.2f", crossCurrencyFee).replace(".","")};

				authTransactionEvent = pdp.validateCardAuthTransactions(cardNumber, approvalCode, responseCode, Integer.parseInt(transactionAmountDE4), panEntryMode, authrrn, acquiringInstutionD19);
				boolean mccValidations = pdp.validateMCCFeeBufferValidation(mcc, approvalCode);

				HashMap<String, String>  authorizationDetails = pdp.fetchAuthorizationDetails(authrrn);
				authRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", 0);
				ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", authRowNumber, 0, authorizationDetails.toString());

				//Executing Authorization Expiry Scenario and Validating the Auth Reversal amount and Base I and II details
				if(precondition.equalsIgnoreCase("Auth Expiry")){
					Log.info("Validating Authorization Expiry Scenario and Base I and II details Post Authorization expiry");
					Log.info("Launching EOD Web Application");
					eodDriver = initBrowser("chrome", "eod");
					csrBasePage = new CSRBasePage(eodDriver);
					driver = eodDriver;
					String authExpiryStatus = csrBasePage.authExpiry();
					eodDriver.close();

					driver = csrDriver;
					csrDriver.switchTo().window(csrWindow);
					if(authExpiryStatus.equalsIgnoreCase("Authorization Expired")){
						pdp.refresh.click();
						Generic.wait(3);
						String authId = csrDriver.findElement(By.xpath(pdp.authRequestTag+"//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[13]")).getText().trim();
						String refundAmount = csrDriver.findElement(By.xpath(pdp.authExpiryTag+"//following::table[1]//tr[2]//a[contains(text(), '"+authId+"')]//following::td[1]")).getText().trim();
						String authExpiredDate = csrDriver.findElement(By.xpath(pdp.authExpiryTag+"//following::table[1]//tr[2]//a[contains(text(), '"+authId+"')]//following::td[2]")).getText().trim();
						authExpiredDate = Generic.reportFormattedDate(authExpiredDate, "MMM d- yyyy- h:mm a");
						authorizationDetails.put("Auth ID", authId);
						authorizationDetails.put("Refund Amount", refundAmount);
						authorizationDetails.put("Auth Expired Date", authExpiredDate);
						authorizationDetails.replace("Auth Status", "Closed");
						String[] postAuthExpiryCardBaseDetails = pdp.fetchCardBaseIBaseIIDetails(cardNumber, "Auth Expiry", authId);

						int expiryRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "AuthorizationExpiryReport", 0);
						ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthorizationExpiryReport", expiryRowNumber, 0, authorizationDetails.toString());
						authorizationDetails.clear();
						authorizationDetails = pdp.fetchAuthorizationDetails(authrrn);
						ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", authRowNumber, 0, authorizationDetails.toString());

						pdp.pre_post_Transaction_BaseIBaseIIValidation(cardBaseDetails, postAuthExpiryCardBaseDetails, 0.00, "Credit");

//						if(postAuthExpiryCardBaseDetails.equals(cardBaseDetails)){
//							//Log.pass( "Authorization pre and Post Authorization Expiry baseI and baseII and Authorization Expiry Validation is successfull");
//						}else{
//							//Log.fail( "Authorization pre and Post Authorization Expiry baseI and baseII and Authorization Expiry event validation is Unsuccessfull");
//						}
					}else{
						Log.fail("Authorization Expiry Job did not process sucessfully");
					}
				}
				pdp.NavigateBackToPrepaidDetailsPage();

				if(authTransactionEvent && authorizedAmountValidation && availableToAuthorizeValidation && availableToSettleValidation && settledAmountValidation && authTransactionValidation && mccValidations){
					Log.pass("Authorization Case is successfull expected authorization response code is matching");
				}else{
					Log.fail("Authorization Case is failure as expected authorization response code is not matching");
				}

			}else{
				pdp.refresh.click();
				//Fetching Failed Authorization Details
				HashMap<String, String>  authorizationDetails = pdp.fetchAuthorizationDetails(authrrn);
				authRowNumber = ExcelLibrary.getLastCellinColumn(TRANSACTION_XLSX_FILE_PATH, "FailedAuthorizationReport", 0);
				ExcelLibrary.writeExcelData(TRANSACTION_XLSX_FILE_PATH, "FailedAuthorizationReport", authRowNumber, 0, authorizationDetails.toString());
			}
			flag1 = responseCode.equalsIgnoreCase(expectedAuthResponseCode);
			if(flag1){
			}else{
			}
//			csrDriver.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
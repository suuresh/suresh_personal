package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;

//@param HashMap authorizationDetails : urn, cardLast4digit, authDate, authAmount, MCC Amount, crossCurrencyFee, Auth Available to settle, Approval Code, RRN, Currency Code, Message, MCC Code
public class TestFailedAuthorizationReport extends BaseTest{

	// Validating Authorization Report after executing Failed Authorization
	// cases
	@Test(description = "Failed Authorization Report", dataProvider = "failedAuthorizationReport", dataProviderClass = DataProviderUtility.class)//, dependsOnMethods = "Authorizations")
	public void failedAuthorizationReportValidation(
			String failedAuthorizationDetails) {
		try {
			HashMap<String, String> failedAuthDetails = Generic
					.parseStringToHashmap(failedAuthorizationDetails);

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info("Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Failed Auth Report");

			String string = failedAuthDetails.get("Date/Time")
					.replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
					"MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String reportDate = date1.getYear() + "-" + date1.getMonthValue()
					+ "-" + date1.getDayOfMonth();
			// From and To Date
			enhancedReports.generateReport(reportDate, reportDate);
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By
					.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			boolean reportValidation = enhancedReports
					.validateFailedAuthReport(failedAuthDetails);

			if (reportValidation) {
				Log.pass(
						"Failed authorization report validation is successfull authorization details are populating in report");
			} else {
				Log.fail(
						"Failed authorization report validation is not successfull authorization details are not populating in report");
			}
		} catch (Exception e) {
			Log.info(
					"Exception : " + ExceptionUtils.getStackTrace(e));
			Log.fail(
					"Card Failed authorization Report validation is unsuccessfull");
		}
	}

	@Test()
	public void failedAuthReportDownload() {
		try {
			Object[][] failedAuthDetails = DataProviderUtility.GetData(TRANSACTION_XLSX_FILE_PATH, "FailedAuthorizationReport");
			String firstfailedAuthDetail = failedAuthDetails[1][0].toString();
			HashMap<String, String> firstfailedAuthDetails = Generic
					.parseStringToHashmap(firstfailedAuthDetail);

			String lastfailedAuthDetail = failedAuthDetails[failedAuthDetails.length - 1][0]
					.toString();
			HashMap<String, String> lastfailedAuthDetails = Generic
					.parseStringToHashmap(lastfailedAuthDetail);

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info(
					"Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info(
					"Navigating to Failed Auth report Report");
			enhancedReports.selectReport("Failed Auth report");

			String string = firstfailedAuthDetails.get("Date/Time")
					.replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
					"MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String fromDate = date1.getYear() + "-" + date1.getMonthValue()
					+ "-" + date1.getDayOfMonth();

			string = lastfailedAuthDetails.get("Date/Time")
					.replace("-", ",");
			date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String toDate = date1.getYear() + "-" + date1.getMonthValue() + "-"
					+ date1.getDayOfMonth();
			// From and To Date
			Log.info( "Loading Report for following dates "
					+ fromDate + " To " + toDate);
			enhancedReports.generateReport(fromDate, toDate);
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By
					.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			Log.info(
					"Downloading Report as excel .xlsx format");
			enhancedReports.exportReports("XLSX", "All Pages", "");
			String reportFileName = Generic.waitForFileToDownload("Failedauth");
			if (reportFileName != null && reportFileName.contains("Failedauth")) {
				Log.pass( "Report Exported Successfully");
			} else {
				Log.fail( "Report Exported Failed");
			}
			Generic.MoveFile("Failed_Auth_Report" + fromDate + "_to_" + toDate);
		} catch (Exception e) {
			Log.info(
					"Exception : " + ExceptionUtils.getStackTrace(e));
		}
	}
}
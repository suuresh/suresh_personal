package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;

import static Prepaid.testScripts.kotak.BaseTest.browser;

//@param HashMap authorizationDetails : urn, cardLast4digit, authDate, authAmount, MCC Amount, crossCurrencyFee, Auth Available to settle, Approval Code, RRN, Currency Code, Message, MCC Code
public class TestAuthorizationReport extends BaseTest {
	
//	Validating Authorization Report after executing authorization cases
	@Test(description="Authorization Report", dataProvider="AuthorizationReport", dataProviderClass = DataProviderUtility.class)
	public void authorizationReportValidation(String authorizationDetails){
		try{
			HashMap<String, String> authDetails =  Generic.parseStringToHashmap(authorizationDetails);
			

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info("Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Authorization Report");
			
			String string = authDetails.get("Authorization Date").replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String reportDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			enhancedReports.generateReport(reportDate, reportDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			boolean reportValidation = enhancedReports.validateAuthReport(authDetails);
			
			if(reportValidation){
				Log.pass( "Authorization report validation is successfull authorization details are populating in report");
			}else{
				Log.fail( "Authorization report validation is not successfull authorization details are not populating in report");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Authorization Report validation is unsuccessfull");
		}
	}
	
	@Test()
	public void authorizationReportDownload(){
		try{
			Object[][] authorizationDetails = DataProviderUtility.GetData(TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData");
			String firstauthDetail = authorizationDetails[1][0].toString();
			HashMap<String, String> firstauthDetails =  Generic.parseStringToHashmap(firstauthDetail);
			
			String lastauthDetail = authorizationDetails[authorizationDetails.length-1][0].toString();
			HashMap<String, String> lastauthDetails =  Generic.parseStringToHashmap(lastauthDetail);
			
			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info( "Navigating to Authorization Report");
			enhancedReports.selectReport("Authorization Report");
			
			String string = firstauthDetails.get("Authorization Date").replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String fromDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			
			string = lastauthDetails.get("Authorization Date").replace("-", ",");
			formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String toDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			Log.info( "Loading Report for following dates "+fromDate+" To "+toDate);
			enhancedReports.generateReport(fromDate, toDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			Log.info( "Downloading Report as excel .xlsx format");
			enhancedReports.exportReports("XLSX", "All Pages", "");
			if(Generic.waitForFileToDownload("authreport")!= null){
				Log.pass( "Report Exported Successfully");
			}else{
				Log.fail( "Report Exported Failed");
			}
			Generic.MoveFile("Authorization_Report_"+fromDate+"_to_"+toDate);
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
		}
	}
	
	//@Test(description="Authorization Report Data Validation", dataProvider="AuthorizationReport", dataProviderClass = DataProviderUtility.class)
	public void exportedReportDataValidtion(String authDetails){
		try{
			Log.info( "Authorization Data Validation of report download data");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			HashMap<String, Boolean> dataValidation = enhancedReports.downloadReportDataValidation(authDetails, "authreport.xlsx", "Approval Code");
			Log.info( "Data Validation result"+dataValidation.toString());
			if(dataValidation.containsValue(false)){
				Log.fail( "Data Validation is a failure");
			}else{
				Log.pass( "Data Validation Succesful");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			}
		}
	}

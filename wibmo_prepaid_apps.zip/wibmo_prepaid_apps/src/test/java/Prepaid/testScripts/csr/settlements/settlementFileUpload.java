package Prepaid.testScripts.csr.settlements;

import Prepaid.pageRepo.transactions.SettlementPage;
import Prepaid.testScripts.csr.BaseTest;
import library.DataProviderUtility;
import library.Log;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertTrue;

public class settlementFileUpload extends BaseTest {

    @Test(description="Settlements", dataProvider="Settlements", dataProviderClass = DataProviderUtility.class)
    public void settlementFileUpload(String cardNumber, String approvalCode,String mcc, String settlementType,
                           String transactionAmount, String acquiringInstution, String transactionDate,
                           String mccBuffer, String crossCurrencyFee, String testCaseID, String testScenario,
                           String debitPrimaryCondition, String debitSecondaryCondition,
                           String creditPrimaryCondition, String creditSecondaryCondition, String debitRPrimaryCondition,
                           String debitRSecondaryCondition, String creditRPrimaryCondition, String creditRSecondaryCondition,
                           String auth_precondition, String settlementProcessStatus, String secondPresentmentProcessStatus,
                           String gtaqEventExpectedStatus) {
        try {
            //Launching Settlement  Web Application
            WebDriver settlementDriver = initBrowser("chrome", "Settlement");
            String settlementWindow = settlementDriver.getWindowHandle();
            // Settlement Process started
            SettlementPage settlement = new SettlementPage(settlementDriver);
            //cardNumber, approvalCode, mcc, settlement type, transactionAmountDE4, acquiringInstutionD19
            List<String> settlementFileName = settlement.settlementType(settlementType, approvalCode, cardNumber, mcc, transactionAmount, acquiringInstution, transactionDate, debitPrimaryCondition, debitSecondaryCondition, creditPrimaryCondition, creditSecondaryCondition, debitRPrimaryCondition, debitRSecondaryCondition, creditRPrimaryCondition, creditRSecondaryCondition, mccBuffer, crossCurrencyFee);
            Log.info("Settlement File :" + settlementFileName);
            List<String> sendToIBSRunStatus = new ArrayList<String>();

            for (int s = 0; s < settlementFileName.size(); s++) {
                if (settlementFileName.get(s) == null) {
                    continue;
                }

                Boolean settlementFileUpload = settlement.UploadFileUsingSendKeys(settlementFileName.get(s));
                assertTrue(settlementFileUpload, "Settlement File Upload is Successful");

                if (settlementFileUpload) {
                    Log.pass("Settelement file is uploaded successfully");
                    settlementFileUpload = false;
                } else {
                    Log.fail("Settelement file is upload un-successfully");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

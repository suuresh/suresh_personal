package Prepaid.testScripts.csr.reports;

import Prepaid.pageRepo.csr.AeroEnhancedReportsPage;
import Prepaid.testScripts.csr.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;

//@param HashMap authorizationDetails : urn, cardLast4digit, authDate, authAmount, MCC Amount, crossCurrencyFee, Auth Available to settle, Approval Code, RRN, Currency Code, Message, MCC Code
public class TestSettlementReport extends BaseTest {
	
//	Validating Authorization Report after executing authorization cases
	@Test(description="Settlement Report", dataProvider="settlementReport", dataProviderClass = DataProviderUtility.class, priority=1)
	public void settlementReportValidation(String settlementDetails){
		try{
			HashMap<String, String> settledDetails =  Generic.parseStringToHashmap(settlementDetails);

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			enhancedReports.selectReport("Settlement Report");
			
			String string = settledDetails.get("Processing_Date").replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String reportDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			enhancedReports.generateReport(reportDate, reportDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			boolean reportValidation = enhancedReports.validateSettlementReport(settledDetails);
			
			if(reportValidation){
				Log.pass( "Settlement report validation is successfull Settlement details are populating in report");
			}else{
				Log.fail( "Settlement report validation is not successfull Settlement details are not populating in report");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			Log.fail("Card Settlement Report validation is unsuccessfull");
		}
	}
	
	@Test(priority=2)
	public void settlementReportDownload(){
		try{
			Object[][] settlementDetails = DataProviderUtility.GetData(System.getProperty("user.dir")+TRANSACTION_XLSX_FILE_PATH, "SettlementReport");
			String firstsettlementDetail = settlementDetails[1][0].toString();
			HashMap<String, String> firstsettlementDetails =  Generic.parseStringToHashmap(firstsettlementDetail);
			
			String lastsettlementDetail = settlementDetails[settlementDetails.length-1][0].toString();
			HashMap<String, String> lastsettlementDetails =  Generic.parseStringToHashmap(lastsettlementDetail);

			initBrowser(BROWSER, "ExternalReports");
//			initBrowser("firefox", "ExternalReports");
			Log.info( "Browser stated and Application launched");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			Log.info( "Navigating to Authorization Report");
			enhancedReports.selectReport("Settlement Report");
			
			String string = firstsettlementDetails.get("Processing_Date").replace("-", ",");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy, h:m a", Locale.ENGLISH);
			LocalDate date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String fromDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			
			string = lastsettlementDetails.get("Processing_Date").replace("-", ",");
			date1 = LocalDate.parse(string, formatter);
			// 2010-01-02
			String toDate = date1.getYear()+"-"+date1.getMonthValue()+"-"+date1.getDayOfMonth();		
			//From and To Date
			Log.info( "Loading Report for following dates "+fromDate+" To "+toDate);
			enhancedReports.generateReport(fromDate, toDate);	
			WebDriverWait wait = new WebDriverWait(driver, 60000);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
			Log.info( "Downloading Report as excel .xlsx format");
			enhancedReports.exportReports("XLSX", "All Pages", "");
			if(Generic.waitForFileToDownload("Accosa_Transactions_Report")!= null){
				Log.pass( "Report Exported Successfully");
			}else{
				Log.fail( "Report Exported Failed");
			}
			Generic.MoveFile("Settlement_Report"+fromDate+"_to_"+toDate);
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
		}
	}
	
	//@Test(description="Settlement Report Data Validation", dataProvider="settlementReport", dataProviderClass = DataProviderUtility.class,priority=3)
	public void exportedReportDataValidtion(String settlementDetails){
		try{
			Log.info( "Data Validation of report download data");
			initBrowser(BROWSER, "ExternalReports");
			AeroEnhancedReportsPage enhancedReports = new AeroEnhancedReportsPage(driver);
			HashMap<String, Boolean> dataValidation = enhancedReports.downloadReportDataValidation(settlementDetails, "Accosa_Transactions_Report.xlsx", "AuthCode");
			Log.info( "Data Validation result"+dataValidation.toString());
			if(dataValidation.containsValue(false)){
				Log.fail( "Data Validation is a failure");
			}else{
				Log.pass( "Data Validation Succesful");
			}
		}catch(Exception e){
			Log.info( "Exception : "+ ExceptionUtils.getStackTrace(e));
			}
		}
}

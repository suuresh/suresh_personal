package Prepaid.testScripts.csr.HeaderFooter;

import Prepaid.pageRepo.csr.HomePage;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

/**
 *
 * @author swathi.rao
 *
 *
 * Validate the details displayed in CSR screen header right hand side(Login page).
 *
 */

public class TC_CSRH_C1_01 extends BaseTest {

    @Test
    public void TC_CSRH_C1_01() {



        String tc_id = "TC_CSRH_C1_01";
        String userID = getValByKey(tc_id, "userID"),password = getValByKey(tc_id, "password");

        HomePage hp= new HomePage(driver);
        LoginPage lp = new LoginPage(driver);

        lp.headerDisplayed();
        System.out.println("Header displayed in login page is as expected");
        lp.csrLogin(userID,password);
        Generic.wait(2);
        lp.headerDisplayed();
        System.out.println("Header displayed in Home page is as expected");
        hp.accosaLite1();
        Generic.wait(2);
        lp.headerDisplayed();
        System.out.println("Header displayed in Prepaid details page is as expected");
        hp.mantainance();
        Generic.wait(2);
        lp.headerDisplayed();
        System.out.println("Header displayed in maintainace page is as expected");
        hp.updateProfile();
        Generic.wait(2);
        lp.headerDisplayed();
        System.out.println("Header displayed in update profile page is as expected");



    }
}
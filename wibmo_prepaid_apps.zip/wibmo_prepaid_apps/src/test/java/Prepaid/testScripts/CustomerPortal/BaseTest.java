package Prepaid.testScripts.customerPortal;

import Prepaid.testScripts.BaseTest1;
import library.ExcelLibrary;

import java.util.HashMap;


/**
 * The Class BaseTest.
 */
public class BaseTest extends BaseTest1 {
	
	/** The test data HashMap which consists of the TestCaseId and TestData as Key Value pairs . */
	private static HashMap<String, String> testData=new HashMap<String, String>();
	
	/** The test scenario HashMap which consists of the TestCaseId and TestScenario as Key Value pairs . */
	private static HashMap<String, String> testScenario=new HashMap<String, String>();
	
	public void initData() //Inputs values into the HashMaps testData and testScenario from the Excel file.
	{
		int rc=ExcelLibrary.getExcelRowCount("./excel_lib/TestData.xls", "Login");
		for (int i = 0; i <= rc; i++) 
		{
			if (!ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0).equals(" ")) 
			{
				testData.put(ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0), ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,2));
				testScenario.put(ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0), ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,1));
			}
		}
	}

	
		
}

package Prepaid.testScripts.customerPortal.login;

import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *         Verify when Cancelled card user enters correct login deatils and successfuly logged-in and card summary screen.
 *
 */

public class TC_CPLGN_C1_06 extends BaseTest {
	@Test
	public void TC_CPLGN_C1_06() {
		try {
			String tc_id = "TC_CPLGN_C1_06";
			String cardNumber = getValByKey(tc_id, "cardnumber"),pin = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assertLoggedCardUser(cardNumber));
			Generic.getFullPageScreenshot(driver, tc_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


package Prepaid.testScripts.customerPortal.login;

import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *         Verify when existing user enters incorrect login deatils for more than 3 times and card gets blocked.
 *
 */

public class TC_CPLGN_C1_03 extends BaseTest {
	@Test
	public void TC_CPLGN_C1_03() {
		try {
			String tc_id = "TC_CPLGN_C1_03";
			String cardNumber = getValByKey(tc_id, "cardnumber"),pin = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assert2AttemptPendingMsg());
			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assertLastAttemptPinMsg());
			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assertLoginBlocked());
			Generic.getFullPageScreenshot(driver, tc_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


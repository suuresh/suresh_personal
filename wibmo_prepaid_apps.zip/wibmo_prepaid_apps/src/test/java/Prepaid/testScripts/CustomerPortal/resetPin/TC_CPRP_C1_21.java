package Prepaid.testScripts.customerPortal.resetPin;

import Prepaid.pageRepo.customerPortal.PinResetPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *Validate resent pin flow with invalid 'Card number' and other field with valid details.
 *Done
 */

public class TC_CPRP_C1_21 extends BaseTest {
	@Test
	public void TC_CPRP_C1_21() {
		try {
			String tc_id = "TC_CPRP_C1_21";
			String  expiry = getValByKey(tc_id, "expiry"),
					mobileNumber = getValByKey(tc_id, "mobileNumber"), dob = getValByKey(tc_id, "dob"); //cardNumber = getValByKey(tc_id, "cardnumber"),

			PinResetPage pr = new PinResetPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			pr.resetPin();
			pr.enterCardNumber("5657645647348219");
			pr.enterCardExpiry(expiry);
			pr.enterMobileNumber(mobileNumber);
			pr.submitResetPinRequest();
			driver.switchTo().alert().getText().contains("Please enter a valid 16 digit Activated Card Number!");
			driver.switchTo().alert().accept();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


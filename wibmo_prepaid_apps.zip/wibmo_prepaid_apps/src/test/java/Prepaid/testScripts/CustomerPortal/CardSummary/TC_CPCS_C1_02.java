package Prepaid.testScripts.customerPortal.cardSummary;

import Prepaid.pageRepo.customerPortal.CardSummary;
import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 * 
 * @author Srikiran
 * 
 *         Verify when existing user enters correct login deatils and successfuly logged-in and card summary screen.
 *
 */

public class TC_CPCS_C1_02 extends BaseTest {
	@Test
	public void TC_CPCS_C1_02() {

		try {
			String tc_id = "TC_CPCS_C1_02";
			String cardNumber = getValByKey(tc_id, "cardnumber"), pin = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
            CardSummary cs = new CardSummary(driver);
			driver.get(getAppURL("CustomerPortal"));

			lp.loginToCustomerPortal(cardNumber, pin);
			Assert.assertTrue(lp.assertLoggedCardUser(cardNumber));
			Assert.assertTrue(cs.assertTransactionHeaders());
			Assert.assertTrue(cs.assertTransactionSectionPopulatingTransaction());
			Generic.getFullPageScreenshot(driver, tc_id);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


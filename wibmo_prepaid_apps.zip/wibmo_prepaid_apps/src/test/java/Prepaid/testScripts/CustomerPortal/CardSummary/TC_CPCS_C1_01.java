package Prepaid.testScripts.customerPortal.cardSummary;

import Prepaid.pageRepo.customerPortal.CardSummary;
import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 * 
 * @author Srikiran
 * 
 *         Verify when existing user enters correct login deatils and successfuly logged-in and card summary screen.
 *
 */

public class TC_CPCS_C1_01 extends BaseTest {
	@Test
	public void TC_CPCS_C1_01() {

		try {
			String tc_id = "TC_CPCS_C1_01";
			String cardNumber = getValByKey(tc_id, "cardnumber"), pin = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
            CardSummary cs = new CardSummary(driver);
			driver.get(getAppURL("CustomerPortal"));

			lp.loginToCustomerPortal(cardNumber, pin);
			Assert.assertTrue(cs.assertLoggedCardUser(cardNumber));
			cs.assertCardSummary();
			Assert.assertTrue(cs.assertCardUsageEndDateValueFormat());
			Assert.assertTrue(cs.assertCardLimitValue());
			Assert.assertTrue(cs.assertTotalPurcahaseValue());
			Assert.assertTrue(cs.assertUnbilledAmountValue());
			Assert.assertTrue(cs.assertAvailableBalanceValue());
			Assert.assertTrue(cs.assertCardStatusValue());
			Generic.getFullPageScreenshot(driver, tc_id);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


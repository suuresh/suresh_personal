package Prepaid.testScripts.customerPortal.resetPin;

import Prepaid.pageRepo.customerPortal.PinResetPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *Change PIN - Expired card
 *Done
 */

public class TC_CPRP_C1_08 extends BaseTest {
	@Test
	public void TC_CPRP_C1_08() {
		try {
			String tc_id = "TC_CPRP_C1_08";
			String cardNumber = getValByKey(tc_id, "cardnumber"), expiry = getValByKey(tc_id, "expiry"),
					mobileNumber = getValByKey(tc_id, "mobileNumber"), dob = getValByKey(tc_id, "dob"), pin = getValByKey(tc_id, "pin");

			PinResetPage pr = new PinResetPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			pr.resetPin();
			pr.submitResetPinRequest(cardNumber, expiry, mobileNumber, dob);
			Assert.assertTrue(pr.assertPinChangeErrorMessageDisplayed());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


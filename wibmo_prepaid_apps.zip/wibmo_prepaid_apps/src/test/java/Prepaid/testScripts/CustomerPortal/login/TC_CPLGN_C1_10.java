package Prepaid.testScripts.customerPortal.login;

import Prepaid.pageRepo.csr.ProcessByCardNumber;
import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *         Validate the blocking of cards on entering wrong pin for 3 times and validate in csr.
 *DONE
 */

public class TC_CPLGN_C1_10 extends BaseTest {
	@Test
	public void TC_CPLGN_C1_10() {
		try {
			String tc_id = "TC_CPLGN_C1_10";
			String cardNumber = getValByKey(tc_id, "cardnumber"),pin = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assert2AttemptPendingMsg());
			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assertLastAttemptPinMsg());
			lp.loginToCustomerPortal(cardNumber,pin);
			Assert.assertTrue(lp.assertLoginBlocked());
			Generic.getFullPageScreenshot(driver, tc_id+"CPBlocked");

			String customerPortalTab = driver.getWindowHandle();
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
			driver.get("https://bob-kenya-cms.pc.enstage-sas.com/csr/index.jsp");
			Prepaid.pageRepo.csr.LoginPage csrLP = new Prepaid.pageRepo.csr.LoginPage(driver);
			csrLP.csrLogin("admin", "password2026");
			csrLP.navigateTo("Process By Card Number");
			ProcessByCardNumber pcp = new ProcessByCardNumber(driver);
			pcp.blockedCardSearch(cardNumber);
			Assert.assertTrue(pcp.assertAccessBlockedCardNumber(cardNumber));
			Generic.getFullPageScreenshot(driver, tc_id+"CSRBlockedCard");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


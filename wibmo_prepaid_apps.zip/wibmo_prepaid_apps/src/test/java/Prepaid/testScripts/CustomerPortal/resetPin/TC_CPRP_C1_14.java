package Prepaid.testScripts.customerPortal.resetPin;

import Prepaid.pageRepo.customerPortal.PinResetPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *Validate the options present in right hand side top corner while navigating through Forgot PIN flow.
 *Done
 */

public class TC_CPRP_C1_14 extends BaseTest {
	@Test
	public void TC_CPRP_C1_14() {
		try {
			String tc_id = "TC_CPRP_C1_14";
			/*String cardNumber = getValByKey(tc_id, "cardnumber"), expiry = getValByKey(tc_id, "expiry"),
					mobileNumber = getValByKey(tc_id, "mobileNumber"), dob = getValByKey(tc_id, "dob");*/

			PinResetPage pr = new PinResetPage(driver);
			driver.get(getAppURL("CustomerPortal"));
			pr.resetPin();
			Assert.assertTrue(pr.assertHomeLinkDisplaying(), "Home Link is visible");
			try{
				Assert.assertFalse(pr.assertlogoffLinkDisplaying());
			}catch(NoSuchElementException e){
				Assert.assertTrue(true, "Logoff is not visible");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


package Prepaid.testScripts.customerPortal.resetPin;

import Prepaid.pageRepo.customerPortal.PinResetPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;


/**
 *
 * @author Srikiran
 *
 *Change PIN - Card whose balance is '0'
 *done
 */

public class TC_CPRP_C1_12 extends BaseTest {
	@Test
	public void TC_CPRP_C1_12() {
		try {
			String tc_id = "TC_CPRP_C1_12";
			String cardNumber = getValByKey(tc_id, "cardnumber"), expiry = getValByKey(tc_id, "expiry"),
					mobileNumber = getValByKey(tc_id, "mobileNumber"), dob = getValByKey(tc_id, "dob");

			PinResetPage pr = new PinResetPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			pr.resetPin();
			pr.submitResetPinRequest(cardNumber, expiry, mobileNumber, dob);
			Assert.assertTrue(pr.assertPinChangeErrorMessageDisplayed());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


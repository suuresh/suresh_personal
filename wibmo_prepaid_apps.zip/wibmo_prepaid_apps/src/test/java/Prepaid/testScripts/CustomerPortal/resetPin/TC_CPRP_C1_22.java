package Prepaid.testScripts.customerPortal.resetPin;

import Prepaid.pageRepo.customerPortal.PinResetPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import library.DB;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.ResultSet;


/**
 *
 * @author Srikiran
 *
 *Validate resent pin flow with not activated 'Card number' and other field with valid details.
 *
 */

public class TC_CPRP_C1_22 extends BaseTest {
	@Test
	public void TC_CPRP_C1_22() {
		try {
			String tc_id = "TC_CPRP_C1_01";
			String cardNumber = getValByKey(tc_id, "cardnumber"), expiry = getValByKey(tc_id, "expiry"),
					mobileNumber = getValByKey(tc_id, "mobileNumber"), dob = getValByKey(tc_id, "dob");

			PinResetPage pr = new PinResetPage(driver);
			driver.get(getAppURL("CustomerPortal"));

			pr.resetPin();
			pr.submitResetPinRequest(cardNumber, expiry, mobileNumber, dob);
			String customerPortal = driver.getWindowHandle();
			Connection con = DB.connectToDB("192.168.106.73", "3306", "bob_kenya_accosa", "aero_app", "accosa2k4");
			String selectQuery = "select OTP_TOKEN from otp_tokens order by CREATE_TIMESTAMP desc;";
			ResultSet result = DB.executeSelectQuery(con, selectQuery);
			String encryptedOTPToken = result.getString("MCC_CODES");
			driver.get("https://aero-pplite-stghdfc.pc.enstage-sas.com/utils/pkcsEnc.jsp");
			String otptoken = pr.text2HSMencryption(encryptedOTPToken, "192.168.105.186", "8809", "bob_alias_key");
			pr.enterOPT(otptoken);
			pr.submitOTPValidation();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}


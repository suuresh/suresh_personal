package Prepaid.testScripts.cms.customerManagement;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.customerManagement.UpdateCustomerProfilePage;
import Prepaid.testScripts.BaseTest1;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class TC_CMS_UCP_03 extends BaseTest1
{
    //This method is to update customer profile for not active card number.

    @Test

    public void TC_CMS_UCP_03 ()
    {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            UpdateCustomerProfilePage UP = new UpdateCustomerProfilePage(driver);
            UP.navigateToCustomerUpdateProfile();
            UP.submitCardDetails("4179235154788144");   // input to this method here should be card which is not activated.
            if (UP.assertCardNumberNotActive()) {
                System.out.println("Test case is successfull");
            }
            else
            {
                System.out.println(" Test case is not successfull");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

package Prepaid.testScripts.cms.cardManagement.cancellation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.CancellationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Aug,2021
 * Verify maker can place cancellation request
 */
public class TC_REG_CMS_CC_19 extends BaseTest {
    @Test
    public void TC_REG_CMS_CC_19(){
        String tc_id = "TC_REG_CMS_CC_19";
        int rowNum= ExcelLibrary.getTestDataRowNum(TEST_EXECUTION_DATA_XLSX_PATH,"CardsPinFileDetail","Reloadable USD TravelCard");
        System.out.println("The row Number:"+rowNum);
        String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2).trim();
        String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 1);
        LoginPage lp = new LoginPage(driver);
        driver.get(getAppURL("cms"));
        String[] Credentials = getAppCredentials("cms");
        String user = Credentials[0];
        String pass=Credentials[1];
        lp.cmsLogin(user, pass);
        CancellationRequestPage cancelReqPage=new CancellationRequestPage(driver);
        String product="Reloadable USD TravelCard";
        Boolean status = false;
        cancelReqPage.cancelRequestCardSearch(product,cardNumber);
        cancelReqPage.cancellationRequest(cardNumber,product);
                if(status){
            Assert.assertTrue(true,"Cancellation Request placed successfully");
            ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2,"ICC_");
        }else{
            Assert.assertTrue(false,"Card Activation request is failed");
        }
    }

}

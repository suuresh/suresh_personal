package Prepaid.testScripts.customerPortal.productModification;

import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.pageRepo.customerPortal.TransactionPage;
import Prepaid.testScripts.customerPortal.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CP_C1_24 extends BaseTest {
    @Test
    public void TC_CP_C1_24(){
        String tc_id="TC_CP_C1_24";
        String cardNumber=getValByKey(tc_id,"cardNumber");
        String pin=getValByKey(tc_id,"pin");
        LoginPage loginPage=new LoginPage(driver);
        TransactionPage transactionPage=new TransactionPage(driver);
        loginPage.loginToCustomerPortal(cardNumber,pin);
        Boolean status=transactionPage.verifyProductImage();
        Assert.assertTrue(status,"The Product image is successfully displayed in Customer portal Transaction Details page");

    }
}

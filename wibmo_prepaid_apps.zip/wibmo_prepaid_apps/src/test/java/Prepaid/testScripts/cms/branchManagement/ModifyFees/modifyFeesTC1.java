package Prepaid.testScripts.cms.branchManagement.ModifyFees;

import Prepaid.pageRepo.cms.branchManagement.CreateBranchAgencyPage;
import Prepaid.pageRepo.cms.branchManagement.ModifyBranchAgencyPage;
import Prepaid.pageRepo.cms.branchManagement.ModifyFees;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.BaseTest1;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class modifyFeesTC1 extends BaseTest1
{
    @Test
    public void modifyFees ()
    {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            ModifyFees MF=new ModifyFees(driver);
            MF.bank_ModifyFees(BANK,"PayuDemo","Non reloadable KES Card","Modify Fees - Success");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

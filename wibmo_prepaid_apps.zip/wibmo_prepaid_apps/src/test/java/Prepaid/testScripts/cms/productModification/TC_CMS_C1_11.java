package Prepaid.testScripts.cms.productModification;

import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

import java.util.HashMap;

public class TC_CMS_C1_11 extends BaseTest {
    @Test
    public void TC_CMS_C1_11(){

        HashMap<String, String> cardData=getTestData();
        System.out.println(cardData);
        String cardNumber=cardData.get("Card Number");
        System.out.println(cardNumber);
    }
}


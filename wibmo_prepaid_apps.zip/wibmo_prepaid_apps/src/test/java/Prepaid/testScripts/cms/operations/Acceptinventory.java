package Prepaid.testScripts.cms.operations;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.cms.OperationsPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.Generic;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

public class Acceptinventory extends BaseTest {

	@Test(dataProvider="InventoryOperations",dataProviderClass=DataProviderUtility.class)
	public void viewInventory(String URN)	{
		/*System.out.println("In View Inventory Method");
		//logger=reports.startTest("View Inventory");
		BasePage basepage = new BasePage(driver);
		initBrowser("chrome", "cms");
		//Log.info( "Browser started and Application launched");
		String[] Credentials = getAppCredentials("cms");
		String user = Credentials[0];
		String pass = Credentials[1];
		System.out.println("Username and password is "+user+"password is "+pass);
		LoginPage csrLogin= new LoginPage(driver);
csrLogin.csrLogin(user,pass);
		//Log.info( "Successfully logged into the application");

		OperationsPage Operations = PageFactory.initElements(driver, OperationsPage.class);
		Operations.ViewInventory(URN, URN);*/
	}
}

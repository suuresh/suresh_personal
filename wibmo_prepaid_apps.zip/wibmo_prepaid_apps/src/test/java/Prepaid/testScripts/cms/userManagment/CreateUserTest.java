package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.CreateUserPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class CreateUserTest extends BaseTest {
    @Test
    public void createUser(){
        cmsLogin();
        CreateUserPage createUserPage=new CreateUserPage(driver);
        String userName= Generic.randomAlphaNumeric(6);
        String mobileNum="123456789101";
        String email="shankar.reddy@wibmo.com";
        createUserPage.submitBranchDetails();
        createUserPage.enterUserDetails(mobileNum,email,userName);
        Boolean successMessage=createUserPage.verifySuccessMessage();
        Assert.assertTrue(successMessage);




    }

}

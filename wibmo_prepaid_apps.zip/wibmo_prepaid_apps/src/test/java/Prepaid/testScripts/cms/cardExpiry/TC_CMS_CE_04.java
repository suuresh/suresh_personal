package Prepaid.testScripts.cms.cardExpiry;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.SearchCardDetailsPage;
import Prepaid.pageRepo.csr.TransactionDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.cms.BaseTest;
import io.restassured.response.Response;
import library.DB;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import java.sql.Statement;

public class TC_CMS_CE_04 extends BaseTest {
@Test
public void TC_CMS_CE_04() {
    String tc_id="TC_CMS_CE_04";
    try {

        //To Create a new active card to perform the scenario
        BasePayLoad basePayLoad = new BasePayLoad(driver);
        JSONObject requestBody = basePayLoad.activationPayload("10000", "100");
        Response responseBody = basePayLoad.createCard(requestBody, false);
        String urn = basePayLoad.getResponseValue(responseBody, "urn");

        //To Get T-1 day in the format of dd-MMM-yyyy for card expiry usage end date update in backend.
        String date = Generic.getPastOrFutureDate("dd-MMM-yyyy", -1);
        //To update the card usage end date to T-1 day in DB.
        Statement stmt = DB.stmt();
        String query = "update ICC_INFO set usage_end_date='" + date + "' where ICC_NUMBER=(select ICC_NUMBER from icc_info_details where urn="+urn+");";
        DB.executeQuery(query);
        //To run the card expiry job in EOD Batch jobs
        EOD_Login_Page eod_page = new EOD_Login_Page(driver);
//          eod_page.browseEODApp("http://192.168.105.124:9797/batch-web/");
        driver.get(getAppURL("eod"));
        String[] Credentials = getAppCredentials("eod");
        String user = Credentials[0];
        String pass = Credentials[1];
        eod_page.eodLogin(user, pass);
        eod_page.selectBank("BOB");
        Generic.wait(05);
        String status = eod_page.wibmoExecuteEODJob("Card Expiry");
        Log.info("The Job Status:" + status);


        // To Login to customer portal and check the card status
        LoginPage loginPage = new LoginPage(driver);
        driver.get(getAppURL("csr"));
        Credentials = getAppCredentials("csr");
        user = Credentials[0];
        pass = Credentials[1];
        loginPage.csrLogin(user, pass);
        SearchCardDetailsPage searchPage = new SearchCardDetailsPage(driver);
        searchPage.submitCardDetails(urn);
        TransactionDetailsPage transactionPage = new TransactionDetailsPage(driver);
        Boolean cardStatus = transactionPage.verifyCardStatus("ICC_EXPIRED");
        if (cardStatus) {
            Log.info("The Card status is Expired In csr  Transaction Details Page");
        } else {
            Log.fail("The card status updation is Failed", Generic.getFullPageScreenshot(driver, tc_id) );
        }
        Boolean usageEndDate = transactionPage.verifyCardUsageEnddate(date);
        if (usageEndDate) {
            Log.info("The Usage end date is updated correctly in csr Transaction Details page.");
        } else {
            Log.fail("The Usage end date is not updated correctly in csr Transaction Details page.", Generic.getFullPageScreenshot(driver, tc_id));
        }
    }catch(Exception e){
      //  Log.error("Exception: "+e.getStackTrace(), Generic.getFullPageScreenshot(driver, tc_id));
    }
}
}

package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CR_RR_01 extends BaseTest
{
	@Test
	public void TC_CMS_CR_RR_01(){
		try {
			String tc_id = "TC_CMS_CR_RR_01";
			String product = getValByKey(tc_id, "product"), cardNumber = getValByKey(tc_id, "cardNumber"),
					amount = getValByKey(tc_id, "amount"), paymentMode = getValByKey(tc_id, "paymentMode");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			RechargeRequestPage rr = new RechargeRequestPage(driver);

			rr.navigatetoRechargeRequest();
			rr.enterCardRechargeDetails(product, cardNumber, amount);
			rr.submitCardRecharge();
			Assert.assertTrue(rr.verifyPaymentMode("Account"));
			Generic.getFullPageScreenshot(driver, tc_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
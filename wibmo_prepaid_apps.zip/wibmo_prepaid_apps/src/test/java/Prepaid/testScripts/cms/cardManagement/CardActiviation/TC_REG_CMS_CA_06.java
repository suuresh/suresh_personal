package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivateCardPage;
import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jul,2021
 * To Verify wheter a checker can reject the card activation placed by Maker.
 */
public class TC_REG_CMS_CA_06 extends BaseTest {
    @Test
    public void TC_REG_CMS_CA_06(){
        int rowNum= ExcelLibrary.getTestDataRowNum(TEST_EXECUTION_DATA_XLSX_PATH,"CardsPinFileDetail","Reloadable USD TravelCard");
        System.out.println("The row Number:"+rowNum);
        String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2).trim();
        String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 1);
        System.out.println("The card number:"+cardNumber);
        System.out.println("The URN:"+urn);
        LoginPage lp = new LoginPage(driver);
        driver.get(getAppURL("cms"));
        String[] Credentials = getAppCredentials("cms");
        String user = Credentials[0];
        String pass=Credentials[1];
        lp.cmsLogin(user, pass);
        //To place Card activation
        ActivationRequestPage activationReqPage=new ActivationRequestPage(driver);
        String product="Reloadable USD TravelCard";
        String amount="1000";
        String last4Digit= Generic.getLast4DigitCardNumber(cardNumber);
        String identityProof="Passport";
        Boolean status=activationReqPage.placeCardActivationRequest(product,amount,last4Digit,urn,identityProof);
        if(status){
            Assert.assertTrue(true,"Card activation request is placed successfully");
            ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2,"ICC_");
        }else{
            Assert.assertTrue(false,"Card Activation request is failed");
        }

        //To Place Modify request on Card activation request.
        ActivateCardPage activateCardPage=new ActivateCardPage(driver);
        status= activateCardPage.rejectActivationRequest(urn,cardNumber);
        if(status){
            Assert.assertTrue(true,"Card Activation request has been cancelled successfully");
        }else{
            Assert.assertTrue(false,"Reject card activation request is failed.");
        }
    }

}

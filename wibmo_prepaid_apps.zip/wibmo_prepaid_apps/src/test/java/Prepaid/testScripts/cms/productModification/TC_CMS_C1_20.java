package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.CancelCardPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

public class TC_CMS_C1_20 extends BaseTest {
    @Test
    public void TC_CMS_C1_20(){
        //To perform the login
        cmsLogin();
        String tc_id="TC_CMS_C1_19";
        String cardNumber=getValByKey(tc_id,"cardNumber");
        String productName=getValByKey(tc_id,"productName");
        CancelCardPage cancelCardPage=new CancelCardPage(driver);
        String last4Digits= Generic.getLast4DigitCardNumber(cardNumber);
        cancelCardPage.selectCancellationRequest(last4Digits);
        cancelCardPage.cancelCard(last4Digits);
    }
}

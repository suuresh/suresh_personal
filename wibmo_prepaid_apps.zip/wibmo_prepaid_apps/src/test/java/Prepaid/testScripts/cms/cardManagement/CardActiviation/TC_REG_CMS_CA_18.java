package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on July,2021
 * Activation request which is available in inventory and not exists in current branch.
 */
public class TC_REG_CMS_CA_18 extends BaseTest {
    @Test
    public void TC_REG_CMS_CA_18() {
        int rowNum = ExcelLibrary.getTestDataRowNum(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", "Reloadable USD TravelCard");
        System.out.println("The row Number:" + rowNum);
        String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2).trim();
        String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 1);
        LoginPage lp = new LoginPage(driver);
        driver.get(getAppURL("cms"));
        String[] Credentials = getAppCredentials("cms");
        String user = Credentials[0];
        String pass = Credentials[1];
        lp.cmsLogin(user, pass);
        //To place Card activation
        ActivationRequestPage activationReqPage = new ActivationRequestPage(driver);
        String product = "Reloadable USD TravelCard";
        String amount = "1000";
        String last4Digit = Generic.getLast4DigitCardNumber(cardNumber);
        String identityProof = "Passport";
        activationReqPage.submitCardActivationDetails(product,amount,cardNumber,urn);
        Boolean status=activationReqPage.getCardDetailsErrorMessage();
        if (status) {
            Assert.assertTrue(false, "On Submit card details, Validation error message displayed");
        } else {
            Assert.assertTrue(false, "Validation error message is not displayed.");
        }
    }
}

package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.ProductModification;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

import java.awt.*;

public class TC_CMS_C1_04 extends BaseTest {

 @Test
      public void TC_CMS_C1_04() throws AWTException {
      //To perform Login
      cmsLogin();
          String tc_id="TC_CMS_C1_04";
        String productName=getValByKey(tc_id,"productName");
        ProductModification productModification=new ProductModification(driver);
        productModification.performProdModification(productName);
        productModification.uploadProductImage();
    }

}

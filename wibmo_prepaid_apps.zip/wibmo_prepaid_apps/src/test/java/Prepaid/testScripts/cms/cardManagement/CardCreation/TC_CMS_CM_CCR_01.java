package Prepaid.testScripts.cms.cardManagement.CardCreation;


import Prepaid.pageRepo.cms.CreateCardRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_CMS_CM_CCR_01 extends BaseTest
{
    String CheckerAction = "Approve";
    //	@Test(dataProvider="CreateCards",dataProviderClass=DataProviderUtility.class)
    @Test
    public void TC_CMS_CM_CCR_01()
    {
        try{
            String tc_id = "TC_CMS_CM_CCR_01";
            String expiryMonths = getValByKey(tc_id, "expiryMonths"), numberofCards= getValByKey(tc_id, "numberofCards"),
                    productName= getValByKey(tc_id, "productName"), cardPersoVendor= getValByKey(tc_id, "cardPersoVendor"),
                    cardTemplate= getValByKey(tc_id, "cardTemplate");
            LoginPage lp = new LoginPage(driver);
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass=Credentials[1];
            lp.cmsLogin(user, pass);

            //Call create card request method
            CreateCardRequestPage ccr = new CreateCardRequestPage(driver);

            ccr.productSelectionforCardCreation(productName);
            Assert.assertEquals(ccr.productName.getText(), productName);
            ccr.productBin.isDisplayed();
            Assert.assertEquals(ccr.productBin.getText().length(), 6);
            ccr.productBin.isDisplayed();
            Assert.assertEquals(ccr.cardUnion.getText(), "Visa Card");
            ccr.productType.isDisplayed();
            Assert.assertNotNull(ccr.productType.getText());
            ccr.cardType.isDisplayed();
            Assert.assertNotNull(ccr.cardType.getText());
            ccr.cardUsage.isDisplayed();
            Assert.assertNotNull(ccr.cardUsage.getText());
            ccr.cardMode.isDisplayed();
            Assert.assertNotNull(ccr.cardMode.getText());
            ccr.serviceCode.isDisplayed();
            Assert.assertNotNull(ccr.serviceCode.getText());
            Log.tagScreeshot(Generic.getFullPageScreenshot(driver, this.getClass().getName()));

            String batchID=ccr.createCardsRequestFromCMS(expiryMonths,numberofCards, cardPersoVendor, cardTemplate);
            int row = ExcelLibrary.createCellSetValue(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", 0, batchID);
            ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1, productName);
            ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 2, cardPersoVendor);
            ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 3, numberofCards);
            Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CM_CCA_01", "batchID", batchID);
            lp.cmsLogout();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}

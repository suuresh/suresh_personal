package Prepaid.testScripts.cms.cardManagement.ViewOrders;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ViewOrdersPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

//view order page downloading the approved and card created batch perso File
public class TC_CMS_VO_03 extends BaseTest {
	@Test(dataProvider="ApproveCards",dataProviderClass= DataProviderUtility.class)
	public void TC_CMS_VO_03(String batchID , String productName, String cardPersoVendor, String numberofCards){
		try {
			String tc_id = "TC_CMS_VO_03";
//			String batchID = getValByKey(tc_id, "batchID");
			int row = ExcelLibrary.searchTextFindCellRoworColumn(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", batchID, "Row");
//			String productName = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1);

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			ViewOrdersPage viewOrder = new ViewOrdersPage(driver);

			viewOrder.SearchCardsBatchID(batchID, cardPersoVendor);
			Assert.assertTrue(viewOrder.validateCardsCreated(numberofCards));

			String persoFileName = viewOrder.downloadPersonalizationFile(batchID,productName);
			Log.info("Perso File Name:"+persoFileName);
			ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 6, persoFileName);
			lp.cmsLogout();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

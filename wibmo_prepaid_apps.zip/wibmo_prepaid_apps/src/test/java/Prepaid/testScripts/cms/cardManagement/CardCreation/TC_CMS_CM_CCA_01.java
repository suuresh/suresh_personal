package Prepaid.testScripts.cms.cardManagement.CardCreation;


import Prepaid.pageRepo.cms.CreateCardApprovePage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_CMS_CM_CCA_01 extends BaseTest
{
    String CheckerAction = "Approve";
    @Test(dataProvider="ApproveCards",dataProviderClass= DataProviderUtility.class)
//    @Test
    public void TC_CMS_CM_CCA_01(String batchID, String productName, String	cardPersoVendor, String numberofCards)
    {
        try {
            String tc_id = "TC_CMS_CM_CCA_01";
//            String batchID = getValByKey(tc_id, "batchID");
            int row = ExcelLibrary.searchTextFindCellRoworColumn(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", batchID, "Row");
//            String productName = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1);
//            String numberofCards = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 3);

            LoginPage lp = new LoginPage(driver);
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass = Credentials[1];
            lp.cmsLogin(user, pass);

            //Call Create card approve method.
            CreateCardApprovePage cca = new CreateCardApprovePage(driver);
            String responseMessage = cca.createCardsApproveFromCMS(batchID, CheckerAction, productName, numberofCards);
            //Assert.assertEquals(responseMessage, ExpectedResult);
            Assert.assertTrue(responseMessage.contains("Card creation request " + batchID + " approved successfully."));
            if(responseMessage.contains("Card creation request " + batchID + " approved successfully.")){
                ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 4, "true");
                Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_VO_01", "batchID", batchID);
                Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_EOD_CCJ_01", "batchID", batchID);
            }else{
                ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 4, "false");
                Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_VO_01", "batchID", batchID);
            }
            lp.cmsLogout();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}

package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.ModifyUserPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class ModifyUserTest extends BaseTest {
    public static String userName="GBY4PC";

    @Test
    public void ModifyUserTest(){
        cmsLogin();
        ModifyUserPage modifyUserPage=new ModifyUserPage(driver);
       modifyUserPage.selectBranch();
       Boolean status=modifyUserPage.submitBranch();
       if(!status){
          Assert.assertTrue(false,"The Modify users page is not displayed");
       }
    status=modifyUserPage.selectUser(userName);
        if(!status){
            Assert.assertTrue(false,"The user details page is not displayed");
        }
        modifyUserPage.modifyUser("123456789254","buddareddy@wibmo.com");
        status=modifyUserPage.verifySuccessMessage();
        if(status){
            Assert.assertTrue(true,"User modified successfully");
        }else{
            Assert.assertTrue(false,"Modify user success message is not displayed" );
        }



    }
}

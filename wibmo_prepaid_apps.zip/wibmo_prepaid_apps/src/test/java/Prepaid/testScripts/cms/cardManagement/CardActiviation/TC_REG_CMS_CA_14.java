package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jul,2021
 * To verify whether the user can place card activation request by submitting card details with invalid Product.
 */
public class TC_REG_CMS_CA_14 extends BaseTest {

        @Test
        public void TC_REG_CMS_CA_14(){
            String productName="Reloadable USD TravelCard";
            String minCardLimit=null;
            int rowNum= ExcelLibrary.getTestDataRowNum(TEST_EXECUTION_DATA_XLSX_PATH,"CardsPinFileDetail",productName);
            String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2).trim();
            String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 1);
            String amount="500";
            String last4Digit= Generic.getLast4DigitCardNumber(cardNumber);
            productName="Non reloadable KES Card";
            LoginPage lp = new LoginPage(driver);
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass=Credentials[1];
            lp.cmsLogin(user, pass);
            //To place Card activation request
            ActivationRequestPage activationReqPage=new ActivationRequestPage(driver);
            activationReqPage.navigateToActivationRequest();
            activationReqPage.submitCardActivationDetails(productName,amount,last4Digit,urn);
            String validationMsg=activationReqPage.getValidationMsgOnCardDetailsSubmit();
            if(validationMsg.trim().equals("Card does not belong to the product choosen, please try again.")){
                Assert.assertTrue(true, "Card Activation Request is Failed.");
            }else{
                System.out.println("The validation message:"+validationMsg);
                Assert.assertTrue(false, "System allows to place card activation request when non matching product is submitted.");
            }

        }

    }

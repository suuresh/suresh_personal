package Prepaid.testScripts.cms.cardManagement.CardInquiry;

//@Author - Swathi Rao
//TestCase - Validate product name displayed is proper for activated card.'

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import library.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CM_CI_07 extends BaseTest {
    @Test
    public void TC_CMS_CM_CI_07(){
        String tc_id = "TC_CMS_CM_CI_07";
        try {
            String urn = getValByKey(tc_id, "urn"), user = getValByKey(tc_id, "user"), password = getValByKey(tc_id, "password"), product = getValByKey(tc_id, "product");

            LoginPage lp = new LoginPage(driver);
            //driver.get(getAppURL("CMS"));
            driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/");
            lp.cmsLogin(user, password);

            CardInquiryPage ci = new CardInquiryPage(driver);
            ci.navigateToCardInquiry();
            ci.doCardInquiryBy("URN", urn);
            ci.assertUrn(urn);
            ci.assertProduct(product);
        }catch (Exception e) {
                Log.error("Error : " + e.getStackTrace());
                e.printStackTrace();
            }


    }
}

package Prepaid.testScripts.cms.cardManagement.CardCreation;

import Prepaid.pageRepo.cms.EODJobsPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class TC_CMS_C1_02 extends BaseTest {
    @Test
    public void TC_CMS_C1_02() throws Exception {

        //To perform login
//        cmsLogin();
        String key = "TC_CMS_C1_02";
        String product = getValByKey(key, "productName");
        String vendor = getValByKey(key, "persoVendor");
        String cardTemplate = getValByKey(key, "template");
        //CreateCardRequestPage cardReqPage = new CreateCardRequestPage(driver);
        //CreateCardApprovePage cardApprovePage = new CreateCardApprovePage(driver);
        EODJobsPage eodJobPage = new EODJobsPage(driver);
        //cardReqPage.productSelectionforCardCreation(product);
        //String batchId = cardReqPage.createCardsRequestFromCMS("", "10", "bob kenya kes card", "non reloadable card", vendor, cardTemplate);
        //cardApprovePage.createCardsApproveFromCMS(batchId, "approve", product, "10");
        Boolean jobStatus = eodJobPage.RunEODJob("card_creation_process");
        if (jobStatus == true) {
            System.out.println("The card creation job run success: job executed time:" + eodJobPage.jobExecutionTime);
            Assert.assertTrue(true);
            //check the job history details for job status
            //eod job page.verify in history("card_creation_process",job runtime);
        } else {
            System.out.println("the card creation job is failure:");
            Assert.assertTrue(false, "the card creation job is failed");
        }


    }
}

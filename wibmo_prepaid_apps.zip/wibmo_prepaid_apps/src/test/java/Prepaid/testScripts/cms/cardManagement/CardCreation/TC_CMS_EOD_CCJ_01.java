package Prepaid.testScripts.cms.cardManagement.CardCreation;

import Prepaid.pageRepo.cms.EODJobsPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_CMS_EOD_CCJ_01 extends BaseTest {
    @Test
    public void TC_CMS_EOD_CCJ_01() {
        try {
            String tc_id = "TC_CMS_EOD_CCJ_01";
            LoginPage cmslogin = new LoginPage(driver);
            EODJobsPage eod = new EODJobsPage(driver);
            driver.get(getAppURL("cms"));
            String[] creds = getAppCredentials("cms");
            cmslogin.cmsLogin(creds[0], creds[1]);

            boolean jobRun = false;
            jobRun =  eod.RunEODJob("card_creation_process");

            Assert.assertTrue(jobRun);
            cmslogin.logOut();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

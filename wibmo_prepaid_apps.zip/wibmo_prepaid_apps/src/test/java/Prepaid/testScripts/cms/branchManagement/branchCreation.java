package Prepaid.testScripts.cms.branchManagement;

import Prepaid.pageRepo.cms.branchManagement.CreateBranchAgencyPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;
import Prepaid.pageRepo.cms.LoginPage;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class branchCreation extends BaseTest
{

    @Test

    public void branchCreation ()
    {
        driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/index.jsp");
        LoginPage lPage = new LoginPage(driver);
        lPage.cmsLogin("admin","password2026");
        CreateBranchAgencyPage CB=new CreateBranchAgencyPage(driver);
        CB.branchCreation("BOBKENYA","AutomationOne2","991001118","sanmativardhaman@mail.com");

    }
}

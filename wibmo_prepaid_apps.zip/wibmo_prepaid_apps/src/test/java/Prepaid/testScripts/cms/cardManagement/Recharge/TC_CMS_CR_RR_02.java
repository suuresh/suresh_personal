package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CR_RR_02 extends BaseTest
{
	@Test
	public void TC_CMS_CR_RR_02(){
		try {
			String tc_id = "TC_CMS_CR_RR_02";
			String product = getValByKey(tc_id, "product"), cardNumber = getValByKey(tc_id, "cardNumber"),
					amount = getValByKey(tc_id, "amount");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			RechargeRequestPage rr = new RechargeRequestPage(driver);

			rr.navigatetoRechargeRequest();
			rr.enterCardRechargeDetails(product, cardNumber, amount);
			rr.submitCardRecharge();
			rr.submitRechargeDetails(product,cardNumber,amount, "Account", Generic.getRandomNumberInRange(100000000, 999999999), "Validating Payment Mode Account");
			rr.assertRechargeRequestSuccessful("Recharge Request successfully done");
			Generic.getFullPageScreenshot(driver, tc_id);

			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CR_RC_01", "paymentMode", "Account");
			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CR_RC_01", "cardNumber", cardNumber);
			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CR_RC_01", "product", product);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
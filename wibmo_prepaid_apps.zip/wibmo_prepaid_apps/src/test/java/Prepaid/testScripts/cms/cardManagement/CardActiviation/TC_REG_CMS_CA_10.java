package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jul,2021
 * To Verify whether user can place card activation request on Reloadable card when card activation activation amount is geater than AML max load amount.
 */
public class TC_REG_CMS_CA_10 extends BaseTest {
    @Test
    public void TC_REG_CMS_CA_10(){
        String productName="Reloadable USD TravelCard";
        String minCardLimit=null;
        int rowNum= ExcelLibrary.getTestDataRowNum(TEST_EXECUTION_DATA_XLSX_PATH,"CardsPinFileDetail",productName);
        String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 2).trim();
        String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", rowNum, 1);
        String amount="20500";
        String last4Digit= Generic.getLast4DigitCardNumber(cardNumber);
       /* //To Get Min card limit configured for product
        String query="select MINIMUM_CARD_LIMIT from card_definition where card_name='"+productName+"'";
        try {
            ResultSet resultSet = DB.result(query);
            if (resultSet.next()) {
                minCardLimit = resultSet.getString("MINIMUM_CARD_LIMIT");
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }*/
        LoginPage lp = new LoginPage(driver);
        driver.get(getAppURL("cms"));
        String[] Credentials = getAppCredentials("cms");
        String user = Credentials[0];
        String pass=Credentials[1];
        lp.cmsLogin(user, pass);
        //To place Card activation request
        ActivationRequestPage activationReqPage=new ActivationRequestPage(driver);
        activationReqPage.navigateToActivationRequest();
        activationReqPage.submitCardActivationDetails(productName,amount,last4Digit,urn);
        String validationMsg=activationReqPage.getValidationMsgOnCardDetailsSubmit();
        if(validationMsg.trim().equals("Amount entered is more than the Maximum Load Amount.")){
            Assert.assertTrue(true, "AML limit for Max card limit validation. Card activation request is failed.");
        }else{
            System.out.println("The validation message:"+validationMsg);
            Assert.assertTrue(false, "System allows to place card activation request when card activation amount greater than Max card limit.");
        }

    }
}

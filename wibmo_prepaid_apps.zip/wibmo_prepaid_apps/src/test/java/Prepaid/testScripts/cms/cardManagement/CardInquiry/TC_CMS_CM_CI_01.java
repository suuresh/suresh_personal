package Prepaid.testScripts.cms.cardManagement.CardInquiry;

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import library.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

//@Author - Srikiran
//TestCase - Post activation , To verify payment mode in card enquiry

public class TC_CMS_CM_CI_01 extends BaseTest {
	@Test()
	public void TC_CMS_CM_CI_01(){
		String tc_id = "TC_CMS_CM_CI_01";
		try {

			String paymentMode = getValByKey(tc_id, "paymentMode"), transactionRefNumber = getValByKey(tc_id, "transactionRefNumber"),
					cardNumber = getValByKey(tc_id, "cardNumber"), urn = getValByKey(tc_id, "urn");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			CardInquiryPage ci = new CardInquiryPage(driver);
			ci.navigateToCardInquiry();
			ci.doCardInquiryBy("Card Number", cardNumber);
			Assert.assertTrue(ci.assertCardNumber(cardNumber));
			Assert.assertTrue(ci.assertTransactionDetails("Activation", transactionRefNumber, "Payment Mode", paymentMode));
			Assert.assertTrue(ci.assertTransactionDetails("Activation", transactionRefNumber, "Transaction Ref. Number", transactionRefNumber));
			Log.pass("Test Case Validation is successful");
		} catch (Exception e) {
			Log.error("Error : " + e.getStackTrace());
			e.printStackTrace();
		}
	}
}

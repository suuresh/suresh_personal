package Prepaid.testScripts.cms.inventoryManagement;

import Prepaid.pageRepo.cms.InventoryManagementPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ViewOrdersPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
//import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.io.IOException;


public class InventoryShipmentManagement extends BaseTest {
	@Test(dependsOnMethods="GetCardsPinFileDetails", dataProvider="CardsPinFileDetail", dataProviderClass=DataProviderUtility.class)
	public void InventoryShipmentManagement(String ProductName, String URN, String CardNumber, String PINNumber, String IPIN)	{
		try{

			initBrowser("chrome", "cms");
			//Log.info( "Browser started and Application launched");
			String[] Credentials = getAppCredentials("cms");
			LoginPage lp = new LoginPage(driver);
			lp.cmsLogin(Credentials[0], Credentials[1]);

			InventoryManagementPage inventoryShipment=PageFactory.initElements(driver, InventoryManagementPage.class);
			inventoryShipment.ShipInventoryToHeadOffice(ProductName, URN, URN); // ShipInventoryToHeadOffice(ProductName, FromURN, ToURN)
			inventoryShipment.ShipInventoryToBranchOrAgencies("", ProductName, URN, URN);//ShipInventoryToBranchOrAgencies( BranchOrAgencies, Product, FromURN, ToURN)
		}catch(Exception e){
			Log.info("Exception : "+ ExceptionUtils.getStackTrace(e));
		}
	}
}

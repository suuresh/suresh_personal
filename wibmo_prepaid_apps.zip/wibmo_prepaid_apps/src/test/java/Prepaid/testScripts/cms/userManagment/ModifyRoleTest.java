package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.ModifyUserRolePage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class ModifyRoleTest extends BaseTest {
    @Test
    public void modifyRoleTest(){
        cmsLogin();
        String roleName="PVmaker";
        ModifyUserRolePage modifyUserRolePage=new ModifyUserRolePage(driver);
       Boolean status= modifyUserRolePage.clickModifyUserRole();
       if(!status){
           Assert.assertTrue(false,"Modify User roles page is not displayed");
       }

      status= modifyUserRolePage.selectModifyRole(roleName);
       if(!status){
           Assert.assertTrue(false,"Role:"+roleName+" Details page is not displayed");
       }
       status=modifyUserRolePage.updateUserRole("Activate Request");
       if(status){
           Assert.assertTrue(true,"Permission is updated for Role and Success Message is displayed");
       }else{
           Assert.assertTrue(false,"Update User role is Failed");
       }
    }

}

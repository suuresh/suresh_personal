package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeCardPage;
import Prepaid.testScripts.BaseTest1;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jul,2021
 */
public class TC_CMS_CR_RC_001 extends BaseTest1
{
    @Test

    public void TC_CMS_CR_RC_001 ()
    {
        try
        {
            String tc_id = "TC_CMS_CR_RC_001";
            String paymentMode = getValByKey(tc_id, "paymentMode"), cardNumber = getValByKey(tc_id, "cardNumber");
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            System.out.println(appCredentials[0]);
            System.out.println(appCredentials[1]);
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            RechargeCardPage rc=new RechargeCardPage(driver);
            rc.navigatetoRechargeCard();
            rc.searchRechargeRequestedCard(cardNumber);
            rc.assertCardRechargeRequest(cardNumber);
            rc.selectCardRechargeRequest(cardNumber);
            String transactionRefNumber = rc.fetchTransationID();
            rc.assertRechargeDetail("Payment Mode", paymentMode);
            rc.reviewRechargeRequest(cardNumber, "Approve");
            Assert.assertTrue(rc.assertCardRechargeSuccessful());

        }

        catch(Exception e)
        {
            e.printStackTrace();

        }
    }
}


package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.RechargeCardPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

public class TC_CMS_C1_07 extends BaseTest {
  /*  @Test
    public void TC_CMS_C1_07(){
        //To perform Login
        cmsLogin();
        String tc_id="TC_CMS_C1_07";
        String urn= getValByKey(tc_id,"urn");
        String cardNumber=getValByKey(tc_id,"cardNumber");
        String productName=getValByKey(tc_id,"productName");
        String rechargeAmount=getValByKey(tc_id,"reloadAmount");
        String last4digit= Generic.getLast4DigitCardNumber(cardNumber);
        RechargeRequestPage rechargeRequestPage=new RechargeRequestPage(driver);
        RechargeCardPage rechargeCardPage=new RechargeCardPage(driver);
       Boolean rechargeqReStatus= rechargeRequestPage.placeRechargeRequest(productName,cardNumber,rechargeAmount,"Cash");
        if(rechargeqReStatus==true){
            System.out.println("The Recharge request is sucess");
        }else{
            System.out.println("The recharge request is failed");
        }
        rechargeCardPage.selectRechargeRequest(last4digit);
        Boolean rechargeStatus=rechargeCardPage.rechargeCard(last4digit,"Approve");
if(rechargeqReStatus==true){
    System.out.println("The Recharge on the card is success!!");
}else{
    System.out.println("The Recharge on the card is Failed!!!");
}
        }
*/
}

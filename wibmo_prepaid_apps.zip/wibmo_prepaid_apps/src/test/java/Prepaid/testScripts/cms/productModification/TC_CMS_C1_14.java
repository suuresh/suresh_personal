package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.AdjustmentCardPage;
import Prepaid.pageRepo.cms.AdjustmentRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_C1_14 extends BaseTest {
    @Test
public void TC_CMS_C1_14(){
    cmsLogin();
    String tc_id="TC_CMS_C1_14";
    String cardNumber=getValByKey(tc_id,"cardNumber");
        String productType = getValByKey(tc_id, "productType");

    String transactionId=getValByKey(tc_id,"transactionID");
    AdjustmentRequestPage adjustmentRequestPage=new AdjustmentRequestPage(driver);
    AdjustmentCardPage adjustmentCardPage =new AdjustmentCardPage(driver);
    adjustmentRequestPage.performAdjustmentRequest(cardNumber,productType,transactionId);
    String successMeggsae=adjustmentRequestPage.getAdjustmentSxvuccessMessage();
    Assert.assertEquals(successMeggsae,"Adjustment Request Successfully done");
    String last4Digits= Generic.getLast4DigitCardNumber(cardNumber);
    adjustmentCardPage.selectAdjustmentRequest(last4Digits);
    Boolean status=adjustmentCardPage.verifyCardAdjustment();
    Assert.assertTrue(true,"Product Image is successfully displayed in card Adjustment Page");
}

}

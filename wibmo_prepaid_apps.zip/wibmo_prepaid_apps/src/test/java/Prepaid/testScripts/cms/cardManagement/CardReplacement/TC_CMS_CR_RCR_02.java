package Prepaid.testScripts.cms.cardManagement.CardReplacement;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ReplaceCardReqPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;

//@Author - Srikiran
//TestCase - "To verify  replace card amount calculation when other fees is entered while doing the replacement"

public class TC_CMS_CR_RCR_02 extends BaseTest {
	/*public void TC_CMS_CR_RCR_02(){
		try {
			String tc_id = "TC_CMS_CR_RCR_02";
			String paymentMode = getValByKey(tc_id, "cardnumber"), transactionRefNumber = getValByKey(tc_id, "pin"),
					cardNumber = getValByKey(tc_id, "pin"), urn = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			ReplaceCardReqPage rcr = new ReplaceCardReqPage(driver);
			rcr.navigateToReplaceCardRequest();
			rcr.searchCardBy("Card Number", cardNumber);
			rcr.assertCardNumber(cardNumber);
			rcr.enterOtherCharges("67");
			Assert.assertTrue(rcr.assertTransferableAmount());
			Generic.getFullPageScreenshot(driver, tc_id);
			rcr.enterDispatchAddress();
			rcr.enterNewCardDetails("New Card Number", newCardNumber);
			rcr.enterMakerComments(cardNumber, newCardNumber);
			rcr.submitReplaceRequest();
			driver.switchTo().alert().accept();
			rcr.assertMessage("Card Replacement Request successfully done");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
}

package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivateCardPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;

//Test Case : Post activation request,To Verify New payment mode 'Account' under card  holder details in activate card (checker)
public class TC_CMS_CM_CAA_01 extends BaseTest {

    public void TC_CMS_CM_CAA_01() {
        try {
            String tc_id = "TC_CMS_CM_CAA_01";
            String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);
            String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);

            LoginPage lp = new LoginPage(driver);
//		driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms");
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass=Credentials[1];
            lp.cmsLogin(user, pass);

            ActivateCardPage ac = new ActivateCardPage(driver);

            ac.navigateToActivateCard();
            Generic.wait(5);
            ac.searchActivatedRequestedCard(urn);
            Assert.assertTrue(ac.assertActivateCardRequest(urn,cardNumber));
            ac.selectActivateCardRequest(urn);
            Generic.wait(5);
            ac.assertCardNumber(cardNumber);
            ac.assertActivateCardRequestDetails("Payment Mode", "Account");
            ac.activateCardRequest(cardNumber);
            ac.assertCardActivated();
            Generic.wait(10);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

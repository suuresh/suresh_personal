package Prepaid.testScripts.cms;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.BaseTest1;
import library.ExcelLibrary;

import java.util.HashMap;


/**
 * The Class BaseTest.
 */
public class BaseTest extends BaseTest1 {
	
	/** The test data HashMap which consists of the TestCaseId and TestData as Key Value pairs . */
	private static HashMap<String, String> testData=new HashMap<String, String>();
	
	/** The test scenario HashMap which consists of the TestCaseId and TestScenario as Key Value pairs . */
	private static HashMap<String, String> testScenario=new HashMap<String, String>();
	
	public void initData() //Inputs values into the HashMaps testData and testScenario from the Excel file.
	{
		int rc=ExcelLibrary.getExcelRowCount("./excel_lib/TestData.xls", "Login");
		for (int i = 0; i <= rc; i++) 
		{
			if (!ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0).equals(" ")) 
			{
				testData.put(ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0), ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,2));
				testScenario.put(ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,0), ExcelLibrary.getExcelData("./excel_lib/TestData.xls", "Login",i,1));
			}
		}
	}

//	public void cmsLogin(){
//		LoginPage loginPage = new LoginPage(driver);
//		String tc_id = "TC_CMS_C1_01";
//		String uname = getValByKey(tc_id, "userName");
//		String pwd = getValByKey(tc_id, "password");
//		loginPage.loginToCmsApp(uname, pwd);
//	}
	
		public static HashMap<String, String> getTestData(){
		String excelFilePath="E:\\D backup\\Shankar\\Automation\\Wibmo_Prepaid_Apps\\excel_lib\\qa\\Web\\Card_Details.xlsx";
		String sheetName="USD_Cards";
		int row_count= ExcelLibrary.getExcelRowCount(excelFilePath,sheetName);
		HashMap<String, String> cardDetails=new HashMap<>();
		for(int i=1;i<row_count;i++){

			//To check the card status and fetch the card card details
			String cardStatus=ExcelLibrary.getExcelData(excelFilePath,sheetName,i,8);
			System.out.println("The card status:"+cardStatus);
			if(cardStatus.equals("Active")){
				for(int j=0;j<8;j++){
					String key=ExcelLibrary.getExcelData(excelFilePath,sheetName,0,j);
					String value=ExcelLibrary.getExcelData(excelFilePath,sheetName, i,j).toString();
					cardDetails.put(key,value);
				}


			}
			Integer in=new Integer(i);
			cardDetails.put("rowNum",in.toString());
			break;
		}
		return cardDetails;
		}

		public static Boolean updateCardDetailsSheet(){
return true;
		}

	public void cmsLogin(){
		LoginPage loginPage = new LoginPage(driver);
		String tc_id = "TC_CMS_C1_01";
		String uname = getValByKey(tc_id, "userName");
		String pwd = getValByKey(tc_id, "password");
		loginPage.cmsLogin(uname, pwd);
	}

}

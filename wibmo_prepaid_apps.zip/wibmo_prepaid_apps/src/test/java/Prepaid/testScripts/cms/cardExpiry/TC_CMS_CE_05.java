package Prepaid.testScripts.cms.cardExpiry;

import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.SearchCardDetailsPage;
import Prepaid.pageRepo.csr.TransactionDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.cms.BaseTest;
import library.DB;
import library.Generic;
import library.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TC_CMS_CE_05 extends BaseTest {

    @Test
    public void TC_CMS_CE_02() throws SQLException {
        String tc_id = "TC_CMS_CE_02";
        try {
            String cardNum = getValByKey(tc_id, "cardNumber"), urn = getValByKey(tc_id, "urn"),
                    productName = getValByKey(tc_id, "product"), productID = getValByKey(tc_id, "productId");

            //To Get T-1 day in the format of dd-MMM-yyyy for card expiry usage end date update in backend.
            String date = Generic.getPastOrFutureDate("dd-MMM-yyyy", -1);
            //To update the card usage end date to T-1 day in DB.
            // Statement stmt= DB.stmt();
            String query = "update ICC_INFO set usage_end_date='" + date + "' where ICC_NUMBER=(select ICC_NUMBER from icc_info_details where urn=" + urn + ");";
            DB.executeQuery(query);
            //To run the card expiry job in EOD Batch jobs
            EOD_Login_Page eod_page = new EOD_Login_Page(driver);
//          eod_page.browseEODApp("http://192.168.105.124:9797/batch-web/");
            driver.get(getAppURL("eod"));
            String[] Credentials = getAppCredentials("eod");
            String user = Credentials[0];
            String pass = Credentials[1];
            eod_page.eodLogin(user, pass);
            eod_page.selectBank("BOB");
            Generic.wait(05);
            String status = eod_page.wibmoExecuteEODJob("Card Expiry");
            Log.info("The Job Status:" + status);

// To Login to customer portal and check the card status
            LoginPage loginPage = new LoginPage(driver);
            driver.get(getAppURL("csr"));
            Credentials = getAppCredentials("csr");
            user = Credentials[0];
            pass = Credentials[1];
            loginPage.csrLogin(user, pass);
            SearchCardDetailsPage searchPage = new SearchCardDetailsPage(driver);
            searchPage.submitCardDetails(urn);
            TransactionDetailsPage transactionPage = new TransactionDetailsPage(driver);
            Boolean cardStatus = transactionPage.verifyCardStatus("ICC_EXPIRED");
            if (cardStatus) {
                Log.info("The Card status is Expired In csr  Transaction Details Page");
            } else {
                Log.fail("The card status updation is Failed", Generic.getFullPageScreenshot(driver, tc_id));
            }
            Boolean usageEndDate = transactionPage.verifyCardUsageEnddate(date);
            if (usageEndDate) {
                Log.info("The Usage end date is updated correctly in csr Transaction Details page.");

            } else {
                Log.fail("The Usage end date is not updated correctly in csr Transaction Details page.", Generic.getFullPageScreenshot(driver, tc_id));
            }

            //To verify the Product id in ICC-TXN_INFO table
            String selectQuery = "select * from icc_txn_info where icc_id = (select icc_id from icc_info where ICC_NUMBER=( select ICC_NUMBER from icc_info_details where urn=" + urn + "));";
            ResultSet rs = DB.result(selectQuery);
            String eventId;
            int product_id = 0;
            while (rs.next()) {
                eventId = rs.getString("EVENT_ID");
                if (eventId.equals("305000")) {
                    product_id = rs.getInt("PRODUCT_ID");
                }

            }
            if (Integer.parseInt(productID) == product_id) {
                Assert.assertTrue(true);
                Log.info("The Product id displayed correctly for expired card in ICC-TXN_INFO table");
            } else {
                Log.fail("The Product id not displayed correctly for expired card in ICC-TXN_INFO table: The Actual ID is:" + product_id, Generic.getFullPageScreenshot(driver, tc_id));
            }
            DB.closeDB();
        }catch(Exception e){
            Log.error("Error : "+e.getStackTrace(), Generic.getFullPageScreenshot(driver, tc_id));
        }
    }
}



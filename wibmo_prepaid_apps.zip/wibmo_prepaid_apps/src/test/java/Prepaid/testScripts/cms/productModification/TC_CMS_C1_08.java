package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.CancellationRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

public class TC_CMS_C1_08 extends BaseTest {
@Test
public void TC_CMS_C1_08(){
    //To Perform the Login
    cmsLogin();
    String tc_id="TC_CMS_C1_08";
    String cardNumber=getValByKey(tc_id,"cardNumber");
    String productName=getValByKey(tc_id,"productName");
    CancellationRequestPage cancellationRequestPage=new CancellationRequestPage(driver);
    //cancellationRequestPage.cancellationRequest(productName,cardNumber,"Refer Card Issuer (01)");
}
}

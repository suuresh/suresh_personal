package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.CreateUserRolePage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class CreateRoleTest extends BaseTest {
public static String roleName;
    @Test
    public void createRole(){
        cmsLogin();
        CreateUserRolePage userRolePage=new CreateUserRolePage(driver);
        Boolean status=userRolePage.ClickCreateUserRoleLink();
        if(!status){
            Assert.assertTrue(false,"The Create User role page is not displayed.");
        }

         roleName= Generic.randomAlphaChar(6);
        System.out.println("The role name: "+roleName);
        status=userRolePage.submitRoleDetails(roleName,"admin");
        if(status){
            Assert.assertTrue(true,"The Create user role is success");
        }else{
            Assert.assertTrue(false,"The Create user role is failed.");
        }

    }
}

package Prepaid.testScripts.cms.CMSFooter;

import Prepaid.pageRepo.customerPortal.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

/**
 * @author swathi.rao
 *
 *
 *
 * Validate the details displayed in cms screen footer.
 *
 *
 */
public class TC_CMSF_C1_01 extends BaseTest {
    @Test
     public void TC_CMSF_C1_01(){

        LoginPage lp = new LoginPage(driver);
        driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/index.jsp");


     }
}

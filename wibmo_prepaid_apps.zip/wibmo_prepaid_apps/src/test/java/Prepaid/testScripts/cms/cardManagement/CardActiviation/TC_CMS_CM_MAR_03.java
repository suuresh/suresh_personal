package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ModfiyActivationReqPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;

//@Srikiran
//TestCase : To verify Modify activation request with new field 'Debit Account Number'
public class TC_CMS_CM_MAR_03 extends BaseTest {

    public void TC_CMS_CM_MAR_03() {
        try {
            String tc_id = "TC_CMS_CM_MAR_03";
            String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);
            String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);
            String debitAccountNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);

            LoginPage lp = new LoginPage(driver);
//		driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms");
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass=Credentials[1];
            lp.cmsLogin(user, pass);

            ModfiyActivationReqPage marp = new ModfiyActivationReqPage(driver);
            marp.navigateToModifyActivationRequest();
            Generic.wait(5);
            marp.searchRejectedCardRequests(urn);
            marp.viewRejectedCardRequest(urn,cardNumber);
            marp.selectRejectedCardRequest(urn);
            Generic.wait(5);
            marp.assertCardNumber(cardNumber);
            marp.verifyRequestDetails("Debit Account Number", debitAccountNumber);
            Generic.getFullPageScreenshot(driver, tc_id);
            marp.modifyActivationDetails("Payment Mode", "Cash");
            marp.modifyActivationDetails("Debit Account Number", Generic.getRandomNumberInRange(100000000,999999999));
            Generic.wait(5);
            Assert.assertTrue(marp.assertModifyRequestSaved());

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

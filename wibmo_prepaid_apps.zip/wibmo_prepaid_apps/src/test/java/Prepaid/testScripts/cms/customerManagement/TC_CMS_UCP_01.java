package Prepaid.testScripts.cms.customerManagement;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.customerManagement.UpdateCustomerProfilePage;
import Prepaid.testScripts.BaseTest1;
import library.Generic;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class TC_CMS_UCP_01 extends BaseTest1 {
    // this test case is with valid card details.
    @Test
    public void TC_CMS_UCP_01() {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            UpdateCustomerProfilePage UP = new UpdateCustomerProfilePage(driver);
            UP.bank_UpdateCustomerProfile(BANK, "4179230611684267", "Swara", "vardhaman", "9900917736", "sanmativardhaman@gmail.com"
                    , "23-01-2018", "AC1121", "Channansandra banglore");
            Generic.checkAlert(driver);
            if(UP.assertSuccesspage())
            {
                System.out.println("Card details are modified");
            }
            else
            {
                System.out.println("Something went wrong please check the code");
            }


        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
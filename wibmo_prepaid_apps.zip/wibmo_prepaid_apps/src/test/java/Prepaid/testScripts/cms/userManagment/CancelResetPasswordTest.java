package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.ResetUserPasswordPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class CancelResetPasswordTest extends BaseTest {

    @Test
    public void CancelResetPasswoordTest() {
        //cmsLogin();
        String userName = "GBY4PC";
        ResetUserPasswordPage restPwdPage = new ResetUserPasswordPage(driver);
        Boolean status = restPwdPage.clickResetPasswordLink();
        if (!status) {
            Assert.assertTrue(false, "Reset Password page is not displayed");
        }
        status = restPwdPage.cancelResetPassword(userName);
        if (status) {
            Assert.assertTrue(true, "The reset password is cancelled successfully");
        } else {
            Assert.assertTrue(false, "The Reset Password is not cancelled and Home page is not displayed.");
        }
    }
}

package Prepaid.testScripts.cms.productModification;


import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.ModfiyActivationReqPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

public class TC_CMS_C1_06 extends BaseTest {
    @Test
    public void TC_CMS_C1_06() {
        //To perform Login
        cmsLogin();
        String tc_id = "TC_CMS_C1_05";
        String urn = getValByKey(tc_id, "urn");
        String cardNumber = getValByKey(tc_id, "cardNumber");
        String productName = getValByKey(tc_id, "productName");
        String activationAmount = getValByKey(tc_id, "activationAmount");
        ActivationRequestPage activationRequestPage = new ActivationRequestPage(driver);
        ModfiyActivationReqPage modfiyActivationReqPage = new ModfiyActivationReqPage(driver);
        String last4Digits = Generic.getLast4DigitCardNumber(cardNumber);
        //activationRequestPage.activationRequest(productName,activationAmount,last4Digits,urn,"user");
        activationRequestPage.modifyActivationRequest(last4Digits,urn);
        modfiyActivationReqPage.modifyActivationRequest(last4Digits);

    }
}
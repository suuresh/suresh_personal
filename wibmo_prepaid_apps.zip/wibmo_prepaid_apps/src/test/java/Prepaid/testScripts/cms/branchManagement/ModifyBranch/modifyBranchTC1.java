package Prepaid.testScripts.cms.branchManagement.ModifyBranch;

import Prepaid.pageRepo.cms.branchManagement.ModifyBranchAgencyPage;
import Prepaid.pageRepo.cms.branchManagement.ModifyFees;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.BaseTest1;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class modifyBranchTC1 extends BaseTest1
{

    @Test

    public void modifyBranch()
    {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            ModifyBranchAgencyPage MB=new ModifyBranchAgencyPage(driver);
            MB.bank_ModifyBranch(BANK,"PayuDemo","9900917736",
                    "9900917736","sanmativardhaman@gmail.com","Bijapur","Karnataka","INDIA");
            MB.assertModifyBranchSuccess("Branch/Agency has been successfully Updated. Find below the summary.");
            System.out.println("succesfull branch is modified");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

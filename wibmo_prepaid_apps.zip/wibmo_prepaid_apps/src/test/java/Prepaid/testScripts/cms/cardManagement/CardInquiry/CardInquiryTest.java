package Prepaid.testScripts.cms.cardManagement.CardInquiry;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.Generic;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class CardInquiryTest extends BaseTest {
	@Test(/*dependsOnMethods="loginAndCreateCards",*/ dataProvider="CardInquiry", dataProviderClass= DataProviderUtility.class)
	public void CardInquiry(String CardNumber,String URNNumber) throws IOException	{
		System.out.println("in test class");
		////logger=reports.startTest("CardInquiry "+CardNumber);
		LoginPage lp = new LoginPage(driver);
		initBrowser("chrome", "cms");
		//Log.info( "Browser started and Application launched");
		String[] Credentials = getAppCredentials("cms");

		lp.cmsLogin(Credentials[0],Credentials[1]);
		////Log.info( "Successfully logged into the application");
				
		CardInquiryPage cardInquiry= new CardInquiryPage(driver);
		////Log.info( "Create and object of Card Inquiry Page");
		cardInquiry.EnterCardDetailsCardInquiry(CardNumber, URNNumber);
		String MaskedCardNumber = cardInquiry.GetCardDetails(CardNumber, URNNumber, "Card Number");
		assertTrue(MaskedCardNumber.contains(Generic.getLast4DigitCardNumber(CardNumber)), "Card Inquiry Details Not Matching");
		assertEquals("Active", cardInquiry.GetCardDetails(CardNumber, URNNumber, "Card Status"));
		////Log.info( CardNumber+"/"+URNNumber+" Card Inquiry request is successfull");
//		String screenshotPath = TakeScreenshotUtility.getScreenshot(URNNumber+" Inquiry", driver);
		////Log.pass( ////logger.addScreenCapture(screenshotPath));
	}
}

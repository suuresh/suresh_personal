package Prepaid.testScripts.cms.cardManagement.cardBlock;

import Prepaid.pageRepo.cms.BlockCardPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class TempBlockTest extends BaseTest {
    @Test
    public void permanentBlockTest(){
        cmsLogin();
        String cardNumber="4179232235614852";
        String mobileNum="918147747016";
        String reason="Lost Card";
        String blockType="Temporary";
        BlockCardPage blockCardPage=new BlockCardPage(driver);
        String successMessage= blockCardPage.blockCard(cardNumber,mobileNum,reason,blockType);
        if(successMessage.trim().equals("Block Card - Success")){
            Assert.assertTrue(true,"The Block type: Temporary is success on a card.");
        }else{
            Assert.assertTrue(false,"The Block type: Temporary is Failed on a card.");
        }
    }
}

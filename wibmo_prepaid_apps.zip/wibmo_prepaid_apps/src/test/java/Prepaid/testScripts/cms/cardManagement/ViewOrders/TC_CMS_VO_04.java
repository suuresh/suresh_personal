package Prepaid.testScripts.cms.cardManagement.ViewOrders;

import Prepaid.pageRepo.cms.InventoryManagementPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ViewOrdersPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.io.IOException;

//read pin and perso file details and save entries into excel
public class TC_CMS_VO_04 extends BaseTest{
	
	@Test(dataProvider="CardBatchPersoPinFileDetails",dataProviderClass= DataProviderUtility.class)
	public void GetCardsPinFileDetails(String batchID, String PersoFileName, String pinFileName, String ProductName) throws IOException	{
		try{
			int row = ExcelLibrary.searchTextFindCellRoworColumn(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", batchID, "Row");
			//logger=reports.startTest("Fetching Card Batch Perso Pin File Details");
			//Log.info( "Fetching Card pin details and storing into excel");
			ViewOrdersPage vop = new ViewOrdersPage(driver);
			vop.FetchCardPinFileDetails(pinFileName, ProductName);
			//Log.info( "Fetching Card perso details and storing into excel");
			vop.FetchCardPersoFileDetails(PersoFileName);
			ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 7, pinFileName);
		}catch(Exception e){
			e.printStackTrace();
			Log.error("Exception : " + e);
		}
	}
}

package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.BaseTest1;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jul,2021
 */
public class TC_CMS_CR_RR_003 extends BaseTest1 {

    //This test case is to check for maximum recharge amount

    @Test

    public void TC_CMS_CR_RR_003() {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            RechargeRequestPage RP = new RechargeRequestPage(driver);
            RP.navigatetoRechargeRequest();
            RP.submitCardRechargeDetails("Reloadable USD TravelCard", "4179234836742298", "70000");
            if (RP.assertMaximumRechargeMessage()) {
                System.out.println("TC_CMS_CR_RC_002- Test Case is passed ");
            } else {
                System.out.println("TC_CMS_CR_RC_002 -Test Case is failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

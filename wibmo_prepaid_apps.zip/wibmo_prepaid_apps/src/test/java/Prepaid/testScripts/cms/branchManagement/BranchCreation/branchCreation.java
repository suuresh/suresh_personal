package Prepaid.testScripts.cms.branchManagement.BranchCreation;

import Prepaid.pageRepo.cms.branchManagement.CreateBranchAgencyPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;
import Prepaid.pageRepo.cms.LoginPage;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class branchCreation extends BaseTest
{

    @Test
    public void branchCreation ()
    {
        try {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            CreateBranchAgencyPage CB = new CreateBranchAgencyPage(driver);
            CB.branchCreation(BANK, "AutomationOne12", "9910011118", "sanmativardhaman@mail.com");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeCardPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CR_RC_01 extends BaseTest
{
	@Test
	public void TC_CMS_CR_RC_01(){
		try {
			String tc_id = "TC_CMS_CR_RC_01";
			String paymentMode = getValByKey(tc_id, "paymentMode"), cardNumber = getValByKey(tc_id, "cardNumber");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			RechargeCardPage rc = new RechargeCardPage(driver);
			rc.navigatetoRechargeCard();
			rc.searchRechargeRequestedCard(cardNumber);
			rc.assertCardRechargeRequest(cardNumber);
			rc.selectCardRechargeRequest(cardNumber);
			String transactionRefNumber = rc.fetchTransationID();
			rc.assertRechargeDetail("Payment Mode", paymentMode);
			rc.reviewRechargeRequest(cardNumber, "Approve");
			Assert.assertTrue(rc.assertCardRechargeSuccessful());

			Generic.getFullPageScreenshot(driver, tc_id);
			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CM_CI_02", "paymentMode", paymentMode);
			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CM_CI_02", "cardNumber", cardNumber);
			Generic.updateValToIni(TESTDATA_INI_PATH, "TC_CMS_CM_CI_02", "transactionRefNumber", transactionRefNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
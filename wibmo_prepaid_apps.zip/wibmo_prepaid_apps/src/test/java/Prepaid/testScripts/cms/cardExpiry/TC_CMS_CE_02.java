package Prepaid.testScripts.cms.cardExpiry;

import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.SearchCardDetailsPage;
import Prepaid.pageRepo.csr.TransactionDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.cms.BaseTest;
import io.restassured.response.Response;
import library.DB;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import java.sql.Statement;

public class TC_CMS_CE_02 extends BaseTest {
@Test
public void TC_CMS_CE_02() {
    String tc_id="TC_CMS_CE_02";
    String urn = getValByKey(tc_id, "urn");
    try {

        // To Login to customer portal and check the card status
        LoginPage loginPage = new LoginPage(driver);
        driver.get(getAppURL("csr"));
        String[] credentials = getAppCredentials("csr");
        String user = credentials[0];
        String pass = credentials[1];
        loginPage.csrLogin(user, pass);
        SearchCardDetailsPage searchPage = new SearchCardDetailsPage(driver);
        searchPage.submitCardDetails(urn);
        TransactionDetailsPage transactionPage = new TransactionDetailsPage(driver);
        Boolean cardStatus = transactionPage.verifyCardStatus("ICC_EXPIRED");
        if (cardStatus) {
            Log.info("The Card status is Expired In csr  Transaction Details Page");
        } else {
           // Log.fail("The card status updation is Failed", Generic.getFullPageScreenshot(driver, tc_id) );
        }
      //  Boolean usageEndDate = transactionPage.verifyCardUsageEnddate(date);
       // if (usageEndDate) {
         //   Log.info("The Usage end date is updated correctly in csr Transaction Details page.");
       // } else {
           // Log.fail("The Usage end date is not updated correctly in csr Transaction Details page.", Generic.getFullPageScreenshot(driver, tc_id));
       // }
    }catch(Exception e){
       // Log.error("Exception: "+e.getStackTrace(), Generic.getFullPageScreenshot(driver, tc_id));
    }
}
}

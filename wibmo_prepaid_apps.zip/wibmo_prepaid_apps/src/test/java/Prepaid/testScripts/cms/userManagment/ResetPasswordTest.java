package Prepaid.testScripts.cms.userManagment;


import Prepaid.pageRepo.cms.userManagement.ResetUserPasswordPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class ResetPasswordTest extends BaseTest {
    @Test
    public void resetPasswoordTest(){
        cmsLogin();
        String userName="GBY4PC";
        ResetUserPasswordPage restPwdPage=new ResetUserPasswordPage(driver);
        Boolean status=restPwdPage.clickResetPasswordLink();
        if(!status){
            Assert.assertTrue(false,"Reset Password page is not displayed");
        }
        status=restPwdPage.resetPassword(userName);
        if(status){
            Assert.assertTrue(true,"The Reset password for the User is success");
        }else{
            Assert.assertTrue(false,"The Reset Password is failed for the user");
        }
    }
}

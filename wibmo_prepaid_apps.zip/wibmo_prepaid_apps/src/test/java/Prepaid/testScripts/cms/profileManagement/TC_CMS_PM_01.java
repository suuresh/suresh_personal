package Prepaid.testScripts.cms.profileManagement;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.profileManagement.ChangePasswordPage;
import Prepaid.testScripts.BaseTest1;
import javafx.scene.control.TextFormatter;
import org.testng.annotations.Test;
import org.yaml.snakeyaml.DumperOptions;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class TC_CMS_PM_01 extends BaseTest1
{
    /**
     * This test case is to change the password.
     */
    @Test

    public void TC_CMS_PM_01()
    {
        try
        {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin("admin", "password2026");
            ChangePasswordPage CP=new ChangePasswordPage(driver);
            CP.navigateToChangePassword();
            CP.submitDetails("password2026","password2027","password2027");
            if(CP.assertSuccessMesage())
            {
                System.out.println("Password is successfully changed");
            }
            else
            {
                System.out.println("Somthing wrong please check the code");
            }


        }

        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}

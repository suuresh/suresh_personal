package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.BaseTest1;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jul,2021
 */
public class TC_CMS_CR_RR_004 extends BaseTest1
{

    // this test case is for non matching product details
    @Test

    public void TC_CMS_CR_RR_004 ()
    {
        try
        {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            RechargeRequestPage RP =new RechargeRequestPage(driver);
            RP.navigatetoRechargeRequest();
            RP.submitCardRechargeDetails("Non reloadable KES Card","4179234836742298","300");
            if(RP.assertInvalidProductSelection("Card does not belong to the product choosen, please try again."))
            {
                System.out.println("TC_CMS_CR_RR_004 -Test case is passed ");
            }
            else
            {
                System.out.println("TC_CMS_CR_RR_004 -Test case is failed");
            }


        }

        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

//package Prepaid.testScripts.cms.cardManagement.Recharge;
//import static org.testng.Assert.assertEquals;
//
//import Prepaid.testScripts.cms.BaseTest;
//import org.openqa.selenium.support.PageFactory;
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
//public class RechargeTest extends BaseTest
//{
//
//
//	@Test(dataProvider="ReloadData",dataProviderClass=DataProviderUtility.class)
//	public void rechargeRequest_Test(String TCNumber,String TestCaseName,String ProductName,String Cnumber,String ReloadAmount,String paymentmode){
//		System.out.println("inside Recharge request test method");
//		//logger=reports.startTest(TCNumber+"__"+TestCaseName);
//		initBrowser(browser, "cms");
//		//Log.info( "Browser stated and Application launched");
//		String[] Credentials = getAppCredentials("cms");
//		String user = Credentials[0];
//		String pass=Credentials[1];
//		System.out.println("Username and password is "+user+"password is "+pass);
//		LoginPage csrLogin= new LoginPage(driver);
//csrLogin.csrLogin(user,pass);
//		//Log.info( "Successfully logged into the application");
//
//		RechargeRequestPage RechargeRequest=PageFactory.initElements(driver,RechargeRequestPage.class);
//		//Log.info( "Initializing the webelements of RechargeRequestPage");
//		boolean rechargeRequest = RechargeRequest.placeRechargeRequest(ProductName, Cnumber, ReloadAmount, paymentmode);
//
//		Assert.assertTrue(rechargeRequest);
//		//Log.pass( "Recharge Request is successful");
//
//		//********************** This section is for calling Re-charge Card method *****************
//		RechargeCardPage RechargeCard=PageFactory.initElements(driver,RechargeCardPage.class);
//		//Log.info( "Initializing the webelements of RechargeCard");
//		//Log.info( "Calling Recharge Card Method");
//		System.out.println(Cnumber);
//		boolean rechargeStatusMessage=RechargeCard.rechargeCard(Cnumber, "Approve");
//		//Log.info( "Calling rechargeCard method");
//		assertEquals(RechargeCard.rechargeSuccessMsg.getText(), "Recharge Card - Success");
//		Assert.assertTrue(rechargeStatusMessage);
//		//Log.pass( "Recharge card is success");
//	}
//}
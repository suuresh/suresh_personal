package Prepaid.testScripts.cms.cardManagement.Recharge;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.RechargeRequestPage;
import Prepaid.testScripts.BaseTest1;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jul,2021
 */
public class TC_CMS_CR_RR_001 extends BaseTest1
{

    //This test case is to submit Proper Recharge request.
    @Test

    public void TC_CMS_CR_RC_001()
    {
        try
        {
            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            String[] appCredentials = getAppCredentials("cms");
            System.out.println(appCredentials[0]);
            System.out.println(appCredentials[1]);
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin(appCredentials[0], appCredentials[1]);
            RechargeRequestPage RP =new RechargeRequestPage(driver);
            RP.navigatetoRechargeRequest();
            RP.submitRechargeDetails("Reloadable USD TravelCard","4179234836742298","500","Cash",
                    "CashAuto","AutoRecharge");
            if(RP.assertRechargeRequestSuccessful("Recharge Request successfully done"))
            {
                System.out.println("Recharge request is successfully submited");
            }
            else
            {
                System.out.println("Test case failed please look into it");
            }

        }
        catch (Exception e)
        {
           e.printStackTrace();
        }
    }
}

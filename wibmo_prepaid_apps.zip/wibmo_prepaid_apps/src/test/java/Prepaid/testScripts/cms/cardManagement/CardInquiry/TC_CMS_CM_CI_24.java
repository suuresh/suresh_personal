package Prepaid.testScripts.cms.cardManagement.CardInquiry;

//@Author - Swathi Rao
//TestCase - Validate available balance, card limit for the card   in Card Inquiry screen after debit card adjustment.

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

public class TC_CMS_CM_CI_24 extends BaseTest {
    @Test
    public void TC_CMS_CM_CI_24(){
        String tc_id = "TC_CMS_CM_CI_24";
        String urn= getValByKey(tc_id,"urn"), user=getValByKey(tc_id,"user"),password=getValByKey(tc_id,"password"),
                cardlimit=getValByKey(tc_id,"cardlimit"),availablebalance=getValByKey(tc_id,"availablebalance");

        LoginPage lp= new LoginPage(driver);
        //driver.get(getAppURL("CMS"));
        driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/");
        lp.cmsLogin(user,password);

        CardInquiryPage ci=new CardInquiryPage(driver);
        ci.navigateToCardInquiry();
        ci.doCardInquiryBy("URN",urn);
        ci.assertUrn(urn);
        ci.assertCardLimit(cardlimit);
        ci.assertAvailableBalance(availablebalance);
        Generic.getFullPageScreenshot(driver, tc_id);

    }
}

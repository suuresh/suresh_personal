package Prepaid.testScripts.cms.cardManagement.CardInquiry;

//@Author - Swathi Rao
//TestCase - Validate the amount displayed for card replacement  in Card Inquiry screen.

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CM_CI_35 extends BaseTest {
    @Test
    public void TC_CMS_CM_CI_35() {
            String tc_id = "TC_CMS_CM_CI_35";

            String urn = getValByKey(tc_id, "urn"), user = getValByKey(tc_id, "user"), password = getValByKey(tc_id, "password"),
                    refNum = getValByKey(tc_id, "txn_ref_num"), txnamount = getValByKey(tc_id, "txnamount");

            LoginPage lp = new LoginPage(driver);
            //driver.get(getAppURL("CMS"));
            driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/");
            lp.cmsLogin(user, password);

            CardInquiryPage ci = new CardInquiryPage(driver);
            ci.navigateToCardInquiry();
            ci.doCardInquiryBy("URN", urn);
            ci.assertUrn(urn);
            Assert.assertTrue(ci.assertTransactionDetails("Replaced Card", refNum, "Transaction Amount", txnamount));
        Assert.assertTrue(ci.assertTransactionDetails("Replaced Card", refNum, "Transaction Ref. Number", refNum));
        Generic.getFullPageScreenshot(driver, tc_id);
    }}

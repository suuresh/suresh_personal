package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.ReplaceCardReqPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

public class TC_CMS_C1_21 extends BaseTest {
    @Test
    public void TC_CMS_C1_21(){
        //to Login
        cmsLogin();
        String tc_id="TC_CMS_C1_21";
        String cardNumber=getValByKey(tc_id,"cardNumber");
        ReplaceCardReqPage replaceCardReqPage=new ReplaceCardReqPage(driver);
       // replaceCardReqPage.replaceCardReqForm(cardNumber);
    }
}

package Prepaid.testScripts.cms.cardManagement.CardInquiry;

//@Author - Swathi Rao
//Testcase Validate Card status for the  Temporarily blocked card  in Card Inquiry screen.

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.annotations.Test;

public class TC_CMS_CM_CI_13 extends BaseTest {
    @Test
    public void TC_CMS_CM_CI_13(){
        String tc_id = "TC_CMS_CM_CI_13";
        String urn= getValByKey(tc_id,"urn"), user=getValByKey(tc_id,"user"),password=getValByKey(tc_id,"password"),
        cardstatus=getValByKey(tc_id,"cardstatus");

        LoginPage lp= new LoginPage(driver);
        //driver.get(getAppURL("CMS"));
        driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/");
        lp.cmsLogin(user,password);

        CardInquiryPage ci=new CardInquiryPage(driver);
        ci.navigateToCardInquiry();
        ci.doCardInquiryBy("URN",urn);
        ci.assertUrn(urn);
        ci.assertCardStatus(cardstatus);
        Generic.getFullPageScreenshot(driver, tc_id);

    }
}

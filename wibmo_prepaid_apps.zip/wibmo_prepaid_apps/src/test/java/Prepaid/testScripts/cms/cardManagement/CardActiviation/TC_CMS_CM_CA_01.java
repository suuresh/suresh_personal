package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_CM_CA_01 extends BaseTest
{
	private String last4digit;

//		@Test(dataProvider="ActivationRequest",dataProviderClass=DataProviderUtility.class)
	@Test()
	public void TC_CMS_CM_CA_01(){
		String tc_id = "TC_CMS_CM_CA_01";
		String productName = getValByKey(tc_id, "cardnumber"), amount = getValByKey(tc_id, "pin"),
				card16DigitNumber = getValByKey(tc_id, "pin"), urn = getValByKey(tc_id, "pin"),
				applicantName = getValByKey(tc_id, "pin"), activated = getValByKey(tc_id, "pin");

		LoginPage lp = new LoginPage(driver);
//		driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms");
		driver.get(getAppURL("cms"));
		String[] Credentials = getAppCredentials("cms");
		String user = Credentials[0];
		String pass=Credentials[1];
		lp.cmsLogin(user, pass);
		//call activation request method
		last4digit= Generic.getLast4DigitCardNumber(card16DigitNumber);
		ActivationRequestPage ar = new ActivationRequestPage(driver);
		boolean CardActivationRequestSuccess=ar.placeCardActivationRequest(productName,amount,last4digit ,urn,"Passport");
		Assert.assertTrue(CardActivationRequestSuccess, "Activation Request is Failed");

		String sheet = "ActivationRequest";
		boolean activateCardSuccess=false;

		int[] row = ExcelLibrary.searchTextFindCellAddress(TEST_EXECUTION_DATA_XLSX_PATH,sheet, urn);
		if(CardActivationRequestSuccess){
			activateCardSuccess=ar.activateCardRequest(urn, last4digit);
			Assert.assertTrue(activateCardSuccess);
			ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, sheet, row[0], 6, Boolean.toString(activateCardSuccess));
		}else{
			ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, sheet, row[0], 6, Boolean.toString(activateCardSuccess));
		}
	}
}

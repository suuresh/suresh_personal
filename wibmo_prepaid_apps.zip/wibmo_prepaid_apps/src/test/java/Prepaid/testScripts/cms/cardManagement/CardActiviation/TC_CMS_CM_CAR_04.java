package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivationRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.ExcelLibrary;
import library.Generic;
import org.testng.Assert;
//@Srikiran
//TestCase : Validation of new field 'debit account number' in activation request page
//Testcase : To Validate whether New field 'Debit Account Number' is optional or mandatory field
public class TC_CMS_CM_CAR_04 extends BaseTest {

    public void TC_CMS_CM_CAR_04() {
        try {
            String tc_id = "TC_CMS_CM_CAR_04";
            String product = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);
            String cardNumber = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);
            String urn = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "", 1, 2);


            LoginPage lp = new LoginPage(driver);
//		driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms");
            driver.get(getAppURL("cms"));
            String[] Credentials = getAppCredentials("cms");
            String user = Credentials[0];
            String pass=Credentials[1];
            lp.cmsLogin(user, pass);

            ActivationRequestPage carp = new ActivationRequestPage(driver);

            carp.navigateToActivationRequest();
            Generic.wait(5);
            carp.submitCardActivationDetails(product, Generic.getRandomNumberInRange(100, 5000), cardNumber, urn);
            Generic.wait(5);
            Assert.assertTrue(carp.assertElementIsVisible(carp.debitAccountNumber));
            Assert.assertTrue(Generic.isEnabled(carp.debitAccountNumber));
            carp.enterCardHolderDetails("Passport");
            carp.submitCardHolderDetails();
            carp.confirmActivationDetails("Cheque", "TC_CMS_CM_CAR_04");
            carp.submitCardActivationRequest();
            Assert.assertTrue(carp.assertActivationSuccessMsg());
            Generic.wait(10);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

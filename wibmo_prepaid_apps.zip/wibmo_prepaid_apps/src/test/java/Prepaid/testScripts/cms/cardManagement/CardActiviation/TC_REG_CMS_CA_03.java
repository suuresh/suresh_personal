package Prepaid.testScripts.cms.cardManagement.CardActiviation;

import Prepaid.pageRepo.cms.ActivateCardPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Shankar Reddy on Jul,2021
 * To verify the card activation request approve for Reloadable USD Card.
 */
public class TC_REG_CMS_CA_03 extends BaseTest {
    @Test
    public void TC_REG_CMS_CA_03(){

        ActivateCardPage activateCardPage=new ActivateCardPage(driver);
        String urn="null";
        String cardNumber=null;
        activateCardPage.navigateToActivateCard();
        Boolean status=activateCardPage.assertActivateCardRequest(urn,cardNumber);
        if(true){
            Assert.assertTrue(true, "The card Activation request is present in Activation request list.");
        }else{
            Assert.assertTrue(false, "The card Activation request is not present in Activation request list.");
        }
        activateCardPage.selectActivateCardRequest(urn);
        status=activateCardPage.assertCardNumber(cardNumber);
        if(status){
            Assert.assertTrue(false, "The Card details are correctly displayed in Activate card details page.");
        }else{
            Assert.assertTrue(false, "The Card details are incorrect in Activate card details page.");
        }
        activateCardPage.activateCardRequest(cardNumber);
        status=activateCardPage.assertCardActivated();
        if(status){
            Assert.assertTrue(true,"The card activation is success");
        }else{
            Assert.assertTrue(false,"The card activation is failed");
        }

    }
}


package Prepaid.testScripts.cms.homePage;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CMS_C1_01 extends BaseTest {
   /* @Test
    public void TC_CMS_C1_01() {
        String tc_id = "TC_CMS_C1_01";
        String uname = getValByKey(tc_id, "userName");
        String pwd = getValByKey(tc_id, "password");

        LoginPage lp = new LoginPage(driver);
        driver.get("https://bob-kenya-cms.pc.enstage-sas.com/prepaid/cms/index.jsp");
        lp.cmsLogin(uname, pwd);
        Assert.assertTrue(lp.verifyWibmoLogo());
       System.out.println("The prowerd by mesage:"+loginPage.getMessage());


    }*/
}



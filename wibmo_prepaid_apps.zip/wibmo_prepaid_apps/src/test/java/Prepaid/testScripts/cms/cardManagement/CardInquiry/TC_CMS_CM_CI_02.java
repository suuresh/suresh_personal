package Prepaid.testScripts.cms.cardManagement.CardInquiry;

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;

//@Author - Srikiran
//TestCase - Post Recharge  , To verify payment mode in card enquiry

public class TC_CMS_CM_CI_02 extends BaseTest {
	public void TC_CMS_CM_CI_02(){
		try {
			String tc_id = "TC_CMS_CM_CI_02";
			String paymentMode = getValByKey(tc_id, "cardnumber"), transactionRefNumber = getValByKey(tc_id, "pin"),
					cardNumber = getValByKey(tc_id, "pin"), urn = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			CardInquiryPage ci = new CardInquiryPage(driver);

			ci.navigateToCardInquiry();
			ci.doCardInquiryBy("Card Number", cardNumber);
			Assert.assertTrue(ci.assertCardNumber(cardNumber));
			Assert.assertTrue(ci.assertTransactionDetails("Activation", transactionRefNumber, "Payment Mode", paymentMode));
			Generic.getFullPageScreenshot(driver, tc_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

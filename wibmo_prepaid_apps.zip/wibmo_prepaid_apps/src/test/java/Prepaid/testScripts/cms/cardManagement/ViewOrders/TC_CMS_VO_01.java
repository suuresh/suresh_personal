package Prepaid.testScripts.cms.cardManagement.ViewOrders;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.ViewOrdersPage;
import Prepaid.testScripts.cms.BaseTest;
import library.DataProviderUtility;
import library.ExcelLibrary;
import org.testng.Assert;
import org.testng.annotations.Test;

//View Order Page searching create card request and validating card request status
public class TC_CMS_VO_01 extends BaseTest {
	@Test(dataProvider="ApproveCards",dataProviderClass= DataProviderUtility.class)
//    @Test
	public void TC_CMS_VO_01(String batchID, String productName, String	cardPersoVendor, String numberofCards){
//	public void TC_CMS_VO_01(){
		try {
			String tc_id = "TC_CMS_VO_01";
//			String batchID = getValByKey(tc_id, "batchID");
			int row = ExcelLibrary.searchTextFindCellRoworColumn(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", batchID, "Row");
//			String productName = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1);
//			String numberofCards = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 3);
//			String persoVendor = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1);
			String approvalStatus = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 1);

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			System.out.println("Username and password is " + user+ "password is " + pass);
			lp.cmsLogin(user, pass);

			ViewOrdersPage viewOrder = new ViewOrdersPage(driver);
			viewOrder.SearchCardsBatchID(batchID, cardPersoVendor);
			Assert.assertTrue(viewOrder.validateCardsCreated(numberofCards));
			ExcelLibrary.writeExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CreatedCardBatchDetails", row, 5, viewOrder.getOrderCardStatus(batchID));
			lp.cmsLogout();
		} catch (Exception e) {
			System.out.println("Exception :"+e.getStackTrace());
		}
	}
}

package Prepaid.testScripts.cms.profileManagement;

import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.cms.profileManagement.ChangePasswordPage;
import Prepaid.testScripts.BaseTest1;
import library.Generic;
import org.testng.annotations.Test;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class TC_CMS_PM_03 extends BaseTest1
{
    /**
     * This test case to assert the message when old and new password fields are same
     */
    @Test

    public void TC_CMS_PM_03()
    {
        try{

            String appURL = getAppURL("cms");
            System.out.println(appURL);
            driver.get(appURL);
            LoginPage lPage = new LoginPage(driver);
            lPage.cmsLogin("rmaker", "password2022");
            ChangePasswordPage CP=new ChangePasswordPage(driver);
            CP.navigateToChangePassword();
            CP.submitDetails("password2022","password2022","password2022");
            String textMessage=Generic.getAlertText(driver);
            Generic.checkAlert(driver);
            if(textMessage.equalsIgnoreCase("New password and Old password must be different!"))
            {
                System.out.println("Test Case is passed");
            }
            else
            {
                System.out.println("Test case failed");
            }



        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

package Prepaid.testScripts.cms.cardExpiry;

import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.SearchCardDetailsPage;
import Prepaid.pageRepo.csr.TransactionDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.pageRepo.reports.FundReconPage;
import Prepaid.pageRepo.reports.ReportsHomePage;
import Prepaid.testScripts.cms.BaseTest;
import library.DB;
import library.Generic;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TC_CMS_CE_06 extends BaseTest {
    @Test
    public void TC_CMS_CE_03() {
        String tc_id = "TC_CMS_CE_03";
        String cardNum = getValByKey(tc_id, "cardNumber");
        String urn = getValByKey(tc_id, "urn");
        String productName = getValByKey(tc_id, "product");
        //To Get T-1 day in the format of dd-MMM-yyyy for card expiry usage end date update in backend.
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, -1);
        String date = new SimpleDateFormat("dd-MMM-yyyy").format(c.getTime());
        //To update the card usage end date to T-1 day in DB.
        String query = "update ICC_INFO set usage_end_date='" + date + "' where ICC_NUMBER=(select ICC_NUMBER from icc_info_details where urn=" + urn + ");";
        DB.executeQuery(query);
        //To run the card expiry job in EOD Batch jobs
        EOD_Login_Page eod_page = new EOD_Login_Page(driver);
//        eod_page.browseEODApp(Generic.getPropValues("EOD_JOBS_URL"));
        eod_page.eodLogin("admin", "password");
        eod_page.selectBank("BOB");
        Generic.wait(05);
        try {
            String status = eod_page.wibmoExecuteEODJob("Card Expiry");
            System.out.println("The Job Status:" + status);
        } catch (Exception e) {
            e.printStackTrace();
        }
// To Login to csr application and verify the card status
        LoginPage loginPage = new LoginPage(driver);
        driver.get(Generic.getPropValues("CSR_URl"));
        loginPage.csrLogin("admin", "password2026");
        SearchCardDetailsPage searchPage = new SearchCardDetailsPage(driver);
        searchPage.submitCardDetails(urn);
        TransactionDetailsPage transactionPage = new TransactionDetailsPage(driver);
        Boolean cardStatus = transactionPage.verifyCardStatus("ICC_EXPIRED");
        if (cardStatus == true) {
            System.out.println("The Card status is Expired In csr  Transaction Details Page");
        } else {
            System.out.println("The card status updation is Failed");
        }
        Boolean usageEndDate = transactionPage.verifyCardUsageEnddate(date);
        if (usageEndDate == true) {
            System.out.println("The Usage end date is updated correctly in csr Transaction Details page.");

        } else {
            System.out.println("The Usage end date is not updated correctly in csr Transaction Details page.");
        }
        // To Run stored procedures related to card balance and fund recon.
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.106.74:3306/bob_kenya_prepaid_reporting", "reportapp", "report@123");

            CallableStatement stmt = conn.prepareCall("{call card_balance_trigger_today}");
            ResultSet rs = stmt.executeQuery();

            stmt = conn.prepareCall("{call fund_recon_v1_1(curdate()+interval 1 day)}");
            rs = stmt.executeQuery();


        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            DB.closeDB();
        }
        ReportsHomePage reportsPage = new ReportsHomePage(driver);
        reportsPage.clickFundReconLink();
        FundReconPage fundReconPage = new FundReconPage(driver);
        fundReconPage.submitParameterDetails(productName);
        Assert.assertTrue(fundReconPage.verifyFundReconPage());
        String expiredCardAmount = fundReconPage.getExpiredAmntInReconReport();
        System.out.println("The Expired Card Amount: " + expiredCardAmount);
        Boolean expiredCardStatus = fundReconPage.expiredCardDetails(urn);
        if (expiredCardStatus) {
            Assert.assertTrue(true);
            System.out.println("The Card details are displayed in drill down page in fund recon");
        } else {
            Assert.assertTrue(false);
            System.out.println("The Card details are not displayed in drill down page in fund recon");
        }
    }
}

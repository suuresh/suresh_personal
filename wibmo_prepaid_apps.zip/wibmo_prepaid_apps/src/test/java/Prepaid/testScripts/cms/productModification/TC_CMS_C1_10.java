package Prepaid.testScripts.cms.productModification;

import Prepaid.pageRepo.cms.ReplaceCardReqPage;
import Prepaid.testScripts.cms.BaseTest;
import org.testng.annotations.Test;

public class TC_CMS_C1_10 extends BaseTest {

     /* @Test
    public void TC_CMS_C1_10(){
      //to Login
        cmsLogin();
        String tc_id="TC_CMS_C1_10";
        String cardNumber=getValByKey(tc_id,"cardNumber");
        ReplaceCardReqPage replaceCardReqPage=new ReplaceCardReqPage(driver);
       replaceCardReqPage.replaceCardReqForm(cardNumber);
    }*/
}

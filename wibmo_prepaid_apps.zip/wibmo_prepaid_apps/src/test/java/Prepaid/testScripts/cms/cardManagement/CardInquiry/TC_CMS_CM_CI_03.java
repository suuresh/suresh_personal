package Prepaid.testScripts.cms.cardManagement.CardInquiry;

import Prepaid.pageRepo.cms.CardInquiryPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.testScripts.cms.BaseTest;
import library.Generic;
import org.testng.Assert;

//@Author - Srikiran
//TestCase - To Verify new field 'Debit account number' under card holder details in card enquiry

public class TC_CMS_CM_CI_03 extends BaseTest {
	public void TC_CMS_CM_CI_03(){
		try {
			String tc_id = "TC_CMS_CM_CI_03";
			String paymentMode = getValByKey(tc_id, "cardnumber"), transactionRefNumber = getValByKey(tc_id, "pin"),
					cardNumber = getValByKey(tc_id, "pin"),
					debitAccountNumber = getValByKey(tc_id, "pin");

			LoginPage lp = new LoginPage(driver);
			driver.get(getAppURL("cms"));
			String[] Credentials = getAppCredentials("cms");
			String user = Credentials[0];
			String pass = Credentials[1];
			lp.cmsLogin(user, pass);

			CardInquiryPage ci = new CardInquiryPage(driver);

			ci.navigateToCardInquiry();
			ci.doCardInquiryBy("Card Number", cardNumber);
			Assert.assertTrue(ci.assertCardNumber(cardNumber));
			Assert.assertTrue(ci.assertCardDetails("Debit Account Number", debitAccountNumber));
			Generic.getFullPageScreenshot(driver, tc_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

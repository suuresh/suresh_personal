package Prepaid.testScripts;

import io.github.bonigarcia.wdm.WebDriverManager;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
//import org.apache.jackrabbit.webdav.WebdavRequest;
import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.*;


/**
 * The Class Prepaid.testScripts.BaseTest1.
 *
 */
public class BaseTest1 extends BaseClass// BaseClass=Execution,   BaseDev=Development
{

	/** The old mvc. */
	protected static String oldMvc = "606606"; // Default value
//	protected static boolean ssoUp = (boolean) getSsoStatus();
	protected static boolean otpMsg = false;

	public static final	String BANK = Generic.getPropValues("BANK");
	public static final	String ENV = Generic.getPropValues("ENV");
	public static final	String EXECUTION = Generic.getPropValues("EXECUTION");
	public static final	String BROWSER = Generic.getPropValues("BROWSER");


	public static final String CONFIG_XLSX_PATH = System.getProperty("user.dir")+File.separator+"config"+File.separator+"config.xlsx";
	public static final String TEST_EXECUTION_DATA_XLSX_PATH = System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+ ENV +File.separator+"Web"+File.separator+"TestExecution_Data"+File.separator+ BANK +"_TestData.xlsx";
	public static final String TESTDATA_INI_PATH = System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+ ENV +File.separator+"Web"+File.separator+"TestData.ini";
	public static final String TRANSACTION_XLSX_FILE_PATH = System.getProperty("user.dir")+ File.separator+"excel_lib"+File.separator+"Authorization_TestData.xlsx";
	public static final String APIPAYLOAD_TESTDATA_XLSX_FILE_PATH = System.getProperty("user.dir")+ File.separator+"excel_lib"+File.separator+"API_TestData.xlsx";
	public static final String APIREQUESTBODY_TESTDATA_XLSX_FILE_PATH = System.getProperty("user.dir")+ File.separator+"excel_lib"+File.separator+"API_RequestBody_TestInput.xlsx";


	/**
	 * The SDK WebDriver to corrersponding udid map. csr.wdriver(driver) needs to
	 * access udid for non Android driver.
	 *
	 */
	public static HashMap<Integer, String> sdkDriverUdid = new HashMap<Integer, String>();

	public static boolean appDataClear;
	private static boolean ITP = false, phoneVerification = false;
	public static String autVersion = " ";

	/** Used to store as udid=newlyRegisteredMobileNumber */
	public static HashMap<String, PriorityQueue<String>> newlyRegisteredMobileNos = new HashMap<String, PriorityQueue<String>>();

	public static ChromeDriverService chromeService;

//	@iOSXCUITFindBy(iOSNsPredicate = "type='XCUIElementTypeButton' and name ='Proceed'")
//	private WebElement proceedButton;

	// public static final String iniPath = "./excel_lib/" + env + '/'
	// +"android"+'/'+ "TestData.ini";

	/**
	 * The Map used to check if the device is currently executing Web Overlay flow.
	 * Set to false from BaseTest of Respective package. Set to true from the Test
	 * Script executing Web Overlay.
	 */
	private static HashMap<String, Boolean> webOverlayStatus = new HashMap<String, Boolean>();

	public String getTestData(String tcId) {
		return getTestVal(tcId, "data");
	}

	public String getTestScenario(String tcId) {
		return getTestVal(tcId, "scenario"); // Test Description
	}

	/**
	 * @author aravindanath
	 *
	 * @return value of the specified key under the given title
	 */

	public String getValByKey(String tcId, String key) {
		String environment = env.contains("uat") ? "uat" : "qa";
		String platform = ExcelLibrary.getExcelData("./config/config.xlsx", "Android_setup", 8, 2); // read

		path = System.getProperty("user.dir") + File.separator + "excel_lib" + File.separator + environment
					+ File.separator + platform + File.separator + "TestData.ini";
		Ini ini = null;
		try {
			// System.out.println(path);
			ini = new Ini(new File(path));
		} catch (IOException e) {
			Assert.fail("TestData.ini file not found");
		}

		String value = ini.get(tcId, key);
		if ((value == null))
			Assert.fail(key + " value not found for " + tcId);

		return value;
	}

	/**
	 * Retrieves the value corresponding to the key in a key=value csv Ex :
	 * loginId=9742410718,securePin=1234
	 *
	 * @param csvData
	 * @param key
	 * @return value corresponding to the key
	 */
	public String getVal(String csvData, String key) {
		if (!csvData.contains(key))
			Log.info("Warning : " + key + " not found in TestData ");

		return csvData.split(key + '=')[1].split(",")[0];
	}

	/**
	 * @author aravindanath
	 *
	 * @return
	 * @throws InvalidFileFormatException
	 * @throws IOException
	 */



	/**
	 * Rerieves the simType (Prepaid or Postpaid) as specified in Devices.ini based
	 * on the udid
	 *
	 * @param udid
	 */
	public static String getSimType(String udid) {
		String path = "./config/" + env + '/' + "Devices.ini";

		Ini ini = null;
		try {
			ini = new Ini(new File(path));
		} catch (IOException e) {
			Assert.fail("Devices.ini file not found");
		}

		String simType = ini.get(udid, "simType");
		if ((simType == null))
			Assert.fail("SimType value not found for " + udid);
		return simType;
	}

	public String getPlatform() {
		String platform = "";

		if (Generic.isAndroid(driver))
			platform = "Android";
		if (Generic.isIos(driver))
			platform = "IOS";

		// if driver==null
		// set platform based on package name for non driver execution

		return platform;
	}

	public String getTestVal(String tcId, String val) {
		int col = val.equals("data") ? 2 : 1; // TestData:TestScenario
//		String environment = env.contains("uat") ? "uat" : "qa";
		String tcRowVal;
		String platform ="web",
				//path = "./excel_lib"+File.separator+"TestData.xlsx";
path=System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+"TestData.xlsx";
//		@author:Srikiran
		System.out.println(this.getClass().getCanonicalName().split("testScripts.")[1]);
		ArrayList<String> testclasspath = new ArrayList<String>(Arrays.asList(this.getClass().getCanonicalName().split("testScripts.")[1].split("\\.")));
//		String module = testclasspath.get(testclasspath.indexOf(testclasspath.get(testclasspath.size()-2)));
		String module = testclasspath.get(1);
		String testPackage = testclasspath.get(0);
		System.out.println("TestData.xls sheet: "+testPackage+"_"+module);
		String sheet = testPackage; //testPackage+"_"+module;
		int rc = ExcelLibrary.getExcelRowCount(path, sheet);
		System.out.println("Row count"+rc+" Path"+path+" Sheet"+sheet);
		for (int i = 0; i <= rc; i++) {
			tcRowVal = ExcelLibrary.getExcelData(path, sheet, i, 0);
			if (tcRowVal.equals(tcId))
				return ExcelLibrary.getExcelData(path, sheet, i, col);
		}
		return "DefaultVal" + tcId + ':' + sheet;
	}

	/**
	 * Sets the ITP falg to true, to be used by VerifyPhonePage If ITP flag is true
	 * then Phone Verification is triggered under VerifyPhonePage
	 *
	 */
	public static void setITP(boolean ITPStatus) {
		ITP = ITPStatus;
	}

	public static boolean getITP() {
		return ITP;
	}

	public static void setPhoneVerifyStatus(boolean phoneVerifyStatus) {
		phoneVerification = phoneVerifyStatus;
	}

	public static boolean getPhoneVerifyStatus() {
		return phoneVerification;
	}

	public static void setWebOverlayStatus(WebDriver driver, boolean status) {
		if (driver == null)
			return;
		if (!Generic.checkAndroid(driver))
			return;

		webOverlayStatus.put(Generic.getUdId(driver), status);
	}

	public static boolean getWebOverlayStatus(WebDriver driver) {
		if (!Generic.checkAndroid(driver))
			return true;

		String udid = Generic.getUdId(driver);

		if (webOverlayStatus.containsKey(udid))
			return webOverlayStatus.get(udid);
		else
			return false;
	}



	public void navigateBack() {
		System.out.println("Navigating Back");
		driver.navigate().back();
	}





 /*

	public static void main(String[] args) {
		BaseTest1 bt = new BaseTest1();
		System.out.println(bt.getTestData("TC_Priority_001"));
	}


  */

	/**
	 * @author aravindanathdm
	 * @return
	 */
	public static Object getSsoStatus() {

		String sheet = "Android_setup";
		Object tcRowVal = "";

		int udidColumn = 8, ssoStatus = 8; // Column Offset
		tcRowVal = ExcelLibrary.getBooleanExcelData(configXLPath, sheet, ssoStatus, udidColumn);
		System.err.println("SSO STATUS is UP ? " + tcRowVal);
		return tcRowVal;

	}

	/**
	 * @author aravindanathdm
	 * @return KillIosApp works only for iphone devices only
	 */

	public static void killIOSApp(String udid) {
		String adbCommand = "idb uninstall com.wibmo.qa.bdo --udid " + udid + "";
		try {
			System.out.println(adbCommand);
			Runtime.getRuntime().exec(adbCommand);
			Generic.wait(10);
			System.out.println("** App uninstalled sucessfully!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author aravindanathdm
	 * @return KillIosApp works only for iphone devices only
	 */

	public static void killIOSApp() {
		String adbCommand = "ideviceinstaller -U com.wibmo.qa.bdo";
		try {
			System.out.println(adbCommand);
			Runtime.getRuntime().exec(adbCommand);
			Generic.wait(10);
			System.out.println("** App uninstalled sucessfully!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author aravindanathdm
	 * @return InstalliOSApp Methos works for iphone devices only
	 */
	public static void installiOSApp(String udid, String path) {
		String adbCommand = "idb install " + path + " --udid " + udid + "";
		try {
			System.out.println(adbCommand);
			Runtime.getRuntime().exec(adbCommand);
			System.out.println("** App installed sucessfully!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getAppURL(String application){
		String url=null;
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_domain", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", ENV, "Row");

		String domain = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		switch(application)
		{
			case "csr":
				url = "https://"+domain+"/csr/";
				System.out.println("Application URL: "+url);
				break;
			case "cms":
				url = "https://"+domain+"/prepaid/cms";
				System.out.println("Application URL: "+url);
				break;
			case "CustomerPortal":
				url = "https://"+domain+"/prepaid/cms/customer";
				System.out.println("Application URL: "+url);
				break;
			case "HSMEncryption":
				url = "https://"+domain+"/utils/pkcsEnc.jsp";
				System.out.println("Application URL: "+url);
				break;
			case "HSMDecryption":
				url = "https://"+domain+"/utils/pkcsDec.jsp";
				System.out.println("Application URL: "+url);
				break;
			case "AuthJSP":
				url = "https://"+domain+"/utils/acq/acqfront.jsp";
				System.out.println("Application URL: "+url);
				break;
			case "eod":
                url = "https://"+domain+"/batch-web/";
                System.out.println("EOD Application URL: "+url);
				break;
			case "ExternalReports":

				break;
			//Settlement app
			case "Settlement":
				url = "https://"+domain+"/utils/enc/encFileUpload.jsp";
				System.out.println("Application URL: "+url);
				break;
		}
		Log.info("Navigating to url :"+url);
		return url;
	}

	public static String[]  getAppCredentials(String application){
		String url=null;
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_credential", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", ENV +"_"+application, "Row");
		String username_Password = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		String[] un = username_Password.split(",");
		return un;
	}

	public static String  getBinDetails(){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_bin", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", "bin", "Row");
		String bin = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		return bin;
	}

	/**
	 * This method is used to initiate new browser and launch the application URL.
	 *
	 * @param browserName
	 */
	public WebDriver initBrowser(String browserName, String application) {
		String downloadFilepath = System.getProperty("user.dir")+File.separator+"Downloads";
//		WebDriver driver;
		if(driver==null) {
			if (browserName.equalsIgnoreCase("chrome")) {
//			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+File.separator+"softwares"+File.separator+"chromedriver.exe");
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 0);
				chromePrefs.put("download.default_directory", downloadFilepath);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", chromePrefs);
				options.addArguments("--disable-notifications");
				DesiredCapabilities cap = DesiredCapabilities.chrome();
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				cap.setCapability(ChromeOptions.CAPABILITY, options);
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver(options);
			} else {
//				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + File.separator + "softwares" + File.separator + "geckodriver.exe");
				DesiredCapabilities cap = DesiredCapabilities.firefox();
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				cap.setCapability("marionette", false);
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
			}
		}
		driver.get(getAppURL(application));
		WebDriverWait wait = new WebDriverWait(driver, 30000);
		driver.manage().window().maximize();
		return driver;
	}

	public void openNewTab(String url){
//		Actions action = new Actions(driver); action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).build().perform(); //opening the URL saved.
		((JavascriptExecutor)driver).executeScript("window.open()");
		Generic.wait(3);
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		Generic.wait(2);
		driver.get(url);
		Generic.wait(5);
	}

	public static String[] getAuthIP_PORT(String cardUnion){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_"+cardUnion+"_auth", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", ENV, "Row");
		String ip_port = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		return ip_port.split(",");
	}

	public static String getBankID(){
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", BANK +"_bankId", "Row");
		String bank_id = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"API_Details", row, 1);
		return bank_id;
	}
	public static String getapiPostUrl(String apiEvent){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", BANK +"_apidomain", "Column");
		//System.out.println(column);
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", ENV, "Row");
		//System.out.println(row);
		String api_domain = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"API_Details", row, column);

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", apiEvent, "Row");
		//System.out.println(row);
		String url = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"API_Details", row, 1);
		System.out.println("API Post URL: "+"https://"+api_domain+"/v1/"+getBankID()+url);
		return "https://"+api_domain+"/v1/"+getBankID()+url;
	}

	public static String getTransactionEventCode(String transactionEvent){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", "Transaction_Event", "Column")+1;
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"API_Details", transactionEvent, "Row");
		return ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"API_Details", row, column);
	}

	public static String[] getRedisIp_Port(){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_redisServer", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", ENV, "Row");
		String ip_port = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		return ip_port.split(":");
	}

	public static String[] getHSM_ip_port_key(){
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", BANK +"_hsmip_port_key", "Column");
		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Web_App_Details", ENV, "Row");
		String ip_port_key = ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Web_App_Details", row, column);
		return ip_port_key.split(",");
	}

	public static HashMap<String, String>  getDBDetails(){

		HashMap<String, String> dbDetails = new HashMap<String, String>();
		int column = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", BANK +"_dbDetails", "Column");

		int row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_IP", "Row");
		dbDetails.put("ip", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_Port", "Row");
		dbDetails.put("port", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_Username", "Row");
		dbDetails.put("username", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_Password", "Row");
		dbDetails.put("password", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_AccosaSchema", "Row");
		dbDetails.put("accosa", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_CommonSchema", "Row");
		dbDetails.put("common", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		row = ExcelLibrary.searchTextFindCellRoworColumn(CONFIG_XLSX_PATH,"Database_Details", ENV +"_PrepaidSchema", "Row");
		dbDetails.put("prepaid", ExcelLibrary.getExcelData(CONFIG_XLSX_PATH,"Database_Details", row, column));

		return dbDetails;
	}

	public HashMap<String, String> getCardPersoDetails(){
		HashMap cardPersoDetails = new HashMap();
		int rows = ExcelLibrary.getExcelRowCount(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail");
		int i=0;
		for (i=1; i<=rows; i++){
			String celldata = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i,8);
			if(celldata.length()==0 || celldata==" " || celldata==""){
				break;
			}
		}
		cardPersoDetails.put("cardNumber", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 1));
		cardPersoDetails.put("exipry", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 2));
		cardPersoDetails.put("cvv2", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 3));
		cardPersoDetails.put("serviceCode", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 4));
		cardPersoDetails.put("cvv", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 5));
		cardPersoDetails.put("Track2Data", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 6));
		cardPersoDetails.put("icvv", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 7));
		return cardPersoDetails;
	}

	public HashMap<String, String> getCardPinDetails(){
		HashMap cardPinDetails = new HashMap();
		int rows = ExcelLibrary.getExcelRowCount(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail");
		int i=0;
		for (i=1; i<=rows; i++){
			String celldata = ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i,8);
			if(celldata.length()==0){
				break;
			}
		}
		cardPinDetails.put("product", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 0));
		cardPinDetails.put("urn", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 1));
		cardPinDetails.put("cardNumber", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 2));
		cardPinDetails.put("pin", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 3));
		cardPinDetails.put("ipin", ExcelLibrary.getExcelData(TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 4));
		return cardPinDetails;
	}
}

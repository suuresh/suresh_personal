package Prepaid.testScripts;

public class Test1 {



    public static void main(String args[]){
        String value = "A1b2c3!@#";

        StringBuilder integer = new StringBuilder();
        StringBuilder character = new StringBuilder();
        StringBuilder special = new StringBuilder();

        char string[] = value.toCharArray();
        for(int i=0; i<string.length;i++){

            if(Character.isDigit(string[i])){
                integer.append(string[i]);
            }

            if(Character.isAlphabetic(string[i])){
                character.append(string[i]);
            }

            if(Character.isSpaceChar(string[i])){
                special.append(string[i]);
            }

        }

        System.out.println("Integer :"+integer);
        System.out.println("Character :"+character);
        System.out.println("Special :"+new String(special));
    }





}

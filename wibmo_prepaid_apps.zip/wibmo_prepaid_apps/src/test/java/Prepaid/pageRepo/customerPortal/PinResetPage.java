package Prepaid.pageRepo.customerPortal;

import Prepaid.pageRepo.BasePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

/**
 * The Class Login page
 */
public class PinResetPage extends BasePage {

	/** The driver. */
	private WebDriver driver;

	public PinResetPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);

	}


	@FindBy(xpath="//a[contains(text(),'Click here')]")
	private WebElement resetPinLink;

	@FindBy(xpath="//input[@id='cardNumber']")
	private WebElement cardNumberTextField;

	@FindBy(xpath="//input[@id='expiry']")
	private WebElement expiryTextField;

	@FindBy(xpath="//input[@id='mobile']")
	private WebElement mobileNumberTextField;

	@FindBy(xpath="//input[@id='dob']")
	private WebElement dobTextField;

	@FindBy(xpath="//input[@value=' Submit ']")
	private WebElement submitButton;

	@FindBy(xpath="//input[@value=' Cancel ']")
	private WebElement cancelButton;

	@FindBy(xpath="//span[contains(text(),' OTP is sent to your registered EmailId,       Mobile number,OTP is valid for 3 mins')]")
	private WebElement otpSentMessage;

	@FindBy(xpath="//input[@id='enterOTP']")
	private WebElement otpTextField;

	@FindBy(xpath = "//input[@id='Resend']")
	private WebElement resendOTPButton;

	@FindBy(xpath="//input[@id='Submit']")
	private WebElement submitOTPButton;

	@FindBy(xpath="//input[@id='Cancel']")
	private WebElement cancelOTPButton;

	@FindBy(xpath="//span[contains(text(),'OTP Has been Sent again,valid for 3 minutes')]")
	private WebElement otpResentMessage;

	@FindBy(xpath = "//form[@name='mailOrMobile']//span[contains(text(),'Entered otp is not correct.Please try again')]")
	private WebElement invaildOTPMessage;

	@FindBy(xpath = "//input[@name='newPin']")
	private WebElement newpinTextField;

	@FindBy(xpath = "//input[@name='confirmPin']")
	private WebElement confirmPinTextField;

	@FindBy(xpath ="//input[@id='submit']")
	private WebElement submitnewPinButton;

	@FindBy(xpath ="//input[@id='cancel']")
	private WebElement cancelnewPinButton;

	@FindBy(xpath = "//div[@id='mainbanner']//b[contains(text(),'Your PIN is updated,Please use new PIN to login')]")
	private WebElement pinUpdatedSuccessMsg;

	@FindBy(xpath="//div[@id='success']/p/span")
	private WebElement pinResetErrorMessage;

	@FindBy(xpath="//div[@id='mainbanner']//font/b")
	private WebElement loginpageErrorMessage;

	@FindBy(xpath = "//a[contains(text(), 'Log Off')]")
	private WebElement logoffLink;

	@FindBy(xpath = "//a[contains(text(), 'Home')]")
	private WebElement homeLink;


	@FindBy(xpath = "//form[@name='newPinReset']//span[contains(text(),'New pin does not match with Confirm New pin.Please try again')]")
	private WebElement resetPinMismatchMessage;

	public void resetPin(){
		resetPinLink.click();
	}

	public void enterCardNumber(String cardNumber){
		cardNumberTextField.clear();
		cardNumberTextField.sendKeys(cardNumber);
	}

	public void enterCardExpiry(String cardExpiry){
		expiryTextField.clear();
		expiryTextField.sendKeys(cardExpiry);
	}

	public void enterMobileNumber(String mobileNumber){
		mobileNumberTextField.clear();
		mobileNumberTextField.sendKeys(mobileNumber);
	}

	public void enterDOB(String dob){
		dobTextField.clear();
		dob = Generic.formatDate(dob, "dd-mm-yyyy");
		dobTextField.sendKeys(dob);
	}

	public void submitResetPinRequest(){
		submitButton.click();
	}

	public void submitResetPinRequest(String cardNumber, String expiry, String mobileNumber, String dob){
		enterCardNumber(cardNumber);
		enterCardExpiry(expiry);
		enterMobileNumber(mobileNumber);
		enterDOB(dob);
		submitResetPinRequest();
		Generic.wait(5);
	}

	public void enterOPT(String otp){
		otpTextField.clear();
		otpTextField.sendKeys(otp);
	}

	public void submitOTPValidation(){
		submitOTPButton.click();
	}

	public void cancelOTPValidation(){
		cancelOTPButton.click();
	}

	public void resendOTP(){
		resendOTPButton.click();
	}

	public boolean assertOTPResent(){
		return otpResentMessage.isDisplayed();
	}

	public boolean assertInvalidOTPMessage(){
		return invaildOTPMessage.isDisplayed();
	}

	public void enterNewPin(String newPin){
		newpinTextField.sendKeys();
	}

	public void enterConfirmNewPin(String newPin){
		confirmPinTextField.sendKeys();
	}

	public void submitNewPinUpdate(){
		submitnewPinButton.click();
	}

	public void submitnewPinChangeRequest(String newPin){
		enterNewPin(newPin);
		enterConfirmNewPin(newPin);
		submitNewPinUpdate();
	}

	public void cancelnewPinChangeRequest(){
		cancelnewPinButton.click();
	}

	public boolean assertPinChangedSuccessfully(){
		return pinUpdatedSuccessMsg.isDisplayed();
	}

	public boolean assertPinChangeErrorMessageDisplayed(){
		return pinResetErrorMessage.getText().equalsIgnoreCase("Entered details don't match with the registered details.Please try again");
	}

	public boolean assertPinChangeLastOptionErrorMessageDisplayed(){
		return pinResetErrorMessage.getText().equalsIgnoreCase("This is your last chance to enter correct details.Please try again");
	}

	public boolean assertLoginPageErrorMessageisDisplayed(){
		return loginpageErrorMessage.getText().equalsIgnoreCase("You have exceeded the number of attempts to enter \n" +
				" card details. please login and again try to change PIN");
	}

	public boolean assertlogoffLinkDisplaying(){
		return logoffLink.isDisplayed();
	}

	public boolean assertHomeLinkDisplaying(){
		return homeLink.isDisplayed();
	}

	public boolean assertResetPinMismatchMessage(){
		return resetPinMismatchMessage.isDisplayed();
	}
}
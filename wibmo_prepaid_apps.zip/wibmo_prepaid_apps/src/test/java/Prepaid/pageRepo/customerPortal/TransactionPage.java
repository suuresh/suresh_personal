package Prepaid.pageRepo.customerPortal;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TransactionPage extends BasePage {
    private static WebDriver driver;

    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public TransactionPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//strong[text()='Card Summary']")
    private WebElement cardSummary;
    @FindBy(xpath = "//div[@class='mainbannerImg']//img[contains(@src,'bob')]")
    private WebElement productImage;

    public Boolean verifyProductImage() {
        try {
            return (productImage.isDisplayed());

        } catch (NoSuchElementException e) {
            return false;
        }
    }
}

package Prepaid.pageRepo.customerPortal;

import Prepaid.pageRepo.BasePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import library.Generic;
import library.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

/**
 * The Class Login page
 */
public class LoginPage extends BasePage {

	/** The driver. */
	private WebDriver driver;

	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		Generic.wait(10);
		PageFactory.initElements(this.driver, this);

	}


	@FindBy(id = "textCCNumber")
	private WebElement cardNumberTextField;


	@FindBy(id = "textPin")
	private WebElement pinTextField;


	@FindBy(xpath = "//div[@id='mainbanner']/form/table/tbody/tr[3]/td[2]/input")
	private WebElement submitButton;


	@FindBy(xpath = "//a[contains(text(), 'Click here')]")
	private WebElement passwordresetlink;

	@FindBy(xpath="//div[@id='mainbanner']//b[contains(text(), 'Invalid PIN you have remaining 2 attempts')]")
	private WebElement incorrectpassword2AttemptsMsgText;

	@FindBy(xpath="//div[@id='mainbanner']//b[contains(text(), 'This is your last attempt. If you enter wrong PIN this time, your card will be blocked .')]")
	private WebElement incorrectpasswordLastAttemptMsgText;

	@FindBy(xpath="//div[@id='mainbanner']//b[contains(text(), 'Your Login has been blocked, Please contact customer service.')]")
	private WebElement loginblockedMsgText;

	@FindBy(xpath = "//td[contains(text(), 'Card Number')]//following-sibling::td")
	private WebElement loggedinMaskedCardNumber;

	@FindBy(xpath = "//a[contains(text(),'Summary')]")
	private WebElement cardSummaryLink;

	@FindBy(xpath = "//a[contains(text(), 'Log Off')]")
	private WebElement logOffLink;



	public void enterCardNumber(String cardNumber){
		cardNumberTextField.clear();
		cardNumberTextField.sendKeys(cardNumber);
	}

	public void enterPin(String pin){
		pinTextField.clear();
		pinTextField.sendKeys(pin);
	}

	public boolean assertLoggedCardUser(String cardNumber){
		Log.info("User logged in is "+ loggedinMaskedCardNumber.getText());
		return loggedinMaskedCardNumber.getText().replaceAll("\\s", "").equalsIgnoreCase(Generic.getMaskedCardNumber(cardNumber));
	}

	public boolean assert2AttemptPendingMsg(){
		return incorrectpassword2AttemptsMsgText.isDisplayed();
	}

	public boolean assertLastAttemptPinMsg(){
		return incorrectpasswordLastAttemptMsgText.isDisplayed();
	}

	public boolean assertLoginBlocked(){
		return loginblockedMsgText.isDisplayed();
	}

	public void loginToCustomerPortal(String cardNumber, String pin){
		Log.info("Credentials Entry CardNumber: "+ cardNumber+" , Pin: "+pin);
		enterCardNumber(cardNumber);
		enterPin(pin);
		submitButton.click();
		Generic.wait(2);
	}

	public void logoffCustomerPortal(){
		logOffLink.click();
	}

	public boolean assertUserLoggedOff(){
		return cardNumberTextField.isDisplayed();
	}
}
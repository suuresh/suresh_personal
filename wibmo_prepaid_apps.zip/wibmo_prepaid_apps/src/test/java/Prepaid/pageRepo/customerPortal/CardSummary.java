package Prepaid.pageRepo.customerPortal;

import Prepaid.pageRepo.BasePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import library.Generic;
import library.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.List;

public class CardSummary extends BasePage {

    /** The driver. */
    private WebDriver driver;

    public CardSummary(WebDriver driver) {
        super(driver);
        this.driver = driver;
        Generic.wait(10);
        PageFactory.initElements(this.driver, this);

    }


    @FindBy (xpath = "//div[@id='success']//table[1]")
    WebElement cardSummarySection;

    @FindBy(xpath = "//td[contains(text(), 'Card Number')]")
    private WebElement cardNumberLable;

    @FindBy(xpath = "//td[contains(text(), 'Card Number')]//following-sibling::td")
    private WebElement maskedCardNumberValue;

    @FindBy(xpath = "//td[contains(text(), 'Card Usage End Date')]")
    private WebElement cardUsageEndDateLable;

    @FindBy(xpath = "//td[contains(text(), 'Card Usage End Date')]//following-sibling::td")
    private WebElement cardUsageEndDateValue;

    @FindBy(xpath = "//td[contains(text(), 'Card Limit')]")
    private WebElement cardLimitLable;

    @FindBy(xpath = "//td[contains(text(), 'Card Limit')]//following-sibling::td")
    private WebElement cardLimitValue;

    @FindBy(xpath = "//td[contains(text(), 'Total Purchase')]")
    private WebElement totalPurchaseLable;

    @FindBy(xpath = "//td[contains(text(), 'Total Purchase')]//following-sibling::td")
    private WebElement totalPurchaseValue;

    @FindBy(xpath = "//td[contains(text(), 'Unbilled Amount')]")
    private WebElement unbilledAmountLable;

    @FindBy(xpath = "//td[contains(text(), 'Unbilled Amount')]//following-sibling::td")
    private WebElement unbilledAmountValue;

    @FindBy(xpath = "//td[contains(text(), 'Available Balance')]")
    private WebElement availableBlanaceLable;

    @FindBy(xpath = "//td[contains(text(), 'Available Balance')]//following-sibling::td")
    private WebElement availableBlanaceValue;

    @FindBy(xpath = "//td[contains(text(), 'Product')]")
    private WebElement productLable;

    @FindBy(xpath = "//td[contains(text(), 'Product')]//following-sibling::td")
    private WebElement productValue;

    @FindBy(xpath = "//td[contains(text(), 'Card Status')]")
    private WebElement cardStatusLable;

    @FindBy(xpath = "//td[contains(text(), 'Card Status')]//following-sibling::td")
    private WebElement cardStatusValue;

    //Card Transaction Section

    @FindBy (xpath = "//div[@id='success']//table[2]")
    WebElement cardTransactionSection;


    public boolean assertLoggedCardUser(String cardNumber){
        Log.info("User logged in is "+ cardNumberLable.getText());
        return maskedCardNumberValue.getText().replaceAll("\\s", "").equalsIgnoreCase(Generic.getMaskedCardNumber(cardNumber));
    }

    public void assertCardSummary(){
        //CardNumber
        Generic.assertTitle(cardNumberLable, "Card Number :");
        Generic.assertTitleValuesDisplaying(cardNumberLable);
        //Card Usage End Date
        Generic.assertTitle(cardUsageEndDateLable, "Card Usage End Date:");
        Generic.assertTitleValuesDisplaying(cardUsageEndDateLable);
        //Card Limit
        Generic.assertTitle(cardLimitLable, "Card Limit:");
        Generic.assertTitleValuesDisplaying(cardLimitLable);
        //Total Purchase
        Generic.assertTitle(totalPurchaseLable, "Total Purchase:");
        Generic.assertTitleValuesDisplaying(totalPurchaseLable);
        //Unbilled Balance
        Generic.assertTitle(unbilledAmountLable, "Unbilled Amount :");
        Generic.assertTitleValuesDisplaying(unbilledAmountLable);
        //Available Balance
        Generic.assertTitle(availableBlanaceLable, "Available Balance :");
        Generic.assertTitleValuesDisplaying(availableBlanaceLable);
        //Product
        Generic.assertTitle(productLable, "Product :");
        Generic.assertTitleValuesDisplaying(productLable);
        //Card Status
        Generic.assertTitle(cardStatusLable, "Card Status:");
        Generic.assertTitleValuesDisplaying(cardStatusLable);
    }

    public boolean assertTransactionSectionPopulatingTransaction(){
        String xpath = cardTransactionSection.toString()+"//tr";
        List <WebElement> records = driver.findElements(By.xpath(xpath));
        return records.size() > 1;
    }

    public boolean assertTransactionHeaders(){
        List <WebElement> headers = driver.findElements(By.xpath("//table[2]//tr[1]//td[contains(text(),'Transaction')]"));
        return headers.size() == 4;
    }

    public boolean assertCardUsageEndDateValueFormat(){
        DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String actualDate = cardUsageEndDateValue.getText();
        try {
            df.parse(actualDate);
            Log.info("Valid Card usage end date is populated "+actualDate);
            return true;
        }catch(ParseException e){
            Log.info("Actual Card Usage End Date "+actualDate);
            return false;
        }
    }

    public boolean assertCardCurrencyFormat(String actualvalue){
        DecimalFormat df = new DecimalFormat("########.##");
        try {
            df.parse(actualvalue).doubleValue();
            Log.info("Valid Card currency format is populated "+actualvalue);
            return true;
        }catch(ParseException e){
            Log.info("Actual Card currency format "+actualvalue);
            return false;
        }
    }

    public boolean assertCardLimitValue(){
        return assertCardCurrencyFormat(cardLimitValue.getText());
    }

    public boolean assertTotalPurcahaseValue(){
        return assertCardCurrencyFormat(totalPurchaseValue.getText());
    }

    public boolean assertUnbilledAmountValue(){
        return assertCardCurrencyFormat(unbilledAmountValue.getText());
    }

    public boolean assertAvailableBalanceValue(){
        return assertCardCurrencyFormat(availableBlanaceValue.getText());
    }

    public boolean assertCardStatusValue(){
        switch(cardStatusValue.getText()){
            case "Active":
                return true;
            case "Cancelled":
                return true;
            case "Temporary Blocked":
                return true;
            case "Permanent Blocked":
                return true;
            default:
                return false;
        }
    }

}

package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import library.Generic;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class LoginPage extends BasePage {


    /** The driver. */
    private WebDriver driver;

    public LoginPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
        }


    @FindBy(xpath = "//input[@name='txtUserId']")
    WebElement userIDTextBox;

    @FindBy(xpath = "//input[@name='txtPassword']")
    WebElement passwordTextBox;

    @FindBy(xpath = "//input[@name='submit']")
    WebElement signinButton;

    @FindBy(xpath = "//a/b[contains(text(), 'Sign Out')]")
    WebElement signoutLink;

    @FindBy(xpath="//a[@href='/csr/accosa/AccosaLite.jsp']")
    public WebElement accosaLiteLink;

    //left Frame
    @FindBy(xpath="//iframe[@src='leftmenu.jsp']")
    public WebElement leftFrame;

    @FindBy(xpath="//a[text()='Process By Card Number']")
    private WebElement processByCardNumber;



    public void enterUserID(String userID){
        userIDTextBox.sendKeys(userID);
    }

    public void enterPassword(String password){
        passwordTextBox.sendKeys(password);
    }

    public void signIn(){
        signinButton.click();
    }

    public boolean isuserloggedin(){
        try {
            return signoutLink.isDisplayed();
        }catch(NoSuchElementException e){
           return false;
        }
    }

    public void csrLogin(String userID, String password){
        if(isuserloggedin()){
            signoutLink.click();
        }
        enterUserID(userID);
        enterPassword(password);
        signIn();
    }



    public void navigateTo(String menu){
        accosaLiteLink.click();
        Generic.wait(5);
        driver.switchTo().frame(leftFrame);

        switch(menu){
            case"Process By Card Number":
                processByCardNumber.click();
                Generic.wait(5);
                break;
        }
        driver.switchTo().defaultContent();
    }



}

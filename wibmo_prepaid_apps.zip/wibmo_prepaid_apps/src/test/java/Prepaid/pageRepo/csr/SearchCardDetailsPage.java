package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchCardDetailsPage extends BasePage {
    private static WebDriver driver;
    public SearchCardDetailsPage(WebDriver driver){
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(xpath="//a[@href='/csr/accosa/AccosaLite.jsp']")
    public WebElement accosaLiteLink;
    @FindBy(name="txtSearch")
    private WebElement cardNumberField;
    @FindBy(name="urn")
    private WebElement urnField;
    @FindBy(name="btnSearch")
    private WebElement search;

public void enterCardDetails(String urnNum){
    accosaLiteLink.click();
    urnField.sendKeys(urnNum);
   }
public void submitCardDetails(String urn){
    enterCardDetails(urn);
    search.click();
}
}

package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TransactionDetailsPage extends BasePage {
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    private WebDriver driver;
    public TransactionDetailsPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
 @FindBy(xpath=" //tr/td[contains(text(),'Status')]/following-sibling::td/font")
    private WebElement status;
@FindBy(xpath="//tr//td[contains(text(),'Usage End')]/following-sibling::td")
    private WebElement usage_end_date;

public Boolean verifyCardStatus(String cardStatus) {
    Boolean iscardExpired = false;
    if (status.getText().trim().equals(cardStatus)) {
        iscardExpired = true;
        return iscardExpired;
    } else {
       return  iscardExpired;
    }
}

public Boolean verifyCardUsageEnddate(String usageEnddate){
    Boolean status=false;
    if (usage_end_date.getText().trim().equals(usageEnddate)) {
        status = true;
        return status;
    } else {
        return  status;
    }
}
}

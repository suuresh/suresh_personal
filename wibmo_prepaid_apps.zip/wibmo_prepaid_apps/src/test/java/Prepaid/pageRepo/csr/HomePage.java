package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import java.time.Duration;

public class HomePage extends BasePage {

    private WebDriver driver;

    public HomePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(this.driver, this);

    }

    @FindBy(xpath ="//a[@href='/csr/accosa/AccosaLite.jsp']/b")
    private WebElement aLite;


    @FindBy(xpath = "//a[@href='/csr/CSRUserHandler?perform=usersList']")
    private WebElement mantainance;


    @FindBy(xpath = "//a[@href='/csr/CSRUserHandler?perform=viewTimeZone']/b")
    private WebElement updateProfile;



    public void accosaLite1(){
        aLite.click();
    }

    public void updateProfile(){
        updateProfile.click();
    }


    public void mantainance(){
        mantainance.click();
    }

}

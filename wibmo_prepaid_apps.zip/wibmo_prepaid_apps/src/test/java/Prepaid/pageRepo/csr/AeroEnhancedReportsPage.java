/**
 * 
 */
package Prepaid.pageRepo.csr;

import com.relevantcodes.extentreports.LogStatus;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import java.util.HashMap;
import java.util.List;

/**
 * @author ${Srikiran}
 *
 */
public class AeroEnhancedReportsPage extends CSRBasePage
{	
	@FindBy (id="FromDate")
	private WebElement reportFromdate;
	
	@FindBy (id="ToDate")
	private WebElement reportToDate;
	
	@FindBy (id="parameterDialogokButton")
	private WebElement ok;
	
	@FindBy (xpath = "//b[contains(text(), 'Processing, please wait ...')]")
	public WebElement loadingDialog;
	
	private String summaryTable = "//table[@id='__bookmark_2']";
	
	@FindBy (name="exportReport")
	public WebElement exportReport;
	
	@FindBy (id="exportFormat")
	private WebElement exportFormat;
	
	@FindBy (id="exportPageAll")
	private WebElement exportPageAll;
	
	@FindBy (id="exportPageCurrent")
	private WebElement exportCurrentPage;
	
	@FindBy (id="exportPageRange")
	private WebElement exportPageRange;
	
	@FindBy (id="exportPageRange_input")
	private WebElement exportPageRangeInput;
	
	@FindBy (xpath="//div[@id='exportReportDialogdialogCustomButtonContainer']//input[@value='OK']")
	private WebElement exportOK;
	
	@FindBy (xpath="//input[@title='Cancel']")
	private WebElement exportCancel;
	
	@FindBy (xpath = "//div[@id='navigationBar']//input[@name='next']")
	public WebElement nextPage; 
	
	@FindBy (xpath = "//div[@id='navigationBar']//input[@name='last']")
	public WebElement lastPage; 
	
	@FindBy (xpath = "//div[@id='navigationBar']//input[@name='previous']")
	public WebElement previousPage;
	
	@FindBy (xpath = "//div[@id='navigationBar']//input[@name='first']")
	public WebElement firstPage; 
	
	@FindBy (xpath = "//div[@id='__BIRT_ROOT']")
	public WebElement reportGrid;

	private WebDriver driver;
	
	//Initialization of all the web elements
	
	public AeroEnhancedReportsPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	
	public void selectReport(String reportName){		
		driver.findElement(By.xpath("//a[contains(text(), '"+reportName+"')]")).click();
		}
	
	//Reload / Unload Report
	public void selectReportType(String reportType){	
		Select reporttype = new Select(driver.findElement(By.id("report_type_selection"))); 
		reporttype.selectByVisibleText(reportType);
		}
	
	public void selectProductreport(String product) throws Exception{
		if(!driver.findElements(By.xpath("//div[contains(text(),'"+product+"')]//following::a")).isEmpty()){
			System.out.println("Report Product: "+product);
			String openWindowName = driver.getWindowHandle();
			Generic.waitForElement(driver, driver.findElement(By.xpath("//div[contains(text(),'"+product+"')]//following::a")), 5);
//			Log.tagScreeshot(Generic.getFullPageScreenshot(driver, product));
			driver.findElement(By.xpath("//div[contains(text(),'"+product+"')]//following::a")).click();
			Generic.switchToNewWindow(driver, openWindowName);
			wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//b[contains(text(), 'Processing, please wait ...')]"))));
		}		
	}
	
	public void generateReport(String fromDate, String toDate) throws Exception	{
		if(!reportFromdate.isDisplayed()){
			driver.findElement(By.name("parameter")).click();
		}
		reportFromdate.clear();
		reportFromdate.sendKeys(fromDate);
		reportToDate.clear();
		reportToDate.sendKeys(toDate);
		ok.click();
//		Generic.waitThread();
		Generic.waitForElement(driver, reportGrid, 10);
	}
	
	public Object[][] fetchReportsCardsSummary(){
		String product = null;
		String activeCardsCount = null;
		String totalActiveCardLimit = null;
		String[] items = {product, activeCardsCount, totalActiveCardLimit};
		List<WebElement> getNoofProducts = driver.findElements(By.xpath(summaryTable+"//tr"));
		Object[][] productSummary = new Object[getNoofProducts.size()-1][items.length];
		for(int i=2; i<=getNoofProducts.size(); i++){
			for(int j=2; j<items.length+2; j++){				
				productSummary[i-2][j-2] = driver.findElement(By.xpath(summaryTable+"//tr["+i+"]/td["+j+"]")).getText();
			}			
		}
		return productSummary;
	}
	
//	public Object[][] fetchRechargeCardsSummary(){			
//		String product = null;
//		String rechargeCardsCount = null;
//		String totalActiveCardLimit = null;
//		String[] items = {product, rechargeCardsCount, totalActiveCardLimit};
//		List<WebElement> getNoofProducts = driver.findElements(By.xpath(summaryTable+"//tr"));
//		Object[][] productSummary = new Object[getNoofProducts.size()-1][items.length];
//		for(int i=2; i<=getNoofProducts.size(); i++){
//			for(int j=2; j<items.length+2; j++){
//				
//				productSummary[i-2][j-2] = driver.findElement(By.xpath(summaryTable+"//tr["+i+"]/td["+j+"]")).getText();
//			}			
//		}
//		return productSummary;
//	}
	
	
	public void exportReports(String exportDocFormat, String pages, String pageRange){
		exportReport.click();
		Select selectFormat = new Select(exportFormat);
		selectFormat.selectByVisibleText(exportDocFormat);
		switch(pages){
		case "All Pages":
			exportPageAll.click();
			break;
		case "Current Page":
			exportCurrentPage.click();
			break;
		case "Selected Pages":
			exportPageRange.click();
			exportPageRangeInput.sendKeys(pageRange);
			break;
		default:
			exportPageAll.click();
			break;				
		}
		exportOK.click();
	}
//	//To Validate Authorization Report
//	public boolean validateAuthReport(HashMap<String, String> authorizationDetails) throws Exception{
//		boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false,flag9 = false, flag10= false, flag11= false, flag12= false, flag13= false, flag14=false, flag15=false;
//				
//		//Authorization Code
//		String authcodeXpath = "//table//tr//div[contains(text(),'"+authorizationDetails.get("Approval Code")+"')]";
//		
//		searchRecordInReport(authcodeXpath);
//		
//		//URN Number[11]
//		flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[11]/div[contains(text(), '"+authorizationDetails.get("URN")+"')]")).isDisplayed();
//		//Card Number Last 4 digits
//		flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[10]/div[contains(text(), '"+authorizationDetails.get("Card Number")+"')]")).isDisplayed();
//		//Authorization Date
//		flag3 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[9]/div[contains(text(), '"+authorizationDetails.get("Authorization Date").toString().replace("-", ",")+"')]")).isDisplayed();
//		//Authorization Amount
//		flag4 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[7]/div[contains(text(), '"+authorizationDetails.get("Authorization Amount").toString().replace(".00", "")+"')]")).isDisplayed();
//		//MCC Amount
//		flag5 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[6]/div[contains(text(), '"+authorizationDetails.get("MCC Amount").toString().replace(".00", "")+"')]")).isDisplayed();
//		//Cross Currency Fee
//		flag6 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[5]/div[contains(text(), '"+authorizationDetails.get("Cross Currency Markup").toString().replace(".00", "")+"')]")).isDisplayed();
//		//Auth Available To Settle
//		flag7 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[3]/div[contains(text(), '"+authorizationDetails.get("Auth Available To Settle").toString().replace(".00", "")+"')]")).isDisplayed();
//		//Auth Settled Amount
//		flag8 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[2]/div[contains(text(), '"+authorizationDetails.get("Auth Settled Amount").toString().replace(".00", "")+"')]")).isDisplayed();
//		//Auth Reversal Amount
//		flag9 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[1]/div[contains(text(), '"+authorizationDetails.get("Reversal Amount").toString().replace(".00", "")+"')]")).isDisplayed();			
//		//RRN
//		flag10 = driver.findElement(By.xpath(authcodeXpath+"//following::td[3]/div[contains(text(),'"+authorizationDetails.get("RRN")+"')]")).isDisplayed();
//		//Currency Code
//		flag11 = driver.findElement(By.xpath(authcodeXpath+"//following::td[5]/div[contains(text(),'"+authorizationDetails.get("Transaction Currency Code")+"')]")).isDisplayed();
//		//Message
//		flag12 = driver.findElement(By.xpath(authcodeXpath+"//following::td[6]/div[contains(text(),'"+authorizationDetails.get("Message")+"')]")).isDisplayed();
//		//MCC Code
//		flag13 = driver.findElement(By.xpath(authcodeXpath+"//following::td[7]/div[contains(text(),'"+authorizationDetails.get("MCC")+"')]")).isDisplayed();
//		//Product
//		flag14 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[12]/div[contains(text(), '"+authorizationDetails.get("Product").toString().replace(".00", "")+"')]")).isDisplayed();
//		//Auth Status
//		switch(authorizationDetails.get("Auth Status").toString()){
//		case "Closed":
//			flag15 = driver.findElement(By.xpath(authcodeXpath+"//following::td[8]/div[contains(text(),'1')]")).isDisplayed();
//			break;
//		case "Open":
//			flag15 = driver.findElement(By.xpath(authcodeXpath+"//following::td[8]/div[contains(text(),'0')]")).isDisplayed();
//			break;
//		}				 
//	Log.info( "Authorization Report Validations: URN "+flag1+" Last 4 Digits "+flag2+" Date/Time "+ flag3+" Original Transaction Amount "+flag4+" MCC Buffer "+ flag5+" Cross Currency Transaction Fee "+flag6+" Available to settle "+ flag7 +"\n Settled Amount "+ flag8+" Reversal Amount "+flag9 +" RRN "+ flag10+" Trasaction Currency Code "+ flag11+" Message "+ flag12+" MCC Code "+ flag13+" Product "+ flag14+" Auth Status "+ flag15);
//	return flag1 && flag2 && flag3 && flag4&& flag5 && flag6&& flag7 && flag8&&flag9 && flag10&& flag11&& flag12&& flag13&& flag14&& flag15;		
//	}
	
	
	//To Validate Authorization Report
		public boolean validateAuthReport(HashMap<String, String> authorizationDetails) throws Exception{
			boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false,flag9 = false, flag10= false, flag11= false, flag12= false, flag13= false, flag14=false, flag15=false;
					
			//Authorization Code
			String authcodeXpath = "//table//tr//div[contains(text(),'"+authorizationDetails.get("Approval Code")+"')]";
			
			searchRecordInReport(authcodeXpath);
			
			//URN Number[11]
			flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[11]/div[contains(text(), '"+authorizationDetails.get("URN")+"')]")).isDisplayed();
			//Card Number Last 4 digits
			flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[10]/div[contains(text(), '"+authorizationDetails.get("Card Number")+"')]")).isDisplayed();
			//Authorization Date
			flag3 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[9]/div[contains(text(), '"+ authorizationDetails.get("Authorization Date").replace("-", ",")+"')]")).isDisplayed();
			//Authorization Amount
			flag4 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[7]/div[contains(text(), '"+ authorizationDetails.get("Authorization Amount").replace(".00", "")+"')]")).isDisplayed();
			//MCC Amount
			flag5 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[6]/div[contains(text(), '"+ authorizationDetails.get("MCC Amount").replace(".00", "")+"')]")).isDisplayed();
			//Cross Currency Fee
			flag6 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[5]/div[contains(text(), '"+ authorizationDetails.get("Cross Currency Markup").replace(".00", "")+"')]")).isDisplayed();
			//Auth Available To Settle
			flag7 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[3]/div[contains(text(), '"+ authorizationDetails.get("Auth Available To Settle").replace(".00", "")+"')]")).isDisplayed();
			//Auth Settled Amount
			flag8 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[2]/div[contains(text(), '"+ authorizationDetails.get("Auth Settled Amount").replace(".00", "")+"')]")).isDisplayed();
			//Auth Reversal Amount
			flag9 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[1]/div[contains(text(), '"+ authorizationDetails.get("Reversal Amount").replace(".00", "")+"')]")).isDisplayed();
			//RRN
			flag10 = driver.findElement(By.xpath(authcodeXpath+"//following::td[3]/div[contains(text(),'"+authorizationDetails.get("RRN")+"')]")).isDisplayed();
			//Currency Code
			flag11 = driver.findElement(By.xpath(authcodeXpath+"//following::td[5]/div[contains(text(),'"+authorizationDetails.get("Transaction Currency Code")+"')]")).isDisplayed();
			//Message
			flag12 = driver.findElement(By.xpath(authcodeXpath+"//following::td[6]/div[contains(text(),'"+authorizationDetails.get("Message")+"')]")).isDisplayed();
			//MCC Code
			flag13 = driver.findElement(By.xpath(authcodeXpath+"//following::td[7]/div[contains(text(),'"+authorizationDetails.get("MCC")+"')]")).isDisplayed();
			//Product
			flag14 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[12]/div[contains(text(), '"+ authorizationDetails.get("Product").replace(".00", "")+"')]")).isDisplayed();
			//Auth Status
			switch(authorizationDetails.get("Auth Status")){
			case "Closed":
				flag15 = driver.findElement(By.xpath(authcodeXpath+"//following::td[8]/div[contains(text(),'1')]")).isDisplayed();
				break;
			case "Open":
				flag15 = driver.findElement(By.xpath(authcodeXpath+"//following::td[8]/div[contains(text(),'0')]")).isDisplayed();
				break;
			}				 
		Log.info( "Authorization Report Validations: URN "+flag1+" Last 4 Digits "+flag2+" Date/Time "+ flag3+" Original Transaction Amount "+flag4+" MCC Buffer "+ flag5+" Cross Currency Transaction Fee "+flag6+" Available to settle "+ flag7 +"\n Settled Amount "+ flag8+" Reversal Amount "+flag9 +" RRN "+ flag10+" Trasaction Currency Code "+ flag11+" Message "+ flag12+" MCC Code "+ flag13+" Product "+ flag14+" Auth Status "+ flag15);
		return flag1 && flag2 && flag3 && flag4&& flag5 && flag6&& flag7 && flag8&&flag9 && flag10&& flag11&& flag12&& flag13&& flag14&& flag15;		
		}
	
	//To validate Open Authorization Report
	public boolean validateOpenAuthReport(HashMap<String, String> authorizationDetails) throws Exception{
		boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false,flag9 = false, flag10= false, flag11= false, flag12= false, flag13= false, flag14=false, flag15=false;

		//Authorization Code
		String authcodeXpath = "//table//tr//div[contains(text(),'"+authorizationDetails.get("Approval Code")+"')]";
		
		searchRecordInReport(authcodeXpath);
		//URN Number
		flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[11][contains(text(), '"+authorizationDetails.get("URN")+"')]")).isDisplayed();
		//Card Number Last 4 digits
		flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[10][contains(text(), '"+authorizationDetails.get("Last 4 Digits")+"')]")).isDisplayed();
		//Authorization Date
		flag3 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[9][contains(text(), '"+ authorizationDetails.get("Date/Time").replace("-", ",")+"')]")).isDisplayed();
		//Authorization Amount
		flag4 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[7][contains(text(), '"+ authorizationDetails.get("Original Transaction Amount").replace(".00", "")+"')]")).isDisplayed();
		//MCC Amount
		flag5 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[6][contains(text(), '"+ authorizationDetails.get("MCC Buffer").replace(".00", "")+"')]")).isDisplayed();
		//Cross Currency Fee
		flag6 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[5][contains(text(), '"+ authorizationDetails.get("Cross Currency Transaction Fee").replace(".00", "")+"')]")).isDisplayed();
		//Auth Available To Settle
		flag7 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[3][contains(text(), '"+ authorizationDetails.get("Available to settle").replace(".00", "")+"')]")).isDisplayed();
		//Auth Settled Amount
		flag8 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[2][contains(text(), '"+ authorizationDetails.get("Settled Amount").replace(".00", "")+"')]")).isDisplayed();
		//Auth Reversal Amount
		flag9 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[1][contains(text(), '"+ authorizationDetails.get("Reversal Amount").replace(".00", "")+"')]")).isDisplayed();
		//RRN
		flag10 = driver.findElement(By.xpath(authcodeXpath+"//following::div[3][contains(text(),'"+authorizationDetails.get("Authorization RRN")+"')]")).isDisplayed();
		//Currency Code
		flag11 = driver.findElement(By.xpath(authcodeXpath+"//following::div[5][contains(text(),'"+authorizationDetails.get("Trasaction Currency Code")+"')]")).isDisplayed();
		//Message
		flag12 = driver.findElement(By.xpath(authcodeXpath+"//following::div[6][contains(text(),'"+authorizationDetails.get("Message")+"')]")).isDisplayed();
		//MCC Code
		flag13 = driver.findElement(By.xpath(authcodeXpath+"//following::div[8][contains(text(),'"+authorizationDetails.get("MCC Code")+"')]")).isDisplayed();
		//Auth Status
		flag14 = driver.findElement(By.xpath(authcodeXpath+"//following::div[9][contains(text(),'0')]")).isDisplayed();
					 
	Log.info( "Open Authorization Report Validations: URN "+flag1+" Last 4 Digits "+flag2+" Date/Time "+ flag3+" Original Transaction Amount "+flag4+" MCC Buffer "+ flag5+" Cross Currency Transaction Fee "+flag6+" Available to settle "+ flag7 +"\n Settled Amount "+ flag8+" Reversal Amount "+flag9 +" RRN "+ flag10+" Trasaction Currency Code "+ flag11+" Message "+ flag12+" MCC Code "+ flag13+" Product "+ flag14);
	return flag1 && flag2 && flag3 && flag4&& flag5 && flag6&& flag7 && flag8&&flag9 && flag10&& flag11&& flag12&& flag13&& flag14;		
	}
	
	public boolean validateFailedAuthReport(HashMap<String, String> failedAuthorizationDetails) throws Exception{
		boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false;
		
		List<WebElement> authCode = driver.findElements(By.xpath("//table//tr//div[contains(text(),'"+failedAuthorizationDetails.get("URN")+"')]"));
		System.out.println("authCode: "+authCode.size());
		for (WebElement i : authCode){
			
			String authURNXpath = "//table//tr//div[contains(text(),'"+failedAuthorizationDetails.get("URN")+"')]";
			searchRecordInReport(authURNXpath);
			
			String divtimexpath = driver.findElement(By.xpath(authURNXpath+"//following::td[6]/div")).getText();
			System.out.println("divtimexpath ::::"+ divtimexpath);
			System.out.println("Time:::::::::::::: "+driver.findElement(By.xpath(authURNXpath+"//following::td[6]/div")).getText()+" TIME::::: "+failedAuthorizationDetails.get("Date/Time"));
			if(driver.findElement(By.xpath(authURNXpath+"//following::td[6]/div")).getText().equalsIgnoreCase(failedAuthorizationDetails.get("Date/Time").replace("-", ","))){
				System.out.println("Auth report Xpath :"+i);
				Log.info( "Auth report Xpath :"+i);
				//Card Number Last 4 digits
				flag1 = driver.findElement(By.xpath(authURNXpath+"//following::div[1][contains(text(), '"+failedAuthorizationDetails.get("Last 4 Digits")+"')]")).isDisplayed();
				//Authorization Amount
				flag2 = i.findElement(By.xpath("//following::div[2][contains(text(), '"+ failedAuthorizationDetails.get("Original Transaction Amount").replace(".00", "")+"')]")).isDisplayed();
				//MCC Amount
				flag3 = i.findElement(By.xpath("//following::div[3][contains(text(), '"+ failedAuthorizationDetails.get("MCC Buffer").replace(".00", "")+"')]")).isDisplayed();
				//MCC
				flag4 = i.findElement(By.xpath("//following::div[7][contains(text(), '"+failedAuthorizationDetails.get("MCC Code")+"')]")).isDisplayed();
				//Response Code
				flag5 = i.findElement(By.xpath("//following::div[11][contains(text(), '"+failedAuthorizationDetails.get("Response Code")+"')]")).isDisplayed();
			}	
		Log.info( "Failed Authorization Report Validations: Last 4 Digits "+flag1+" Original Transaction Amount "+flag2+" MCC Buffer "+ flag3+" MCC Code "+flag4+" Response Code "+ flag5);
		}
		return flag1 && flag2 && flag3 && flag4&& flag5;	
	}
	
	//To validate Auth Settlement Report
	public boolean validateSettlementReport(HashMap<String, String> settlementDetails) throws Exception{
		boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false,flag9 = false, flag10= false, flag11= false, flag12= false;
				
		//Authorization Code
		String authcodeXpath = "//table//tr/td[12]//div[contains(text(),'"+settlementDetails.get("AuthCode")+"')]";
		
		searchRecordInReport(authcodeXpath);
		//URN Number
		flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[10][contains(text(), '"+settlementDetails.get("URN Number")+"')]")).isDisplayed();
		//Card Number Last 4 digits
		flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[9][contains(text(), '"+settlementDetails.get("Card No Last Four Digits")+"')]")).isDisplayed();
		//Settlement Type
		flag3 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[8][contains(text(), '"+settlementDetails.get("Type")+"')]")).isDisplayed();
		//Product
		flag4 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[7][contains(text(), '"+ settlementDetails.get("Product").replace(".00", "")+"')]")).isDisplayed();
		//Event Type
		flag5 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[6][contains(text(), '"+settlementDetails.get("Event")+"')]")).isDisplayed();
		//Settled Amount
		flag6 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[5][contains(text(), '"+ settlementDetails.get("Settlement Amt").replace(".00", "")+"')]")).isDisplayed();
//		Settled Date
		flag7 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[3][contains(text(), '"+ settlementDetails.get("Settlement_Date").replace("-", ",")+"')]")).isDisplayed();
		//Processing Date
		flag8 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[2][contains(text(), '"+ settlementDetails.get("Processing_Date").replace("-", ",")+"')]")).isDisplayed();
		//MCC Code
		flag9 = driver.findElement(By.xpath(authcodeXpath+"//following::div[1][contains(text(),'"+settlementDetails.get("MCC")+"')]")).isDisplayed();
		//ARN
		flag10 = driver.findElement(By.xpath(authcodeXpath+"//following::div[4][contains(text(), '"+settlementDetails.get("Arn")+"')]")).isDisplayed();
		//Processed Flag
		flag11 = driver.findElement(By.xpath(authcodeXpath+"//following::div[6][contains(text(), '"+settlementDetails.get("Processed_Flag")+"')]")).isDisplayed();
		//Error Message
		flag12 = driver.findElement(By.xpath(authcodeXpath+"//following::div[11][contains(text(), '"+settlementDetails.get("ErrorMessage").trim()+"')]")).isDisplayed();				 
	Log.info( "Settlement Report Validations: URN "+flag1+" Last 4 Digits "+flag2+" Settlement Type "+ flag3+" Product "+flag4+" Event Type "+ flag5+" Settled Amount "+flag6+" Settled Date "+ flag7 +"\n Processing Date "+ flag8+" MCC Code "+flag9 +" ARN "+ flag10+" Processed Flag "+ flag11+" Error Message "+ flag12);
	return flag1 && flag2 && flag3 && flag4&& flag5 && flag6&& flag7 && flag8&&flag9 && flag10&& flag11&& flag12;		
	}
	
	//To Validate Authorization Expiry Report
		public boolean validateAuthExpiryReport(HashMap<String, String> authorizationExpiryDetails) throws Exception{
			boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false;
					
			//Authorization Code
			String authcodeXpath = "//table//tr//div[contains(text(),'"+authorizationExpiryDetails.get("Approval Code")+"')]";
			
			searchRecordInReport(authcodeXpath);
			
//			List<WebElement> authCode = driver.findElements(By.xpath("//table//tr//div[contains(text(),'9U1WA4')]"));
//			for (WebElement i : authCode){
//			Log.info( "Auth report Xpath :"+i);
			
			//Auth ID Number
			flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[8][contains(text(), '"+authorizationExpiryDetails.get("Auth ID")+"')]")).isDisplayed();
			//URN Number
			flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[7][contains(text(), '"+authorizationExpiryDetails.get("URN")+"')]")).isDisplayed();
			//Card Number Last 4 digits
			flag3 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[6][contains(text(), '"+authorizationExpiryDetails.get("Last 4 Digits")+"')]")).isDisplayed();
			//Authorization Amount
			flag4 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[4][contains(text(), '"+authorizationExpiryDetails.get("Original Transaction Amount").replace(".00", "")+"')]")).isDisplayed();
			//Refund Amount
			flag5 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[3][contains(text(), '"+authorizationExpiryDetails.get("Refund Amount").replace(".00", "")+"')]")).isDisplayed();
			//Authorization Date
			flag6 = driver.findElement(By.xpath(authcodeXpath+"//preceding::div[1][contains(text(), '"+authorizationExpiryDetails.get("Date/Time").replace("-", ",")+"')]")).isDisplayed();
			//Authorization Expiry Date
			flag7 = driver.findElement(By.xpath(authcodeXpath+"//following::div[3][contains(text(), '"+authorizationExpiryDetails.get("Auth Expired Date").replace("-", ",")+"')]")).isDisplayed();
			//Auth Status
			flag8 = driver.findElement(By.xpath(authcodeXpath+"//following::div[6][contains(text(),'"+authorizationExpiryDetails.get("Auth Status")+"')]")).isDisplayed();				 
		Log.info( "Authorization Report Validations: Auth ID "+flag1+" URN "+flag2+" Last 4 Digits "+flag3+" Authorization Amount "+ flag4+ " Refund Amount "+flag5+" Authorization Date "+ flag6+" Authorization Expiry Date "+flag7+" Auth Status "+ flag8);
		return flag1 && flag2 && flag3 && flag4&& flag5 && flag6&& flag7 && flag8;		
		}
		
		//To Validate Authorization Report
		public boolean validateChargebackReport(HashMap<String, String> chargeBackDetails) throws Exception{
			boolean flag1 = false, flag2= false, flag3 = false, flag4= false, flag5 = false, flag6= false, flag7 = false, flag8= false,flag9 = false, flag10= false, flag11= false, flag12= false, flag13= false, flag14=false, flag15=false;
					
			//Authorization Code
			String authcodeXpath = "//table//tr/td[4]/div[contains(text(),'"+chargeBackDetails.get("Approval Code")+"')]";
			
			searchRecordInReport(authcodeXpath);
			
			//URN Number[1]
			flag1 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[1]/div[contains(text(), '"+chargeBackDetails.get("URN")+"')]")).isDisplayed();
//			//Card Number Last 4 digits
//			flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[10]/div[contains(text(), '"+chargeBackDetails.get("Last 4 Digits")+"')]")).isDisplayed();
			
			//Authorization Date
			flag2 = driver.findElement(By.xpath(authcodeXpath+"//preceding::td[2]/div[contains(text(), '"+chargeBackDetails.get("Auth Transaction Date")+"')]")).isDisplayed();
			//Authorization Amount
			flag3 = driver.findElement(By.xpath(authcodeXpath+"//following::td[1]/div[contains(text(), '"+ chargeBackDetails.get("Authorized Amount").replace(".00", "")+"')]")).isDisplayed();
			
			//MCC Chargers
			flag4 = driver.findElement(By.xpath(authcodeXpath+"//following::td[2]/div[contains(text(), '"+ chargeBackDetails.get("MCC Charges").replace(".00", "")+"')]")).isDisplayed();
			//Settlement Amount
			flag5 = driver.findElement(By.xpath(authcodeXpath+"//following::td[3]/div[contains(text(), '"+ chargeBackDetails.get("Settled Amount").replace(".00", "")+"')]")).isDisplayed();
			//Chargeback Amount
			flag6 = driver.findElement(By.xpath(authcodeXpath+"//following::td[4]/div[contains(text(), '"+ chargeBackDetails.get("Chargeback Amount").replace(".00", "")+"')]")).isDisplayed();
			//Processed Flag
			flag7 = driver.findElement(By.xpath(authcodeXpath+"//following::td[5]/div[contains(text(), '"+ chargeBackDetails.get("Processed Flag").replace(".00", "")+"')]")).isDisplayed();
			//MCC Code
			flag8 = driver.findElement(By.xpath(authcodeXpath+"//following::td[7]/div[contains(text(),'"+chargeBackDetails.get("MCC Code")+"')]")).isDisplayed();
			//Settlement Date
			flag9 = driver.findElement(By.xpath(authcodeXpath+"//following::td[9]/div[contains(text(),'"+chargeBackDetails.get("Settlement Date")+"')]")).isDisplayed();
			//Chargeback Request date
			flag10 = driver.findElement(By.xpath(authcodeXpath+"//following::td[10]/div[contains(text(),'"+chargeBackDetails.get("Chargeback Request Date")+"')]")).isDisplayed();
			//Vroll #
			flag11 = driver.findElement(By.xpath(authcodeXpath+"//following::td[13]/div[contains(text(),'"+chargeBackDetails.get("VRoll Number")+"')]")).isDisplayed();
			//Status
			flag12 = driver.findElement(By.xpath(authcodeXpath+"//following::td[21]/div[contains(text(),'"+chargeBackDetails.get("Status")+"')]")).isDisplayed();
			//Chargeback Reasoncode
			flag13 = driver.findElement(By.xpath(authcodeXpath+"//following::td[11]/div[contains(text(),'"+chargeBackDetails.get("Reason code")+"')]")).isDisplayed();
			//Status Closed Validate processed date
			if(chargeBackDetails.get("Status")== "Completed"){
				flag14 = driver.findElement(By.xpath(authcodeXpath+"//following::td[19]/div[contains(text(),'"+chargeBackDetails.get("Chargeback Processed Date")+"')]")).isDisplayed();	
			}else{
				flag14= driver.findElement(By.xpath(authcodeXpath+"//following::td[19]/div[contains(text(),'')]")).isDisplayed();
			}
			Log.info( "Chargeback Report Validations: URN "+flag1+" Authorization Date "+flag2+" Authorization Amount "+
			flag3+" MCC Charges "+flag4+" Settlement Amount "+ flag5+" Chargeback Amount "+flag6+" Processed Flag "+ flag7 +
			"\n MCC Code "+ flag8+" Settlement Date"+flag9 +" Chargeback Request Date "+ flag10+" VRoll "+ flag11+
			" Status "+ flag12+" Reason code "+ flag13+" Chargeback Processed Date "+ flag14);
		return flag1&& flag2&& flag3&& flag4&& flag5&& flag6&& flag7 &&flag8 &&flag9 &&flag10 && flag11&& flag12&& flag13&& flag14;		
		}
		
		public void searchRecordInReport(String recordXpath) throws Exception{
			List<WebElement> elements = driver.findElements(By.xpath(recordXpath));
			if(elements.size()==0){
			do{
				nextPage.click();
				Generic.wait(5);
				elements = driver.findElements(By.xpath(recordXpath));
			}while(!(elements.size()>0));
			}
//			Log.info( logger.addScreenCapture(helper.getFullPageScreenshot(driver).toString()));
		}
		
		public HashMap<String, Boolean> downloadReportDataValidation(String authDetails, String reportFile, String transactionDetail) throws Exception{
			boolean flag1=false;
			String sheetName = null;
			int[] authCell = null;
			HashMap<String, Boolean> dataValidation = new HashMap<String, Boolean>();
			HashMap<String, String> authDetail =  Generic.parseStringToHashmap(authDetails);
			String transaction = authDetail.get(transactionDetail);
			int sheetsCount = ExcelLibrary.getNoofSheets(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile);
			for(int s=0; s<sheetsCount; s++){
				authCell = ExcelLibrary.searchTextFindCellAddress(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, s, transaction);
				sheetName = ExcelLibrary.getSheetName(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, s);
			}
			
			Object[] authHeader = authDetail.keySet().toArray();
			for(int i=0;i<authDetail.size();i++){
				for(int c=1;c<=30;c++){
					if(ExcelLibrary.getExcelData(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, sheetName, 5, c).contains(authHeader[i].toString())){
						if(authHeader[i].toString().equalsIgnoreCase("Auth Status")){
							//Auth Status
							switch(authDetail.get("Auth Status")){
							case "Closed":
								flag1 = ExcelLibrary.getExcelData(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, sheetName, authCell[0], c).contains("1");
								break;
							case "Open":
								flag1 = ExcelLibrary.getExcelData(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, sheetName, authCell[0], c).contains("0");
								break;
							}
						}else{
							flag1 = ExcelLibrary.getExcelData(System.getProperty("user.dir")+"\\TCGeneratedData\\"+reportFile, sheetName, authCell[0], c).contains(authDetail.get(authHeader[i]));
						}
						dataValidation.put(authHeader[i].toString(), flag1);
					}					
				}
			}
			return dataValidation;
		}		
}

/**
 * 
 */
package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.apiPayLoads.CardInquiryPayLoad;
import Prepaid.pageRepo.apiPayLoads.UnloadPayLoad;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.BaseTest1;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DB;
import library.ExcelLibrary;
import library.Generic;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisShardInfo;


import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author ${Srikiran D}
 *
 */
public class CSRBasePage extends BasePage
{

	/** The driver. */
	private WebDriver driver;

	public CSRBasePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}


	public static WebDriverWait wait;
	Connection con=null;
	
	@FindBy(name="submit")
	public WebElement signIn;

//	@FindBy(xpath="//a//b[contains(text(),'Sign Out')]")
//	public WebElement signOut;
	
	@FindBy(xpath="//b[contains(text(),'Logged in:')]") //--//following::font[contains(text(),'admin')]
	public WebElement loggedInLabel;
	
	@FindBy(xpath="//a[@href='/csr/CSRUserHandler?perform=logoff']")
	public WebElement signOut;
	
	@FindBy(linkText="/csr/accosa/Accosa.jsp")
	public WebElement accosaLink;
	
	@FindBy(xpath="//a[@href='/csr/accosa/AccosaLite.jsp']")
	public WebElement accosaLiteLink;
	
	//left Frame
	
	@FindBy(xpath="//iframe[@src='leftmenu.jsp']")
	public WebElement leftFrame;
	
	@FindBy(xpath="//a[text()='Prepaid Details']")
	protected WebElement prepaidDetails;
	
	@FindBy(xpath="//a[text()='Download Statement']")
	private WebElement downloadStatement;
	
	@FindBy(xpath="//a[text()='Enhanced Report']")
	protected WebElement enhacedReports;
	
	@FindBy(xpath="//a[text()='Exception Handling']")
	private WebElement exceptionHandling;
	
	@FindBy(xpath="//a[text()='Process Exception Items']")
	protected WebElement processExceptionItems;
	
	@FindBy(xpath="//a[text()='Chargeback Billed Items']")
	private WebElement chargebackBilledItems;
	
	@FindBy(xpath="//a[text()='Chargeback Billed Items(Lite)']")
	protected WebElement chargebackBilledItems_Lite;
	
	@FindBy(xpath="//a[text()='Process Chargeback Items']")
	private WebElement processChargebackItems;
	
	@FindBy(xpath="//a[text()='Credit Chargeback Amount']")
	private WebElement creditChargebackAmount;
	
	@FindBy(xpath="//a[text()='Credit Chargeback Amount(Lite)']")
	protected WebElement creditChargebackAmount_Lite;
	
	@FindBy(xpath="//a[text()='Process Blocked Cards']")
	private WebElement processBlockedCards;
	
	@FindBy(xpath="//a[text()='Process By Card Number']")
	private WebElement processByCardNumber;
		
	@FindBy(id="FromDate")
	private WebElement fromDate;
	
	@FindBy(id="ToDate")
	private WebElement toDate;
	
	@FindBy(xpath="//a[text()='Process Cache']")
	private WebElement processCache;
	
	@FindBy(id="publishText")
	private WebElement publish;
	
	@FindBy(id="publish")
	private WebElement submitPublish;

	@FindBy(xpath="//input[@name='ip']")
    WebElement hsmIP;

	@FindBy(xpath="//input[@name='port']")
    WebElement hsmPort;

	@FindBy(xpath="//input[@name='key1']")
    WebElement hsmKeyAlias;

	@FindBy(xpath="//input[@name='Data']")
    WebElement clearData;

	@FindBy(xpath="//input[@value='Send to HSM']")
    WebElement send2HSM;

	@FindBy(xpath="//body[1]/textarea[1]")
    WebElement encryptedData;


	public void explicitWait(WebElement element, int timeUnit)	{
		WebDriverWait wait=new WebDriverWait(driver,timeUnit);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	// ****************************************************************************
	/**
	 * This method is used to login into app
	 *
	 * @param uname
	 * @param pwd
	 */
	public void csrLogin(String uname, String pwd) {
		System.out.println("inside logininto app method");
		driver.findElement(By.name("txtUserId")).sendKeys(uname);
		driver.findElement(By.name("txtPassword")).sendKeys(pwd);
		driver.findElement(By.name("submit")).click();
		Generic.wait(5);
	}
	
	
	public static String GetCardNumber(String filePath, String sheet, String cardStatus)	{
		int[] cellAddress = ExcelLibrary.searchTextFindCellAddress(filePath, sheet, cardStatus);
		String cardNumber = ExcelLibrary.getExcelData(filePath, sheet, cellAddress[0], 0);
		return cardNumber;
	}
	
	//This method is to fetch the cardnumber of a particular event like activation of a card, reload, unload, block, unblock
	public static String GetCardNumber(String filePath, String sheet, String event, String status)	{
		Sheet sheetValue =  ExcelLibrary.getSheet(filePath, sheet);
	    for(Row row : sheetValue) {
	        for(Cell cell : row) {
	           // if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
	        			if((cell.getStringCellValue().equals(status)) && (ExcelLibrary.getExcelData(filePath, sheet, row.getRowNum(), 4).equals("Active"))) {
	                    return ExcelLibrary.getExcelData(filePath, sheet, row.getRowNum(), 0); 
	                }
	        //    }
	        }
	    }
		return null;
	}
	
	/**
	 * This method is used to enter from and to date
	 * @param fDate
	 * @param tDate
	 */
	public void enterFromToDate(String fDate,String tDate)	{
		fromDate.sendKeys(fDate);
		toDate.sendKeys(tDate);
	}
	
	/**
	 * This method take two parameter, one is Webelement of ProductdropDown list, Second is name of the product.
	 * @param _prodName
	 * @param productName
	 */
	public void  productSelection(WebElement _prodName, String productName)	{
		Select product=new Select(_prodName);
		product.selectByVisibleText(productName);
	}

	/**
	 * 
	 * @param handle
	 */
	
	public void swithWindows(int handle)	{
		ArrayList<String> myList =new ArrayList<String>(driver.getWindowHandles());
		System.out.println("size of window handle is "+myList.size());
		driver.switchTo().window(myList.get(handle));
	}
	
	public void scrollDown()	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}
	
	public void processCache(String cacheType)	{
		processCache.click();
		publish.sendKeys(cacheType);
		submitPublish.click();
		submitPublish.click();
	}	
	
	public String authorizationPrecondition(String condition, String cardNumber) throws Exception{
		
		int[] cellAddress = ExcelLibrary.searchTextFindCellAddress(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cardNumber);
		String last4digits = ExcelLibrary.getExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cellAddress[0], 1);
		String urn = ExcelLibrary.getExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cellAddress[0], 2);
		String custId = ExcelLibrary.getExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cellAddress[0], 3);

		CardInquiryPayLoad apiCardInquiry = new CardInquiryPayLoad(driver);
		BasePayLoad basePayLoad = new BasePayLoad(driver);
		JSONObject requestObject = apiCardInquiry.cardInqPayLoad(urn, custId, last4digits);
		Response response = apiCardInquiry.cardInquiry(requestObject);
		JsonPath responseValue = basePayLoad.jsonObject(response);
		String cardStatus = basePayLoad.getResponseValue(response, "description");
		int cardBalance=0;		
		String returnvalue = null;
		switch(condition)
		{
		case "Custom Block":
			if(!cardStatus.equalsIgnoreCase("Custom Blocked")){
				returnvalue = basePayLoad.blockCard(cardNumber, "Custom");
			}
			break;
		case "Temporary Block":
			if(!cardStatus.equalsIgnoreCase("Blocked Temporarily")){
				returnvalue = basePayLoad.blockCard(cardNumber, "Temporary");
			}
			break;
		case "Permanent Block":
			if(!cardStatus.equalsIgnoreCase("Blocked Permanently")){
				returnvalue = basePayLoad.blockCard(cardNumber, "Permanent");
			}
			break;
			
		case "Full Card Limit":			
			returnvalue =  basePayLoad.getResponseValue(response, "availableBalance");
			break;
			
		case "No Card Balance":
            UnloadPayLoad unloadAPI = new UnloadPayLoad(driver);
			cardBalance = Integer.parseInt(basePayLoad.getResponseValue(response, "availableBalance"));
			JSONObject unloadRequest = unloadAPI.unloadPayLoad(urn, last4digits, custId, cardBalance,"","","");
			Response unloadResponse = unloadAPI.unloadCard(unloadRequest);
			returnvalue =  basePayLoad.getResponseValue(response, "responseCode");
//			//Log.info( "Unload Request - Response : " +unloadResponse.asString());
			if(returnvalue.equalsIgnoreCase("00")){
//				//Log.pass( "Unload Request is : " +returnvalue);
			}else{
//				//Log.fail( "Unload Request is : " +returnvalue);
			}
			break;
		case "MCC Authoriation":
			returnvalue = basePayLoad.getConfiguredMCCCode();		
			break;
		case "No MCC Authorization":
			returnvalue = basePayLoad.getNonConfiguredMCCCode();	
			break;
		case "Partial Authorization":			
			break;
		case "Greater than Card Balance":
			cardBalance = Integer.parseInt(basePayLoad.getResponseValue(response, "availableBalance"));
//			//Log.info( "Card Balance is : " +returnvalue);
			returnvalue =  String.valueOf(cardBalance+1000);
			break;

		}
		return returnvalue;
	}
	
	public String authExpiry() throws Exception{
		EOD_Login_Page eod= new EOD_Login_Page(driver);
		String[] cred = BaseTest1.getAppCredentials("eod");
		eod.eodLogin(cred[0], cred[1]);
		eod.selectBank(BaseTest1.BANK);
		String authExpiryStatus = eod.wibmoExecuteEODJob("Auth Expiry");
		if(authExpiryStatus.equalsIgnoreCase("SUCCESS")){
//			//Log.pass( "Auth Expiry job is successful");
			return "Authorization Expired";
		}else{
//			//Log.fail( "Auth Expiry job is failure");
//			//logger.log(LogStatus.SKIP, "Auth Expiry job is failure So skipping the test");
			return "Authorization Expiry Failed";
		}
	}

	//This method is to get clear value to HSM encrypted value.
	//@author srikiran.d
	public String text2HSMencryption(String text) throws Exception {
		String[] hsm_ip_port_key = BaseTest1.getHSM_ip_port_key();
	    hsmIP.clear();
		hsmIP.sendKeys(hsm_ip_port_key[0]);
		hsmPort.clear();
		hsmPort.sendKeys(hsm_ip_port_key[1]);
		hsmKeyAlias.clear();
		hsmKeyAlias.sendKeys(hsm_ip_port_key[2]);
		send2HSM.click();
		return encryptedData.getText();
	}

	public String fetchAMLProfileValue(String amlParamID) throws Exception{
		String amlvalue = null;
		BasePayLoad basePayLoad = new BasePayLoad(driver);
		String selectQuery = "select aml_profile_value from aml_profile_parameters where INSTANCE_ID = " +
				"(select instance_id from aml_profile_instance where profile_id="+basePayLoad.getFullKYCProfileID()+" and product_id="+basePayLoad.getProductID()+
				") and aml_param_id = '"+amlParamID+"';";
		HashMap<String, String> dbDetails = BaseTest1.getDBDetails();
		con = DB.connectToDB(dbDetails.get("ip"), dbDetails.get("port"), dbDetails.get("accosa"), dbDetails.get("username"),dbDetails.get("password"));
		System.out.println("select Query"+selectQuery);
		ResultSet result = basePayLoad.executeSelectQuery(con, selectQuery);
		while (result.next()) {
			amlvalue = result.getString("aml_profile_value");
			System.out.println("Select Query result for " + result.getString("aml_profile_value"));
		}
		return amlvalue;
	}

	public void clearcache(String table, String iccid){
		String[] ip_port = BaseTest1.getRedisIp_Port();

		//Connecting to Redis server
		JedisShardInfo shardInfo = new JedisShardInfo(ip_port[0], ip_port[1]);
//		shardInfo.setUser();
		shardInfo.setPassword("pplite@123");
		Jedis jedis = new Jedis(shardInfo);
		jedis.connect();
		System.out.println("redis Ping"+jedis.ping());
		System.out.println("Cache Cleard : "+jedis.del(BaseTest1.getBankID()+"/"+table+"/"+iccid));
	}

	public void cleartablecache(String table, String action){

        String[] ip_port = BaseTest1.getRedisIp_Port();
		//Connecting to Redis server
		JedisShardInfo shardInfo = new JedisShardInfo(ip_port[0], ip_port[1]);
//		shardInfo.setUser();
		shardInfo.setPassword("pplite@123");
		Jedis jedis = new Jedis(shardInfo);
		jedis.connect();
		System.out.println("redis Ping"+jedis.ping());
		System.out.println("Table Cache : "+jedis.publish("AERO/COMP/QUEUE", BaseTest1.getBankID()+"|"+action+"|"+table));
	}
}

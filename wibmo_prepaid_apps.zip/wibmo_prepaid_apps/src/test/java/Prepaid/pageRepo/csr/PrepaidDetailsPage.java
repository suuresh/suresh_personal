/**
 *
 */
package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.testScripts.BaseTest1;
import Prepaid.testScripts.csr.settlements.AuthSettlements;
import library.DB;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;

/**
 * @author ${Srikiran D}
 *
 */
public class PrepaidDetailsPage extends BasePage
{
	private WebDriver driver;
	private String bank;

	public PrepaidDetailsPage(WebDriver driver, String bank){
		super(driver, bank);
		this.driver = driver;
		this.bank = bank;
		PageFactory.initElements(driver, this);
	}

	public PrepaidDetailsPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//Declaration of all the webElements of Prepaid Details Page

	@FindBy(id="txtSearch")
	public WebElement cardNumberId;

	@FindBy(id="urn")
	public WebElement urnId;

	@FindBy(id="btnSearch")
	public WebElement goButton;

	@FindBy(id="toDate")
	public WebElement toDateTextFiled;

	@FindBy(id="fromDate")
	public WebElement fromDateTextFiled;

	//Base I and BaseII Section

	@FindBy(xpath="//td[contains(text(),'Authorized Amount :')]//following::td[1]")
	public WebElement cardAuthorizedAmount;

	@FindBy(xpath="//td[contains(text(),'Available to authorise :')]//following::td[1]")
	public WebElement cardAvailableToAuthorize;

	@FindBy(xpath="//td[contains(text(),'Available to Settle Amount :')]//following::td[1]")
	public WebElement cardAvailableToSettle;

	@FindBy(xpath="//td[contains(text(),'Settled Amount :')]//following::td[1]")
	public WebElement cardSettledAmount;

	//search card number link

	@FindBy(xpath="//a[contains(@title,'Click')]")
	public WebElement cardNumberLink;

	@FindBy(xpath="//td[contains(text(),'Card Number :')]//following::font[1]")
	public WebElement transactionPageCardNumber;

	@FindBy(xpath = "//table[@id='content-box']")
	public WebElement transactionTable;

	public String icc_ActivateTag = "//td[contains(text(),'ICC_ACTIVATE')]";

	public String icc_RechargeTag="//td[contains(text(),'ICC_RECHARGE')]";

	public String icc_UnloadTag="//td[contains(text(),'ICC_UNLOAD')]";

	public String icc_ProfileUpdateTag="//td[contains(text(),'CARD_PROFILE_UPDATE')]";

	public String icc_ResetPinTag="//td[contains(text(),'ICC_RESET_PIN')]";

	public String icc_FundTransfer_Debit="//td[contains(text(),'FUND_TRANSFER_DEBIT')]";

	public String icc_FundTransfer_Credit="//td[contains(text(),'FUND_TRANSFER_CREDIT')]";

	public String icc_TempBlockTag="//td[contains(text(),'TEMP_CARD_BLOCK')]";

	public String icc_CardBlockTag="//td[contains(text(),'CARD_BLOCK')]";

	public String icc_CustomBlockTag="//td[contains(text(),'CUSTOM_CARD_BLOCK')]";

	public String icc_CardUnBlockTag="//td[contains(text(),'CARD_UNBLOCK')]";

	public String icc_CreditAdjustmentTag ="//td[contains(text(),'CARD_ADJUSTMENT_CR')]";

	public String icc_DebitAdjustmentTag = "//td[contains(text(),'CARD_ADJUSTMENT_DR')]";

	public String  authRequestTag = "//td[contains(text(),'AUTHORIZATION_REQUEST')]";
	public String authExpiryTag = "//td[contains(text(),'AUTH EXPIRY')]";

	public String  firstPresentmentDebitTag = "//td[contains(text(),'FIR_PRESENTMENT_PUR')]";
	public String  firstPresentmentCreditTag = "//td[contains(text(),'FIR_PRESENTMENT_CR')]";
	public String  firstPresentmentDebitReversalTag = "//td[contains(text(),'FIR_PRESENTMENT_PUR_REV')]";
	public String  firstPresentmentCreditReversalTag = "//td[contains(text(),'FIR_PRESENTMENT_CR_REV')]";

	public String firstChargebackPresentmentTag = "//td[contains(text(),'FIR_CHARGE_BACK_PUR')]";
	public String firstChargebackCreditTag = "//td[contains(text(),'FIR_CHARGE_BACK_CR')]";
	public String  secondPresentmentDebitTag = "//td[contains(text(),'SEC_PRESENTMENT_PUR')]";
	public String  secondPreDebitReversalTag = "//td[contains(text(),'SEC_PRESENTMENT_PUR_REV')]";

	public String  disputeResponseReversalPreARBTag = "//td[contains(text(),'DISPUTE_RESPONSE_FINANCIAL_REVERSAL_PRE_ARB_ACCEPTANCE')]";
	public String  disputeResponseReversalARBTag = "//td[contains(text(),'DISPUTE_RESPONSE_FINANCIAL_REVERSAL_ARB_ACCEPTANCE')]";
	public String  disputeReversalPreARBTag = "//td[contains(text(),'DISPUTE_FINANCIAL_REVERSAL_PRE_ARB_ACCEPTANCE')]";
	public String  disputeReversalARBTag = "//td[contains(text(),'DISPUTE_FINANCIAL_REVERSAL_ARB_DECISION_ACCEPTANCE')]";

	//close button in next page	
	@FindBy(id="cmdDone")
	public WebElement closeButton;

	//web Element to get product name and status

	@FindBy(xpath="//td[contains(text(),'Product :')]/following-sibling::td/font")
	public WebElement productName;

	@FindBy(xpath="//input[@value='Back']")
	public WebElement back;

	@FindBy(xpath="//input[@value='Refresh']")
	public WebElement refresh;

	BasePayLoad basePayLoad = new BasePayLoad(driver);

	//method to check card status and 

	public String checkPrepaidDetails(String cardNumberOrURN)
	{
		boolean card16digitnumber = cardNumberOrURN.length()==16;
		String maskedCardNumber = null;
		switch(bank)
		{
			case "hdfc":
			case "SURYA":
			case "BDO":
			case "IDBI":
			case "bobk":
			Log.info("Navigating to Prepaid Details Page");
				accosaLiteLink.click();
				Generic.waitForElement(driver, cardNumberId, 30);
				if(card16digitnumber){
					cardNumberId.sendKeys(cardNumberOrURN);
				}else{
					urnId.sendKeys(cardNumberOrURN);
				}
			Log.info("Searching for an card: "+cardNumberOrURN);
				goButton.click();
				Generic.waitForElement(driver,transactionPageCardNumber, 30);
				maskedCardNumber=transactionPageCardNumber.getText();
				break;
			case "SBIB":
			case "SBIM":
			case "BOB":
				driver.switchTo().frame(leftFrame);
				prepaidDetails.click();
				driver.switchTo().defaultContent();
				cardNumberId.sendKeys(cardNumberOrURN);
				goButton.click();
				Generic.waitForElement(driver,cardNumberLink, 30);
				cardNumberLink.click();
				//switch to new window
				Generic.switchWindows(driver, 1);
				maskedCardNumber=cardNumberLink.getText();
				closeButton.click();
				Generic.switchWindows(driver,0);
				break;
		}
		return maskedCardNumber;
	}


	public void NavigateBackToPrepaidDetailsPage()
	{
		Generic.waitForElement(driver,back, 30);
		back.click();
		Generic.waitForElement(driver,cardNumberId, 30);
		Log.info("Navigate back to Prepaid details search page");
	}


	public boolean CSRValidateCardTransaction(String event, double loadAmount, String transactionReferenceNum) throws Exception
	{
		String element = null;
		Boolean amountValidation = false;
		boolean eventAmountValidation = false;
		boolean eventTagValidation = false;
		boolean eventReferenceIDValidation = false;
		//Log.info(event);
		switch(event)
		{
			case "Activation":
				element = icc_ActivateTag;
				amountValidation = true;
				break;
			case "Reload":
				element = icc_RechargeTag;
				amountValidation = true;
				break;
			case "Unload":
				element = icc_UnloadTag;
				amountValidation = true;
				break;
			case "Reset Pin":
				element = icc_ResetPinTag;
				eventAmountValidation=true;
				break;
			case "Fund Transfer Debit":
				element = icc_FundTransfer_Debit;
				amountValidation = true;
				break;
			case "Fund Transfer Credit":
				element = icc_FundTransfer_Credit;
				amountValidation = true;
				break;
			case "Temporary":
				element = icc_TempBlockTag;
				eventAmountValidation=true;
				break;
			case "Unblock":
				element = icc_CardUnBlockTag;
				eventAmountValidation=true;
				break;
			case "Permanent":
				element = icc_CardBlockTag;
				eventAmountValidation=true;
				break;
			case "Custom":
				element = icc_CustomBlockTag;
				eventAmountValidation=true;
				break;
			case "Profile Update":
				element = icc_ProfileUpdateTag;
				eventAmountValidation=true;
				break;
			case "Credit Adjustment":
				element = icc_CreditAdjustmentTag;
				eventAmountValidation=true;
				break;
			case "Debit Adjustment":
				element = icc_DebitAdjustmentTag;
				eventAmountValidation=true;
				break;
		}
		Generic.waitForElement(driver,driver.findElement(By.xpath(element)), 30);
		//Activation event tag heading
		eventTagValidation = driver.findElement(By.xpath(element)).isDisplayed();
		Log.info("Activation event is populated in transaction");
//		double dLoadAmount = Double.parseDouble(loadAmount);

		String referenceNumberXpath = "//table[@id='content-box']//following::td[contains(text(),'"+transactionReferenceNum+"')]";
		eventReferenceIDValidation = driver.findElement(By.xpath(referenceNumberXpath)).isDisplayed();
		if(amountValidation){
			loadAmount = loadAmount/100;
			System.out.println(String.format("%.2f", loadAmount));
			loadAmount = Double.parseDouble(String.format("%.2f", loadAmount));
			eventAmountValidation = driver.findElement(By.xpath(referenceNumberXpath+"//following-sibling::td[contains(text(),'"+loadAmount+"')]")).isDisplayed();
			Log.info("Activation event transaction amount and reference number is populated");
			//driver.navigate().back();
			NavigateBackToPrepaidDetailsPage();
		}
		return eventAmountValidation==eventTagValidation==eventReferenceIDValidation;
	}

	public boolean validateCardAuthTransactions(String cardNumber, String approvalCode, String responseCode, int transactionAmount, String panEntryMode, String authRRN, String authTxnCurrency) throws Exception{

		boolean authAmountValidation = false, authResponseCode=false, authApprovalCodeValidation=false, authCurrencyValidation=false, authRRNValidation=false;
		Generic.waitForElement(driver, driver.findElement(By.xpath(authRequestTag)), 30);
		//Activation event tag heading
		boolean eventTagValidation = driver.findElement(By.xpath(authRequestTag)).isDisplayed();

//		authResponseCode = driver.findElement(By.xpath("//table//tr/td[contains(text(),'"+approvalCode+"')]/following::a[contains(text(),'"+responseCode+"')][1]")).isDisplayed();
		authResponseCode = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+responseCode+"')]")).isDisplayed();
		if(responseCode.equals("00")){
//			authApprovalCodeValidation = driver.findElement(By.xpath("//table//tr/td[contains(text(),'"+approvalCode+"')]")).isDisplayed();
			authApprovalCodeValidation = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]")).isDisplayed();
			double authTransactionAmount = transactionAmount/100;
			System.out.println(String.format("%.2f", authTransactionAmount));
			authTransactionAmount = Double.parseDouble(String.format("%.2f", authTransactionAmount));
			authAmountValidation = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authTransactionAmount+"')]")).isDisplayed();
			authCurrencyValidation= driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authTxnCurrency+"')]")).isDisplayed();
			authRRNValidation= driver.findElement(By.xpath("//table//tr/td[contains(text(),'"+authRRN+"')]")).isDisplayed();
		}
		Log.info("eventTagValidation:"+eventTagValidation+" authAmountValidation:"+authAmountValidation+" authApprovalCodeValidation:"+authApprovalCodeValidation);
		return eventTagValidation==authAmountValidation==authApprovalCodeValidation;
	}

	public boolean validateMCCFeeBufferValidation(String mcc, String authCode){
		boolean mccChargesValidation = false;
		double mccPercentvalue1 = 0;
		double mccPercentvalue2 = 0;
		double minValue = 0;
		String mccCode;

//		refresh.click();
		double orginalTransactionAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authCode+"')]//preceding::td[10]")).getText().trim());
		double applliedMCCCharges = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authCode+"')]//preceding::td[9]")).getText().trim());
		double appliedMCCPercentage =  (applliedMCCCharges/orginalTransactionAmount)*100;

		//Fetch DB MCC configured charges
		Connection con;
		try {
			HashMap<String, String> dbDetails = BaseTest1.getDBDetails();
			con = DB.connectToDB(dbDetails.get("ip"), dbDetails.get("port"),dbDetails.get("accosa"), dbDetails.get("username"), dbDetails.get("password"));
			String query = "select MCC_CODES,ATTRIBUTE_VALUE_1, ATTRIBUTE_VALUE_2,MIN_VALUE from mcc_rules where MCC_CODES = '"+mcc+"';";
			ResultSet result = DB.executeSelectQuery(con, query);
			while(result.next())
			{
				mccCode = result.getString("MCC_CODES");
				if(mccCode.equalsIgnoreCase(basePayLoad.getConfiguredMCCCode())){
					mccPercentvalue1 = result.getDouble("ATTRIBUTE_VALUE_1");
					mccPercentvalue2 = result.getDouble("ATTRIBUTE_VALUE_2");
					minValue = result.getDouble("MIN_VALUE");
				}
			}
			Log.info("DB MCC Configuration >>>> mccPercentvalue1: "+mccPercentvalue1+", mccPercentvalue2: "+mccPercentvalue2+", minValue: "+minValue);
			if(applliedMCCCharges != 0.0){
				if(appliedMCCPercentage == mccPercentvalue1){
					mccChargesValidation = true;
					Log.info( "MCC Charges Applied is valid and ATTRIBUTE_VALUE_1 value is applied");
				}else{
					if(appliedMCCPercentage==mccPercentvalue2){
						mccChargesValidation = true;
						Log.info("MCC Charges Applied is valid and ATTRIBUTE_VALUE_2 value is applied");
					}else{
						if(appliedMCCPercentage == minValue){
							mccChargesValidation = true;
							Log.info("MCC Charges Applied is valid and Minimum value is applied");
						}else{
							Log.info("MCC Charges Applied is not valid");
						}
					}
				}
			}else{
				mccChargesValidation = true;
			}

		} catch (Exception e) {
			Log.info( ExceptionUtils.getStackTrace(e));
		}
		return mccChargesValidation;
	}

	public boolean validateAuthorizationStatus(String authApprovalCode, int settledAmount){

		boolean authApprovalCodeValidation = false, authsettledAmountValidation=false, settledAuthStatus=false, authEventTagValidation=false;
		authEventTagValidation = driver.findElement(By.xpath(authRequestTag)).isDisplayed();
		authApprovalCodeValidation = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]")).isDisplayed();
		Log.info("Auth approval is populating");

		double authSettledAmount;
		authSettledAmount = settledAmount/100;
		authSettledAmount = Double.parseDouble(String.format("%.2f", authSettledAmount));

		double actualSettledAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(), '"+authApprovalCode+"')]//following::td[7]")).getText());
		if(actualSettledAmount >= authSettledAmount){
			authSettledAmount = actualSettledAmount;
		}
//		authsettledAmountValidation = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authSettledAmount+"')]")).isDisplayed();

		//if Auth Settled amount and auth amount is equal or not
		//String.format("%.02f",Float.parseFloat(
		double totalTransactionAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(), '"+authApprovalCode+"')]//preceding::td[12]")).getText());
		double totalSettledAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(), '"+authApprovalCode+"')]//following::td[7]")).getText().replace(" ", ""));
		String toSettleAmount = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[6]")).getText();
		double pendingSettlement;
		if(toSettleAmount.isEmpty()||toSettleAmount.equalsIgnoreCase(" ")){
			pendingSettlement = 0.00;
		}else{
			pendingSettlement =  Double.parseDouble(toSettleAmount);
		}


		String authStatus =  driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[4]")).getText().trim();

		if(authStatus.equalsIgnoreCase("Open")){
			Log.info("Authorization is Open the settled amount is: "+authSettledAmount);
			Log.info("Total Transaction Amount is: "+totalTransactionAmount);
		}else{
			Log.info("Authorization is Closed");
			authsettledAmountValidation = (totalSettledAmount == totalTransactionAmount);
			Log.info("Authorization settlement amount is populating");
			double expectedPendingSettlement = totalTransactionAmount-authSettledAmount;
			Log.info("Authorization Settled Amount: "+authSettledAmount+" Actual Total Authorized Amount: "+totalTransactionAmount+" Actual To be Settled Amount: "+pendingSettlement+" expectedPendingSettlement: "+expectedPendingSettlement);
			if(expectedPendingSettlement == pendingSettlement){
				authsettledAmountValidation = true;
				////Log.pass( "Actual To Be Settled amount is valid amount"+ pendingSettlement);
			}else{
				if(expectedPendingSettlement < 0){
					authsettledAmountValidation = true;
					////Log.pass( "Actual To Be Settled amount is valid amount"+ pendingSettlement);
				}else{
					////Log.fail( "Actual To Be Settled amount is not valid amount"+ pendingSettlement);
				}
			}
		}
		Log.info("Settlement Validations  -  "+", authsettledAmountValidation: "+authsettledAmountValidation+", authApprovalCodeValidation: "+authApprovalCodeValidation+", settledAuthStatus: "+settledAuthStatus+", authEventTagValidation: "+authEventTagValidation);
		return authsettledAmountValidation==authApprovalCodeValidation==settledAuthStatus==authEventTagValidation;

	}

	public boolean validateSettlement(String cardNumber, String authApprovalCode, String settlementType, int debitSettlementAmount, int creditSettlementAmount, int debitReversalSettlementAmount, int creditReversalSettlementAmount) throws Exception{
		String settlementTag = null;
		int settledAmount = 0;
		refresh.click();
		Generic.wait(3);
		int[] cell = ExcelLibrary.searchTextFindCellAddress(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cardNumber);
		switch(settlementType){
			case "05":
				settlementTag = firstPresentmentDebitTag;
				settledAmount = debitSettlementAmount;
				validateAuthorizationStatus(authApprovalCode, settledAmount);
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 27, "true");
				break;
			case "06":
				settlementTag = firstPresentmentCreditTag;
				settledAmount = creditSettlementAmount;
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 29, "true");
				break;
			case "25":
				settlementTag = firstPresentmentDebitReversalTag;
				settledAmount = debitReversalSettlementAmount;
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 31, "true");
				break;
			case "26":
				settlementTag = firstPresentmentCreditReversalTag;
				settledAmount = creditReversalSettlementAmount;
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 33, "true");
				break;
			case "052":
				settlementTag = secondPresentmentDebitTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
			case "L1":
				settlementTag = secondPreDebitReversalTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
			case "L2":
				settlementTag = disputeResponseReversalPreARBTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
			case "L3":
				settlementTag = disputeResponseReversalARBTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
			case "R2":
				settlementTag = disputeReversalPreARBTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
			case "R3":
				settlementTag = disputeReversalARBTag;
				settledAmount = debitSettlementAmount;
//			 ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardDetails", cell[0], 25, "true");
				break;
		}

		boolean eventTagFirstPresentment=false, settlementApprovalCodeValidation=false, settledAmountValidation=false;
		//Activation event tag heading
		eventTagFirstPresentment = driver.findElement(By.xpath(settlementTag)).isDisplayed();
		Log.info(settlementTag+" Settlement Transaction is populating");
		settlementApprovalCodeValidation = driver.findElement(By.xpath(settlementTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]")).isDisplayed();
//		settlementApprovalCodeValidation = driver.findElement(By.xpath(firstPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+AuthSettlements.authCode+"')]")).isDisplayed();
		Log.info(authApprovalCode+ " approval code is populating");
		double SettledAmount = settledAmount/100.00;
		SettledAmount = Double.parseDouble(String.format("%.2f", SettledAmount));
		settledAmountValidation = driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//preceding::td[contains(text(),'"+SettledAmount+"')]")).isDisplayed();
		Log.info(SettledAmount+" Settled amount is populating");
		Log.info("Validating Settlement Process status and other details");
//		boolean settlementprocessStatus = validateSettlementProcessStatus(AuthSettlements.authCode, expected_txn_Dest, expected_ProcessFlag, Expected_message);
		Log.info("Settlement Validations  -  "+"event Tag FirstPresentment: "+eventTagFirstPresentment+", settlement Approval Code Validation: "+settlementApprovalCodeValidation+", settled Amount Validation: "+settledAmountValidation);
		return eventTagFirstPresentment==settlementApprovalCodeValidation==settledAmountValidation;
	}

	public HashMap<String, String> fetchAuthorizationDetails(String authRRN) throws Exception{
		HashMap<String, String> authorizationDetails = new HashMap<String, String>();
		authorizationDetails.put("RRN", authRRN);
		if(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]")).isDisplayed()){
			Log.info("Fetching Authorization Details");
			//Card Last 4 Digits
			authorizationDetails.put("Card Number", driver.findElement(By.xpath("//td[contains(text(),'Card Number :')]//following::td[1]")).getText().substring(15, 19).trim());
			//URN
			authorizationDetails.put("URN", driver.findElement(By.xpath("//td[contains(text(),'Urn :')]//following::td[1]")).getText().trim());
			//Authorization ID	
			authorizationDetails.put("Auth Id", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[8]")).getText().trim());
			// Trasaction Currency Code
			authorizationDetails.put("Transaction Currency Code", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[6]")).getText().trim());
			//Orginal Trasaction Amount
			authorizationDetails.put("Authorization Amount", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[5]")).getText().trim());
			//MCC Buffer
			authorizationDetails.put("MCC Amount", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[4]")).getText().trim());
			//Cross Currency Markup
			authorizationDetails.put("Cross Currency Markup", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[3]")).getText().trim());
			//Cross Currency Transaction Fee
			authorizationDetails.put("Cross Currency Fee", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//preceding::td[2]")).getText().trim());

			//Date/Time
			String authDate = driver.findElement(By.xpath("//td[contains(text(), '"+authRRN+"')]//preceding::td[contains(text(),'AUTHORIZATION_REQUEST')]//following::td[2]")).getText().trim();
			authDate = Generic.reportFormattedDate(authDate, "MMM d- yyyy- h:mm a");

			authorizationDetails.put("Authorization Date", authDate);
			//MCC Code
			authorizationDetails.put("MCC", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[2]")).getText().trim());
			//Auth Code
			authorizationDetails.put("Approval Code", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[5]")).getText().trim());
			//Response Code
			authorizationDetails.put("Response Code", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[6]")).getText().trim());
			//Auth Status
			authorizationDetails.put("Auth Status", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[9]")).getText().trim());
			//Message
			authorizationDetails.put("Message", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[10]")).getText().trim());
			//Available to settle
			authorizationDetails.put("Auth Available To Settle", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[11]")).getText().trim());
			//Settled Amount
			authorizationDetails.put("Auth Settled Amount", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[12]")).getText().trim());
			//Reversal Amount
			authorizationDetails.put("Reversal Amount", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[8]")).getText().trim());
			//Product
			authorizationDetails.put("Product", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authRRN+"')]//following::td[14]")).getText().trim());
		}
		return authorizationDetails;
	}

	public HashMap<String, String> fetchSettlementDetails(String authApprovalCode, HashMap<String, String> settlementApprovalCode, String settlementType){
		HashMap<String, String> settlementDetails = new HashMap<String, String>();
		String settlementCode = null;
		String settlementTag = null;
		//Fetching Card Number and urn details
		//Card Last 4 Digits
		settlementDetails.put("Card No Last Four Digits", driver.findElement(By.xpath("//td[contains(text(),'Card Number :')]//following::td[1]")).getText().substring(15, 19).trim());
		//URN
		settlementDetails.put("URN Number", driver.findElement(By.xpath("//td[contains(text(),'Urn :')]//following::td[1]")).getText());


		switch(settlementType){
			case "05":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = firstPresentmentDebitTag;
				settlementDetails.put("Type", "DR");
				settlementDetails.put("Event", "FIR_PRESENTMENT_PUR");
				break;
			//Second Presentment
			case "052":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = secondPresentmentDebitTag;
				settlementDetails.put("Type", "DR");
				settlementDetails.put("Event", "SEC_PRESENTMENT_PUR");
				break;
			case "06":
				if(settlementApprovalCode.get("creditSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("creditSettlementApprovalCode");
				}
				settlementTag = firstPresentmentCreditTag;
				settlementDetails.put("Type", "CR");
				settlementDetails.put("Event", "FIR_PRESENTMENT_CR");
				break;
			case "25":
				if(settlementApprovalCode.get("debitReversalSettlementApprovalCode") != null){
					settlementCode = settlementApprovalCode.get("debitReversalSettlementApprovalCode");
				}
				settlementTag = firstPresentmentDebitReversalTag;
				settlementDetails.put("Type", "CR");
				settlementDetails.put("Event", "FIR_PRESENTMENT_PUR_REV");
				break;
			case "26":
				if(settlementApprovalCode.get("creditReversalSettlementApprovalCode") != null){
					settlementCode = settlementApprovalCode.get("creditReversalSettlementApprovalCode");
				}
				settlementTag = firstPresentmentCreditReversalTag;
				settlementDetails.put("Type", "DR");
				settlementDetails.put("Event", "FIR_PRESENTMENT_CR_REV");
				break;
			case "L1":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = secondPreDebitReversalTag;
				settlementDetails.put("Type", "L1");
				settlementDetails.put("Event", "SEC_PRESENTMENT_PUR_REV");

				break;
			case "L2":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = disputeResponseReversalPreARBTag;
				settlementDetails.put("Type", "L2");
				settlementDetails.put("Event", "DISPUTE_RESPONSE_FINANCIAL_REVERSAL_PRE_ARB_ACCEPTANCE");
				break;
			case "L3":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = disputeResponseReversalARBTag;
				settlementDetails.put("Type", "L3");
				settlementDetails.put("Event", "DISPUTE_RESPONSE_FINANCIAL_REVERSAL_ARB_ACCEPTANCE");
				break;
			case "R2":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = disputeReversalPreARBTag;
				settlementDetails.put("Type", "R2");
				settlementDetails.put("Event", "DISPUTE_FINANCIAL_REVERSAL_PRE_ARB_ACCEPTANCE");
				break;
			case "R3":
				if(settlementApprovalCode.get("debitSettlementApprovalCode")!= null){
					settlementCode = settlementApprovalCode.get("debitSettlementApprovalCode");
				}
				settlementTag = disputeReversalARBTag;
				settlementDetails.put("Type", "R3");
				settlementDetails.put("Event", "DISPUTE_FINANCIAL_REVERSAL_ARB_DECISION_ACCEPTANCE");

				break;
		}

		if(settlementCode==null){
			settlementCode = authApprovalCode;
		}

		if(driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]")).isDisplayed()){
			Log.info("Fetching Settlement Details");

			settlementDetails.put("Product", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//following::td[13]")).getText().trim());
			//Date/Time
			String authDate = driver.findElement(By.xpath("//td[contains(text(), '"+settlementCode+"')]//preceding::td[contains(text(),'"+settlementDetails.get("Event")+"')]//following::td[2]")).getText().trim();
			String processingDate = Generic.reportFormattedDate(authDate, "MMM d- yyyy- h:m a");
			settlementDetails.put("Processing_Date", processingDate);
			String settlementDate = Generic.reportFormattedDate(authDate, "MMM d- yyyy");
			settlementDetails.put("Settlement_Date", settlementDate);

			settlementDetails.put("Processed_Flag", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//following::td[6]")).getText().trim());
			settlementDetails.put("ErrorMessage", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//following::td[4]")).getText());

			settlementDetails.put("settlementRefNumber", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//preceding::td[7]")).getText().trim());
			settlementDetails.put("Settlement Amt", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//preceding::td[5]")).getText().trim());
			settlementDetails.put("Arn", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//following::td[12]")).getText().trim());
			settlementDetails.put("purchaseDate", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//preceding::td[2]")).getText().trim());
			settlementDetails.put("MCC", driver.findElement(By.xpath(settlementTag+"//following::tr[2]//td[contains(text(),'"+settlementCode+"')]//preceding::td[1]")).getText().trim());
			settlementDetails.put("AuthCode", authApprovalCode);
			settlementDetails.put("authorizationID", driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//preceding::td[13]")).getText().trim());
		}
		return settlementDetails;
	}

	public HashMap<String, String> fetchChargebackDetails(String authApprovalCode, String chargebackProcess){
		refresh.click();
		HashMap<String, String> chargeBackDetails = new HashMap<String, String>();
		chargeBackDetails.put("Approval Code", authApprovalCode);
//		if(driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr"+firstChargebackPresentmentTag+"//following::tr[2]")).isDisplayed()){
		Log.info("Fetching Chargeback Details");
		//Card Last 4 Digits
		chargeBackDetails.put("Last 4 Digits", driver.findElement(By.xpath("//td[contains(text(),'Card Number :')]//following::td[1]")).getText().substring(15, 19).trim());
		//URN
		chargeBackDetails.put("URN", driver.findElement(By.xpath("//td[contains(text(),'Urn :')]//following::td[1]")).getText());

		//Authorization Event Date and time details

		String authorizedDate = driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+authRequestTag+"//following::td[2]")).getText().trim();
		authorizedDate = Generic.reportFormattedDate(authorizedDate, "dd-MM-yyyy");
		chargeBackDetails.put("Auth Transaction Date", authorizedDate);

		//Authorization Total Transaction Amount
		chargeBackDetails.put("Auth Total Transaction Amount", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+authRequestTag+"//following::tr[4]/td[2]")).getText().trim());
		//Authorization Orginal Trasaction Amount
		chargeBackDetails.put("Authorized Amount", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+authRequestTag+"//following::tr[4]/td[4]")).getText().trim());
		//Authorization MCC Buffer Charges
		chargeBackDetails.put("MCC Charges", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+authRequestTag+"//following::tr[4]/td[5]")).getText().trim());

		//Settlement Date
		String settlementDate = driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstPresentmentDebitTag+"//following::td[2]")).getText().trim();
		settlementDate = Generic.reportFormattedDate(settlementDate, "dd-MM-yyyy");
		chargeBackDetails.put("Settlement Date", settlementDate);
		//Settled Amount
		chargeBackDetails.put("Settled Amount", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstPresentmentDebitTag+"//following::tr[4]/td[3]")).getText().trim());

		String transactionType = null;
		switch(chargebackProcess){
			case "Chargeback Request":
				transactionType = firstChargebackPresentmentTag ;
				chargeBackDetails.put("Status", "Pending");
				break;
			case "Credit Chargeback":
				//Chargeback Credited Date
				String chargebackCreditedDate = driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstChargebackCreditTag+"//following::td[2]")).getText().trim();
				chargebackCreditedDate = Generic.reportFormattedDate(chargebackCreditedDate, "dd-MM-yyyy");
				chargeBackDetails.put("Chargeback Processed Date", chargebackCreditedDate);
				transactionType = firstChargebackCreditTag ;
				chargeBackDetails.put("Status", "Completed");
				break;
		}

		//Chargeback raised Date
		String chargebackRaisedDate = driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstChargebackPresentmentTag+"//following::td[2]")).getText().trim();
		chargebackRaisedDate = Generic.reportFormattedDate(chargebackRaisedDate, "dd-MMM-yyyy");
		chargeBackDetails.put("Chargeback Request Date", chargebackRaisedDate);
		//Chargeback ReasonCode
		chargeBackDetails.put("Reason code", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstChargebackPresentmentTag+"//following::tr[4]/td[15]")).getText().trim());
		//Chargeback Amount
		chargeBackDetails.put("Chargeback Amount", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+transactionType+"//following::tr[4]/td[3]")).getText().trim());
		//Processed Flag
		chargeBackDetails.put("Processed Flag", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+firstChargebackPresentmentTag+"//following::tr[4]/td[14]")).getText().trim());
		//VRoll Number
		chargeBackDetails.put("VRoll Number", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+transactionType+"//following::tr[4]/td[24]")).getText().trim());
		//MCC Code
		chargeBackDetails.put("MCC Code", driver.findElement(By.xpath("//td[contains(text(),'"+authApprovalCode+"')]//preceding::tr[3]"+transactionType+"//following::tr[4]/td[7]")).getText().trim());

//			}
		return chargeBackDetails;
	}

	//	public boolean validateSettlementProcessStatus(String authApprovalCode, String settlementType, String expected_txn_Dest, String expected_ProcessFlag, String Expected_message){
	public String validateSettlementProcessStatus(String authApprovalCode, String settlementType, String expectedProcessStatus, HashMap<String, String> authorizationDetails, HashMap<String, String> settlementDetails) throws Exception{

		HashMap<String, String> processStatus =  Generic.parseStringToHashmap(expectedProcessStatus);
		String expected_txn_Dest = processStatus.get("value0");
		String expected_ProcessFlag = processStatus.get("value1");
		String Expected_message = processStatus.get("value2");

		String transactionType = null;

		boolean txn_Destination_Validation = false;
		boolean process_flag_Validation = false;
		boolean message_Validation = false;
		String settlementTag = null;

		refresh.click();
		Log.info("Refresh the Transaction page");
		switch(settlementType){
			case "05":
				settlementTag = firstPresentmentDebitTag;
				break;
			case "06":
				settlementTag = firstPresentmentCreditTag;
				break;
			case "25":
				settlementTag = firstPresentmentDebitReversalTag;
				break;
			case "26":
				settlementTag = firstPresentmentCreditReversalTag;
				break;
			case "052":
				settlementTag = secondPresentmentDebitTag;
				break;
			case "L1":
				settlementTag = secondPreDebitReversalTag;
				break;
			case "L2":
				settlementTag = disputeResponseReversalPreARBTag;
				break;
			case "L3":
				settlementTag = disputeResponseReversalARBTag;
				break;
			case "R2":
				settlementTag = disputeReversalPreARBTag;
				break;
			case "R3":
				settlementTag = disputeReversalARBTag;
				break;
		}
		if(!expected_txn_Dest.equalsIgnoreCase("0")){
			transactionType = "";
		}else{
			transactionType = "Debit";
		}

		Generic.wait(3);
		Log.info("Validating Settlement Process details for AuthCode : "+authApprovalCode);
		txn_Destination_Validation = expected_txn_Dest.equalsIgnoreCase(driver.findElement(By.xpath(settlementTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[5]")).getText().trim());
		process_flag_Validation = expected_ProcessFlag.equalsIgnoreCase(driver.findElement(By.xpath(settlementTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[6]")).getText().trim());
		message_Validation = Expected_message.equalsIgnoreCase(driver.findElement(By.xpath(settlementTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[4]")).getText().trim());
		Log.info("Settlement process validation txn_Destination_Validation: "+txn_Destination_Validation+", process_flag_Validation: "+process_flag_Validation+", message_Validation: "+message_Validation);
		if(txn_Destination_Validation && process_flag_Validation && message_Validation){
			Log.info("Settlement Process is successfull and settlement status are valid");
			if(expected_txn_Dest.equalsIgnoreCase("2")){
				int row = ExcelLibrary.getLastCellinColumn(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "Exception Clearing", 0);
				ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "Exception Clearing", row, 0, authorizationDetails.toString());
				ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "Exception Clearing", row, 1, settlementDetails.toString());
			}
		}else{
			Log.info("Settlement Processing is Failure and settlement status is invalid");
		}
		return transactionType;
	}

	public String[] fetchCardBaseIBaseIIDetails(String cardNumberOrURN, String event, String approvalCode){
		String authorizedAmount, availableToAuthorize, availableToSettle, settledAmount, closingBalance = null, ledgerBalance = null;
		refresh.click();
		Generic.wait(3);
		authorizedAmount = cardAuthorizedAmount.getText().replace(" INR", "").trim();
		availableToAuthorize = cardAvailableToAuthorize.getText().replaceAll("[ INR, ]", "").trim();
		availableToSettle = cardAvailableToSettle.getText().replace(" INR", "").trim();
		settledAmount = cardSettledAmount.getText().replace(" INR", "").trim();
		String closing = null, ledger = null;
		switch(event){
			case "Activation":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_ACTIVATE')]//following::table[1]//tr[2]//td[5]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_ACTIVATE')]//following::table[1]//tr[2]//td[6]")).getText().trim();
				break;
			case "Recharge":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_RECHARGE')]//following::table[1]//tr[2]//td[8]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_RECHARGE')]//following::table[1]//tr[2]//td[9]")).getText().trim();
				break;
			case "Card Recharge Fee":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD RECHARGE FEE')]//following::table[1]//tr[2]//td[5]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD RECHARGE FEE')]//following::table[1]//tr[2]//td[6]")).getText().trim();
				break;
			case "Authorization":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[10]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[11]")).getText().trim();
				break;
			case "First Presentment Debit":
				if(approvalCode=="" || approvalCode == " "){
					closing = "//td[contains(text(),'"+approvalCode+"')]//following::td[14]";
					ledger = "//td[contains(text(),'"+approvalCode+"')]//following::td[15]";
				}else{
					closing = "//td[22]";
					ledger = "//td[23]";
				}
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_PUR')]//following::table[1]//tr[2]"+closing)).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_PUR')]//following::table[1]//tr[2]"+ledger)).getText().trim();
				break;

			case "First Presentment Debit Reversal":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_PUR_REV')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[14]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_PUR_REV')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[15]")).getText().trim();
				break;

			case "First Presentment Credit":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[14]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[15]")).getText().trim();
				break;

			case "First Presentment Credit Reversal":
//				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR_REV')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[14]")).getText().trim();
//				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR_REV')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[15]")).getText().trim();
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR_REV')]//following::table[1]//tr[2]//following::td[21]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FIR_PRESENTMENT_CR_REV')]//following::table[1]//tr[2]//following::td[22]")).getText().trim();
				break;

			case "Auth Expiry":
				closingBalance = driver.findElement(By.xpath(authExpiryTag+"//following::table[1]//tr[2]//a[contains(text(), '"+approvalCode+"')]//following::td[6]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath(authExpiryTag+"//following::table[1]//tr[2]//a[contains(text(), '"+approvalCode+"')]//following::td[7]")).getText().trim();
				break;
			case "Unload":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_UNLOAD')]//following::table[1]//tr[2]//td[8]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'ICC_UNLOAD')]//following::table[1]//tr[2]//td[9]")).getText().trim();
				break;
			case "Unload Fee":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD RECHARGE FEE')]//following::table[1]//tr[2]//td[6]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD RECHARGE FEE')]//following::table[1]//tr[2]//td[7]")).getText().trim();
				break;
			case "Update Profile":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD_PROFILE_UPDATE')]//following::table[1]//tr[2]//td[5]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'CARD_PROFILE_UPDATE')]//following::table[1]//tr[2]//td[6]")).getText().trim();
				break;
			case "Fund Transfer Debit":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FUND_TRANSFER_DEBIT')]//following::table[1]//tr[2]//td[8]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FUND_TRANSFER_DEBIT')]//following::table[1]//tr[2]//td[9]")).getText().trim();
				break;
			case "Fund Transfer Credit":
				closingBalance = driver.findElement(By.xpath("//td[contains(text(),'FUND_TRANSFER_CREDIT')]//following::table[1]//tr[2]//td[8]")).getText().trim();
				ledgerBalance = driver.findElement(By.xpath("//td[contains(text(),'FUND_TRANSFER_CREDIT')]//following::table[1]//tr[2]//td[9]")).getText().trim();
				break;
			case "Second Presentment Debit":
				if(approvalCode=="" || approvalCode == " "){
					closing = "//td[contains(text(),'"+approvalCode+"')]//following::td[14]";
					ledger = "//td[contains(text(),'"+approvalCode+"')]//following::td[15]";
				}else{
					closing = "//td[22]";
					ledger = "//td[23]";
				}
				closingBalance = driver.findElement(By.xpath(secondPresentmentDebitTag+"//following::table[1]//tr[2]"+closing)).getText().trim();
				ledgerBalance = driver.findElement(By.xpath(secondPresentmentDebitTag+"//following::table[1]//tr[2]"+ledger)).getText().trim();
				break;
			default:
				if(event.equals("none")){
					closingBalance = availableToAuthorize;
					ledgerBalance = availableToSettle;
				}
				break;
		}
		String[] bIbIIDetails = {authorizedAmount, availableToAuthorize, availableToSettle, settledAmount, closingBalance, ledgerBalance};
		return bIbIIDetails;
	}

	//Validate Base I and Base II details, Authorization, Debit Settlement and Credit Settlement 
	public boolean validateBaseIBaseIIPostSettlement(String settlementType, String cardNumber, String[] cardBaseDetails, HashMap<String, String> settlementApprovalCode, String authApprovalCode, int debitSettlementAmount, int creditSettlementAmount, int debitReversalSettlementAmount, int creditReversalSettlementAmount) throws Exception{
		boolean authorizedAmountValidation=false;
		boolean availableToAuthorizeValidation=false;
		boolean availableToSettleValidation=false;
		boolean settledAmountValidation=false;
		boolean closingBalanceValidation=false;
		boolean ledgerBalanceValidation=false;
		float settledAmount;
		String[] postcardBaseDetails = null;

		switch(settlementType){
			case "05":
				if(settlementApprovalCode.get("05") != null){
					authApprovalCode = settlementApprovalCode.get("05");
				}
				postcardBaseDetails = fetchCardBaseIBaseIIDetails(cardNumber, "First Presentment Debit", authApprovalCode);
				break;
			case "25":
				if(settlementApprovalCode.get("25")!= null){
					authApprovalCode = settlementApprovalCode.get("25");
				}
				creditSettlementAmount = debitReversalSettlementAmount;
				postcardBaseDetails = fetchCardBaseIBaseIIDetails(cardNumber, "First Presentment Debit Reversal", authApprovalCode);
				break;
			case "06":
				if(settlementApprovalCode.get("06") != null){
					authApprovalCode = settlementApprovalCode.get("06");
				}
				postcardBaseDetails = fetchCardBaseIBaseIIDetails(cardNumber, "First Presentment Credit", authApprovalCode);
				break;
			case "26":
				if(settlementApprovalCode.get("26") != null){
					authApprovalCode = settlementApprovalCode.get("26");
				}
				debitSettlementAmount = creditReversalSettlementAmount;
				postcardBaseDetails = fetchCardBaseIBaseIIDetails(cardNumber, "First Presentment Credit Reversal", authApprovalCode);
				break;
		}

		switch(settlementType){
			case "05":
			case "26":
				settledAmount = debitSettlementAmount/100;
				Log.info("Post Settlement - Base I and BaseII - authorizedAmount: "+postcardBaseDetails[0]+", "+"availableToAuthorize: "+postcardBaseDetails[1] +", "+"availableToSettle: "+postcardBaseDetails[2] +", "+"settledAmount: "+postcardBaseDetails[3] +", "+"closingBalance: "+postcardBaseDetails[4] +", "+"ledgerBalance: "+postcardBaseDetails[5]);

				authorizedAmountValidation = cardBaseDetails[0].equalsIgnoreCase(postcardBaseDetails[0]);
				availableToAuthorizeValidation = cardBaseDetails[1].equalsIgnoreCase(postcardBaseDetails[1]);
				availableToSettleValidation = Double.parseDouble(cardBaseDetails[2])-settledAmount == Double.parseDouble(postcardBaseDetails[2]);
				settledAmountValidation = Double.parseDouble(cardBaseDetails[3])+settledAmount == Double.parseDouble(postcardBaseDetails[3]);
				closingBalanceValidation = Double.parseDouble(cardBaseDetails[4]) == Double.parseDouble(postcardBaseDetails[4].trim());
				ledgerBalanceValidation = Double.parseDouble(cardBaseDetails[5])-settledAmount == Double.parseDouble(postcardBaseDetails[5]);
				break;

			case "06":
			case "25":
				settledAmount = creditSettlementAmount/100;
				Log.info("Post Settlement - Base I and BaseII - authorizedAmount: "+postcardBaseDetails[0]+", "+"availableToAuthorize: "+postcardBaseDetails[1] +", "+"availableToSettle: "+postcardBaseDetails[2] +", "+"settledAmount: "+postcardBaseDetails[3] +", "+"closingBalance: "+postcardBaseDetails[4] +", "+"ledgerBalance: "+postcardBaseDetails[5]);

				authorizedAmountValidation = cardBaseDetails[0].equalsIgnoreCase(postcardBaseDetails[0]);//Double.parseDouble(cardBaseDetails[0]) == Double.parseDouble(postcardBaseDetails[0])-settledAmount;
				availableToAuthorizeValidation = Double.parseDouble(cardBaseDetails[1])+settledAmount == Double.parseDouble(postcardBaseDetails[1]);//Double.parseDouble(cardBaseDetails[1]) == Double.parseDouble(postcardBaseDetails[1])-settledAmount;
				availableToSettleValidation = Double.parseDouble(cardBaseDetails[2])+settledAmount == Double.parseDouble(postcardBaseDetails[2]);
				settledAmountValidation = cardBaseDetails[3].equalsIgnoreCase(postcardBaseDetails[3]);
				closingBalanceValidation = Double.parseDouble(cardBaseDetails[4])+settledAmount == Double.parseDouble(postcardBaseDetails[4].trim());
				ledgerBalanceValidation = Double.parseDouble(cardBaseDetails[5])+settledAmount == Double.parseDouble(postcardBaseDetails[5]);
				break;
		}
		if(authorizedAmountValidation && availableToAuthorizeValidation && availableToSettleValidation && settledAmountValidation && closingBalanceValidation && ledgerBalanceValidation){
			Log.info("authorizedAmountValidation: "+ authorizedAmountValidation +" availableToAuthorizeValidation: "+  availableToAuthorizeValidation +" availableToSettleValidation: "+ availableToSettleValidation +" settledAmountValidation: "+ settledAmountValidation +" closingBalanceValidation: "+ closingBalanceValidation +" ledgerBalanceValidation: "+ ledgerBalanceValidation);
			return true;
		}else{
			Log.info("authorizedAmountValidation: "+ authorizedAmountValidation +" availableToAuthorizeValidation: "+  availableToAuthorizeValidation +" availableToSettleValidation: "+ availableToSettleValidation +" settledAmountValidation: "+ settledAmountValidation +" closingBalanceValidation: "+ closingBalanceValidation +" ledgerBalanceValidation: "+ ledgerBalanceValidation);
			return false;
		}
	}


	//To validate Expired Authorization Details
	public boolean validateExpiredAuthorization(String[] transactionDetails){
		String authApprovalCode = transactionDetails[1];
		double transationAmount = Double.parseDouble(transactionDetails[4])/100;
		AuthSettlements authSettlements = new AuthSettlements();
//		PrepaidDetailsPage prepaidDetailsPage = PageFactory.initElements(AuthSettlements.csrDriver, PrepaidDetailsPage.class);
		driver = AuthSettlements.csrDriver;
		refresh.click();
		//Autorization Tag is Visible
		driver.findElement(By.xpath(authRequestTag)).isDisplayed();
		//Approval Code Displaying
		driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]")).isDisplayed();
		//Authorization Status
		boolean statusValidation = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'Closed')]")).isDisplayed();
		//Available to settle validation
		driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[6]")).getText().isEmpty();
		//Settled Amount
		double settledAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[7]")).getText());
		//Total Transaction Amount
		double totalTransactionAmount = Double.parseDouble(driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//preceding::td[12]")).getText());

		//Authorization Message
		String authMessage = driver.findElement(By.xpath(authRequestTag+"//following::tr[2]//td[contains(text(),'"+authApprovalCode+"')]//following::td[5]")).getText();
		boolean expiryMessageValidation = authMessage.contains("System Auth Has expired on ");

		double reversedAmount = totalTransactionAmount-settledAmount;
		boolean reversedAmountValidation =  authMessage.contains(" reversed an amount of:"+reversedAmount);

		boolean settledAmountValidation = settledAmount != transationAmount;
		Log.info("Expired Authorization Validation Details : -> settledAmountValidation: "+settledAmountValidation+"reversedAmountValidation: "+reversedAmountValidation+"expiryMessageValidation: "+expiryMessageValidation+"statusValidation: "+statusValidation);
		if(settledAmountValidation&&reversedAmountValidation&&expiryMessageValidation&&statusValidation){
			////Log.pass( "Expired Authorization transaction details are validated successfully and valid");
		}else{
			////Log.fail( "Expired Authorization transaction details are validated details are not valid");
		}
		return (settledAmountValidation&&reversedAmountValidation&&expiryMessageValidation&&statusValidation);
	}

	public Object[] validateChargebackPresentment(HashMap settlementDetails, Object[] expectedValidations){
		boolean flag1 = false, flag2=false, flag3=false, flag4=false, flag5=false, flag6=false, flag7=false;
		//transaction page refresh
		refresh.click();
		Generic.waitForElement(driver, driver.findElement(By.xpath(firstChargebackPresentmentTag)), 10);
		//Activation event tag heading
		flag1 = driver.findElement(By.xpath(firstChargebackPresentmentTag)).isDisplayed();
		String approvalCode = settlementDetails.get("AuthCode").toString();
		flag2 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]")).isDisplayed();

//		//Transaction Destination
//		driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[5]")).getText();

		//Transaction Destination
		flag3 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[5]")).getText().trim().equalsIgnoreCase(expectedValidations[0].toString());
		//Process Flag
		flag4 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[6]")).getText().trim().equalsIgnoreCase(expectedValidations[1].toString());
		//Acquirer Reference Number
		flag5 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[12]")).getText().trim().equalsIgnoreCase(expectedValidations[2].toString());
		//Destination Amount
		flag6 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[5]")).getText().trim().equalsIgnoreCase(expectedValidations[3].toString());
		//Chargeback Reason detail
		flag7 = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//following::td[7]")).getText().trim().contains(expectedValidations[4].toString());

		String chargebackTransactionID = driver.findElement(By.xpath(firstChargebackPresentmentTag+"//following::tr[2]//following::tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[7]")).getText().trim();

		boolean flag = flag1&&flag2&&flag3&&flag4&&flag5&&flag6&&flag7;

		if(flag){
			////Log.pass( "Chargeback Presentment transaction is populating in Prepaid detials page");
		}else{
			////Log.fail( "Chargeback Presentment transaction is not populating in Prepaid detials page");
		}

		Object[] chargebackRequestDetails = {flag,chargebackTransactionID};
		return chargebackRequestDetails;
	}


	//Validate Base I and Base II details
	public boolean pre_post_Transaction_BaseIBaseIIValidation(String[] preBaseIBaseIIDetails, String[] postBaseIBaseIIDetails, double transactionAmount, String transactionType) throws Exception{
		boolean authorizedAmountValidation=false;
		boolean availableToAuthorizeValidation=false;
		boolean availableToSettleValidation=false;
		boolean settledAmountValidation=false;
		boolean closingBalanceValidation=false;
		boolean ledgerBalanceValidation=false;

		switch(transactionType){
			case "Credit":
				transactionAmount = +transactionAmount;
				break;
			case "Debit":
				transactionAmount = -transactionAmount;
				break;
			default:
				transactionAmount = 0;
				break;
		}

		Log.info("Before Transaction - Base I and BaseII Details -- Authorized Amount: "+preBaseIBaseIIDetails[0]+", "+"availableToAuthorize: "+preBaseIBaseIIDetails[1] +", "+"availableToSettle: "+preBaseIBaseIIDetails[2] +", "+"settledAmount: "+preBaseIBaseIIDetails[3] +", "+"closingBalance: "+preBaseIBaseIIDetails[4] +", "+"ledgerBalance: "+preBaseIBaseIIDetails[5]);
		Log.info("After Transaction - Base I and BaseII Details -- Authorized Amount: "+postBaseIBaseIIDetails[0]+", "+"availableToAuthorize: "+postBaseIBaseIIDetails[1] +", "+"availableToSettle: "+postBaseIBaseIIDetails[2] +", "+"settledAmount: "+postBaseIBaseIIDetails[3] +", "+"closingBalance: "+postBaseIBaseIIDetails[4] +", "+"ledgerBalance: "+postBaseIBaseIIDetails[5]);

		authorizedAmountValidation = Double.parseDouble(preBaseIBaseIIDetails[0]) == (Double.parseDouble(postBaseIBaseIIDetails[0]))+transactionAmount;
		availableToAuthorizeValidation = (Double.parseDouble(preBaseIBaseIIDetails[1]))+transactionAmount == Double.parseDouble(postBaseIBaseIIDetails[1]);
		availableToSettleValidation = transactionAmount+(Double.parseDouble(preBaseIBaseIIDetails[2])) == Double.parseDouble(postBaseIBaseIIDetails[2]);
		settledAmountValidation = Double.parseDouble(preBaseIBaseIIDetails[3]) == transactionAmount + (Double.parseDouble(postBaseIBaseIIDetails[3]));
		closingBalanceValidation = transactionAmount + (Double.parseDouble(preBaseIBaseIIDetails[4])) == Double.parseDouble(postBaseIBaseIIDetails[4].trim());
		ledgerBalanceValidation = transactionAmount + (Double.parseDouble(preBaseIBaseIIDetails[5])) == Double.parseDouble(postBaseIBaseIIDetails[5]);
		Log.info("BaseI and BaseII validation post Transaction : "+ authorizedAmountValidation +" availableToAuthorizeValidation: "+  availableToAuthorizeValidation +" availableToSettleValidation: "+ availableToSettleValidation +" settledAmountValidation: "+ settledAmountValidation +" closingBalanceValidation: "+ closingBalanceValidation +" ledgerBalanceValidation: "+ ledgerBalanceValidation);
		if(authorizedAmountValidation && availableToAuthorizeValidation && availableToSettleValidation && settledAmountValidation && closingBalanceValidation && ledgerBalanceValidation){
			////Log.pass( "As per the transaction value balance are effected to BaseI and BaseII");
			return true;
		}else{
			////Log.fail( "As per the transaction value balance is not effective to BaseI and BaseII");
			return false;
		}
	}
}

package Prepaid.pageRepo.csr;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ProcessByCardNumber extends BasePage{

    private WebDriver driver;

    public ProcessByCardNumber(WebDriver driver){
        super(driver);
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//input[@id='txtSearch']")
    private WebElement blockedCardSearchTextBox;

    @FindBy(xpath = "//input[@id='btnSearch']")
    private WebElement searchButton;

    @FindBy(xpath = "//table[@id='QUERY_TABLE']//following::a")
    private WebElement processLink;

    @FindBy(xpath = "//table[@id='QUERY_TABLE']//following::a//preceding::center[2]")
    private WebElement loginAttemptsCountText;

    @FindBy(xpath = "//table[@id='QUERY_TABLE']//following::a//preceding::center[3]")
    private WebElement maskedCardNumberText;

    @FindBy(xpath = "//input[@name='txtDescription']")
    private WebElement descriptionTextArea;

    @FindBy(xpath = "//textarea[@name='txtTextArea']")
    private WebElement statusCommentsTextArea;

    @FindBy(xpath = "//select[@name='txtStatus']")
    private WebElement cardStatusSelect;

    @FindBy(xpath = "//input[@name='submit']")
    private WebElement updateCardStatusButton;

    @FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']//font[contains(text(), 'Successfully updated Card details.')]")
    private WebElement statusUpdateSuccessfulMessage;

    public void blockedCardSearch(String cardNumber){
        blockedCardSearchTextBox.sendKeys(cardNumber);
        searchButton.click();
        Generic.wait(5);
    }

    public boolean assertAccessBlockedCardNumber(String cardNumber){
        return maskedCardNumberText.getText().replaceAll("\\s","").contains(Generic.getMaskedCardNumber(cardNumber));
    }

    public boolean assertCardBlockCount(String expectedCount){
        return loginAttemptsCountText.getText().contains(expectedCount);
    }

    public void procesCard(){
        processLink.click();
    }



    public void enterDescription(String description){
        descriptionTextArea.sendKeys(description);
    }

    public void enterStatusUpdateComments(String comments){
        statusCommentsTextArea.sendKeys(comments);
    }

    public void selectCardStatus(String status){
        Select statusDropdown = new Select(cardStatusSelect);
        statusDropdown.selectByValue(status);
    }

    public void saveStatusUpdateRequest(){
        updateCardStatusButton.click();
    }

    public void updateCardStatus(String description, String comments, String status){
        enterDescription(description);
        enterStatusUpdateComments(comments);
        selectCardStatus(status);
        saveStatusUpdateRequest();
    }

    public boolean assertStatusUpdatedSuccessfully(){
        return statusUpdateSuccessfulMessage.isDisplayed();
    }

}

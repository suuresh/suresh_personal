package Prepaid.pageRepo.kotak;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Shankar Reddy on Sep,2021
 */
public class CancelNetCardPage extends BasePage {
    private WebDriver driver;

    public CancelNetCardPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//a[contains(text(),'Cancel')]")
    private WebElement cancelNetCardLink;
    @FindBy(xpath = "//input[contains(@src,'images/cancel.gif')]")
    private WebElement cancelLink;
    @FindBy(xpath = "//font[contains(text(),'Cancellation')]/../../..//tr[2]/td/p/font")

    private WebElement canellationSuccessMessage;

    //To click on cancel net card link on kotak net card page
    public void clickCancelCard() {
        cancelNetCardLink.click();
    }

    //To select the net card for cancellation
    public void selectNetCard(String cardNumber) {
        String xpath = "//input[contains(@value,'" + cardNumber + ",')]";
        driver.findElement(By.xpath(xpath)).click();

    }

    //To verify the the net card is selected post clicking  on checkbox.
    public Boolean verifyCheckBoxSelected(String cardNumber) {
        String xpath = "//input[contains(@value,'" + cardNumber + ",')]";
        return(driver.findElement(By.xpath(xpath)).isSelected());
    }

    //To Click on cancel button
    public void clickCancelLink() {
        cancelLink.click();
    }

    //To verify whether the net card is cancelled successfully and success message is dispalyed.
    public String getSuccessMessage() {
        return (canellationSuccessMessage.getText());
    }

}

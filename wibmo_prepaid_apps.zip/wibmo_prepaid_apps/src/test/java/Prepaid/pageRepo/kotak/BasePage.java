package Prepaid.pageRepo.kotak;


import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import library.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.List;


public class BasePage {
    public static WebDriver driver;
    public static ExtentTest logger;
    WebDriverWait wait;

    //*** commonly used web elements    
    //Menu Section
    //Customer ID
    @FindBy(xpath = "//input[@name='crn']")
    WebElement custID;
    //Session ID
    @FindBy(xpath = "//input[@name='sessionId']")
    WebElement sessionID;
    //Login Link
    @FindBy(xpath = "//a[contains(text(), 'Click Here to login to NetBanking')]")
    WebElement netCardLogin;


    @FindBy(xpath = "//frameset/frame[1]")
    WebElement headerFrame;
    @FindBy(xpath = "//frameset/frame[2]")
    WebElement bodyFrame;
    @FindBy(xpath = "//form[@name='processing']//iframe")
    WebElement formFrame;
    //netc@rd link
    @FindBy(xpath = "//a/font[contains(text(), 'netc@rd')]")
//	@FindBy(xpath="//a[contains(text(),'Generate')]/i[contains(text(),'netc@rd')]")	
            WebElement netCardLink;

    @FindBy(id = "txtFirstName")
    WebElement firstName;

    @FindBy(name = "rdoAccountNumber")
    WebElement selectAcc;

    @FindBy(name = "txtCardLimit")
    WebElement cardLimit;

    @FindBy(id = "btn")
    WebElement submit;

    @FindBy(xpath = "//td[contains(text(), 'has been successfully created')]")
    WebElement successNotification;

    @FindBy(xpath = "//a/font[contains(text(),'Logout')]")
    WebElement logout;

    @FindBy(xpath = "//b[contains(text(), 'For your safety, you have been logged out of netc@rd. Please Login again.')]")
    WebElement loggedOutSuccessful;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }


    public void loadFrame() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.getElementByName('//frameset/frame[2]').contentWindow.location.reload();");
    }

    public void loginNetCard(String customerId, String sessionid) {
        Log.info( "Login To NetCard");
        custID.sendKeys(customerId);
        sessionID.sendKeys(sessionid);
        netCardLogin.click();
    }


    public boolean logout() throws InterruptedException {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(headerFrame);
        logout.click();
//		Thread.sleep(10000);
        Log.pass( "Logout Successful");
        driver.switchTo().defaultContent();
        driver.switchTo().frame(bodyFrame);
        return loggedOutSuccessful.isDisplayed();
    }

    public void explicitWait(WebElement element) {
        wait = new WebDriverWait(driver, 10000);
        wait.until(ExpectedConditions.visibilityOf(element));
    }
}
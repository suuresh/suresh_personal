/**
 * 
 */
package Prepaid.pageRepo.transactions;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.csr.settlements.AuthSettlements;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

/**
 * @author ${Srikiran D}
 *
 */
public class ChargeBackPage extends BasePage
{
	WebDriver driver;
	/**
	 * initialization of all the web elements
	 * @param driver
	 */

	public ChargeBackPage(WebDriver driver)
	{
		super(driver);
		this.driver =driver;
		PageFactory.initElements(this.driver, this);
	}

	//WebElements of Chargeback process page 
	
	@FindBy(id="txtCCNumber")
	private WebElement cardNumberTextbox;
	
	@FindBy(id = "fromDate")
	private WebElement fromDateTextBox;
	
	@FindBy(id = "toDate")
	private WebElement toDateTextBox;
	
	@FindBy(name = "submit")
	private WebElement submitButton;
	
	@FindBy(name = "txtAuthId")
	private WebElement authIdTextbox;
	
	@FindBy(name = "cboReasonCode")
	private WebElement reasonCodeSelect;
	
	@FindBy(name = "vrollId")
	private WebElement vRollIDTextbox;
	
	@FindBy(name="txtMsg")
	private WebElement messageTextField;
	
	@FindBy(name="Submit")
	private WebElement chargebackSubmit;
	
	@FindBy(xpath="//iframe[@src='billedRecords_Lite.jsp']")
	private WebElement billedItemsList;
	
	@FindBy(xpath="//iframe[@src='billedDetailsRecord_Lite.jsp']")
	private WebElement billedItemsDetailsRecord;
	
	String billedItemsListReport = "//form[@name='frmExceptionlistPassword']/table//tr";
	
	//Credit Chargeback page
	@FindBy(id="searchOptions")
	private WebElement searchCreditItemBy;
	@FindBy(id="iccNumber")
	private WebElement cardSearchTextField;
	@FindBy(xpath = "//input[@value='Search']")
	private WebElement searchCreditChargebackItem;
	
	@FindBy(xpath="//table[@id='QUERY_SUB_TABLE']//input[@value='Reverse']")
	private WebElement chargebackReverseButton;
	

	public void searchBilledItems(String cardNumber, Object[] dateRange){
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe")));
		chargebackBilledItems_Lite.click();
		driver.switchTo().defaultContent();
		cardNumberTextbox.clear();
		cardNumberTextbox.sendKeys(cardNumber);
		fromDateTextBox.clear();
		fromDateTextBox.sendKeys(dateRange[1].toString());
		toDateTextBox.clear();
		toDateTextBox.sendKeys(dateRange[0].toString());
		submitButton.click();	
	}
	
	public boolean viewChargebackDetails(HashMap<String, String> settlementDetails) throws Exception{
		boolean flag1=false;
		
		String settlementId = settlementDetails.get("settlementRefNumber");
		String cardNumber = settlementDetails.get("cardNumber");
		String authID = settlementDetails.get("authorizationID");
		
		//if billed item is not displaying to process chargeback looking in to exception list and clearing
		ProcessExceptionItemsPage pei = new ProcessExceptionItemsPage(driver);
		driver.switchTo().frame(billedItemsList);		
		if(driver.findElements(By.xpath("//th[contains(text(),'"+settlementId+"')]//preceding::th[1]/a")).size() == 0){
			driver.switchTo().defaultContent();
			flag1 = pei.clearExceptionItem(settlementId, cardNumber, authID, "Accept");
			Object[] dateRange = {Generic.currentDate("dd/MM/YYYY"), Generic.getPastOrFutureDate("dd/MM/YYYY", -10)};
			searchBilledItems(cardNumber, dateRange);
			driver.switchTo().frame(billedItemsList);
			if(flag1 && driver.findElement(By.xpath("//th[contains(text(),'"+settlementId+"')]//preceding::th[1]/a")).isDisplayed()){
				flag1 = true;
			}else{
				flag1 = false;
			}
		}				
		driver.findElement(By.xpath("//th[contains(text(),'"+settlementId+"')]//preceding::th[1]/a")).click();
		return flag1;
	}
	
	public boolean validateBilledItemDetails(String cardNumber, HashMap settlementDetails){
		
		boolean flag1 = false, flag2 = false, flag3 = false, flag4 = false, flag5 = false, flag6 = false, flag7 = false, flag8 = false;
		driver.switchTo().frame(billedItemsDetailsRecord);
		//validating masked card number
		flag1 = driver.findElement(By.xpath("//div[contains(text(),'Primary Account Number :')]//following::td[1]/div")).getText().contains(Generic.getLast4DigitCardNumber(cardNumber));
		//validating settlement Reference Number
		flag2 = driver.findElement(By.xpath("//div[contains(text(),'Transaction Code :')]//following::td[1]/div")).getText().contains(settlementDetails.get("settlementRefNumber").toString());
		//validating destination amount value
		flag3 = driver.findElement(By.xpath("//div[contains(text(),'Destination Amount :')]//following::td[1]/div")).getText().contains(settlementDetails.get("Settlement Amt").toString());
		//validating purchase date
		flag4 = driver.findElement(By.xpath("//div[contains(text(),'Purchase Date :')]//following::td[1]/div")).getText().contains(settlementDetails.get("purchaseDate").toString());
		//validating acquirer reference number
		flag5 = driver.findElement(By.xpath("//div[contains(text(),'Acquirer Reference Number :')]//following::td[1]/div")).getText().contains(settlementDetails.get("Arn").toString());
		//validating authorization approval id
		flag6 = driver.findElement(By.xpath("//div[contains(text(),'Authorisation Code :')]//following::td[1]/div")).getText().contains(settlementDetails.get("AuthCode").toString());
		//validating authorization merchant code
		flag7 = driver.findElement(By.xpath("//div[contains(text(),'Merchant Category Code :')]//following::td[1]/div")).getText().contains(settlementDetails.get("MCC").toString());
		//validating authorization ID detail
//		flag8 = driver.findElement(By.xpath("//div[contains(text(),'Authorisation Code :')]//following::td[1]/div")).getText().contains(settlementDetails.get("authorizationID").toString());
		
		return flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7;
	}	
	
	public Object[] submitChargebackRequest(String authID){
		
		authIdTextbox.clear();
		authIdTextbox.sendKeys(authID);
		vRollIDTextbox.clear();
		vRollIDTextbox.sendKeys(authID);
		//Select of chargeback reason code
		Select reasonCode = new Select(reasonCodeSelect);
		ArrayList<Integer> reasonValue = new ArrayList<>(Arrays.asList(10,11,12,13,30,41,53,57,60,62,70,71,72,73,74,75,76,77,78,80,81,82,83,85,86,90,93,96)); 
		Random rand = new Random();		
		String reason = reasonValue.get(rand.nextInt(reasonValue.size())).toString();
		reasonCode.selectByValue(reason);	
		messageTextField.clear();
		messageTextField.sendKeys("Chargeback for "+reason+" on authorization "+authID);
		chargebackSubmit.click();
		Generic.wait(5000);
		boolean requestStatus = driver.findElement(By.xpath("//table//tr[3]/td//font")).getText().contains("The record has been successfully updated for card number");
		Object[] chargebackDetails =  {requestStatus, reason};
		driver.switchTo().defaultContent();
		return chargebackDetails;
		
	}
	
	public HashMap<String, String> raiseChargebackRequest(String cardNumber, Object[] dateRange, HashMap<String, String> settlementDetails) throws Exception{	
		
		Object[] chargebackDetails = null ;
		settlementDetails.put("cardNumber", cardNumber);
//		PrepaidDetailsPage csrpdp = new PrepaidDetailsPage(driver);
		searchBilledItems(cardNumber, dateRange);
		boolean flag = viewChargebackDetails(settlementDetails);
		validateBilledItemDetails(cardNumber, settlementDetails);
		Object[] requestedChargebackDetails = submitChargebackRequest(settlementDetails.get("authorizationID"));
		if((boolean) requestedChargebackDetails[0]){
			settlementDetails.put("ChargebackReason", requestedChargebackDetails[1].toString());			
			
			// Transaction Destination, Process Flag, Acquirer Reference number, Destination Amount, Chargeback Reason Code, 
			Object[] expectedChargebackVaildation = {1, 0, settlementDetails.get("Arn"), settlementDetails.get("Settlement Amt"), settlementDetails.get("ChargebackReason")};
			AuthSettlements.pdp.checkPrepaidDetails(cardNumber);
			Object[] chargebackRequestDetails = AuthSettlements.pdp.validateChargebackPresentment(settlementDetails, expectedChargebackVaildation);
		}else{
			//Log.fail( "Could not raise Chargeback Request");
			//logger.log(LogStatus.SKIP, "Skipping the case");
			//logger.log(LogStatus.FATAL, "Skipping the case");
		}
		
		WebDriver csrdriver = driver;
		String csrWindow = driver.getWindowHandle();
		
		EOD_Login_Page eodJobs = new EOD_Login_Page(driver);
		boolean jobStatus = eodJobs.loginExecuteJobLogout("Charge Back File Generator");	
		
		driver = csrdriver;
		driver.switchTo().window(csrWindow);
		
		if(jobStatus){
			//Log.pass( "Charge Back File Generator Job Executed Successfully");
			//Validating Chargeback details post Charge Back File Generator job executing succesfully
			//Log.info( "Validating Chargeback details post Charge Back File Generator job executing succesfully");
			// Transaction Destination, Process Flag, Acquirer Reference number, Destination Amount, Chargeback Reason Code, 
			Object[] expectedChargebackVaildation = {1, 2, settlementDetails.get("Arn"), settlementDetails.get("Settlement Amt"), settlementDetails.get("ChargebackReason")};
			chargebackDetails = AuthSettlements.pdp.validateChargebackPresentment(settlementDetails, expectedChargebackVaildation);
			settlementDetails.put("ChargebackTransId", chargebackDetails[1].toString());
			AuthSettlements.pdp.back.click();
		}else{
			//Log.fail( "Charge Back File Generator Job is failure");
			//logger.log(LogStatus.SKIP, "Skipping the case");
		}	
		
		if(Boolean.parseBoolean(chargebackDetails[0].toString())){
			settlementDetails.put("Chargeback Processed", chargebackDetails[0].toString());
			//Log.pass( "Chargeback Request has processed successful");
		}else{
			settlementDetails.put("Chargeback Processed", chargebackDetails[0].toString());
			//Log.fail( "Chargeback Request processing is not successful");
			//logger.log(LogStatus.SKIP, "Skipping the case");
		}		
		return settlementDetails;
	}
	
	
	public boolean creditChargeback(HashMap settlementDetails) throws Exception{
		
		searchForCreditChargebackInfo(settlementDetails.get("cardNumber").toString());
		Generic.waitForElement(driver, driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]")), 30);
		boolean chargebackRaised = validateCreditChargebackDetails(settlementDetails);
		if(chargebackRaised){
			//Log.info( //logger.addScreenCapture(helper.getFullPageScreenshot(driver).toString()));
			//Log.pass( "Requested Chargeback is populating in credit chargeback list");
			//select raised Credit Chargeback Item
			 driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]")).click();
		}else{
			//Log.fail(  "Requested Chargeback is not populating in credit chargeback list");
			//logger.log(LogStatus.SKIP, "Skipping the case");
		}		
		boolean chargebackProcessed = validateAndProcessCreditChargeBack(settlementDetails);
		return chargebackProcessed;
	}
	
	public void searchForCreditChargebackInfo(String cardNumber){
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe")));
		creditChargebackAmount_Lite.click();
		Select searchBy = new Select(searchCreditItemBy);
		searchBy.selectByVisibleText("Card Number");
		cardSearchTextField.clear();
		cardSearchTextField.sendKeys(cardNumber);
		searchCreditChargebackItem.click();
		driver.switchTo().defaultContent();
	}
	
	public boolean validateCreditChargebackDetails(HashMap settlementDetails){
		boolean flag1=false, flag2=false, flag3=false, flag4=false, flag5=false;
		
		//Validating Transaction ID for ChargeBack
		flag1 = driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]")).isDisplayed();
		//validating Destination amount
		flag2 = driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]//following::td[3]")).getText().trim().equalsIgnoreCase(settlementDetails.get("Settlement Amt").toString());
		//validating Auth Code
		flag3 = driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]//following::td[6]")).getText().trim().equalsIgnoreCase(settlementDetails.get("AuthCode").toString());
		//validating MCC Code
		flag4 = driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]//following::td[7]")).getText().trim().equalsIgnoreCase(settlementDetails.get("MCC").toString());
		//validating Chargeback Reason code
		flag5 = driver.findElement(By.xpath("//table//a[contains(text(),'"+settlementDetails.get("ChargebackTransId").toString()+"')]//following::td[8]")).getText().trim().contains(settlementDetails.get("ChargebackReason").toString());
		
		return flag1&& flag2&& flag3&& flag4&& flag5;
	}

	public boolean validateAndProcessCreditChargeBack(HashMap settlementDetails){
		boolean flag1=false, flag2=false;
		Generic.waitForElement(driver, driver.findElement(By.xpath("//table[@id='QUERY_SUB_TABLE']//td[contains(text(),'"+settlementDetails.get("ChargebackTransId")+"')]")),30);
		flag1 = driver.findElement(By.xpath("//table[@id='QUERY_SUB_TABLE']//td[contains(text(),'"+settlementDetails.get("ChargebackTransId")+"')]")).isDisplayed();
		Generic.waitForElement(driver, chargebackReverseButton,30);
		chargebackReverseButton.click();
		Generic.waitForElement(driver, driver.findElement(By.xpath("//font[contains(text(),'Transaction reversal was sucessful')]")),30);
		flag2 = driver.findElement(By.xpath("//font[contains(text(),'Transaction reversal was sucessful')]")).isDisplayed();
		return flag1&&flag2;
	}
	
}

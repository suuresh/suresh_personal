package Prepaid.pageRepo.transactions;

import Prepaid.pageRepo.BasePage;
import com.relevantcodes.extentreports.LogStatus;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * @author ${Srikiran D}
 *
 */
public class ProcessExceptionItemsPage extends BasePage
{
	WebDriver driver;

	public ProcessExceptionItemsPage(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}


	//WebElements of Process Exception Items Page
	
	@FindBy(id="searchOptions")
	private WebElement searchExceptionBySelect;
	
	@FindBy(id="iccNumber")
	private WebElement exceptionCardNumber;
	
	@FindBy(xpath = "//iframe[@src='exceptionRecords.jsp']")
	private WebElement exceptionItemsListsection;
	
	private String exceptionItemsGrid = "//form[@name='frmExceptionlistPassword']//table";
	
	@FindBy(xpath = "//iframe[@src='exceptionDetailRecord.jsp']")
	private WebElement exceptionTransactionFrame;
	
	@FindBy(xpath = "//form[@name='frmExceptionItemDetails']")
	private WebElement exceptionTransactionDetails;
	
	@FindBy(xpath="//input[@name='txtAuthId']")
	private WebElement authIdTextfield;
	
	@FindBy(id="cboDestination")
	private WebElement destinationSelect;
	
	@FindBy(xpath = "//select[@name='fraudType']")
	private WebElement fraudTypeSelect;
	
	@FindBy(id="vrollId")
	private WebElement vrollIDTextfield;
	
	@FindBy(xpath = "//select[@name='docindicator']")
	private WebElement documentIncicatorSelect;
	
	@FindBy(xpath = "//select[@name='cboReasonCode']")
	private WebElement reasonCodeSelect;
	
	@FindBy(xpath = "//textarea[@name='txtMsg']")
	private WebElement exceptionMessage;
	
	@FindBy(id="Submit")
	private WebElement submitException;
	
	@FindBy(xpath = "//div[contains(text(),'Primary Account Number :')]//following::td[1]/div")
	private WebElement maskedCardNumber;
	@FindBy(xpath = "//div[contains(text(),'Destination Amount :')]//following::td[1]/div")
	private WebElement destinationAmount;
	@FindBy(xpath = "//div[contains(text(),'Settlement Transaction Id :')]//following::td[1]/div")
	private WebElement settlementTransactionId;
	@FindBy(xpath = "//div[contains(text(),'Authorisation Amout :')]//following::td[1]/div")
	private WebElement authorisationAmount;
	@FindBy(xpath = "//div[contains(text(),'Acquirer Reference Number :')]//following::td[1]/div")
	private WebElement arNumber;
	@FindBy(xpath = "//div[contains(text(),'Authorisation Code :')]//following::td[1]/div")
	private WebElement authorisationCode;
	@FindBy(xpath = "//div[contains(text(),'Error Message :')]//following::td[1]/div")
	private WebElement errorMessage;
	@FindBy(xpath = "//div[contains(text(),'Processed Flag :')]//following::td[1]/div")
	private WebElement processedFlag;
	@FindBy(xpath = "//div[contains(text(),'Purchase Date :')]//following::td[1]/div")
	private WebElement purchaseDate;
	
	//Credit Chargeback page
	@FindBy(id="searchOptions")
	private WebElement searchCreditItemBy;
	@FindBy(id="iccNumber")
	private WebElement cardSearchTextField;
	@FindBy(xpath = "//input[@value='Search']")
	private WebElement searchCreditChargebackItem;
	
	@FindBy(xpath="//table[@id='QUERY_SUB_TABLE']//input[@value='Reverse']")
	private WebElement chargebackReverseButton;
	

	
	public void searchForExceptionItems(String cardNumber) throws Exception{
		accosaLiteLink.click();
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe")));
		processExceptionItems.click();
		Select searchBy = new Select(searchExceptionBySelect);
		searchBy.selectByVisibleText("Card Number");
		cardSearchTextField.clear();
		cardSearchTextField.sendKeys(cardNumber);
		searchCreditChargebackItem.click();
		driver.switchTo().defaultContent();
	}
	
	public void viewExceptionItems(String settlementId){
		driver.switchTo().frame(exceptionItemsListsection);
		driver.findElement(By.xpath(exceptionItemsGrid+"//tr//th[contains(text(), '"+settlementId+"')]//preceding::a[1]")).click();
		driver.switchTo().defaultContent();
	}
	
	public boolean processExceptionItem(String authID, String destinationValue){
		boolean flag1=false;
		Random rand = new Random();
		
		ArrayList<Integer> fraudValue = new ArrayList<>(Arrays.asList(0,1,2,3,4,5,6,9)); 		
		String fraud = fraudValue.get(rand.nextInt(fraudValue.size())).toString();
		
		ArrayList<Integer> docIndicatorValue = new ArrayList<>(Arrays.asList(0,1,2,3,4));
		String docIndicator = docIndicatorValue.get(rand.nextInt(docIndicatorValue.size())).toString();
		
		ArrayList<Integer> reasonValue = new ArrayList<>(Arrays.asList(10,11,12,13,30,41,53,57,60,62,70,71,72,73,74,75,76,77,78,80,81,82,83,85,86,90,93,96));
		String reason = reasonValue.get(rand.nextInt(reasonValue.size())).toString();
		
		
		List<WebElement> i = driver.findElements(By.xpath("//iframe[@src='exceptionDetailRecord.jsp']"));
		if(i.size()!=0){
			driver.switchTo().frame(exceptionTransactionFrame);
		}
		authIdTextfield.clear();
		authIdTextfield.sendKeys(authID);
		Select destination = new Select(destinationSelect);
		Select fraudType = new Select(fraudTypeSelect);
		Select documentIndicator = new Select(documentIncicatorSelect);
		Select reasonCode = new Select(reasonCodeSelect);
		
		if(destinationValue.equalsIgnoreCase("First ChargeBack")){

			destination.selectByVisibleText(destinationValue);
			vrollIDTextfield.clear();
			vrollIDTextfield.sendKeys(authID);

			documentIndicator.selectByValue(docIndicator);

			reasonCode.selectByValue(reason);
		}else{

			destination.selectByVisibleText(destinationValue);
			fraudType.selectByValue(fraud);	

		}
		exceptionMessage.clear();

		exceptionMessage.sendKeys(authID+" "+destinationValue);
		submitException.click();
		try{
			driver.switchTo().alert().accept();
		}catch(Exception e){

		}
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//font[contains(text(), 'The record has been successfully updated ')]"))));
		Generic.waitForElement(driver, driver.findElement(By.xpath("//font[contains(text(), 'The record has been successfully updated ')]")), 10000);
		flag1 = driver.findElement(By.xpath("//font[contains(text(), 'The record has been successfully updated ')]")).isDisplayed();
		driver.switchTo().defaultContent();
		return flag1;
	}
	
	public Boolean validateExceptionItem(String cardNumber, String settlementId, String settledAmount, 
			String authorizedAmount, String authorizedDate, String arn, String authCode, 
			String errorMsg, String processedCode){
		Boolean flag1=false, flag2=false, flag3=false, flag4=false, flag5=false, flag6=false, flag7=false, flag8=false, flag9=false;
		
		driver.switchTo().frame(exceptionTransactionFrame);
		String last4digit = Generic.getLast4DigitCardNumber(cardNumber);
		//CardNumber
		System.out.println(maskedCardNumber.getText().trim());
		flag1 = maskedCardNumber.getText().trim().contains(last4digit);
		//settlementId
		flag2 = settlementTransactionId.getText().contains(settlementId);
		//SettledAmount/Destination Amount
		flag3 = destinationAmount.getText().contains(settledAmount);
		//Authorized Amount
		flag4 = authorisationAmount.getText().contains(authorizedAmount);
		//Purchase Date
		flag5 = purchaseDate.getText().contains(authorizedDate);
		//ARN
		flag6 = arNumber.getText().contains(arn);
		//authorization Code
		flag7 = authorisationCode.getText().contains(authCode);
		//Error Message
		if(errorMsg==null){ errorMsg="";}
		flag8 = errorMessage.getText().contains(errorMsg);
		//ProcessedFlag
		if(processedCode.equalsIgnoreCase("0")){
			flag9 = processedFlag.getText().contains("No");
		}
		return flag1&&flag2&&flag3&&flag4&&flag5&&flag6&&flag7&&flag8&&flag9;
	}
	
	public boolean  clearExceptionItem(String settlementId, String cardNumber, String authID, String destinationValue)throws Exception{
		searchForExceptionItems(cardNumber);
		viewExceptionItems(settlementId);
		return processExceptionItem(authID, destinationValue);
	}
	
}

/**
 *
 */
package Prepaid.pageRepo.transactions;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import Prepaid.pageRepo.eodBatchJobs.EOD_Login_Page;
import Prepaid.testScripts.BaseTest1;
import Prepaid.testScripts.csr.settlements.AuthSettlements;
import library.DataProviderUtility;
import library.Generic;
import library.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.testng.Assert.assertTrue;

/**
 * @author ${Srikiran}
 *
 */

public class SettlementPage extends BasePage
{
	int settlementAmount;
	String settlementApprovalCode;

	AuthSettlements authSettlementsTest = new AuthSettlements();

	private @FindBy(xpath="//input[@name='txtBrowse']")
	WebElement chooseFile;

	private @FindBy(xpath="//input[@value = 'Send the file']")
	WebElement sendFile;

	private WebDriver driver;

	private static String settlementFilesFolder = System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+BaseTest1.ENV+File.separator+"Settlement_Files"+File.separator;

	// Initialization of all the web Elements using page factory		
	public SettlementPage(WebDriver driver)
	{
		super(driver);
		this.driver =driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 * this method is used to Compose Settlement File
	 * @param settlementCardDetails = {cardNumber, approvalCode, mcc, settlementType, transactionAmount, acquiringInstution, transactionDate, arn}
	 * @return
	 */
//	Object[][] settlementCardDetails 
	public String GenerateSettlementFile(boolean bulk, Object[][] settlementCardDetails){
		Log.info("Settlement process Started");

		String issuerBin = BaseTest1.getBinDetails();
		String Settlementfile = "";
		String totalSettlementLine = "";
		String mmdd;// = String.format("%013d", Integer.parseInt(Generic.DateMMDD()));
		String julianDate = Generic.JulianDate();//yyDDD
		String fileDate = Generic.currentDate("ddMMyyyy_hhmm");
		String filePrefix = "Auto_"+fileDate;
		String line90;
		String line91;
		String line92;
		String settlementType = null;
		String settlementEvent = null;
		File settlementFile = null;
		FileOutputStream fos = null;
		String fileId = Generic.getRandomNumberInRange(1111,9999);

		line90 = "90"+issuerBin+julianDate+"      "+julianDate+"  300                                 "+"8084BII      "+fileId;
		totalSettlementLine = totalSettlementLine+line90;

		int i=0;

		if(bulk){
			settlementCardDetails = DataProviderUtility.GetData(System.getProperty("user.dir")+"\\DataFolder\\Settlement file data.xlsx", "BulkSettlement");
			i=1;
		}

		for(i=i; i<settlementCardDetails.length; i++){
			System.out.println("Settlement Record Row :"+i);
			String cardNumber = settlementCardDetails[i][0].toString();
			String approvalCode = settlementCardDetails[i][1].toString();
			String mcc = settlementCardDetails[i][2].toString();
			settlementType = settlementCardDetails[i][3].toString();
			String secondPresentment = settlementType.substring(2);
			settlementType = settlementType.substring(0, 2);
			if(secondPresentment.length()>=1){
				settlementEvent = secondPresentment.substring(1);
			}
			String settlementAmount = String.format("%012d", Integer.parseInt(settlementCardDetails[i][4].toString()));
			String settlementCurrency = settlementCardDetails[i][5].toString();
			String arn = settlementCardDetails[i][7].toString();
			mmdd = String.format("%012d", Integer.parseInt(settlementCardDetails[i][6].toString()));

			line90 ="";
			line91 ="";
			line92 ="";
			String acquirerReferenceNumber = "";

			String tcr0 = null;
			String tcr1 = null;
			String tcr4 = "";
			String tcr5 = null;
			acquirerReferenceNumber = String.format("%023d",Integer.parseInt(julianDate)); // ARN--REF NUMBER
//		            acquirerReferenceNumber = julianDate+fileId+"111000101"+approvalCode; // ARN--REF NUMBER
			tcr0 = "\n"+settlementType+"00"+cardNumber+"000Z  "+acquirerReferenceNumber+mmdd+settlementAmount+settlementCurrency+settlementAmount+settlementCurrency+"AUTOMATION MERCHANT      JAKARTA      ID "+mcc+"00000     1008M"+approvalCode+"8   0"+julianDate+"0";
			tcr1 = "\n"+settlementType+"01            000000                                                          I02529         10004455000000000000  000000      0                           000000000";

			if(secondPresentment.contains("2")){
				tcr0=null;
				switch(settlementEvent){
					case "P1":
						settlementType = "05";
						break;
					case "L1":
					case "L2":
					case "L3":
						settlementType = "25";
						break;
					case "R2":
					case "R3":
						settlementType = "35";
						break;
					default:
						settlementType = "05";
						settlementEvent = "P1";
						break;
				}
				tcr0 = "\n"+settlementType+"00"+cardNumber+"000Z  "+acquirerReferenceNumber+mmdd+settlementAmount+settlementCurrency+settlementAmount+settlementCurrency+"AUTOMATION MERCHANT      JAKARTA      ID "+mcc+"00000     9008M"+approvalCode+"8   0"+julianDate+"0";
				tcr4 = "\n"+settlementType+"04          DF0002                              1  13.1-8081  9TY88J889500000000001759491082          "+settlementEvent+"00000000DB";
			}
			tcr5 = "\n"+settlementType+"05611234545222089"+settlementAmount+settlementCurrency+"          0000 000000000000                              000000000000000 0000000000000000900000000000";

			totalSettlementLine = totalSettlementLine+tcr0+tcr1+tcr4+tcr5;
		}
		int noOflines = totalSettlementLine.split("\n").length;
		String formatednoOflines91 = String.format("%012d", noOflines);
		noOflines++;
		String formatednoOflines92 = String.format("%012d", noOflines);

		int noOfRecords = (noOflines-1)/3;
		noOfRecords++;
		String formatednoOfRecords91 = String.format("%09d", noOfRecords);
		noOfRecords++;
		String formatednoOfRecords92 = String.format("%09d", noOfRecords);

		line91 ="\n"+"9100"+issuerBin+julianDate+"000000000000000000000000003000001"+formatednoOflines91+"000000        "+formatednoOfRecords91+"000000000000000000000000000000000000000000000000000000000000000000000000000000";
		line92 ="\n"+"9200"+issuerBin+julianDate+"000000000000000000000000003000001"+formatednoOflines92+"000000        "+formatednoOfRecords92+"000000000000000000000000000000000000000000000000000000000000000000000000000000";
		totalSettlementLine = totalSettlementLine+line91+line92;

		/* Create a file name for the settlement*/
		String settlementFilename = settlementType+"_"+filePrefix+"_"+fileDate+"_"+fileId+".001";
		settlementFile = new File(settlementFilesFolder+settlementFilename);
		try{
			settlementFile.createNewFile();
			fos = new FileOutputStream(settlementFile);
			byte[] dataToWrite = totalSettlementLine.getBytes();
			fos.write(dataToWrite);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return settlementFile.getName();
	}

	public boolean UploadFileUsingSendKeys(String fileName)throws InterruptedException {

		String filepath = settlementFilesFolder+fileName;
		System.out.println("Settlement upload path:"+filepath);
		WebElement fileInput = chooseFile;
		fileInput.sendKeys(filepath);
		// Added a wait to make you notice the difference.
		Generic.wait(3);
		sendFile.click();
		Generic.wait(3);
		return driver.findElement(By.xpath("//font[contains(text(),'File has been successfully uploaded to the Server')]")).isDisplayed();
//
	}

	public boolean settlementFileUpload(String fileName){
		boolean uploadSuccessful=false;
		try{
			System.out.println("Driver"+driver);
			String window = driver.getWindowHandle();
			driver.switchTo().window(window);
			chooseFile.click();
			Generic.wait(10);

			//put path to your image in a clipboard
			StringSelection ss = new StringSelection(settlementFilesFolder+fileName);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

			//imitate keyboard events like ENTER, CTRL+C, CTRL+V
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Generic.wait(5);
			driver.switchTo().defaultContent();
			sendFile.click();
			Generic.wait(5);
			uploadSuccessful = driver.findElement(By.xpath("//font[contains(text(),'File has been successfully uploaded to the Server')]")).isDisplayed();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return 	uploadSuccessful;
	}

	public List<String> settlementType(String settlementType, String approvalCode, String cardNumber, String mcc, String transactionAmount, String acquiringInstution, String transactionDate, String debitPrimaryCondition, String debitSecondaryCondition, String creditPrimaryCondition, String creditSecondaryCondition, String debitRPrimaryCondition, String debitRSecondaryCondition, String creditRPrimaryCondition, String creditRSecondaryCondition, String mccBuffer, String crossCurrencyFee){
		List<String> settlementFileName = new ArrayList<String>();
		List<String> debitSettlementFileName = new ArrayList<String>();
		List<String> creditSettlementFileName = new ArrayList<String>();
		List<String> creditSettlementReversalFileName = new ArrayList<String>();
		AuthorizationJSPPage ajspPage = new AuthorizationJSPPage(driver);

		try{
			// @return transactionDetails = cardNumber, approvalCode, mcc, transactionAmountDE4, acquiringInstutionD19, mccBuffer, crossCurrencyFee
			HashMap<String, String> transactionDetails = new HashMap<String, String>();
			if(approvalCode.isEmpty()){
				//@parameter : authType, transactionType, cardNumber, transactionAmountDE4, cardHolderBillingDE6, expiry, mcc, panEntryMode, pinEntryCapability, serviceCode, pvv, acquiringInstutionD19, AuthCurrencyD49, CardCurrencyD51, posCondCode, terminalType, terminalEntry, additionAuthindicator
				//@Return : Card Number, Expiry, Approval Code, MCC, Authorization RRN, Authorization Amount, Authorization Currency Code, Authorization RRN, Response Code, Transaction Date, MCC Buffer Charges, Cross Currency Fee}
				transactionDetails = ajspPage.authorize("visa", "ECOM", "Transaction", "", "10000", "10000", "", "5999", "5", "2", "226", "546", "356", "356", "356", "0", "0", "5", "0");
				if(transactionDetails.get("Response Code").equalsIgnoreCase("00")){
					cardNumber = transactionDetails.get("Card Number");
					approvalCode = transactionDetails.get("Approval Code");
					mcc = transactionDetails.get("MCC Code");
					transactionAmount = transactionDetails.get("Authorization Amount");
					acquiringInstution = transactionDetails.get("Authorization Currency Code");
					mccBuffer = transactionDetails.get("MCC Buffer Charges");
					crossCurrencyFee = transactionDetails.get("Cross Currency Fee");
				}else{
				}
			}
			String secondPresentment = settlementType.substring(2);
			settlementType = settlementType.substring(0, 2);
			switch(settlementType)
			{
				//Debit Settlement
				case "05":
					settlementFileName = settlementCondition(settlementType+secondPresentment, debitPrimaryCondition, debitSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.debitSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("debitSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					break;
				//Credit Settlement
				case "06":
					debitSettlementFileName = settlementCondition("05", debitPrimaryCondition, debitSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.debitSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("debitSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					settlementFileName.addAll(0, debitSettlementFileName);

					creditSettlementFileName = settlementCondition("06", creditPrimaryCondition, creditSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.creditSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("creditSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					settlementFileName.addAll(debitSettlementFileName.size(), creditSettlementFileName);
					break;
				//Debit Reversal
				case "25":
					debitSettlementFileName = settlementCondition("05", debitPrimaryCondition, debitSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.debitSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("debitSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					settlementFileName.addAll(0, debitSettlementFileName);

					creditSettlementFileName = settlementCondition("25", debitRPrimaryCondition, debitRSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.debitReversalSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("debitReversalSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					settlementFileName.addAll(settlementFileName.size(), creditSettlementFileName);
					break;
				//Credit Reversal
				case "26":
					debitSettlementFileName = settlementCondition("05", debitPrimaryCondition, debitSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.debitSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("debitSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					creditSettlementFileName = settlementCondition("06", creditPrimaryCondition, creditSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.creditSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("creditSettlementApprovalCode", settlementApprovalCode);//Null pointer exception

					settlementFileName.addAll(0, debitSettlementFileName);
					settlementFileName.addAll(settlementFileName.size(), creditSettlementFileName);

					creditSettlementReversalFileName = settlementCondition("26", creditRPrimaryCondition, creditRSecondaryCondition, cardNumber, approvalCode, mcc, transactionAmount, acquiringInstution, transactionDate, mccBuffer, crossCurrencyFee);
					authSettlementsTest.creditReversalSettlementAmount = settlementAmount;
//					authsettlement.settledApprovalCode.put("creditReversalSettlementApprovalCode", settlementApprovalCode);//Null pointer exception
					settlementFileName.addAll(settlementFileName.size(), creditSettlementReversalFileName);
					break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return settlementFileName;
	}

	public List<String> settlementCondition(String settlementType, String primaryCondition, String secondaryCondition, String cardNumber, String approvalCode, String mcc, String transactionAmount, String acquiringInstution, String transactionDate, String mccBuffer, String crossCurrencyFee) throws Exception{
		String[] transactionDetails = {cardNumber, approvalCode, mcc, settlementType, transactionAmount, acquiringInstution, transactionDate, approvalCode, mccBuffer, crossCurrencyFee};
		List<String> settlementFileName = new ArrayList<String>();
		Object[][] settlementCardDetails = {transactionDetails};

		BasePayLoad basePayLoad = new BasePayLoad(driver);
		PrepaidDetailsPage prepaidDetailsPage = new PrepaidDetailsPage(driver);
		int partialAmount;
		int withMCCTransactionAmount;
		int authAmount;
		String approvalNumber;
		String transactionD;
		String cardStatus;
		String blockStatus = null;
		authSettlementsTest.settledApprovalCode.put(settlementType, approvalCode);
		switch(primaryCondition){
			case "Duplicate":
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				break;
			case "Partial":
				partialAmount = Integer.parseInt(transactionAmount)/2;
				settlementAmount = partialAmount;
				transactionDetails[4] = transactionDetails[4].replace(transactionDetails[4], String.valueOf(partialAmount));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				if(secondaryCondition.equalsIgnoreCase("Authorization Expiry")){
					procesSettlements(settlementFileName);
					settlementFileName.clear();
				}
				if(!secondaryCondition.isEmpty()){
					settlementFileName.add(settlementSecondaryCondition(secondaryCondition, transactionDetails));
					settlementFileName.remove(null);
				}
				break;
			case "Partial Full Settlement":
				partialAmount = Integer.parseInt(transactionAmount)/2;
				settlementAmount = partialAmount+partialAmount;
				transactionDetails[4] = transactionDetails[4].replace(transactionDetails[4], String.valueOf(partialAmount));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				break;
			case "Greater Auth Amount":
				authAmount = (Integer.parseInt(transactionAmount)+Integer.parseInt(mccBuffer))+1000;
				settlementAmount = authAmount;
				transactionDetails[4] = transactionDetails[4].replace(transactionDetails[4], String.valueOf(authAmount));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));

//			authAmount = Integer.parseInt(transactionDetails[4])-10;
//			transactionDetails[4] = transactionDetails[4].replace(transactionDetails[4], String.valueOf(authAmount));
//			settlementFileName.add(settlementSecondaryCondition(secondaryCondition, transactionDetails));
				break;
			case "Invalid Approval Code":
			case "Direct Settlement":
//			approvalNumber = Integer.parseInt(transactionDetails[1])+15;
				approvalNumber = String.valueOf(Generic.getRandomNumberInRange(111111, 999999));
				authSettlementsTest.settledApprovalCode.put(settlementType, approvalNumber);
//			settlementApprovalCode = approvalNumber;
				transactionDetails[1] = transactionDetails[1].replace(transactionDetails[1], approvalNumber);
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				break;
			case "Invalid Transaction Date":
				transactionD = Generic.getPastOrFutureDate("MMdd", -1);
				transactionDetails[6] = transactionDetails[6].replace(transactionDetails[6], String.valueOf(transactionD));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				break;
			case "Custom Block":
				cardStatus = basePayLoad.getCardStatus(cardNumber);
				if(!cardStatus.equalsIgnoreCase("Custom Blocked")){
					blockStatus = basePayLoad.blockCard(cardNumber, "Custom");
				}
				if(cardStatus.equalsIgnoreCase("Custom Blocked") || blockStatus.equalsIgnoreCase("SUCCESS")){
					settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
					settlementAmount = Integer.parseInt(transactionAmount);
				}
				break;
			case "Temporary Block":
				cardStatus = basePayLoad.getCardStatus(cardNumber);
				if(!cardStatus.equalsIgnoreCase("Blocked Temporarily")){
					blockStatus = basePayLoad.blockCard(cardNumber, "Temporary");
				}
				if(cardStatus.equalsIgnoreCase("Blocked Temporarily") || blockStatus.equalsIgnoreCase("SUCCESS")){
					settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
					settlementAmount = Integer.parseInt(transactionAmount);
				}
				break;
			case "Permanent Block":
				cardStatus = basePayLoad.getCardStatus(cardNumber);
				if(!cardStatus.equalsIgnoreCase("Blocked Permanently")){
					blockStatus = basePayLoad.blockCard(cardNumber, "Permanent");
				}
				if(cardStatus.equalsIgnoreCase("Blocked Permanently") || blockStatus.equalsIgnoreCase("SUCCESS")){
					settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
					settlementAmount = Integer.parseInt(transactionAmount);
				}
				break;
			case "Blank Approval Code":
				//replacing valid approval code with an blank code
				settlementApprovalCode = "      ";
				transactionDetails[1] = transactionDetails[1].replace(transactionDetails[1], "      ");
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				break;
			case "No Debit":
			case "No Credit":
//			settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				if(secondaryCondition.equalsIgnoreCase("Authorization Expiry")){
					settlementSecondaryCondition(secondaryCondition, transactionDetails);
					prepaidDetailsPage.validateExpiredAuthorization(transactionDetails);
					settlementFileName.clear();
				}
				break;
			case "ARN Mismatch":
				transactionDetails[7] = transactionDetails[7].replace(transactionDetails[7], String.valueOf(Generic.getRandomNumberInRange(111111, 999999)));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				break;
			case "With MCC Fee":
				withMCCTransactionAmount = (int)(Double.parseDouble(transactionAmount)+Double.parseDouble(mccBuffer));
				settlementAmount =  Integer.parseInt(String.valueOf(withMCCTransactionAmount));
				transactionDetails[4] = transactionDetails[4].replace(transactionDetails[4], String.valueOf(withMCCTransactionAmount));
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				break;
			case "Without MCC Fee":
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				if(secondaryCondition.equalsIgnoreCase("Authorization Expiry")){
					procesSettlements(settlementFileName);
				}
				if(!secondaryCondition.isEmpty()){
					settlementSecondaryCondition(secondaryCondition, transactionDetails);
				}
				if(secondaryCondition.equalsIgnoreCase("Authorization Expiry")){
					prepaidDetailsPage.validateExpiredAuthorization(transactionDetails);
					settlementFileName.clear();
				}
				break;
			default:
				settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));
				settlementAmount = Integer.parseInt(transactionAmount);
				if(primaryCondition.equalsIgnoreCase("") && secondaryCondition.equalsIgnoreCase("Authorization Expiry")){
					settlementFileName.clear();
				}
				if(!secondaryCondition.isEmpty()){
					settlementFileName.add(settlementSecondaryCondition(secondaryCondition, transactionDetails));
				}
				break;
		}
		return settlementFileName;
	}

	// @param : transactionDetails = {cardNumber, approvalCode, mcc, settlementType, transactionAmount, acquiringInstution, transactionDate, approvalCode}
	public String settlementSecondaryCondition(String secondaryCondition, String[] transactionDetails) throws Exception{
//		List<String> settlementFileName = new ArrayList<String>();
		String settlementFileName = null;
		Object[][] settlementCardDetails = {transactionDetails};
		switch(secondaryCondition){
			case "2nd ARN Mismatch":
				transactionDetails[7] = transactionDetails[7].replace(transactionDetails[7], String.valueOf(Generic.getRandomNumberInRange(111111, 999999)));
				settlementFileName = GenerateSettlementFile(false, settlementCardDetails);
				break;
			case "Duplicate Debit Settlement":
//			settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));	
				settlementFileName = GenerateSettlementFile(false, settlementCardDetails);
				break;
			case "Auth Amount Credit Settlement":
				transactionDetails[3] = transactionDetails[3].replace(transactionDetails[3], "06");
//			settlementFileName.add(GenerateSettlementFile(false, settlementCardDetails));	
				settlementFileName = GenerateSettlementFile(false, settlementCardDetails);
				break;
			case "Partial Credit":
				settlementFileName = GenerateSettlementFile(false, settlementCardDetails);
				break;
			case "Authorization Expiry":
				EOD_Login_Page eod= new EOD_Login_Page(driver);
				String authExpiryStatus = eod.wibmoExecuteEODJob("Auth Expiry");
				if(authExpiryStatus.equalsIgnoreCase("SUCCESS")){
					PrepaidDetailsPage pdp = new PrepaidDetailsPage(driver);
					pdp.validateExpiredAuthorization(transactionDetails);
					settlementFileName = GenerateSettlementFile(false, settlementCardDetails);
				}else{
				}
				break;
		}
		return settlementFileName;
	}

	public boolean procesSettlements(List <String> settlementFileName)throws Exception{
		WebDriver settlementDriver = AuthSettlements.settlementDriver;
		WebDriver eodDriver = AuthSettlements.eodDriver;
		WebDriver csrDriver = AuthSettlements.csrDriver;
		boolean settlementFileUploadStatus ;
		List<String> sendToIBSRunStatus = new ArrayList<String>();

		SettlementPage settlementUpload= PageFactory.initElements(AuthSettlements.settlementDriver, SettlementPage.class);
		for(int s=0; s<settlementFileName.size();s++){
			settlementDriver.navigate().refresh();
			driver = settlementDriver;
			settlementFileUploadStatus = false;
			settlementFileUploadStatus = UploadFileUsingSendKeys(settlementFileName.get(s));
			assertTrue(settlementFileUploadStatus, "Settlement File Upload is Successful");
			if(settlementFileUploadStatus){
			}else{
			}
		}

		EOD_Login_Page eodJobs= new EOD_Login_Page(driver) ;
		driver =  eodDriver;
		String fileHandlerRunStatus = eodJobs.wibmoExecuteEODJob("File Handler");
		if(fileHandlerRunStatus.equalsIgnoreCase("SUCCESS")){
			sendToIBSRunStatus.add(eodJobs.wibmoExecuteEODJob("Send To IBS"));
		}else{
			sendToIBSRunStatus.add("Job Not Triggred");
		}
		if(sendToIBSRunStatus.contains("SUCCESS")){
			return true;
		}else{
			return false;
		}
	}
}

package Prepaid.pageRepo.transactions;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.apiPayLoads.BasePayLoad;
import Prepaid.pageRepo.csr.LoginPage;
import Prepaid.pageRepo.csr.PrepaidDetailsPage;
import Prepaid.testScripts.BaseTest1;
import io.restassured.response.Response;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;


/**
 * @author ${D.Srikiran}
 *
 */
public class AuthorizationJSPPage extends BasePage {

	WebDriver driver;
	static BaseTest1 BaseTest1 = new BaseTest1();
	// Initialization of all the web Elements using page factory
	public AuthorizationJSPPage(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Declaration of all the webElements of Prepaid Details Page

	@FindBy(xpath="//iframe[@name='responseFrame']")
	private WebElement responseFrame;

	@FindBy(name="serverType")
	private WebElement serverType;

	@FindBy(name="serverIP")
	private WebElement serverIP;

	@FindBy(name="serverPort")
	private WebElement serverPort;

	@FindBy(xpath="//td[contains(text(),'MESSAGE TYPE INDICATOR')]//following-sibling::td//select")
	private WebElement messageType;

	@FindBy(xpath="//td[contains(text(),'PAN')]//following-sibling::td//input")
	private WebElement pan;

	@FindBy(xpath="//td[contains(text(),'Processing Code')]//following-sibling::td//select")
	private WebElement processingCode;

	@FindBy(xpath="//td[contains(text(),'Amount (DE 4)')]//following-sibling::td//input")
	private WebElement amountDE4;

	@FindBy(xpath="//td[contains(text(),'Amount (DE 6)')]//following-sibling::td//input")
	private WebElement amountDE6;

	@FindBy(xpath="//td[contains(text(),'System Trace Audit')]//following-sibling::td//input")
	private WebElement systemTraceAudit;

	@FindBy(xpath="//td[contains(text(),'Expiry (DE 14)')]//following-sibling::td//input")
	private WebElement expiryDE14;

	@FindBy(name="de18")
	private WebElement mccDE18;

	@FindBy(xpath="//td[contains(text(),'POS Cond Code')]//following-sibling::td//input")
	private WebElement posConditionCode;

	@FindBy(xpath="//td[contains(text(),'Track2 Data DE 35')]//following-sibling::td//input")
	private WebElement track2Data;

	@FindBy(xpath="//td[contains(text(),'Additional Data')]//following-sibling::td//select")
	private WebElement additionalData;

	@FindBy(xpath="//td[contains(text(),'Additional Data')]//following-sibling::td//input")
	private WebElement additionalDataInput;

	@FindBy(xpath="//td[contains(text(),'Currency DE 49')]//following-sibling::td//input")
	private WebElement currencyDE49;

	@FindBy(xpath="//td[contains(text(),'Currency DE 51')]//following-sibling::td//input")
	private WebElement currencyDE51;

	@FindBy(xpath="//td[contains(text(),'Acquirer Country DE 19')]//following-sibling::td//input")
	private WebElement acquirerCountryDE19;

	@FindBy(xpath="//td[contains(text(),'ATM PIN')]//following-sibling::td//input")
	private WebElement atmPIN;

	@FindBy(xpath="//td[contains(text(),'DE 25')]//following-sibling::td//input")
	private WebElement de25;

	@FindBy(xpath="//td[contains(text(),'DE 32')]//following-sibling::td//input")
	private WebElement de32;

	@FindBy(xpath="//td[contains(text(),'DE 33')]//following-sibling::td//input")
	private WebElement de33;

	@FindBy(xpath="//td[contains(text(),'DE 37')]//following-sibling::td//input")
	private WebElement de37;

	@FindBy(xpath="//td[contains(text(),'DE 41')]//following-sibling::td//input")
	private WebElement de41;

	@FindBy(xpath="//td[contains(text(),'DE 42')]//following-sibling::td//input")
	private WebElement de42;

	@FindBy(xpath="//td[contains(text(),'DE 43')]//following-sibling::td//input")
	private WebElement de43;

	@FindBy(xpath="//td[contains(text(),'DE 48-20')]//following-sibling::td//input")
	private WebElement de48_20;

	@FindBy(xpath="//td[contains(text(),'DE 48-42')]//following-sibling::td//input")
	private WebElement de48_42;

	@FindBy(xpath="//td[contains(text(),'DE 48-43')]//following-sibling::td//input")
	private WebElement de48_43;

	@FindBy(xpath="//td[contains(text(),'DE 48-71')]//following-sibling::td//input")
	private WebElement de48_71;

	@FindBy(xpath="//td[contains(text(),'DE 60')]//following-sibling::td//input")
	private WebElement de60;

	@FindBy(xpath="//td[contains(text(),'DE 61-1')]//following-sibling::td//input")
	private WebElement de61_1;

	@FindBy(xpath="//td[contains(text(),'DE 61-2')]//following-sibling::td//input")
	private WebElement de61_2;

	@FindBy(xpath="//td[contains(text(),'DE 61-3')]//following-sibling::td//input")
	private WebElement de61_3;

	@FindBy(xpath="//td[contains(text(),'DE 61-4')]//following-sibling::td//input")
	private WebElement de61_4;

	@FindBy(xpath="//td[contains(text(),'DE 61-5')]//following-sibling::td//input")
	private WebElement de61_5;

	@FindBy(xpath="//td[contains(text(),'DE 61-6')]//following-sibling::td//input")
	private WebElement de61_6;

	@FindBy(xpath="//td[contains(text(),'DE 61-7')]//following-sibling::td//input")
	private WebElement de61_7;

	@FindBy(xpath="//td[contains(text(),'DE 61-8')]//following-sibling::td//input")
	private WebElement de61_8;

	@FindBy(xpath="//td[contains(text(),'DE 61-9')]//following-sibling::td//input")
	private WebElement de61_9;

	@FindBy(xpath="//td[contains(text(),'DE 61-10')]//following-sibling::td//input")
	private WebElement de61_10;

	@FindBy(xpath="//td[contains(text(),'DE 61-11')]//following-sibling::td//input")
	private WebElement de61_11;

	@FindBy(xpath="//td[contains(text(),'DE 61-12')]//following-sibling::td//input")
	private WebElement de61_12;

	@FindBy(xpath="//td[contains(text(),'DE 61-13')]//following-sibling::td//input")
	private WebElement de61_13;

	@FindBy(xpath="//td[contains(text(),'DE 61-14')]//following-sibling::td//input")
	private WebElement de61_14;

	@FindBy(xpath="//td[contains(text(),'DE 90')]//following-sibling::td//input")
	private WebElement de90;

	@FindBy(name="Submit")
	private WebElement submit;




	public void selectServer(String type, String ip, String port)	{
		try{
//			Select server = new Select(serverType);
//			server.selectByVisibleText(type);
			serverIP.clear();
			serverIP.sendKeys(ip);
			serverPort.clear();
			serverPort.sendKeys(port);
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}

	public void selectMessageTypeIndicator(String mti)	{
		Select selectMTI = new Select(messageType);
		selectMTI.selectByVisibleText(mti.toUpperCase());
	}

	public void enterPAN(String cardNumber)	{
		pan.clear();
		pan.sendKeys(cardNumber);
	}

	public void processingCode(String AuthProcess)	{
		Select processCode = new Select(processingCode);

		switch (AuthProcess) {
			case "POS":
			case "ECOM":
				processCode.selectByValue("000000");
				break;
			case "ATM":
				processCode.selectByValue("010000");
				break;
		}
	}

	public void amountDE4_DE6(String DE4, String DE6)	{
		amountDE4.clear();
		amountDE4.sendKeys(String.format("%012d", Integer.parseInt(DE4)));
		amountDE6.clear();
		amountDE6.sendKeys(String.format("%012d", Integer.parseInt(DE6)));
	}

	public void systemTraceAudit()	{
		String sta = Generic.getRandomNumberInRange(1, 999999);
		systemTraceAudit.sendKeys(String.format("%06d", String.valueOf(sta)));
	}

	public void cardExpiry(String mmyy)	{
		String yymm = mmyy.substring(2, 4)+mmyy.substring(0, 2);
		expiryDE14.clear();
		expiryDE14.sendKeys(yymm);
	}

	public void mcc(String mcc)	{
//		Select mccValue = new Select(mccDE18);
//		mccValue.selectByValue(mcc);
		mccDE18.clear();
		mccDE18.sendKeys(mcc);
	}

	public void de22POSEntry(String panEntryMode, String pinEntryCapability)	{
		String de22 = String.format("%02d", Integer.parseInt(panEntryMode))+pinEntryCapability+"0";
		posConditionCode.clear();
		posConditionCode.sendKeys(de22);
	}

	public void track2Data(String cardNumber, String cardExpiry, String serviceCode, String pvv)	{
		System.out.println("track2DataString :::::::::::"+String.format("%010d", Integer.parseInt(Generic.getRandomNumberInRange(1, 99))));
		String track2data = cardNumber+"="+cardExpiry+serviceCode+pvv+Integer.parseInt(Generic.getRandomNumberInRange(1, 99));
		track2Data.clear();
		track2Data.sendKeys(track2data);
	}

	public void authorizationCurrency(String acquiringInstutionCurrencyD19, String authorizationCurrencyD49, String cardCurrencyD51)	{
		currencyDE49.clear();
		currencyDE49.sendKeys(String.valueOf(authorizationCurrencyD49));
		currencyDE51.clear();
		currencyDE51.sendKeys(String.valueOf(cardCurrencyD51));
		acquirerCountryDE19.clear();
		acquirerCountryDE19.sendKeys(String.valueOf(acquiringInstutionCurrencyD19));
	}

	public void pin(String pin)	{
		atmPIN.clear();
		atmPIN.sendKeys(pin);
	}

	public void de25POSCondCode(String condCode)	{
		de25.clear();
		de25.sendKeys(condCode);
	}

	//DE60 - Terminal Type, Terminal Entry Capability, Additional Authorization Indicator
	public void de60POSInformation(String terminalType, String terminalEntry, String additionAuthindicator)	{
		de60.clear();
		String de60Value = terminalType+terminalEntry+"000000000"+additionAuthindicator;
		de60.sendKeys(de60Value);
	}


	public void authorization(String cardUnion, String authType, String transactionType, String cardNumber, String transactionAmountDE4, String cardHolderBillingDE6, String expiry, String mcc, String panEntryMode, String pinEntryCapability, String serviceCode, String pvv, String acquiringInstutionD19, String AuthCurrencyD49, String CardCurrencyD51, String posCondCode, String terminalType, String terminalEntry, String additionAuthindicator)	{
		String[] ip_port = BaseTest1.getAuthIP_PORT(cardUnion);
		selectServer(cardUnion, ip_port[0], ip_port[1]);
		selectMessageTypeIndicator(transactionType);//Transaction, Reversal Advice, Reversal Repeat, Reversal Request, ATM_Confirmation
		enterPAN(cardNumber);
		processingCode(authType);// Ecom/POS - POS Purchase(Goods and Service), ATM - ATM Cash Withdrawal
		amountDE4_DE6(transactionAmountDE4, cardHolderBillingDE6);
		cardExpiry(expiry);
		mcc(mcc);
		de22POSEntry(panEntryMode, pinEntryCapability);
		track2Data(cardNumber, expiry, serviceCode, pvv);
		authorizationCurrency(acquiringInstutionD19, AuthCurrencyD49, CardCurrencyD51);
		de25POSCondCode(posCondCode);
		String rrn_numbergeneric = String.valueOf(Generic.getRandomNumberInRange(100000000, 999999999));
		de37.clear();
		de37.sendKeys(rrn_numbergeneric);
		de60POSInformation(terminalType, terminalEntry, additionAuthindicator);
		submit.submit();
	}

	public String fetchAuthResponse(String field){
		Generic.wait(3);
		driver.switchTo().frame("responseFrame");
		String responseData = driver.findElement(By.xpath("//html//body/div[2]/div[1]")).getText();
		int a;
		if(field.length()==1){a=11;}else{a=12;}
		int startIndex = responseData.indexOf("\""+field+"\"")+a;
//		int startIndex = responseData.indexOf("\""+field+"\" value=\"");
		int endIndex = responseData.indexOf("\"", startIndex);
		driver.switchTo().parentFrame();
		return responseData.substring(startIndex, endIndex);
	}

	public HashMap<String, String> authorize(String cardUnion, String authType, String transactionType, String cardNumber, String transactionAmountDE4, String cardHolderBillingDE6, String expiry, String mcc, String panEntryMode, String pinEntryCapability, String serviceCode, String pvv, String acquiringInstutionD19, String AuthCurrencyD49, String CardCurrencyD51, String posCondCode, String terminalType, String terminalEntry, String additionAuthindicator){

		String status=null;
		JSONObject requestBody;
		Response response = null;
		HashMap<String, String> transactionDetails = new HashMap<String, String>();
		BasePayLoad basePayLoad = new BasePayLoad(driver);

		try{
			Log.info("No Authorization Code is available, So doing an authorization of "+authType);
			//To Check Card Status is active
			if(!cardNumber.equalsIgnoreCase("")){
				status = basePayLoad.getCardStatus(cardNumber);
			}

			//To Check if a cardnumber exist if not creating a new card via api create card request and proceeding with test execution.
			if(cardNumber.equalsIgnoreCase("") || status.equalsIgnoreCase("Card Inactive")){
				Log.info("Card is either Inactive or no card present - status is-"+status);
				requestBody = basePayLoad.activationPayload("100000", basePayLoad.getFullKYCProfileID());
				response = basePayLoad.createCard(requestBody, false);
				cardNumber = basePayLoad.getResponseValue(response, "cardNumber");
				expiry = basePayLoad.getResponseValue(response, "cardExpiry");
				transactionDetails.put("Card Number", cardNumber);
				transactionDetails.put("Expiry", expiry);
				Log.info("Card is created : "+cardNumber);
			}

			//Initiating authorization JSP page
//			WebDriver jspDriver= BaseTest1.initBrowser("chrome", "AuthJSP");
			driver.get(BaseTest1.getAppURL("AuthJSP"));
			//checking if expiry is empty or null if then fetching expiry details from api response
			if(expiry.equalsIgnoreCase("")||expiry.equalsIgnoreCase(null)){
				expiry = basePayLoad.getRequestResponse("activation", "cardExpiry", cardNumber);
				transactionDetails.put("Expiry", expiry);
			}
			// Hitting an authorization request from Auth JSP Page
			authorization(cardUnion, authType, transactionType, cardNumber, transactionAmountDE4, cardHolderBillingDE6, expiry, mcc, panEntryMode, pinEntryCapability, serviceCode, pvv, acquiringInstutionD19, AuthCurrencyD49, CardCurrencyD51, posCondCode, terminalType, terminalEntry, additionAuthindicator);

			String approvalCode = fetchAuthResponse("38");
			String responseCode = fetchAuthResponse("39");
			String authrrn = fetchAuthResponse("37").replace(" ", "");
			String transactionDate = Generic.currentDate("MMdd");

			transactionDetails.put("Approval Code", approvalCode);
			transactionDetails.put("MCC", mcc);
			transactionDetails.put("Authorization Amount", transactionAmountDE4);
			transactionDetails.put("Authorization Currency Code", acquiringInstutionD19);
			transactionDetails.put("Authorization RRN", authrrn);
			transactionDetails.put("Response Code", responseCode);
			transactionDetails.put("Transaction Date", transactionDate);//
			Log.info("Authorization is successfully placed and auth details : "+transactionDetails.toString());
			driver.close();


			//Launch CSR Application
			WebDriver csrDriver = BaseTest1.initBrowser("chrome", "csr");
			driver = csrDriver;
			String[] Credentials = BaseTest1.getAppCredentials("csr");
			LoginPage csrlp= new LoginPage(csrDriver);
			csrlp.csrLogin(Credentials[0],Credentials[1]); // Username, Password

			PrepaidDetailsPage pdp = new PrepaidDetailsPage(csrDriver, BaseTest1.BANK);
			pdp.checkPrepaidDetails(cardNumber);
			String csrWindow = csrDriver.getWindowHandle();

			if(approvalCode!=null && responseCode.equalsIgnoreCase("00")){
				csrDriver.switchTo().window(csrWindow);
				pdp.refresh.click();
				Generic.wait(3);
				Log.info("Validating Authorized details in CSR Transactions");
				//Fetching Orginal Transaction Amount, MCC Buffer, Cross Currency Fee
				double orginalTransAmount = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[10]")).getText().trim());
				double mccbuffer = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[9]")).getText().trim());
				double crossCurrencyFee = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[8]")).getText().trim());
				double totalTransaction = Double.parseDouble(driver.findElement(By.xpath("//td[contains(text(),'AUTHORIZATION_REQUEST')]//following::table[1]//tr[2]//td[contains(text(),'"+approvalCode+"')]//preceding::td[12]")).getText().trim());

				transactionDetails.put("MCC Buffer Charges", String.format("%.2f", mccbuffer).replace(".",""));
				transactionDetails.put("Cross Currency Fee", String.format("%.2f", crossCurrencyFee).replace(".",""));

				boolean authTransactionEvent = pdp.validateCardAuthTransactions(cardNumber, approvalCode, responseCode, Integer.parseInt(transactionAmountDE4), panEntryMode, authrrn, acquiringInstutionD19);
				boolean mccValidations = pdp.validateMCCFeeBufferValidation(mcc, approvalCode);
				Log.info("authTransactionEvent: "+authTransactionEvent+"mccValidations: "+mccValidations);
				if(authTransactionEvent && mccValidations ){
					Log.info("Auth is successful so registering event in excel card deatils sheet");
					int[] cell = ExcelLibrary.searchTextFindCellAddress(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "CardDetails", cardNumber);
					ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "CardDetails", cell[0], 25, "true");
				}

				pdp.NavigateBackToPrepaidDetailsPage();
				saveAuthorizedTransactionDetails(transactionDetails);
			}
			csrDriver.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return transactionDetails;
	}


	//@param - transactionDetails - CardNumber, Expiry, Approval Code, MCC, Authorization Amount,MCC Buffer Charges
	// Authorization Currency Code, Authorization RRN, Response Code, Transaction Date
	// Cross Currency Fee
	public void saveAuthorizedTransactionDetails(HashMap<String, String> transactionDetails){
		int cardCellAddress = ExcelLibrary.getLastCellinColumn(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", 0);
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "Authorizations", cardCellAddress, 5, transactionDetails.get("Card Number"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 0, transactionDetails.get("Card Number"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 1, transactionDetails.get("Approval Code"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 2, transactionDetails.get("MCC"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 4, transactionDetails.get("Authorization Amount"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 5, transactionDetails.get("Authorization Currency Code"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 6, transactionDetails.get("Transaction Date"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 7, transactionDetails.get("MCC Buffer Charges"));
		ExcelLibrary.writeExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthSettlement", cardCellAddress, 8, transactionDetails.get("Cross Currency Fee"));
		Log.info("Saved the Authorization details to "+BaseTest1.TRANSACTION_XLSX_FILE_PATH);
	}
}

package Prepaid.pageRepo.apiPayLoads;

import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class AMLInquiryPayLoad extends BasePayLoad
{
	WebDriver driver;

	public AMLInquiryPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String amlPayLoad(String urn,String custId,String last4digits)
	{
		String payLoadBody="{"+
			    "\"messageCode\": 1550,"+
			    //"\"clientId\": \"WIBMO\","+
			    "\"clientId\":"+"\""+getClientID()+"\""+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"clientTxnId\":"+"\""+ Generic.randomStringGen()+"\""+","+
			    "\"requestDateTime\":\"20171118170601\","+
			    //"\"bankId\": \"6019\","+
			    "\"bankId\":"+getBankID()+","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+"\""+urn+"\""+","+
			    "\"customerId\":"+"\""+custId+"\""+
			"}" ;
		return payLoadBody;
		
	}
}

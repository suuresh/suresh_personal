package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import library.ExcelLibrary;
import library.Generic;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class FundTransferPayLoad extends BasePayLoad
{

	WebDriver driver;

	public FundTransferPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	JSONObject requestBody;
	Response response = null;
	String cardNumber;
	
	public JSONObject fundTransferPayLoad(String senderURN, String senderlast4digits, String senderCustid, String receiverURN, String receiverlast4digits, String receiverCustid, String amount) throws Exception
	{
		if((senderURN==null || senderlast4digits==null || senderCustid==null) || (senderURN=="" || senderlast4digits=="" || senderCustid=="")){
			requestBody = activationPayload("00", getFullKYCProfileID());
			response = createCard(requestBody,true);
			cardNumber = getResponseValue(response, "cardNumber");
			senderlast4digits = Generic.getLast4DigitCardNumber(cardNumber);
			senderURN = getResponseValue(response, "urn");
			senderCustid = getResponseValue(response, "customerId");
		}

		if((receiverURN==null || receiverlast4digits==null || receiverCustid==null) || (receiverURN=="" || receiverlast4digits=="" || receiverCustid=="")){
			requestBody = activationPayload("150000", getFullKYCProfileID());
			response = createCard(requestBody,true);
			cardNumber = getResponseValue(response, "cardNumber");
			receiverlast4digits = Generic.getLast4DigitCardNumber(cardNumber);
			receiverURN = getResponseValue(response, "urn");
			receiverCustid = getResponseValue(response, "customerId");
		}

		String payLoadBody= "{"+
		    "\"messageCode\": \"1680\","+
		    "\"clientId\":"+"\""+getClientID()+"\""+","+
			"\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
			"\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
			"\"bankId\":"+getBankID()+","+
			"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			"\"entityId\": 100,"+
		    "\"senders\": ["+
		       "{"+
			       "\"last4Digits\":"+"\""+senderlast4digits+"\""+","+
				   "\"urn\":"+"\""+senderURN+"\""+","+
				   "\"customerId\":"+"\""+senderCustid+"\""+","+
				   "\"transactionAmount\":"+"\""+amount+"\""+","+
		           "\"sourceAccountType\": \"1\","+
		           "\"sourceAccount\": \"2147483647\","+
		           "\"reserved1\": \"100\","+
		           "\"reserved2\": \"reserved2\","+
		           "\"reserved3\": \"reserved3\","+
		           "\"reserved4\": \"Fund transfer\","+
		           "\"reserved5\": \"I|10003\""+
		        "}],"+
		    "\"receivers\": ["+
		    	"{"+
	    			"\"last4Digits\":"+"\""+receiverlast4digits+"\""+","+
	    			"\"urn\":"+"\""+receiverURN+"\""+","+
				   	"\"customerId\":"+"\""+receiverCustid+"\""+","+
				   	"\"transactionAmount\":"+"\""+amount+"\""+","+
				   	"\"reserved1\": \"100\","+
				   	"\"reserved2\": \"reserved2\","+
				   	"\"reserved3\": \"reserved3\","+
				   	"\"reserved4\": \"Fund transfer\","+
				   	"\"reserved5\": \"I|10003\""+
 		        "}]}";
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
		return requestObject;
	}
	
		
	public Response fundTransfer(JSONObject requestObject){
		Response response = null;
		try	{
			response = given().contentType("application/json").
					body(requestObject).
					when().log().body().post(BaseTest1.getapiPostUrl("CardFundTransfer")).
					then().and().assertThat().statusCode(200).and()
					.contentType(ContentType.JSON).and().
					extract().response();
//			//Log.info( "Fund Transfer Response"+response.asString());
			if(getResponseValue(response, "responseMessage").equalsIgnoreCase("SUCCESS")){
				// to fetch Sender and Receiver details from response
				String responsesender = getResponseValue(response, "senders").replace("[", "").replace("]", "");
				String responsereceiver = getResponseValue(response, "receivers").replace("[", "").replace("]", "");			
				HashMap<String, String> responseSenderDetails = Generic.parseStringToHashmap(responsesender);
				HashMap<String, String> responseReceviersDetails = Generic.parseStringToHashmap(responsereceiver);			
				
				int[] senderURNcell = ExcelLibrary.searchTextFindCellAddress(api_Payload_TestData_xlsx_filepath, "CardDetails", responseSenderDetails.get("urn"));
				int[] recevierURNcell = ExcelLibrary.searchTextFindCellAddress(api_Payload_TestData_xlsx_filepath, "CardDetails", responseReceviersDetails.get("urn"));
				
				//Sender URN
				ExcelLibrary.writeExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", senderURNcell[0], 11, "true"); //update Fund Transfer event as true if performed
				ExcelLibrary.writeExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", senderURNcell[0], 12, response.asString()); //update Fund Transfer event as true if card is active
				//Recevier URN
				ExcelLibrary.writeExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", recevierURNcell[0], 13, "true"); //update Fund Transfer event as true if performed
				ExcelLibrary.writeExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", recevierURNcell[0], 14, response.asString()); //update Fund Transfer event as true if card is active
			}
		}
		catch(Exception e)	{
			e.printStackTrace();
		}	
		return response;
	}
}

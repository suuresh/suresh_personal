package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class CardInquiryPayLoad extends BasePayLoad {

	WebDriver driver;

	public CardInquiryPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 * This method return the body-
	 * 
	 * @return
	 */

	public JSONObject cardInqPayLoad(String urn, String custId,
			String last4digits) {
		String payLoadBody = "{" + "\"messageCode\": 1090," + "\"clientId\":"
				+ "\""
				+ getClientID()
				+ "\""
				+ ","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"clientTxnId\":"
				+ "\""
				+ getClientTxnID()
				+ "\""
				+ ","
				+ "\"requestDateTime\":"
				+ "\""
				+ getRequestDateTime()
				+ "\""
				+ ","
				+ "\"bankId\":"
				+ getBankID()
				+ ","
				+ "\"customerId\":"
				+ "\""
				+ custId
				+ "\""
				+ ","
				+ "\"last4Digits\":"
				+ "\""
				+ last4digits + "\"" + "," + "\"urn\":" + urn + "" + "}";
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
//		//Log.info("Card Inquiry API Request Object is "+ requestObject.toString());
		return requestObject;
	}

	public Response cardInquiry(JSONObject requestObject) throws Exception{
		Response response = null;
		response = given().contentType("application/json")
					.body(requestObject).when().log().body()
					.post(BaseTest1.getapiPostUrl("CardInquiry")).then().and()
					.assertThat().statusCode(200).and()
					.contentType(ContentType.JSON).and().extract().response();
//		//Log.info("Card Inquiry API Request responseMessage is "+ response.asString());
		return response;
	}

}
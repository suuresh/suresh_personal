package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class CardHolderUpdateProfilePayLoad extends BasePayLoad
{
	WebDriver driver;

	public CardHolderUpdateProfilePayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public JSONObject updateProfileID(String urn, String custId, String last4digits, String profileID){
		String payLoadBody= null;
		JSONObject requestObject=null;
		try{
			payLoadBody="{"+
					"\"messageCode\": \"1280\","+
					"\"clientId\":"+"\""+getClientID()+"\""+","+
					"\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
					"\"bankId\":"+getBankID()+","+
					"\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
					"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
					"\"entityId\": 100,"+
					"\"urn\":"+urn+","+
					"\"last4Digits\":"+"\""+last4digits+"\""+","+
					"\"customerId\":"+"\""+custId+"\""+","+
					"\"cardholder\":"+
					"{"+
					"\"cardProfileId\":"+profileID+","+
					"\"cardholderFirstName\": \"Automation \","+
					"\"cardholderLastName\": \"User\","+
					"\"cardholderMobile\": \"9988758556\","+
					"\"cardholderDateOfBirth\" :\"15-08-1947\","+
					"\"cardholderEmail\":"+"\""+urn+"@wibmo.com\","+
					"\"cardholderAddress\":\"Automation Address\","+
					"\"cardholderCity\":\"Automation city\","+
					"\"cardholderState\":\"Automation State\","+
					"\"cardholderZipCode\":\"111111\","+
					"\"cardholderCountry\":\"Automation\","+
					"\"customerIdentityProfile\":"+
					"{"+
					"\"customerAadharCardNumber\": \"A_feb13_02\","+
					"\"customerPANCardNumber\": \"\","+
					"\"customerPassportNumber\": \"\","+
					"\"customerVoterIdNumber\": \"\","+
					"\"customerDrivingLicenseNumber\": \"\""+
					"}"+
					"}"+
					"}";
			requestObject = ParseStringToJSON(payLoadBody);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return requestObject;
	}

	public Response updateCardProfile(JSONObject requestObject) throws Exception{
		Response response = null;
		response = given().contentType("application/json").
				body(requestObject).
				when().log().body().post(BaseTest1.getapiPostUrl("CardUpdateProfile")).
				then().and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().
						extract().response();
		return response;
	}
}

package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class RechargePayLoad extends BasePayLoad{

	WebDriver driver;

	public RechargePayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	public JSONObject reloadPayLoad(String urn, String last4digits, String custid, int rechargeAmount, String orginalClientTxnId, String event, String eventComments)
	{
		System.out.println("----***This is Reload card API request***----");
		String payLoadBody="{"+
			"\"messageCode\": \"1080\","+
			"\"clientId\":"+"\""+getClientID()+"\""+","+
			"\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
			"\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
			"\"bankId\":"+getBankID()+","+
			"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			"\"entityId\": 100,"+
			"\"last4Digits\":"+"\""+last4digits+"\""+","+
			"\"urn\":"+"\""+urn+"\""+","+
			"\"customerId\":"+"\""+custid+"\""+","+
			"\"agentComments\":\"Credit to customer rest\","+
			"\"transactionAmount\":"+rechargeAmount+","+
			"\"sourceAccountType\":\"00\","+
			"\"sourceAccount\":\"1234\","+
			"\"originalClientTxnId\":"+"\""+orginalClientTxnId+"\""+","+
			"\"reserved1\":\"\","+
			"\"reserved2\":\"\","+
			"\"reserved3\":\"0\","+
			"\"reserved4\":"+"\""+event+"\""+","+
			"\"reserved5\":"+"\""+eventComments+"\""+
			"}";		
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
//		//Log.info("Card Reload API Request object is "+ requestObject.toString());
		return requestObject;
	}

	public Response reloadCard(JSONObject requestObject)throws Exception{
		Response response = null;
			response = given().contentType("application/json").
					body(requestObject).
					when().log().body().post(BaseTest1.getapiPostUrl("CardReload")).
					then().and().assertThat().statusCode(200).and()
					.contentType(ContentType.JSON).and().
					extract().response();				
//		//Log.info("Card Reload API Request responseMessage is "+ response.asString());
		return response;
	}
	
}


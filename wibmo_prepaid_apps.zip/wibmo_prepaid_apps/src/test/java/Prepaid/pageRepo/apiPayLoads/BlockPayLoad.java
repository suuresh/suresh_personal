package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class BlockPayLoad extends BasePayLoad
{
	WebDriver driver;

	public BlockPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public JSONObject blockPayload(String urn, String last4digits, String custId, String blockType)
	{
		System.out.println();
		System.out.println("----***This is blocked card API request***----");
		String payLoadBody="{"+
			    "\"messageCode\": \"1240\","+
			    "\"clientId\":"+"\""+getClientID()+"\""+","+
			    "\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
			    "\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
			    "\"bankId\":"+getBankID()+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"entityId\": 100,"+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
				"\"urn\":"+urn+","+
				"\"blockType\":"+"\""+blockType+"\""+","+
				"\"customerId\":"+"\""+custId+"\""+","+
				"\"reserved1\":"+"\""+blockType+"\""+","+
				"\"reserved2\":\"mobile lost so Blocking the card API\""+
				"}";
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
		return requestObject;
	}
	
	public Response BlockCard(JSONObject requestObject)	throws Exception{
		Response response = null;
		
			response = given().contentType("application/json").
					body(requestObject).
					when().log().body().post(BaseTest1.getapiPostUrl("CardBlock")).
					then().and().assertThat().statusCode(200).and()
					.contentType(ContentType.JSON).and().
					extract().response();
			return response;
	}
}

package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class UCICRegPayLoad extends BasePayLoad {

	WebDriver driver;

	public UCICRegPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public JSONObject ucicRegPayload(String urn, String last4digits,
                                     String custid, int ucicID, String CustomerIdentityProof) {
		System.out.println("----***This is UCIC Registration API request***----");
		String payLoadBody = "{" + "\"messageCode\": \"1620\","
				+ "\"clientId\":" + "\""
				+ getClientID()
				+ "\""
				+ ","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"requestDateTime\":"
				+ "\""
				+ getRequestDateTime()
				+ "\""
				+ ","
				+ "\"bankId\":"
				+ getBankID()
				+ ","
				+ "\"entityId\": 100,"
				+ "\"last4Digits\":"
				+ "\""
				+ last4digits
				+ "\""
				+ ","
				+ "\"urn\":"
				+ "\""
				+ urn
				+ "\""
				+ ","
				+ "\"customerId\":"
				+ "\""
				+ custid
				+ "\""
				+ ","
				+ "\"clientTxnId\":" + "\"" + getClientTxnID() + "\"" + ",";
		if (CustomerIdentityProof == null || CustomerIdentityProof == "") {
			payLoadBody = payLoadBody + "\"ucicId\":" + ucicID + "," + "}";
		} else {
			payLoadBody = payLoadBody + "\"customerIdentityProof\":" + "\""
					+ CustomerIdentityProof + "\"" + "," + "}";
		}
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
//		 //Log.info("Card UCIC Registration API Request object is "+
//		 requestObject.toString());
		return requestObject;
	}

	public Response ucicReg(JSONObject requestObject) throws Exception {
		Response response = null;
		response = given().contentType("application/json").body(requestObject)
				.when().log().body().post(BaseTest1.getapiPostUrl("CardUCICReg")).then()
				.and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().extract().response();
//		 //Log.info("Card UCIC Registration API Request responseMessage is "+
//		 response.asString());
		return response;
	}
	
	public String getucicpanDetail(JSONObject requestObject) throws Exception {
		String ucicID=null;
		String panDetail=null;
		try{
		 ucicID = requestObject.get("ucicId").toString();
		 panDetail = requestObject.get("customerIdentityProof").toString();
		}catch(Exception e){
			if(ucicID != null){
				return ucicID;
			}else{
				return panDetail;
			}
		}
		return null;		
	}

}

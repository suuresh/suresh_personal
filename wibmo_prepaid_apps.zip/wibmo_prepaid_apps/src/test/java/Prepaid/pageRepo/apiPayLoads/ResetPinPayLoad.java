package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static io.restassured.RestAssured.given;

public class ResetPinPayLoad extends BasePayLoad
{
	WebDriver driver;

	public ResetPinPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	public JSONObject resetPayLoad(String urn, String last4digits, String custid, String newPin)
	{
		String payLoadBody="{"+
				"\"messageCode\": \"1480\","+
				"\"clientId\":"+"\""+getClientID()+"\""+","+
				"\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
				"\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
				"\"bankId\":"+getBankID()+","+
				"\"entityId\": 100,"+
				"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
				"\"newPIN\":"+newPin+","+
				"\"last4Digits\":"+"\""+last4digits+"\""+","+
				"\"urn\":"+"\""+urn+"\""+","+
				"\"customerId\":"+"\""+custid+"\""+","+
				"}";
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
		return requestObject;

	}


	public Response resetPin(JSONObject requestObject) throws Exception{
		Response response = null;
		response = given().contentType("application/json").body(requestObject)
				.when().log().body().post(BaseTest1.getapiPostUrl("CardResetPin")).then()
				.and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().extract().response();
		return response;
	}
}

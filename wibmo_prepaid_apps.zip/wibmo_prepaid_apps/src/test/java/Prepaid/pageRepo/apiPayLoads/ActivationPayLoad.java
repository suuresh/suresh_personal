package Prepaid.pageRepo.apiPayLoads;

//import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class ActivationPayLoad extends BasePayLoad {
//	DataProviderUtility dataProvider = new DataProviderUtility();
//	ExcelUtilities csvReadandWrite = new ExcelUtilities();

	WebDriver driver;

	public ActivationPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String actPayloadDuplicateCardCreationCheck(String custID, String clientTxnID) {
		System.out.println();
		System.out.println("---*** This is Actviation API request***----");
		System.out.println();
		String payLoadBody = "{" + "\"messageCode\": \"1010\","
				+ "\"clientId\": \"WIBMO\"," + "\"clientTxnId\":" + "\""
				+ clientTxnID
				+ "\""
				+ ","
				+ "\"requestDateTime\": \"20161223121001\","
				+ "\"bankId\":"
				+ getBankID()
				+ ","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"entityId\": 100,"
				+ "\"loadAmount\": \"300000\","
				+ "\"productId\":"
				+ getProductID()
				+ ","
				+ "\"cardHolder\": {"
				+ "\"cardholderFirstName\":\"Velocity Check Non KYC\","
				+ "\"cardholderLastName\": \"NewAPI\","
				+ "\"cardholderMobile\": \"9900917736\","
				+ "\"cardholderDateOfBirth\" :\"25-12-1997\","
				+ "\"cardholderEmail\":\"sanmati.vardhaman@wibmo.com\","
				+ "\"cardholderAddress\":\"WINGS,Cambridge Road,Domlur1\","
				+ "\"cardholderCity\":\"Bangalore\","
				+ "\"cardholderState\":\"Karnataka\","
				+ "\"cardholderZipCode\":\"560020\","
				+ "\"cardholderCountry\":\"India\""
				+ "},"
				+ "\"customerIdentityProfile\": {"
				+ "\"customerAadharCardNumber\": \"A_feb13_02\","
				+ "\"customerPANCardNumber\": \"\","
				+ "\"customerPassportNumber\": \"\","
				+ "\"customerVoterIdNumber\": \"\","
				+ "\"customerDrivingLicenseNumber\": \"\""
				+ "},"
				+ "\"cardProfileId\":"
				+ getFullKYCProfileID()
				+ ","
				+ "\"customerId\":"
				+ "\""
				+ custID
				+ "\""
				+ ","
				+ "\"sourceAccountType\":\"00\","
				+ "\"sourceAccount\":\"1234\"" + "}";
		return payLoadBody;
	}

	/*// This Method is for BOB API Request Body Composition
	public void PayloadBody(String event) {
		Object[] Return = DataProviderUtility.GetData("E:\\prepaid_api\\DataFolder\\Encrypted_data_Sheet.xlsx","Output");
		String[] hearders = (String[]) Return[0];
		Object[][] headerValues = (Object[][]) Return[1];
		// System.out.println(headerValues.length);
		System.out.println();
		System.out.println("---*** This is API request Body***----");
		System.out.println();
		String payLoadBody = "{";
		// System.out.println(hearders.length);
		int hashCellValue;
        int[] header = null;
        int[] ActHeaders = {0, 1, 2, 3, 4, 6, 8, 9, 10, 11, 12, 13, 14, 15,
                16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 37,
                38, 39, 40, 41, 42, 43, 44, 45};
        int[] RecHeaders = {0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                16, 32, 35, 36, 37, 38, 39, 40, 41};
        int[] CanHeaders = {0, 1, 2, 3, 4, 6, 8, 9, 10, 12, 30, 33, 37, 41};
        int[] InqHeaders = {0, 1, 2, 3, 6, 8, 9, 34, 37};

		switch (event) {
		case "Activation":
			header = ActHeaders;
			break;
		case "Recharge":
			header = RecHeaders;
			break;
		case "Cancellation":
			header = CanHeaders;
			break;
		case "Inquiry":
			header = InqHeaders;
			break;
		}
		for (int v = 1; v < headerValues.length; v++) {
			// if{}
			for (int i = 0, j = 0; j < header.length; i++) {
				payLoadBody = payLoadBody + "\"" + headerValues[j][header[i]]
						+ "\":\"" + headerValues[v][header[i]] + "\",";
				payLoadBody = payLoadBody + "}";
			}
		}
		System.out.println(payLoadBody);
	}*/

}
/**
 * 
 */
package Prepaid.pageRepo.apiPayLoads;

import io.restassured.path.json.JsonPath;
import library.ExcelLibrary;
import library.Generic;
import library.Log;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;

import static Prepaid.testScripts.BaseTest1.getTransactionEventCode;

/**
 * @author ${Srikiran}
 *
 */
public class WalletStatementPayLoad extends BasePayLoad 
{

	WebDriver driver;

	public WalletStatementPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	public String walletStatementPayload(String urn,String last4digits,String custid)
	{
		String payLoadBody="{"+
			    "\"messageCode\": \"1072\","+
			   // "\"clientId\": \"WIBMO\","+
			   "\"clientId\":"+"\""+getClientID()+"\""+","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+getBankID()+","+
			    "\"requestDateTime\": \"20160627102149\","+
			    "\"clientTxnId\":"+ Generic.randomAlphaNumeric(10)+","+
			    "\"fromDate\":\"13/08/2018\","+
			    "\"toDate\": \"13/08/2019\","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+"\""+urn+"\""+","+
			    "\"customerId\":"+"\""+custid+"\""+ 
			"}";
		return payLoadBody;
	}
	
	public boolean ValidateWalletStatementEvent(JsonPath jsonValue, String urn, String statementType, String validationEvent)
	{
		boolean walletValidation =  false;
		String event;
		String eventId;
		String eventResponse;
		JSONParser parser = new JSONParser();
		JSONObject eventResponseObject=null;
		HashMap statementDetail;
		boolean closeOpenAmountValidation = false;
		int statementOpeningBalance=0;
		int statementClosingBalance=0;
		int diff;
		int rows;
		boolean flag1 = false, flag2 = false, flag3 = false, flag4 = false, flag5 = false, flag6 = false, flag7 = false;
		
		int[] urncell = ExcelLibrary.searchTextFindCellAddress(api_Payload_TestData_xlsx_filepath, "CardDetails", urn);
		int row = urncell[0];
		
		if(statementType.equals("Wallet"))
		{
			statementType = "statementDetails";
			closeOpenAmountValidation = true;
		}else{
			statementType = "transactionDetails";
		}
		
		for(int i=5, k=6; i<=35; k+=2, i+=2){
			event = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", 0, i);
			System.out.println("event:"+event);
			if(event.equalsIgnoreCase(validationEvent)){
				eventId =  getTransactionEventCode(event);
				if(Boolean.parseBoolean(ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", row, i)))
					{						
						eventResponse = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "CardDetails", row, k);
						
						try {
							eventResponseObject = (JSONObject) parser.parse(eventResponse);
						} catch (Exception e) {
							
						}
						
						ArrayList cardStatement = jsonValue.get(statementType);
						if(cardStatement.size() == 0)break;
							statementDetail = (HashMap) cardStatement.get(0);
							for(int a=0; a<cardStatement.size(); a++)
							{
								statementDetail = (HashMap) cardStatement.get(a);
								if(String.valueOf(statementDetail.get("eventId")).equals(eventId))
								{									
									break;									
								}
							}
							String statementClientTxnId = statementDetail.get("clientTxnId").toString();
							String statementTransactionRefNo = statementDetail.get("transRefNumber").toString();
							String statementTransactionAmount = statementDetail.get("transactionAmount").toString();
							String statementTransactionType = statementDetail.get("transactionType").toString();
							String approvalCode = statementDetail.get("approvalCode").toString();
							String authRefTxnID=null;
							String rrn = statementDetail.get("rrn").toString();
							if(closeOpenAmountValidation){
								statementOpeningBalance = Integer.parseInt(statementDetail.get("openningBalance").toString());
								statementClosingBalance = Integer.parseInt(statementDetail.get("closingBalance").toString());
							}
						
							if(String.valueOf(statementDetail.get("eventId")).equals(eventId))
							{
								switch(eventId)
								{	//Activation
									case "303001" :
										Log.info( "Activation Validation");
										//validate Transaction type
										flag1 = statementTransactionType.equalsIgnoreCase("CR");
										//validate Client Transation ID
										flag2 = statementClientTxnId.equalsIgnoreCase(eventResponseObject.get("clientTxnId").toString());
										//validate Transaction Reference Number
										flag3 = statementTransactionRefNo.equalsIgnoreCase(eventResponseObject.get("accosaRefNo").toString());
										//validate Transaction Amount
										flag4 = statementTransactionAmount.equalsIgnoreCase(eventResponseObject.get("loadAmount").toString());
										
										//validating closing balance and opening balance
										if(closeOpenAmountValidation){
											diff = statementClosingBalance - statementOpeningBalance;
											flag5 = diff == Integer.parseInt(eventResponseObject.get("loadAmount").toString());
											Log.info( "Wallet Closing Balance are equal? - "+flag5);
										}
										Log.info( flag1+""+flag2+""+flag3+""+flag4);
										walletValidation = flag1&&flag2&&flag3&&flag4;
										break;
									//reload
									case "303003" :
										Log.info( "Reload Validation");
										//validate Transaction type
										flag1 = statementTransactionType.equalsIgnoreCase("CR");
										//validate Client Transation ID
										flag2 = statementClientTxnId.equalsIgnoreCase(eventResponseObject.get("clientTxnId").toString());
										//validate Transaction Reference Number
										flag3 = statementTransactionRefNo.equalsIgnoreCase(eventResponseObject.get("accosaRefNo").toString());
										//validate Transaction Amount
										flag4 = statementTransactionAmount.equalsIgnoreCase(eventResponseObject.get("transactionAmount").toString());
										
										//validating closing balance and opening balance
										if(closeOpenAmountValidation){
											diff = statementClosingBalance - statementOpeningBalance;
											flag5 = diff == Integer.parseInt(eventResponseObject.get("transactionAmount").toString());
											Log.info( "Wallet Closing Balance are equal? - "+flag5);
										}
										Log.info( flag1+""+flag2+""+flag3+""+flag4);
										walletValidation = flag1&&flag2&&flag3&&flag4;
										break;
									//unload
									case "303014" :
										Log.info( "Unload Validation");
																				
										//validate Transaction type
										flag1 = statementTransactionType.equalsIgnoreCase("DR");
										//validate Client Transation ID
										flag2 = statementClientTxnId.equalsIgnoreCase(eventResponseObject.get("clientTxnId").toString());
										//validate Transaction Reference Number
										flag3 = statementTransactionRefNo.equalsIgnoreCase(eventResponseObject.get("accosaRefNo").toString());
										//validate Transaction Amount
										flag4 = statementTransactionAmount.equalsIgnoreCase(eventResponseObject.get("transactionAmount").toString());
										
										//validating closing balance and opening balance
										if(closeOpenAmountValidation){
											diff = statementClosingBalance - statementOpeningBalance;
											flag5 = diff == Integer.parseInt(eventResponseObject.get("transactionAmount").toString());
											Log.info( "Wallet Closing Balance are equal? - "+flag5);
										}
										Log.info( flag1+""+flag2+""+flag3+""+flag4);
										walletValidation = flag1&&flag2&&flag3&&flag4;
										break;
									//fundtransferdebit
									case "303041" :
										Log.info( "Fund Transfer Debit Validation");
										
										ArrayList senderDetails = (ArrayList) eventResponseObject.get("senders");
										HashMap<String, String> debitDetail = (HashMap) senderDetails.get(0);
																				
										//validate Transaction type
										flag1 = statementTransactionType.equalsIgnoreCase("DR");
										//validate Client Transation ID
										flag2 = statementClientTxnId.equalsIgnoreCase(eventResponseObject.get("clientTxnId").toString());
										//validate Transaction Reference Number
										flag3 = statementTransactionRefNo.equalsIgnoreCase(String.valueOf(debitDetail.get("accosaRefNo")));
										//validate Transaction Amount
										flag4 = statementTransactionAmount.equalsIgnoreCase(String.valueOf(debitDetail.get("transactionAmount")));
										
										//validating closing balance and opening balance
										if(closeOpenAmountValidation){
											diff = statementClosingBalance - statementOpeningBalance;
											flag5 = diff == Integer.parseInt(String.valueOf(debitDetail.get("transactionAmount")));
											Log.info( "Wallet Closing Balance are equal? - "+flag5);
										}
										Log.info( flag1+""+flag2+""+flag3+""+flag4);
										walletValidation = flag1&&flag2&&flag3&&flag4;
										break;
									//fundtransfercredit
									case "303040" :
										Log.info( "Fund Transfer Credit Validation");
										
										ArrayList recevierDetails = (ArrayList) eventResponseObject.get("receivers");
										HashMap<String, String> creditDetail = (HashMap) recevierDetails.get(0);
										
										//validate Transaction type
										flag1 = statementTransactionType.equalsIgnoreCase("CR");
										//validate Client Transation ID
										flag2 = statementClientTxnId.equalsIgnoreCase(eventResponseObject.get("clientTxnId").toString());
										//validate Transaction Reference Number
										flag3 = statementTransactionRefNo.equalsIgnoreCase(String.valueOf(creditDetail.get("accosaRefNo")));
										//validate Transaction Amount
										flag4 = statementTransactionAmount.equalsIgnoreCase(String.valueOf(creditDetail.get("transactionAmount")));
										
										//validating closing balance and opening balance
										if(closeOpenAmountValidation){
											diff = statementClosingBalance - statementOpeningBalance;
											flag5 = diff == Integer.parseInt(String.valueOf(creditDetail.get("transactionAmount")));
											Log.info( "Wallet Closing Balance are equal? - "+flag5);
										}
										Log.info( flag1+""+flag2+""+flag3+""+flag4);
										walletValidation = flag1&&flag2&&flag3&&flag4;
										break;
									//Authorization
									case "105010" :
										Log.info( "Authorization Debit Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "AuthorizationReportData");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "AuthorizationReportData", a, 0);
											HashMap<String, String> authorizationdata = Generic.parseStringToHashmap(cell);
											if(authorizationdata.get("URN").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("DR");
												//validate Client Transation ID
												flag2 = statementTransactionAmount.equalsIgnoreCase(authorizationdata.get("Authorization Amount").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(authorizationdata.get("Auth Id"));
												//validate Transaction Amount
												flag4 = approvalCode.equalsIgnoreCase(authorizationdata.get("Approval Code"));
												//validate Transaction Amount
												flag5 = rrn.equalsIgnoreCase(authorizationdata.get("RRN"));
												
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementOpeningBalance - statementClosingBalance;
													flag6 = diff == Integer.parseInt(authorizationdata.get("Authorization Amount").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag6);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag6);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag6;
										break;
									//Debit Settlement
									case "205000" :
										authRefTxnID = statementDetail.get("authEpfTxnId").toString();
										Log.info( "Authorization Debit Settlement Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "SettlementReport");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "SettlementReport", a, 0);
											HashMap<String, String> settlementData = Generic.parseStringToHashmap(cell);
											if(settlementData.get("URN Number").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("DR");
												//validate Transaction Amount
												flag2 = statementTransactionAmount.equalsIgnoreCase(settlementData.get("Settlement Amt").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(settlementData.get("settlementRefNumber"));
												//validate Authorization Code/Approval Code
												flag4 = approvalCode.equalsIgnoreCase(settlementData.get("AuthCode"));
												//validate Settlement Authorization Id
												flag5 = authRefTxnID.equalsIgnoreCase(settlementData.get("authorizationID"));
												//validate RRN Details
												flag6 = rrn.equalsIgnoreCase(settlementData.get("RRN"));
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementOpeningBalance - statementClosingBalance;
													flag7 = diff == Integer.parseInt(settlementData.get("Settlement Amt").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag6);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag6+" "+flag7);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag6&&flag7;
										break;
									//Credit Settlement
									case "206000" :
										authRefTxnID = statementDetail.get("authEpfTxnId").toString();
										Log.info( "Authorization Credit Settlement Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "SettlementReport");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "SettlementReport", a, 0);
											HashMap<String, String> settlementData = Generic.parseStringToHashmap(cell);
											if(settlementData.get("URN Number").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("CR");
												//validate Transaction Amount
												flag2 = statementTransactionAmount.equalsIgnoreCase(settlementData.get("Settlement Amt").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(settlementData.get("settlementRefNumber"));
												//validate Authorization Code/Approval Code
												flag4 = approvalCode.equalsIgnoreCase(settlementData.get("AuthCode"));
												//validate Settlement Authorization Id
												flag5 = authRefTxnID.equalsIgnoreCase(settlementData.get("authorizationID"));
												//validate RRN Details
												flag6 = rrn.equalsIgnoreCase(settlementData.get("RRN"));
												
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementOpeningBalance - statementClosingBalance;
													flag7 = diff == Integer.parseInt(settlementData.get("Settlement Amt").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag6);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag6+" "+flag7);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag6&&flag7;
										break;
									//Debit Reversal
									case "225000" :
										authRefTxnID = statementDetail.get("authEpfTxnId").toString();
										Log.info( "Authorization Debit Reversal Settlement Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "SettlementReport");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "SettlementReport", a, 0);
											HashMap<String, String> settlementData = Generic.parseStringToHashmap(cell);
											if(settlementData.get("URN Number").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("CR");
												//validate Transaction Amount
												flag2 = statementTransactionAmount.equalsIgnoreCase(settlementData.get("Settlement Amt").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(settlementData.get("settlementRefNumber"));
												//validate Authorization Code/Approval Code
												flag4 = approvalCode.equalsIgnoreCase(settlementData.get("AuthCode"));
												//validate Settlement Authorization Id
												flag5 = authRefTxnID.equalsIgnoreCase(settlementData.get("authorizationID"));
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementClosingBalance-statementOpeningBalance;
													flag7 = diff == Integer.parseInt(settlementData.get("Settlement Amt").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag7);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag7);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag7;
										break;
									//Credit Reversal
									case "226000" :
										authRefTxnID = statementDetail.get("authEpfTxnId").toString();
										Log.info( "Authorization Credit Reversal Settlement Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "SettlementReport");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "SettlementReport", a, 0);
											HashMap<String, String> settlementData = Generic.parseStringToHashmap(cell);
											if(settlementData.get("URN Number").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("DR");
												//validate Transaction Amount
												flag2 = statementTransactionAmount.equalsIgnoreCase(settlementData.get("Settlement Amt").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(settlementData.get("settlementRefNumber"));
												//validate Authorization Code/Approval Code
												flag4 = approvalCode.equalsIgnoreCase(settlementData.get("AuthCode"));
												//validate Settlement Authorization Id
												flag5 = authRefTxnID.equalsIgnoreCase(settlementData.get("authorizationID"));
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementOpeningBalance-statementClosingBalance;
													flag7 = diff == Integer.parseInt(settlementData.get("Settlement Amt").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag7);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag7);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag7;
										break;
									//Credit Chargeback
									case "216000" :
										authRefTxnID = statementDetail.get("authEpfTxnId").toString();
										Log.info( "Authorization Credit Chargeback reversal statement Validation");
										rows = ExcelLibrary.getExcelRowCount(testAuthorizationDataXlsxPath, "ChargebackReport");
										for(int a=1; a<=rows; a++){
											String cell = ExcelLibrary.getExcelData(testAuthorizationDataXlsxPath, "ChargebackReport", a, 0);
											HashMap<String, String> chargeBackData = Generic.parseStringToHashmap(cell);
											if(chargeBackData.get("URN Number").equalsIgnoreCase(urn)){
												//validate Transaction type
												flag1 = statementTransactionType.equalsIgnoreCase("DR");
												//validate Transaction Amount
												flag2 = statementTransactionAmount.equalsIgnoreCase(chargeBackData.get("Chargeback Amount").replace(".", ""));
												//validate Transaction Reference Number
												flag3 = statementTransactionRefNo.equalsIgnoreCase(chargeBackData.get("settlementRefNumber"));
												//validate Authorization Code/Approval Code
												flag4 = approvalCode.equalsIgnoreCase(chargeBackData.get("AuthCode"));
												//validate Settlement Authorization Id
												flag5 = authRefTxnID.equalsIgnoreCase(chargeBackData.get("authorizationID"));
												//validating closing balance and opening balance
												if(closeOpenAmountValidation){
													diff = statementOpeningBalance-statementClosingBalance;
													flag7 = diff == Integer.parseInt(chargeBackData.get("Settlement Amt").replace(".", ""));
													Log.info( "Wallet Closing Balance are equal? - "+flag7);
												}
												break;												
											}
										}
										Log.info( flag1+" "+flag2+" "+flag3+" "+flag4+" "+flag5+" "+flag7);
										walletValidation = flag1&&flag2&&flag3&&flag4&&flag5&&flag7;
										break;
//									//temporary block
//									case "303116" :
//										break;
//									//permanent block
//									case "303117" :
//										break;
//									//customblock
//									case "303128" :
//										break;
//									//unblock
//									case "300116" :
//										break;
								}
							}else{
								continue;
								}
					}	
			}
		}
		return walletValidation;
	}
}
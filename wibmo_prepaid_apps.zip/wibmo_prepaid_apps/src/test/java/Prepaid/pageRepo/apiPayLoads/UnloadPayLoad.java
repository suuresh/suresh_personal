package Prepaid.pageRepo.apiPayLoads;

import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import static io.restassured.RestAssured.given;

public class UnloadPayLoad extends BasePayLoad
{
	WebDriver driver;

	public UnloadPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public JSONObject unloadPayLoad(String urn, String last4digits, String custid, int amount, String orginalClientTxnId, String event, String eventComments)
	{
		System.out.println("----***This is Unload card API request***----");
		String payLoadBody="{"+
				"\"messageCode\": \"1480\","+
				"\"clientId\":"+"\""+getClientID()+"\""+","+
				"\"clientTxnId\":"+"\""+getClientTxnID()+"\""+","+
				"\"requestDateTime\":"+"\""+getRequestDateTime()+"\""+","+
				"\"bankId\":"+getBankID()+","+
				"\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
				"\"entityId\": 100,"+
				"\"last4Digits\":"+"\""+last4digits+"\""+","+
				"\"urn\":"+"\""+urn+"\""+","+
				"\"agentComments\": \"Debit to customer\","+
				"\"customerId\":"+"\""+custid+"\""+","+
				"\"transactionAmount\":"+amount+","+
				"\"sourceAccountType\":1,"+
				"\"sourceAccount\":\"1234\","+
				"\"originalClientTxnId\":"+"\""+orginalClientTxnId+"\""+","+
				"\"reserved1\":\"\","+
				"\"reserved2\":\"\","+
				"\"reserved3\":\"\","+
				"\"reserved4\":"+"\""+event+"\""+","+
				"\"reserved5\":"+"\""+eventComments+"\""+
				"}";
		JSONObject requestObject = ParseStringToJSON(payLoadBody);
//		//Log.info("Card Unload API Request Object is "+ requestObject);
		return requestObject;
	}

	public Response unloadCard(JSONObject requestObject)throws Exception{
		Response response = null;
		response = given().contentType("application/json").
				body(requestObject).
				when().log().body().post(BaseTest1.getapiPostUrl("CardUnload")).
				then().and().assertThat().statusCode(200).and()
				.contentType(ContentType.JSON).and().
						extract().response();
//		//Log.info("Card Unload API Request Response Message is "+ response.asString());
		return response;
	}
}

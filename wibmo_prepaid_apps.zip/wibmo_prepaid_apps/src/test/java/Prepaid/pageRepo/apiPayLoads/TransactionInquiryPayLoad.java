package Prepaid.pageRepo.apiPayLoads;

import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class TransactionInquiryPayLoad extends BasePayLoad 
{
	WebDriver driver;

	public TransactionInquiryPayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String txnInqPayLoad(String urn,String last4digits,String custid)
	{
		System.out.println();
		String payLoadBody=
				"{"+
			    "\"messageCode\": \"1070\","+
			   // "\"clientId\": \"WIBMO\","+
			   "\"clientId\":"+"\""+getClientID()+"\""+","+
			   // "\"bankId\": 6019,"+
			   "\"bankId\":"+getBankID()+","+
			    "\"requestDateTime\": \"20161221210608\","+
			    "\"clientTxnId\":"+"\""+ Generic.randomStringGen()+"\""+","+
			    "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","+
			    "\"last4Digits\":"+"\""+last4digits+"\""+","+
			    "\"urn\":"+urn+","+
			    "\"customerId\":"+"\""+custid+"\""+","+
			    "\"fromDate\":\"08/06/2015\","+
			    "\"toDate\": \"30/06/2019\","+
			    "\"pageNumber\":\"1\","+
			    "\"count\":\"10\","+
			    "\"fromRowId\":\"0\""+
			"}";
				
		return payLoadBody;
	}
}


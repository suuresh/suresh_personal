package Prepaid.pageRepo.apiPayLoads;

import Prepaid.pageRepo.BasePage;
import Prepaid.pageRepo.cms.AdjustmentRequestPage;
import Prepaid.pageRepo.cms.LoginPage;
import Prepaid.pageRepo.csr.CSRBasePage;
import Prepaid.testScripts.BaseTest1;
//import Prepaid.testScripts.cms.BaseTest;
import io.restassured.http.ContentType;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.DB;
import library.DataProviderUtility;
import library.ExcelLibrary;
import library.Generic;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import java.sql.*;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

/**
 * @author ${Srikiran D}
 *
 */

public class BasePayLoad extends BasePage {

	private static BaseTest1 BaseTest1 = new BaseTest1();

    protected static String api_Payload_TestData_xlsx_filepath = BaseTest1.APIPAYLOAD_TESTDATA_XLSX_FILE_PATH;
    protected static String api_requestbody_TestData_xlsx_filepath = BaseTest1.APIREQUESTBODY_TESTDATA_XLSX_FILE_PATH;
	protected static String testExecutionDataXlsxPath = BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH;
	protected static String testAuthorizationDataXlsxPath = BaseTest1.TRANSACTION_XLSX_FILE_PATH;

	static JSONParser parser = new JSONParser();

	WebDriver driver;


	public BasePayLoad(WebDriver driver){
		super(driver);
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	/**
	 * This method return JSON Object
	 * @return
	 */
	public static JsonPath jsonObject(Response response){
		JsonPath myJson=new JsonPath(response.asString());
		return myJson;
	}

	// to fetch client id
	public String getClientID() {
		String clientID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 2,1);
		return clientID;
	}

	// to fetch client id
	public String getProductName() {
		String productName = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 4,3);
		System.out.println("Product Name:" +productName);
		return productName;
	}

	// to fetch requestdate/time
	public String getRequestDateTime() {
		String requestDateTime = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath,"General", 0, 3);
		return requestDateTime;
	}

	// to fetch requestdate/time
	public String getCustID() {
		return "AIN"+ Generic.getRandomNumberInRange(111111, 999999)+Generic.getRandomNumberInRange(111111, 999999);
	}

	// to fetch UCIC ID
	public int getUCICID() {
		return Integer.parseInt(ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 3, 5));
	}

	// to fetch UCIC ID
	public String getPAN() {
		return ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 4, 5);
	}

	// to fetch bank id
	public String getBankID() {
		String bankID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 1, 1);
		return bankID;
	}

	//to fetch UCIC Registraion required or not
	public Boolean getUCICRegRequired() {
		String ucicRegRequired = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General", 8, 3);
		return Boolean.parseBoolean(ucicRegRequired);
	}

	// to fetch client txn id
	public String getClientTxnID() {
		String clientTxnID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",0, 3);
		clientTxnID = clientTxnID + "_API_Req_"+ Generic.getRandomNumberInRange(0, 100000);
		return clientTxnID;
	}

	// to fetch product id
	public String getProductID() {
		String productID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",3, 1);
		return productID;
	}

	// to fetch profile id
	public String getFullKYCProfileID() {
		String profileID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",4, 1);
		return profileID;
	}

	// to fetch profile id
	public String getNoKYCProfileID() {
		String profileID = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",1, 5);
		return profileID;
	}

	// to fetch configured MCC Code
	public String getConfiguredMCCCode() {
		String mccCode = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "General", 0, 3);
		return mccCode;
	}
	// to fetch non-configured MCC Code
	public String getNonConfiguredMCCCode() {
		String mccCode = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "General",1, 3);
		return mccCode;
	}

	// to fetch AML Max Card limit test data
	public String getAMLMaxCardLimit() {
		String maxCardLimit = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",7, 5);
		return maxCardLimit;
	}

	// to fetch AML Min Card limit test data
	public String getAMLMinCardLimit() {
		String minCardLimit = ExcelLibrary.getExcelData(api_Payload_TestData_xlsx_filepath, "General",6, 5);
		return minCardLimit;
	}

	// This Method is for API Request Body Composition
	public void AeroPayloadBody(String event) throws Exception {
	    // Fetching data for the defined "event" as referring to the sheet name
		// in AERO_API_data_Sheet.xlsx file
		Object[][] AeroReturn = DataProviderUtility.GetData(api_Payload_TestData_xlsx_filepath, event);
		// Fetching only header names from the object and assigning
		Object[] APIHeaders = AeroReturn[0];
		Object[][] APIHeadersvalues = AeroReturn;

//		RechargePayLoad reloadpayload = new RechargePayLoad();

		// looping across number of rows from APIBodyDataExcel.xlsx for the
		// event type
		for (int v = 1, d=1; v < APIHeadersvalues.length; v++) {
			String customerId=null;
			String cardNumber=null;
			String last4Digits=null;
			String urn=null;
			JSONObject requestBody;
			Response response = null;

			// checking if any messagecode api header value is not defined or empty
			if (APIHeadersvalues[v][6] == "")continue;

//			if (APIHeadersvalues[v][5] != BasePage.bank)break;

			String payLoadBody = "";
			boolean blockCardHolderDetails = false;
			boolean blockSenderDetails = false;
			boolean blockReceiverDetails = false;

			// checking if testcase is required for test execution regression or Sanity/Smoke.
			if (APIHeadersvalues[v][2].toString().equalsIgnoreCase("yes")|| APIHeadersvalues[v][3].toString().equalsIgnoreCase("yes")) {

				payLoadBody="{";
				// looping across number of columns from APIBodyDataExcel.xlsx for the event type
				// for(int i=2, j=2; i<APIHeaders.length; i++, j++)
				for (int i = 6; i < APIHeaders.length; i++) {
					// Convert Object to String by casting String HeaderValue = (String) APIHeadersvalues[v][j];
					String HeaderValue = (String) APIHeadersvalues[v][i];
					switch ((String) APIHeaders[i]) {
						case ("last4Digits"):
							if (HeaderValue.equals("") || HeaderValue.equals(null)) {
								requestBody = activationPayload("00", getFullKYCProfileID());
								response = createCard(requestBody, getUCICRegRequired());
								cardNumber = getResponseValue(response, "cardNumber");
								last4Digits = Generic.getLast4DigitCardNumber(cardNumber);
								HeaderValue = last4Digits;
							} else {
								last4Digits = HeaderValue;
							}
							break;
						case ("urn"):
							try {
								if (HeaderValue.equals("") || HeaderValue.equals(null)) {
									urn = getResponseValue(response, "urn");
									HeaderValue = urn;
								} else {
									urn = HeaderValue;
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							break;
						case ("customerId"):
							if (HeaderValue.equals("") || HeaderValue.equals(null)) {
								customerId = getResponseValue(response, "customerId");
								HeaderValue = customerId;
							} else {
								customerId = HeaderValue;
							}
							break;
						// Writing Expected Response Code to Excel
						case ("responseCode"):
							ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 3, HeaderValue);
							break;
						// Writing Response Message to Excel
						case ("responseMessage"):
							ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 4, HeaderValue);
							break;
						// Writing Status Code to Excel
						case ("statusCode"):
							ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 5, HeaderValue);
							break;
					}

					if (i < APIHeaders.length - 3) {
						// To Skip any header and value if not required in body
						if (HeaderValue.equalsIgnoreCase("false"))
							continue;
						// To replace header value "none" with ""
						if (HeaderValue.equalsIgnoreCase("none"))
							HeaderValue = "";
						// Fund transfers senders block body composition
						if (("senders").equalsIgnoreCase((String) APIHeaders[i]) || blockSenderDetails == true) {
							blockSenderDetails = true;
							// checking if the header value is expected
							if (("senders").equalsIgnoreCase((String) APIHeaders[i])) {
								payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\": [{";
								continue;
							} else {
								if (("reserved5").equals(APIHeaders[i])) {
									payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\":\"" + HeaderValue + "\"";
									// continue;
								}
							}
							// checking if sender block is completed then closing
							// the body for sender block
							if (("reserved5").equals(APIHeaders[i]) && blockSenderDetails == true) {
								payLoadBody = payLoadBody + "}],";
								blockSenderDetails = false;
								continue;
							}
						}

						// Fund transfers receivers block body composition
						if (("receivers").equalsIgnoreCase((String) APIHeaders[i]) || blockReceiverDetails == true) {
							blockReceiverDetails = true;
							// checking if the header value is expected
							if (("receivers").equalsIgnoreCase((String) APIHeaders[i])) {
								payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\": [{";
								continue;
							} else {
								if (("reserved5").equals(APIHeaders[i])) {
									payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\":\"" + HeaderValue + "\"";
									// continue;
								}
							}
							// checking if receivers block is completed then closing
							// the body for receivers block
							if (("reserved5").equals(APIHeaders[i]) && blockReceiverDetails == true) {
								payLoadBody = payLoadBody + "}]}";
								blockReceiverDetails = false;
								continue;
							}
						}

						// Card Holder Details Block body composition
						if (("cardholder").equalsIgnoreCase((String) APIHeaders[i]) || blockCardHolderDetails == true) {
							blockCardHolderDetails = true;
							// checking if the header value is expected
							if (("cardHolder").equalsIgnoreCase((String) APIHeaders[i])) {
								payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\": {";
								continue;
							} else {
								if (("cardholderCountry").equals(APIHeaders[i])) {
									payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\":\"" + HeaderValue + "\"";
								}
							}
							// checking if Card Holder block is completed then
							// closing the body for Card Holder block
							if (("cardholderCountry").equals(APIHeaders[i]) && i == APIHeaders.length - 4) {
								payLoadBody = payLoadBody + "}}";
								blockCardHolderDetails = false;
								continue;
							} else {
								if (("cardholderCountry").equals(APIHeaders[i]) && blockCardHolderDetails == true) {
									payLoadBody = payLoadBody + "},";
									blockCardHolderDetails = false;
									continue;
								}
							}
						}
						// other header Details body composition
						// checking if Request last header is completed then closing
						// the request body else continuing for next header
						if (i == APIHeaders.length - 4) {
							payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\":\"" + HeaderValue + "\"}";
						} else {
							payLoadBody = payLoadBody + "\"" + APIHeaders[i] + "\":\"" + HeaderValue + "\",";
						}
					}
				}
			}else{
				continue;
			}
			if(payLoadBody.length()>=1){
				// Writing Testcase ID to Excel
				ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 0, APIHeadersvalues[v][0].toString());
				// Writing Test Scenario details to Excel
				ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 1, APIHeadersvalues[v][1].toString());
				// Writing Test precondition details to Excel
				ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 6, APIHeadersvalues[v][2].toString());
				// Writing Report validation required or not details to Excel
				ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 7, APIHeadersvalues[v][3].toString());
				// after composition of request body seeding the request body to
				// APIRequestBodyExcel.xlsx
				ExcelLibrary.writeExcelData(api_requestbody_TestData_xlsx_filepath, event, d, 2,payLoadBody);
				d++;
			}
		}
//		requestBody = reloadpayload.reloadPayLoad(urn, last4Digits, customerId, 50000, "", "", "");
//		response = reloadpayload.reloadCard(requestBody);
//		System.out.println("reload response"+response.asString());
	}

//	public Connection ConnectToDB(String bank, String schema)throws ClassNotFoundException, SQLException {
//		// Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"
//		String dbUrl = "jdbc:mysql://" + pf.getProperty(bank + "dbIP") + ":"+ pf.getProperty(bank + "dbPort") + "/"+ pf.getProperty(bank + schema + "Schema") + "?useSSL=false";
//		System.out.println("dbUrl: "+dbUrl);
//		// Database Username
//		String username = pf.getProperty(bank + "dbUsername");
//		// Database Password
//		String password = pf.getProperty(bank + "dbPassword");
//
//		// Load mysql jdbc driver
//		Class.forName("com.mysql.jdbc.Driver");
//
//		// Create Connection to DB
//		Connection con = DriverManager.getConnection(dbUrl, username, password);
//
//		return con;
//	}

	public int executeUpdateQuery(Connection con, String query)	throws SQLException {
		// Create Statement Object
		Statement stmt = con.createStatement();
		// Execute the SQL Query. Store results in ResultSet
		int result = stmt.executeUpdate(query);
		return result;
	}

	public ResultSet executeSelectQuery(Connection con, String query)	throws SQLException {
		// Create Statement Object
		Statement stmt = con.createStatement();
		// Execute the SQL Query. Store results in ResultSet
		ResultSet result = stmt.executeQuery(query);
		return result;
	}

	public Response Precondition(String preCondition, String requestPayLoad) throws Exception {

		BlockPayLoad blockpayload = new BlockPayLoad(driver);
		RechargePayLoad reloadpayload = new RechargePayLoad(driver);
		UnBlockCardPayLoad unBlockPayLoad = new UnBlockCardPayLoad(driver);
		CardInquiryPayLoad cardInquiryPayLoad = new CardInquiryPayLoad(driver);
		CardHolderUpdateProfilePayLoad updateProfile = new CardHolderUpdateProfilePayLoad(driver);
		UnloadPayLoad unloadpayload = new UnloadPayLoad(driver);
		ResetPinPayLoad resetpinpayload = new ResetPinPayLoad(driver);
        FundTransferPayLoad fundTransferPayLoad = new FundTransferPayLoad(driver);
        AdjustmentRequestPage cardAdjust = new AdjustmentRequestPage(driver);
		int rows = 0;
		Connection con = null;
		int result = 0;

		String urn = null, last4Digits = null, customerId = null, event = null, eventComments = null;


		JSONObject requestObject;
		Response response = null;
		String[] cmscred = BaseTest1.getAppCredentials("cms");
		String transactionId;

		RestAssuredResponseImpl responseImpl = new RestAssuredResponseImpl();

		// to fetch URN, Last4Digits and customer ID from the request Payload
		JSONObject jsonRequest = ParseStringToJSON(requestPayLoad);
		//if messageCode is 1680-FundTransfer then fetching sender/receiver details(URN, Last4Digits and CustomerID)
		if (jsonRequest.get("messageCode").toString().equalsIgnoreCase("1680")) {
			String[] condition = preCondition.split(",");
			//to fetch sender or receiver card details
			System.out.println(jsonRequest.get(condition[0]).toString().replace("[,]", ""));
			JSONObject cardDetails = ParseStringToJSON(jsonRequest.get(condition[0]).toString().replaceAll("[\\]\\[]", ""));
			urn = cardDetails.get("urn").toString();
			last4Digits = cardDetails.get("last4Digits").toString();
			customerId = cardDetails.get("customerId").toString();
			preCondition = condition[1];
		} else {
			urn = jsonRequest.get("urn").toString();
			last4Digits = jsonRequest.get("last4Digits").toString();
			customerId = jsonRequest.get("customerId").toString();
			//if messageCode is 1081-Reload then fetching reserve details
			if (jsonRequest.get("messageCode").toString().equalsIgnoreCase("1081") || jsonRequest.get("messageCode").toString().equalsIgnoreCase("1080") ||
					jsonRequest.get("messageCode").toString().equalsIgnoreCase("1480")) {
				event = jsonRequest.get("reserved4").toString();
				eventComments = jsonRequest.get("reserved5").toString();
			}
		}


		JSONObject cardInquiryPost = cardInquiryPayLoad.cardInqPayLoad(urn, customerId, last4Digits);
		Response cardInquiryResponse = cardInquiryPayLoad.cardInquiry(cardInquiryPost);
		JsonPath responseValue = jsonObject(cardInquiryResponse);
		String cardStatus = responseValue.get("description");
		HashMap cardHolderDetails = responseValue.getJsonObject("cardHolder");
		String cardProfile = cardHolderDetails.get("cardProfileId").toString();
        String cardBalance = responseValue.get("availableCashLimit").toString();

		String[] condition = preCondition.split(",");
		for (int c = 0; c < condition.length; c++) {
			preCondition = condition[c];
			UpdateAMLProfileValue(preCondition);
			switch (preCondition) {
				// to custom block an active card
				case "Custom Block":
					if (!cardStatus.equals("Custom Blocked")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits, customerId, "Custom");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to temporary block an active card
				case "Temporary Block":
					if (!cardStatus.equals("Blocked Temporarily")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits, customerId, "Temporary");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to permanent block an active card
				case "Permanent Block":
					if (!cardStatus.equals("Blocked Permanently")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits, customerId, "Permanent");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to credit block an active card
				case "Credit Block":
					if (!cardStatus.equals("Credit Block")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits,
								customerId, "Credit Block");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to debit block an active card
				case "Debit Block":
					if (!cardStatus.equals("Debit Block")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits,
								customerId, "Debit Block");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to credit debit block an active card
				case "Credit Debit Block":
					if (!cardStatus.equals("Custom")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits,
								customerId, "Custom");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to close an active card
				case "Closed":
					if (!cardStatus.equals("Closed")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits,
								customerId, "Closed");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to cancel an active card
				case "Cancelled":
					if (!cardStatus.equals("Cancelled")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits,
								customerId, "Cancelled");
						response = blockpayload.BlockCard(requestObject);
					}
					break;
				// to UnBlock a temp/custom block card
				case "Unblock":
					if (!cardStatus.equals("Temporary Block") || !cardStatus.equals("Permanent Block") || !cardStatus.equals("Permanent Block")) {
						requestObject = blockpayload.blockPayload(urn, last4Digits, customerId, "Temporary");
						response = blockpayload.BlockCard(requestObject);
					}
					if (getResponseValue(response, "responseMessage").equalsIgnoreCase("success")) {
						requestObject = unBlockPayLoad.unblockPayLoad(urn, last4Digits, customerId);
						response = unBlockPayLoad.UnblockCard(requestObject);
					}
					break;
				// To upgrade an Non-KYC profile to KYC Profile
				case "KYC Upgrade":
					if (Integer.parseInt(cardProfile) != 100) {
						requestObject = updateProfile.updateProfileID(urn, customerId, last4Digits, getFullKYCProfileID());
						response = updateProfile.updateCardProfile(requestObject);
					}
					break;
				// to unload reversal for an card
				case "UnloadReversal":

					break;
				// to unload reversal for an card
				case "ZeroCardActivation":
					requestObject = activationPayload("00", getFullKYCProfileID());
					response = createCard(requestObject, true);
					break;
				// to reload on an active card
				case "Reload":
					if (cardStatus.equals("Active")) {
						requestObject = reloadpayload.reloadPayLoad(urn, last4Digits, customerId, 50000, "", "", "");
						response = reloadpayload.reloadCard(requestObject);
					}
					break;
				// to unload an active card
				case "Unload":
                        if(cardBalance.equalsIgnoreCase("0")){
                            reloadCard(String.valueOf(urn), last4Digits,customerId,100000, "","", "");
                        }
					if (cardStatus.equals("Active")) {
						requestObject = unloadpayload.unloadPayLoad(urn, last4Digits, customerId, 50000, "", "", "");
						response = unloadpayload.unloadCard(requestObject);
					}
					break;

				// Credit Adjustment from cms
				case "CreditAdjustment":
					BaseTest1.initBrowser("chrome", "cms");
                    LoginPage cmslogin = new LoginPage(driver);
					cmslogin.cmsLogin(cmscred[0], cmscred[1]);
                    cardAdjust.navigateToAdjustmentRequest();
					transactionId = getRequestResponse("activation", "accosaRefNo", urn);
                    cardAdjust.cardAdjustementRequest(getProductName(), urn, "Amount", "CR", "Activation", "100", transactionId);
                    cardAdjust.validateAdjustCardRequest(getProductName(), urn, "Amount", "Activation", "CR");
                    cardAdjust.submitCardAdjustment(transactionId);
////response=ParseStringToJSON("{\"precondition:\"success\"\"}");
//			responseImpl.setContent("{\"precondition:\"success\"\", transactionId:"+transactionId+"}");
//			response = responseImpl;
					break;
				// Debit Adjustment from cms
				case "DebitAdjustment":
                    BaseTest1.initBrowser("chrome", "cms");
                    LoginPage login = new LoginPage(driver);
                    login.cmsLogin(cmscred[0], cmscred[1]);
                    cardAdjust.navigateToAdjustmentRequest();
					transactionId = getRequestResponse("activation", "accosaRefNo", urn);
                    cardAdjust.cardAdjustementRequest(getProductName(), urn, "Amount", "DR", "Activation", "100", transactionId);
                    cardAdjust.validateAdjustCardRequest(getProductName(), urn, "Amount", "Activation", "CR");
					cardAdjust.submitCardAdjustment(transactionId);
////response=ParseStringToJSON("{\"precondition:\"success\"\"}");
//			responseImpl.setContent("{\"precondition:\"success\"\", transactionId:"+transactionId+"}");
//			response = responseImpl;
					break;

				// To Reset Pin on an active card
				case "ResetPin":
					if (cardStatus.equals("Active")) {
						requestObject = resetpinpayload.resetPayLoad(urn, last4Digits, customerId, last4Digits);
						response = resetpinpayload.resetPin(requestObject);
					}

					// To expire a card
				case "CardExpired":
//			con = ConnectToDB(BasePage.bank, "Accosa");
					result = 0;
					String query = null;
					boolean queryUpdate = false;

					System.out.println("Update Query to update card usage end date");
					query = "update aml_profile_parameters set AML_PROFILE_VALUE = 10000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MINIMUM_CARD_LIMIT' and INSTANCE_ID=8;";
					result = executeUpdateQuery(con, query);
					System.out.println("Update Query result for card usage end date:" + result);
					con.close();
					break;

				// To Create a KYC Card
				case "KYCCard":
					requestObject = activationPayload("150000", getFullKYCProfileID());
					response = createCard(requestObject, true);
					break;
				// To Create a Non-KYC Card
				case "FundDebit":
				case "FundCredit":
//			ArrayList senderdetails = (ArrayList) jsonRequest.get("senders");
//			HashMap sender = (HashMap) senderdetails.get(0);
//			ArrayList receiverdetails = (ArrayList) jsonRequest.get("receivers");
//			HashMap receiver = (HashMap) receiverdetails.get(0);
//			requestObject = fundTransferPayLoad.fundTransferPayLoad(sender.get("urn").toString(), sender.get("last4digits").toString(), sender.get("customerId").toString(), receiver.get("urn").toString(), receiver.get("last4digits").toString(), receiver.get("customerId").toString(), "10000");
					requestObject = fundTransferPayLoad.fundTransferPayLoad("", "", "", "", "", "", "10000");
					response = fundTransferPayLoad.fundTransfer(requestObject);
					break;
				// to perform an unload request and to process reload on a event on an active card
				case "Duplicate Reload Event":
                    if(cardBalance.equalsIgnoreCase("0")){
                        reloadCard(String.valueOf(urn), last4Digits,customerId,200000, "","", "");
                    }
					if (cardStatus.equals("Active")) {
						requestObject = unloadpayload.unloadPayLoad(urn, last4Digits, customerId, 50000, "", "", "");
						response = unloadpayload.unloadCard(requestObject);
						String unloadClientTxnId = getResponseValue(response, "clientTxnId");
						requestObject = reloadpayload.reloadPayLoad(urn, last4Digits, customerId, 50000, unloadClientTxnId, event, eventComments);
						reloadpayload.reloadCard(requestObject);
					}
					break;
				// to perform an reload request and to process reload on a event on an active card
				case "Duplicate Unload Event":
                    if(cardBalance.equalsIgnoreCase("0")){
                        reloadCard(String.valueOf(urn), last4Digits,customerId,200000, "","", "");
                    }
					if (cardStatus.equals("Active")) {
						requestObject = reloadpayload.reloadPayLoad(urn, last4Digits, customerId, 10000, "", "", "");
						response = reloadpayload.reloadCard(requestObject);
						String reloadClientTxnId = getResponseValue(response, "clientTxnId");
						requestObject = unloadpayload.unloadPayLoad(urn, last4Digits, customerId, 10000, reloadClientTxnId, event, eventComments);
						unloadpayload.unloadCard(requestObject);
					}
					break;
//		// To perform an authorization debit transaction
				case "Authorization":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "AuthorizationReportData", i, 0);
						HashMap<String, String> authorizationdata = Generic.parseStringToHashmap(data);
						if (authorizationdata.get("Auth Status").equalsIgnoreCase("Open")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", authorizationdata.get("URN"));
							jsonRequest.replace("urn", authorizationdata.get("URN"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				case "DebitSettlement":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport", i, 0);
						HashMap<String, String> settlementData = Generic.parseStringToHashmap(data);
						if (settlementData.get("Event").equalsIgnoreCase("FIR_PRESENTMENT_PUR")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", settlementData.get("URN Number"));
							jsonRequest.replace("urn", settlementData.get("URN Number"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				case "CreditSettlement":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport", i, 0);
						HashMap<String, String> settlementData = Generic.parseStringToHashmap(data);
						if (settlementData.get("Event").equalsIgnoreCase("FIR_PRESENTMENT_CR")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", settlementData.get("URN Number"));
							jsonRequest.replace("urn", settlementData.get("URN Number"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				case "DebitReversal":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport", i, 0);
						HashMap<String, String> settlementData = Generic.parseStringToHashmap(data);
						if (settlementData.get("Event").equalsIgnoreCase("FIR_PRESENTMENT_PUR_REV")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", settlementData.get("URN Number"));
							jsonRequest.replace("urn", settlementData.get("URN Number"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				case "CreditReversal":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "SettlementReport", i, 0);
						HashMap<String, String> settlementData = Generic.parseStringToHashmap(data);
						if (settlementData.get("Event").equalsIgnoreCase("FIR_PRESENTMENT_CR_REV")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", settlementData.get("URN Number"));
							jsonRequest.replace("urn", settlementData.get("URN Number"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				case "CreditChargeback":
					rows = ExcelLibrary.getExcelRowCount(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "ChargebackReport");
					for (int i = 1; i <= rows; i++) {
						String data = ExcelLibrary.getExcelData(BaseTest1.TRANSACTION_XLSX_FILE_PATH, "ChargebackReport", i, 0);
						HashMap<String, String> chargeBackData = Generic.parseStringToHashmap(data);
						if (chargeBackData.get("Processed Flag").equalsIgnoreCase("3")) {
							int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", chargeBackData.get("URN Number"));
							jsonRequest.replace("urn", chargeBackData.get("URN Number"));
							jsonRequest.replace("last4Digits", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1));
							jsonRequest.replace("customerId", ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3));
							break;
						}
					}
					response = Generic.buildRestResponse(jsonRequest.toString());
					break;
				// to update card expiry details
				case "Update Card Expiry":
                    CSRBasePage csrBasePage = new CSRBasePage(driver);
                    BaseTest1.initBrowser("chrome", "HSMEncryption");
                    String expiry = Generic.getPastOrFutureDate("MMYYYY", -1);
                    String encryptedExpiry = csrBasePage.text2HSMencryption(expiry);
                    expiry = Generic.getPastOrFutureDate("dd-MMM-YYYY", -1);
                    HashMap<String, String> dbDetails = BaseTest1.getDBDetails();
                    con = DB.connectToDB(dbDetails.get("ip"), dbDetails.get("port"), dbDetails.get("accosa"), dbDetails.get("username"),dbDetails.get("password"));
                    ResultSet selectresult = executeSelectQuery(con, "select * from icc_info_details where urn = " + urn);
                    String iccid = null;
                    while (selectresult.next()) {
                        System.out.println("Result Select" + selectresult.getString("ICC_ID"));
                        iccid = selectresult.getString("ICC_ID");
                    }
                    query = "UPDATE `hdfc_accosa`.`icc_info` SET `ICC_EXP_DATE`='" + encryptedExpiry + "', `USAGE_END_DATE`='" + expiry + "' WHERE `ICC_ID`=" + iccid + ";";
                    result = executeUpdateQuery(con, query);
                    System.out.println("query :" + query);
                    System.out.println("Expiry Update Query Result:" + result);
                    if (result == 1) {
                        csrBasePage.clearcache("II", iccid);
                    }
                    con.close();
					break;
			}
		}
		return response;
	}

	// Updating ALM Profile values
	public int UpdateAMLProfileValue(String condition)throws Exception {

		HashMap<String, String> dbDetails = BaseTest1.getDBDetails();
		Connection con = DB.connectToDB(dbDetails.get("ip"), dbDetails.get("port"), dbDetails.get("accosa"), dbDetails.get("username"),dbDetails.get("password"));
		int result = 0;
		String query = null;
		boolean queryUpdate = false;
		switch (condition) {

			// Update Query to validate AML validation for card min limit
			case "Min Card Limit":
				System.out.println("Update Query to validate AML validation for min card limit");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = "+getAMLMinCardLimit()+" where " +
						"INSTANCE_ID=(select INSTANCE_ID from aml_profile_instance where PRODUCT_ID = "+getProductID()+" and PROFILE_ID = "+getFullKYCProfileID()+") " +
						"and AML_PARAM_ID = 'MINIMUM_CARD_LIMIT';";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MINIMUM_CARD_LIMIT:"+ result);
				con.close();
				break;
			// Update Query to validate AML validation for card max limit
			case "Max Card Limit":
				System.out.println("Update Query to validate AML validation for card max limit");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = "+getAMLMaxCardLimit()+" where " +
						"INSTANCE_ID=(select INSTANCE_ID from aml_profile_instance where PRODUCT_ID = "+getProductID()+" and PROFILE_ID = "+getFullKYCProfileID()+") " +
						"and AML_PARAM_ID = 'MAXIMUM_CARD_LIMIT';";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAXIMUM_CARD_LIMIT:"+ result);
				con.close();
				break;
			// Update Query to validate AML validation for Day
			case "Max Load per Day":
				System.out.println("Update Query to validate AML validation for Day");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1000000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_AMOUNT_LOADED_PER_DAY' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_AMOUNT_LOADED_PER_DAY:"+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1500000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAXIMUM_CARD_LIMIT', 'MAX_AMOUNT_LOADED_PER_MONTH', 'MAX_AMOUNT_LOADED_PER_YEAR') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result CARD Max/Month/year"+ result);
				con.close();
				break;
			// Update Query to validate AML validation for Month
			case "Max Load per Month":
				System.out.println("Update Query to validate AML validation for Month");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1000000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_AMOUNT_LOADED_PER_MONTH' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_AMOUNT_LOADED_PER_MONTH:"+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1500000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAXIMUM_CARD_LIMIT', 'MAX_AMOUNT_LOADED_PER_DAY', 'MAX_AMOUNT_LOADED_PER_YEAR') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out
						.println("Update Query result CARD Day/Max/year" + result);

				con.close();
				break;
			// Update Query to validate AML validation for Year
			case "Max Load per Year":
				System.out.println("Update Query to validate AML validation for Year");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1000000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_AMOUNT_LOADED_PER_YEAR' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_AMOUNT_LOADED_PER_YEAR:"
						+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1500000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAXIMUM_CARD_LIMIT', 'MAX_AMOUNT_LOADED_PER_DAY', 'MAX_AMOUNT_LOADED_PER_MONTH') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result CARD Day/Max/Month"+ result);
				con.close();
				break;

			// Update Query to validate AML validation for card min Recharge limit
			case "Min Recharge Limit":
				System.out.println("Update Query to validate AML validation for card max limit");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 15000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MIN_RECHARGE_AMOUNT_PER_CARD' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MIN_RECHARGE_AMOUNT_PER_CARD:"+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 10000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MINIMUM_CARD_LIMIT') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MINIMUM_CARD_LIMIT"+ result);

				con.close();
				break;

			// Update Query to validate AML validation for card max Recharge limit
			case "Max Recharge Limit":
				System.out.println("Update Query to validate AML validation for card max limit");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 500000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_RECHARGE_AMOUNT_PER_CARD' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_RECHARGE_AMOUNT_PER_CARD:"
						+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 1000000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAXIMUM_CARD_LIMIT') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAXIMUM_CARD_LIMIT "+ result);

				con.close();
				break;

			// Update Query to validate AML validation for
			// MAX_DEBIT_AMOUNT_PER_DAY_KYC
			case "UL_TC_14":
				System.out.println("Update Query to validate AML validation for MAX_DEBIT_AMOUNT_PER_DAY_KYC");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 100000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_DEBIT_AMOUNT_PER_DAY_KYC' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_DAY_KYC:"+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 150000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAX_DEBIT_AMOUNT_PER_MONTH_KYC', 'MAX_DEBIT_AMOUNT_PER_YEAR_KYC') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_MONTH/YEAR_KYC "+ result);

				con.close();
				break;

			// Update Query to validate AML validation for
			// MAX_DEBIT_AMOUNT_PER_MONTH_KYC
			case "UL_TC_15":
				System.out.println("Update Query to validate AML validation for MAX_DEBIT_AMOUNT_PER_MONTH_KYC");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 100000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_DEBIT_AMOUNT_PER_MONTH_KYC' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_DAY_KYC:"
						+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 150000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAX_DEBIT_AMOUNT_PER_DAY_KYC', 'MAX_DEBIT_AMOUNT_PER_YEAR_KYC') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_DAY/YEAR_KYC "+ result);

				con.close();
				break;

			// Update Query to validate AML validation for
			// MAX_DEBIT_AMOUNT_PER_YEAR_KYC
			case "UL_TC_16":
				System.out.println("Update Query to validate AML validation for MAX_DEBIT_AMOUNT_PER_YEAR_KYC");
				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 100000 where PROFILE_ID = 200 and AML_PARAM_ID = 'MAX_DEBIT_AMOUNT_PER_YEAR_KYC' and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_DAY_KYC:"+ result);

				query = "update aml_profile_parameters set AML_PROFILE_VALUE = 150000 where PROFILE_ID = 200 and AML_PARAM_ID in ('MAX_DEBIT_AMOUNT_PER_DAY_KYC', 'MAX_DEBIT_AMOUNT_PER_MONTH_KYC') and INSTANCE_ID=8;";
				result = executeUpdateQuery(con, query);
				System.out.println("Update Query result MAX_DEBIT_AMOUNT_PER_DAY/MONTH_KYC "+ result);

				con.close();
				break;
		}
		con.close();
		return result;
	}

	public JSONObject ParseStringToJSON(String requestPayLoad) {

		//System.out.println("Inside json object method");
		JSONObject jsonRequest = null;
		try {
			jsonRequest = (JSONObject) parser.parse(requestPayLoad);
			//System.out.println(jsonRequest);
		} catch (Exception e) {
			System.out.println("Exception : " + e);
		}
		return jsonRequest;
	}

	public String getResponseValue(Response response, String responseKey) {
		JsonPath jsonValue = jsonObject(response);
		String responseValue = jsonValue.get(responseKey).toString();
		return responseValue;
	}


	/**
	 * This method return the payLoadBody
	 * @param profileID TODO
	 *
	 * @return
	 */

	public JSONObject activationPayload(String amount, String profileID) throws Exception {

//		amount = csrBasePage.fetchAMLProfileValue("minimum_card_limit");
		String payLoadBody = "{" + "\"messageCode\": \"1010\","
				+ "\"clientId\":" + "\""
				+ getClientID()
				+ "\""
				+ ","
				+ "\"clientTxnId\":"
				+ "\""
				+ getClientTxnID()
				+ "\""
				+ ","
				+ "\"requestDateTime\":"
				+ "\""
				+ getRequestDateTime()
				+ "\""
				+ ","
				+ "\"bankId\":"
				+ getBankID()
				+ ","
				+ "\"secureCode\": \"AfYtlO5kqdySIjXyNmGg3F\","
				+ "\"entityId\": 100,"
				+ "\"loadAmount\":"
				+ amount
				+ ","
				+ "\"productId\":"
				+ getProductID()
				+ ","
				+ "\"cardHolder\": {"
				+ "\"cardholderFirstName\":\"Automation\","
				+ "\"cardholderLastName\": \"Test\","
				+ "\"cardholderMobile\": \"1234567890\","
				+ "\"cardholderDateOfBirth\" :\"01-01-1997\","
				+ "\"cardholderEmail\":\"automation.test@wibmo.com\","
				+ "\"cardholderAddress\":\"automation.test, Wibmo\","
				+ "\"cardholderCity\":\"Wibmo\","
				+ "\"cardholderState\":\"Karnataka\","
				+ "\"cardholderZipCode\":\"560001\","
				+ "\"cardholderCountry\":\"India\""
				+ "},"
				// + "\"customerIdentityProfile\": {"
				// + "\"customerAadharCardNumber\": \"A_feb13_02\","
				// + "\"customerPANCardNumber\": \"\","
				// + "\"customerPassportNumber\": \"\","
				// + "\"customerVoterIdNumber\": \"\","
				// + "\"customerDrivingLicenseNumber\": \"\"" + "},"
				+ "\"cardProfileId\":"+ profileID+ ","
				+ "\"customerId\":"	+ "\""+ getCustID()+"\","
				+ "\"sourceAccountType\":\"00\","
				+ "\"sourceAccount\":\"1234\"" + "}";

		JSONObject requestObject = ParseStringToJSON(payLoadBody);
		return requestObject;
	}

	public Response createCard(JSONObject requestObject, Boolean ucicRegRequired) throws Exception{
		Response response = null;
		UCICRegPayLoad ucicRegistration = new UCICRegPayLoad(driver);
		try {
			response = given().contentType("application/json")
					.body(requestObject).when().log().body()
					.post(BaseTest1.getapiPostUrl("CardCreation")).then().and()
					.assertThat().statusCode(200).and()
					.contentType(ContentType.JSON).and().extract().response();
			System.out.println("Response :"+response.asString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		String jsonResponseMessage = getResponseValue(response,"responseMessage");
		if (jsonResponseMessage.equalsIgnoreCase("SUCCESS")) {
			String cardNumber = getResponseValue(response, "cardNumber");
			String urn = getResponseValue(response, "urn");
			String customerID = getResponseValue(response, "customerId");
			String cardLast4Digit = Generic.getLast4DigitCardNumber(cardNumber);
			String ucicPanDetail = null;

			if(ucicRegRequired){
				JSONObject ucicrequest = ucicRegistration.ucicRegPayload(urn, cardLast4Digit, customerID, getUCICID(), "");
				Response ucicresponse = ucicRegistration.ucicReg(ucicrequest);
				ucicPanDetail = ucicRegistration.getucicpanDetail(ucicrequest);
			}

			// updating the Card Last 4 Digits, URN and Customer ID details on
			// Card Details API Data sheet

			int i = ExcelLibrary.getExcelRowCount(testExecutionDataXlsxPath,"CardDetails")+1;
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 0, cardNumber);
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 1, cardLast4Digit);
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 2, urn);
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 3, customerID);
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 4, "Active");
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 5, "true"); // update activation event as true if card is active
			ExcelLibrary.writeExcelData(testExecutionDataXlsxPath, "CardDetails",i, 6, response.asString()); // update activation event as true if card is active
		}
		return response;
	}

	public String getRequestResponse(String apiEvent, String responseData, String cardDetail){
		int[] cardCell = null;
		int[] apieventCell = null;
		cardCell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails",String.valueOf(cardDetail));
		apieventCell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails",String.valueOf(apiEvent));
		String apiEventResponse = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cardCell[0], apieventCell[1]+1);
		JSONObject jsonObject =  ParseStringToJSON(apiEventResponse);
		return jsonObject.get(responseData).toString();
	}

	public String getCardStatus(String cardNumberOrURN) throws Exception{
		CardInquiryPayLoad cardInquiry = new CardInquiryPayLoad(driver);
		int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", cardNumberOrURN);
		if(cell==null){
			return "Card Inactive";
		}
		String last4digits = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1);
		String urn = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 2);
		String custId = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3);
		JSONObject requestObject = cardInquiry.cardInqPayLoad(urn, custId, last4digits);
		Response response = cardInquiry.cardInquiry(requestObject);
		String status = getResponseValue(response, "description");

		if(!status.equalsIgnoreCase("Active")){
			return "Card Inactive";
		}
		return status;
	}

	public String blockCard(String cardNumberOrURN, String blockType)throws Exception{
		BlockPayLoad cardBlock = new BlockPayLoad(driver);
		int[] cell = ExcelLibrary.searchTextFindCellAddress(testExecutionDataXlsxPath, "CardDetails", cardNumberOrURN);
		String last4digits = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 1);
		String urn = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 2);
		String custId = ExcelLibrary.getExcelData(testExecutionDataXlsxPath, "CardDetails", cell[0], 3);

		JSONObject requestObject = cardBlock.blockPayload(urn, last4digits, custId, blockType);
		Response response = cardBlock.BlockCard(requestObject);
		String status = getResponseValue(response, "responseMessage");
		if(!status.equalsIgnoreCase("SUCCESS")){
			return "Card Blocked";
		}
		return status;
	}

	public Response reloadCard(String urn, String last4Digits, String customerId, int reloadAmount, String orginalClientTxnId, String event, String eventComments) throws Exception{
		RechargePayLoad reloadpayload = new RechargePayLoad(driver);
		JSONObject requestObject = reloadpayload.reloadPayLoad(urn, last4Digits, customerId, reloadAmount, orginalClientTxnId,event,eventComments);
		Response response = reloadpayload.reloadCard(requestObject);
		return response;
	}
}


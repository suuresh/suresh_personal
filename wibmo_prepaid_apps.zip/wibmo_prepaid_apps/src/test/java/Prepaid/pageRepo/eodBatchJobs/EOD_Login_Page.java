package Prepaid.pageRepo.eodBatchJobs;

import Prepaid.pageRepo.BasePage;
import Prepaid.testScripts.BaseTest1;
import com.relevantcodes.extentreports.LogStatus;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


public class EOD_Login_Page extends BasePage
{
	private WebDriver driver;
	private static BaseTest1 BaseTest1 = new BaseTest1();

	/** Declaration of all the web elements */
	@FindBy(xpath = "//input[contains(@name, 'username')]")
	private WebElement eodUsername;

	@FindBy(xpath = "//input[contains(@name, 'password')]")
	private WebElement eodPassword;

	@FindBy(name="submit")
	private WebElement eodLogin;

	@FindBy(name="bankName")
	private WebElement bankName;

	@FindBy(xpath = "//input[@value='Get jobs List']")
	private WebElement getJobList;

	@FindBy(xpath="//input[@value='Get History']")
	private WebElement getHistory;

	@FindBy(xpath="//form[@id='jobList']")
	private WebElement jobListForm;

	@FindBy(xpath="//table[@summary='Job List']")
	private WebElement jobHistoryTable;

	@FindBy(xpath="//a[contains(text(),'Logout')]")
	private WebElement logout;

	@FindBy(id="message")
	private WebElement jobInitiatedMessage;

	@FindBy(xpath = "//table[@summary='Job List']//tr//td[contains(text(),'FAILURE')]//following-sibling::td[3]")
	private WebElement failureComments;

	@FindBy(xpath="//form[@name='jobList']")
	private WebElement batch;

	//EOD Jobs
	@FindBy (xpath="//span[text()='EOD Jobs']")
	public static WebElement EODJobs;
	@FindBy (xpath="//a[text()='Jobs List']")
	public static WebElement JobsList;
	@FindBy (xpath="//a[text()='Jobs Status']")
	public static WebElement JobsStatus;
	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public EOD_Login_Page(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void eodLogin(String username, String password)
	{
		//entering username
		eodUsername.sendKeys(username);
		//entering password
		eodPassword.sendKeys(password);
		//click on login
		eodLogin.click();
	}

	public void eodLogout()
	{
		//click on login
		logout.click();
		//validate login page is displayed
		eodLogin.isDisplayed();
	}


	public void selectBank(String bank)
	{
		Select Bank = new Select(bankName);
		switch(bank)
		{
			case "hdfc":
				Bank.selectByValue("HDF");
				break;
			case "bobk":
				Bank.selectByValue("BOB");
				break;
			case "IDBI":
				Bank.selectByValue("IDB");
				break;
			case "MCSurya":
				Bank.selectByValue("MCS");
				break;
			case "SBIB":
				Bank.selectByValue("SBI");
				break;
		}
		getJobList.click();
	}

	public String validateJobStatus(String status, int jobID)	{
		switch(status)	{
			case "SUCCESS":
				status = "SUCCESS";
				break;
			case "FAILURE":
				status = navigateToJobComments(jobID);
				break;
			case "ABORTED":
				break;
			case "STARTED":
				break;
			case "RUNNING":
				break;
		}
		return status;
	}

	public String navigateToJobComments(int jobID)	{
		driver.findElement(By.xpath("//a[@href='getJobHistory/getComments/"+jobID+"']")).click();
		String comments = failureComments.getText();
		return comments;
	}

	public String wibmoExecuteEODJob(String jobName) throws Exception	{
		String jobStatus=null;
		switch(jobName)
		{
			case "Card Expiry":
				jobName = "card_expiry";
				break;
			case "File Handler":
				jobName = "FileHandlerJob";
				break;
			case "Send To IBS":
				jobName = "SendToIBSJob";
				break;
			case "Auth Expiry":
				jobName = "system_expire_auth";
				break;
			case "Charge Back File Generator":
				jobName = "ChargeBackFileGeneratorJob";
				break;
			case "Charge Back Processor":
				jobName = "ChargeBackProcessorJob";
				break;

		}
		String jobToRun = "//td[contains(text(),'"+jobName+"')]/following-sibling::td/input[@id='trigger']";
		String jobHistory = "//td[contains(text(),'"+jobName+"')]/following-sibling::td/input[@id='triggerHistory']";

		Generic.wait(02);
		driver.findElement(By.xpath(jobToRun)).click();
		Generic.wait(5);
		String triggerMessage = jobInitiatedMessage.getText();
		int jobID = Integer.parseInt(triggerMessage.substring(triggerMessage.indexOf(":")+1, triggerMessage.indexOf(" ", triggerMessage.indexOf(":"))));
		int jobID2 = jobID+1;
		driver.navigate().back();
		Generic.wait(5);
		//Navigating to history page
		driver.findElement(By.xpath(jobHistory)).click();
		do{
//			getHistory.click();
			driver.navigate().refresh();
			if((driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+jobID+"')]//following-sibling::td[5]")).getText()).equals("SUCCESS")){
				boolean visibility = driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+ jobID2 +"')]")).isDisplayed();
				if(visibility){
					if(driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+ jobID2 +"')]//following-sibling::td[5]")).getText().equals("SUCCESS")){
						jobStatus = validateJobStatus(driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+ jobID2 +"')]//following-sibling::td[5]")).getText(), jobID);
						break;
					}
				}else{
					jobStatus = validateJobStatus(driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+ jobID2 +"')]//following-sibling::td[5]")).getText(), jobID);
					break;
				}
			}else{
				jobStatus = "FAILURE";
			/*	//Log.info( //logger.addScreenCapture(helper.getFullPageScreenshot(driver).toString()));
				String comments = navigateToJobComments(jobID);
				//Log.info( "Job Comments: "+comments);*/
				driver.navigate().back();
			}
		}while((driver.findElement(By.xpath("//table[@summary='Job List']//tr//td[contains(text(),'"+ jobID +"')]//following-sibling::td[5]")).getText()).equals("SUCCESS"));
		do{
//			String url = driver.getCurrentUrl();
//			driver.navigate().to(url.replace("getJobHistory", "getJobList"));
			driver.navigate().back();
			if(jobListForm.isDisplayed()){
				break;
			}
		}while(jobHistoryTable.isDisplayed());
		return jobStatus;
	}

	public boolean RunEODJob(String jobName) throws Exception
	{
		boolean Success = false;
		String jobToRun = "//form[@name='jobList']/table//b[contains(text(),'"+ jobName +"')]//following::a[1]";
		String jobStatus = "//form[@name='jobList']/table//b[contains(text(),'"+ jobName +"')]//following::td[2]";
		String Status;

		navigateToPage(EODJobs, JobsList);
		Generic.wait(5);
		driver.findElement(By.xpath(jobToRun)).click();
		Generic.wait(5);
		Assert.assertEquals(driver.findElement(By.xpath(jobStatus)).getText(), "Running");
		navigateToPage(EODJobs, JobsStatus);
		//assertEquals(driver.findElement(By.xpath(jobStatus)).getText(), "Completed");
		do{
			driver.navigate().refresh();
			Generic.wait(5);
			Status = driver.findElement(By.xpath(jobStatus)).getText();
		}while(Status.contentEquals("Running"));
		if(Status == "Completed"){
			Success = true;
		}else{
			Success = true;
		}
		return Success;
	}
	
	
	public boolean loginExecuteJobLogout(String jobName) throws Exception{
		//Launching EOD Web Application
		//Log.info("Launching EOD Web Application");
		BaseTest1.initBrowser("chrome", "EOD");
		WebDriver eodDriver = driver;
		EOD_Login_Page eod= PageFactory.initElements(eodDriver, EOD_Login_Page.class);
		//Log.info( "Launching EOD/cms Application to Run "+jobName);
		//Log.info( "logging to EOD/cms Application");
		String[] cred = BaseTest1.getAppCredentials("eod");
		eod.eodLogin(cred[0], cred[1]);
		eod.selectBank(BaseTest1.BANK);
		//Log.info( "Executing "+jobName);
		String jobRunStatus = eod.wibmoExecuteEODJob(jobName);	
		if(jobRunStatus.equalsIgnoreCase("SUCCESS")){
			//Log.pass( jobName+" is success");
			driver.close();
			return true;
			
		}else{
			//Log.info( //logger.addScreenCapture(helper.getFullPageScreenshot(driver).toString()));
			//Log.fail( jobName+" Job Status is Faliure");
			driver.close();
			return false;
		}
	}
}

package Prepaid.pageRepo.cms.userManagement;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class CreateUserPage extends BasePage {
    private WebDriver driver;

    public CreateUserPage(WebDriver driver) {
        super(driver);
        this.driver = driver;

    }

    @FindBy(xpath = "//a[text()='Create User']")
    private WebElement createUserLink;
    @FindBy(xpath = "//span[text()='User Management']")
    private WebElement userManagement;
    @FindBy(xpath = "//input[@value='Choose  Branch/Agency']")
    private WebElement chooseBranchBtn;
    @FindBy(xpath = "//a[text()='bdo']")
    private WebElement branchName;
    @FindBy(xpath = "//input[@value='submit']")
    private WebElement submit;
    @FindBy(name = "txtFirstName")
    private WebElement firstName;
    @FindBy(name = "txtLastName")
    private WebElement lastName;
    @FindBy(name = "txtMobile")
    private WebElement mobile;
    @FindBy(name = "txtEmail")
    private WebElement email;
    @FindBy(name = "txtLoginId")
    private WebElement loginId;
    @FindBy(name = "rolesId")
    private WebElement roleId;
    @FindBy(xpath = "//input[@value='Save']")
    private WebElement saveBtn;
@FindBy(xpath="//strong[contains(text(),'User was created Successfully')]")
private WebElement createUserSuccessMessage;
    public void navigateCreateUserPage() {
        navigateToPage(userManagement, createUserLink);
    }

    public void chooseBranch() {
        chooseBranchBtn.click();
        branchName.click();
    }

    public void submitBranch() {
        submit.click();
    }

    public void enterFirstName() {
        firstName.sendKeys("Automation");
    }

    public void enterLastName() {
        lastName.sendKeys("User");
    }

    public void enterMobileNum(String mobileNum) {
        mobile.sendKeys(mobileNum);
    }

    public void enterEmail(String emailID) {
        email.sendKeys(emailID);
    }

    public void enterLoginID(String userName) {
        loginId.sendKeys(userName);
    }

    public void selectRole() {
        Select userRole = new Select(roleId);
        userRole.selectByIndex(1);
    }

    public void clickSaveButton() {
        saveBtn.click();
        try{
            driver.switchTo().alert().accept();
        }
        catch(Exception e){

        }
    }

    public void submitBranchDetails() {
        navigateCreateUserPage();
        chooseBranch();
        submitBranch();
    }

    public void enterUserDetails(String mobileNum, String emailId, String userID) {
        enterFirstName();
        enterLastName();
        enterMobileNum(mobileNum);
        enterEmail(emailId);
        enterLoginID(userID);
        selectRole();
        clickSaveButton();
    }

    public void createUser(String userName, String mobileNum, String emailId) {
        submitBranchDetails();
        enterUserDetails(userName, mobileNum, emailId);
    }

public Boolean verifySuccessMessage(){
try{
    return(createUserSuccessMessage.isDisplayed());

}catch(NoSuchElementException e){
    return false;
}
    }
}

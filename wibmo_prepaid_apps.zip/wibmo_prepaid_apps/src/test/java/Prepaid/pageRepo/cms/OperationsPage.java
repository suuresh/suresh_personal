package Prepaid.pageRepo.cms;
/**
 * @author srikiran.d
 * Inventory Management Module
 * functions : Ship to head office, SHipe to Branch/Agencies  
 */
import static org.testng.Assert.assertTrue;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Set;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



public class OperationsPage extends BasePage {

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public OperationsPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}


	/***
	 * Declaration of all the web elements for Inventory Management Page
	 */

	//operations
	@FindBy(xpath="//span[text()='operations']")
	public static WebElement operations;
	@FindBy (xpath="//a[text()='Inventory']")
	public static WebElement inventory;

	@FindBy (xpath= "//h3[contains(text(),'Inventory Dashboard')]")
	private WebElement inventoryDashBoardPopup;
	@FindBy(id="fromUrnNo")
	private WebElement fromURNNumber;
	@FindBy(id="toUrnNo")
	private WebElement toURNNumber;
	@FindBy(id="urnStatus")
	private WebElement urnStatus;
	@FindBy (name="button")
	private WebElement urnStatusSubmit;
	@FindBy(xpath = "//font[text()='Inventory accept Sucessful']")
	private WebElement urnStatusSuccessMsg;
	
	public void ViewInventory(String FromURN, String ToURN) {
		// TODO Auto-generated method stub
		navigateToPage(operations, inventory);
		String CMSWindow = driver.getWindowHandle();
		String CMSinventoryWindow;
		Generic.wait(5);
		for (String InventoryDashboard : driver.getWindowHandles()) {
        	System.out.println(InventoryDashboard);
        	driver.switchTo().window(InventoryDashboard);
        }
		CMSinventoryWindow = driver.getWindowHandle();
		int NoOfBatchs = driver.findElements(By.xpath("//a[contains(text(),'Batch ')]")).size();
		for(int i=1; i<=NoOfBatchs; i++){
			driver.findElement(By.xpath("//a[contains(text(),'Batch ')]["+i+"]")).click();
			System.out.println(driver.findElement(By.xpath("//a[contains(text(),'Batch ')]["+i+"]")).getText());
			Generic.wait(5);
			for (String HeadOfficeInventory : driver.getWindowHandles()) 
			{			 
	        	driver.switchTo().window(HeadOfficeInventory);
	        }    	
	    	if((FromURN.equals(fromURNNumber.getAttribute("value"))  && ToURN.equals(toURNNumber.getAttribute("value"))))
	    	{	    		
	    		Select URNStatus = new Select(urnStatus);
	    		URNStatus.selectByVisibleText("Accept");
	    		urnStatusSubmit.click();
	    		driver.switchTo().alert().accept();
				Generic.wait(5);
	    		assertTrue(urnStatusSuccessMsg.isDisplayed());
	    		driver.close();
				Generic.wait(5);
	        	driver.switchTo().window(CMSinventoryWindow);
	    		break;
	    	}else{
	    		driver.close();
				Generic.wait(5);
	        	driver.switchTo().window(CMSinventoryWindow);
	    	}
		}
    	driver.close();
    	driver.switchTo().window(CMSWindow);
	}
}
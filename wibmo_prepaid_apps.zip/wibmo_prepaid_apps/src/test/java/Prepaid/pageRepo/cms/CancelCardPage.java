package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class CancelCardPage extends BasePage {
    private WebDriver driver;

    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public CancelCardPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(xpath="//div[@align='right']//img[contains(@src,'bob')]")
    private WebElement productImage;
    @FindBy(xpath = "//textarea[@name='comments']")
    private WebElement checkerComments;
    @FindBy(id="cancelCard")
    private WebElement cancelButton;
    @FindBy(xpath="//font[text()='Successfully Card Cancelled']")
    private WebElement cancelSuccessMsg;
    @FindBy(xpath="//input[@id='rejectCard']")
    private WebElement rejectButton;
    @FindBy(xpath="//input[@id='modifyCard']")
    private WebElement modifyReqButton;
    @FindBy(xpath="//font[text()='Successfully Done']")
    private WebElement rejectSuccessMessage;
    @FindBy(xpath  ="//font[text()='Modification Request successfully done']")
    private WebElement modifyRequestSuccessMessage;
    public void selectCancellationRequest(String Card4Digi){
        HomePage homePage=new HomePage(driver);
        homePage.clickCardManagementLink();
        homePage.clickCancelCard();
        Generic.wait(02);
        driver.findElement(By.xpath("//u[contains(text(), '"+Card4Digi+"')]")).click();
        Generic.wait(02);
        driver.findElement(By.xpath("//td[contains(text(),'"+Card4Digi+"')]")).isDisplayed();

    }

    public Boolean cancelCard(String Card4Digi){
        Assert.assertTrue(productImage.isDisplayed());
        System.out.println("The Product image is successfully displayed in Cancel Card page");
        checkerComments.sendKeys(Card4Digi+" Cancellation");
         cancelButton.click();
            driver.switchTo().alert().accept();
            Generic.wait(05);
            return cancelSuccessMsg.isDisplayed();

    }
public void rejectCancellationReq(){
        rejectButton.click();
        try{
            driver.switchTo().alert().accept();
        }catch(NoAlertPresentException e){
            e.getMessage();
        }
}

public Boolean verifyRejectSucccessMessage(){
try{
   return(rejectSuccessMessage.isDisplayed());
}
catch(Exception e){
    return false;
}
}
public void modifyCancelReq(){
        modifyReqButton.click();
}
public Boolean verifyModifyReqSuccessMessage(){
    try{
        return(modifyRequestSuccessMessage.isDisplayed());
    }
    catch(Exception e){
        return false;
    }
}
}

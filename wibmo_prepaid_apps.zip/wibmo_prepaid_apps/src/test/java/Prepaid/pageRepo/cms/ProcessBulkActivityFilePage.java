package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * @author Sanmati Vardhaman on May,2021
 */
public class ProcessBulkActivityFilePage extends BasePage
{
    WebDriver driver;
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public ProcessBulkActivityFilePage(WebDriver driver)
    {
        super(driver);
        //this.driver=driver;
        PageFactory.initElements(driver,this);
    }


    /** Declaration of all the web elements */
    @FindBy(xpath="//iframe[@class='iframe']")
    private WebElement cmsFrame;

    @FindBy(xpath="//input[@value='Collapse']")
    private WebElement collapseLink;

    @FindBy(xpath="//span[text()='File Management']")
    private WebElement fileManagement;

    @FindBy(linkText ="Process Bulk Activity File")
    private WebElement processBulkActivityFileLink;

    @FindBy(id="txtFromDate")
    private WebElement fromDate;

    @FindBy(id="txtToDate")
    private WebElement toDate;

    @FindBy(id="productId")
    private WebElement selectProductID;

    @FindBy(id="activity")
    private WebElement activityType;

    @FindBy(id="choseType")
    private WebElement fileTye;

    @FindBy(xpath="//input[@value='Fetch Bulk Activity']")
    private WebElement fetchButton;

    @FindBy(xpath="//a[@title='Click here to process the file : actviation_bulk_21032021_09.csv']")
    private WebElement fileClick;

    @FindBy(xpath="//h3[text()='Bulk File Confirmation']")
    private WebElement bulkConfirmation;

    @FindBy(id="comments")
    private WebElement userComments;

    @FindBy(xpath ="//input[@value='Approve']")
    private WebElement approveButton;

    public void processBulkFileForm(String productName,String activity,String file)
        {
            Select productSelect=new Select (selectProductID);
            productSelect.selectByVisibleText(productName);

            Select activitySelect=new Select (activityType);
            activitySelect.selectByVisibleText(activity);

            Select fileSelect=new Select(fileTye);
            fileSelect.selectByVisibleText(file);

            fetchButton.click();
            Generic.wait(5);

            fileClick.click();
            Generic.checkAlert(driver);
            if(bulkConfirmation.isDisplayed())
            {
                userComments.sendKeys("Uploading the bulk file by Automation");
                approveButton.click();
                Generic.checkAlert(driver);
            }
            System.out.println("Successfully processed the file");

        }

        public void bulkUtilityProcess(String productName,String activity,String file )
        {
            navigateToPage(fileManagement, processBulkActivityFileLink);
            processBulkFileForm(productName, activity, file);
            //driver.switchTo().alert().accept();
            Generic.wait(5);
        }





}

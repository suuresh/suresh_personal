package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import static org.testng.Assert.assertEquals;


public class ActivateCardPage extends BasePage
{

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public ActivateCardPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/** Declaration of all the web elements */
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;

	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;

	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;

	@FindBy(linkText="Activate Card")
	private WebElement activateCardLink;

	@FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']")
	private WebElement activationRequestList;

	@FindBy(name="checkerComments")
	private WebElement checkerComment;

	@FindBy(xpath="//input[@value='Reject Card']")
	private WebElement rejectCard;

	@FindBy(xpath="//input[@value='Modify']")
	private WebElement ModifyCard;

	@FindBy(xpath="//input[@value='Activate Card']")
	private WebElement ActivateCard;

	@FindBy(xpath="//input[@value='Modify']")
	private WebElement modifyButton;

	@FindBy(xpath="//input[@value='Reject Card']")
	private WebElement rejectButton;

	@FindBy(xpath ="//strong[text()='Card Activation request has been succesfully placed for modification.']")
	private WebElement modifyRequestSuccessMsg;

	@FindBy(xpath="//h3[text()='Activate Card - Success']")
	private WebElement successMessage;

	@FindBy(xpath="//strong[text()='Card Activation process has been succesfully cancelled.']")
	private WebElement rejectReqSuccessMessage;

	@FindBy(xpath="//frame[@name='activateCardConfirm']")
	private WebElement activateFrame;


	public void navigateToActivateCard(){
		navigateToPage(cardManagement, activateCardLink);
	}


	public WebElement searchActivatedRequestedCard(String urn){
		return driver.findElement(By.xpath(activationRequestList+"//td/center[contains(text(), '"+urn+"')]"));
	}

	public boolean assertActivateCardRequest(String urn, String cardNumber)
	{
		WebElement urnLocator = searchActivatedRequestedCard(urn);
		return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(driver.findElement(By.xpath(urnLocator+"//following::a")).getText().trim().replaceAll("\\s", ""));
	}

	public void selectActivateCardRequest(String urn){
		WebElement urnLocator = searchActivatedRequestedCard(urn);
		driver.findElement(By.xpath(urnLocator+"//following::a")).click();
	}

	public boolean assertCardNumber(String cardNumber){
		String maskedCardNumber = driver.findElement(By.xpath(activationRequestList+"//div[contains(text(), 'Card Number :')]/following::td")).getText().replaceAll("\\s", "");
		return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(maskedCardNumber);
	}

	public void activateCardRequest(String cardNumber){
		checkerComment.sendKeys("activated card number is "+Generic.getLast4DigitCardNumber(cardNumber) );
		ActivateCard.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generic.wait(5);
	}

	public boolean assertCardActivated(){
		return successMessage.isDisplayed() && successMessage.getText().equalsIgnoreCase("Activate Card - Success")
				&& driver.findElement(By.xpath(successMessage+"/following::strong[contains(text(),'Card Activation has been accepted, your card would be activated within 24 hours. Please find your activation')]")).isDisplayed();
	}

	public boolean assertActivateCardRequestDetails(String detail, String expectedValue){
		return expectedValue.equalsIgnoreCase(driver.findElement(By.xpath("//form[@name='activateCard']//table//div[contains(text(),'"+detail+" :')]/following::td[1]")).getText());
	}

	public boolean processCardActivationRequest(String cardNumber){
		navigateToPage(cardManagement, activateCardLink);
		searchActivatedRequestedCard(cardNumber);
		selectActivateCardRequest(cardNumber);
		assertCardNumber(cardNumber);
		activateCardRequest(cardNumber);
		return assertCardActivated();
	}


	public boolean modifyActivationRequest(String urn, String last4digit)
	{
		navigateToPage(cardManagement, activateCardLink);
		driver.findElement(By.xpath("//center[text()='"+urn+"']")).isDisplayed();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		checkerComment.sendKeys("Modified card number is "+last4digit );
		modifyButton.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generic.wait(5);
		assertEquals("Card Activation request has been succesfully placed for modification.",successMessage.getText());
		return successMessage.isDisplayed();
	}

	public boolean rejectActivationRequest(String urn, String last4digit)
	{
		navigateToPage(cardManagement, activateCardLink);
		driver.findElement(By.xpath("//center[text()='"+urn+"']")).isDisplayed();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		checkerComment.sendKeys("Rejected card number is "+last4digit );
		rejectButton.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generic.wait(5);
	    return successMessage.isDisplayed();
	}

}

package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Shankar Reddy on May,2021
 */
public class ReplacementCardPage extends BasePage {

    private WebDriver driver;
    public ReplacementCardPage(WebDriver driver){
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(xpath = "//span[text()='Card Management']")
    public static WebElement cardManagement;
    @FindBy(xpath = "//a[text()='Replace Card']")
    private WebElement replaceCardLink;
   @FindBy(name="checkerComments")
    private WebElement checkerCommentsInputField;
   @FindBy(name="replaceCard2")
    private WebElement approveButton;
   @FindBy(name="replaceCard1")
    private WebElement rejectButton;
   @FindBy(xpath="//font[text()='Card Replaced successfully']")
    private WebElement approveSuccessMessage;
    @FindBy(xpath="//font[text()='Successfully Done']")
    private WebElement rejectSuccessMessage;
    @FindBy(xpath = "//div[@align='right']//img[contains(@src,'bob')]")
    private WebElement productImage;
    @FindBy(xpath="//*[@id='QUERY_SUB_TABLE']/tbody//div[contains(text(),'Debit Account Number')]/../../td[2]")
    private WebElement debitAccNumberField;

    public void selectReplaceCardRequest(String card4Digi) {
        navigateToPage(cardManagement, replaceCardLink);
        driver.findElement(By.xpath("//u[contains(text(), '" + card4Digi + "')]")).click();
        Generic.wait(02);
    }
    public Boolean approveCardReplacement(){
        approveButton.click();
        try{
            return approveSuccessMessage.isDisplayed();
        }
        catch(NoSuchElementException e){
            return false;
        }
    }
    public Boolean rejectCardReplacement(){
        rejectButton.click();
        try{
            return rejectSuccessMessage.isDisplayed();
        }
        catch(NoSuchElementException e){
            return false;
        }

    }
        //@Shankar Reddy
        //To verify the debit account number exists in Replace Card Request page
        public Boolean verifyDebitAccNumberValue(String debitAccNumber){

            String debitAccNumValue=debitAccNumberField.getText();
            if(debitAccNumValue.contains(debitAccNumber)){
                return true;
            }else{
                return false;
            }
        }
        //To verify the debit account number is non-editable in Replace Card Request page.
        public Boolean verifyDebitAccNumberField(){
            return(debitAccNumberField.isEnabled());
        }

        //To verify the Product image is displayed in the Replace Card Request page.
        public Boolean verifyProductImage() {
            try {
                return (productImage.isDisplayed());

            } catch (NoSuchElementException e) {
                return false;
            }
        }

    }


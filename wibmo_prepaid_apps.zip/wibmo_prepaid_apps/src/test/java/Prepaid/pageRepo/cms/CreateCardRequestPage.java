package Prepaid.pageRepo.cms;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CreateCardRequestPage extends BasePage {

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public CreateCardRequestPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/** Declaration of all the web elements of Create Card Request Page*/

	public String ProductName, ExpiryMonths, NumberofCards, CardPersoVendor, CardTemplate, MakersComments;

	/**
	 *  Declaration of all the web elements of Create Card Approve Request.
	 */

	//cms Menu Section
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagement;

	@FindBy(xpath="//a[text()='Create Cards']")
	public static WebElement CreateCards;

	@FindBy(xpath="//a[text()='Create Card Request']")
	public static WebElement cardCreateRequest;

	//Create Card page-I
//Choose Product
	@FindBy(id="product")
	private WebElement productList;
	//Card Creation Mode
	@FindBy(id="cardCreationMode")
	private WebElement modeOfSelection;
	//Create Cards Submit
	@FindBy(name="submit")
	private WebElement cardCreationSubmit;

//Create Card page-II

	//BOB Bank
	@FindBy(name="expiryMon")
	private WebElement expiryMonths;
	//BOB Banks
	@FindBy(name="expiryDate")
	private WebElement infoExpiryDate;

	//Common Elements across Banks apps - Card Creation Page Form entry!
	@FindBy(xpath="//div[contains(text(),'Choose Product')]//following::select[1]")
	private WebElement ChooseProduct;

	@FindBy(xpath="//form[@name='createCards']/table//div[contains(text(),'Product Name')]/following::td[1]")
	public WebElement productName;
	@FindBy(xpath="//div[contains(text(), 'Product BIN')]/following::td")
	public WebElement productBin;
	@FindBy(xpath="//div[contains(text(), 'Card Union')]/following::td")
	public WebElement cardUnion;
	@FindBy(xpath="//div[contains(text(), 'Product Type')]/following::td")
	public WebElement productType;
	@FindBy(xpath="//div[contains(text(), 'Card Type')]/following::td")
	public WebElement cardType;
	@FindBy(xpath="//div[contains(text(), 'Card Usage')]/following::td")
	public WebElement cardUsage;
	@FindBy(xpath="//div[contains(text(), 'Card Mode')]/following::td")
	public WebElement cardMode;
	@FindBy(xpath="//div[contains(text(), 'Service Code')]/following::td")
	public WebElement serviceCode;


	@FindBy(xpath="//div[contains(text(),'No of Cards')]//following::select[1]")
	private WebElement NoofCards;
	@FindBy (xpath="//div[contains(text(),'Expiry Date')]//following::input[1]")
	private WebElement ExpiryDate;
	@FindBy(xpath="//div[contains(text(),'Name on Card')]//following::input[1]")
	private WebElement NameOnCard;
	@FindBy(xpath="//input[@name='submit']")
	private WebElement CreateSubmit;
	@FindBy(name="denominationSel")
	private WebElement numberOfCards;
	@FindBy(name="denominations")
	private WebElement CustomNumberOfCards;
	@FindBy(id="thirdLine")
	private WebElement thirdLinePrinting;
	@FindBy(id="fourthLine")
	private WebElement fourthLinePrinting;
	@FindBy(id="persoVendor")
	private WebElement cardPersoVendor;
	@FindBy(id="template")
	private WebElement template;
	@FindBy(id="templateDiv")
	private WebElement selectedTemplate;
	@FindBy(id="makerComments")
	private WebElement makerComments;
	@FindBy(name="submit")
	private WebElement createCardSubmit;



	@FindBy (xpath="//div[contains(text(),'Batch Id')]/following::td[1]")
	private WebElement BatchID;
	@FindBy (xpath="//div[contains(text(),'Product')]/following::td[1]")
	private WebElement CardProduct;
	@FindBy (xpath="//div[contains(text(),'BIN')]/following::td[1]")
	private WebElement BIN;
	@FindBy (xpath="//div[contains(text(),'No Of Cards Requested')]/following::td[1]")
	private WebElement CardsRequested;
	@FindBy (xpath="//div[contains(text(),'No Of Cards Created')]/following::td[1]")
	private WebElement CardsCreated;

	//Create Card Request Success page
	@FindBy(xpath="//div[contains(text(), 'Please find your card creation request id.')]/following::td[1]")
	private WebElement cardCreationRequestId;

	public void productSelectionforCardCreation(String ProductName)
	{
		navigateToPage(cardManagement, cardCreateRequest);
		//select the product from the product lists		
		Select select_Product=new Select(productList);
		select_Product.selectByVisibleText(" "+ProductName);
		this.ProductName = ProductName;
		//select card creation mode
		Select mode=new Select(modeOfSelection);
		mode.selectByVisibleText("Non-Personalized");
		//click on submit
		cardCreationSubmit.click();
		Generic.wait(3);
	}

	/**
	 *
	 * This method is used to Form Filling for Create Card Request (Maker Process)
	 * @param Expiry-BOB Bank
	 * @param NumberofCards
	 * @param ThirdLinePrinting
	 * @param FourthLinePrinting
	 * @param CardPersoVendor
	 * @param CardTemplate
	 * @param MakersComments
	 * @return Batch Id
	 */

	public String createCardsRequestFromCMS(String ExpiryMonths,String NumberofCards, String CardPersoVendor,String CardTemplate)
	{
		assertEquals(productName.getText(), ProductName);

		if(expiryMonths.isDisplayed()&&!ExpiryMonths.isEmpty())
		{
			//enter the details in second page
			expiryMonths.sendKeys(ExpiryMonths);

		}
		//select number of cards from the select box
		Select NoOfCards=new Select(numberOfCards);
		try{
			NoOfCards.selectByValue(NumberofCards);
		}catch(NoSuchElementException nsee)	{
			NoOfCards.selectByValue("C");
			CustomNumberOfCards.sendKeys(NumberofCards);
		}
		this.NumberofCards=NumberofCards;

		thirdLinePrinting.sendKeys(ProductName);
		fourthLinePrinting.sendKeys(ProductName);

		//card perso vendor select box
		Select persoVendor=new Select (cardPersoVendor);
		try{
			persoVendor.selectByVisibleText(CardPersoVendor);
		}catch(NoSuchElementException nsee)	{
			persoVendor.selectByValue("1");
			CardPersoVendor = persoVendor.getFirstSelectedOption().getText();
		}
		this.CardPersoVendor = CardPersoVendor;

		//select template from the template select box
		Select persoTemplate=new Select(template);
		try{
			persoTemplate.selectByVisibleText(CardTemplate);
		}catch(NoSuchElementException nsee)	{
			persoTemplate.selectByVisibleText("All Cards");
		}

		makerComments.sendKeys("-Card creation through Automation Bank");
		createCardSubmit.click();
		Generic.wait(3);

		String cardsBatchID=cardCreationRequestId.getText();
		System.out.println("batch id is "+cardsBatchID);
		Generic.wait(3);

		return cardsBatchID;
	}

	public void createCards(String Product, String NoOfCards, String ExpiryMonths) throws IOException
	{
		navigateToPage(cardManagement, CreateCards);
		Select chooseProduct = new Select(ChooseProduct);
		chooseProduct.selectByVisibleText(" "+Product);
		Select noOfCards = new Select(NoofCards);
		noOfCards.selectByVisibleText(" "+NoOfCards);
		String ExpiryMMYY = Generic.ExpiryMMYY(5,5);
		ExpiryDate.sendKeys(ExpiryMMYY);
//		NameOnCard.sendKeys(CardName);
		CreateSubmit.click();
		Generic.wait(3);
		//Fetch Order Details
		BatchID.getText();
		CardProduct.getText();
//		ExcelUtilities excelUtility = new ExcelUtilities();
//		int row = excelUtility.createCellSetValue(Generic.getPropertyTestDataFilePath(), "CreatedCardBatchDetails", 0, CardProduct.getText());
//		excelUtility.writeExcelData(Generic.getPropertyTestDataFilePath(), "CreatedCardBatchDetails", row, 2, BatchID.getText());
//		assertEquals(CardsRequested.getText(), CardsCreated.getText());
	}
}

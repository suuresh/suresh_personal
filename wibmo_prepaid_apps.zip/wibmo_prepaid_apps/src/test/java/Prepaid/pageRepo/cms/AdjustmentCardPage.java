package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AdjustmentCardPage extends BasePage {
    private static WebDriver driver;

    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public AdjustmentCardPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsLeftMenuFrame;

    @FindBy(xpath="//span[text()='Card Management']")
    public static WebElement cardManagement;

    @FindBy(xpath="//div[@align='right']//img[contains(@src,'bob')]")
    private WebElement productImage;



//    public void navigateToAdjustementRequest(){
//        navigateToPage(cardManagement, activationRequestLink);
//    }


    public void selectAdjustmentRequest(String card4Digi){
        HomePage homePage=new HomePage(driver);
        homePage.clickAdjustment();
        driver.findElement(By.xpath("//u[contains(text(), '"+card4Digi+"')]")).click();
        Generic.wait(02);

    }
    public Boolean verifyCardAdjustment(){
        try{
            return(productImage.isDisplayed());

        }
        catch (NoSuchElementException e){
            return false;
        }
    }

}

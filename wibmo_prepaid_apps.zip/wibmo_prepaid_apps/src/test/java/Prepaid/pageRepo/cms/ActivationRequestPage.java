package Prepaid.pageRepo.cms;

import static org.testng.Assert.assertEquals;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class ActivationRequestPage extends BasePage
{

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public ActivationRequestPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/** Declaration of all the web elements */
	@FindBy(xpath="//iframe[@class='iframe']")
	private WebElement cmsFrame;

	@FindBy(xpath="//input[@value='Collapse']")
	private WebElement collapseLink;

	@FindBy(xpath="//span[text()='Card Management']")
	private WebElement cardManagement;

	@FindBy(linkText="Activation Request")
	private WebElement activationRequestLink;

//********************************************

	@FindBy(name="cmbProduct")
	private WebElement productListDropdown;

	@FindBy(name="amount")
	private WebElement amountField;

	@FindBy(name="lastFourDigits")
	private WebElement lastFourDigitsField;

	@FindBy(name="urn")
	private WebElement urnField;

	//@FindBy(name="submit")
	@FindBy(xpath = "//div[@id='firstSubmit']//button")
	private WebElement actSubmitButton;
	//Validation error message while submitting card details.
	@FindBy(xpath="//span[@id='errorMsg']")
	private WebElement validationErrorMessage;

//************ Activation form web elements ************

	@FindBy(name="cardholderFirstName")
	private WebElement applicantName;

	@FindBy(name="mothername")
	private WebElement motherName;

	@FindBy(name="cardholderLastName")
	private WebElement lastName;

	@FindBy(name="cardholderdob")
	private WebElement dobField;

	@FindBy(name="cardholderAddress")
	private WebElement addressField;

	@FindBy(name="cardholderCity")
	private WebElement cityField;

	@FindBy(name="cardholderState")
	private WebElement stateField;
	@FindBy(name="cardholderCountry")
	private WebElement country;
	@FindBy(name="cardholderZipcode")
	private WebElement cardholderZipcode;
	@FindBy(name="identityProof")
	private WebElement identityProof;
	@FindBy(name="identityProofNumber")
	private WebElement identityProofNumber;
	@FindBy(name="taxationDocument")
	private WebElement taxationDocument;
	@FindBy(name="taxationDocumentNumber")
	private WebElement taxationDocumentNumber;
	@FindBy(name="debitAccountNumber")
	public WebElement debitAccountNumber;
	@FindBy(name="pobox")
	private WebElement poboxField;

	@FindBy(name="paddress")
	private WebElement pAddress;

	@FindBy(name="cardholderMobile")
	private WebElement mobileField;

	@FindBy(name="cardholderEmail")
	private WebElement emailField;

	@FindBy(name="paymentMode")
	private WebElement paymentModeList;

	@FindBy(name="chequeNo")
	private WebElement chequeField;

	@FindBy(name="pancardNumbercb")
	private WebElement pancardCheckBox;

	@FindBy(name="panCard")
	private WebElement panCardField;

	@FindBy(name="addressProffText")
	private WebElement addressProofField;

	@FindBy(id="journalNum")
	private WebElement cbsID;

	@FindBy(name="other")
	private WebElement commentsField;

	@FindBy(xpath="//button[@id='submitDetails']")
	private WebElement submitButton;

	@FindBy(id="paymentMode")
	public WebElement paymentMode;
	@FindBy(name="paymentDetails")
	private WebElement paymentDetails;
	@FindBy(name="makerComments")
	private WebElement makerComments;
	@FindBy(name="submit")
	private WebElement submit;


	@FindBy(xpath="//h3[text()='Card Activation Request - Success']")
	private WebElement activationRequestSuccess;

	/**
	 * 	Web Elements of Activate Card Request
	 */

	@FindBy(linkText="Activate Card")
	private WebElement activateCardLink;

	@FindBy(name="checkerComments")
	private WebElement checkerComment;

	@FindBy(xpath="//input[@value='Reject Card']")
	private WebElement rejectCard;

	@FindBy(xpath="//input[@value='Modify']")
	private WebElement ModifyCard;

	@FindBy(xpath="//input[@value='Activate Card']")
	private WebElement ActivateCard;

	@FindBy(xpath="//input[@value='Modify']")
	private WebElement modifyButton;
	@FindBy(xpath ="//strong[text()='Card Activation request has been succesfully placed for modification.']")
	private WebElement modifyRequestSuccessMsg;
	@FindBy(xpath="//h3[text()='Activate Card - Success']")
	private WebElement successMessage;

	@FindBy(xpath="//frame[@name='activateCardConfirm']")
	private WebElement activateFrame;



	public void navigateToActivationRequest(){
		navigateToPage(cardManagement, activationRequestLink);
	}

	public void selectProduct(String product){
		//select the product from the product list
		Select selProduct=new Select(productListDropdown);
		selProduct.selectByVisibleText(product);
	}

	public void enterCardActivationAmount(String amount){
		amountField.sendKeys(amount);
	}

	public void enterCardLast4digits(String last4digits){
	//	String last4digit = Generic.getLast4DigitCardNumber(cardNumber);
		lastFourDigitsField.sendKeys(last4digits);
	}

	public void enterCardURN(String urn){
		urnField.sendKeys(urn);
	}

	public void submitCardActivation(){
		actSubmitButton.click();
	}

	public void submitCardActivationDetails(String product, String amount, String cardNumber, String urn){
		selectProduct(product);
		enterCardActivationAmount(amount);
		enterCardLast4digits(cardNumber);
		enterCardURN(urn);
		submitCardActivation();
		Generic.wait(5);
	}

	public Boolean getCardDetailsErrorMessage(){
		try{
			return(validationErrorMessage.isDisplayed());
		}
		catch(Exception e){
			return false;
		}

	}

	public String enterCardHolderFirstName(){
		String firstname = Generic.getName();
		applicantName.sendKeys(Generic.getName());
		return firstname;

	}

	public void enterCardHolderLastName(){
		lastName.sendKeys(Generic.getName());
	}

	public void enterCardHolderDOB(){
		dobField.sendKeys(Generic.getPastOrFutureDate("dd-MM-yyyy", -8000));
	}

	public void enterCardHolderEmail(){
		emailField.sendKeys(Generic.getName()+"@testmail.com");
	}

	public void enterCardHolderMobile(){
		mobileField.sendKeys("933"+ Generic.getRandomNumberInRange(100000000, 999999999));
	}
	public void enterCardHolderAddress(){
		addressField.sendKeys(Generic.getStreetAddress());
	}
	public void enterCardHolderCity(){
		cityField.sendKeys(Generic.getCity());
	}

	public void enterCardHolderState(){
		stateField.sendKeys(Generic.getState());
	}

	public void enterCardHolderCountry(){
		country.sendKeys(Generic.getCountry());
	}

	public void enterCardHolderZipCode(){
		cardholderZipcode.sendKeys(Generic.getZipCode());
	}

	public void enterCardHolderIdentityProof(String identityType){
		Select selectIdProof=new Select(identityProof);
		selectIdProof.selectByVisibleText(identityType);
	}

	public void enterCardHolderIdentityProofNumber(){
		identityProofNumber.sendKeys(Generic.getIdentityNumber());
	}

	public void enterCardHolderTaxationDocument(){
		Select taxationDoc=new Select(taxationDocument);
		taxationDoc.selectByVisibleText("KRA PIN Number");
	}

	public void enterCardHolderTaxationDocumentNumber(){
		taxationDocumentNumber.sendKeys(Generic.getRandomNumberInRange(100000000, 999999999));
	}

	public void enterCardHolderDebitAccountNumber(){
		debitAccountNumber.sendKeys(Generic.getRandomNumberInRange(100000000, 999999999));

	}

	public void submitCardHolderDetails(){
		submitButton.click();
		Generic.wait(5);
	}

	public void enterCardHolderDetails(String idType)
	{
		//*******enter all the details in the form****
		Generic.waitForElement(driver,applicantName, 10);
		enterCardHolderFirstName();
		enterCardHolderLastName();
		enterCardHolderDOB();
		enterCardHolderEmail();
		enterCardHolderMobile();
		enterCardHolderAddress();
		enterCardHolderCity();
		enterCardHolderState();
		enterCardHolderCountry();
		enterCardHolderZipCode();
		enterCardHolderIdentityProof(idType);
		enterCardHolderIdentityProofNumber();
		enterCardHolderTaxationDocument();
		enterCardHolderTaxationDocumentNumber();
		enterCardHolderDebitAccountNumber();

		Generic.wait(5);

	}

	public void selectPaymentMode(String mode){
		Select paymentModeSelect = new Select(paymentMode);
		paymentModeSelect.selectByVisibleText(mode);
	}

	public void enterPaymentDetails(){
		paymentDetails.sendKeys(Generic.randomAlphaNumeric(25));
	}

	public void enterMakerComments(){
		makerComments.sendKeys(Generic.randomAlphaNumeric(25));
	}

	public void submitCardActivationRequest(){
		submit.click();
	}

	public boolean assertElementIsVisible(WebElement element){
		return element.isDisplayed();
	}

	public void confirmActivationDetails(String paymentMode, String makerComments){
		selectPaymentMode(paymentMode);
		enterPaymentDetails();
		enterMakerComments();
	}

	public boolean assertActivationSuccessMsg(){
		return activationRequestSuccess.getText().equalsIgnoreCase("Card Activation Request - Success") &&
				activationRequestSuccess.isDisplayed() &&
				driver.findElement(By.xpath("//h3[text()='Card Activation Request - Success']/following::strong[contains(text(),'Card Activation request has been sent to the checker for verification, your card would be activated shortly.')]")).isDisplayed();
	}

	public boolean placeCardActivationRequest(String productname,String amount,String last4digit,String urn,String idType)
	{
		navigateToActivationRequest();
		submitCardActivationDetails(productname, amount, last4digit, urn);
		enterCardHolderDetails(idType);
		submitCardHolderDetails();
		confirmActivationDetails("Cash","Card activation request");
		Generic.wait(5);
		submitCardActivationRequest();
		return assertActivationSuccessMsg();
	}

	public boolean activateCardRequest(String urn, String last4digit)
	{
		navigateToPage(cardManagement, activateCardLink);
		driver.findElement(By.xpath("//center[text()='"+urn+"']")).isDisplayed();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		checkerComment.sendKeys("activated card number is "+last4digit );
		ActivateCard.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generic.wait(5);
		assertEquals("Activate Card - Success",successMessage.getText());
		return successMessage.isDisplayed();
	}

	public boolean modifyActivationRequest(String urn, String last4digit)
	{
		navigateToPage(cardManagement, activateCardLink);
		driver.findElement(By.xpath("//center[text()='"+urn+"']")).isDisplayed();
		driver.findElement(By.xpath("//u[contains(.,'"+last4digit+"')]")).click();
		checkerComment.sendKeys("activated card number is "+last4digit );
		modifyButton.click();
		driver.switchTo().alert().accept();
		driver.switchTo().frame(activateFrame);
		Generic.wait(5);
		assertEquals("Card Activation request has been succesfully placed for modification.",successMessage.getText());
		return successMessage.isDisplayed();
	}
//To Get the validation error message While submitting  the card details in activation request page.
	public String getValidationMsgOnCardDetailsSubmit(){
		return validationErrorMessage.getText();
	}
}

package Prepaid.pageRepo.cms.userManagement;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ModifyUserRolePage extends BasePage {
    private WebDriver driver;

    public ModifyUserRolePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
    }
    @FindBy(xpath = "//span[text()='User Management']")
    private WebElement userManagement;
    @FindBy(xpath = "//a[text()='Modify User Roles']")
    private WebElement modifyUserRoleLink;
    @FindBy(xpath = "//h3[text()='Modify User Roles']")
    private WebElement modifyUserRolePage;
    @FindBy(xpath = "//td[text()='User Roles Information']")
    private WebElement userRoleInfoPage;
    @FindBy(xpath = "//input[@value='Activate Request,']")
    private WebElement activationRequestCheckBox;
    @FindBy(xpath = "//input[@name='submit']")
    private WebElement saveButton;

    @FindBy(xpath = "//font[text()='Successfully updated the user roles']")
    private WebElement modifyRoleSuccessMessage;

    public Boolean clickModifyUserRole() {
        navigateToPage(userManagement,modifyUserRoleLink);
        try {
            return (modifyUserRolePage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public Boolean selectModifyRole(String role) {
        String xpath = "//a/u[text()='" + role + "']";
        driver.findElement(By.xpath(xpath)).click();
        try {
            return (userRoleInfoPage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public String modifyPermission(String permission) {
        String xpath = "//input[@value='" + permission + ",']";
        WebElement element = driver.findElement(By.xpath(xpath));
        String attributeValue = element.getAttribute("checked");
        if (attributeValue != null) {
            element.click();
            return "UnSelected";
        } else {
            element.click();
            return "Selected";
        }
    }

    public void clickSaveButton() {
        saveButton.click();
    }

    public Boolean updateUserRole(String permission) {
        modifyPermission(permission);
        clickSaveButton();
        try {
            return (modifyRoleSuccessMessage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}



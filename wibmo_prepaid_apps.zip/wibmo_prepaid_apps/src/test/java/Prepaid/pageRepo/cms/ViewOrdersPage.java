package Prepaid.pageRepo.cms;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import Prepaid.pageRepo.BasePage;
import Prepaid.testScripts.BaseTest1;
import library.ExcelLibrary;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ViewOrdersPage extends BasePage
{	
	/***
	 * Declaration of all the web elements
	 */

	//Card Management
	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagement;

	@FindBy(linkText="View Orders")
	public static WebElement viewOrderLink;
		
	@FindBy(xpath="//input[@name='batchId']")
	private WebElement batch;	
	@FindBy(name="persoVendorSel")
	private WebElement vendorName;	
	@FindBy(name="submit")
	private WebElement submitButton;
	@FindBy(xpath="//u[text()='Pin File']")
	private WebElement pinFileLink;
	@FindBy(xpath="//u[contains(text(),'Vendor ')]")
	private WebElement persoFileLink;
	@FindBy(xpath="//form[@name = 'viewOrders']/table[3]//tr[2]/td[3]/div")
	private WebElement batchCardsRequested;
	@FindBy(xpath="//form[@name = 'viewOrders']/table[3]//tr[2]/td[4]/div")
	private WebElement batchCardsCreated;
	@FindBy(xpath = "//table//td/div[contains(text(), '')]//following::div[3]")
	private WebElement cardStatusLable;


	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public ViewOrdersPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void SearchCardsBatchID(String cardBatchID, String cardPersoVendor)
	{
		navigateToPage(cardManagement, viewOrderLink);
		Generic.wait(3);
		batch.sendKeys(cardBatchID);
		
		//select the vendor for the select box		
		Select vendorSelect=new Select(vendorName);
		vendorSelect.selectByVisibleText(cardPersoVendor);
		submitButton.click();
		Generic.wait(3);
	}

	public boolean validateCardsCreated(String NumberOfCards)
	{
		return NumberOfCards.equals(batchCardsCreated.getText());
	}

	public String getOrderCardStatus(String batchID){
		return driver.findElement(By.xpath("//table//td/div[contains(text(), '"+batchID+"')]//following::div[3]")).getText();
	}


	public boolean assertViewOrderCardStatus(String batchID, String expectedStatus){
		return driver.findElement(By.xpath("//table//td/div[contains(text(), '"+batchID+"')]//following::div[3]")).getText().equalsIgnoreCase(expectedStatus);
	}

	public String downloadPersonalizationFile(String BatchId, String ProductName) throws IOException	{
		Generic.wait(3);
		persoFileLink.click();
		driver.switchTo().alert().accept();
		String persoFileName = Generic.waitForFileToDownload("Personalization");
		//Generic.MoveFile(persoFileName);
		Generic.MoveFile(persoFileName);
		return persoFileName;
	}
	
	public String downloadPinFile(String batchID, String productName) throws IOException	{
		Generic.wait(3);
		pinFileLink.click();
		driver.switchTo().alert().accept();
		String pinFileName = Generic.waitForFileToDownload("Pin");
		//Generic.MoveFile(pinFileName);
		Generic.MoveFile(pinFileName);
		return pinFileName;
	}

	public void FetchCardPersoFileDetails(String fileName) throws Exception{
		FileReader fr=new FileReader(new File(System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+BaseTest1.ENV+File.separator+"Downloads"+File.separator+fileName));
		BufferedReader br=new BufferedReader(fr);
		String line;
		int i = ExcelLibrary.getExcelRowCount(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail");

		while((line = br.readLine())!=null){
			String[] a=line.split("\\$");
			if(a.length>1){
				//product
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 0, a[1].trim());
				//cardNumber
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 1, a[2].trim());
				String expiry = a[4].replace(a[2].trim(), "").trim();
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 2, expiry);
				//CVV2
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 3, a[5].substring(16).trim());
				String[] s = a[6].split("\\^");
				s[2] = s[2].substring(0, s[2].indexOf("?"));

				String serviceCode = s[2].substring(4,7);
				String cvv = s[2].substring(7,10);
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 4, serviceCode);
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 5, cvv);
				s = a[6].split("\\?");
				//Track2Data
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 6, s[1].replace(";", "").trim());
				//iCVV
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPersoFileDetail", i, 7, s[2].trim());
				i++;
			}
		}
	}

	public void FetchCardPinFileDetails(String fileName, String ProductName) throws Exception{
		FileReader fr=new FileReader(new File(System.getProperty("user.dir")+File.separator+"excel_lib"+File.separator+BaseTest1.ENV+File.separator+"Downloads"+File.separator+fileName));
		BufferedReader br=new BufferedReader(fr);
		String line;
		int i = ExcelLibrary.getExcelRowCount(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail");

		while((line = br.readLine())!=null){
			String[] a=line.split(",");
			if(line.isEmpty())break;//if(i==row || line.isEmpty())break;
			if((a[0].trim().contains("Id") && a[1].trim().contains("Card Number") && a[2].trim().contains("PIN Number"))){
				continue;
			}
			ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", i, 0, ProductName);
			for(int j=0,k=1;j<a.length;j++,k++){
				ExcelLibrary.writeExcelData(BaseTest1.TEST_EXECUTION_DATA_XLSX_PATH, "CardsPinFileDetail", i, k, a[j]);
			}
			i++;
		}
	}
}

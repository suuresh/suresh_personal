package Prepaid.pageRepo.cms;

/**@author Srikiran
 *
 */

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BlockCardPage extends BasePage
{

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public BlockCardPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 * Declaration of all the webElements of Block Card Page
	 */

	//cms Menu Section
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagement;

	@FindBy(linkText="Card Blocking")
	private WebElement cardBlockingLink;
	
	@FindBy(name="iccNumber")
	private WebElement cardNumberField;
	
	@FindBy(id="benefcheck")					// this is for only gift cards
	private WebElement checkBoxForGiftCards;
	
	@FindBy(id="mobile")
	private WebElement mobileNumberField;
	
	@FindBy(name="submit")
	private WebElement submitButton;
	
	@FindBy(name="reason")
	private WebElement reasonList;
	
	@FindBy(name="type")
	private WebElement typeOfBlock;
	
	@FindBy(xpath="//input[@value='Block Card']")
	private WebElement blockButton;

	@FindBy(xpath="//frame[@name='blockedCardConfirm']")
	private WebElement blockFrame;
	
	@FindBy(xpath="//h3[text()='Block Card - Success']")
	private WebElement blockSuccessMessage;
	
	
	/**
	 * Declaration of all the web elements for Card Unblock Page
	 */
	
	@FindBy(linkText="Card Unblocking")
	private WebElement cardUnlbockingLink;
	
	
	@FindBy(xpath="//input[@name='reason']")
	private WebElement userComments;
	
	@FindBy(xpath="//input[@value='Unblock Card']")
	private WebElement unblockButton;
	
	

	/**@author Srikiran
	 *
	 */
	public String blockCard(String cardNumber,String mobileNumber,String reason,String blockType)
	{
		switchToFrame(cmsLeftMenuFrame);
		Generic.waitForElement(driver, cardBlockingLink, 10);
		cardBlockingLink.click();
		driver.switchTo().defaultContent();
		
		//enter the card number to be blocked
		cardNumberField.sendKeys(cardNumber);
		submitButton.click();
		
		//Select the reason for blocking
		Select sel_Reason=new Select(reasonList);
		sel_Reason.selectByValue(reason);
	
		//Select the type of blocking
		Select sel_Type=new Select(typeOfBlock);
		sel_Type.selectByVisibleText(blockType);
		
		blockButton.click();
		driver.switchTo().frame(blockFrame);
		
		String message=blockSuccessMessage.getText();
		return message;
		
	}
}

package Prepaid.pageRepo.cms;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class RechargeCardPage extends BasePage {

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public RechargeCardPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 *  Declaration of all the web elements of Card Inquiry Request.
	 */
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;


	@FindBy(xpath="//a[text()='Recharge Card']")
	public static WebElement rechargeCardLink;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagementLink;

	@FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']")
	private WebElement rechargeRequestList;

	@FindBy(id="QUERY_SUB_TABLE")
	private WebElement rechargeDetailsSection;



	@FindBy(xpath = "//textarea[@name='checkerComments']")
	private WebElement checkerComments;
	@FindBy(xpath="//input[@value='Recharge Card']")
	private WebElement rechargeCard;
	@FindBy(xpath="//input[@value='Cancel Recharge']")
	private WebElement cancelRecharge;
	@FindBy(xpath="//div/h3[contains(text(), 'Recharge Card - Success')]")
	public WebElement rechargeSuccessMsg;
	@FindBy(xpath="//strong[contains(text(), 'Card Recharge process has been succesfully cancelled.')]")
	private WebElement cancelRechargeMsg;


	public void navigatetoRechargeCard(){
		navigateToPage(cardManagementLink, rechargeCardLink);
	}

	public WebElement searchRechargeRequestedCard(String cardNumber){
//		return driver.findElement(By.xpath(rechargeRequestList+"//td[contains(text(), '"+urn+"')]"));
		return driver.findElement(By.xpath(rechargeRequestList+"//a/u[contains(text(), '"+Generic.getLast4DigitCardNumber(cardNumber)+"')]"));
	}


	public boolean assertCardRechargeRequest(String cardNumber)	{
		WebElement cardLinkLocator = searchRechargeRequestedCard(cardNumber);
		return cardLinkLocator.isDisplayed() && Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(cardLinkLocator.getText().trim().replaceAll("\\s", ""));
	}

	public void selectCardRechargeRequest(String cardNumber){
		WebElement cardLinkLocator = searchRechargeRequestedCard(cardNumber);
		cardLinkLocator.click();
		Generic.wait(10);
	}

	public boolean assertCardNumber(String cardNumber){
		String maskedCardNumber = driver.findElement(By.xpath(rechargeRequestList+"//div[contains(text(), 'Card Number')]/following::td[1]")).getText().replaceAll("\\s", "");
		return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(maskedCardNumber);
	}

	public boolean assertRechargeDetail(String detail, String expectedValue){
		return driver.findElement(By.xpath(rechargeDetailsSection+"//div[contains(text(), '"+detail+"')]/following::td[1]")).getText().equalsIgnoreCase(expectedValue);
	}


	public void reviewRechargeRequest(String cardnumber, String reviewAction){
		checkerComments.sendKeys(cardnumber+" - Recharge "+reviewAction);
		if(reviewAction == "Approve"){
			rechargeCard.click();
			driver.switchTo().alert().accept();
			Generic.wait(5);
		}else{
			cancelRecharge.click();
			driver.switchTo().alert().accept();
			Generic.wait(5);
		}
	}

	public boolean assertCardRechargeSuccessful(){
		return rechargeSuccessMsg.isDisplayed();
	}

	public boolean assertCardRechargeCancelled(){
		return !cancelRechargeMsg.isDisplayed();
	}

	public String fetchTransationID(){
		return driver.findElement(By.xpath(rechargeDetailsSection+"//div/font[contains(text(),'Transaction Id')]/following::font[1]")).getText();
	}



}
package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class ProductModification  extends BasePage {
    private WebDriver driver;
   public ProductModification(WebDriver driver){
       super(driver);
       this.driver=driver;
       PageFactory.initElements(this.driver, this);
   }

    @FindBy(xpath="//select[@name='cmbProduct']")
    private static WebElement productSelectDropDown;

    @FindBy(xpath="//input[@value='Submit']")
    private static WebElement submit;

    @FindBy(xpath="//input[@type='radio' ][@value='1'][@name='optcrit']")
    private static WebElement updateImageRadioBtn;

    @FindBy(xpath="//*[@id=\"QUERY_SUB_TABLE_TAB\"]/tbody/tr[1]/td[2]/input")
    private static WebElement fileUploadLink;

    @FindBy(xpath="//input[@type='submit'][@name='cardImage']")
            private static WebElement uploadButton;

    @FindBy(xpath="//table[@id='QUERY_ERROR']//tr[2]//font")
            private static WebElement uploadFileSuccessMsg;



    public void performProdModification(String productName){
        HomePage homePage=new HomePage(driver);
        homePage.clickProductManagementLink();
       homePage.clickProductModification();
 Select select=new Select(productSelectDropDown);
select.selectByVisibleText(productName);
submit.click();
    }

    public void uploadProductImage() throws AWTException {
        updateImageRadioBtn.click();
        Assert.assertTrue(updateImageRadioBtn.isSelected());
        Generic.wait(5);
        Actions action=new Actions(driver);
        action.moveToElement(fileUploadLink).click().build().perform();
        Generic.wait(3);
        String userDir=System.getProperty("user.dir");
        String relativeFilePath="\\fileUploads\\bob_kenya_usd_card.jpg";
        String uploadFilePath=userDir+relativeFilePath;
        System.out.println("The path:"+uploadFilePath);

      /*StringSelection filePath=new StringSelection("filePath");

        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filePath, null);*/

        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection selection = new StringSelection(uploadFilePath);
        clipboard.setContents(selection, null);

        Robot rb = new Robot();
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_V);
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
        Generic.wait(3);
        driver.switchTo().defaultContent();
        try{
            Alert alert=driver.switchTo().alert();
            alert.accept();

        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }

        uploadButton.click();

Generic.wait(5);
        System.out.println("The File upload successfuly: Success message is: "+uploadFileSuccessMsg.getText());

    }
}

package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BasePage {
    private WebDriver driver;
    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsFrame;
    @FindBy(xpath="//input[@value='Collapse']")
    public static WebElement collapseLink;

    //product management
    @FindBy(xpath="//span[text()='Product Management']")
    private static WebElement productmanagementLink;
    @FindBy(xpath="//a[text()='Product Modification']")
    private static WebElement productModification;


    //Card Management
    @FindBy(xpath="//span[text()='Card Management']")
    public static WebElement cardManagement;
    @FindBy(xpath="//a[text()='Create Cards']")
    public static WebElement CreateCards;
    @FindBy(xpath="//a[text()='Create Card Request']")
    public static WebElement cardCreateRequest;
    @FindBy(xpath="//a[text()='Create Card Approve']")
    public static WebElement cardCreateApprove;


    @FindBy(xpath="//a[text()='Activation Request']")
    public static WebElement activationReqLink;
    @FindBy(xpath="//a[text()='Activate Card']")
    public static WebElement activateCardLink;
    @FindBy(xpath="//a[text()='Modify Activation Request']")
    private WebElement modifyActivationReqLink;
    @FindBy(xpath="  //a[text()='Recharge Request']")
    private WebElement rechargeReqLink;
    @FindBy(xpath=" //a[text()='Recharge Card']")
    private WebElement rechargeCardLink;
    public static WebElement viewOrderLink;
    @FindBy(xpath="//a[text()='Card Inquiry']")
    public static WebElement cardInquiry;
    @FindBy(xpath="//a[text()='Recharge Request']")
    public static WebElement rechargeRequest;
    @FindBy(xpath="//a[text()='Recharge Card']")
    public static WebElement rechargeCard;

    @FindBy(xpath="//a[text()='Cancel Card Request']")
    private WebElement cancelCardReqLink;
    @FindBy(xpath="//a[text()='Cancel Card']")
    private WebElement cancelCardLink;
    @FindBy(xpath="//a[text()='Replace Card Request']")
    private WebElement replaceCardReqLink;
    @FindBy(xpath="//a[text()='Replace Card']")
    private WebElement replaceCardLink;
    @FindBy(xpath="//a[text()='Adjustment Card Request']")
    private WebElement adjustmentReqLink;
    @FindBy(xpath="//a[text()='Adjustment Card']")
    private WebElement adjustmentCard;
    //AERO banks web element
    @FindBy(xpath="//a[text()='Adjustment Card(Lite)']")
    public static WebElement cardAdjustment;
    //non-AERO banks web element
    @FindBy(xpath="//a[text()='Adjustment Request']")
    public static WebElement cardAdjustmentRequest;

    //EOD Jobs
    @FindBy (xpath="//span[text()='EOD Jobs']")
    public static WebElement EODJobs;
    @FindBy (xpath="//a[text()='Jobs List']")
    public static WebElement jobsList;
    @FindBy (xpath="//a[text()='Jobs Status']")
    public static WebElement jobStatus;

    //Inventory Management
    @FindBy (xpath="//span[text()='Inventory Management']")
    public static WebElement inventoryManagement;
    @FindBy (xpath="//a[text()='Ship to Head Office']")
    public static WebElement shiptoHeadOffice;
    @FindBy (xpath="//a[text()='Ship to Branches/Agencies']")
    public static WebElement shiptoBranchesOrAgencies;

    //operations
    @FindBy(xpath="//span[text()='operations']")
    public static WebElement operations;
    @FindBy (xpath="//a[text()='Inventory']")
    public static WebElement inventory;

    public HomePage(WebDriver driver){
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }

    public void clickCardManagementLink(){
        driver.switchTo().frame(cmsFrame);
        collapseLink.click();
        Generic.wait(02);
        cardManagement.click();

    }
    public void clickActivationReqLink(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        activationReqLink.click();

    }

    public void clickActivationCardLink(){
        driver.switchTo().frame(cmsFrame);
        Generic.wait(04);
        activateCardLink.click();
    }
public void clickModifyActivationRequest(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        modifyActivationReqLink.click();
}
    public void clickRechargeRequest(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        rechargeReqLink.click();
    }
    public void clickRechargeCard(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        rechargeCardLink.click();
    }

    public void clickCancelCardRequest(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        cancelCardReqLink.click();
    }

    public void clickCancelCard(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        cancelCardLink.click();
    }

    public void clickReplaceCardReq(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        replaceCardReqLink.click();
    }

    public void clickReplaceCardLink(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(02);
        replaceCardLink.click();

    }
    public void clickCreateCardReq()
    {
        cardCreateRequest.click();
    }

    public void clickEODjobs(){
        driver.switchTo().frame(cmsFrame);
        collapseLink.click();
        Generic.wait(05);
        EODJobs.click();

    }

    public void clickJobList(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        jobsList.click();
    }

    public void clickJobStatus(){
     driver.switchTo().frame(cmsFrame);
        Generic.wait(05);
    jobStatus.click();
    }
public void clickProductManagementLink(){

        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(2);
        productmanagementLink.click();
}
public void clickAdjustmentReqLink(){
    driver.switchTo().defaultContent();
    driver.switchTo().frame(cmsFrame);
    Generic.wait(2);
    adjustmentReqLink.click();
}
    public void clickAdjustment(){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(cmsFrame);
        Generic.wait(2);
        adjustmentCard.click();
    }
public void clickProductModification(){
        productModification.click();
}
}

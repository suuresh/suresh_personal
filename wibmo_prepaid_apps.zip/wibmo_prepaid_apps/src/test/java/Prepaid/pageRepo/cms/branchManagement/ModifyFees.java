package Prepaid.pageRepo.cms.branchManagement;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class ModifyFees extends BasePage
{
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    WebDriver driver;

    public ModifyFees(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    //declaration of all the web elements in modify branch page

    @FindBy(xpath="//span[text()='Manage Branch/Agency ']")
    private WebElement branchManagement;

    @FindBy(xpath="//a[text()='Modify Fees']")
    private WebElement modifyFeesLink;

    @FindBy(xpath="//input[@name='entityName']")
    private WebElement entityName;

    @FindBy(xpath="//input[@value='Submit']")
    private WebElement submitDetails;

    //product details webelement

    @FindBy(xpath="//td[contains(text(),'Product : Non reloadable KES Card')]")
    private WebElement productName;

    @FindBy(xpath="//input[@name='feeAmount0']")
    private WebElement activationFeeAmount;

    @FindBy(xpath="//input[@name='submit']")
    private WebElement updateDetails;

    @FindBy(xpath="//h3[text()='Modify Fees - Success']")
    private WebElement successMessage;

    @FindBy(xpath="//*[text()='No Such Entity/Branch Name Present.']")
    private WebElement erroMessageOnNoEntity;

    //navigate to modify fee and enter branch details

    public void navigateToModifyFees(){
        navigateToPage(branchManagement, modifyFeesLink);
    }

    public void enterBranchName(String branchName){entityName.sendKeys(branchName);}

    public void submitBranch(){submitDetails.click();}

    public void submitBranchDetails(String branchName)
    {
        enterBranchName(branchName);
        submitBranch();
    }

    public void enterFeeDetails(String productName)
    {
        Generic.wait(5);
        System.out.println(activationFeeAmount.getText());
        if(productName.equalsIgnoreCase("Non reloadable KES Card"))
        {
            activationFeeAmount.clear();
            activationFeeAmount.sendKeys("200.00");
            Generic.wait(5);
            System.out.println(activationFeeAmount.getText());
        }

    }

    public void submitFeeDetails(String productName)
    {
        enterFeeDetails(productName);
        updateDetails.click();

    }

    public void assertModifyFeesSuccess(String expectedMessage) {
        successMessage.getText().equalsIgnoreCase(expectedMessage);
    }

    /// this method decides which bank fees to be updated.


    // method decides which bank to execute
    public void bank_ModifyFees(String bankName,String branchName,String productName,String expectedMessage)
    {


        switch(bankName)
        {
            case "bobk":
                navigateToModifyFees();
                submitBranchDetails(branchName);
                submitFeeDetails(productName);
                Generic.checkAlert(driver);
                assertModifyFeesSuccess(expectedMessage);
                break;

            default:
                System.out.println(bankName+ ":-  entered is not present in the prepaid system");



        }

    }


}

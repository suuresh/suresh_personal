package Prepaid.pageRepo.cms;

/**
 * @author srikiran.d
 * Inventory Management Module
 * functions : Ship to head office, SHipe to Branch/Agencies  
 */

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class InventoryManagementPage extends BasePage {


	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public InventoryManagementPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/***
	 * Declaration of all the web elements for Inventory Management Page
	 */

	//Inventory Management
	@FindBy (xpath="//span[text()='Inventory Management']")
	public static WebElement inventoryManagement;
	@FindBy (xpath="//a[text()='Ship to Head Office']")
	public static WebElement shiptoHeadOffice;
	@FindBy (xpath="//a[text()='Ship to Branches/Agencies']")
	public static WebElement shiptoBranchesOrAgencies;

	@FindBy(id="product")
	private WebElement chooseProduct;
	@FindBy(id="fromUrn")
	private WebElement fromURN;
	@FindBy(id="toUrn")
	private WebElement toURN;
	@FindBy(id="totalCardsReq")
	private WebElement totalCardsRequested;
	@FindBy(id="totalCardsProcessed")
	private WebElement totalCardsProcessed;
	@FindBy(id="totalInvalidCards")
	private WebElement totalInvalidCards;
	@FindBy(xpath="//a[text()='View Invalid URNs')]")
	private WebElement viewInvalidURNs;
	@FindBy(name="courierName")
	private WebElement courierName;
	@FindBy(name="proofOfDelivery")
	private WebElement proofOfDelivery;
	@FindBy(name="submit")
	private WebElement submit;	
	@FindBy(xpath = "//font[contains(text(),'Inventory loading was successful')]")
	private WebElement inventoryloadedSuccessfullyMsg;
	
	//Ship to Branch/Agencies
	
	@FindBy(id="entityName")
	private WebElement branchOrAgenciesName;
	
	public void ShipInventoryToHeadOffice(String Product, String FromURN, String ToURN)
	{
		navigateToPage(inventoryManagement, shiptoHeadOffice);
		Select choose_Product=new Select(chooseProduct);
		choose_Product.selectByVisibleText(" "+Product);
		fromURN.sendKeys(FromURN);
		toURN.sendKeys(ToURN);
		assertEquals(totalCardsRequested.getText(), totalCardsProcessed.getText());
		courierName.sendKeys(Product+"- URN From "+FromURN+" To URN "+ToURN);
		proofOfDelivery.sendKeys(Product+"- URN From "+FromURN+" To URN "+ToURN);
		submit.click();
		Generic.wait(5);
		assertTrue(inventoryloadedSuccessfullyMsg.isDisplayed());
	}
	
	public void ShipInventoryToBranchOrAgencies(String BranchOrAgencies, String Product, String FromURN, String ToURN)
	{
		navigateToPage(inventoryManagement, shiptoBranchesOrAgencies);
		branchOrAgenciesName.sendKeys(BranchOrAgencies);
		Select choose_Product=new Select(chooseProduct);
		choose_Product.selectByVisibleText(" "+Product);
		fromURN.sendKeys(FromURN);
		toURN.sendKeys(ToURN);
		assertEquals(totalCardsRequested.getText(), totalCardsProcessed.getText());
		courierName.sendKeys(BranchOrAgencies+" - "+Product+"- URN From "+FromURN+" To URN "+ToURN);
		proofOfDelivery.sendKeys(BranchOrAgencies+" - "+Product+"- URN From "+FromURN+" To URN "+ToURN);
		submit.click();
		Generic.wait(5);
		assertTrue(inventoryloadedSuccessfullyMsg.isDisplayed());
	}	
}

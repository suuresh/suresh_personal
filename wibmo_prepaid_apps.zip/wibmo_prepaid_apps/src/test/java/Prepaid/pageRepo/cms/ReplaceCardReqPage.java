package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.text.DecimalFormat;

public class ReplaceCardReqPage extends BasePage {

    private WebDriver driver;
    public ReplaceCardReqPage(WebDriver driver){
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }


    /**
     *  Declaration of all the web elements of Card Inquiry Request.
     */
    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsLeftMenuFrame;

    @FindBy(xpath="//a[text()='Replace Card Request']")
    public static WebElement replaceCardRequest;

    @FindBy(xpath="//span[text()='Card Management']")
    public static WebElement cardManagementLink;

    @FindBy(name="iccNumber")
    private WebElement cardNumberField;
    @FindBy(name="urn")
    private WebElement urnField;
    @FindBy(name="lastFour")
    private WebElement last4DigitsField;
    @FindBy(name="submit")
    private WebElement submitButton;

    @FindBy(xpath = "//table[@id='QUERY_SUB_TABLE'][1]")
    private WebElement cardDetailsDiv;

    @FindBy(xpath = "//table[@id='QUERY_SUB_TABLE'][2]")
    private WebElement cardBalanceDetailsDiv;

    @FindBy(xpath="//table[@id='QUERY_SUB_TABLE'][2]//div[contains(text(), 'Balance Amount')]")
    private WebElement balanceAmountLabel;

    @FindBy(id="otherCharges")
    private WebElement otherChargesInputField;
    @FindBy(id="address")
    private WebElement addressInputField;
    @FindBy(xpath="//a[text()='Cancel']")
    private WebElement cancelButton;
    @FindBy(xpath="//td[text()='Card Details']")
    private WebElement cardDetails;
    @FindBy(xpath="//div[@align='right']//img[contains(@src,'bob')]")
    private WebElement productImage;

    @FindBy(name="newIccNumber")
    private WebElement newCardNumberInputField;
    @FindBy(id="urn")
    private WebElement newCardURNInputField;
    @FindBy(id="lastFour")
    private WebElement newCardLast4digitInputField;

    @FindBy(name="makerComments")
    private WebElement makerCommentsInputField;
    @FindBy(xpath="//*[@id='QUERY_SUB_TABLE']/tbody//div[contains(text(),'Debit Account Number')]/../../td[2]")
    private WebElement debitAccNumberField;
    @FindBy(xpath = "//font[text()='Card Replacement Request successfully done']")
    private WebElement successMessage;

    @FindBy(xpath="//table[@id='QUERY_ERROR']//Font")
    private WebElement messageDiv;


    public void navigateToReplaceCardRequest(){
        navigateToPage(cardManagementLink, replaceCardRequest);
    }

    public void searchCardBy(String cardDetail, String cardValue){
        switch (cardDetail){
            case "Card Number":
                enterCardNumber(cardValue);
                break;
            case "URN":
                enterURN(cardValue);
                break;
            case "Last 4 Digits":
                enterlast4Digits(cardValue);
                break;
        }
        submitCardDetails();
    }

    public void enterCardNumber(String cardNumber){
        cardNumberField.sendKeys(cardNumber);
    }

    public void enterURN(String urn){
        urnField.sendKeys(urn);
    }

    public void enterlast4Digits(String cardNumber){
        last4DigitsField.sendKeys(Generic.getLast4DigitCardNumber(cardNumber));
    }

    public void submitCardDetails(){
        submitButton.click();
    }

    public void enterOtherCharges(String charges){
        otherChargesInputField.sendKeys(charges);
    }

    public void enterDispatchAddress(){
        addressInputField.sendKeys(Generic.getAddress());
    }

    public boolean assertTransferableAmount(){
        int balanceAmount = fetchCardBalanceValues("Balance Amount");
        int replacementFee = fetchCardBalanceValues("Replacement Fee");
        int taxAmount = fetchCardBalanceValues("Tax Amount");
        int currencyRate = fetchCardBalanceValues("Currency Rate");
        int otherCharges = fetchCardBalanceValues("Other Charges");
        int transferableAmount = fetchCardBalanceValues("Transferable Amount ");

        float expectedTransferableAmount = balanceAmount-((replacementFee+taxAmount)+(otherCharges/currencyRate));
        DecimalFormat df = new DecimalFormat("#.00");
        expectedTransferableAmount = Float.valueOf(df.format(expectedTransferableAmount));
        return expectedTransferableAmount==transferableAmount;


    }


    public boolean assertCardNumber(String cardNumber){
        String maskedCardNumber = driver.findElement(By.xpath(cardDetailsDiv+"//div[contains(text(), 'Card Number')]/following::td[1]")).getText().replaceAll("\\s", "");
        return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(maskedCardNumber);
    }


    public boolean assertCardDetails(String cardData, String expectedValue){
        String actualValue = driver.findElement(By.xpath(cardDetailsDiv+"//div[contains(text(), '"+cardData+"')]/following::td[1]")).getText().trim();
        return expectedValue.equalsIgnoreCase(actualValue);
    }

    public boolean assertCardBalanceDetails(String cardData, String expectedValue){
        String actualValue = driver.findElement(By.xpath(cardBalanceDetailsDiv+"//div[contains(text(), '"+cardData+"')]/following::td[1]")).getText().trim();
        return expectedValue.equalsIgnoreCase(actualValue);
    }

    public void enterNewCardNumber(String cardNumber){
        newCardNumberInputField.sendKeys(cardNumber);
    }

    public void enterNewCardURN(String urn){
        newCardURNInputField.sendKeys(urn);
    }


    public void enterNewCardlast4Digits(String cardNumber){
        newCardLast4digitInputField.sendKeys(Generic.getLast4DigitCardNumber(cardNumber));
    }


    public void enterNewCardDetails(String cardDetail, String cardNumber, String urn){
        switch (cardDetail){
            case "New Card Number":
                enterNewCardNumber(cardNumber);
                break;
            case "New URN":
                enterNewCardURN(urn);
                enterNewCardlast4Digits(Generic.getLast4DigitCardNumber(cardNumber));
                break;
        }
    }

    public void enterMakerComments(String oldCardDetail, String newCardDetail){
        makerCommentsInputField.sendKeys(oldCardDetail+" Replaced By "+newCardDetail);
    }

    public void submitReplaceRequest(){
        submitButton.click();
    }

    public boolean assertMessage(String expectedMessage){
        return messageDiv.getText().equalsIgnoreCase(expectedMessage);
    }

    public String fetchCardBalanceDetails(String cardBalanceDetail){
        return driver.findElement(By.xpath(cardBalanceDetailsDiv+"//div[contains(text(), '"+cardBalanceDetail+"')]//following::td[1]")).getText();
    }

    public int fetchCardBalanceValues(String cardBalanceDetail){
        return Integer.parseInt(driver.findElement(By.xpath(cardBalanceDetailsDiv+"//div[contains(text(), '"+cardBalanceDetail+"')]//following::input[1]")).getAttribute("value"));
    }



    public void enterCardDetailsInReplaceReqForm(String cardNumber,String last4Digits){
        HomePage homePage=new HomePage(driver);
        homePage.clickCardManagementLink();
        homePage.clickReplaceCardReq();
        cardNumberField.sendKeys(cardNumber);
        last4DigitsField.sendKeys(last4Digits);
        submitButton.click();
    }
    public void replaceCardReqForm(String cardNumber, String newCardNumber){
        String last4Digits= Generic.getLast4DigitCardNumber(cardNumber);
        enterCardDetailsInReplaceReqForm(cardNumber,last4Digits);
        Assert.assertEquals(cardDetails.getText().trim(),"Card Details");
        addressInputField.sendKeys("kenya");
        newCardNumberInputField.sendKeys(newCardNumber);
        makerCommentsInputField.sendKeys("Replacement Card request");
    }
    public Boolean performCardReplacementReq(){
        submitButton.click();
        try{
            return successMessage.isDisplayed();
        }
        catch(NoSuchElementException e){
            return false;
        }
    }
    public Boolean cancelCardReplacementReq(){
        cancelButton.click();
        try{
            return cardNumberField.isDisplayed();
        }
        catch(NoSuchElementException e){
            return false;
        }

    }
    //@Shankar Reddy
    //To verify the debit account number exists in Replace Card Request page
    public Boolean verifyDebitAccNumberValue(String debitAccNumber){

        String debitAccNumValue=debitAccNumberField.getText();
        if(debitAccNumValue.contains(debitAccNumber)){
            return true;
        }else{
            return false;
        }
    }
    //To verify the debit account number is non-editable in Replace Card Request page.
    public Boolean verifyDebitAccNumberField(){
        return(debitAccNumberField.isEnabled());
    }

    //To verify the Product image is displayed in the Replace Card Request page.
    public Boolean verifyProductImage() {
        try {
            return (productImage.isDisplayed());

        } catch (NoSuchElementException e) {
            return false;
        }
    }
}

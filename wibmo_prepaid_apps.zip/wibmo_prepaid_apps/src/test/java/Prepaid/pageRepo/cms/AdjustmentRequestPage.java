package Prepaid.pageRepo.cms;
import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AdjustmentRequestPage extends BasePage {
    private static WebDriver driver;
    public AdjustmentRequestPage(WebDriver driver){
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsLeftMenuFrame;

    @FindBy(xpath="//span[text()='Card Management']")
    public static WebElement cardManagement;

    @FindBy(xpath="//a[text()='Adjustment Request']")
    public static WebElement cardAdjustmentRequest;

    @FindBy(name="cmbProduct")
    private WebElement productDropDown;
    @FindBy(name="iccNumber")
    private WebElement cardNumber;
    @FindBy(id="urn")
    private WebElement urn;
    @FindBy(name="mode")
    private WebElement mode;
    @FindBy(name="type")
    private WebElement type;
    @FindBy(name="reason")
    private WebElement reason;
    @FindBy(name="amount")
    private WebElement amount;
    @FindBy(name="transactionId")
    private WebElement transactionId;
    @FindBy(name="makerComments")
    private WebElement makerComments;
    @FindBy(name="submit1")
    private WebElement submitBtn;
    @FindBy(xpath="//font[text()='Adjustment Request Successfully done']")
    WebElement successMessage;


    @FindBy(xpath= "//div[contains(text(),'Product')]")
    private WebElement productLabel;

    @FindBy(xpath= "//div[contains(text(),'Card Number')]")
    private WebElement cardNumberLabel;

    @FindBy(xpath= "//div[contains(text(),'Adjustment Amount')]")
    private WebElement adjustmentAmountLabel;

    @FindBy(xpath= "//div[contains(text(),'Type')]")
    private WebElement typeLabel;

    @FindBy(xpath= "//div[contains(text(),'Reason')]")
    private WebElement reasonLabel;

    @FindBy(name="comments")
    private WebElement comments;
    @FindBy(id="submit1")
    private WebElement submit;


    public void navigateToAdjustmentRequest(){
        navigateToPage(cardManagement, cardAdjustmentRequest);
    }


    public void performAdjustmentRequest(String cardNum, String productType, String transactionNum){
        HomePage homePage=new HomePage(driver);
        homePage.clickAdjustmentReqLink();
        Select selectProduct=new Select(productDropDown);
        selectProduct.selectByVisibleText(productType);
        cardNumber.sendKeys(cardNum);
        Generic.wait(02);
        Select selectMode=new Select(mode);
        selectMode.selectByVisibleText(" Amount");
        Select selectType=new Select(type);
        selectType.selectByVisibleText(" CR");
        //Generic.selectElementFromDropDown(reason, "Activation");
        Select selectReason=new Select(reason);
        selectReason.selectByValue("303001,Activation");
        Generic.wait(02);
        amount.sendKeys("100");
        Generic.wait(02);
        transactionId.sendKeys(transactionNum);
        makerComments.sendKeys("Adjustment Req");
        submitBtn.click();


    }

    public String getAdjustmentSxvuccessMessage(){
        return(successMessage.getText());
    }

    public void cardAdjustementRequest(String productName, String cardNumberORurn, String modeDetail, String transactionType, String reasonDetail, String transactionAmount, String transactionIdDetail){

//		if(Generic.bank.equalsIgnoreCase("")||Generic.bank.equalsIgnoreCase("")){
//			navigateToPage(cardManagementLink, cardAdjustment);
//		}else{
//			navigateToPage(cardManagementLink, cardAdjustmentRequest);
//		}
        //Selection of product
        Select selectProduct = new Select(productDropDown);
        selectProduct.selectByVisibleText(productName);
        //Entry of CardNumber or URN
        if(cardNumberORurn.length() >= 16){
            cardNumber.sendKeys(cardNumberORurn);
        }else{
            urn.sendKeys(cardNumberORurn);
        }
        //Selection of Mode
        Select selectMode = new Select(mode);
        selectMode.selectByVisibleText(" "+modeDetail);
        //Selection of Type
        Select selectType = new Select(type);
        selectType.selectByValue(transactionType);
        //Selection of Reason
        Select selectReason = new Select(reason);
        selectReason.selectByVisibleText(" "+reasonDetail);
        //Entry of amount
        amount.sendKeys(transactionAmount);
        //Entry of amount
        transactionId.sendKeys(transactionIdDetail);
        //clicking on Submit
        submitBtn.click();
    }

    public boolean validateAdjustCardRequest(String productName, String cardNumberORurn, String transactionAmount, String reasonDetail, String event){

        boolean validateProduct=false;
        boolean validateCardnumber=false;
        boolean validateTransactionAmount=false;
        boolean validateReason =false;
        boolean validateEvent=false;
        //Todo
//		boolean postAdjustmentBalance=false;
        String last4Digit;

        validateProduct = driver.findElement(By.xpath(productLabel+"//following::td[contains(text(), '"+productName+"')]")).isDisplayed();
        if(cardNumberORurn.length() == 16){
            last4Digit = Generic.getLast4DigitCardNumber(cardNumberORurn);
            validateCardnumber = driver.findElement(By.xpath(cardNumberLabel+"//following::td[contains(text(), '"+last4Digit+"')]")).isDisplayed();
        }
        //Todo
//		driver.findElement(By.xpath(availableBalanceLabel+"//following::td[1]")).getText().replace("(INR)", "");
        validateTransactionAmount = driver.findElement(By.xpath(adjustmentAmountLabel+"//following::td[contains(text(), '"+transactionAmount+"')]")).isDisplayed();
        validateReason = driver.findElement(By.xpath(reasonLabel+"//following::td[contains(text(), '"+reasonDetail+"')]")).isDisplayed();
        validateEvent = driver.findElement(By.xpath(typeLabel+"//following::td[contains(text(), '"+event+"')]")).isDisplayed();
        return 	(validateProduct==validateCardnumber==validateTransactionAmount==validateReason==validateEvent);
    }

    public void submitCardAdjustment(String adjustementComments){

        comments.sendKeys(adjustementComments+" Approved");
        submit.click();
    }
}

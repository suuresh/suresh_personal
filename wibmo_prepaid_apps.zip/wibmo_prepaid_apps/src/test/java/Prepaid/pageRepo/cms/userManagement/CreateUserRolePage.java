package Prepaid.pageRepo.cms.userManagement;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class CreateUserRolePage extends BasePage {
    private WebDriver driver;

    public CreateUserRolePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
    }
    @FindBy(xpath = "//span[text()='User Management']")
    private WebElement userManagement;
    @FindBy(xpath = "//a[text()='Create User Roles']")
    private WebElement createUserRoleLink;
    @FindBy(xpath = "//h3[text()='Create User Roles']")
    private WebElement createUserRolePage;
    @FindBy(xpath="//input[@name='name']")
    private WebElement roleNameFiled;
    @FindBy(xpath = "//select[@id='parentRoleId']")
    private WebElement parentRoleDropDown;
    @FindBy(xpath = "//input[@value='PREPAID,']")
    private WebElement prepaidCheckBox;
    @FindBy(xpath = "//input[@value='Card Management,']")
    private WebElement cardManagementCheckBox;
    @FindBy(xpath = "//input[@value='Activate Request,']")
    private WebElement activationRequestCheckBox;
    @FindBy(xpath = "//input[@value='Activate Card,']")
    private WebElement activateCardCheckBox;
    @FindBy(xpath = "//input[@value='Cancel Request,']")
    private WebElement cancelRequestCheckBox;
    @FindBy(xpath = "//input[@value='Cancel Card,']")
    private WebElement cancelCardCheckBox;
    @FindBy(xpath = "//input[@value='Card Inquiry,']")
    private WebElement cardInquiryCheckBox;
    @FindBy(xpath = "//input[@name='submit']")
    private WebElement saveButton;

    @FindBy(xpath = "//strong[contains(text(),'User Role created successfully.')]")
    private WebElement createRoleSuccessMessage;

    public Boolean ClickCreateUserRoleLink() {
        navigateToPage(userManagement,createUserRoleLink);
        try {
            createUserRolePage.isDisplayed();
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void enterRoleName(String roleName) {
        roleNameFiled.click();
        roleNameFiled.sendKeys(roleName);
    }

    public void selectParentRole(String roleName) {
        Select selectRole = new Select(parentRoleDropDown);
        selectRole.selectByVisibleText(roleName.trim());
    }

    public void selectCheckBoxPrepaid() {
        prepaidCheckBox.click();
    }

    public void selectCheckBoxCardManagement() {
        cardManagementCheckBox.click();
    }

    public void selectCheckBoxActivationReq() {
        activationRequestCheckBox.click();
    }

    public void selectCheckBoxActivateCard() {
        activateCardCheckBox.click();
    }

    public void selectCheckBoxCancelCardReq() {
        cancelRequestCheckBox.click();
    }

    public void selectCheckBoxCancelCard() {
        cancelCardCheckBox.click();
    }

    public void selectCardCheckBoxCardInquiry() {
        cardInquiryCheckBox.click();
    }

    public void clickSaveButton() {
        saveButton.click();
    }

    public void enterRoleDetails(String roleName, String parentRoleName) {
        enterRoleName(roleName);
        selectParentRole(parentRoleName);
        selectCheckBoxPrepaid();
        selectCheckBoxCardManagement();
        selectCheckBoxActivationReq();
        selectCheckBoxActivateCard();
        selectCheckBoxCancelCardReq();
        selectCheckBoxCancelCard();
        selectCardCheckBoxCardInquiry();
    }

    public Boolean submitRoleDetails(String roleName, String parentRoleName) {
        enterRoleDetails(roleName, parentRoleName);
        clickSaveButton();
        try {
            driver.switchTo().alert().accept();
        } catch (Exception e) {

        }
        try {
            return (createRoleSuccessMessage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}

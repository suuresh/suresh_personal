package Prepaid.pageRepo.cms.branchManagement;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class ModifyBranchAgencyPage extends BasePage
{
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    WebDriver driver;
    public ModifyBranchAgencyPage(WebDriver driver)
    {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    //declarations of all the webelements on this page

    @FindBy(xpath="//span[text()='Manage Branch/Agency ']")
    private WebElement branchManagement;

    @FindBy(xpath="//a[text()='Modify Branch/Agency']")
    private WebElement modifyBranchLink;

    @FindBy(xpath="//input[@name='entityName']")
    private WebElement entityName;

    @FindBy(xpath="//input[@value='Submit']")
    private WebElement submitDetails;

    @FindBy(xpath="//textarea[@name='address1']")
    private WebElement branchAddressField;

    @FindBy(xpath="//input[@name='phone1']")
    private WebElement phoneDetails;

    @FindBy(xpath="//input[@name='mobile']")
    private WebElement mobileDetails;

    @FindBy(xpath = "//input[@name='email']")
    private WebElement emailAdress;

    @FindBy(xpath="//input[@name='city']")
    private WebElement cityDetails;

    @FindBy(xpath="//input[@name='state']")
    private WebElement stateDetails;

    @FindBy(xpath="//input[@name='country']")
    private WebElement countryDetails;

    @FindBy(xpath = "//textarea[@name='comments']")
    private WebElement userComments;

    @FindBy(xpath = "//input[@value='Update']")
    private WebElement updateButton;

    @FindBy(xpath="//strong[text()='Branch/Agency has been successfully Updated. Find below the summary.']")
    private WebElement successMessage;

    @FindBy(xpath="//*[text()='No Such Entity/Branch Name Present.']")
    private WebElement erroMessageOnNoEntity;

    //utilization of all the webelements

    //entering of branch detils in first screen

    public void navigateToModifyBranch(){
        navigateToPage(branchManagement, modifyBranchLink);
    }

    public void enterBranchName(String branchName){entityName.sendKeys(branchName);}

    public void submitBranch(){submitDetails.click();}


    public void submitBranchDetails(String branchName)
    {
        enterBranchName(branchName);
        submitBranch();
    }

    // entering of modification details in next page

    public void enterAddress()
    {
        branchAddressField.clear();
        branchAddressField.sendKeys("vijayanagar blore");
    }

    public  void enterPhoneNumber(String phoneNumber)
    {
        phoneDetails.clear();
        phoneDetails.sendKeys(phoneNumber);
    }

    public void enterMobileDetails(String mobileNumber)
    {
        mobileDetails.clear();
        mobileDetails.sendKeys(mobileNumber);
    }

    public void enterEmailDetails(String emailID)
    {
        emailAdress.clear();
        emailAdress.sendKeys(emailID);
    }

    public void enterCityDetails(String city)
    {
       cityDetails.clear();
       cityDetails.sendKeys(city);
    }

    public void enterStateDetails(String state)
    {
        stateDetails.clear();
        stateDetails.sendKeys(state);
    }

    public void enterCountryDetals(String country)
    {
        countryDetails.clear();
        countryDetails.sendKeys(country);
    }

    public void enterUserComments(){userComments.sendKeys("Branch details are updated by automation");}

    public void enterUpdateBranchDetails(String phoneNumber,String mobileNumber,String emailID,String city,String state,String country)
    {
        enterAddress();
        enterPhoneNumber(phoneNumber);
        enterMobileDetails(mobileNumber);
        enterEmailDetails(emailID);
        enterCityDetails(city);
        enterStateDetails(state);
        enterCountryDetals(country);
        enterUserComments();
    }

    public void submitUpdateBranchDetails(String phoneNumber,String mobileNumber,String emailID,String city,String state,String country)
    {
        enterUpdateBranchDetails(phoneNumber,mobileNumber,emailID,city,state,country);
        updateButton.click();
    }

    public void assertModifyBranchSuccess(String expectedMessage){
        successMessage.getText().equalsIgnoreCase(expectedMessage);
    }

    public void assertNoBranchEntity(String expectedMessage)
    {
        erroMessageOnNoEntity.getText().equalsIgnoreCase(expectedMessage);
    }

    // method decides which bank to execute
    public void bank_ModifyBranch(String bankName,String branchName,String phoneNumber,String mobileNumber,String emailID,String city,String state,String country)
    {


        switch(bankName)
        {
            case "bobk":
                navigateToModifyBranch();
                submitBranchDetails(branchName);
                submitUpdateBranchDetails(phoneNumber,mobileNumber,emailID,city,state,country);
                Generic.checkAlert(driver);
                break;

            default:
                System.out.println(bankName+ ":-  entered is not present in the prepaid system");



        }

    }



}

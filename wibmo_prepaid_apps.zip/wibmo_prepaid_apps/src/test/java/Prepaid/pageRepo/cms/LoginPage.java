package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage
{
	/**	
	 *  Declaration of all the web elements
	 *  
	 */
	
	@FindBy(xpath="//input[@name='txtUserId']")
	private WebElement userName;
	
	@FindBy(xpath="//input[@name='txtPassword']")
	private WebElement userPassword;
	
	@FindBy(xpath="//input[@name='submit']")
	private WebElement singInButton;

	@FindBy(xpath = "//a[contains(text(),'Sign Out')]")
	private WebElement signoutLink;
	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public LoginPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}


	public void cmsLogin(String name,String pwd)
	{
		userName.sendKeys(name);
		userPassword.sendKeys(pwd);
		singInButton.click();
		
	}


	public void cmsLogout()
	{
		signoutLink.click();
		Generic.wait(3);
	}
	
}

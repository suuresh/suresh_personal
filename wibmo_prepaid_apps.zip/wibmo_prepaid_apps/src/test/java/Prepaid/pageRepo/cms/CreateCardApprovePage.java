package Prepaid.pageRepo.cms;

import static org.testng.Assert.assertEquals;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateCardApprovePage extends BasePage {

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public CreateCardApprovePage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	//cms Menu Section
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagement;

	@FindBy(xpath="//a[text()='Create Card Approve']")
	public static WebElement cardCreateApprove;

	/**
	 *  Declaration of all the web elements of Create Card Approve Request.
	 */
	
	//Create Card Approval - View Card Requests Page

	@FindBy(xpath="//b[contains(text(),'Batch Id :')]/following::td[1]")
	private WebElement approvalBatchID;
	@FindBy(xpath="//div[contains(text(),'Product Name')]/following::td[1]")
	private WebElement selectedProductName;
	@FindBy(xpath = "//div[contains(text(),'No. of cards :')]/following::td[1]")
	private WebElement approvalNoOfCards;
	@FindBy(xpath = "//div[contains(text(),'Card Perso Vendor :')]/following::td[1]")
	private WebElement approvalPersoVendor;
	@FindBy(xpath = "//div[contains(text(),'Perso Template')]/following::td[1]")
	private WebElement approvalPersoTemplate;
	@FindBy(xpath = "//form[@name='approveCardCreation']//*[starts-with(text(), 'Template')]//following::div[1]")
	private WebElement approvalSelectedTemplate;
	@FindBy(id="checkerComments")
	private WebElement checkerComments;
	@FindBy(name="approve")
	private WebElement approveButton;
	@FindBy(name="reject")
	private WebElement rejectButton;


	//Create Card Approval - Success Page
	@FindBy(xpath="//form[@name='approveCardCreation']//table[1]/tbody/tr[2]//font")
	private WebElement CardApprovalSuccessMessage;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Batch Id')]")
	private WebElement approvedBatchId;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Product Name')]")
	private WebElement approvedProductName;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Card Creation mode')]")
	private WebElement approvedCreationMode;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Third line printing')]")
	private WebElement approvedThirdLine;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Fourth line printing')]")
	private WebElement approvedFourthLine;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Card Perso Vendor')]")
	private WebElement approvedPersoVendor;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[contains(text(),'Perso Template')]")
	private WebElement approvedPersoTemplate;
	@FindBy(xpath="//form[@name='approveCardCreation']//*[starts-with(text(),'Template')]")
	private WebElement approvedTemplate;

	/**
	 * 
	 * This method is used to Approve Card Requests
	 * @param BatchID
	 * @param CheckerAction
	 * @return Result
	 */
		
	public String createCardsApproveFromCMS(String BatchID, String CheckerAction, String ProductName, String NumberofCards)
	{
		//CreateCardRequestPage createCardCrequestPage = new CreateCardRequestPage(driver);
		switchToFrame(cmsLeftMenuFrame);
		cardManagement.click();
		Generic.waitForElement(driver, cardCreateApprove, 5);
		cardCreateApprove.click();
		driver.switchTo().defaultContent();
		
		String pathofBatchID= "//a[text()='"+BatchID+"']";
		driver.findElement(By.xpath(pathofBatchID)).click();
		assertEquals(approvalBatchID.getText(), BatchID);
		assertEquals(selectedProductName.getText(),ProductName); 
		assertEquals(approvalNoOfCards.getText(),NumberofCards);
		checkerComments.sendKeys("Approving the "+BatchID+" batchid");
		if(CheckerAction=="Approve")
		{
			approveButton.click();
		}else
		{
			rejectButton.click();
		}
		if(CardApprovalSuccessMessage.isDisplayed())
		{
			return CardApprovalSuccessMessage.getText();
		}
		else
		{
			return "Oops cards are not succesfully created";
		}				
	}	
}

package Prepaid.pageRepo.cms.profileManagement;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class ChangePasswordPage extends BasePage
{
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */

    WebDriver driver;
    public ChangePasswordPage(WebDriver driver)
    {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    //webelements of the page
    @FindBy(xpath="//span[text()='Profile ']")
    private WebElement profileLink;

    @FindBy(xpath="//a[text()='Change Password']")
    private WebElement changePasswordLink;

    //web element to identify next page is displayed
    @FindBy(xpath="//h3[text()='Change Password']")
    private WebElement nextPage;

    //webelements on chagne password page
    @FindBy(xpath="//input[@name='txtOldPassword']")
    private WebElement oldPassword;

    @FindBy(xpath="//input[@name='txtNewPassword']")
    private WebElement newPassword;

    @FindBy(xpath="//input[@name='txtConfirmNewPassword']")
    private WebElement confirmNewPassword;

    @FindBy(xpath="//input[@value='Save']")
    private WebElement saveButton;

    @FindBy(xpath="////b[text()='Password Changed Successfully.']")
    private WebElement successMessage;

    //utilitzation of webelements

    public void navigateToChangePassword()
    {
        navigateToPage(profileLink,changePasswordLink);
    }

    public void enterOldPassword(String oPassword){oldPassword.sendKeys(oPassword);}

    public void enterNewPassword(String nPassword){newPassword.sendKeys(nPassword);}

    public void enterConfirmPassword(String confirmPassword){confirmNewPassword.sendKeys(confirmPassword);}

    public void enterPasswordDetails(String oPassword,String nPassword,String confirmPassword)
    {
        enterOldPassword(oPassword);
        enterNewPassword(nPassword);
        enterConfirmPassword(confirmPassword);
    }

    public void submitDetails(String oPassword,String nPassword,String confirmPassword)
    {
        enterPasswordDetails(oPassword,nPassword,confirmPassword);
        Generic.wait(3);
        saveButton.click();
    }

    public boolean assertSuccessMesage()
    {
        return successMessage.isDisplayed();
    }



}

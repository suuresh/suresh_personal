package Prepaid.pageRepo.cms;
//@author Srikiran
import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class CancellationRequestPage extends BasePage

{
	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public CancellationRequestPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 * 	Declaration of all the web elements for Re-charge request details
	 */

	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagement;

	@FindBy(xpath="//a[text()='Recharge Request']")
	public static WebElement rechargeRequest;

	@FindBy(xpath="//div[contains(text(), 'Product')]/following::select")
	private WebElement productList;
	@FindBy(name="iccNumber")
	private WebElement cardNumber;
	@FindBy(name="submit")
	private WebElement submit;
	
	@FindBy(name="submit")
	private WebElement cancelCard;
	
	@FindBy(id="paymentDetails")
	private WebElement payDetails;
	@FindBy(xpath="//h3[text()='Recharge Request - Success']")
	private WebElement succesMessage;
	
	@FindBy(xpath="//div[contains(text(),'Card Number')]")
	private WebElement MaskedCardNumber;
	@FindBy(xpath="//div[contains(text(),'Reason')]/following::select")
	private WebElement CancellationReason;
	
	public void cancelRequestCardSearch(String Product, String CardNumber)
	{
		Select productSelection = new Select(productList);
		productSelection.selectByVisibleText(Product);
		cardNumber.sendKeys(CardNumber);
		submit.click();
	}
	
	public void cancellationRequest(String CardNumber, String Reason)
	{
		String Card4Digi = Generic.getLast4DigitCardNumber(CardNumber);
		MaskedCardNumber.getText().contains(Card4Digi);
		Select reason = new Select(CancellationReason);
		reason.selectByVisibleText(Reason);
		cancelCard.click();
	}	
}
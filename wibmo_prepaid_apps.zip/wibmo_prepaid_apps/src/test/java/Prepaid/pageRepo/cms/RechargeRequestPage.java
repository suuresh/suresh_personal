package Prepaid.pageRepo.cms;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class RechargeRequestPage extends BasePage{

	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public RechargeRequestPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 *  Declaration of all the web elements of Card Inquiry Request.
	 */
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//a[text()='Recharge Request']")
	public static WebElement rechargeRequestLink;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagementLink;

	/**
	 * 	Declaration of all the web elements for Re-charge request details
	 */
	//View Recharge Request Grid Card Number raw xpath - //u[contains(text(), '')]

	@FindBy(name="cmbProduct")
	private WebElement productListDropdown;

	@FindBy(name="iccNumber")
	private WebElement cardNumberTextField;

	@FindBy(name="amount")
	private WebElement amountTextField;

	@FindBy(xpath = "//button[contains(text(), 'Submit')]")
	private WebElement submitButton;

	@FindBy(id="paymentMode")
	private WebElement paymentModeDropdown;

	@FindBy(id="paymentDetails")
	private WebElement paymentDeatilsTextarea;

	@FindBy(id="makerComments")
	private WebElement makerCommentsTextarea;


	@FindBy(xpath="//h3[text()='Recharge Request - Success']")
	private WebElement succesMessage;
	
	@FindBy(name="journalNum")
	private WebElement jrNumber;

	@FindBy(id="errorMsg")
	private WebElement messageContentDiv;

	@FindBy(xpath ="//*[@id='submitDetails']")
	private WebElement rechargeSubmitButton;

	@FindBy(xpath="//span[text()='Amount entered is lesser than the Minimum Recharge Amount.']")
	private WebElement minumumCardLimitMessage;

	@FindBy(xpath="//span[text()='Amount entered is more than the Maximum Recharge Amount.']")
	private WebElement maximumCardLimitMessage;

	@FindBy(xpath="//span[text()='Card does not belong to the product choosen, please try again.']")
	private WebElement invalidProductMessage;

	@FindBy(xpath="//span[text()='Card is not in Active state']")
	private WebElement nonActiveCard;


	public void navigatetoRechargeRequest(){
		navigateToPage(cardManagementLink, rechargeRequestLink);
	}

	public void selectProduct(String product){
		//select the product from the product list
		Select selProduct=new Select(productListDropdown);
		selProduct.selectByVisibleText(product);
	}

	public void enterCardActivationAmount(String amount){
		amountTextField.sendKeys(amount);
	}

	public void enterCardLast4digits(String cardNumber) {
		cardNumberTextField.sendKeys(cardNumber);
	}

	public void submitCardRecharge(){
		submitButton.click();
	}

	public void enterCardRechargeDetails(String product, String cardNumber, String amount){
		selectProduct(product);
		enterCardActivationAmount(amount);
		enterCardLast4digits(cardNumber);
	}

	public void submitCardRechargeDetails(String product, String cardNumber, String amount){
		enterCardRechargeDetails(product, cardNumber, amount);
		submitCardRecharge();
		Generic.wait(5);
	}

	public void selectPaymentMode(String paymentMode){
		Select mode = new Select(paymentModeDropdown);
		mode.selectByVisibleText(paymentMode);
	}

	public void enterPaymentDetails(String paymentDetails){
		paymentDeatilsTextarea.sendKeys(paymentDetails);
	}

	public void enterMakerComments(String makerComments){
		makerCommentsTextarea.sendKeys(makerComments);
	}

	public void enterRechargeDetails(String paymentMode, String paymentDetails, String makerComments){
		selectPaymentMode(paymentMode);
		enterPaymentDetails(paymentDetails);
		enterMakerComments(makerComments);
	}

	public void submitRechargeDetails(String product, String cardNumber, String amount, String paymentMode, String paymentDetails, String makerComments){
		submitCardRechargeDetails(product, cardNumber, amount);
		enterRechargeDetails(paymentMode, paymentDetails, makerComments);
		rechargeSubmitButton.click();
		Generic.wait(5);
		//System.out.println("Recharge request is successfully submitted");
	}

	public boolean verifyPaymentMode(String mode){
		boolean flag = false;
		Select paymentMode = new Select(paymentModeDropdown);
		List<WebElement> options = paymentMode.getOptions();
		for (WebElement e : options) {
			flag = e.getText().equalsIgnoreCase(mode);
		}
		return flag;
	}

	public boolean assertRechargeRequestSuccessful(String expectedMessage){
		return messageContentDiv.getText().equalsIgnoreCase(expectedMessage);
	}

	public boolean assertMinumumRechargeMessage()
	{
		return minumumCardLimitMessage.isDisplayed();
	}

	public boolean assertMaximumRechargeMessage()
	{
		return maximumCardLimitMessage.isDisplayed();
	}

	public boolean assertInvalidProductSelection(String expectedMessage)
	{
		return invalidProductMessage.getText().equalsIgnoreCase(expectedMessage);
	}

	public boolean assertNonActiveCardStatus(String expectedMessage)
	{
		return nonActiveCard.getText().equalsIgnoreCase(expectedMessage);
	}
}
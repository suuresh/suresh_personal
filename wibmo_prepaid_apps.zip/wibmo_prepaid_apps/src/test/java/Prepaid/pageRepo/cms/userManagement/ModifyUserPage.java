package Prepaid.pageRepo.cms.userManagement;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

/**
 * @author Shankar Reddy on Jun,2021
 */
public class ModifyUserPage extends BasePage {
    private WebDriver driver;

    public ModifyUserPage(WebDriver driver) {
        super(driver);
        this.driver = driver;

    }

    @FindBy(xpath = "//span[text()='User Management']")
    private WebElement userManagementLink;
    @FindBy(xpath = "//a[text()='Modify Users']")
    private WebElement modifyUserLink;
    @FindBy(xpath = "//input[@value='Choose Branch/Agency']")
    private WebElement chooseBranchBtn;
    @FindBy(xpath = "//a[text()='bdo']")
    private WebElement branchName;
    @FindBy(xpath = "//input[@value='submit']")
    private WebElement submitBtn;
    @FindBy(xpath = "//input[@type='submit']")
    private WebElement submitFormBtn;
    @FindBy(xpath = "//td[text()='Modify Users']")
    private WebElement modifyUsersPage;
    @FindBy(xpath = "//input[@name='mobile']")
    private WebElement mobileInputField;
    @FindBy(xpath = "//input[@name='email']")
    private WebElement emailInputField;
    @FindBy(xpath = "//input[@name='Save']")
    private WebElement saveBtn;
    @FindBy(xpath = "//font[text()='Successfully updated the user details']")
    private WebElement modifyUserSuccessMsg;


    public void selectBranch() {
        navigateToPage(userManagementLink, modifyUserLink);
        chooseBranchBtn.click();
        branchName.click();
        Generic.wait(2);
        submitBtn.click();

    }

    public Boolean submitBranch() {
         submitFormBtn.click();
        try {
            return (modifyUsersPage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }

    }

    public Boolean selectUser(String userName) {
        Generic.wait(5);
        String userNameLink = "//u[text()='" + userName + "']";
        driver.findElement(By.xpath(userNameLink)).click();
        try {
            return (modifyUsersPage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void modifyMobileNum(String mobileNum) {
        mobileInputField.clear();
        mobileInputField.sendKeys(mobileNum);
    }

    public void modifyEmailID(String emailID) {
        emailInputField.clear();
        emailInputField.sendKeys(emailID);
    }

    public void clickSaveButton() {
        saveBtn.click();
        try {
            driver.switchTo().alert().accept();
        } catch (NoAlertPresentException e) {

        }
    }

    public Boolean verifySuccessMessage() {
        try {
            return (modifyUserSuccessMsg.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public void modifyUser(String mobile, String email) {
        modifyMobileNum(mobile);
        modifyEmailID(email);
        clickSaveButton();
    }

}

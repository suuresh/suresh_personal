package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class ModfiyActivationReqPage extends BasePage {
    private WebDriver driver;


    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public ModfiyActivationReqPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }


    //cms Menu Section
    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsLeftMenuFrame;

    @FindBy(xpath="//span[text()='Card Management']")
    public static WebElement cardManagementLink;

    @FindBy(xpath="//a[text()='Modify Activation Request']")
    public static WebElement modifyActivationRequestLink;


    @FindBy(xpath="//td[text()='Card Details']")
    private WebElement modifyReqCardDetails;
    @FindBy(xpath="//div[@align='right']//img[contains(@src,'bob')]")
    private WebElement productImage;
    @FindBy(id="debitAccountNumber")
    private WebElement debitAccountNumberTextfield;
    @FindBy(name="paymentDetails")
    private WebElement paymentDetails;
    @FindBy(name="makerComments")
    private WebElement makerComments;
    @FindBy(name="submit")
    private WebElement submitBtn;
    @FindBy(xpath="//font[text()='Modification Done Successfully']")
    private WebElement modifyRequestSuccessMsg;

    @FindBy(id="paymentMode")
    private WebElement paymentModeDropdown;
    @FindBy(id="accountNum")
    private WebElement paymentDetailsTextbox;
    @FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']")
    private WebElement rejectedActivationRequestList;

    @FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']")
    public WebElement rejectedActivationRequestDetailsDiv;




    public void navigateToModifyActivationRequest(){
        navigateToPage(cardManagementLink, modifyActivationRequestLink);
    }


    public WebElement searchRejectedCardRequests(String urn){
        return driver.findElement(By.xpath(rejectedActivationRequestList+"//td/center[contains(text(), '"+urn+"')]"));
    }

    public boolean viewRejectedCardRequest(String urn, String cardNumber){
        WebElement urnLocator = searchRejectedCardRequests(urn);
        return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(driver.findElement(By.xpath(urnLocator+"//following::a")).getText().trim().replaceAll("\\s", ""));
    }

    public void selectRejectedCardRequest(String urn){
        WebElement urnLocator = searchRejectedCardRequests(urn);
        driver.findElement(By.xpath(urnLocator+"//following::a")).click();
    }

    public boolean assertCardNumber(String cardNumber){
        String maskedCardNumber = driver.findElement(By.xpath(rejectedActivationRequestList+"//div[contains(text(), 'Card Number :')]/following::td")).getText().replaceAll("\\s", "");
        return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(maskedCardNumber);
    }

//    public boolean assertModifyCardRequest(){
//        return successMessage.isDisplayed() && successMessage.getText().equalsIgnoreCase("Activate Card - Success")
//                && driver.findElement(By.xpath(successMessage+"/following::strong[contains(text(),'Card Activation has been accepted, your card would be activated within 24 hours. Please find your activation')]")).isDisplayed();
//    }

    public void modifyActivationDetails(String detail, String updatedValue){

        switch(detail){
            case"Payment Mode":
                Select paymentMode = new Select(paymentModeDropdown);
                paymentMode.selectByVisibleText(updatedValue);
                paymentDetailsTextbox.sendKeys(Generic.getIdentityNumber());
                break;
            case"Debit Account Number":
                debitAccountNumberTextfield.sendKeys(updatedValue);
                break;
        }
        makerComments.sendKeys("Modified by Maker");
        submitBtn.click();
        try{
            Alert alert=driver.switchTo().alert();
            alert.accept();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        Generic.wait(02);
    }

    public boolean assertModifyRequestSaved(){
        return modifyRequestSuccessMsg.getText().equalsIgnoreCase("Modification Done Successfully");
    }

    public boolean verifyPaymentMode(String mode){
        boolean flag = false;
        Select paymentMode = new Select(paymentModeDropdown);
        List<WebElement> options = paymentMode.getOptions();
        for (WebElement e : options) {
            flag = e.getText().equalsIgnoreCase(mode);
        }
        return flag;
    }

    public boolean verifyRequestDetails(String requestDetail, String expectedData){
        return expectedData.equalsIgnoreCase(driver.findElement(By.xpath(rejectedActivationRequestDetailsDiv+"//td//div[contains(text(), '"+requestDetail+"')]//following::td[1]")).getText());
    }

    public void modifyActivationRequest(String last4Digits){

        HomePage homePage=new HomePage(driver);
        homePage.clickModifyActivationRequest();
        driver.findElement(By.xpath("//u[contains(.,'"+last4Digits+"')]")).click();
        Generic.wait(02);
        Assert.assertEquals("Card Details",modifyReqCardDetails.getText());
        Assert.assertTrue(productImage.isDisplayed());
        System.out.println("The Product image is successfully displayed in Modify Activation Request page");
        paymentDetails.sendKeys("1234");
        makerComments.sendKeys("Modified by Maker");
        submitBtn.click();
        try{
            Alert alert=driver.switchTo().alert();
            alert.accept();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        Generic.wait(02);

        Assert.assertEquals(modifyRequestSuccessMsg.getText(),"Modification Done Successfully");
        System.out.println("Modify Activation Request is Successfull.");
    }


}

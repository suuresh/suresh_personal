package Prepaid.pageRepo.cms.customerManagement;

import Prepaid.pageRepo.BasePage;
import Prepaid.testScripts.BaseTest1;
import library.Generic;
import library.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Sanmati Vardhaman on Jun,2021
 */
public class UpdateCustomerProfilePage extends BasePage
{
    WebDriver driver;
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public UpdateCustomerProfilePage(WebDriver driver)
    {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(driver,this);

    }

    //webelements of CustomerUpdate profile page

    @FindBy(xpath="//span[text()='Customer Management']")
    private WebElement customerManagement;

    @FindBy(xpath="//a[text()='Update Customer Profile']")
    private WebElement updateCustomerProfileLink;

    @FindBy(xpath="//input[@name='iccNumber']")
    private WebElement cardNumberField;

    @FindBy(xpath="//input[@name='submit']")
    private WebElement  submitButton;



    @FindBy(xpath="//*[text()='Card Number did not match, please try again.']") // card number not active webelement
    private WebElement cardNotMatchingMessage;

    // next form webelements

    @FindBy(xpath = "//strong[contains(text(),'Edit')]")
    private WebElement nextPageNavigation;

    @FindBy(xpath="//input[@name='firstName']")
    private WebElement firstName;

    @FindBy(xpath="//input[@name='lastName']")
    private WebElement lastName;

    @FindBy(xpath="//input[@name='mobile']")
    private WebElement mobileNumber;

    @FindBy(xpath="//input[@name='email']")
    private WebElement emailID;

    @FindBy(xpath="//input[@name='dob']")
    private WebElement dateOfBirth;

    @FindBy(xpath="//input[@name='debitAccountNumber']")
    private WebElement debitAccountNumber;

    @FindBy(xpath="//textarea[@name='address']")
    private WebElement addressField;

    @FindBy(xpath="//input[@value='Update']")
    private WebElement updateButton;

    @FindBy(xpath="//*[text()='Profile successfully updated.']")
    private  WebElement successMessage;


    //utilization of webelements

    public void navigateToCustomerUpdateProfile()
    {
        navigateToPage(customerManagement,updateCustomerProfileLink);
    }

    public void enterCardNumber(String cardNumber)
    {
        cardNumberField.clear();
        cardNumberField.sendKeys(cardNumber);
    }

    public void submitCardDetails(String cardNumber)
    {
        enterCardNumber(cardNumber);
        submitButton.click();
        Log.info("Error message displayed is "+cardNotMatchingMessage.getText());
    }

    public boolean assertCardNumberNotActive(){return cardNotMatchingMessage.isDisplayed();}

    public boolean assertNextPageNavigation(){return nextPageNavigation.isDisplayed();}


    // user details method

    public void enterFirstName(String userFirstName)
    {
        firstName.clear();
        firstName.sendKeys(userFirstName);
    }


    public void enterLastName(String userLastName)
    {
        lastName.clear();
        lastName.sendKeys(userLastName);
    }

    public void enterMobileNumber(String userMobileNumber)
    {
        mobileNumber.clear();
        mobileNumber.sendKeys(userMobileNumber);
    }


    public void enterEmailID(String userEmailID)
    {
        emailID.clear();
        emailID.sendKeys(userEmailID);
    }

    public void enterDOB(String userDOB)
    {
        dateOfBirth.clear();
        dateOfBirth.sendKeys(userDOB);
    }


    public void enterDebitAccountNumber(String debitAccNumber)
    {
        debitAccountNumber.clear();
        debitAccountNumber.sendKeys(debitAccNumber);
    }

    public void enterUserAddress(String userAddress)
    {
        addressField.clear();
        addressField.sendKeys(userAddress);
    }

    public void enterUserDetails(String userFirstName,String userLastName,String userMobile,String userEmail,String userDOB,String userDebitAccNumber,String userAddress)
    {
        enterFirstName(userFirstName);
        enterLastName(userLastName);
        enterMobileNumber(userMobile);
        enterEmailID(userEmail);
        enterDOB(userDOB);
        enterDebitAccountNumber(userDebitAccNumber);
        enterUserAddress(userAddress);
    }

    public void submitUserDetails(String userFirstName,String userLastName,String userMobile,String userEmail,String userDOB,String userDebitAccNumber,String userAddress)
    {
        enterUserDetails(userFirstName,userLastName,userMobile,userEmail,userDOB,userDebitAccNumber,userAddress);
        updateButton.click();

    }

    public boolean assertSuccesspage(){return successMessage.isDisplayed();}

    public void bank_UpdateCustomerProfile(String bankName,String cardNumber,String userFirstName,String userLastName,String userMobile,
                                           String userEmail,String userDOB,String userDebitAccNumber,String userAddress)
    {


        switch(bankName)
        {
            case "bobk":
                navigateToCustomerUpdateProfile();
                submitCardDetails(cardNumber);
                submitUserDetails(userFirstName,userLastName,userMobile,userEmail,userDOB,userDebitAccNumber,userAddress);
               // Generic.checkAlert(driver);
                //assertModifyFeesSuccess(expectedMessage);
                break;

            default:
                System.out.println(bankName+ ":-  entered is not present in the prepaid system");



        }

    }






}

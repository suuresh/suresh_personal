package Prepaid.pageRepo.cms.branchManagement;


import com.sun.tracing.dtrace.FunctionName;
import library.Generic;
import Prepaid.pageRepo.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static library.Generic.scrollToWebElement;

/**
 * @author Sanmati Vardhaman on May,2021
 */
public class CreateBranchAgencyPage extends Prepaid.pageRepo.BasePage
{
    WebDriver driver;


    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public CreateBranchAgencyPage(WebDriver driver)
    {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(xpath="//iframe[@class='iframe']")
    private WebElement cmsFrame;

    @FindBy(xpath="//input[@value='Collapse']")
    private WebElement collapseLink;

    @FindBy(xpath="//span[text()='Manage Branch/Agency ']")
    private WebElement branchManagement;

    @FindBy(xpath="//a[text()='Create Branch/Agency']")
    private WebElement createBranchLink;

    // ** elements of product selection
    @FindBy(xpath="//select[@name='productListed']")
    private WebElement productListSelection;


    @FindBy(xpath="//input[@value='Add >>']")
    private WebElement addProducts;

    @FindBy(xpath="//input[@value='<< Remove']")
    private WebElement removeProducts;

    @FindBy(xpath="//input[@value='Submit']")
    private WebElement submitButton;

    // **** elements of branch creation Form
    @FindBy(xpath="//h3[text()='Create Branch/Agency']")
    private WebElement createBranchPage;

    @FindBy(xpath="//input[@value='Choose Parent Branch/Agency']")
    private WebElement chooseParentBranchLink;

    @FindBy(id="popupWindow")
    private WebElement brachSelectionWindow;

    //@FindBy(xpath="//a[@onclick='getId('100|bdo')']")
    //@FindBy(linkText = "javascript: d.o(0);")
    @FindBy(xpath ="//a[text()='bdo']")
    private WebElement mainBranchSelection;

    @FindBy(linkText = "expand all")
    private WebElement expandAllLink;

    @FindBy(linkText = "collapse all")
    private  WebElement collapeLink;

    @FindBy(xpath="//input[@value='submit']")
    private WebElement branchSubmit;

    @FindBy(xpath = "//input[@value='close']")
    private WebElement branchClose;

    @FindBy(id="parentIdspan")
    private WebElement parentBranchSelected;

    @FindBy(xpath = "//input[@name='entityName']")
    private WebElement enterBranchName;

    @FindBy(xpath = "//input[@name='branchCode']")
    private WebElement enterBranchCode;

    @FindBy(xpath="//textarea[@name='address1']")
    private WebElement enterBranchAddress;

    @FindBy(xpath="//input[@name='phone1']")
    private WebElement enterPhoneNumber;

    @FindBy(xpath="//input[@name='mobile']")
    private WebElement enterMobileNumber;

    @FindBy(xpath="//input[@name='fax']")
    private WebElement enterFax;

    @FindBy(xpath="//input[@name='email']")
    private WebElement enterEmailAddress;

    @FindBy(xpath="//select[@name='country']")
    private WebElement selectCountry;

    @FindBy(xpath="//input[@name='state']")
    private  WebElement enterState;

    @FindBy(xpath="//input[@name='city']")
    private WebElement enterCity;

    @FindBy(xpath="//textarea[@name='comments']")
    private WebElement userComments;

    @FindBy(xpath="//input[@value='Next >>']")
    private WebElement nextButton;

    // *** webelements of fees page ***

    @FindBy(xpath="//h3[text()='Create Branch/Agency:Configure Fees']")
    private WebElement configureFees;

    @FindBy(xpath="//input[@value='<< Back']")
    private WebElement backButton;

    @FindBy(xpath="//input[@value='  Next >>']")
    private WebElement feesNextButton;

    // ** weblements of limits page **

    @FindBy(xpath="//div[contains(text(),'Minimum Load Amount Per Card')]")
    private WebElement limitsConfirmation;

    @FindBy(xpath="//input[@value='Save']")
    private  WebElement saveButton;

    // weblement for successful branch creation

    @FindBy(xpath="//frame[@name='confirmCreateEntity']")
    private WebElement successFrame;

    @FindBy(xpath = "//h3[text()='Create Branch/Agency - Success']")
    private WebElement successfulBranchCreation;

    public boolean parentBranchSelected()   {return parentBranchSelected.isDisplayed();}

    public boolean movedToFeeSection() { return configureFees.isDisplayed();}

    public boolean branchCreatedAssert() {return successfulBranchCreation.isDisplayed();}

    public void branchCreationBOBKenya(String branchName,String branchCode,String emailID)
    {
        System.out.println("This request is to create branch in BOB Kenya application");
        Select product=new Select (productListSelection);
        List<WebElement> allProducts = product.getOptions();
        for(int i=0;i<allProducts.size();i++)
        {
            product.selectByIndex(i);
        }
        addProducts.click();
        submitButton.click();
        Generic.wait(5);
        System.out.println("Product selection is successful and navigated to next screen :-** "+createBranchPage.getText()+"** is displayed");

        // below line of code is to select the parents branch.
        if(parentBranchSelected.isDisplayed())
        {
            System.out.println("parent branch is selected");
        }
        chooseParentBranchLink.click();
        Generic.wait(5);
                mainBranchSelection.click();
        ///Generic.scrollToWebElement(driver,branchSubmit);
        branchSubmit.click();
        System.out.println("**Main branch is selected");
        enterBranchName.sendKeys(branchName);
        enterBranchCode.sendKeys(branchCode);
        enterBranchAddress.sendKeys("Vijayanagar bangalore");
        enterPhoneNumber.sendKeys("9900917736");
        enterMobileNumber.sendKeys("9900917736");
        enterEmailAddress.sendKeys(emailID);
        Select select =new Select(selectCountry);
        select.selectByVisibleText("Kenya");
        enterState.sendKeys("Karnataka");
        enterCity.sendKeys("Bangalore");
        userComments.sendKeys("Branch details are enetered");
        nextButton.click();

        //entering to fees page
        if(configureFees.isDisplayed())
        {
            System.out.println("branch details are filled");
        }
       // Generic.scrollToWebElement(driver,feesNextButton);
        feesNextButton.click();

        //entering to aml limits page
        if(limitsConfirmation.isDisplayed())
        {
            System.out.println("fees are configured and we are in aml limits page");
        }
       // Generic.scrollToWebElement(driver,saveButton);
        saveButton.click();
        Generic.wait(5);
        Generic.checkAlert(driver);
        driver.switchTo().frame(successFrame);
       // driver.switchTo().alert().accept();

       // Generic.wait(5);

        if(successfulBranchCreation.isDisplayed())
        {
            System.out.println("Branch is successfully created");
        }



   }

    /**
     * This method takes input as bank name ,based on that its redirected to respective bank branch creation page
     * @param bankName
     * @param branchName
     * @param branchCode
     * @param emailID
     */

    public void branchCreation(String bankName,String branchName,String branchCode,String emailID)
    {


        switch(bankName)
        {
            case "BOBKENYA":
                navigateToPage(branchManagement, createBranchLink);
                branchCreationBOBKenya(branchName,branchCode,emailID);
                break;

            default:
                System.out.println(bankName+ ":-  entered is not present in the prepaid system");



        }

    }





}

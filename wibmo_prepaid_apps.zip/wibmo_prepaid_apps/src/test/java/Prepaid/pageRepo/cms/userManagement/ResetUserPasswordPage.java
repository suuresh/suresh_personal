package Prepaid.pageRepo.cms.userManagement;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ResetUserPasswordPage extends BasePage {
    private WebDriver driver;

    public ResetUserPasswordPage(WebDriver driver){
        super(driver);
        this.driver=driver;
    }
    @FindBy(xpath = "//span[text()='User Management']")
    private WebElement userManagement;
    @FindBy(xpath = "//a[text()='Reset User Password']")
    private WebElement resetPasswordLink;
    @FindBy(xpath="//h3[text()='Reset Password']")
    private WebElement resetPasswordPage;
    @FindBy(xpath="//input[@name='UserName']")
    private WebElement searchUserField;
    @FindBy(xpath = "//select[@name='txtUserName']")
    private WebElement userNameDropDown;
    @FindBy(xpath = "//input[@value='Reset']")
    private WebElement resetButton;
    @FindBy(xpath = "//input[@value='Cancel']")
    private WebElement cancelButton;
    @FindBy(xpath = "//u[text()='Welcome to ACCOSA-Services']")
    private WebElement homePageWelcomeMsg;
    @FindBy(xpath = "//font[text()=\"'Successfully changed the Password! New password sent to the user's registered email Id. '\"]")
    private WebElement resetPasswordSuccessMsg;

    public Boolean clickResetPasswordLink(){
        navigateToPage(userManagement,resetPasswordLink);
        try{
            return(resetPasswordPage.isDisplayed());
        }
        catch(NoSuchElementException e){
            return false;
        }

    }
public void enterUserName(String userName){
    searchUserField.sendKeys(userName);
}

public void selectUsername(String userName){
    Select select=new Select(userNameDropDown);
    select.selectByVisibleText(userName);

}
public void clickResetButton(){
        resetButton.click();
}
public void clickCancelButton(){
        cancelButton.click();
}
public Boolean resetPassword(String userName) {
    enterUserName(userName);
    selectUsername(userName);
    clickResetButton();
    try {
        return (resetPasswordSuccessMsg.isDisplayed());
    } catch (NoSuchElementException e) {
        return false;
    }
}

public Boolean cancelResetPassword(String userName){
    enterUserName(userName);
    selectUsername(userName);
    clickCancelButton();
    try{
        return(homePageWelcomeMsg.isDisplayed());
    }catch(NoSuchElementException e){
        return false;
    }

    }
}


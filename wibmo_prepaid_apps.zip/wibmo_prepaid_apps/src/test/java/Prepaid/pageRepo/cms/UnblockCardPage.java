package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UnblockCardPage extends BasePage {

    private WebDriver driver;

    public UnblockCardPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    @FindBy(xpath = "//a[text()='Card Unblocking']")
    private WebElement cardUnblockLink;
    @FindBy(xpath = "//td[text()='Card Details']")
    private WebElement cardUnblockPage;
    @FindBy(xpath = "//input[@name='iccNumber']")
    private WebElement cardNumberField;
    @FindBy(xpath = "//input[@name='submit']")
    private WebElement submitButton;
    @FindBy(xpath = "//div[text()='Card Number :']")
    private WebElement unblockCardDetailsPage;
    @FindBy(xpath = "//input[@name='reason']")
    private WebElement commentsField;
    @FindBy(xpath = "//input[@value='Unblock Card']")
    private WebElement unblockButton;

    @FindBy(xpath = "//h3[text()='Unblock Card - Success']")
    private WebElement unblockSuccessMessage;

    public Boolean clickUnblockCardLink() {
        try {
            return (cardUnblockPage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void enterCardNumber(String cardNumber) {
        cardNumberField.sendKeys(cardNumber);
    }

    public void clickSubmitButton() {
        submitButton.click();
    }

    public Boolean submitCardDetails(String cardNumber) {
        enterCardNumber(cardNumber);
        clickSubmitButton();
        try {
            return (unblockCardDetailsPage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public Boolean verifyCardNumber(String maskedCardNumber) {
        String xpath = "//td[contains(text(),'" + maskedCardNumber + "')]";
        try {
            return (driver.findElement(By.xpath(xpath)).isDisplayed());

        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void enterComments() {
        commentsField.sendKeys("Unblocking the Temp Blocked Card.");
    }

    public void clickUnblockCardButton() {
        unblockButton.click();
    }

    public Boolean unblockCard() {
        enterComments();
        clickUnblockCardButton();
        try {
            return (unblockSuccessMessage.isDisplayed());
        } catch (NoSuchElementException e) {
            return false;
        }
    }


}

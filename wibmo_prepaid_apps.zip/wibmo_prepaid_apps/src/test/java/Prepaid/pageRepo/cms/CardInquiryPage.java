package Prepaid.pageRepo.cms;

/**@author Srikiran
 *
 */

import Prepaid.pageRepo.BasePage;
import library.Generic;
import library.Log;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class CardInquiryPage extends BasePage
{


	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public CardInquiryPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/**
	 *  Declaration of all the web elements of Card Inquiry Request.
	 */
	@FindBy(xpath="//iframe[@class='iframe']")
	public static WebElement cmsLeftMenuFrame;

	@FindBy(xpath="//a[text()='Card Inquiry']")
	public static WebElement cardInquiryLink;

	@FindBy(xpath="//span[text()='Card Management']")
	public static WebElement cardManagementLink;


//	@FindBy(xpath = "//table[@id='QUERY_SUB_TABLE']")
//	private WebElement cardDetailsDiv;
	String cardDetailsDiv = "//table[@id='QUERY_SUB_TABLE']";

	// Card Inquiry - Entry Details Page for View Card Summary page

	@FindBy(xpath="//input[@name='cardNumber']")
	private WebElement cardNumberTextbox;
	@FindBy(xpath="//input[@name='urn']")
	private WebElement urnNumberTextBox;
	@FindBy(xpath="//input[@name='submit']")
	private WebElement submitButton;

	
	
	//Card Summary Page
	
	@FindBy(xpath ="//strong[contains(text(),'Find below the summary of events that has occured on your card along with the available balance.')]")
	private WebElement summaryPageDesc;
	@FindBy(xpath = "//div[text() = 'Card Number :']")
	private WebElement cardNumberFieldLabel;
	@FindBy(xpath = "//div[text() = 'Card Status :']//following::td[1]")
	private WebElement cardStatus;

//	@FindBy(xpath = "//h4[contains(text(), 'Transaction Details')]")
//	private WebElement transactionDetailsHeader;

	String transactionDetailsHeader = "//h4[contains(text(), 'Transaction Details')]";



	public void navigateToCardInquiry(){
		navigateToPage(cardManagementLink, cardInquiryLink);
	}


	public void enterCardNumber(String cardnumber){
		cardNumberTextbox.sendKeys(cardnumber);
	}

	public void enterCardURN(String urn){
		urnNumberTextBox.sendKeys(urn);
	}

	public void submitCardInquiry(){
		submitButton.click();
		Generic.wait(10);
	}

	public void doCardInquiryBy(String cardData, String cardValue){
		switch(cardData){
			case "Card Number":
				enterCardNumber(cardValue);
				break;
			case "URN":
				enterCardURN(cardValue);
				break;
		}
		submitCardInquiry();
	}

	public boolean assertCardNumber(String cardNumber){
		System.out.println(cardDetailsDiv+"//div[contains(text(), 'Card Number')]/following::td[1]");
		String maskedCardNumber = driver.findElement(By.xpath(cardDetailsDiv+"//div[contains(text(), 'Card Number')]/following::td[1]")).getText().replaceAll("\\s", "");
		return Generic.getMaskedCardNumber(cardNumber).equalsIgnoreCase(maskedCardNumber);
	}
/*
----assertUrn is to comapare the serched urn in card Inquiry screen---
@author Swathi Rao
----
 */
	public boolean assertUrn(String urn){
		String ciUrn = driver.findElement(By.xpath("//div[contains(text(), 'URN')]/following::td[1]")).getText();
		return urn.equalsIgnoreCase(ciUrn);
	}

	/*
----assertCardStatus is to compare the status of the card in card Inquiry screen---
@author Swathi Rao
----
 */
	public void assertCardStatus(String cardstatus){
		String ciCardstatus = driver.findElement(By.xpath("//div[contains(text(), 'Card Status')]/following::td[1]")).getText();
		Generic.assertCompareString(ciCardstatus,cardstatus);
	}

	/*
----assertCardLimit is to compare the limit of the card in card Inquiry screen---
@author Swathi Rao
----
*/
	public void assertCardLimit(String cardlimit){
		String ciCardlimit = driver.findElement(By.xpath("//div[contains(text(), 'Card Limit')]/following::td[1]")).getText();
		Generic.assertCompareString(ciCardlimit,cardlimit);
	}

	/*
----assertCardLimit is to compare the limit of the card in card Inquiry screen---
@author Swathi Rao
----
*/
	public void assertAvailableBalance(String availablebalance){
		String ciavailablebalance = driver.findElement(By.xpath("//div[contains(text(), 'Available Balance')]/following::td[1]")).getText();
		Generic.assertCompareString(availablebalance,ciavailablebalance);
	}
	/*
    ----assertProduct is to comapare the product in card Inquiry screen---
    @author Swathi Rao
    ----
     */
	public void assertProduct(String product){
		String ciProduct = driver.findElement(By.xpath("//div[contains(text(), 'Product')]/following::td[1]")).getText();
		Generic.assertCompareString(product,ciProduct);
	}

		/*
    ----assertProduct is to compare the activation entry in card Inquiry screen---
    @author Swathi Rao
    ----
     */

	@FindBy(xpath = "//strong[contains(text(),'ICC_ACTIVATE')]")
	private WebElement activateEntry;

	public boolean assertActivateEntry(){
		return activateEntry.isDisplayed();
	}

			/*
    ----assertProduct is to compare the activation Fee entry in card Inquiry screen---
    @author Swathi Rao
    ----
     */

	@FindBy(xpath = "//strong[contains(text(),'ICC_FEE')]")
	private WebElement activateFeeEntry;

	public boolean assertActivateFeeEntry(){
		String actTxnRef = driver.findElement(By.xpath("//strong[contains(text(),'ICC_ACTIVATE')]/../table/tbody/tr[2]/td[1]")).getText();
		String feeTxnRef = driver.findElement(By.xpath("//strong[contains(text(),'ICC_FEE')]/../table/tbody/tr[2]/td[1]")).getText();
		return actTxnRef.equalsIgnoreCase(feeTxnRef);

	}



	public boolean assertCardDetails(String cardData, String expectedValue){
		String actualValue = driver.findElement(By.xpath(cardDetailsDiv+"//div[contains(text(), '"+cardData+"')]/following::td[1]")).getText().trim();
		return expectedValue.equalsIgnoreCase(actualValue);
	}

			/*
    ----assertTransactionFeeDetails is Generic function for  Fee entry of different transaction in card Inquiry screen---
    @author Swathi Rao
    ----
     */

	public boolean assertTransactionFeeDetails(String transactionType, String transactionRefNumber, String transactionData, String expectedValue){
		boolean  assertFlag = false;
		String transactionTag=null;
		String transactionTagFee="ICC_FEE";

		switch(transactionType)
		{
			case "Activation Fee":
				transactionTag = "ICC_ACTIVATE";
				break;
			case"Recharge Fee":
				transactionTag = "ICC_RECHARGE";
				break;
			case "Cancel Card Fee":
				transactionTag = "CANCEL_CARD";
				break;
            case "Replace Card Fee":
                transactionTag = "CARD_REPLACEMENT";
                break;

		}
		WebElement element = driver.findElement(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+transactionTag+"')]/../following::div[1]/strong[contains(text(),'"+transactionTagFee+"')]"));
		Generic.assertElementDisplayed(element, transactionType);
		List<WebElement> headerCount = driver.findElements(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+
				transactionTag+"')]/../following::div[1]/strong[contains(text(),'"+transactionTagFee+"')]"+"//following-sibling::table[1]/tbody/tr[1]/td"));
		String actualValue = driver.findElement(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+transactionTag+"')]/../following::div[1]/strong[contains(text(),'"+transactionTagFee+"')]"+
				"//following-sibling::table//u[contains(text(), '"+transactionData+"')]//following::td["+headerCount.size()+"]")).getText().trim();
		Log.info("Actual Value: "+actualValue+" - Expected Value: "+expectedValue);
		if(!actualValue.equalsIgnoreCase(expectedValue.trim())){
			Log.fail("Validation is Failed");
			return false;
		}else{
			return true;
		}
	}


	public boolean assertTransactionDetails(String transactionType, String transactionRefNumber, String transactionData, String expectedValue){
		boolean  assertFlag = false;
		String transactionTag=null;

		switch(transactionType)
		{
			case "Activation":
				transactionTag = "ICC_ACTIVATE";
				break;
			case"Fee":
				transactionTag = "ICC_FEE";
				break;
			case"Temporary Block":
				transactionTag = "TEMP_CARD_BLOCK";
				break;
			case"Permanent Block":
				transactionTag = "PERMANENT_CARD_BLOCK";
				break;
			case"Unblock card":
				transactionTag = "CARD_UNBLOCK";
				break;
			case"Recharge card":
				transactionTag = "ICC_RECHARGE";
				break;
			case"Recharge Fee":
				transactionTag = "ICC_FEE";
				break;
			case"Card Adjustment Credit":
				transactionTag = "CARD_ADJUSTMENT_CR";
				break;
			case"Card Adjustment Debit":
				transactionTag = "CARD_ADJUSTMENT_DR";
				break;
			case"Cancel Card":
				transactionTag = "CANCEL_CARD";
				break;
            case"Replace Card":
                transactionTag = "CARD_REPLACEMENT";
                break;
			case"Replaced Card":
				transactionTag = "REPLACED_CARD";
				break;

		}
		WebElement element = driver.findElement(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+transactionTag+"')]"));
		Generic.assertElementDisplayed(element, transactionType);
		List<WebElement> headerCount = driver.findElements(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+
				transactionTag+"')]"+"//following-sibling::table[1]/tbody/tr[1]/td"));
		String actualValue = driver.findElement(By.xpath(transactionDetailsHeader+"/following::div/strong[contains(text(), '"+transactionTag+"')]"+
				"//following-sibling::table//u[contains(text(), '"+transactionData+"')]//following::td["+headerCount.size()+"]")).getText().trim();
		Log.info("Actual Value: "+actualValue+" - Expected Value: "+expectedValue);
		if(!actualValue.equalsIgnoreCase(expectedValue.trim())){
			Log.fail("Validation is Failed");
			return false;
		}else{
			return true;
		}
	}

	public void EnterCardDetailsCardInquiry(String CardNumber, String URNNumber){
		navigateToPage(cardManagementLink, cardInquiryLink);
		cardNumberTextbox.sendKeys(CardNumber);
		urnNumberTextBox.sendKeys(URNNumber);
		submitButton.click();
		Generic.wait(3);
	}

	public String GetCardDetails(String CardNumber, String URNNumber, String Detail){
		if(!summaryPageDesc.isDisplayed())EnterCardDetailsCardInquiry(CardNumber, URNNumber);
		return driver.findElement(By.xpath("//div[contains(text(), '"+Detail+"')]//following::td[1]")).getText();
	}
}

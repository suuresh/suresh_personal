package Prepaid.pageRepo.cms;
/**
 * @author srikiran.d
 * EOD jobs Module
 * functions : RunEODJob, 
 */

import static org.testng.Assert.assertEquals;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class EODJobsPage extends BasePage
{
public static String jobExecutionTime=null;
	private WebDriver driver;

	/**
	 * Initialization of all the web elements.
	 * @param driver
	 */
	public EODJobsPage(WebDriver driver){
		super(driver);
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	/***
	 * Declaration of all the web elements for EOD Jobs - Jobs List page
	 */
		
	@FindBy(xpath="//form[@name='jobList']")
	private WebElement batch;

	//EOD Jobs
	@FindBy (xpath="//span[text()='EOD Jobs']")
	public static WebElement EODJobs;
	@FindBy (xpath="//a[text()='Jobs List']")
	public static WebElement JobsList;
	@FindBy (xpath="//a[text()='Jobs Status']")
	public static WebElement JobsStatus;
	
	/* 
	Run Job Link - //form[@name='jobList']/table//b[contains(text(),'billing')]//following::a[1]
	Edit Job Link - //form[@name='jobList']/table//b[contains(text(),'billing')]//following::a[2]
	Job history Link - //form[@name='jobList']/table//b[contains(text(),'billing')]//following::a[3]
	*/

	public boolean RunEODJob(String jobName) throws Exception
	{
		boolean Success = false;
		String jobToRun = "//form[@name='jobList']/table//b[contains(text(),'"+ jobName +"')]//following::a[1]";
		String jobStatus = "//form[@name='jobList']/table//b[contains(text(),'"+ jobName +"')]//following::td[2]";
		String jobRunTime="//form[@name='jobList']/table//b[contains(text(),'"+ jobName +"')]//following::td[1]";
		String Status;
		
		navigateToPage(EODJobs, JobsList);
		Generic.wait(5);
		driver.findElement(By.xpath(jobToRun)).click();
		Generic.wait(5);
		assertEquals(driver.findElement(By.xpath(jobStatus)).getText(), "Running");
		navigateToPage(EODJobs, JobsStatus);
		//assertEquals(driver.findElement(By.xpath(jobStatus)).getText(), "Completed");
		do{
			driver.navigate().refresh();
			Generic.wait(5);
			Status = driver.findElement(By.xpath(jobStatus)).getText();
		}while(Status.contentEquals("Running"));
		System.out.println("The job status: "+Status);
		if(Status.equals("Completed")){
			Success = true;
			 jobExecutionTime=driver.findElement(By.xpath(jobRunTime)).getText();
		}else{
			Success = false;
		}
		return Success;
	}
}
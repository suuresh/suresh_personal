package Prepaid.pageRepo.cms;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import static org.testng.Assert.assertEquals;

/**
 * @author Sanmati Vardhaman on May,2021
 */
public class UploadBulkActivityFilePage extends BasePage
{
    WebDriver driver;
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public UploadBulkActivityFilePage(WebDriver driver)
    {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }


    /** Declaration of all the web elements */
    @FindBy(xpath="//iframe[@class='iframe']")
    private WebElement cmsFrame;

    @FindBy(xpath="//input[@value='Collapse']")
    private WebElement collapseLink;

    @FindBy(xpath="//span[text()='File Management']")
    private WebElement fileManagement;

    @FindBy(linkText ="Upload Bulk Activity File")
    private WebElement uploadBulkActivityFileLink;


    /*** bulk utility form webelemetns **************  */

    @FindBy(id="productId'")
    private WebElement productSelection;

    @FindBy(id="activity")
    private WebElement activitySelection;

    @FindBy(id="file_type")
    private WebElement fileTypeSelection;

    @FindBy(id="txtBrowse")
    private WebElement fileUpload;

    @FindBy(xpath="//textarea[@name='comments']")
    private WebElement commentBox;

    @FindBy(id="submit")
    private WebElement submitButton;

    @FindBy(xpath="//br[text()='File has been uploaded successfully.']")
    private WebElement fileUplaodSuccessMessage;


    // method to select the product and upload the file.

    public void bulkFileuploadFormOne(String productName,String activity,String fileType,String filePath)
    {
        Select selectProduct=new Select(productSelection);
        selectProduct.selectByVisibleText(productName);

        Select selectActivity=new Select(activitySelection);
        selectActivity.selectByVisibleText(activity);

        Select selectFileType=new Select(fileTypeSelection);
        selectFileType.selectByVisibleText(fileType);

        fileUpload.click();
        commentBox.sendKeys("Entering comments through automation");
        submitButton.click();

    }

    //method to move to file management and proceed with bulk activation
    public boolean bulkUtilityRequest(String productName, String activity, String fileType, String filePath)
    {
        navigateToPage(fileManagement, uploadBulkActivityFileLink);
        bulkFileuploadFormOne(productName, activity, fileType, filePath);
       //driver.switchTo().alert().accept();
        Generic.wait(5);
        assertEquals("File has been uploaded successfully.", fileUplaodSuccessMessage.getText());
        return fileUplaodSuccessMessage.isDisplayed();
    }


}

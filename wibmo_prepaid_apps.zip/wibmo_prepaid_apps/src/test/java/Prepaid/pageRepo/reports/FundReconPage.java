package Prepaid.pageRepo.reports;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class FundReconPage extends BasePage {
    private WebDriver driver;

    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    public FundReconPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(id="Product_selection")
    private WebElement productDropDown;
    @FindBy(xpath="//div[@id='parameterDialogokButton']/input")
    private WebElement submitButton;

    @FindBy(xpath="//div[text()='FUNDS RECONCILIATION REPORT']")
    private WebElement fundReconPage;

    @FindBy(xpath = "//table[@id='__bookmark_2']//tr[3]//td[18]/div/a")
    private WebElement expiredCardsLink;

    @FindBy(xpath="//table[@id='__bookmark_2']//tr")
    private List<WebElement> expiredTable;

    public void selectDropDown(String product){
        Generic.wait(03);
        Select selectProduct=new Select(productDropDown);
        selectProduct.selectByVisibleText(product);
    }

    public void submitParameterDetails(String product){
        selectDropDown(product);
        Generic.wait(03);
        WebDriverWait wait=new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.elementToBeClickable(submitButton));
        submitButton.click();

    }

    public Boolean verifyFundReconPage(){
       try{
           return(fundReconPage.isDisplayed());
       }
       catch(NoSuchElementException e){
           return false;
       }
    }

    public String getExpiredAmntInReconReport(){
        return(expiredCardsLink.getText());
    }

public Boolean expiredCardDetails(String urn){
        String parentWindow=driver.getWindowHandle();
    expiredCardsLink.click();
    //Generic.wait(05);
    String cardNumber;
    String urn_value;
     List<WebElement> td;
//To switch to card expiry drill down window.
   Set <String>windowHandles=driver.getWindowHandles();
    Iterator <String>it=windowHandles.iterator();
    System.out.println("no of windows:"+windowHandles.size());
    String childWindow;
    while(it.hasNext()){
        childWindow=it.next();
        if(!parentWindow.equalsIgnoreCase(childWindow)){
            driver.switchTo().window(childWindow);
              }

    }
//To Read the card expiry web table and check for the expired card details
    for(int i=1;i<expiredTable.size();i++){
      td=expiredTable.get(i).findElements(By.tagName("td"));
      for(int j=2;j<td.size();j++){
        if(td.get(j).findElement(By.tagName("div")).getText().trim().equals(urn))
        {
            cardNumber=td.get(j+1).findElement(By.tagName("div")).getText();
            System.out.println(cardNumber);
            //To Close child widow
            driver.close();
            driver.switchTo().window(parentWindow);
            return true;
        }
      }
    }
    //To Close child widow
driver.close();
    driver.switchTo().window(parentWindow);
return false;

}

}

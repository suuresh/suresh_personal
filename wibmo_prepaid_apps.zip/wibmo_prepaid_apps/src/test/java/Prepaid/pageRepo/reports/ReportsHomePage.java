package Prepaid.pageRepo.reports;

import Prepaid.pageRepo.BasePage;
import library.Generic;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReportsHomePage extends BasePage {
    /**
     * Instantiates a new base page.
     *
     * @param driver the driver
     */
    private WebDriver driver;
    public ReportsHomePage(WebDriver driver) {
        super(driver);
        this.driver=driver;
        PageFactory.initElements(this.driver, this);
    }
    @FindBy(xpath="//a[text()='Fund Recon Report ']")
    private WebElement reconReportLink;

    public void browseReportsPage(){
        driver.get(Generic.getPropValues("REPORT_URL"));
    }
    public void clickFundReconLink(){
        browseReportsPage();
        reconReportLink.click();
    }

}

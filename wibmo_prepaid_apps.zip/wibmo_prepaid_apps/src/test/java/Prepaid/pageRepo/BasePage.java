package Prepaid.pageRepo;

import Prepaid.testScripts.BaseTest1;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import library.Generic;
import library.Log;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;

//import org.openqa.selenium.By;

/**
 * The Class BasePage consists of elements and actions common to all the pages.
 * Can be extended by all the pages having common features.
 */
public class BasePage {

	/** The driver. */
	private WebDriver driver;

	private String bank;

	static SoftAssert sAssert;

	static ArrayList<String> upperNav;

	static ArrayList<String> lowerNav;

	/** Used to store all the Navigation link texts */
	static ArrayList<String> allNav;

    //author Srikiran
    //cms Menu Section
    @FindBy(xpath="//iframe[@class='iframe']")
    public static WebElement cmsLeftMenuFrame;

    @FindBy(xpath="//input[@value='Collapse']")
    public static WebElement collapseLink;

	//author:srikiran
	//Encryption Utility Page elements
	@FindBy(xpath="//input[@name='ip']")
	WebElement hsmIPTextfield;

	@FindBy(xpath="//input[@name='port']")
	WebElement hsmPortTextfield;

	@FindBy(xpath="//input[@name='key1']")
	WebElement hsmKeyAliasTextfield;

	@FindBy(xpath="//input[@name='Data']")
	WebElement clearData;

	@FindBy(xpath="//input[@value='Send to HSM']")
	WebElement send2HSMButton;

	@FindBy(xpath="//body[1]/textarea[1]")
	WebElement encryptedDataTextarea;


	@FindBy(name="submit")
	public WebElement signIn;

//	@FindBy(xpath="//a//b[contains(text(),'Sign Out')]")
//	public WebElement signOut;

	@FindBy(xpath="//b[contains(text(),'Logged in:')]") //--//following::font[contains(text(),'admin')]
	public WebElement loggedInLabel;

	@FindBy(xpath="//a[@href='/csr/CSRUserHandler?perform=logoff']")
	public WebElement signOut;

	@FindBy(linkText="/csr/accosa/Accosa.jsp")
	public WebElement accosaLink;

	@FindBy(xpath="//a[@href='/csr/accosa/AccosaLite.jsp']")
	public WebElement accosaLiteLink;

	//left Frame

	@FindBy(xpath="//iframe[@src='leftmenu.jsp']")
	public WebElement leftFrame;

	@FindBy(xpath="//a[text()='Prepaid Details']")
	protected WebElement prepaidDetails;

	@FindBy(xpath="//a[text()='Download Statement']")
	private WebElement downloadStatement;

	@FindBy(xpath="//a[text()='Enhanced Report']")
	protected WebElement enhacedReports;

	@FindBy(xpath="//a[text()='Exception Handling']")
	private WebElement exceptionHandling;

	@FindBy(xpath="//a[text()='Process Exception Items']")
	protected WebElement processExceptionItems;

	@FindBy(xpath="//a[text()='Chargeback Billed Items']")
	private WebElement chargebackBilledItems;

	@FindBy(xpath="//a[text()='Chargeback Billed Items(Lite)']")
	protected WebElement chargebackBilledItems_Lite;

	@FindBy(xpath="//a[text()='Process Chargeback Items']")
	private WebElement processChargebackItems;

	@FindBy(xpath="//a[text()='Credit Chargeback Amount']")
	private WebElement creditChargebackAmount;

	@FindBy(xpath="//a[text()='Credit Chargeback Amount(Lite)']")
	protected WebElement creditChargebackAmount_Lite;

	@FindBy(xpath="//a[text()='Process Blocked Cards']")
	private WebElement processBlockedCards;

	@FindBy(xpath="//a[text()='Process By Card Number']")
	private WebElement processByCardNumber;

	@FindBy(id="FromDate")
	private WebElement fromDate;

	@FindBy(id="ToDate")
	private WebElement toDate;

	@FindBy(xpath="//a[text()='Process Cache']")
	private WebElement processCache;

	@FindBy(id="publishText")
	private WebElement publish;

	@FindBy(id="publish")
	private WebElement submitPublish;

	@FindBy(xpath="//input[@name='ip']")
	WebElement hsmIP;

	@FindBy(xpath="//input[@name='port']")
	WebElement hsmPort;

	@FindBy(xpath="//input[@name='key1']")
	WebElement hsmKeyAlias;

	@FindBy(xpath="//input[@value='Send to HSM']")
	WebElement send2HSM;

	@FindBy(xpath="//body[1]/textarea[1]")
	WebElement encryptedData;

	/** Page title text .ios to be used only if the pagetitle has text value */
	@iOSXCUITFindBy(iOSNsPredicate = "value contains ' Verification' or value contains 'Hi '")
	@AndroidFindBy(id = "title_text")
	protected WebElement pageTitle;

	/** The more options Icon under the Navigation Panel. */
	@iOSXCUITFindBy(accessibility = "IconMenu")
	@AndroidFindBy(xpath = "//*[@content-desc='More options']|(//*[contains(@resource-id,'title_text')]/../../..//android.widget.ImageView)[last()]")
	protected WebElement moreOptions;

	/**
	 * The BasePage navigate link. For IOS Click on Back or Menu whichever is
	 * present under the TitleBar
	 */
	@iOSXCUITFindBy(iOSNsPredicate = "(name endswith 'Back' or name='IconMenu') and visible=true")
	@AndroidFindBy(xpath = "//*[@content-desc='Navigate up']")
	protected WebElement navigateLink;

	/** The about link under More Options Menu */
	@iOSXCUITFindBy(accessibility = "About")
	@AndroidFindBy(xpath = "//*[@text='About']")
	protected WebElement aboutLink;

	@FindBy(xpath = "//*[@text='FAQ']")
	protected WebElement faqLink;

	/** The Change User link under More Options Menu */
	@iOSXCUITFindBy(accessibility = "Change User")
	protected WebElement changeUserLink;

	/** The app version displayed in the About page */
	@FindBy(id = "fl_main_version")
	protected WebElement appVersion;

	/** The Navigation Elements displayed in the page. */
	@iOSXCUITFindBy(iOSNsPredicate = "name contains [ci]'IconMenu'") // //
																		// **/XCUIElementTypeTable/**/XCUIElementTypeStaticText[`name
																		// like "+'*'+"`]
	@AndroidFindBy(id = "design_menu_item_text")
	protected List<WebElement> navElements;

	/** The logout link under Navigation Panel */
	@iOSXCUITFindBy(accessibility = "Logout")
	@AndroidFindBy(xpath = "//*[@text='Logout']")
	protected WebElement logoutLink;

	/** The Program Card Link under Navigation Panel */
	@iOSXCUITFindBy(accessibility = "PayZapp Card")
	protected WebElement programCardLink;

	/** The MVISA Scan To Pay link under Navigation Panel */
	@iOSXCUITFindBy(accessibility = "Scan to Pay")
	protected WebElement scanToPayLink;

	/** The Recharge link under Navigation Panel */
	@iOSXCUITFindBy(iOSNsPredicate = "name beginswith 'Recharge'")
	protected WebElement rechargeLink;

	@iOSXCUITFindBy(iOSNsPredicate = "name beginswith 'Pay / Send'")
	protected WebElement addSendLink;

	/**
	 * The Check used to check for logout , whether the Logout Link occurred or not
	 */
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'message') or contains(@resource-id,'login_button')]")
	protected WebElement logoutChk;

	@iOSXCUITFindBy(iOSNsPredicate = "type='XCUIElementTypeNavigationBar' or (type='XCUIElementTypeButton' and name='Login')")
	protected List<WebElement> iosLogoutChk;

	@iOSXCUITFindBy(iOSNsPredicate = "type in {'XCUIElementTypeNavigationBar','XCUIElementTypeActivityIndicator'}")
	protected List<WebElement> iosPageloadChk;

	@FindBy(xpath = "//*[contains(@resource-id,'skip')]")
	protected WebElement logoutDontAskChkBox;

	@iOSXCUITFindBy(accessibility = "Yes")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'button1')]")
	protected WebElement logoutConfirmYesBtn;

	@iOSXCUITFindBy(accessibility = "Settings")
	@AndroidFindBy(xpath = "//*[@text='Settings']")
	protected WebElement settingsLink;

	@iOSXCUITFindBy(accessibility = "Transaction History")
	protected WebElement transactionHistoryLink;

	@AndroidFindBy(id = "image_manage_cards")
	@iOSXCUITFindBy(accessibility = "Manage Cards")
	protected WebElement manageCardsLink;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'message')]")
	protected WebElement alertMessage;

	/** The ok or the yes button where id=button1. */
	@iOSXCUITFindBy(accessibility = "Ok")
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'OK') or contains(@text,'Ok') or contains(@text,'ok')]")
	protected WebElement okButton;

	/** The ok or the yes button where id=button2. @see okButton */
	@iOSXCUITFindBy(accessibility = "Ok")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'button2')]")
	protected WebElement okBtn;

	@iOSXCUITFindBy(iOSNsPredicate = "name=[ci]'submit'")
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'cmdSubmit') or contains(@resource-id,'submitButton') or contains(@content-desc,'Submit')]")
	private WebElement submitBtn3ds;

	@FindBy(id = "sign_in_btn") // login_button
	private WebElement loginBtn;

	@FindBy(id = "menu_close")
	private WebElement closeAuthBtn;

	@iOSXCUITFindBy(iOSNsPredicate = "type='XCUIElementTypeButton' and visible=true")
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'text1')]")
	private List<WebElement> cancelReasons;
	

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'More')]")
	@iOSXCUITFindBy(accessibility = "More")
	private WebElement moreButton;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Yes')]")
	private WebElement yesButton;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Logout')]")
	@iOSXCUITFindBy(accessibility = "Logout")
	private WebElement logoutButton;

	/**
	 * Used to handle repeated Cancel reason List . Cick on CancelReason/PageTitle
	 */
	@AndroidFindBy(xpath = "//*[contains(@text,'Changed my mind') or contains(@resource-id,'title_text') or contains(@text,'Wibmo SDK')]")
	private WebElement cancelRedundantClick;

	@iOSXCUITFindBy(className = "XCUIElementTypePickerWheel")
	protected List<WebElement> dobPicker;

	@iOSXCUITFindBy(className = "XCUIElementTypePickerWheel")
	protected List<WebElement> expiryPicker;

	protected String prgBarTxtId = "progressBar";
	protected String prgBarTxtIdBdo = "progress_bar";

	protected String logoutConfirmTxt = "Are you sure";
	protected String navMenuIdTxt = "design_menu_item_text";

	@FindBy(xpath = "//*[@text='Ok' or @text='OK' or @text='YES' or @text='Proceed' or @text='PROCEED']")
	private WebElement alertAcceptBtn;

	@FindBy(xpath = "//*[@text='Cancel' or @text='CANCEL' or @text='NO' or @text='DECLINE']")
	private WebElement alertDismissBtn;

	// ========================= Navigation Check elements
	// ============================//

	@FindBy(id = "label_mvisa_qr_help")
	protected WebElement scanElement;

	@iOSXCUITFindBy(className = "XCUIElementTypeNavigationBar")
	@AndroidFindBy(id = "title_text")
	protected WebElement linkElement;

	@iOSXCUITFindBy(iOSNsPredicate = "name in {'Notifications','Ok'} and visible=true")
	protected WebElement notificationsAlert;

	@FindBy(id = "got_it_button")
	protected WebElement coachGotItBtn;

	// ================================================================================//

	// ================ IOS Logout Elements ================ //

	@iOSXCUITFindBy(className = "XCUIElementTypeApplication")
	protected WebElement iosAppName;

	@iOSXCUITFindBy(className = "XCUIElementTypeNavigationBar")
	protected WebElement navBarChk;

	@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeButton")
	protected List<WebElement> navBarBtns;

	// ============================================ //

	// ================= Logos ====================== //

	@iOSXCUITFindBy(accessibility = "Bank Logo")
	@AndroidFindBy(id = "pci_logo")
	protected WebElement bankLogo;

	@iOSXCUITFindBy(accessibility = "Wibmo Logo")
	@AndroidFindBy(id = "poweredby_logo")
	protected WebElement companyLogo;
	// ===========================================//

	// ======================Header Footer in CSR====================//
	@FindBy(xpath = "//td[@class='Table_Td_NA']/table/tbody/tr/td[2]/table/tbody/tr/td")
	private WebElement footerPath;

	@FindBy(xpath = "//a[@href='/csr/welcome.jsp']/font/../../../td[2]/p/a/font")
	private WebElement headerPath;

	//========================================================================//

	/**
	 * Instantiates a new base page.
	 *
	 * @param driver the driver
	 */
	public BasePage(WebDriver driver, String bank) {
		this.driver = driver;
		this.bank = bank;
        PageFactory.initElements(driver, this);
//		PageFactory.initElements(new AppiumFieldDecorator(this.driver, Duration.ofSeconds(30)), this);
		//Generic.wait(10);
	}

	/**
	 * Instantiates a new base page.
	 *
	 * @param driver the driver
	 */
	public BasePage(WebDriver driver) {
		this.driver = driver;
//		PageFactory.initElements(new AppiumFieldDecorator(this.driver, Duration.ofSeconds(30)), this);
		PageFactory.initElements(driver, this);
		//Generic.wait(10);
	}

	// ================== Wrapper Methods ================ //
	/**
	 * 
	 * @ios For IOS Element non null "value" or "name" attribute is returned
	 * @param element
	 * @return text value present in the element
	 */
	public String getText(WebElement element) {
		return Generic.getText(driver, element);
	}

	public void sendKeys(WebElement element, String text, String... customArgs) {
		element.sendKeys(text);
	}

	/**
	 * Used to perform universal click. Use customArgs to do different types of
	 * clicks
	 * 
	 * @param element
	 * @param customArgs
	 */
	public void click(WebElement element, String... customArgs) {
		if (Generic.isIos(driver))
			Generic.waitUntilIOSElementVisible(driver, element, 30);

		try {
			element.click();
		} catch (StaleElementReferenceException s) {
			Log.info("Warning : StaleElementReferenceException ");
			if (Generic.isIos(driver))
				return;

			driver.findElement(By.xpath("//*")); // WK UiAuto2
			element.click();
		}

	}

	public void clear(WebElement element, String... args) {
		Generic.clear(driver, element);
	}

	public void assertDisplayed(WebElement element, String... errMsg) {
		String msg = errMsg.length > 0 ? errMsg[0] : "";

		try {
			Generic.isDisplayed(element);
		} catch (Exception e) {
			Assert.fail(msg);
		}

	}

	public boolean isDisplayed(WebElement element) {
		return Generic.isDisplayed(element);
	}

	public void verifyNavigation(String data) {
		sAssert = new SoftAssert();

		obtainNavigationLinks(); // Android Only

		verifyLink(data, "Offers", "Offers");
		verifyLink(data, "Travel", "Travel");
		verifyLink(data, "Shopping", "Shopping");
		verifyLink(data, "Movies", "Movies");
		// verifyLink(data,"Dining","Dining");
		// verifyLink(data,"Gifting","Gifting");
		verifyLink(data, "Groceries & Dining", "Groceries & Dining");
		verifyLink(data, "Taxi", "Taxi");
		verifyLink(data, "Request Money", "Accepted");
		verifyLink(data, "Recent", "Recent");
		verifyLink(data, "Notifications", "Notifications");
		verifyLink(data, "Support", "Support");
		verifyLink(data, "About", "About");

		sAssert.assertAll();

	}

	/**
	 * Reads all the Navigation Link text values in to the allNav ArrayList
	 * 
	 */
	private void obtainNavigationLinks() {
		String navigationTxt;

		if (Generic.isIos(driver))
			return;

		allNav = new ArrayList<String>();

		Log.info("======== Clicking on Navigation ========");
		click(navigateLink);

		System.out.println(" nav Elements " + navElements.size());

		for (WebElement e : navElements) {
			navigationTxt = Generic.isAndroid(driver) ? e.getText() : Generic.getAttribute(e, "name");
			allNav.add(navigationTxt.toLowerCase()); // For IOS allNav is populated without scroll
		}

		if (Generic.isAndroid(driver)) {
			Generic.scroll(driver, "Logout");

			for (WebElement e : navElements)
				allNav.add(e.getText().toLowerCase());

			Generic.scroll(driver, "Home");
		}

		Log.info("======= Navigation Links found :" + allNav + " ========");

		Log.info("======== Navigating Back ========");
		Generic.navigateBack(driver);

	}

	private void verifyLink(String data, String linkName, String verifyText) {
		String actualText;

		if (!Generic.containsIgnoreCase(data, linkName))
			return; // Navigation Links which are present in the TestData will be checked

		// === IOS === //
		if (Generic.isIos(driver)) {
			verifyLinkIos(linkName, verifyText);
			return;
		}
		// =========//

		if (checkLink(linkName)) {
			Log.info("======== Clicking on Navigation ========");
			navigateLink.click();

			Log.info("======= Verifying " + linkName + " navigation link ========");

			if (Generic.isAndroid(driver)) // Scroll to Navigation Link Android
			{
				Generic.scroll(driver, linkName).click();
				Generic.wait(2);
			}

			else // Scroll to Navigation Link IOS
			{
				String navLinkClassChain = "**/XCUIElementTypeTable/**/XCUIElementTypeStaticText[`name contains \"navLinkText\"`]"
						.replace("navLinkText", linkName);
				IOSElement navLink = (IOSElement) driver.findElement(MobileBy.iOSClassChain((navLinkClassChain)));

				// === To be replaced with Generic.scroll() for ios === //
				if (Generic.getAttribute(navLink, "visible").equals("false")) // Swipe To IOS Element if not visible
					if (Generic.getAttribute(logoutLink, "visible").equals("false"))
						Generic.swipeToBottom(driver); // if at top swipe to bottom
					else
						Generic.swipeUp(driver); // if at bottom swipe to top
				// =============================== //

				navLink.click(); // Click on Navigation Element

				// === Handle Additional IOS Elements behaviour for Recent Transactions === //
				if (Generic.containsIgnoreCase(linkName, "Notifications"))
					notificationsAlert.click();
				if (Generic.containsIgnoreCase(linkName, "Recent"))
					Generic.wait(5); // Wait for Pageload

			}
			// === Validate Link === //
			try {
				actualText = Generic.isAndroid(driver) ? linkElement.getText()
						: Generic.getAttribute(linkElement, "name");
				Assert.assertTrue(Generic.containsIgnoreCase(actualText, verifyText),
						linkName + " screen not displayed with " + verifyText + "," + actualText + " displayed.");
			} catch (Exception e) {
				Assert.fail(linkName + " screen was not displayed with " + verifyText + " text\n" + e.getMessage());
			}

			if (Generic.isAndroid(driver)) {
				Log.info("======== Navigating back ========");
				Generic.navigateBack(driver);
			} else
				navigateLink.click(); // NavigateLink=Back Button IOS

			Generic.wait(2);
		} else // Link not present in Navigation . If link present then only validate link.
			Log.info("==" + linkName + " link not present in Navigation ==");

	}

	private void verifyLinkIos(String linkName, String verifyText) {
		String actualTxt;
		String navLinkClassChain = "**/XCUIElementTypeTable/**/XCUIElementTypeStaticText[`name contains \"navLinkText\"`]"
				.replace("navLinkText", linkName);
		IOSElement navLink = (IOSElement) driver.findElement(MobileBy.iOSClassChain((navLinkClassChain)));

		navigateLink.click();

		Log.info("======== Clicking on Navigation link : " + linkName + " ========");
		// === To be replaced with Generic.scroll() for ios === //
		if (Generic.getAttribute(navLink, "visible").equals("false")) // Swipe To IOS Element if not visible`
			if (Generic.getAttribute(logoutLink, "visible").equals("false"))
				Generic.swipeToBottom(driver); // if at top swipe to bottom
			else
				Generic.swipeUp(driver); // if at bottom swipe to top
		// =============================== //

		navLink.click(); // Click on Navigation Element

		// === Handle Additional IOS Elements behaviour for Recent Transactions === //
		if (Generic.containsIgnoreCase(linkName, "Notifications"))
			notificationsAlert.click();
		// === Wait for recent transactions to load
		if (Generic.containsIgnoreCase(linkName, "Recent"))
			waitOnProgressBarId(30);

		// === Validate Link === //
		try {
			actualTxt = Generic.getAttribute(linkElement, "name");
			Assert.assertTrue(Generic.containsIgnoreCase(actualTxt, verifyText),
					linkName + " screen not displayed with " + verifyText + "," + actualTxt + " displayed.");
		} catch (Exception e) {
			Assert.fail(linkName + " screen was not displayed with " + verifyText + " text\n" + e.getMessage());
		}

		Log.info("======== Navigating back ========");
		navigateLink.click();

		// Form nested element from xcuitable or attempt \ classchain join
		// click navigate
		// click element
		// verify element
		// click back

	}

	/**
	 * Checks whether the navigation linkname is present in the allNav String list
	 * 
	 * @param linkName
	 * @return
	 */
	private boolean checkLink(String linkName) {
		for (String s : allNav)
			if (Generic.containsIgnoreCase(s, linkName)) {
				Log.info("======== " + linkName + " link found ========");
				return true;
			}
		return false;
	}

	/**
	 * 
	 * Selects the given date
	 * 
	 * @param dateField
	 * @param date
	 */
	protected void selectDateIos(WebElement dateField, String date) {
		String dd = date.substring(0, 2), month = Generic.getMonthName(Integer.parseInt(date.substring(2, 4))),
				yyyy = date.substring(4);

		dateField.click();

		Log.info("======== Selecting " + dd + ' ' + month + ' ' + ' ' + yyyy + " ========");
		Generic.setValue(driver, dobPicker.get(2), yyyy);
		Generic.hideKeyBoard(driver);
		if (true)
			return;

		// dobPicker.get(2).sendKeys(yyyy);
		// dobPicker.get(1).sendKeys(month);
		// dobPicker.get(0).sendKeys(dd);

	}

	/**
	 * autoacceptAlert capability does not work for XCUITest. Hence the workaround
	 * 
	 */
	private void acceptAllowAlertIos() {

	}

	/**
	 * Navigates to Add Send page.
	 */
	private void gotoAddSendPage() {
		Log.info("======== Navigating to Pay / Send page ========");
		navigateLink.click();

		Log.info("======== Scrolling to PaySend navigation link ========");
		Generic.scroll(driver, "/ Send").click();
	}

	/**
	 * Navigates to Program Card page.
	 */
	public void gotoProgramCard() {
		String programName = Generic.getPropValues("PROGRAMNAME");
		Log.info("======== Navigating to " + programName + " card page ========");
		navigateLink.click();

		Generic.scroll(driver, programName + " Card").click();
	}

	/**
	 * Navigates to Recharge page.
	 */
	public void gotoRecharge() {
		Log.info("======== Navigating to Recharge Page ========");
		navigateLink.click();
		Generic.wait(2);
		Generic.scroll(driver, "Recharge").click();
	}

	public void gotoSettings() {
		Log.info("======== Navigating to Settings Page ========");
		navigateLink.click();
		Generic.wait(1);
		Generic.scroll(driver, "Settings").click();
	}

	/**
	 * Clicks 3DS submit button to be inherited by all 3DS methods.
	 */
	public void click3DSsubmit() {

		if (Generic.isIos(driver)) {
			submitBtn3ds.click();
			return;
		}

		AndroidDriver adriver = (AndroidDriver) driver;
		Generic.wait(2); // Wait for hidekeyboard bounce

		if (Generic.isUiAuto2(adriver)) {
			Log.info("======== Clicking on 3DS Submit button ========");
			submitBtn3ds.click();
		} else {
			Log.info("======== Submitting 3DS Pin ========");
			adriver.pressKeyCode(66);
		}
	}

	public void cancel3DSAuthentication() {
		Log.info("======== Closing Authentication Page ========");
		closeAuthBtn.click();
		okButton.click();
		handleCancelReason();
	}

	/**
	 * Handles the Cancel Reason list that occurs after Payment Cancellation.
	 *
	 */
	public void handleCancelReason() {
		Generic.wait(2);
		Log.info("======== Handling Cancel reason ========");
		try {
			cancelReasons.get(new Random().nextInt(cancelReasons.size() - 1)).click();
		} catch (Exception e) {
			Log.info("== Delay due to non occrence of Cancel reason list ==");
		}
		if (Generic.isIos(driver))
			return;

		// Handle redundancy in Cancel Reasons for some Android Versions
		Generic.wait(2);
		try {
			cancelRedundantClick.click();
		} catch (Exception e) {
			Log.info("== Cancel Reason Delay == ");
		}

	}

	/**
	 * Logs out from a given page if the logout option is present under More
	 * Options. Otherwise it logs out from Navigation
	 */
	public boolean logOut() {
		Log.info("==== User is trying to Logout ====");
		
		Generic.isDisplayed(moreButton);
		moreButton.click();
		logoutButton.click();
		try {
			if (Generic.isAndroid(driver)) {
				yesButton.click();
			} else if (Generic.isIos(driver)) {
				okButton.click();
			}
		} catch (Exception e) {
		}
		Log.info("==== User successfully Logout ====");
		return false;
		
	} // Use startActivity under advancedLaunch()

	/**
	 * Logs Out from any page .
	 * 
	 */
	public boolean logOutIos() {
		try {
			// if(getText(iosAppName).contains("Test")) return; // No Logout for Merchant
			// App

			if (navBarChk.getAttribute("visible").equals("false")) {
				System.out.println("IOS Navigation disabled for logout");
				return false;
			} // Logout not possible if Navigation bar not visible

			// === if XCUIElementTypeNavigationBar button children contains Back then click
			// back === //
			for (WebElement navBarBtn : navBarBtns)
				if (navBarBtn.getAttribute("name").contains("Back")) {
					System.out.println("Clicking on Back button in IOS");
					navBarBtn.click();
					Generic.wait(1);
					break;
				}

			// === If Login button present in Page , then logged out === //
			if (iosLogoutChk.size() > 1)
				return true; // true

			// ===Complete logout : if XCUIElementTypeNavigationBar button children contains
			// IconMenu then click IconMenu === //

			for (WebElement navBarBtn : navBarBtns)
				if (navBarBtn.getAttribute("name").contains("IconMenu")) {
					System.out.println("Logging out from Navigation Panel IOS");
					navBarBtn.click();
					Generic.wait(1); // WDA visibility
					Generic.tap(driver, Generic.scroll(driver, "Logout"));
					logoutConfirmYesBtn.click();
					waitOnProgressBarId(30);
					break;
				}
			return iosLogoutChk.size() > 1;
		} catch (Exception e) {
			System.err.println("Unable to logout");
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Handles the Logout alert if it occurs and waits for Logout to complete.
	 * 
	 */
	private void handleLogout() {
		handleLogoutAlert();

		waitOnProgressBarId(30);

		try {
			new WebDriverWait(driver, 30).pollingEvery(1, TimeUnit.SECONDS).ignoring(Exception.class)
					.until(ExpectedConditions.visibilityOf(loginBtn));
		} catch (Exception e) {
			System.err.println("Unable to logout" + e.getMessage());
		}

	}

	/**
	 * Handles logout confirmation Alert if it occurs
	 * 
	 */
	private void handleLogoutAlert() {
		Generic.wait(1);

		if (Generic.checkTextInPageSource(driver, logoutConfirmTxt).contains(logoutConfirmTxt)) {
			System.out.println("=== Handling Logout confirmation Alert ===");
			logoutDontAskChkBox.click();
			Generic.wait(1);
			logoutConfirmYesBtn.click();
		}

	}

	/**
	 * Waits for the page to load completely based on the visibility of the
	 * progressbar. prgBarTxtId String can be overridden
	 *

	 * @param timeout     in seconds
	 */
	public void waitOnProgressBarId(int timeout) {

		int i = 0, j;
		System.out.println("======== Waiting for Page Load to Complete ========");

		try {
			for (i = 0; i < timeout / 2; i++) {
				Generic.wait(2);

				if (Generic.isAndroid(driver)) // Android

					if (!driver.getPageSource().contains(prgBarTxtId)) // id=smoothprogressbar
						break;
					else
						System.out.println("Waiting for Pageload : " + i);

				else // IOS

				if ((j = iosPageloadChk.size()) == 1)
					break;
				else
					System.out.println("Waiting for IOS Pageload : " + j);

			}
		} catch (Exception e) {
			System.err.println("=======Error during the page load=======");
		}

		if (i >= timeout - 1)
			System.out.println("== PageLoad Delay ==");
	}

	/**
	 * Waits for the page to load completely based on the visibility of the for BDO
	 * app progressbar. prgBarTxtId String can be overridden
	 * 
	 * @author Rashmi
	 * @param timeout     in seconds
	 */
	public void waitOnProgressBarIdBDO(int timeout) {

		int i = 0, j;
		System.out.println("======== Waiting for Page Load to Complete ========");

		try {
			for (i = 0; i < timeout / 2; i++) {
				Generic.wait(5);

				if (Generic.isAndroid(driver)) // Android

					if (!driver.getPageSource().contains(prgBarTxtIdBdo)) // id=smoothprogressbar
						break;
					else
						System.out.println("Waiting for Pageload : " + i);

				else // IOS

				if ((j = iosPageloadChk.size()) == 1)
					break;
				else
					System.out.println("Waiting for IOS Pageload : " + j);

			}
		} catch (Exception e) {
			System.err.println("=======Error during the page load=======");
		}

		if (i >= timeout - 1)
			System.out.println("== PageLoad Delay ==");
	}

	/**
	 * Reads and initialises the global autVersion to AUT Version
	 * 
	 */
	public String getAutVersion() {
		if (!BaseTest1.autVersion.isEmpty())
			return BaseTest1.autVersion;

		try {

			moreOptions.click();
			aboutLink.click();

			BaseTest1.autVersion = BaseTest1.autVersion + getText(appVersion);
			navigateLink.click();

		} catch (Exception e) {
		}

		return BaseTest1.autVersion;
	}

	public void verifyPageTitle(String expectedTitle) {
		String actualTitle = "";

		try {

			new WebDriverWait(driver, 30).until(ExpectedConditions.textToBePresentInElement(pageTitle, expectedTitle));
			Log.info("======== Page Title : " + (actualTitle = getText(pageTitle)) + " ========");
			Assert.assertTrue(actualTitle.contains(expectedTitle), "Incorrect Pagetitle : " + actualTitle);

		} catch (Exception e) {
			Log.info("Error : Incorrect Pagetitle " + actualTitle);
		} catch (AssertionError ae) {
			Log.info("Error : Incorrect PageTitle " + actualTitle);
		}

	}

	private void verifyAlert(boolean accept, int alertTimeout, String[] expectedAlertContents) {
		String alertText = "__";
		Alert alert = null;

		try {
			if (Generic.isAndroid(driver)) // Android
			{
				alertAcceptBtn.isDisplayed();
				alertText = alertMessage.getText();
			} else // IOS
			{
				WebDriverWait wait = new WebDriverWait(driver, alertTimeout);
				wait.until(ExpectedConditions.alertIsPresent());
				alert = driver.switchTo().alert();
				alertText = alert.getText();
			}
		} catch (Exception e) {
			Assert.fail("Expected Alert not found" + e.getMessage());
		}

		Log.info("======== Verifying Alert message " + alertText + " ========");

		for (String alertContent : expectedAlertContents)
			Assert.assertTrue(alertText.contains(alertContent), "Incorrect alert message : " + alertText);

		Log.info("======== Accepting Alert ========");

		if (Generic.isAndroid(driver))

			if (accept)
				click(alertAcceptBtn); // Accept Alert button1 Rightmost btn
			else
				click(alertDismissBtn); // Cancel Alert button2 Leftmost btn

		else // IOS
		if (accept)
			alert.accept();
		else
			alert.dismiss();

	}

	/** Can be used to verify two Alert with two buttons */
	public void verifyAlertAndAccept(int timeout, String... expectedAlertContents) {
		verifyAlert(true, timeout, expectedAlertContents);
	}

	/** Can be used to verify two Alert with two buttons */
	public void verifyAlertAndDismiss(int timeout, String... expectedAlertContents) {
		verifyAlert(false, timeout, expectedAlertContents);
	}

	/**
	 * To be updated
	 * 
	 * @param date        as dd/mm/yyyy
	 */
	public void enterDateAndroid(WebElement dateTxtField, String date) {
		By dobIcon = By.id("main_dob_icon"); // Global private
		By dobOkBtn = By.xpath("(//android.widget.Button)[last()]");

		Log.info("======== Entering date : " + date + " ========");

		// ====================== //
		if (Generic.getUdId(driver).contains("ZY223CPDLT")) // Swipe click backwards
		{
			String yearEntryXp = "(//*[contains(@resource-id,text1) and contains(@text,'20')])[2]";
			driver.findElement(dobIcon).click();

			for (int i = 0; i < 10; i++) {
				driver.findElement(By.xpath("//*[contains(@resource-id,'date_picker_header_year')]")).click();
				driver.findElement(By.xpath(yearEntryXp)).click();
			}

			driver.findElement(dobOkBtn).click();
		}
		// ========================//
		if (Generic.getUdId(driver).contains("420085dad66ba291")) // direct sendkeys
			dateTxtField.sendKeys(date);
		// ========================//
		if (Generic.getUdId(driver).contains("YED7N16901000792")) // enter into mutable scroll
		{
			driver.findElement(dobIcon).click();
			String yearEntryXp = "(//*[contains(@resource-id,'numberpicker_input')])[3]";

			driver.findElement(By.xpath(yearEntryXp)).click();
			driver.findElement(By.xpath(yearEntryXp)).clear();
			driver.findElement(By.xpath(yearEntryXp)).sendKeys("2000");

			driver.findElement(dobOkBtn).click();
		}
	}
		public void footerDisplayed(){

			footerPath.isDisplayed();
			System.out.println("Footer present");
			String footername="Wibmo";

			assertEquals(footerPath.getText(), footername, "Footer displayed is  " + footerPath.getText());


		}

		public void headerDisplayed() {

			SoftAssert sa = new SoftAssert();
			String name="Customer Service";
			headerPath.isDisplayed();
			System.out.println("Header present");

			sa.assertEquals(headerPath.getText(), name);
			sa.assertAll();



		}

	//This method is to decrypt and get clear value from HSM encrypted value.
	//@author srikiran.d
	public String text2HSMencryption(String text, String hsmIP, String hsmPort, String hsmKey) throws Exception {
		hsmIPTextfield.clear();
		hsmIPTextfield.sendKeys(hsmIP);
		hsmPortTextfield.clear();
		hsmPortTextfield.sendKeys(hsmPort);
		hsmKeyAliasTextfield.clear();
		hsmKeyAliasTextfield.sendKeys(hsmKey);
		send2HSMButton.click();
		return encryptedDataTextarea.getText();
	}

    public void switchToFrame(WebElement frame)
    {
        driver.switchTo().frame(frame);
        collapseLink.click();
        Generic.wait(5);
    }

	//cms Navigation
    public void navigateToPage(WebElement  elementMainMenu, WebElement elementSubMenu)
    {
        switchToFrame(cmsLeftMenuFrame);
        Generic.waitForElement(driver, elementMainMenu, 10);
        elementMainMenu.click();
        Generic.waitForElement(driver, elementSubMenu, 10);
        elementSubMenu.click();
        driver.switchTo().defaultContent();
        Generic.wait(5);
        driver.switchTo().defaultContent();
    }

	/**
	 * This method take two parameter, one is Webelement of ProductdropDown list, Second is name of the product.
	 * @param _prodName
	 * @param productName
	 */
	public void  productSelection(WebElement _prodName,String productName)	{
		Select product=new Select(_prodName);
		product.selectByVisibleText(productName);
	}
}
